import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { 
  Award, 
  Eye, 
  Shield, 
  Download, 
  Calendar,
  ExternalLink
} from "lucide-react";
import { useState } from "react";

interface Certificate {
  id: string;
  title: string;
  issuer: string;
  issueDate: string;
  expiryDate: string;
  credentialId: string;
  verified: boolean;
  skills: string[];
  score: number;
  level: string;
  verificationCode?: string;
  certificateHash?: string;
}

interface CertificateHeaderPopupProps {
  certificates: Certificate[];
  onViewCertificate: (certificate: Certificate) => void;
  onVerifyCertificate: (certificate: Certificate) => void;
  onDownloadCertificate: (certificate: Certificate) => void;
}

export default function CertificateHeaderPopup({
  certificates,
  onViewCertificate,
  onVerifyCertificate,
  onDownloadCertificate
}: CertificateHeaderPopupProps) {
  const [open, setOpen] = useState(false);

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button variant="ghost" size="sm" className="relative">
          <Award className="w-4 h-4 mr-2" />
          Earned Certifications
          <Badge 
            variant="secondary" 
            className="ml-2 bg-green-100 text-green-700 text-xs"
          >
            {certificates.length}
          </Badge>
        </Button>
      </PopoverTrigger>
      
      <PopoverContent className="w-96 p-0" align="end">
        <div className="p-4 border-b">
          <h3 className="font-semibold text-gray-900 mb-1">Your Certifications</h3>
          <p className="text-sm text-gray-600">
            {certificates.length} verified certificates earned
          </p>
        </div>
        
        <div className="max-h-96 overflow-y-auto">
          {certificates.length === 0 ? (
            <div className="p-4 text-center text-gray-500">
              <Award className="w-8 h-8 mx-auto mb-2 text-gray-300" />
              <p className="text-sm">No certificates yet</p>
              <p className="text-xs">Complete assessments to earn certificates</p>
            </div>
          ) : (
            <div className="space-y-0">
              {certificates.map((certificate, index) => (
                <div key={certificate.id} className="p-4 hover:bg-gray-50 transition-colors">
                  {index > 0 && <Separator className="mb-4" />}
                  
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center space-x-2 mb-1">
                        <Award className="w-4 h-4 text-yellow-500 flex-shrink-0" />
                        <h4 className="font-medium text-gray-900 text-sm truncate">
                          {certificate.title}
                        </h4>
                      </div>
                      <p className="text-xs text-gray-600 mb-1">{certificate.issuer}</p>
                      <div className="flex items-center space-x-3 text-xs text-gray-500">
                        <div className="flex items-center">
                          <Calendar className="w-3 h-3 mr-1" />
                          {new Date(certificate.issueDate).toLocaleDateString()}
                        </div>
                        <span className="font-medium text-green-600">
                          {certificate.score}%
                        </span>
                      </div>
                    </div>
                    
                    <div className="flex flex-col space-y-1 ml-3">
                      <Badge 
                        variant="outline" 
                        className="text-xs bg-green-50 text-green-700 border-green-200"
                      >
                        {certificate.level}
                      </Badge>
                      {certificate.verified && (
                        <Badge 
                          variant="outline" 
                          className="text-xs bg-blue-50 text-blue-700 border-blue-200"
                        >
                          Verified
                        </Badge>
                      )}
                    </div>
                  </div>
                  
                  {/* Skills */}
                  <div className="mb-3">
                    <div className="flex flex-wrap gap-1">
                      {certificate.skills.slice(0, 3).map((skill, skillIndex) => (
                        <Badge 
                          key={skillIndex} 
                          variant="secondary" 
                          className="text-xs bg-gray-100 text-gray-600"
                        >
                          {skill}
                        </Badge>
                      ))}
                      {certificate.skills.length > 3 && (
                        <Badge 
                          variant="secondary" 
                          className="text-xs bg-gray-100 text-gray-600"
                        >
                          +{certificate.skills.length - 3}
                        </Badge>
                      )}
                    </div>
                  </div>
                  
                  {/* Action Buttons */}
                  <div className="flex space-x-1">
                    <Button
                      size="sm"
                      variant="default"
                      onClick={() => {
                        onViewCertificate(certificate);
                        setOpen(false);
                      }}
                      className="flex-1 h-7 text-xs bg-blue-600 hover:bg-blue-700"
                    >
                      <Eye className="w-3 h-3 mr-1" />
                      View
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => {
                        onVerifyCertificate(certificate);
                        setOpen(false);
                      }}
                      className="flex-1 h-7 text-xs"
                    >
                      <Shield className="w-3 h-3 mr-1" />
                      Verify
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => {
                        onDownloadCertificate(certificate);
                        setOpen(false);
                      }}
                      className="flex-1 h-7 text-xs"
                    >
                      <Download className="w-3 h-3 mr-1" />
                      Download
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
        
        {certificates.length > 0 && (
          <>
            <Separator />
            <div className="p-3">
              <Button 
                variant="ghost" 
                size="sm" 
                className="w-full text-sm"
                onClick={() => setOpen(false)}
              >
                <ExternalLink className="w-4 h-4 mr-2" />
                View All Certifications
              </Button>
            </div>
          </>
        )}
      </PopoverContent>
    </Popover>
  );
}