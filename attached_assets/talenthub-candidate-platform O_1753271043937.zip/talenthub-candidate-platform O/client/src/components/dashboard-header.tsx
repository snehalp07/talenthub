import { useState } from "react";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Users, ChevronDown, LogOut } from "lucide-react";
import { User, Tenant } from "@shared/schema";

interface DashboardHeaderProps {
  user: User | null;
  tenant: Tenant | null;
}

export default function DashboardHeader({ user, tenant }: DashboardHeaderProps) {
  const { logoutMutation } = useAuth();
  const [currentRole, setCurrentRole] = useState(user?.role || "candidate");

  const getRoleDisplayName = (role: string) => {
    switch (role) {
      case "candidate": return "Candidate View";
      case "recruiter": return "Recruiter View";
      case "admin": return "Admin View";
      case "lms_user": return "LMS View";
      default: return "User View";
    }
  };

  const getPlanColor = (plan: string) => {
    switch (plan) {
      case "starter": return "bg-blue-100 text-blue-600";
      case "professional": return "bg-green-100 text-green-600";
      case "enterprise": return "bg-purple-100 text-purple-600";
      default: return "bg-gray-100 text-gray-600";
    }
  };

  return (
    <header className="bg-white border-b border-neutral-200 sticky top-0 z-50">
      <div className="flex items-center justify-between px-6 py-4">
        {/* Logo and Tenant Info */}
        <div className="flex items-center space-x-4">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
              <Users className="h-5 w-5 text-white" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-neutral-600">TalentHub</h1>
              <p className="text-sm text-neutral-500">
                {tenant?.name || "Your Organization"}
              </p>
            </div>
          </div>
        </div>

        {/* Role Switcher and User Menu */}
        <div className="flex items-center space-x-4">
          {/* Role Switcher */}
          <Select value={currentRole} onValueChange={setCurrentRole}>
            <SelectTrigger className="w-40">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="candidate">Candidate View</SelectItem>
              <SelectItem value="recruiter">Recruiter View</SelectItem>
              <SelectItem value="admin">Admin View</SelectItem>
              <SelectItem value="lms_user">LMS View</SelectItem>
            </SelectContent>
          </Select>

          {/* Subscription Status */}
          <Badge className={getPlanColor(tenant?.plan || "starter")}>
            <div className="w-2 h-2 rounded-full bg-current mr-2"></div>
            {tenant?.plan?.charAt(0).toUpperCase() + tenant?.plan?.slice(1) || "Starter"} Plan
          </Badge>

          {/* User Menu */}
          <div className="flex items-center space-x-2">
            <Avatar className="h-8 w-8">
              <AvatarFallback className="bg-primary/10 text-primary">
                {user?.firstName?.[0]}{user?.lastName?.[0]}
              </AvatarFallback>
            </Avatar>
            <div className="hidden md:block">
              <p className="text-sm font-medium text-neutral-600">
                {user?.firstName} {user?.lastName}
              </p>
              <p className="text-xs text-neutral-500 capitalize">{user?.role}</p>
            </div>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => logoutMutation.mutate()}
              disabled={logoutMutation.isPending}
            >
              <LogOut className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </div>
    </header>
  );
}
