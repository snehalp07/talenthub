import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useMutation } from "@tanstack/react-query";
import { 
  MapPin, 
  DollarSign, 
  Calendar, 
  Building, 
  Upload,
  FileText,
  User,
  Mail,
  Phone
} from "lucide-react";

interface JobPosting {
  id: number;
  title: string;
  organizationName: string;
  location: string;
  minSalary?: number;
  maxSalary?: number;
  experienceLevel: string;
  applicationDeadline?: string;
  description: string;
  requirements?: string;
  requiredSkills: string[];
  remoteAllowed: boolean;
}

interface JobApplicationModalProps {
  job: JobPosting | null;
  isOpen: boolean;
  onClose: () => void;
}

export default function JobApplicationModal({ job, isOpen, onClose }: JobApplicationModalProps) {
  const { toast } = useToast();
  const [formData, setFormData] = useState({
    coverLetter: "",
    expectedSalary: "",
    availabilityDate: "",
    portfolioUrl: "",
    resumeFile: null as File | null,
    candidateName: "",
    candidateEmail: "",
    candidatePhone: ""
  });

  const submitApplicationMutation = useMutation({
    mutationFn: async (applicationData: any) => {
      const res = await apiRequest("POST", "/api/job-applications", applicationData);
      return await res.json();
    },
    onSuccess: () => {
      toast({
        title: "Application Submitted",
        description: "Your job application has been submitted successfully!",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/job-applications"] });
      onClose();
      setFormData({
        coverLetter: "",
        expectedSalary: "",
        availabilityDate: "",
        portfolioUrl: "",
        resumeFile: null,
        candidateName: "",
        candidateEmail: "",
        candidatePhone: ""
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Application Failed",
        description: error.message || "Failed to submit application. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!job) return;

    if (!formData.candidateName || !formData.candidateEmail || !formData.coverLetter) {
      toast({
        title: "Missing Information",
        description: "Please fill in all required fields.",
        variant: "destructive",
      });
      return;
    }

    const applicationData = {
      jobId: job.id,
      candidateName: formData.candidateName,
      candidateEmail: formData.candidateEmail,
      candidatePhone: formData.candidatePhone,
      coverLetter: formData.coverLetter,
      expectedSalary: formData.expectedSalary,
      availabilityDate: formData.availabilityDate,
      portfolioUrl: formData.portfolioUrl,
      resumeAttached: !!formData.resumeFile
    };

    submitApplicationMutation.mutate(applicationData);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 5 * 1024 * 1024) { // 5MB limit
        toast({
          title: "File Too Large",
          description: "Resume file must be under 5MB.",
          variant: "destructive",
        });
        return;
      }
      setFormData(prev => ({ ...prev, resumeFile: file }));
    }
  };

  if (!job) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-xl font-bold text-sky-800">
            Apply for {job.title}
          </DialogTitle>
        </DialogHeader>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Job Details Sidebar */}
          <Card className="bg-sky-50 border-sky-200">
            <CardContent className="p-6">
              <h3 className="font-semibold text-sky-800 mb-4">Job Overview</h3>
              
              <div className="space-y-3 mb-4">
                <div className="flex items-center gap-2 text-sm">
                  <Building className="w-4 h-4 text-sky-600" />
                  <span>{job.organizationName}</span>
                </div>
                
                <div className="flex items-center gap-2 text-sm">
                  <MapPin className="w-4 h-4 text-sky-600" />
                  <span>{job.location}</span>
                  {job.remoteAllowed && <Badge variant="outline" className="ml-2">Remote OK</Badge>}
                </div>
                
                {(job.minSalary || job.maxSalary) && (
                  <div className="flex items-center gap-2 text-sm">
                    <DollarSign className="w-4 h-4 text-sky-600" />
                    <span>
                      {job.minSalary && job.maxSalary 
                        ? `₹${job.minSalary.toLocaleString()} - ₹${job.maxSalary.toLocaleString()}`
                        : job.minSalary 
                        ? `₹${job.minSalary.toLocaleString()}+`
                        : `Up to ₹${job.maxSalary?.toLocaleString()}`
                      }
                    </span>
                  </div>
                )}
                
                {job.applicationDeadline && (
                  <div className="flex items-center gap-2 text-sm">
                    <Calendar className="w-4 h-4 text-sky-600" />
                    <span>Apply by {new Date(job.applicationDeadline).toLocaleDateString()}</span>
                  </div>
                )}
              </div>

              {job.requiredSkills.length > 0 && (
                <div className="mb-4">
                  <h4 className="font-medium text-sky-800 mb-2">Required Skills</h4>
                  <div className="flex flex-wrap gap-2">
                    {job.requiredSkills.map((skill, index) => (
                      <Badge key={index} variant="secondary" className="bg-sky-100 text-sky-700">
                        {skill}
                      </Badge>
                    ))}
                  </div>
                </div>
              )}

              <div className="text-sm text-gray-600">
                <h4 className="font-medium text-sky-800 mb-2">Experience Level</h4>
                <Badge variant="outline">{job.experienceLevel}</Badge>
              </div>
            </CardContent>
          </Card>

          {/* Application Form */}
          <div>
            <form onSubmit={handleSubmit} className="space-y-4">
              {/* Personal Information */}
              <div className="space-y-4">
                <h3 className="font-semibold text-sky-800">Personal Information</h3>
                
                <div>
                  <Label htmlFor="candidateName" className="flex items-center gap-2">
                    <User className="w-4 h-4" />
                    Full Name *
                  </Label>
                  <Input
                    id="candidateName"
                    value={formData.candidateName}
                    onChange={(e) => setFormData(prev => ({ ...prev, candidateName: e.target.value }))}
                    placeholder="Enter your full name"
                    required
                  />
                </div>

                <div>
                  <Label htmlFor="candidateEmail" className="flex items-center gap-2">
                    <Mail className="w-4 h-4" />
                    Email Address *
                  </Label>
                  <Input
                    id="candidateEmail"
                    type="email"
                    value={formData.candidateEmail}
                    onChange={(e) => setFormData(prev => ({ ...prev, candidateEmail: e.target.value }))}
                    placeholder="Enter your email address"
                    required
                  />
                </div>

                <div>
                  <Label htmlFor="candidatePhone" className="flex items-center gap-2">
                    <Phone className="w-4 h-4" />
                    Phone Number
                  </Label>
                  <Input
                    id="candidatePhone"
                    type="tel"
                    value={formData.candidatePhone}
                    onChange={(e) => setFormData(prev => ({ ...prev, candidatePhone: e.target.value }))}
                    placeholder="Enter your phone number"
                  />
                </div>
              </div>

              {/* Application Details */}
              <div className="space-y-4">
                <h3 className="font-semibold text-sky-800">Application Details</h3>
                
                <div>
                  <Label htmlFor="coverLetter">Cover Letter *</Label>
                  <Textarea
                    id="coverLetter"
                    value={formData.coverLetter}
                    onChange={(e) => setFormData(prev => ({ ...prev, coverLetter: e.target.value }))}
                    placeholder="Explain why you're the perfect fit for this role..."
                    rows={4}
                    required
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="expectedSalary">Expected Salary (LPA)</Label>
                    <Input
                      id="expectedSalary"
                      value={formData.expectedSalary}
                      onChange={(e) => setFormData(prev => ({ ...prev, expectedSalary: e.target.value }))}
                      placeholder="e.g., 15-20"
                    />
                  </div>

                  <div>
                    <Label htmlFor="availabilityDate">Available From</Label>
                    <Input
                      id="availabilityDate"
                      type="date"
                      value={formData.availabilityDate}
                      onChange={(e) => setFormData(prev => ({ ...prev, availabilityDate: e.target.value }))}
                    />
                  </div>
                </div>

                <div>
                  <Label htmlFor="portfolioUrl">Portfolio/LinkedIn URL</Label>
                  <Input
                    id="portfolioUrl"
                    type="url"
                    value={formData.portfolioUrl}
                    onChange={(e) => setFormData(prev => ({ ...prev, portfolioUrl: e.target.value }))}
                    placeholder="https://linkedin.com/in/yourname"
                  />
                </div>

                <div>
                  <Label htmlFor="resumeFile" className="flex items-center gap-2">
                    <FileText className="w-4 h-4" />
                    Upload Resume (PDF, DOC)
                  </Label>
                  <div className="flex items-center gap-2">
                    <Input
                      id="resumeFile"
                      type="file"
                      accept=".pdf,.doc,.docx"
                      onChange={handleFileChange}
                      className="flex-1"
                    />
                    {formData.resumeFile && (
                      <Badge variant="secondary" className="flex items-center gap-1">
                        <Upload className="w-3 h-3" />
                        {formData.resumeFile.name}
                      </Badge>
                    )}
                  </div>
                  <p className="text-sm text-gray-500 mt-1">Max file size: 5MB</p>
                </div>
              </div>

              {/* Submit Buttons */}
              <div className="flex gap-3 pt-4">
                <Button
                  type="button"
                  variant="outline"
                  onClick={onClose}
                  className="flex-1"
                >
                  Cancel
                </Button>
                <Button
                  type="submit"
                  disabled={submitApplicationMutation.isPending}
                  className="flex-1 bg-sky-600 hover:bg-sky-700"
                >
                  {submitApplicationMutation.isPending ? "Submitting..." : "Submit Application"}
                </Button>
              </div>
            </form>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}