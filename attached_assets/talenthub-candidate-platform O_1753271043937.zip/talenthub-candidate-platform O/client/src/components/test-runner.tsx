import { useState, useEffect, useCallback } from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { 
  Clock, 
  ChevronLeft, 
  ChevronRight, 
  Flag, 
  CheckCircle, 
  AlertTriangle,
  X,
  Play,
  Pause,
  RotateCcw
} from "lucide-react";

interface Question {
  id: string;
  type: 'multiple_choice' | 'essay' | 'coding' | 'true_false';
  title: string;
  content: string;
  options?: string[];
  correctAnswer?: string | string[];
  points: number;
  timeLimit?: number;
  explanation?: string;
}

interface Test {
  id: string;
  title: string;
  description: string;
  duration: number; // in minutes
  totalQuestions: number;
  totalPoints: number;
  questions: Question[];
  passingScore: number;
  allowRetakes: boolean;
}

interface TestAttempt {
  id: string;
  testId: string;
  userId: string;
  answers: Record<string, any>;
  startTime: Date;
  endTime?: Date;
  timeSpent: number;
  score?: number;
  status: 'in_progress' | 'completed' | 'submitted';
}

interface TestRunnerProps {
  test: Test;
  onClose: () => void;
  onSubmit: (submissionData: { testId: string; answers: Record<string, any>; timeSpent: number }) => void;
}

export default function TestRunner({ test, onClose, onSubmit }: TestRunnerProps) {
  const { toast } = useToast();
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [answers, setAnswers] = useState<Record<string, any>>({});
  const [timeRemaining, setTimeRemaining] = useState(test.duration * 60); // Convert to seconds
  const [isPaused, setIsPaused] = useState(false);
  const [flaggedQuestions, setFlaggedQuestions] = useState<Set<string>>(new Set());
  const [isSubmitting, setIsSubmitting] = useState(false);

  const currentQuestion = test.questions[currentQuestionIndex];
  const isLastQuestion = currentQuestionIndex === test.questions.length - 1;
  const isFirstQuestion = currentQuestionIndex === 0;

  // Timer effect
  useEffect(() => {
    if (timeRemaining <= 0) {
      handleSubmitTest();
      return;
    }

    if (!isPaused) {
      const timer = setInterval(() => {
        setTimeRemaining(prev => prev - 1);
      }, 1000);

      return () => clearInterval(timer);
    }
  }, [timeRemaining, isPaused]);

  // Auto-save answers
  const saveAnswerMutation = useMutation({
    mutationFn: async (answerData: { questionId: string; answer: any }) => {
      const res = await apiRequest("POST", `/api/tests/${test.id}/save-answer`, answerData);
      return res.json();
    },
    onError: (error: Error) => {
      toast({
        title: "Auto-save failed",
        description: "Your answer couldn't be saved automatically.",
        variant: "destructive",
      });
    },
  });

  const handleAnswerChange = useCallback((questionId: string, answer: any) => {
    setAnswers(prev => ({ ...prev, [questionId]: answer }));
    
    // Auto-save the answer
    saveAnswerMutation.mutate({ questionId, answer });
  }, [saveAnswerMutation]);

  const handleNextQuestion = () => {
    if (!isLastQuestion) {
      setCurrentQuestionIndex(prev => prev + 1);
    }
  };

  const handlePreviousQuestion = () => {
    if (!isFirstQuestion) {
      setCurrentQuestionIndex(prev => prev - 1);
    }
  };

  const handleFlagQuestion = () => {
    const questionId = currentQuestion.id;
    setFlaggedQuestions(prev => {
      const newSet = new Set(prev);
      if (newSet.has(questionId)) {
        newSet.delete(questionId);
      } else {
        newSet.add(questionId);
      }
      return newSet;
    });
  };

  const handleSubmitTest = async () => {
    if (isSubmitting) return;
    
    setIsSubmitting(true);
    
    try {
      const timeSpent = (test.duration * 60) - timeRemaining;
      onSubmit({
        testId: test.id,
        answers,
        timeSpent
      });
      
      toast({
        title: "Test submitted",
        description: "Your test has been submitted successfully.",
      });
      
      onClose();
    } catch (error) {
      toast({
        title: "Submission failed",
        description: "There was an error submitting your test.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  const formatTime = (seconds: number) => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    
    if (hours > 0) {
      return `${hours}:${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
    }
    return `${minutes}:${secs.toString().padStart(2, '0')}`;
  };

  const getAnsweredCount = () => {
    return Object.keys(answers).length;
  };

  const getProgressPercentage = () => {
    return (currentQuestionIndex / test.questions.length) * 100;
  };

  const renderQuestionContent = () => {
    const currentAnswer = answers[currentQuestion.id];

    switch (currentQuestion.type) {
      case 'multiple_choice':
        return (
          <div className="space-y-4">
            <RadioGroup
              value={currentAnswer || ""}
              onValueChange={(value) => handleAnswerChange(currentQuestion.id, value)}
            >
              {currentQuestion.options?.map((option, index) => (
                <div key={index} className="flex items-center space-x-2">
                  <RadioGroupItem value={option} id={`option-${index}`} />
                  <Label htmlFor={`option-${index}`} className="flex-1 cursor-pointer">
                    {option}
                  </Label>
                </div>
              ))}
            </RadioGroup>
          </div>
        );

      case 'true_false':
        return (
          <div className="space-y-4">
            <RadioGroup
              value={currentAnswer || ""}
              onValueChange={(value) => handleAnswerChange(currentQuestion.id, value)}
            >
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="true" id="true" />
                <Label htmlFor="true" className="cursor-pointer">True</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="false" id="false" />
                <Label htmlFor="false" className="cursor-pointer">False</Label>
              </div>
            </RadioGroup>
          </div>
        );

      case 'essay':
        return (
          <div className="space-y-4">
            <Textarea
              value={currentAnswer || ""}
              onChange={(e) => handleAnswerChange(currentQuestion.id, e.target.value)}
              placeholder="Type your answer here..."
              className="min-h-[200px]"
            />
            <div className="text-sm text-gray-600">
              Word count: {(currentAnswer || "").split(/\s+/).filter(Boolean).length}
            </div>
          </div>
        );

      case 'coding':
        return (
          <div className="space-y-4">
            <Textarea
              value={currentAnswer || ""}
              onChange={(e) => handleAnswerChange(currentQuestion.id, e.target.value)}
              placeholder="Write your code here..."
              className="min-h-[300px] font-mono"
            />
            <div className="text-sm text-gray-600">
              Lines: {(currentAnswer || "").split('\n').length}
            </div>
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <div className="fixed inset-0 bg-white z-50 flex flex-col">
      {/* Header */}
      <div className="border-b bg-white px-6 py-4">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-xl font-semibold">{test.title}</h1>
            <p className="text-sm text-gray-600">
              Question {currentQuestionIndex + 1} of {test.questions.length}
            </p>
          </div>
          
          <div className="flex items-center space-x-4">
            {/* Timer */}
            <div className="flex items-center space-x-2">
              <Clock className="w-4 h-4" />
              <span className={`font-mono ${timeRemaining < 300 ? 'text-red-600' : ''}`}>
                {formatTime(timeRemaining)}
              </span>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setIsPaused(!isPaused)}
              >
                {isPaused ? <Play className="w-4 h-4" /> : <Pause className="w-4 h-4" />}
              </Button>
            </div>

            {/* Progress */}
            <div className="flex items-center space-x-2">
              <span className="text-sm">Progress:</span>
              <div className="w-32">
                <Progress value={getProgressPercentage()} />
              </div>
              <span className="text-sm">{getAnsweredCount()}/{test.questions.length}</span>
            </div>

            {/* Exit */}
            <Button variant="outline" onClick={onClose}>
              <X className="w-4 h-4 mr-2" />
              Exit Test
            </Button>
          </div>
        </div>
      </div>

      {/* Warning for low time */}
      {timeRemaining < 300 && (
        <Alert className="mx-6 mt-4 border-red-200 bg-red-50">
          <AlertTriangle className="h-4 w-4 text-red-600" />
          <AlertDescription className="text-red-800">
            Warning: Only {formatTime(timeRemaining)} remaining!
          </AlertDescription>
        </Alert>
      )}

      {/* Main Content */}
      <div className="flex-1 overflow-auto">
        <div className="max-w-4xl mx-auto p-6">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="flex items-center space-x-2">
                    <span>Question {currentQuestionIndex + 1}</span>
                    {flaggedQuestions.has(currentQuestion.id) && (
                      <Flag className="w-4 h-4 text-yellow-600 fill-current" />
                    )}
                  </CardTitle>
                  <CardDescription>
                    {currentQuestion.points} {currentQuestion.points === 1 ? 'point' : 'points'}
                    {currentQuestion.timeLimit && ` • ${currentQuestion.timeLimit} minutes`}
                  </CardDescription>
                </div>
                
                <Button
                  variant="outline"
                  size="sm"
                  onClick={handleFlagQuestion}
                >
                  <Flag className={`w-4 h-4 mr-1 ${flaggedQuestions.has(currentQuestion.id) ? 'fill-current text-yellow-600' : ''}`} />
                  Flag
                </Button>
              </div>
            </CardHeader>
            
            <CardContent className="space-y-6">
              <div>
                <h3 className="font-medium mb-2">{currentQuestion.title}</h3>
                <div 
                  className="prose prose-sm max-w-none"
                  dangerouslySetInnerHTML={{ __html: currentQuestion.content }}
                />
              </div>
              
              <Separator />
              
              {renderQuestionContent()}
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Footer Navigation */}
      <div className="border-t bg-white px-6 py-4">
        <div className="flex items-center justify-between">
          <Button
            variant="outline"
            onClick={handlePreviousQuestion}
            disabled={isFirstQuestion}
          >
            <ChevronLeft className="w-4 h-4 mr-2" />
            Previous
          </Button>
          
          <div className="flex items-center space-x-4">
            {/* Question Navigator */}
            <div className="flex items-center space-x-1">
              {test.questions.map((_, index) => (
                <Button
                  key={index}
                  variant={index === currentQuestionIndex ? "default" : "outline"}
                  size="sm"
                  className={`w-8 h-8 p-0 ${
                    answers[test.questions[index].id] ? 'bg-green-100 border-green-300' : ''
                  } ${
                    flaggedQuestions.has(test.questions[index].id) ? 'bg-yellow-100 border-yellow-300' : ''
                  }`}
                  onClick={() => setCurrentQuestionIndex(index)}
                >
                  {index + 1}
                </Button>
              ))}
            </div>
          </div>
          
          <div className="flex items-center space-x-2">
            {isLastQuestion ? (
              <Button
                onClick={handleSubmitTest}
                disabled={isSubmitting}
                className="bg-green-600 hover:bg-green-700"
              >
                <CheckCircle className="w-4 h-4 mr-2" />
                {isSubmitting ? "Submitting..." : "Submit Test"}
              </Button>
            ) : (
              <Button onClick={handleNextQuestion}>
                Next
                <ChevronRight className="w-4 h-4 ml-2" />
              </Button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}