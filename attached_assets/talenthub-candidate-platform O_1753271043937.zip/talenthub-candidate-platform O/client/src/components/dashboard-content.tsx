import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { 
  Users, 
  Briefcase, 
  CalendarCheck, 
  UserCheck, 
  Plus, 
  ClipboardCheck, 
  BarChart3,
  ArrowRight,
  UserRoundCheck,
  Shield,
  GraduationCap,
  Target
} from "lucide-react";
import { User, Tenant } from "@shared/schema";

interface DashboardContentProps {
  user: User | null;
  metrics?: {
    candidateCount: number;
    jobCount: number;
    interviewCount: number;
    hireCount: number;
  };
  recentCandidates?: User[];
  tenant?: Tenant | null;
}

export default function DashboardContent({ 
  user, 
  metrics, 
  recentCandidates = [],
  tenant 
}: DashboardContentProps) {
  const metricsData = [
    {
      title: "Active Candidates",
      value: metrics?.candidateCount || 0,
      change: "+12%",
      icon: Users,
      color: "bg-primary/10 text-primary"
    },
    {
      title: "Open Positions",
      value: metrics?.jobCount || 0,
      change: "+5%",
      icon: Briefcase,
      color: "bg-secondary/10 text-secondary"
    },
    {
      title: "Interviews This Week",
      value: metrics?.interviewCount || 0,
      change: "+8",
      icon: CalendarCheck,
      color: "bg-accent/10 text-accent"
    },
    {
      title: "Hires This Month",
      value: metrics?.hireCount || 0,
      change: "+3",
      icon: UserCheck,
      color: "bg-green-100 text-green-600"
    }
  ];

  const upcomingInterviews = [
    { candidate: "John Doe", position: "Full Stack Developer", time: "Today, 2:00 PM", action: "Join" },
    { candidate: "Sarah Wilson", position: "Product Manager", time: "Tomorrow, 10:00 AM", action: "Schedule" },
    { candidate: "Mike Johnson", position: "Data Scientist", time: "Friday, 3:30 PM", action: "Reschedule" }
  ];

  const quickActions = [
    { title: "Create Job Posting", icon: Plus, color: "bg-primary/5 text-primary hover:bg-primary/10" },
    { title: "Schedule Assessment", icon: ClipboardCheck, color: "bg-secondary/5 text-secondary hover:bg-secondary/10" },
    { title: "View Reports", icon: BarChart3, color: "bg-accent/5 text-accent hover:bg-accent/10" }
  ];

  const platformModules = [
    {
      title: "Candidate Platform",
      description: "Profile builder, job search, skill assessments",
      icon: UserRoundCheck,
      color: "bg-blue-100 text-blue-600",
      badge: "1,247 Active"
    },
    {
      title: "Admin Platform",
      description: "User management, system monitoring, analytics",
      icon: Shield,
      color: "bg-red-100 text-red-600",
      badge: "12 Admins"
    },
    {
      title: "LMS Platform",
      description: "Course library, progress tracking, certifications",
      icon: GraduationCap,
      color: "bg-green-100 text-green-600",
      badge: "85 Courses"
    },
    {
      title: "Assessment Engine",
      description: "Test creation, automated scoring, analytics",
      icon: Target,
      color: "bg-purple-100 text-purple-600",
      badge: "342 Tests"
    }
  ];

  return (
    <div className="p-8">
      {/* Dashboard Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-neutral-600 mb-2">
          {user?.role === 'recruiter' ? 'Recruiter Dashboard' : 'Dashboard'}
        </h1>
        <p className="text-neutral-500">
          Welcome back, {user?.firstName}! Here's what's happening with your platform.
        </p>
      </div>

      {/* Key Metrics Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {metricsData.map((metric, index) => (
          <Card key={index} className="shadow-sm">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <div className={`w-12 h-12 rounded-lg flex items-center justify-center ${metric.color}`}>
                  <metric.icon className="w-6 h-6" />
                </div>
                <Badge variant="outline" className="text-secondary">
                  {metric.change}
                </Badge>
              </div>
              <h3 className="text-2xl font-bold text-neutral-600 mb-1">
                {metric.value}
              </h3>
              <p className="text-sm text-neutral-500">{metric.title}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Main Dashboard Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-12">
        {/* Recent Candidates */}
        <div className="lg:col-span-2">
          <Card className="shadow-sm">
            <CardHeader className="pb-4">
              <div className="flex items-center justify-between">
                <CardTitle className="text-xl">Recent Candidates</CardTitle>
                <Button variant="ghost" size="sm">View All</Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {recentCandidates.length > 0 ? (
                  recentCandidates.map((candidate) => (
                    <div key={candidate.id} className="flex items-center space-x-4 p-4 hover:bg-neutral-50 rounded-lg transition-colors">
                      <Avatar className="h-12 w-12">
                        <AvatarFallback className="bg-primary/10 text-primary">
                          {candidate.firstName?.[0]}{candidate.lastName?.[0]}
                        </AvatarFallback>
                      </Avatar>
                      <div className="flex-1">
                        <h3 className="font-semibold text-neutral-600">
                          {candidate.firstName} {candidate.lastName}
                        </h3>
                        <p className="text-sm text-neutral-500 capitalize">{candidate.role}</p>
                        <div className="flex items-center space-x-2 mt-1">
                          <Badge variant="outline" className="text-xs">New</Badge>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="text-sm font-medium text-neutral-600">--</div>
                        <div className="text-xs text-neutral-500">Match Score</div>
                      </div>
                      <Button variant="ghost" size="sm">
                        <ArrowRight className="w-4 h-4" />
                      </Button>
                    </div>
                  ))
                ) : (
                  <div className="text-center py-8 text-neutral-500">
                    No candidates found. Start by creating job postings to attract talent.
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Sidebar Widgets */}
        <div className="space-y-8">
          {/* Upcoming Interviews */}
          <Card className="shadow-sm">
            <CardHeader className="pb-4">
              <CardTitle className="text-lg">Upcoming Interviews</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {upcomingInterviews.map((interview, index) => (
                  <div key={index} className="flex items-start space-x-3">
                    <div className="w-2 h-2 bg-primary rounded-full mt-2 flex-shrink-0"></div>
                    <div className="flex-1">
                      <h3 className="font-medium text-neutral-600">{interview.candidate}</h3>
                      <p className="text-sm text-neutral-500">{interview.position}</p>
                      <p className="text-xs text-neutral-400 mt-1">{interview.time}</p>
                    </div>
                    <Button variant="ghost" size="sm" className="text-primary text-xs">
                      {interview.action}
                    </Button>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Quick Actions */}
          <Card className="shadow-sm">
            <CardHeader className="pb-4">
              <CardTitle className="text-lg">Quick Actions</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {quickActions.map((action, index) => (
                  <Button
                    key={index}
                    variant="ghost"
                    className={`w-full justify-start ${action.color} transition-colors`}
                  >
                    <action.icon className="w-5 h-5 mr-3" />
                    {action.title}
                  </Button>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Billing Summary */}
          <Card className="shadow-sm">
            <CardHeader className="pb-4">
              <CardTitle className="text-lg">Billing Summary</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <span className="text-sm text-neutral-500">Current Plan</span>
                  <span className="font-semibold text-neutral-600 capitalize">
                    {tenant?.plan || "Starter"}
                  </span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-neutral-500">Monthly Spend</span>
                  <span className="font-semibold text-neutral-600">₹29,999</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-neutral-500">Usage Charges</span>
                  <span className="font-semibold text-neutral-600">₹4,250</span>
                </div>
                <div className="pt-3 border-t border-neutral-200">
                  <div className="flex justify-between items-center">
                    <span className="text-sm font-medium text-neutral-600">Total This Month</span>
                    <span className="font-bold text-lg text-neutral-600">₹34,249</span>
                  </div>
                </div>
                <Button variant="outline" className="w-full mt-4">
                  View Detailed Billing
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Multi-Module Integration Section */}
      <div>
        <h2 className="text-2xl font-bold text-neutral-600 mb-6">Platform Integration</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {platformModules.map((module, index) => (
            <Card 
              key={index} 
              className="shadow-sm hover:shadow-md transition-shadow cursor-pointer"
            >
              <CardContent className="p-6">
                <div className={`w-12 h-12 rounded-lg flex items-center justify-center mb-4 ${module.color}`}>
                  <module.icon className="w-6 h-6" />
                </div>
                <h3 className="text-lg font-semibold text-neutral-600 mb-2">
                  {module.title}
                </h3>
                <p className="text-sm text-neutral-500 mb-4">
                  {module.description}
                </p>
                <div className="flex items-center justify-between">
                  <Badge variant="outline" className="text-xs">
                    {module.badge}
                  </Badge>
                  <ArrowRight className="w-4 h-4 text-primary" />
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
}
