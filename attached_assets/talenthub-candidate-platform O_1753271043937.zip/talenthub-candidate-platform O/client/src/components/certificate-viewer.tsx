import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { 
  Award, 
  Download, 
  Share2, 
  Calendar, 
  User, 
  Building, 
  CheckCircle, 
  Shield,
  ExternalLink,
  QrCode,
  Printer,
  Copy
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface Certificate {
  id: string;
  title: string;
  description: string;
  type: 'test' | 'project' | 'mock_interview' | 'skill' | 'course';
  issuedDate: string;
  expiryDate?: string;
  issuer: {
    name: string;
    logo?: string;
    website?: string;
  };
  recipient: {
    name: string;
    email: string;
    id: string;
  };
  skills: string[];
  score?: number;
  passingScore?: number;
  credentialId: string;
  verificationUrl: string;
  status: 'active' | 'expired' | 'revoked';
  metadata?: {
    duration?: string;
    difficulty?: string;
    topics?: string[];
    grade?: string;
  };
}

interface CertificateViewerProps {
  certificate: Certificate;
  onClose?: () => void;
  showActions?: boolean;
}

export default function CertificateViewer({ certificate, onClose, showActions = true }: CertificateViewerProps) {
  const { toast } = useToast();
  const [isFullscreen, setIsFullscreen] = useState(false);

  const handleDownload = () => {
    // Create a downloadable certificate PDF
    toast({
      title: "Download started",
      description: "Your certificate is being prepared for download.",
    });
  };

  const handleShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: certificate.title,
          text: `I've earned a ${certificate.title} certificate!`,
          url: certificate.verificationUrl,
        });
      } catch (error) {
        // Fallback to copy URL
        handleCopyUrl();
      }
    } else {
      handleCopyUrl();
    }
  };

  const handleCopyUrl = async () => {
    try {
      await navigator.clipboard.writeText(certificate.verificationUrl);
      toast({
        title: "Link copied",
        description: "Verification link copied to clipboard.",
      });
    } catch (error) {
      toast({
        title: "Copy failed",
        description: "Unable to copy link to clipboard.",
        variant: "destructive",
      });
    }
  };

  const handlePrint = () => {
    window.print();
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'bg-green-100 text-green-800';
      case 'expired': return 'bg-yellow-100 text-yellow-800';
      case 'revoked': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'test': return <CheckCircle className="w-4 h-4" />;
      case 'project': return <Building className="w-4 h-4" />;
      case 'mock_interview': return <User className="w-4 h-4" />;
      case 'skill': return <Award className="w-4 h-4" />;
      case 'course': return <Shield className="w-4 h-4" />;
      default: return <Award className="w-4 h-4" />;
    }
  };

  const CertificateContent = () => (
    <div className="space-y-6">
      {/* Certificate Header */}
      <div className="text-center space-y-4 py-8 bg-gradient-to-br from-sky-50 to-blue-50 rounded-lg border">
        <div className="flex justify-center">
          <div className="w-16 h-16 bg-sky-600 rounded-full flex items-center justify-center">
            <Award className="w-8 h-8 text-white" />
          </div>
        </div>
        
        <div>
          <h1 className="text-2xl font-bold text-gray-900 mb-2">Certificate of Achievement</h1>
          <h2 className="text-xl font-semibold text-sky-700">{certificate.title}</h2>
        </div>

        <div className="text-center">
          <p className="text-gray-600">This is to certify that</p>
          <p className="text-xl font-semibold text-gray-900 mt-1">{certificate.recipient.name}</p>
          <p className="text-gray-600 mt-1">has successfully completed</p>
        </div>

        <div className="flex justify-center">
          <Badge variant="outline" className="text-sm">
            {getTypeIcon(certificate.type)}
            <span className="ml-1 capitalize">{certificate.type.replace('_', ' ')}</span>
          </Badge>
        </div>
      </div>

      {/* Certificate Details */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="text-base">Certificate Details</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex justify-between">
              <span className="text-gray-600">Issued Date:</span>
              <span className="font-medium">{new Date(certificate.issuedDate).toLocaleDateString()}</span>
            </div>
            
            {certificate.expiryDate && (
              <div className="flex justify-between">
                <span className="text-gray-600">Expires:</span>
                <span className="font-medium">{new Date(certificate.expiryDate).toLocaleDateString()}</span>
              </div>
            )}

            <div className="flex justify-between">
              <span className="text-gray-600">Status:</span>
              <Badge className={getStatusColor(certificate.status)}>
                {certificate.status}
              </Badge>
            </div>

            <div className="flex justify-between">
              <span className="text-gray-600">Credential ID:</span>
              <span className="font-mono text-sm">{certificate.credentialId}</span>
            </div>

            {certificate.score && (
              <div className="flex justify-between">
                <span className="text-gray-600">Score:</span>
                <span className="font-medium">
                  {certificate.score}%
                  {certificate.passingScore && ` (Pass: ${certificate.passingScore}%)`}
                </span>
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-base">Issuer Information</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex items-center space-x-3">
              {certificate.issuer.logo && (
                <img 
                  src={certificate.issuer.logo} 
                  alt={certificate.issuer.name}
                  className="w-8 h-8 rounded"
                />
              )}
              <div>
                <p className="font-medium">{certificate.issuer.name}</p>
                {certificate.issuer.website && (
                  <a 
                    href={certificate.issuer.website}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-sky-600 hover:text-sky-700 text-sm flex items-center"
                  >
                    Visit Website
                    <ExternalLink className="w-3 h-3 ml-1" />
                  </a>
                )}
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Skills & Metadata */}
      {(certificate.skills.length > 0 || certificate.metadata) && (
        <div className="space-y-4">
          {certificate.skills.length > 0 && (
            <div>
              <h3 className="font-medium text-gray-900 mb-2">Skills Demonstrated</h3>
              <div className="flex flex-wrap gap-2">
                {certificate.skills.map((skill, index) => (
                  <Badge key={index} variant="secondary">
                    {skill}
                  </Badge>
                ))}
              </div>
            </div>
          )}

          {certificate.metadata && (
            <div>
              <h3 className="font-medium text-gray-900 mb-2">Additional Information</h3>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                {certificate.metadata.duration && (
                  <div>
                    <span className="text-gray-600">Duration:</span>
                    <p className="font-medium">{certificate.metadata.duration}</p>
                  </div>
                )}
                {certificate.metadata.difficulty && (
                  <div>
                    <span className="text-gray-600">Difficulty:</span>
                    <p className="font-medium capitalize">{certificate.metadata.difficulty}</p>
                  </div>
                )}
                {certificate.metadata.grade && (
                  <div>
                    <span className="text-gray-600">Grade:</span>
                    <p className="font-medium">{certificate.metadata.grade}</p>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      )}

      {/* Description */}
      <div>
        <h3 className="font-medium text-gray-900 mb-2">Description</h3>
        <p className="text-gray-600">{certificate.description}</p>
      </div>

      {/* Verification */}
      <Card className="bg-gray-50">
        <CardContent className="pt-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Shield className="w-5 h-5 text-green-600" />
              <span className="font-medium">Verification</span>
            </div>
            <Button
              variant="outline"
              size="sm"
              onClick={() => window.open(certificate.verificationUrl, '_blank')}
            >
              <QrCode className="w-4 h-4 mr-2" />
              Verify Certificate
            </Button>
          </div>
          <p className="text-sm text-gray-600 mt-2">
            This certificate can be verified at: {certificate.verificationUrl}
          </p>
        </CardContent>
      </Card>
    </div>
  );

  if (isFullscreen) {
    return (
      <Dialog open={isFullscreen} onOpenChange={setIsFullscreen}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Certificate Viewer</DialogTitle>
          </DialogHeader>
          <CertificateContent />
        </DialogContent>
      </Dialog>
    );
  }

  return (
    <div className="space-y-4">
      <CertificateContent />
      
      {showActions && (
        <>
          <Separator />
          <div className="flex flex-wrap items-center justify-between gap-4">
            <div className="flex items-center space-x-2">
              <Button onClick={handleDownload} variant="outline">
                <Download className="w-4 h-4 mr-2" />
                Download PDF
              </Button>
              
              <Button onClick={handleShare} variant="outline">
                <Share2 className="w-4 h-4 mr-2" />
                Share
              </Button>
              
              <Button onClick={handlePrint} variant="outline">
                <Printer className="w-4 h-4 mr-2" />
                Print
              </Button>
            </div>

            <div className="flex items-center space-x-2">
              <Button onClick={handleCopyUrl} variant="ghost" size="sm">
                <Copy className="w-4 h-4 mr-2" />
                Copy Link
              </Button>
              
              <Button onClick={() => setIsFullscreen(true)} variant="ghost" size="sm">
                View Fullscreen
              </Button>
            </div>
          </div>
        </>
      )}
    </div>
  );
}