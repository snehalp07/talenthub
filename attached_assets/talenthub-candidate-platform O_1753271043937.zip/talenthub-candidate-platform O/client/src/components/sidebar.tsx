import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { 
  BarChart3, 
  Users, 
  Briefcase, 
  ClipboardCheck, 
  Calendar, 
  TrendingUp, 
  BarChart, 
  Settings, 
  CreditCard 
} from "lucide-react";
import { User } from "@shared/schema";
import { cn } from "@/lib/utils";

interface SidebarProps {
  user: User | null;
  usageSummary: Array<{ feature: string; totalCount: number }>;
}

export default function Sidebar({ user, usageSummary }: SidebarProps) {
  const navigation = [
    { name: "Dashboard", icon: BarChart3, current: true, badge: null },
    { name: "Candidates", icon: Users, current: false, badge: "147" },
    { name: "Job Postings", icon: Briefcase, current: false, badge: "12" },
    { name: "Assessments", icon: ClipboardCheck, current: false, badge: null },
    { name: "Interviews", icon: Calendar, current: false, badge: "8" },
  ];

  const analytics = [
    { name: "Hiring Reports", icon: BarChart },
    { name: "Performance", icon: TrendingUp },
  ];

  const settings = [
    { name: "Account Settings", icon: Settings },
    { name: "Billing & Usage", icon: CreditCard },
  ];

  const getDashboardTitle = (role: string) => {
    switch (role) {
      case "candidate": return "Candidate Dashboard";
      case "recruiter": return "Recruiter Dashboard";
      case "admin": return "Admin Dashboard";
      case "lms_user": return "LMS Dashboard";
      default: return "Dashboard";
    }
  };

  const getDashboardDescription = (role: string) => {
    switch (role) {
      case "candidate": return "Manage your career journey";
      case "recruiter": return "Manage hiring pipeline";
      case "admin": return "System administration";
      case "lms_user": return "Learning management";
      default: return "Platform overview";
    }
  };

  // Calculate usage percentages
  const candidateViews = usageSummary.find(u => u.feature === 'candidate_views')?.totalCount || 0;
  const assessments = usageSummary.find(u => u.feature === 'assessments')?.totalCount || 0;
  
  const candidateViewsLimit = 500;
  const assessmentsLimit = 200;
  
  const candidateViewsPercent = Math.min((candidateViews / candidateViewsLimit) * 100, 100);
  const assessmentsPercent = Math.min((assessments / assessmentsLimit) * 100, 100);

  return (
    <aside className="w-80 bg-white border-r border-neutral-200 flex flex-col">
      {/* Navigation Header */}
      <div className="p-6 border-b border-neutral-200">
        <h2 className="text-lg font-semibold text-neutral-600">
          {getDashboardTitle(user?.role || "candidate")}
        </h2>
        <p className="text-sm text-neutral-500 mt-1">
          {getDashboardDescription(user?.role || "candidate")}
        </p>
      </div>

      {/* Navigation Menu */}
      <nav className="flex-1 p-4 space-y-2">
        <div className="space-y-1">
          {navigation.map((item) => (
            <a
              key={item.name}
              href="#"
              className={cn(
                "flex items-center space-x-3 px-3 py-2 rounded-lg font-medium transition-colors",
                item.current
                  ? "bg-primary/10 text-primary"
                  : "text-neutral-600 hover:bg-neutral-100"
              )}
            >
              <item.icon className="w-5 h-5" />
              <span>{item.name}</span>
              {item.badge && (
                <Badge 
                  variant={item.badge === "8" ? "secondary" : "outline"}
                  className="ml-auto"
                >
                  {item.badge}
                </Badge>
              )}
            </a>
          ))}
        </div>

        {/* Analytics Section */}
        <div className="pt-4 border-t border-neutral-200">
          <h3 className="text-xs font-semibold text-neutral-400 uppercase tracking-wider mb-2">
            Analytics
          </h3>
          {analytics.map((item) => (
            <a
              key={item.name}
              href="#"
              className="flex items-center space-x-3 px-3 py-2 text-neutral-600 hover:bg-neutral-100 rounded-lg transition-colors"
            >
              <item.icon className="w-5 h-5" />
              <span>{item.name}</span>
            </a>
          ))}
        </div>

        {/* Settings Section */}
        <div className="pt-4 border-t border-neutral-200">
          <h3 className="text-xs font-semibold text-neutral-400 uppercase tracking-wider mb-2">
            Settings
          </h3>
          {settings.map((item) => (
            <a
              key={item.name}
              href="#"
              className="flex items-center space-x-3 px-3 py-2 text-neutral-600 hover:bg-neutral-100 rounded-lg transition-colors"
            >
              <item.icon className="w-5 h-5" />
              <span>{item.name}</span>
            </a>
          ))}
        </div>
      </nav>

      {/* Usage Meter */}
      <div className="p-4 border-t border-neutral-200">
        <div className="bg-neutral-50 rounded-lg p-4">
          <h3 className="text-sm font-semibold text-neutral-600 mb-3">Monthly Usage</h3>
          <div className="space-y-4">
            <div>
              <div className="flex justify-between text-xs text-neutral-500 mb-1">
                <span>Candidate Views</span>
                <span>{candidateViews}/{candidateViewsLimit}</span>
              </div>
              <Progress value={candidateViewsPercent} className="h-2" />
            </div>
            <div>
              <div className="flex justify-between text-xs text-neutral-500 mb-1">
                <span>Assessments</span>
                <span>{assessments}/{assessmentsLimit}</span>
              </div>
              <Progress value={assessmentsPercent} className="h-2" />
            </div>
          </div>
        </div>
      </div>
    </aside>
  );
}
