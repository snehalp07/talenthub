import { Badge } from "@/components/ui/badge";
import { Zap } from "lucide-react";

interface FeatureCostDisplayProps {
  featureName: string;
  credits: number;
  className?: string;
  showIcon?: boolean;
}

export function FeatureCostDisplay({ 
  featureName, 
  credits, 
  className = "", 
  showIcon = true 
}: FeatureCostDisplayProps) {
  return (
    <div className={`inline-flex items-center gap-2 ${className}`}>
      {showIcon && <Zap className="h-4 w-4 text-blue-600" />}
      <Badge 
        variant="outline" 
        className="bg-blue-50 text-blue-700 border-blue-200 hover:bg-blue-100"
      >
        {credits} credits
      </Badge>
      <span className="text-sm text-gray-600">per {featureName}</span>
    </div>
  );
}

// Credit pricing for recruiter features
export const RECRUITER_FEATURE_COSTS = {
  // Basic Features (subscription overages)
  extraJobPostings: 15,
  extraCandidateSearches: 3,
  extraVideoInterviews: 25,
  
  // AI-Powered Features
  aiMatching: 20,
  aiInterviewAnalysis: 35,
  aiScoringAdvanced: 15,
  aiTalentPrediction: 40,
  
  // Advanced Analytics
  marketIntelligence: 50,
  diversityAnalytics: 25,
  competitorAnalysis: 45,
  salaryBenchmarking: 30,
  
  // Automation Features
  bulkEmailCampaigns: 40,
  workflowAutomation: 35,
  multiboardDistribution: 20,
  
  // Premium Integrations
  linkedinSourcing: 8,
  githubTalentSearch: 12,
  customIntegrations: 60,
  
  // Expert Services
  expertConsultation: 200,
  customReportGeneration: 150,
  dedicatedAccountManager: 500
};