import { Link } from "wouter";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { cn } from "@/lib/utils";

interface SidebarItem {
  name: string;
  icon: React.ComponentType<{ className?: string }>;
  href: string;
  current?: boolean;
  badge?: string;
}

interface SidebarSection {
  title?: string;
  items: SidebarItem[];
}

interface SidebarProps {
  title: string;
  subtitle: string;
  sections: SidebarSection[];
  usageData?: {
    label: string;
    current: number;
    max: number;
  }[];
}

export default function Sidebar({ title, subtitle, sections, usageData }: SidebarProps) {
  return (
    <aside className="w-64 bg-white border-r border-neutral-200 flex flex-col">
      <div className="p-6 border-b border-neutral-200">
        <h2 className="text-lg font-semibold text-neutral-600">{title}</h2>
        <p className="text-sm text-neutral-500 mt-1">{subtitle}</p>
      </div>
      
      <nav className="flex-1 p-4 space-y-6">
        {sections.map((section, sectionIndex) => (
          <div key={sectionIndex} className={section.title ? "pt-4 border-t border-neutral-200" : ""}>
            {section.title && (
              <h3 className="text-xs font-semibold text-neutral-400 uppercase tracking-wider mb-2">
                {section.title}
              </h3>
            )}
            <div className="space-y-1">
              {section.items.map((item) => (
                <Link key={item.name} href={item.href}>
                  <div
                    className={cn(
                      "flex items-center space-x-3 px-3 py-2 rounded-lg font-medium transition-colors group cursor-pointer",
                      item.current
                        ? "bg-primary/10 text-primary"
                        : "text-neutral-600 hover:bg-neutral-100"
                    )}
                  >
                    <item.icon className="w-5 h-5" />
                    <span className="flex-1">{item.name}</span>
                    {item.badge && (
                      <Badge variant={item.current ? "default" : "outline"} className="text-xs">
                        {item.badge}
                      </Badge>
                    )}
                  </div>
                </Link>
              ))}
            </div>
          </div>
        ))}
      </nav>

      {usageData && (
        <div className="p-4 border-t border-neutral-200">
          <div className="bg-neutral-50 rounded-lg p-4">
            <h3 className="text-sm font-semibold text-neutral-600 mb-3">Usage Overview</h3>
            <div className="space-y-4">
              {usageData.map((usage, index) => (
                <div key={index}>
                  <div className="flex justify-between text-xs text-neutral-500 mb-1">
                    <span>{usage.label}</span>
                    <span>{usage.current}/{usage.max}</span>
                  </div>
                  <Progress value={(usage.current / usage.max) * 100} className="h-2" />
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </aside>
  );
}