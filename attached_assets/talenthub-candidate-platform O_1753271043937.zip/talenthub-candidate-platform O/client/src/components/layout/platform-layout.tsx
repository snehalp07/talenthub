import { ReactNode, useState } from "react";
import { Button } from "@/components/ui/button";
import { Home, ArrowLeft } from "lucide-react";
import { Link } from "wouter";
import ExpandableSidebar, { NavigationSection } from "./expandable-sidebar";
import CertificateHeaderPopup from "@/components/certificate-header-popup";
import CertificateViewerModal from "@/components/certificate-viewer-modal";
import CertificateVerificationModal from "@/components/certificate-verification-modal";

interface Certificate {
  id: string;
  title: string;
  issuer: string;
  issueDate: string;
  expiryDate: string;
  credentialId: string;
  verified: boolean;
  skills: string[];
  score: number;
  level: string;
  verificationCode?: string;
  certificateHash?: string;
}

interface PlatformLayoutProps {
  children: ReactNode;
  sidebarTitle: string;
  sidebarSubtitle: string;
  sidebarSections: NavigationSection[];
  usageData?: {
    label: string;
    current: number;
    max: number;
  }[];
}

export default function PlatformLayout({
  children,
  sidebarTitle,
  sidebarSubtitle,
  sidebarSections,
  usageData
}: PlatformLayoutProps) {
  // Certificate modal state
  const [selectedCertificate, setSelectedCertificate] = useState<Certificate | null>(null);
  const [viewerOpen, setViewerOpen] = useState(false);
  const [verificationOpen, setVerificationOpen] = useState(false);

  // Sample certificate data - in real app this would come from API
  const earnedCertifications: Certificate[] = [
    {
      id: "cert-react-dev-001",
      title: "React Developer Certification",
      issuer: "TalentHub Academy",
      issueDate: "2024-05-15",
      expiryDate: "2026-05-15",
      credentialId: "TH-RDC-2024-5789",
      verified: true,
      skills: ["React", "JavaScript", "JSX", "Hooks"],
      score: 94,
      level: "Advanced",
      verificationCode: "VF-TH-RDC-2024-5789",
      certificateHash: "a1b2c3d4e5f6g7h8i9j0k1l2m3n4o5p6"
    },
    {
      id: "cert-fullstack-js-002",
      title: "Full Stack JavaScript",
      issuer: "TechSkills Institute",
      issueDate: "2024-03-20",
      expiryDate: "2025-03-20",
      credentialId: "TSI-FSJ-2024-3421",
      verified: true,
      skills: ["Node.js", "Express", "MongoDB", "React"],
      score: 87,
      level: "Intermediate",
      verificationCode: "VF-TSI-FSJ-2024-3421",
      certificateHash: "b2c3d4e5f6g7h8i9j0k1l2m3n4o5p6q7"
    },
    {
      id: "cert-aws-cloud-003",
      title: "AWS Cloud Fundamentals",
      issuer: "Amazon Web Services",
      issueDate: "2024-01-10",
      expiryDate: "2025-01-10",
      credentialId: "AWS-CF-2024-1234",
      verified: true,
      skills: ["AWS", "EC2", "S3", "Lambda"],
      score: 91,
      level: "Foundation",
      verificationCode: "VF-AWS-CF-2024-1234",
      certificateHash: "c3d4e5f6g7h8i9j0k1l2m3n4o5p6q7r8"
    }
  ];

  // Certificate handlers
  const handleViewCertificate = (certificate: Certificate) => {
    setSelectedCertificate(certificate);
    setViewerOpen(true);
  };

  const handleVerifyCertificate = (certificate: Certificate) => {
    setSelectedCertificate(certificate);
    setVerificationOpen(true);
  };

  const handleDownloadCertificate = (certificate: Certificate) => {
    const element = document.createElement("a");
    const file = new Blob([`Certificate: ${certificate.title}\nCredential ID: ${certificate.credentialId}`], 
      { type: 'text/plain' });
    element.href = URL.createObjectURL(file);
    element.download = `${certificate.title.replace(/\s+/g, '_')}_Certificate.pdf`;
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
  };

  return (
    <div className="flex h-screen bg-sky-50">
      <ExpandableSidebar
        sidebarTitle={sidebarTitle}
        sidebarSubtitle={sidebarSubtitle}
        sidebarSections={sidebarSections}
        usageData={usageData}
      />
      <main className="flex-1 overflow-auto">
        {/* Header with Navigation */}
        <div className="bg-white border-b border-sky-200 p-4">
          <div className="flex items-center justify-between">
            <Link href="/" className="inline-block">
              <Button 
                variant="outline" 
                size="sm"
                className="flex items-center gap-2 text-sky-600 hover:text-sky-900 hover:bg-sky-100 border-sky-300"
              >
                <ArrowLeft className="w-4 h-4" />
                <Home className="w-4 h-4" />
                <span className="font-medium">Back to Home</span>
              </Button>
            </Link>
            
            {/* Certificate Header Popup */}
            <CertificateHeaderPopup
              certificates={earnedCertifications}
              onViewCertificate={handleViewCertificate}
              onVerifyCertificate={handleVerifyCertificate}
              onDownloadCertificate={handleDownloadCertificate}
            />
          </div>
        </div>
        
        {/* Main Content */}
        <div className="p-6">
          {children}
        </div>

        {/* Certificate Modals */}
        <CertificateViewerModal
          certificate={selectedCertificate}
          isOpen={viewerOpen}
          onClose={() => setViewerOpen(false)}
          onVerify={handleVerifyCertificate}
          onDownload={handleDownloadCertificate}
        />

        <CertificateVerificationModal
          certificate={selectedCertificate}
          isOpen={verificationOpen}
          onClose={() => setVerificationOpen(false)}
        />
      </main>
    </div>
  );
}