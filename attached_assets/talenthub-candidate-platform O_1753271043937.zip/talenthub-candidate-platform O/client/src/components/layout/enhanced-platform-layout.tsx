import { useState } from "react";
import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import ExpandableSidebar from "./expandable-sidebar";
import { 
  Menu, 
  X, 
  Bell, 
  Search, 
  Settings, 
  LogOut,
  ChevronDown,
  Home,
  Zap
} from "lucide-react";

interface PlatformLayoutProps {
  platformName: string;
  platformSubtitle: string;
  platformIcon: any;
  platformColor: string;
  planName: string;
  planColor: string;
  userInitials: string;
  sidebarTitle: string;
  sidebarSubtitle: string;
  sidebarSections: any[];
  usageData?: {
    label: string;
    current: number;
    max: number;
  }[];
  children: React.ReactNode;
}

export default function EnhancedPlatformLayout({
  platformName,
  platformSubtitle,
  platformIcon: PlatformIcon,
  platformColor,
  planName,
  planColor,
  userInitials,
  sidebarTitle,
  sidebarSubtitle,
  sidebarSections,
  usageData,
  children
}: PlatformLayoutProps) {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [location] = useLocation();

  const getPlatformColorClasses = (color: string) => {
    const colorMap = {
      blue: "bg-blue-600 text-white",
      green: "bg-green-600 text-white",
      purple: "bg-purple-600 text-white",
      emerald: "bg-emerald-600 text-white"
    };
    return colorMap[color as keyof typeof colorMap] || colorMap.blue;
  };

  const getPlanColorClasses = (color: string) => {
    const colorMap = {
      blue: "bg-blue-100 text-blue-800",
      green: "bg-green-100 text-green-800",
      purple: "bg-purple-100 text-purple-800",
      emerald: "bg-emerald-100 text-emerald-800"
    };
    return colorMap[color as keyof typeof colorMap] || colorMap.blue;
  };

  return (
    <div className="h-screen flex bg-gray-50">
      {/* Mobile sidebar overlay */}
      {sidebarOpen && (
        <div 
          className="fixed inset-0 z-40 lg:hidden bg-gray-600 bg-opacity-75"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Desktop Sidebar */}
      <div className="hidden lg:flex lg:flex-shrink-0">
        <ExpandableSidebar
          sidebarTitle={sidebarTitle}
          sidebarSubtitle={sidebarSubtitle}
          sidebarSections={sidebarSections}
          usageData={usageData}
        />
      </div>

      {/* Mobile Sidebar */}
      <div className={`fixed inset-y-0 left-0 z-50 w-64 lg:hidden transform ${
        sidebarOpen ? 'translate-x-0' : '-translate-x-full'
      } transition-transform duration-300 ease-in-out`}>
        <div className="flex flex-col h-full">
          <div className="flex items-center justify-between p-4 border-b border-gray-200 bg-white">
            <h2 className="text-lg font-semibold text-gray-900">{sidebarTitle}</h2>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setSidebarOpen(false)}
            >
              <X className="w-5 h-5" />
            </Button>
          </div>
          <div className="flex-1 bg-white">
            <ExpandableSidebar
              sidebarTitle={sidebarTitle}
              sidebarSubtitle={sidebarSubtitle}
              sidebarSections={sidebarSections}
              usageData={usageData}
            />
          </div>
        </div>
      </div>

      {/* Main content */}
      <div className="flex flex-col w-0 flex-1 overflow-hidden">
        {/* Top Navigation */}
        <div className="relative z-10 flex-shrink-0 flex h-16 bg-white shadow-sm border-b border-gray-200">
          {/* Mobile menu button */}
          <Button
            variant="ghost"
            size="sm"
            className="px-4 lg:hidden"
            onClick={() => setSidebarOpen(true)}
          >
            <Menu className="w-5 h-5" />
          </Button>

          {/* Platform Header */}
          <div className="flex-1 px-4 flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className={`flex items-center space-x-3 px-3 py-2 rounded-lg ${getPlatformColorClasses(platformColor)}`}>
                <PlatformIcon className="w-5 h-5" />
                <div>
                  <h1 className="text-sm font-semibold">{platformName}</h1>
                  <p className="text-xs opacity-90">{platformSubtitle}</p>
                </div>
              </div>
              <Badge className={getPlanColorClasses(planColor)}>
                <Zap className="w-3 h-3 mr-1" />
                {planName}
              </Badge>
            </div>

            {/* Right side actions */}
            <div className="flex items-center space-x-4">
              {/* Search */}
              <Button variant="ghost" size="sm">
                <Search className="w-4 h-4" />
              </Button>

              {/* Notifications */}
              <Button variant="ghost" size="sm" className="relative">
                <Bell className="w-4 h-4" />
                <span className="absolute -top-1 -right-1 w-3 h-3 bg-red-500 rounded-full text-xs flex items-center justify-center text-white">
                  3
                </span>
              </Button>

              {/* Platform Switcher */}
              <div className="relative">
                <Button variant="ghost" size="sm" className="flex items-center space-x-2">
                  <Home className="w-4 h-4" />
                  <span className="hidden md:block">Platforms</span>
                  <ChevronDown className="w-3 h-3" />
                </Button>
              </div>

              {/* User Menu */}
              <div className="flex items-center space-x-3">
                <Avatar className="h-8 w-8">
                  <AvatarFallback className="bg-gray-100 text-gray-600 text-sm">
                    {userInitials}
                  </AvatarFallback>
                </Avatar>
                <Button variant="ghost" size="sm">
                  <ChevronDown className="w-4 h-4" />
                </Button>
              </div>
            </div>
          </div>
        </div>

        {/* Breadcrumb Navigation */}
        <div className="bg-white border-b border-gray-200 px-6 py-3">
          <nav className="flex" aria-label="Breadcrumb">
            <ol className="flex items-center space-x-4">
              <li>
                <Link href="/">
                  <Button variant="ghost" size="sm" className="text-gray-500 hover:text-gray-700">
                    <Home className="w-4 h-4 mr-1" />
                    Home
                  </Button>
                </Link>
              </li>
              <li className="flex items-center">
                <span className="text-gray-400 mx-2">/</span>
                <span className="text-sm font-medium text-gray-900">{platformName}</span>
              </li>
              {location !== "/" && location !== `/${platformColor}` && (
                <li className="flex items-center">
                  <span className="text-gray-400 mx-2">/</span>
                  <span className="text-sm text-gray-500 capitalize">
                    {location.split('/').pop()?.replace('-', ' ')}
                  </span>
                </li>
              )}
            </ol>
          </nav>
        </div>

        {/* Page Content */}
        <main className="flex-1 relative overflow-y-auto focus:outline-none bg-gray-50">
          {children}
        </main>
      </div>
    </div>
  );
}