import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { ArrowLeft, Bell } from "lucide-react";

interface PlatformHeaderProps {
  platformName: string;
  platformSubtitle: string;
  platformIcon: React.ComponentType<{ className?: string }>;
  platformColor: string;
  planName: string;
  planColor: string;
  userInitials: string;
}

export default function PlatformHeader({
  platformName,
  platformSubtitle,
  platformIcon: Icon,
  platformColor,
  planName,
  planColor,
  userInitials
}: PlatformHeaderProps) {
  return (
    <header className="bg-white border-b border-neutral-200 sticky top-0 z-50">
      <div className="flex items-center justify-between px-6 py-4">
        <div className="flex items-center space-x-4">
          <Link href="/">
            <Button variant="ghost" size="sm">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Platform
            </Button>
          </Link>
          <div className="flex items-center space-x-3">
            <div className={`w-8 h-8 ${platformColor} rounded-lg flex items-center justify-center`}>
              <Icon className="h-4 w-4 text-white" />
            </div>
            <div>
              <h1 className="text-lg font-bold text-neutral-600">{platformName}</h1>
              <p className="text-xs text-neutral-500">{platformSubtitle}</p>
            </div>
          </div>
        </div>
        <div className="flex items-center space-x-4">
          <Button variant="ghost" size="sm">
            <Bell className="w-4 h-4" />
          </Button>
          <Badge className={planColor}>
            {planName}
          </Badge>
          <Avatar className="h-8 w-8">
            <AvatarFallback className={planColor}>
              {userInitials}
            </AvatarFallback>
          </Avatar>
        </div>
      </div>
    </header>
  );
}