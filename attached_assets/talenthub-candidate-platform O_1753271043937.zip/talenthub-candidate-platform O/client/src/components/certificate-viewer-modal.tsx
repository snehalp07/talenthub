import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { 
  Download, 
  ExternalLink, 
  Shield, 
  Calendar, 
  Award, 
  CheckCircle, 
  QrCode,
  Printer,
  X
} from "lucide-react";

interface Certificate {
  id: string;
  title: string;
  issuer: string;
  issueDate: string;
  expiryDate: string;
  credentialId: string;
  verified: boolean;
  skills: string[];
  score: number;
  level: string;
  verificationCode?: string;
  certificateHash?: string;
}

interface CertificateViewerModalProps {
  certificate: Certificate | null;
  isOpen: boolean;
  onClose: () => void;
  onVerify: (certificate: Certificate) => void;
  onDownload: (certificate: Certificate) => void;
}

export default function CertificateViewerModal({ 
  certificate, 
  isOpen, 
  onClose, 
  onVerify, 
  onDownload 
}: CertificateViewerModalProps) {
  if (!certificate) return null;

  const handlePrint = () => {
    window.print();
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader className="flex flex-row items-center justify-between space-y-0 pb-4">
          <DialogTitle className="text-2xl font-bold text-gray-900">
            Certificate Preview
          </DialogTitle>
          <Button variant="ghost" size="sm" onClick={onClose}>
            <X className="w-4 h-4" />
          </Button>
        </DialogHeader>

        {/* Certificate Display Area */}
        <div className="bg-gradient-to-br from-blue-50 to-indigo-100 p-8 rounded-lg border-2 border-blue-200 relative overflow-hidden">
          {/* Watermark */}
          <div className="absolute inset-0 opacity-5 flex items-center justify-center">
            <div className="text-8xl font-bold text-blue-900 rotate-45">TALENTHUB</div>
          </div>
          
          {/* Certificate Header */}
          <div className="text-center mb-8 relative z-10">
            <div className="inline-flex items-center justify-center w-20 h-20 bg-blue-600 rounded-full mb-4">
              <Award className="w-10 h-10 text-white" />
            </div>
            <h1 className="text-3xl font-bold text-gray-900 mb-2">Certificate of Achievement</h1>
            <p className="text-lg text-gray-600">This certifies that</p>
          </div>

          {/* Recipient Name */}
          <div className="text-center mb-8 relative z-10">
            <div className="text-4xl font-bold text-blue-800 mb-2">Alex Johnson</div>
            <p className="text-lg text-gray-600">has successfully completed</p>
          </div>

          {/* Certificate Details */}
          <div className="text-center mb-8 relative z-10">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">{certificate.title}</h2>
            <div className="grid grid-cols-2 gap-4 max-w-md mx-auto">
              <div className="text-center">
                <div className="text-sm text-gray-600">Score Achieved</div>
                <div className="text-2xl font-bold text-green-600">{certificate.score}%</div>
              </div>
              <div className="text-center">
                <div className="text-sm text-gray-600">Level</div>
                <div className="text-lg font-semibold text-blue-600">{certificate.level}</div>
              </div>
            </div>
          </div>

          {/* Skills */}
          <div className="text-center mb-8 relative z-10">
            <p className="text-sm text-gray-600 mb-2">Skills Demonstrated</p>
            <div className="flex flex-wrap justify-center gap-2">
              {certificate.skills.map((skill, index) => (
                <Badge key={index} variant="secondary" className="bg-blue-100 text-blue-800">
                  {skill}
                </Badge>
              ))}
            </div>
          </div>

          {/* Certificate Footer */}
          <div className="flex justify-between items-end mt-12 relative z-10">
            <div className="text-left">
              <div className="text-sm text-gray-600">Issued by</div>
              <div className="font-semibold text-gray-900">{certificate.issuer}</div>
              <div className="text-sm text-gray-600 mt-2">Date: {new Date(certificate.issueDate).toLocaleDateString()}</div>
            </div>
            
            <div className="text-center">
              {certificate.verified && (
                <div className="flex items-center justify-center mb-2">
                  <Shield className="w-5 h-5 text-green-600 mr-1" />
                  <span className="text-sm text-green-600 font-medium">Verified</span>
                </div>
              )}
              <div className="text-xs text-gray-500">Credential ID</div>
              <div className="text-sm font-mono text-gray-700">{certificate.credentialId}</div>
            </div>

            <div className="text-right">
              <div className="w-16 h-16 bg-gray-200 rounded flex items-center justify-center mb-2">
                <QrCode className="w-8 h-8 text-gray-600" />
              </div>
              <div className="text-xs text-gray-500">Scan to verify</div>
            </div>
          </div>
        </div>

        <Separator className="my-6" />

        {/* Certificate Information */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
          <div>
            <h3 className="font-semibold text-gray-900 mb-3">Certificate Details</h3>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-gray-600">Issue Date:</span>
                <span>{new Date(certificate.issueDate).toLocaleDateString()}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Expiry Date:</span>
                <span>{new Date(certificate.expiryDate).toLocaleDateString()}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Credential ID:</span>
                <span className="font-mono text-xs">{certificate.credentialId}</span>
              </div>
              {certificate.verificationCode && (
                <div className="flex justify-between">
                  <span className="text-gray-600">Verification Code:</span>
                  <span className="font-mono text-xs">{certificate.verificationCode}</span>
                </div>
              )}
            </div>
          </div>

          <div>
            <h3 className="font-semibold text-gray-900 mb-3">Verification Status</h3>
            <div className="space-y-2">
              <div className="flex items-center space-x-2">
                <CheckCircle className="w-4 h-4 text-green-600" />
                <span className="text-sm">Digitally Signed</span>
              </div>
              <div className="flex items-center space-x-2">
                <Shield className="w-4 h-4 text-green-600" />
                <span className="text-sm">Blockchain Verified</span>
              </div>
              <div className="flex items-center space-x-2">
                <Calendar className="w-4 h-4 text-blue-600" />
                <span className="text-sm">Valid Until {new Date(certificate.expiryDate).toLocaleDateString()}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex flex-col sm:flex-row gap-3 pt-4 border-t">
          <Button
            onClick={() => onVerify(certificate)}
            className="flex-1 bg-blue-600 hover:bg-blue-700 text-white"
          >
            <Shield className="w-4 h-4 mr-2" />
            Verify Certificate
          </Button>
          
          <Button
            onClick={handlePrint}
            variant="outline"
            className="flex-1"
          >
            <Printer className="w-4 h-4 mr-2" />
            Print
          </Button>
          
          <Button
            onClick={() => onDownload(certificate)}
            variant="outline"
            className="flex-1"
          >
            <Download className="w-4 h-4 mr-2" />
            Download PDF
          </Button>
          
          <Button
            onClick={onClose}
            variant="ghost"
            className="flex-1"
          >
            Close
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}