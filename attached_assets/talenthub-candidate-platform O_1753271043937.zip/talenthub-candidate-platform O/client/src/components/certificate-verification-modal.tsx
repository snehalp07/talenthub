import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { 
  Shield, 
  CheckCircle, 
  ExternalLink, 
  Copy, 
  QrCode,
  Calendar,
  User,
  Building,
  Hash,
  X
} from "lucide-react";
import { useState } from "react";

interface Certificate {
  id: string;
  title: string;
  issuer: string;
  issueDate: string;
  expiryDate: string;
  credentialId: string;
  verified: boolean;
  skills: string[];
  score: number;
  level: string;
  verificationCode?: string;
  certificateHash?: string;
}

interface CertificateVerificationModalProps {
  certificate: Certificate | null;
  isOpen: boolean;
  onClose: () => void;
}

export default function CertificateVerificationModal({ 
  certificate, 
  isOpen, 
  onClose 
}: CertificateVerificationModalProps) {
  const [copied, setCopied] = useState(false);

  if (!certificate) return null;

  const verificationUrl = `https://verify.talenthub.com/${certificate.credentialId}`;
  const verificationCode = certificate.verificationCode || `VF-${certificate.credentialId}`;

  const handleCopyVerificationUrl = async () => {
    try {
      await navigator.clipboard.writeText(verificationUrl);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.error('Failed to copy URL:', err);
    }
  };

  const verificationSteps = [
    {
      step: 1,
      title: "Digital Signature",
      description: "Certificate signed with TalentHub's private key",
      status: "verified",
      details: "SHA-256 hash verified"
    },
    {
      step: 2,
      title: "Blockchain Record",
      description: "Certificate hash recorded on blockchain",
      status: "verified",
      details: "Block #847592 confirmed"
    },
    {
      step: 3,
      title: "Issuer Authentication",
      description: "Issuing authority verified",
      status: "verified",
      details: certificate.issuer
    },
    {
      step: 4,
      title: "Expiry Check",
      description: "Certificate validity period",
      status: new Date(certificate.expiryDate) > new Date() ? "valid" : "expired",
      details: `Valid until ${new Date(certificate.expiryDate).toLocaleDateString()}`
    }
  ];

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl">
        <DialogHeader className="flex flex-row items-center justify-between space-y-0 pb-4">
          <DialogTitle className="text-2xl font-bold text-gray-900 flex items-center">
            <Shield className="w-6 h-6 text-green-600 mr-2" />
            Certificate Verification
          </DialogTitle>
          <Button variant="ghost" size="sm" onClick={onClose}>
            <X className="w-4 h-4" />
          </Button>
        </DialogHeader>

        {/* Certificate Overview */}
        <Card className="mb-6">
          <CardContent className="p-6">
            <div className="flex items-start justify-between mb-4">
              <div>
                <h3 className="text-lg font-semibold text-gray-900">{certificate.title}</h3>
                <p className="text-gray-600">{certificate.issuer}</p>
              </div>
              <Badge className="bg-green-100 text-green-800">
                <CheckCircle className="w-3 h-3 mr-1" />
                Verified
              </Badge>
            </div>
            
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div>
                <span className="text-gray-600">Credential ID:</span>
                <div className="font-mono text-xs bg-gray-100 p-2 rounded mt-1">
                  {certificate.credentialId}
                </div>
              </div>
              <div>
                <span className="text-gray-600">Verification Code:</span>
                <div className="font-mono text-xs bg-gray-100 p-2 rounded mt-1">
                  {verificationCode}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Verification Steps */}
        <div className="mb-6">
          <h3 className="font-semibold text-gray-900 mb-4">Verification Process</h3>
          <div className="space-y-3">
            {verificationSteps.map((step, index) => (
              <div key={index} className="flex items-center space-x-4 p-3 bg-gray-50 rounded-lg">
                <div className="flex-shrink-0">
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium ${
                    step.status === 'verified' || step.status === 'valid'
                      ? 'bg-green-100 text-green-700'
                      : 'bg-red-100 text-red-700'
                  }`}>
                    {step.step}
                  </div>
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between">
                    <p className="text-sm font-medium text-gray-900">{step.title}</p>
                    {(step.status === 'verified' || step.status === 'valid') ? (
                      <CheckCircle className="w-4 h-4 text-green-600" />
                    ) : (
                      <X className="w-4 h-4 text-red-600" />
                    )}
                  </div>
                  <p className="text-sm text-gray-600">{step.description}</p>
                  <p className="text-xs text-gray-500 mt-1">{step.details}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* QR Code and Public Verification */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
          <Card>
            <CardContent className="p-4 text-center">
              <div className="w-32 h-32 bg-gray-200 rounded-lg mx-auto mb-4 flex items-center justify-center">
                <QrCode className="w-16 h-16 text-gray-600" />
              </div>
              <p className="text-sm text-gray-600 mb-2">Scan QR code to verify</p>
              <p className="text-xs text-gray-500">Public verification available 24/7</p>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-4">
              <h4 className="font-medium text-gray-900 mb-3">Public Verification URL</h4>
              <div className="bg-gray-100 p-3 rounded-lg mb-3">
                <p className="text-xs font-mono text-gray-700 break-all">{verificationUrl}</p>
              </div>
              <Button
                onClick={handleCopyVerificationUrl}
                size="sm"
                variant="outline"
                className="w-full"
              >
                <Copy className="w-4 h-4 mr-2" />
                {copied ? 'Copied!' : 'Copy URL'}
              </Button>
            </CardContent>
          </Card>
        </div>

        {/* Certificate Details */}
        <Card>
          <CardContent className="p-4">
            <h4 className="font-medium text-gray-900 mb-3">Certificate Details</h4>
            <div className="grid grid-cols-2 gap-4 text-sm">
              <div className="space-y-2">
                <div className="flex items-center space-x-2">
                  <User className="w-4 h-4 text-gray-500" />
                  <span className="text-gray-600">Recipient:</span>
                  <span>Alex Johnson</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Building className="w-4 h-4 text-gray-500" />
                  <span className="text-gray-600">Issuer:</span>
                  <span>{certificate.issuer}</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Calendar className="w-4 h-4 text-gray-500" />
                  <span className="text-gray-600">Issued:</span>
                  <span>{new Date(certificate.issueDate).toLocaleDateString()}</span>
                </div>
              </div>
              <div className="space-y-2">
                <div className="flex items-center space-x-2">
                  <Hash className="w-4 h-4 text-gray-500" />
                  <span className="text-gray-600">Score:</span>
                  <span>{certificate.score}%</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Shield className="w-4 h-4 text-gray-500" />
                  <span className="text-gray-600">Level:</span>
                  <span>{certificate.level}</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Calendar className="w-4 h-4 text-gray-500" />
                  <span className="text-gray-600">Expires:</span>
                  <span>{new Date(certificate.expiryDate).toLocaleDateString()}</span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Separator className="my-4" />

        {/* Action Buttons */}
        <div className="flex justify-between">
          <Button
            onClick={() => window.open(verificationUrl, '_blank')}
            variant="outline"
          >
            <ExternalLink className="w-4 h-4 mr-2" />
            View Public Verification
          </Button>
          
          <Button onClick={onClose}>
            Close
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}