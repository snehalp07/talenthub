import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";

// Add comprehensive error handling
window.addEventListener('unhandledrejection', event => {
  console.warn('Unhandled promise rejection:', event.reason);
  event.preventDefault();
});

window.addEventListener('error', event => {
  console.warn('Runtime error:', event.error);
  event.preventDefault();
});

createRoot(document.getElementById("root")!).render(<App />);
