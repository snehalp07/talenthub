// Centralized theme configuration for easy modifications
export type PlatformType = 'candidate' | 'recruiter' | 'admin' | 'lms';

export interface ThemeConfig {
  primary: string;
  secondary: string;
  accent: string;
  background: string;
  gradient: string;
  borderClass: string;
  textClass: string;
  navClass: string;
}

export const platformThemes: Record<PlatformType, ThemeConfig> = {
  candidate: {
    primary: 'var(--candidate-primary)',
    secondary: 'var(--candidate-secondary)', 
    accent: 'var(--candidate-accent)',
    background: 'var(--candidate-bg)',
    gradient: 'bg-candidate-gradient',
    borderClass: 'border-accent-mint',
    textClass: 'text-sky-600',
    navClass: 'platform-candidate'
  },
  recruiter: {
    primary: 'var(--recruiter-primary)',
    secondary: 'var(--recruiter-secondary)',
    accent: 'var(--recruiter-accent)', 
    background: 'var(--recruiter-bg)',
    gradient: 'bg-recruiter-gradient',
    borderClass: 'border-accent-lavender',
    textClass: 'text-sky-600',
    navClass: 'platform-recruiter'
  },
  admin: {
    primary: 'var(--admin-primary)',
    secondary: 'var(--admin-secondary)',
    accent: 'var(--admin-accent)',
    background: 'var(--admin-bg)', 
    gradient: 'bg-admin-gradient',
    borderClass: 'border-neutral-300',
    textClass: 'text-sky-600',
    navClass: 'platform-admin'
  },
  lms: {
    primary: 'var(--accent-peach)',
    secondary: 'var(--sky-500)',
    accent: 'var(--accent-steel)',
    background: 'var(--accent-peach)',
    gradient: 'bg-lms-gradient',
    borderClass: 'border-accent-peach',
    textClass: 'text-sky-600', 
    navClass: 'platform-lms'
  }
};

// Utility function to get theme for a platform
export function getPlatformTheme(platform: PlatformType): ThemeConfig {
  return platformThemes[platform];
}

// Utility function to get platform class name
export function getPlatformClassName(platform: PlatformType): string {
  return platformThemes[platform].navClass;
}

// Hook for theme-aware components
export function useThemeClasses(platform: PlatformType) {
  const theme = getPlatformTheme(platform);
  
  return {
    // Card styling
    card: `theme-card ${theme.borderClass} card-hover`,
    
    // Button styling 
    primaryButton: `theme-button text-white font-semibold rounded-xl`,
    secondaryButton: `btn-secondary ${theme.borderClass} ${theme.textClass}`,
    
    // Navigation styling
    sidebar: `theme-sidebar ${theme.navClass}`,
    navActive: `theme-nav-active text-white`,
    navInactive: `text-neutral-600 hover:${theme.textClass}`,
    
    // Layout styling
    header: `theme-header ${theme.navClass}`,
    background: `bg-gradient-to-br from-${theme.background} to-background`,
    
    // Text styling
    accent: `theme-accent-text`,
    title: `text-2xl font-bold ${theme.textClass}`,
    
    // Border styling
    border: `theme-border`
  };
}