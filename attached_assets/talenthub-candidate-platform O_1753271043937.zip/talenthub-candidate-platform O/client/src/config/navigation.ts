import {
  Home,
  Search,
  FileText,
  User,
  BarChart3,
  Settings,
  Bell,
  CreditCard,
  Users,
  Brain,
  Calendar,
  Target,
  Briefcase,
  GraduationCap,
  Shield,
  MessageSquare,
  TrendingUp,
  Database,
  Monitor,
  Building,
  BookOpen,
  Award,
  UserCheck,
  Zap,
  Globe,
  Camera,
  PlayCircle,
  PenTool,
  Link,
  Download,
  PhoneCall,
  HelpCircle,
  Filter,
  Mail,
  Workflow,
  BarChart,
  Eye,
  Clock,
  CheckCircle,
  Star
} from "lucide-react";

export interface NavigationItem {
  name: string;
  href: string;
  icon: any;
  current?: boolean;
  badge?: string;
  children?: NavigationItem[];
}

export interface NavigationSection {
  title?: string;
  items: NavigationItem[];
}

export interface PlatformConfig {
  platformName: string;
  platformSubtitle: string;
  platformIcon: any;
  platformColor: string;
  planName: string;
  planColor: string;
  sidebarTitle: string;
  sidebarSubtitle: string;
  sidebarSections: NavigationSection[];
  usageData?: {
    label: string;
    current: number;
    max: number;
  }[];
}

// CANDIDATE PLATFORM NAVIGATION
export const candidateNavigation: NavigationSection[] = [
  {
    title: "Dashboard",
    items: [
      { name: "Dashboard", href: "/candidate/dashboard", icon: Home }
    ]
  },
  {
    title: "Job Search & Applications",
    items: [
      { name: "Job Board", href: "/candidate/job-board", icon: Search },
      { name: "Application Tracker", href: "/candidate/application-tracker", icon: FileText },
      { name: "Job Alerts", href: "/candidate/job-alerts", icon: Bell },
      { name: "Saved Jobs", href: "/candidate/saved-jobs", icon: Star }
    ]
  },
  {
    title: "Skills & Assessment",
    items: [
      { name: "Skill Tests", href: "/candidate/skill-tests", icon: Brain },
      { name: "AI Skill Assessment", href: "/candidate/ai-skill-assessment", icon: Zap },
      { name: "Browse Tests", href: "/candidate/browse-tests", icon: BookOpen },
      { name: "Certifications", href: "/candidate/certifications", icon: Award },
      { name: "Learning Path", href: "/candidate/learning-path", icon: Target }
    ]
  },
  {
    title: "Profile & Branding",
    items: [
      { name: "Profile Builder", href: "/candidate/profile-builder", icon: User },
      { name: "Video CV", href: "/candidate/video-cv", icon: Camera },
      { name: "Infographic CV", href: "/candidate/infographic-cv", icon: BarChart },
      { name: "Resume Tips", href: "/candidate/resume-tips", icon: PenTool },
      { name: "Profile Preview", href: "/candidate/profile-preview", icon: Eye }
    ]
  },
  {
    title: "Interview Preparation",
    items: [
      { name: "AI Mock Interviews", href: "/candidate/ai-mock-interviews", icon: PlayCircle },
      { name: "Interview Scheduler", href: "/candidate/interview-scheduler", icon: Calendar },
      { name: "Interview Feedback", href: "/candidate/interview-feedback", icon: MessageSquare },
      { name: "Personal Interview", href: "/candidate/personal-interview", icon: PhoneCall }
    ]
  },
  {
    title: "Career Development",
    items: [
      { name: "Career Guidance", href: "/candidate/career-guidance", icon: TrendingUp },
      { name: "Market Trends", href: "/candidate/market-trends", icon: BarChart3 },
      { name: "Performance Insights", href: "/candidate/performance-insights", icon: Target },
      { name: "Networking", href: "/candidate/networking", icon: Users }
    ]
  },
  {
    title: "Tools & Integration",
    items: [
      { name: "LinkedIn Integration", href: "/candidate/linkedin-integration", icon: Link },
      { name: "Mobile App", href: "/candidate/mobile-app", icon: Globe },
      { name: "Project Access", href: "/candidate/project-access", icon: Briefcase },
      { name: "Project Editor", href: "/candidate/project-editor-enhanced", icon: PenTool }
    ]
  },
  {
    title: "Analytics & Insights",
    items: [
      { name: "Analytics", href: "/candidate/analytics", icon: BarChart3 },
      { name: "My Performance", href: "/candidate/my-performance", icon: TrendingUp },
      { name: "Test Reports", href: "/candidate/test-reports", icon: FileText }
    ]
  },
  {
    title: "Support & Services",
    items: [
      { name: "One-on-One Support", href: "/candidate/one-on-one-support", icon: UserCheck },
      { name: "Priority Support", href: "/candidate/priority-support", icon: Star }
    ]
  },
  {
    title: "Subscription & Settings",
    items: [
      { name: "Subscription", href: "/candidate/subscription", icon: CreditCard },
      { name: "Notifications", href: "/candidate/notifications", icon: Bell },
      { name: "Settings", href: "/candidate/settings", icon: Settings }
    ]
  }
];

// RECRUITER PLATFORM NAVIGATION
export const recruiterNavigation: NavigationSection[] = [
  {
    title: "Core Management",
    items: [
      { name: "Dashboard", href: "/recruiter/dashboard", icon: Home },
      { name: "Talent Intelligence", href: "/recruiter/talent-intelligence", icon: Brain }
    ]
  },
  {
    title: "Candidate Discovery",
    items: [
      { name: "AI Candidate Discovery", href: "/recruiter/ai-candidate-discovery", icon: Zap },
      { name: "Resume Parser", href: "/recruiter/resume-parser", icon: FileText },
      { name: "Talent Pool", href: "/recruiter/talent-pool", icon: Users },
      { name: "Candidate Ranking", href: "/recruiter/candidate-ranking", icon: Filter }
    ]
  },
  {
    title: "Job Management",
    items: [
      { name: "Job Management", href: "/recruiter/job-management", icon: Briefcase },
      { name: "Job Templates", href: "/recruiter/job-templates", icon: FileText },
      { name: "Job Publishing", href: "/recruiter/job-publishing", icon: Globe },
      { name: "Multi-board Distribution", href: "/recruiter/multi-board-distribution", icon: Database }
    ]
  },
  {
    title: "Interview & Assessment",
    items: [
      { name: "Interview Pipeline", href: "/recruiter/interview-pipeline", icon: Calendar },
      { name: "Video Interviews", href: "/recruiter/video-interviews", icon: Camera },
      { name: "Interview Scorecards", href: "/recruiter/interview-scorecards", icon: CheckCircle }
    ]
  },
  {
    title: "AI-Powered Tools",
    items: [
      { name: "AI Matching", href: "/recruiter/ai-matching", icon: Target },
      { name: "AI Screening", href: "/recruiter/ai-screening", icon: Filter },
      { name: "AI Interview Analysis", href: "/recruiter/ai-interview-analysis", icon: Brain },
      { name: "AI Scoring", href: "/recruiter/ai-scoring", icon: BarChart },
      { name: "AI Command Center", href: "/recruiter/ai-command-center", icon: Monitor }
    ]
  },
  {
    title: "Analytics & Intelligence",
    items: [
      { name: "Recruiter Analytics", href: "/recruiter/recruiter-analytics", icon: BarChart3 },
      { name: "Predictive Hiring", href: "/recruiter/predictive-hiring", icon: TrendingUp },
      { name: "Real-time Analytics", href: "/recruiter/real-time-analytics", icon: Clock },
      { name: "Success Prediction", href: "/recruiter/success-prediction", icon: Target },
      { name: "Market Intelligence", href: "/recruiter/market-intelligence", icon: Globe },
      { name: "Diversity Metrics", href: "/recruiter/diversity-metrics", icon: Users }
    ]
  },
  {
    title: "Automation & Workflow",
    items: [
      { name: "Workflow Automation", href: "/recruiter/workflow-automation", icon: Workflow },
      { name: "Email Templates", href: "/recruiter/email-templates", icon: Mail },
      { name: "Bulk Operations", href: "/recruiter/bulk-operations", icon: Database }
    ]
  },
  {
    title: "Employer Branding",
    items: [
      { name: "Company Profile", href: "/recruiter/company-profile", icon: Building },
      { name: "Candidate Experience", href: "/recruiter/candidate-experience", icon: UserCheck },
      { name: "Brand Analytics", href: "/recruiter/brand-analytics", icon: BarChart3 }
    ]
  },
  {
    title: "Business Management",
    items: [
      { name: "Team Collaboration", href: "/recruiter/team-collaboration", icon: Users },
      { name: "Cost Analytics", href: "/recruiter/cost-analytics", icon: BarChart },
      { name: "Subscription Management", href: "/recruiter/subscription-management", icon: CreditCard }
    ]
  },
  {
    title: "Settings & Configuration",
    items: [
      { name: "Recruiter Settings", href: "/recruiter/settings", icon: Settings }
    ]
  }
];

// ADMIN PLATFORM NAVIGATION
export const adminNavigation: NavigationSection[] = [
  {
    title: "Core Management",
    items: [
      { name: "Dashboard", href: "/admin/dashboard", icon: Home },
      { name: "User Management", href: "/admin/user-management", icon: Users },
      { name: "Organization Settings", href: "/admin/organization-settings", icon: Building }
    ]
  },
  {
    title: "Assessment Control",
    items: [
      { name: "Test Creation", href: "/admin/test-creation", icon: PenTool },
      { name: "Question Bank", href: "/admin/question-bank", icon: Database },
      { name: "Question Upload", href: "/admin/question-upload", icon: Download },
      { name: "Bulk Question Upload", href: "/admin/bulk-question-upload", icon: Database },
      { name: "Assessment Analytics", href: "/admin/assessment-analytics", icon: BarChart3 }
    ]
  },
  {
    title: "AI & Content",
    items: [
      { name: "AI Monitoring", href: "/admin/ai-monitoring", icon: Monitor },
      { name: "Content Moderation", href: "/admin/content-moderation", icon: Shield },
      { name: "Media Library", href: "/admin/media-library", icon: FileText },
      { name: "Resume Parser", href: "/admin/resume-parser", icon: FileText }
    ]
  },
  {
    title: "System Operations",
    items: [
      { name: "System Monitoring", href: "/admin/system-monitoring", icon: Monitor },
      { name: "Database Management", href: "/admin/database-management", icon: Database },
      { name: "Audit Logs", href: "/admin/audit-logs", icon: FileText },
      { name: "Feature Control", href: "/admin/feature-control", icon: Settings }
    ]
  },
  {
    title: "Business Management",
    items: [
      { name: "Subscription Management", href: "/admin/subscription-management", icon: CreditCard },
      { name: "Verification Queue", href: "/admin/verification-queue", icon: CheckCircle },
      { name: "Bulk Scheduling", href: "/admin/bulk-scheduling", icon: Calendar }
    ]
  },
  {
    title: "Platform Settings",
    items: [
      { name: "Admin Settings", href: "/admin/settings", icon: Settings }
    ]
  }
];

// LMS PLATFORM NAVIGATION
export const lmsNavigation: NavigationSection[] = [
  {
    title: "Core Learning",
    items: [
      { name: "Dashboard", href: "/lms/dashboard", icon: Home },
      { name: "Course Library", href: "/lms/course-library", icon: BookOpen },
      { name: "My Learning", href: "/lms/my-learning", icon: GraduationCap }
    ]
  },
  {
    title: "Learning Modules",
    items: [
      { name: "Interactive Courses", href: "/lms/interactive-courses", icon: PlayCircle },
      { name: "Video Lectures", href: "/lms/video-lectures", icon: Camera },
      { name: "Practice Tests", href: "/lms/practice-tests", icon: FileText },
      { name: "Assignments", href: "/lms/assignments", icon: PenTool }
    ]
  },
  {
    title: "Certification Programs",
    items: [
      { name: "Browse Certifications", href: "/lms/browse-certifications", icon: Award },
      { name: "Certification Tracker", href: "/lms/certification-tracker", icon: Target },
      { name: "AI Learning Path", href: "/lms/ai-learning-path", icon: Brain },
      { name: "Blockchain Certificates", href: "/lms/blockchain-certificates", icon: Shield }
    ]
  },
  {
    title: "Advanced Features",
    items: [
      { name: "Mentorship Programs", href: "/lms/mentorship-programs", icon: UserCheck },
      { name: "Project-based Learning", href: "/lms/project-based-learning", icon: Briefcase },
      { name: "Security Certifications", href: "/lms/security-certifications", icon: Shield }
    ]
  },
  {
    title: "Collaboration",
    items: [
      { name: "Study Groups", href: "/lms/study-groups", icon: Users },
      { name: "Peer Learning", href: "/lms/peer-learning", icon: MessageSquare },
      { name: "Discussion Forums", href: "/lms/discussion-forums", icon: MessageSquare }
    ]
  },
  {
    title: "Progress Tracking",
    items: [
      { name: "Learning Analytics", href: "/lms/learning-analytics", icon: BarChart3 },
      { name: "Progress Reports", href: "/lms/progress-reports", icon: FileText },
      { name: "Achievement Badges", href: "/lms/achievement-badges", icon: Award }
    ]
  },
  {
    title: "Profile & Settings",
    items: [
      { name: "LMS Profile", href: "/lms/profile", icon: User },
      { name: "Settings", href: "/lms/settings", icon: Settings }
    ]
  }
];

// Assessment platform navigation
const assessmentNavigation: NavigationSection[] = [
  {
    title: "Test Management",
    items: [
      { name: "Browse Tests", href: "/assessment/browse-tests", icon: Search },
      { name: "Test Runner", href: "/assessment/test-runner", icon: PlayCircle },
      { name: "Question Bank", href: "/assessment/question-bank", icon: Database },
      { name: "Bulk Upload", href: "/assessment/bulk-upload", icon: Download }
    ]
  },
  {
    title: "Analytics & Reports",
    items: [
      { name: "Assessment Analytics", href: "/assessment/analytics", icon: BarChart3 },
      { name: "Test Results", href: "/assessment/test-results", icon: FileText },
      { name: "Performance Insights", href: "/assessment/insights", icon: TrendingUp }
    ]
  },
  {
    title: "Certification",
    items: [
      { name: "Certifications", href: "/assessment/certifications", icon: Award },
      { name: "Badge Management", href: "/assessment/badges", icon: Star }
    ]
  }
];

// Platform configurations
export const platformConfigs: Record<string, PlatformConfig> = {
  candidate: {
    platformName: "Candidate Portal",
    platformSubtitle: "Your Career Journey",
    platformIcon: User,
    platformColor: "bg-blue-500",
    planName: "Professional",
    planColor: "text-blue-600",
    sidebarTitle: "Candidate Hub",
    sidebarSubtitle: "Build Your Career",
    sidebarSections: candidateNavigation,
    usageData: [
      { label: "Job Applications", current: 15, max: 50 },
      { label: "Skill Tests", current: 8, max: 20 },
      { label: "Mock Interviews", current: 3, max: 10 }
    ]
  },
  recruiter: {
    platformName: "Recruiter Portal",
    platformSubtitle: "Talent Acquisition Hub",
    platformIcon: Users,
    platformColor: "bg-green-500",
    planName: "Enterprise",
    planColor: "text-green-600",
    sidebarTitle: "Recruiter Hub",
    sidebarSubtitle: "Find Top Talent",
    sidebarSections: recruiterNavigation,
    usageData: [
      { label: "Active Jobs", current: 12, max: 25 },
      { label: "Candidates Screened", current: 340, max: 500 },
      { label: "Interviews Scheduled", current: 28, max: 50 }
    ]
  },
  admin: {
    platformName: "AdminHub",
    platformSubtitle: "System Control Center",
    platformIcon: Shield,
    platformColor: "bg-purple-500",
    planName: "Admin",
    planColor: "text-purple-600",
    sidebarTitle: "Admin Control",
    sidebarSubtitle: "Manage Platform",
    sidebarSections: adminNavigation,
    usageData: [
      { label: "System Health", current: 98, max: 100 },
      { label: "Active Users", current: 1547, max: 2000 },
      { label: "Storage Used", current: 67, max: 100 }
    ]
  },
  lms: {
    platformName: "LearningHub",
    platformSubtitle: "Knowledge & Skills",
    platformIcon: GraduationCap,
    platformColor: "bg-emerald-500",
    planName: "Education Pro",
    planColor: "text-emerald-600",
    sidebarTitle: "Learning Center",
    sidebarSubtitle: "Expand Your Skills",
    sidebarSections: lmsNavigation,
    usageData: [
      { label: "Courses Completed", current: 12, max: 30 },
      { label: "Certifications", current: 4, max: 10 },
      { label: "Study Hours", current: 47, max: 100 }
    ]
  },
  assessment: {
    platformName: "Assessment Hub",
    platformSubtitle: "Testing & Certification",
    platformIcon: Brain,
    platformColor: "bg-purple-500",
    planName: "Assessment Pro",
    planColor: "text-purple-600",
    sidebarTitle: "Assessment Center",
    sidebarSubtitle: "Test & Certify",
    sidebarSections: assessmentNavigation,
    usageData: [
      { label: "Tests Completed", current: 23, max: 50 },
      { label: "Certifications Earned", current: 6, max: 15 },
      { label: "Question Bank", current: 1247, max: 2000 }
    ]
  }
};