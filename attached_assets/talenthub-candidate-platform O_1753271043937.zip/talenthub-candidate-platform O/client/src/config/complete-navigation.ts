import { 
  Home, 
  Users, 
  Briefcase, 
  Calendar, 
  Settings, 
  BarChart3, 
  FileText, 
  Search, 
  Target, 
  Award, 
  Video, 
  MessageSquare, 
  TrendingUp, 
  Bell, 
  Bookmark, 
  User, 
  Code, 
  FolderOpen, 
  CreditCard,
  Plus,
  Grid3X3,
  Trophy,
  Lightbulb,
  BookOpen,
  AlertTriangle,
  Flag,
  Heart,
  PlusCircle,
  Calculator,
  Wrench,
  Sliders,
  Activity,
  Brain,
  Zap,
  Lock,
  Globe,
  Eye,
  Play,
  UserPlus,
  Palette,
  Book,
  Link,
  Upload,
  MapPin,
  Database,
  Shield,
  Star,
  Headphones,
  Smartphone,
  Box as Package,
  CreditCard as Wallet,
  Settings as Workflow,
  Monitor,
  Server,
  Layers,
  Cloud,
  Focus,
  Building,
  CheckCircle,
  History,
  FileImage,
  MessageCircle,
  FileBarChart,
  DollarSign,
  GraduationCap,
  PlayCircle,
  PenTool,
  UserCheck,
  HandHeart,
  School,
  RotateCcw,
  BarChart,
  Filter,
  Mail,
  HelpCircle,
  Clock,
  Download,
  Handshake,
  Key,
  ArrowUp,
  Crown,
  Folder,
  Tags
} from "lucide-react";

export interface NavigationItem {
  name: string;
  href: string;
  icon: any;
  current?: boolean;
  badge?: string;
  children?: NavigationItem[];
  isSubHeader?: boolean;
}

export interface NavigationSection {
  title?: string;
  items: NavigationItem[];
  isHeader?: boolean;
  isParent?: boolean;
}

export interface PlatformConfig {
  platformName: string;
  platformSubtitle: string;
  platformIcon: any;
  platformColor: string;
  planName: string;
  planColor: string;
  sidebarTitle: string;
  sidebarSubtitle: string;
  sidebarSections: NavigationSection[];
  usageData?: {
    label: string;
    current: number;
    max: number;
  }[];
}

// 1. CANDIDATE PLATFORM - Blue Theme with Visual Separators
export const candidateNavigation: NavigationSection[] = [
  {
    title: "Dashboard",
    items: [
      { name: "Dashboard", href: "/candidate", icon: BarChart3, current: true },
    ]
  },
  {
    title: "Profile",
    items: [
      { name: "Profile Builder", href: "/candidate/profile-builder", icon: User },
      { name: "Video CV", href: "/candidate/video-cv", icon: Video },
      { name: "Infographic CV", href: "/candidate/infographic-cv", icon: FileImage },
      { name: "Resume Tips", href: "/candidate/resume-tips", icon: FileText },
      { name: "Profile Preview", href: "/candidate/profile-preview", icon: Eye },
    ]
  },
  {
    title: "Test Skills",
    items: [
      { name: "Test Packages", href: "/candidate/test-package-marketplace", icon: Package },
      { name: "Tests", href: "/candidate/assessment-testing", icon: Target },
      { name: "Certification Progress", href: "/candidate/certification-progress", icon: CheckCircle },
      { name: "Certification Wallet", href: "/candidate/certification-wallet", icon: Wallet },
      { name: "Skill Tests", href: "/candidate/skill-tests", icon: Target },
      { name: "Browse Tests", href: "/candidate/browse-tests", icon: Search },
    ]
  },
  {
    title: "Global Certifications",
    items: [
      { name: "Global Tech Stack Certs", href: "/candidate/global-tech-certs", icon: GraduationCap },
      { name: "Preparation Workflows", href: "/candidate/preparation-workflows", icon: Workflow },
      { name: "Package-Based Learning", href: "/candidate/package-learning", icon: Package },
      { name: "AI-Powered Recommendations", href: "/candidate/ai-cert-recommendations", icon: Brain },
      { name: "Blockchain Certificate Management", href: "/candidate/blockchain-cert-management", icon: Shield },
    ]
  },
  {
    title: "Jobs", 
    items: [
      { name: "Job Board", href: "/candidate/job-board", icon: Briefcase, badge: "247" },
      { name: "Applications Tracker", href: "/candidate/application-tracker", icon: FileText, badge: "12" },
      { name: "Alerts", href: "/candidate/job-alerts", icon: Bell, badge: "5" },
      { name: "Saved Jobs", href: "/candidate/saved-jobs", icon: Bookmark, badge: "18" },
      { name: "Interview Communication", href: "/candidate/interview-communication", icon: MessageSquare, badge: "3" },
    ]
  },
  {
    title: "Mock Interview",
    items: [
      // Essential Practice (Most Used)
      { name: "Mock Interviews", href: "/candidate/ai-mock-interviews", icon: MessageSquare, badge: "Popular" },
      { name: "Feedback", href: "/candidate/interview-feedback", icon: MessageCircle },
      { name: "Performance Dashboard", href: "/candidate/interview-performance", icon: BarChart3 },
      { name: "PI", href: "/candidate/personal-interview", icon: Users },
      // Interview Certification
      { name: "Interview Certification", href: "/candidate/interview-certification-dashboard", icon: Trophy, badge: "5 Tracks" },
      { name: "Interview Achievements", href: "/candidate/interview-achievements", icon: Trophy },
      { name: "Certification Showcase", href: "/candidate/certification-showcase", icon: Award },
      // Advanced Analytics
      { name: "Interview Pattern Analysis", href: "/candidate/interview-patterns", icon: TrendingUp },
      { name: "Behavioral Assessment", href: "/candidate/behavioral-assessment", icon: Brain },
      { name: "Tech Stack Proficiency", href: "/candidate/tech-proficiency", icon: Target },
      { name: "Practice History", href: "/candidate/practice-history", icon: History },
      // Smart Prep Tools
      { name: "Personalized Interview Prep", href: "/candidate/personalized-prep", icon: Lightbulb },
      { name: "Company-Specific Prep", href: "/candidate/company-prep", icon: Building },
      { name: "Weakness Targeting", href: "/candidate/weakness-targeting", icon: Focus },
      { name: "Role-Based Scenarios", href: "/candidate/role-scenarios", icon: Users },
      { name: "Simulator", href: "/candidate/tech-stack-simulators", icon: Code },
    ]
  },
  {
    title: "Project",
    items: [
      // Essential Development (Most Used)
      { name: "Project Creator", href: "/candidate/project-creator", icon: Plus, badge: "Popular" },
      { name: "My Projects", href: "/candidate/my-projects", icon: Folder },
      { name: "Project Analytics", href: "/candidate/project-analytics", icon: BarChart },
      { name: "Code Analysis", href: "/candidate/code-analysis", icon: Code },
      // Portfolio & Showcase
      { name: "Project Gallery", href: "/candidate/project-gallery", icon: Grid3X3 },
      { name: "Sample Projects", href: "/candidate/sample-projects", icon: BookOpen },
      { name: "Certificate Gallery", href: "/candidate/certificate-gallery", icon: Award },
      // Certification Pathway
      { name: "Certification Tracks", href: "/candidate/certification-tracks", icon: Trophy },
      { name: "Project Challenges", href: "/candidate/project-challenges", icon: Target },
      { name: "Submission Portal", href: "/candidate/submission-portal", icon: Upload },
      // Smart AI Tools
      { name: "Project Recommendations", href: "/candidate/project-recommendations", icon: Lightbulb },
      { name: "Project Insights", href: "/candidate/project-insights", icon: TrendingUp },
      { name: "Skill Gap Analysis", href: "/candidate/skill-gap-analysis", icon: Target },
    ]
  },
  {
    title: "Career",
    items: [
      { name: "Career Guidance", href: "/candidate/career-guidance", icon: TrendingUp },
      { name: "Market Trends", href: "/candidate/market-trends", icon: BarChart3 },
      { name: "Performance Insights", href: "/candidate/performance-insights", icon: Activity },
    ]
  },
  {
    title: "Network",
    items: [
      { name: "Connections", href: "/candidate/professional-network", icon: Users },
      { name: "Blog", href: "/candidate/blog", icon: FileText },
      { name: "Professional Vlogs", href: "/candidate/professional-vlogs", icon: Video },
      { name: "Groups", href: "/candidate/groups", icon: Users },
      { name: "Forum", href: "/candidate/forum", icon: MessageSquare },
      { name: "Events", href: "/candidate/events-meetups", icon: Calendar },
      { name: "Mentors", href: "/candidate/mentorship", icon: GraduationCap },
      { name: "Insights", href: "/candidate/industry-insights", icon: Zap },
      { name: "Collaboration Hub", href: "/candidate/collaboration", icon: HandHeart },
      { name: "Alumni Network", href: "/candidate/alumni", icon: School },
      { name: "Skill Exchanges", href: "/candidate/skill-exchanges", icon: RotateCcw },
      { name: "Professional Recommendations", href: "/candidate/recommendations", icon: Award },
    ]
  },
  {
    title: "Recruitment Portal",
    items: [
      { name: "Registration Portal", href: "/candidate/registration-portal", icon: UserCheck, badge: "New" },
      { name: "Test Booking", href: "/candidate/test-booking", icon: Calendar, badge: "New" },
      { name: "Interview Communication", href: "/candidate/interview-communication", icon: MessageCircle },
      { name: "Document Center", href: "/candidate/document-center", icon: FileText, badge: "New" },
      { name: "Payment History", href: "/candidate/payment-history", icon: CreditCard, badge: "New" },
    ]
  },
  {
    title: "Tools",
    items: [
      { name: "Assessment Hub", href: "/assessment", icon: Target, badge: "New" },
      { name: "LinkedIn Integration", href: "/candidate/linkedin-integration", icon: Link },
      { name: "Mobile App", href: "/candidate/mobile-app", icon: Smartphone },
    ]
  },
  {
    title: "Insights",
    items: [
      { name: "Career Intelligence Dashboard", href: "/candidate/career-intelligence", icon: Brain },
      { name: "Skills & Performance Analytics", href: "/candidate/skills-analytics", icon: TrendingUp },
      { name: "Profile & Brand Analytics", href: "/candidate/profile-analytics", icon: Eye },
      { name: "Job Search Intelligence", href: "/candidate/job-intelligence", icon: Target },
      { name: "Interview Performance Insights", href: "/candidate/interview-insights", icon: Video },
      { name: "Project Portfolio Analytics", href: "/candidate/portfolio-analytics", icon: FolderOpen },
      { name: "Networking & Community Insights", href: "/candidate/networking-insights", icon: Users },
      { name: "Learning Path Analytics", href: "/candidate/learning-analytics", icon: BookOpen },
      { name: "Market Intelligence", href: "/candidate/market-intelligence", icon: Globe },
      { name: "Predictive Career Insights", href: "/candidate/predictive-insights", icon: Zap },
      { name: "Comparative Benchmarking", href: "/candidate/benchmarking", icon: BarChart },
    ]
  },
  {
    title: "Subscription",
    items: [
      { name: "Billing Analytics", href: "/candidate/billing-analytics", icon: BarChart3, badge: "New" },
      { name: "Subscription Plans", href: "/candidate/subscription", icon: Crown },
    ]
  }
];

// 2. RECRUITER PLATFORM - Green Theme
export const recruiterNavigation: NavigationSection[] = [
  {
    title: "Core Management",
    items: [
      { name: "Dashboard", href: "/recruiter", icon: BarChart3, current: true },
      { name: "Talent Intelligence", href: "/recruiter/talent-intelligence", icon: Brain },
    ]
  },
  {
    title: "Recruitment Management",
    items: [
      { name: "Campaign Management", href: "/recruiter/campaign-management", icon: Target, badge: "New" },
      { name: "Bulk CV Processing", href: "/recruiter/bulk-cv-processing", icon: Upload, badge: "Enhanced" },
      { name: "Candidate Database", href: "/recruiter/candidate-database", icon: Database, badge: "New" },
      { name: "Email Campaigns", href: "/recruiter/email-campaigns", icon: Mail, badge: "New" },
      { name: "Registration Forms", href: "/recruiter/registration-forms", icon: FileText, badge: "New" },
      { name: "Interview Scheduler", href: "/recruiter/interview-scheduler", icon: Calendar, badge: "New" },
      { name: "Offer Management", href: "/recruiter/offer-management", icon: Award, badge: "New" },
      { name: "Recruitment Analytics", href: "/recruiter/recruitment-analytics", icon: BarChart3, badge: "New" },
    ]
  },
  {
    title: "Candidate Discovery",
    items: [
      { name: "AI Candidate Discovery", href: "/recruiter/ai-candidate-discovery", icon: Search },
      { name: "Resume Parser", href: "/recruiter/resume-parser", icon: FileText },
      { name: "Talent Pool", href: "/recruiter/talent-pool", icon: Users },
      { name: "Candidate Ranking", href: "/recruiter/candidate-ranking", icon: Star },
    ]
  },
  {
    title: "Job Management",
    items: [
      { name: "Job Management", href: "/recruiter/jobs", icon: Briefcase, badge: "12" },
      { name: "Job Templates", href: "/recruiter/job-templates", icon: FileText },
      { name: "Job Publishing", href: "/recruiter/job-publishing", icon: ArrowUp },
      { name: "Multi-board Distribution", href: "/recruiter/multi-board", icon: Globe },
    ]
  },
  {
    title: "Job Requirements Labels",
    items: [
      { name: "View All Labels", href: "/recruiter/job-labels", icon: Tags, badge: "New" },
      { name: "Create New Label", href: "/recruiter/create-label", icon: Plus },
      { name: "Label Management", href: "/recruiter/label-management", icon: Settings },
      { name: "Candidate Review", href: "/recruiter/candidate-review", icon: Users },
    ]
  },
  {
    title: "Interview & Assessment",
    items: [
      { name: "Assessment Hub", href: "/assessment", icon: Target, badge: "New" },
      { name: "Interview Pipeline", href: "/recruiter/interview-pipeline", icon: Calendar },
      { name: "Video Interviews", href: "/recruiter/video-interviews", icon: Video },
      { name: "Interview Scorecards", href: "/recruiter/scorecards", icon: CheckCircle },
    ]
  },
  {
    title: "AI-Powered Tools",
    items: [
      { name: "AI Matching", href: "/recruiter/ai-matching", icon: Target },
      { name: "AI Screening", href: "/recruiter/ai-screening", icon: Filter },
      { name: "AI Interview Analysis", href: "/recruiter/ai-interview", icon: MessageSquare },
      { name: "AI Scoring", href: "/recruiter/ai-scoring", icon: Star },
      { name: "AI Command Center", href: "/recruiter/ai-command", icon: Zap },
    ]
  },
  {
    title: "Analytics & Intelligence",
    items: [
      { name: "Success Predictions", href: "/recruiter/predictive", icon: TrendingUp },
      { name: "Recruitment Analytics", href: "/recruiter/analytics", icon: BarChart3 },
      { name: "Real-time Analytics", href: "/recruiter/realtime", icon: Activity },
      { name: "Market Intelligence", href: "/recruiter/market", icon: Globe },
      { name: "Diversity Metrics", href: "/recruiter/diversity", icon: Users },
    ]
  },
  {
    title: "Automation & Workflow",
    items: [
      { name: "Workflow Automation", href: "/recruiter/automation", icon: Workflow },
      { name: "Email Templates", href: "/recruiter/email-templates", icon: Mail },
      { name: "Bulk Operations", href: "/recruiter/bulk-operations", icon: Database },
    ]
  },
  {
    title: "Employer Branding",
    items: [
      { name: "Company Profile", href: "/recruiter/company-profile", icon: Building },
      { name: "Candidate Experience", href: "/recruiter/candidate-experience", icon: Star },
      { name: "Brand Analytics", href: "/recruiter/brand-analytics", icon: BarChart3 },
    ]
  },
  {
    title: "Business Management",
    items: [
      { name: "Team Collaboration", href: "/recruiter/team-collaboration", icon: Users },
      { name: "Billing & Usage", href: "/recruiter/recruiter-billing", icon: CreditCard },
      { name: "Cost Analytics", href: "/recruiter/cost-analytics", icon: DollarSign },
      { name: "Subscription Management", href: "/recruiter/subscription-management", icon: Star },
    ]
  }
];

// 3. ADMIN PLATFORM - Purple Theme (Strategic Command Center)
export const adminNavigation: NavigationSection[] = [
  {
    title: "Real-Time Command Center",
    items: [
      { name: "Live Dashboard", href: "/admin/live-dashboard", icon: Monitor, badge: "Live" },
      { name: "Active Sessions", href: "/admin/active-sessions", icon: Users },
      { name: "System Health", href: "/admin/system-health", icon: Activity },
      { name: "Emergency Controls", href: "/admin/emergency-controls", icon: AlertTriangle },
    ]
  },
  {
    title: "Platform Control Hub",
    items: [
      { name: "Candidate Platform Control", href: "/admin/candidate-control", icon: UserCheck },
      { name: "Recruiter Platform Control", href: "/admin/recruiter-control", icon: Users },
      { name: "Cross-Platform Analytics", href: "/admin/cross-platform-analytics", icon: BarChart3 },
      { name: "Feature Flag Management", href: "/admin/feature-flags", icon: Flag },
    ]
  },
  {
    title: "Revenue Intelligence",
    items: [
      { name: "Billing Overview", href: "/admin/billing-overview", icon: CreditCard },
      { name: "Revenue Optimization", href: "/admin/revenue-optimization", icon: TrendingUp },
      { name: "Credit Analytics", href: "/admin/credit-analytics", icon: DollarSign },
      { name: "Subscription Intelligence", href: "/admin/subscription-intelligence", icon: Star },
    ]
  },
  {
    title: "User Management & Insights",
    items: [
      { name: "User Management", href: "/admin/user-management", icon: Users },
      { name: "Tenant Health Scores", href: "/admin/tenant-health", icon: Heart },
      { name: "Usage Pattern Analysis", href: "/admin/usage-patterns", icon: TrendingUp },
      { name: "Customer Success Automation", href: "/admin/customer-success", icon: Target },
    ]
  },
  {
    title: "Assessment & Content Control",
    items: [
      { name: "Test Creation", href: "/admin/test-creation", icon: PlusCircle },
      { name: "Question Bank", href: "/admin/question-bank", icon: HelpCircle },
      { name: "Bulk Operations", href: "/admin/bulk-upload", icon: Upload },
      { name: "Content Moderation", href: "/admin/content-moderation", icon: Shield },
      { name: "Assessment Analytics", href: "/admin/assessment-analytics", icon: BarChart3 },
    ]
  },
  {
    title: "Security & Compliance",
    items: [
      { name: "Security Monitoring", href: "/admin/security-monitoring", icon: Shield },
      { name: "Audit Logs", href: "/admin/audit-logs", icon: FileText },
      { name: "Compliance Dashboard", href: "/admin/compliance-dashboard", icon: CheckCircle },
      { name: "Data Privacy Controls", href: "/admin/data-privacy", icon: Lock },
    ]
  },
  {
    title: "System Operations",
    items: [
      { name: "System Monitoring", href: "/admin/system-monitoring", icon: Monitor },
      { name: "Database Management", href: "/admin/database-management", icon: Database },
      { name: "API Management", href: "/admin/api-management", icon: Key },
      { name: "Integration Control", href: "/admin/integration-control", icon: Settings },
    ]
  },
  {
    title: "Business Intelligence",
    items: [
      { name: "Market Analysis", href: "/admin/market-analysis", icon: Globe },
      { name: "Growth Forecasting", href: "/admin/growth-forecasting", icon: TrendingUp },
      { name: "Feature Adoption Tracking", href: "/admin/feature-adoption", icon: Target },
      { name: "ROI Calculator", href: "/admin/roi-calculator", icon: Calculator },
    ]
  },
  {
    title: "Automation & AI",
    items: [
      { name: "AI Monitoring", href: "/admin/ai-monitoring", icon: Brain },
      { name: "Automated Workflows", href: "/admin/automated-workflows", icon: Zap },
      { name: "Predictive Maintenance", href: "/admin/predictive-maintenance", icon: Wrench },
      { name: "Smart Alerts", href: "/admin/smart-alerts", icon: Bell },
    ]
  },
  {
    title: "Configuration & Settings",
    items: [
      { name: "Platform Settings", href: "/admin/platform-settings", icon: Settings },
      { name: "Feature Control", href: "/admin/feature-control", icon: Sliders },
      { name: "API Keys", href: "/admin/api-keys", icon: Key },
      { name: "Admin Settings", href: "/admin/settings", icon: User },
    ]
  }
];

// 4. LMS PLATFORM - Green Theme (Education Focus)
export const lmsNavigation: NavigationSection[] = [
  {
    title: "Core Learning",
    items: [
      { name: "Dashboard", href: "/lms", icon: BarChart3, current: true },
      { name: "Course Library", href: "/lms/library", icon: BookOpen },
      { name: "My Learning", href: "/lms/my-learning", icon: User },
    ]
  },
  {
    title: "Learning Modules",
    items: [
      { name: "Interactive Courses", href: "/lms/courses", icon: BookOpen, badge: "24" },
      { name: "Video Lectures", href: "/lms/videos", icon: Video },
      { name: "Practice Tests", href: "/lms/practice-tests", icon: Target },
      { name: "Assignments", href: "/lms/assignments", icon: PenTool },
    ]
  },
  {
    title: "Certification Programs",
    items: [
      { name: "Assessment Hub", href: "/assessment", icon: Target, badge: "New" },
      { name: "Browse Certifications", href: "/lms/certifications", icon: Award },
      { name: "Certification Tracker", href: "/lms/cert-tracker", icon: CheckCircle },
      { name: "AI Learning Path", href: "/lms/ai-path", icon: Brain },
      { name: "Blockchain Certificates", href: "/lms/blockchain-certs", icon: Shield },
    ]
  },
  {
    title: "Advanced Features",
    items: [
      { name: "Mentorship Programs", href: "/lms/mentorship", icon: Users },
      { name: "Project-based Learning", href: "/lms/projects", icon: Code },
      { name: "Security Certifications", href: "/lms/security-certs", icon: Shield },
    ]
  },
  {
    title: "Collaboration",
    items: [
      { name: "Study Groups", href: "/lms/study-groups", icon: Users },
      { name: "Peer Learning", href: "/lms/peer-learning", icon: MessageSquare },
      { name: "Discussion Forums", href: "/lms/forums", icon: MessageCircle },
    ]
  },
  {
    title: "Progress Tracking",
    items: [
      { name: "Learning Analytics", href: "/lms/analytics", icon: BarChart3 },
      { name: "Progress Reports", href: "/lms/progress", icon: TrendingUp },
      { name: "Achievement Badges", href: "/lms/badges", icon: Award },
    ]
  },
  {
    title: "Profile & Settings",
    items: [
      { name: "LMS Profile", href: "/lms/profile", icon: User },
      { name: "Billing & Usage", href: "/billing-dashboard", icon: CreditCard },
      { name: "Settings", href: "/lms/settings", icon: Settings },
    ]
  }
];

// 5. ASSESSMENT PLATFORM - Purple Theme
export const assessmentNavigation: NavigationSection[] = [
  {
    title: "Core Assessment Hub",
    items: [
      { name: "Dashboard", href: "/assessment/dashboard", icon: Target, current: true },
      { name: "Platform Overview", href: "/assessment/overview", icon: BarChart3 },
      { name: "Test Creation Studio", href: "/assessment/test-creation", icon: Plus, badge: "Enhanced" },
      { name: "AI Test Generator", href: "/assessment/ai-generator", icon: Brain, badge: "AI" },
    ]
  },
  {
    title: "Assessment Types",
    items: [
      { name: "Technical Assessments", href: "/assessment/technical", icon: Code },
      { name: "Behavioral Testing", href: "/assessment/behavioral", icon: Users },
      { name: "Cognitive Assessments", href: "/assessment/cognitive", icon: Brain },
      { name: "Role-Based Testing", href: "/assessment/role-based", icon: Briefcase },
    ]
  },
  {
    title: "Test Management",
    items: [
      { name: "Browse Tests", href: "/assessment/browse-tests", icon: Search },
      { name: "Test Runner", href: "/assessment/test-runner", icon: Play },
      { name: "Test Results", href: "/assessment/test-results", icon: BarChart3 },
      { name: "Question Bank", href: "/assessment/question-bank", icon: Database },
    ]
  },
  {
    title: "AI-Powered Features",
    items: [
      { name: "Smart Proctoring", href: "/assessment/ai-proctoring", icon: Shield, badge: "AI" },
      { name: "Automated Scoring", href: "/assessment/ai-scoring", icon: Zap, badge: "AI" },
      { name: "Fraud Detection", href: "/assessment/fraud-detection", icon: AlertTriangle, badge: "Security" },
      { name: "Behavioral Analytics", href: "/assessment/behavioral-analytics", icon: Activity, badge: "AI" },
    ]
  },
  {
    title: "User Management",
    items: [
      { name: "Test Takers", href: "/assessment/users", icon: Users },
      { name: "Team Collaboration", href: "/assessment/collaboration", icon: UserPlus },
      { name: "Role Management", href: "/assessment/roles", icon: Shield },
      { name: "Bulk Operations", href: "/assessment/bulk-upload", icon: Upload },
    ]
  },
  {
    title: "Analytics & Insights",
    items: [
      { name: "Performance Analytics", href: "/assessment/analytics", icon: TrendingUp },
      { name: "Test Analytics", href: "/assessment/test-analytics", icon: BarChart3 },
      { name: "Learning Insights", href: "/assessment/learning-insights", icon: Lightbulb },
      { name: "Predictive Analytics", href: "/assessment/predictive", icon: TrendingUp, badge: "AI" },
    ]
  },
  {
    title: "Certification & Achievements",
    items: [
      { name: "Earned Certificates", href: "/assessment/certifications", icon: Award },
      { name: "Blockchain Certificates", href: "/assessment/blockchain-certificates", icon: Shield },
      { name: "Digital Badges", href: "/assessment/digital-badges", icon: Star, badge: "New" },
      { name: "Achievement Gallery", href: "/assessment/achievements", icon: Trophy },
    ]
  },
  {
    title: "Integration & Customization",
    items: [
      { name: "Third-Party Integration", href: "/assessment/integrations", icon: Link },
      { name: "Custom Branding", href: "/assessment/branding", icon: Palette },
      { name: "White-Label Setup", href: "/assessment/white-label", icon: Settings, badge: "Enterprise" },
      { name: "API Management", href: "/assessment/api-management", icon: Code },
    ]
  },
  {
    title: "Learning Integration",
    items: [
      { name: "LMS Courses", href: "/assessment/courses", icon: BookOpen },
      { name: "Practice Tests", href: "/assessment/practice-tests", icon: Target },
      { name: "Learning Paths", href: "/assessment/learning-paths", icon: MapPin, badge: "New" },
      { name: "Study Materials", href: "/assessment/study-materials", icon: Book },
    ]
  }
];

// Platform Configurations
export const platformConfigs: Record<string, PlatformConfig> = {
  candidate: {
    platformName: "Candidate Portal",
    platformSubtitle: "Your Career Journey Starts Here",
    platformIcon: UserCheck,
    platformColor: "blue",
    planName: "Professional",
    planColor: "blue",
    sidebarTitle: "Candidate Portal",
    sidebarSubtitle: "Build Your Future",
    sidebarSections: candidateNavigation,
    usageData: [
      { label: "Applications", current: 12, max: 50 },
      { label: "Skill Tests", current: 8, max: 20 },
      { label: "AI Sessions", current: 15, max: 30 }
    ]
  },
  recruiter: {
    platformName: "Recruiter Portal",
    platformSubtitle: "Smart Hiring Made Simple",
    platformIcon: Users,
    platformColor: "green",
    planName: "Enterprise",
    planColor: "green",
    sidebarTitle: "Recruiter Portal",
    sidebarSubtitle: "Find Top Talent",
    sidebarSections: recruiterNavigation,
    usageData: [
      { label: "Active Jobs", current: 12, max: 25 },
      { label: "Candidates", current: 247, max: 500 },
      { label: "AI Credits", current: 850, max: 1000 }
    ]
  },
  admin: {
    platformName: "AdminHub",
    platformSubtitle: "System Control Center",
    platformIcon: Shield,
    platformColor: "purple",
    planName: "Super Admin",
    planColor: "purple",
    sidebarTitle: "AdminHub",
    sidebarSubtitle: "Platform Management",
    sidebarSections: adminNavigation,
    usageData: [
      { label: "System Load", current: 68, max: 100 },
      { label: "Active Users", current: 1247, max: 2000 },
      { label: "Storage", current: 45, max: 100 }
    ]
  },
  lms: {
    platformName: "LearningHub",
    platformSubtitle: "Knowledge Empowers Growth",
    platformIcon: GraduationCap,
    platformColor: "emerald",
    planName: "Education Pro",
    planColor: "emerald",
    sidebarTitle: "LearningHub",
    sidebarSubtitle: "Expand Your Skills",
    sidebarSections: lmsNavigation,
    usageData: [
      { label: "Courses", current: 8, max: 15 },
      { label: "Certificates", current: 3, max: 10 },
      { label: "Learning Hours", current: 45, max: 100 }
    ]
  },
  assessment: {
    platformName: "AssessmentHub",
    platformSubtitle: "Skills Testing Platform",
    platformIcon: Target,
    platformColor: "purple",
    planName: "Assessment Pro",
    planColor: "purple",
    sidebarTitle: "AssessmentHub",
    sidebarSubtitle: "Test Your Skills",
    sidebarSections: assessmentNavigation,
    usageData: [
      { label: "Tests Taken", current: 12, max: 30 },
      { label: "Certificates", current: 4, max: 15 },
      { label: "Test Credits", current: 85, max: 100 }
    ]
  }
};