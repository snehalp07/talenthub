import { 
  Home, 
  Target, 
  FileText, 
  Code, 
  Brain, 
  Users, 
  Database, 
  BarChart3, 
  Award, 
  Play, 
  Eye, 
  Star,
  Zap,
  CheckCircle,
  TrendingUp,
  Activity,
  PlusCircle
} from "lucide-react";

export interface NavigationItem {
  name: string;
  href: string;
  icon: any;
  current?: boolean;
  badge?: string;
  children?: NavigationItem[];
  isSubHeader?: boolean;
}

export interface NavigationSection {
  title?: string;
  items: NavigationItem[];
  isHeader?: boolean;
  isParent?: boolean;
}

// Streamlined Assessment Platform Navigation - Logical User Workflow
export const assessmentNavigation: NavigationSection[] = [
  {
    title: "Assessment Hub",
    items: [
      { name: "Dashboard", href: "/assessment/dashboard", icon: Home },
      { name: "Test Creation Studio", href: "/assessment/test-creation", icon: PlusCircle },
      { name: "Question Bank", href: "/assessment/question-bank", icon: Database },
      { name: "Active Tests", href: "/assessment/active-tests", icon: Play },
      { name: "Test Runner", href: "/assessment/test-runner", icon: Code },
    ]
  },
  {
    title: "Assessment Types",
    items: [
      { name: "Technical", href: "/assessment/technical", icon: Code },
      { name: "Behavioral", href: "/assessment/behavioral", icon: Users },
      { name: "Cognitive", href: "/assessment/cognitive", icon: Brain },
      { name: "Role-Based", href: "/assessment/role-based", icon: Target },
    ]
  },
  {
    title: "AI Automation",
    items: [
      { name: "AI Generator", href: "/assessment/ai-generator", icon: Zap },
      { name: "Smart Proctoring", href: "/assessment/smart-proctoring", icon: Eye },
      { name: "Auto Scoring", href: "/assessment/auto-scoring", icon: CheckCircle },
      { name: "Adaptive Testing", href: "/assessment/adaptive-testing", icon: Activity },
    ]
  },
  {
    title: "Results & Analytics",
    items: [
      { name: "Test Results", href: "/assessment/test-results", icon: BarChart3 },
      { name: "Performance Analytics", href: "/assessment/analytics", icon: TrendingUp },
      { name: "Certifications", href: "/assessment/certifications", icon: Award },
    ]
  },
  {
    title: "Learning Support",
    items: [
      { name: "Learning Paths", href: "/assessment/learning-paths", icon: Star },
      { name: "Study Materials", href: "/assessment/study-materials", icon: FileText },
      { name: "Practice Tests", href: "/assessment/practice-tests", icon: Target },
    ]
  }
];