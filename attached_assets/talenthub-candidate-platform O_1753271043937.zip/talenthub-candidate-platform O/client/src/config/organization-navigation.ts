import { 
  Building2,
  Users,
  GraduationCap,
  Shield,
  Target,
  BarChart3,
  Settings,
  TestTube,
  Award,
  Calendar,
  TrendingUp,
  FileText,
  Download
} from "lucide-react";
import { NavigationSection } from "@/components/layout/expandable-sidebar";

export const organizationNavigation: NavigationSection[] = [
  {
    title: "Core Management",
    items: [
      { name: "Dashboard", href: "/organization", icon: Building2 },
      { name: "Department Structure", href: "/organization/departments", icon: Building2 },
      { name: "User Management", href: "/organization/users", icon: Users },
      { name: "Organization Settings", href: "/organization/settings", icon: Settings }
    ]
  },
  {
    title: "Core Data Model",
    items: [
      { name: "Skill Competency Matrix", href: "/organization/skill-matrix", icon: Target },
      { name: "Career Progression Paths", href: "/organization/career-paths", icon: TrendingUp },
      { name: "Performance Benchmarks", href: "/organization/benchmarks", icon: BarChart3 },
      { name: "Budget & Resource Tracking", href: "/organization/budget-tracking", icon: FileText }
    ]
  },
  {
    title: "Cross-Platform Intelligence",
    items: [
      { name: "Assessment Trigger Events", href: "/organization/trigger-events", icon: Calendar },
      { name: "Skills Gap Analysis", href: "/organization/skills-gap", icon: Target },
      { name: "Resource Optimization", href: "/organization/resource-optimization", icon: Settings },
      { name: "Workflow Automation", href: "/organization/workflow-automation", icon: TestTube }
    ]
  },
  {
    title: "Advanced Analytics",
    items: [
      { name: "Predictive Analytics", href: "/organization/predictive-analytics", icon: TrendingUp },
      { name: "Industry Benchmarking", href: "/organization/industry-benchmarking", icon: BarChart3 },
      { name: "Advanced Permissions", href: "/organization/advanced-permissions", icon: Shield },
      { name: "Cross-Platform Sync", href: "/organization/cross-platform-sync", icon: Download }
    ]
  },
  {
    title: "Integration & Intelligence",
    items: [
      { name: "Unified User Context", href: "/organization/user-context", icon: Users },
      { name: "Learning Intelligence", href: "/organization/learning-intelligence", icon: GraduationCap },
      { name: "Multi-Tenant Intelligence", href: "/organization/multi-tenant-intelligence", icon: Building2 },
      { name: "API Integration Hub", href: "/organization/api-integration", icon: Download }
    ]
  }
];