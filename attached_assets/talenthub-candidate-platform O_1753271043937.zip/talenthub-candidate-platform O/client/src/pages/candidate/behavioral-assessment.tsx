import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import PlatformLayout from "@/components/layout/platform-layout";
import { candidateNavigation } from "@/config/complete-navigation";
import { 
  Brain, Users, MessageSquare, Heart, Award, TrendingUp,
  Star, CheckCircle, Target, Activity, Clock, Play,
  Eye, Zap, BookOpen, ArrowRight, Shield, Lightbulb
} from "lucide-react";

const BehavioralAssessment: React.FC = () => {
  const [selectedDimension, setSelectedDimension] = useState('communication');

  const behavioralDimensions = {
    communication: {
      name: 'Communication Skills',
      icon: MessageSquare,
      color: 'from-blue-500 to-cyan-500',
      score: 82,
      percentile: 78,
      trend: '+8%',
      strengths: ['Clear articulation', 'Active listening', 'Technical explanation'],
      weaknesses: ['Presentation confidence', 'Public speaking'],
      skills: [
        { skill: 'Verbal Communication', score: 85, benchmark: 80 },
        { skill: 'Technical Explanation', score: 88, benchmark: 75 },
        { skill: 'Active Listening', score: 79, benchmark: 82 },
        { skill: 'Presentation Skills', score: 74, benchmark: 78 },
        { skill: 'Question Asking', score: 81, benchmark: 80 }
      ]
    },
    leadership: {
      name: 'Leadership Potential',
      icon: Users,
      color: 'from-purple-500 to-pink-500',
      score: 75,
      percentile: 68,
      trend: '+12%',
      strengths: ['Team collaboration', 'Decision making', 'Mentoring others'],
      weaknesses: ['Conflict resolution', 'Delegation'],
      skills: [
        { skill: 'Team Leadership', score: 78, benchmark: 75 },
        { skill: 'Decision Making', score: 82, benchmark: 78 },
        { skill: 'Conflict Resolution', score: 68, benchmark: 72 },
        { skill: 'Delegation', score: 71, benchmark: 75 },
        { skill: 'Mentoring', score: 79, benchmark: 70 }
      ]
    },
    problemSolving: {
      name: 'Problem Solving',
      icon: Brain,
      color: 'from-green-500 to-emerald-500',
      score: 88,
      percentile: 85,
      trend: '+6%',
      strengths: ['Analytical thinking', 'Creative solutions', 'Systematic approach'],
      weaknesses: ['Time pressure handling', 'Complex prioritization'],
      skills: [
        { skill: 'Analytical Thinking', score: 91, benchmark: 82 },
        { skill: 'Creative Problem Solving', score: 86, benchmark: 78 },
        { skill: 'Systematic Approach', score: 89, benchmark: 80 },
        { skill: 'Under Pressure', score: 72, benchmark: 75 },
        { skill: 'Root Cause Analysis', score: 84, benchmark: 79 }
      ]
    },
    emotional: {
      name: 'Emotional Intelligence',
      icon: Heart,
      color: 'from-orange-500 to-red-500',
      score: 79,
      percentile: 72,
      trend: '+15%',
      strengths: ['Self-awareness', 'Empathy', 'Stress management'],
      weaknesses: ['Social awareness', 'Relationship management'],
      skills: [
        { skill: 'Self Awareness', score: 84, benchmark: 78 },
        { skill: 'Self Regulation', score: 77, benchmark: 75 },
        { skill: 'Empathy', score: 81, benchmark: 79 },
        { skill: 'Social Skills', score: 73, benchmark: 76 },
        { skill: 'Motivation', score: 80, benchmark: 77 }
      ]
    }
  };

  const recentAssessments = [
    {
      type: 'STAR Method Analysis',
      date: '2 days ago',
      score: 84,
      scenario: 'Project Deadline Challenge',
      strengths: ['Clear situation description', 'Measurable results'],
      improvements: ['More specific actions', 'Quantify impact better']
    },
    {
      type: 'Conflict Resolution Scenario',
      date: '1 week ago',
      score: 76,
      scenario: 'Team Disagreement',
      strengths: ['Active listening', 'Multiple perspectives'],
      improvements: ['Faster resolution', 'Follow-up actions']
    },
    {
      type: 'Leadership Challenge',
      date: '2 weeks ago',
      score: 81,
      scenario: 'Cross-functional Coordination',
      strengths: ['Strategic thinking', 'Stakeholder management'],
      improvements: ['Delegation clarity', 'Timeline management']
    }
  ];

  const interviewQuestions = [
    {
      category: 'Teamwork',
      difficulty: 'Medium',
      frequency: 92,
      examples: [
        'Tell me about a time you worked with a difficult team member',
        'Describe a situation where you had to collaborate across departments',
        'How do you handle disagreements in a team setting?'
      ]
    },
    {
      category: 'Leadership',
      difficulty: 'High',
      frequency: 78,
      examples: [
        'Tell me about a time you led a project without formal authority',
        'Describe a situation where you had to motivate an underperforming team',
        'How do you handle when your team disagrees with your decision?'
      ]
    },
    {
      category: 'Problem Solving',
      difficulty: 'Medium',
      frequency: 89,
      examples: [
        'Tell me about the most complex problem you\'ve solved',
        'Describe a time when you had to make a decision with incomplete information',
        'How do you approach problems you\'ve never encountered before?'
      ]
    },
    {
      category: 'Adaptability',
      difficulty: 'Medium',
      frequency: 85,
      examples: [
        'Tell me about a time you had to adapt to significant changes',
        'Describe a situation where priorities changed suddenly',
        'How do you handle working with new technologies or processes?'
      ]
    }
  ];

  const improvementPlan = [
    {
      area: 'Presentation Skills',
      priority: 'High',
      currentScore: 74,
      targetScore: 82,
      timeframe: '4 weeks',
      actions: ['Toastmasters practice', 'Video recording analysis', 'Peer feedback sessions'],
      resources: ['Public speaking course', 'Presentation templates', 'Practice groups']
    },
    {
      area: 'Conflict Resolution',
      priority: 'Medium',
      currentScore: 68,
      targetScore: 75,
      timeframe: '6 weeks',
      actions: ['Case study analysis', 'Role-playing exercises', 'Mediation training'],
      resources: ['Conflict resolution course', 'Harvard negotiation project', 'Practice scenarios']
    }
  ];

  const selectedDimensionData = behavioralDimensions[selectedDimension as keyof typeof behavioralDimensions];

  return (
    <PlatformLayout
      sidebarTitle="Candidate Platform"
      sidebarSubtitle="Interview Preparation"
      sidebarSections={candidateNavigation}
    >
      <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-white to-purple-50 p-6">
        <div className="max-w-7xl mx-auto space-y-8">
          {/* Header */}
          <div className="text-center space-y-4">
            <div className="inline-flex items-center space-x-2 bg-indigo-100 text-indigo-800 px-4 py-2 rounded-full text-sm font-medium">
              <Brain className="h-4 w-4" />
              <span>Behavioral Assessment & Analysis</span>
            </div>
            <h1 className="text-4xl font-bold text-gray-900">
              Behavioral Interview Intelligence
            </h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              AI-powered analysis of your behavioral interview responses, emotional intelligence, 
              and soft skills with personalized improvement recommendations.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Main Content */}
            <div className="lg:col-span-2 space-y-6">
              {/* Behavioral Dimensions */}
              <Tabs value={selectedDimension} onValueChange={setSelectedDimension} className="space-y-6">
                {/* Dimension Selection */}
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  {Object.entries(behavioralDimensions).map(([key, dimension]) => {
                    const IconComponent = dimension.icon;
                    return (
                      <Card 
                        key={key}
                        className={`cursor-pointer transition-all duration-300 hover:shadow-lg border-2 ${
                          selectedDimension === key 
                            ? 'border-indigo-500 shadow-lg' 
                            : 'border-gray-200 hover:border-indigo-300'
                        }`}
                        onClick={() => setSelectedDimension(key)}
                      >
                        <CardContent className="p-4 text-center">
                          <div className={`p-3 rounded-lg bg-gradient-to-r ${dimension.color} mb-2 mx-auto w-fit`}>
                            <IconComponent className="h-6 w-6 text-white" />
                          </div>
                          <h3 className="font-medium text-sm">{dimension.name}</h3>
                          <div className="text-xl font-bold mt-1">{dimension.score}%</div>
                          <div className="text-xs text-green-600">{dimension.trend}</div>
                        </CardContent>
                      </Card>
                    );
                  })}
                </div>

                {/* Selected Dimension Details */}
                <Card>
                  <CardHeader className={`bg-gradient-to-r ${selectedDimensionData.color} text-white`}>
                    <CardTitle className="flex items-center space-x-3">
                      <selectedDimensionData.icon className="h-6 w-6" />
                      <span>{selectedDimensionData.name}</span>
                    </CardTitle>
                    <CardDescription className="text-white/80">
                      Detailed analysis and skill breakdown
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="p-6">
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
                      <div className="text-center">
                        <div className="text-3xl font-bold text-blue-600">{selectedDimensionData.score}%</div>
                        <div className="text-sm text-gray-500">Overall Score</div>
                      </div>
                      <div className="text-center">
                        <div className="text-3xl font-bold text-green-600">{selectedDimensionData.percentile}th</div>
                        <div className="text-sm text-gray-500">Percentile</div>
                      </div>
                      <div className="text-center">
                        <div className="text-3xl font-bold text-purple-600">{selectedDimensionData.trend}</div>
                        <div className="text-sm text-gray-500">Improvement</div>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                      <div>
                        <h3 className="font-semibold text-green-700 mb-2">Key Strengths</h3>
                        <div className="space-y-1">
                          {selectedDimensionData.strengths.map((strength: any, index: number) => (
                            <div key={index} className="flex items-center space-x-2">
                              <CheckCircle className="h-4 w-4 text-green-500" />
                              <span className="text-sm">{strength}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                      <div>
                        <h3 className="font-semibold text-orange-700 mb-2">Development Areas</h3>
                        <div className="space-y-1">
                          {selectedDimensionData.weaknesses.map((weakness: any, index: number) => (
                            <div key={index} className="flex items-center space-x-2">
                              <Target className="h-4 w-4 text-orange-500" />
                              <span className="text-sm">{weakness}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>

                    <div>
                      <h3 className="font-semibold mb-4">Skill Breakdown</h3>
                      <div className="space-y-4">
                        {selectedDimensionData.skills.map((skill: any, index: number) => (
                          <div key={index} className="space-y-2">
                            <div className="flex justify-between items-center">
                              <span className="font-medium">{skill.skill}</span>
                              <div className="flex items-center space-x-2">
                                <span className="text-sm">{skill.score}%</span>
                                <Badge variant={skill.score >= skill.benchmark ? 'default' : 'secondary'}>
                                  {skill.score >= skill.benchmark ? 'Above' : 'Below'} Benchmark
                                </Badge>
                              </div>
                            </div>
                            <div className="relative">
                              <Progress value={skill.score} className="h-2" />
                              <div 
                                className="absolute top-0 h-2 w-1 bg-blue-500 rounded-full"
                                style={{ left: `${skill.benchmark}%` }}
                              />
                            </div>
                            <div className="flex justify-between text-xs text-gray-500">
                              <span>Your Score: {skill.score}%</span>
                              <span>Benchmark: {skill.benchmark}%</span>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Recent Assessments */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-2">
                      <Activity className="h-5 w-5" />
                      <span>Recent Behavioral Assessments</span>
                    </CardTitle>
                    <CardDescription>Your latest behavioral interview evaluations</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {recentAssessments.map((assessment, index) => (
                        <div key={index} className="p-4 border rounded-lg">
                          <div className="flex items-center justify-between mb-3">
                            <div>
                              <h3 className="font-semibold">{assessment.type}</h3>
                              <p className="text-sm text-gray-600">{assessment.scenario}</p>
                            </div>
                            <div className="text-right">
                              <div className="text-xl font-bold">{assessment.score}%</div>
                              <div className="text-xs text-gray-500">{assessment.date}</div>
                            </div>
                          </div>
                          
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                            <div>
                              <span className="font-medium text-green-700">Strengths:</span>
                              <ul className="list-disc list-inside mt-1 text-gray-600">
                                {assessment.strengths.map((strength, i) => (
                                  <li key={i}>{strength}</li>
                                ))}
                              </ul>
                            </div>
                            <div>
                              <span className="font-medium text-orange-700">Improvements:</span>
                              <ul className="list-disc list-inside mt-1 text-gray-600">
                                {assessment.improvements.map((improvement, i) => (
                                  <li key={i}>{improvement}</li>
                                ))}
                              </ul>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </Tabs>
            </div>

            {/* Sidebar */}
            <div className="space-y-6">
              {/* Common Behavioral Questions */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <MessageSquare className="h-5 w-5" />
                    <span>Common Questions</span>
                  </CardTitle>
                  <CardDescription>Frequently asked behavioral questions</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  {interviewQuestions.map((category, index) => (
                    <div key={index} className="p-3 border rounded-lg">
                      <div className="flex items-center justify-between mb-2">
                        <span className="font-medium text-sm">{category.category}</span>
                        <div className="flex items-center space-x-1">
                          <Badge variant="outline" className="text-xs">{category.difficulty}</Badge>
                          <span className="text-xs text-gray-500">{category.frequency}%</span>
                        </div>
                      </div>
                      <div className="text-xs text-gray-600">
                        {category.examples.slice(0, 1).map((example, i) => (
                          <div key={i}>"{example}"</div>
                        ))}
                      </div>
                      <Button variant="ghost" size="sm" className="w-full mt-2 text-xs">
                        <Eye className="h-3 w-3 mr-1" />
                        View All Questions
                      </Button>
                    </div>
                  ))}
                </CardContent>
              </Card>

              {/* Improvement Plan */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Lightbulb className="h-5 w-5" />
                    <span>Improvement Plan</span>
                  </CardTitle>
                  <CardDescription>Personalized development roadmap</CardDescription>
                </CardHeader>
                <CardContent className="space-y-3">
                  {improvementPlan.map((plan, index) => (
                    <div key={index} className="p-3 bg-gray-50 rounded-lg">
                      <div className="flex items-center justify-between mb-2">
                        <span className="font-medium text-sm">{plan.area}</span>
                        <Badge variant={plan.priority === 'High' ? 'destructive' : 'default'}>
                          {plan.priority}
                        </Badge>
                      </div>
                      <div className="text-xs text-gray-600 mb-2">
                        {plan.currentScore}% → {plan.targetScore}% in {plan.timeframe}
                      </div>
                      <Progress value={(plan.currentScore / plan.targetScore) * 100} className="h-1 mb-2" />
                      <div className="text-xs text-blue-600">
                        {plan.actions.slice(0, 2).join(', ')}
                      </div>
                    </div>
                  ))}
                </CardContent>
              </Card>

              {/* Action Buttons */}
              <div className="space-y-3">
                <Button size="lg" className="w-full bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700">
                  <Play className="h-4 w-4 mr-2" />
                  Practice STAR Method
                </Button>
                <Button variant="outline" size="lg" className="w-full">
                  <BookOpen className="h-4 w-4 mr-2" />
                  Behavioral Guide
                </Button>
                <Button variant="outline" size="lg" className="w-full">
                  <Target className="h-4 w-4 mr-2" />
                  Set Development Goals
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </PlatformLayout>
  );
};

export default BehavioralAssessment;