import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import PlatformLayout from "@/components/layout/platform-layout";
import { platformConfigs } from "@/config/complete-navigation";
import { useQuery } from "@tanstack/react-query";
import { 
  Brain, 
  Play, 
  Clock, 
  Trophy,
  Target,
  CheckCircle,
  Star,
  BarChart3,
  Award,
  Users,
  BookOpen,
  Zap
} from "lucide-react";

export default function SkillTests() {
  const config = platformConfigs.candidate;

  const { data: availableTests = [], isLoading } = useQuery({
    queryKey: ["/api/candidate/tests"],
    queryFn: async () => {
      const response = await fetch("/api/candidate/tests");
      if (!response.ok) throw new Error("Failed to fetch tests");
      return response.json();
    },
  });

  const mockTests = [
    {
      id: 1,
      title: "JavaScript Fundamentals",
      description: "Test your core JavaScript knowledge including ES6+ features",
      difficulty: "Intermediate",
      duration: "45 minutes",
      questions: 30,
      passRate: 75,
      attempts: 2847,
      avgScore: 78,
      skills: ["JavaScript", "ES6", "Functions", "Objects"],
      category: "Frontend"
    },
    {
      id: 2,
      title: "React Advanced Concepts",
      description: "Deep dive into React patterns, hooks, and performance optimization",
      difficulty: "Advanced",
      duration: "60 minutes",
      questions: 25,
      passRate: 68,
      attempts: 1923,
      avgScore: 82,
      skills: ["React", "Hooks", "Context", "Performance"],
      category: "Frontend"
    },
    {
      id: 3,
      title: "Node.js Backend Development",
      description: "Server-side development with Node.js, Express, and databases",
      difficulty: "Intermediate",
      duration: "50 minutes",
      questions: 28,
      passRate: 71,
      attempts: 2156,
      avgScore: 75,
      skills: ["Node.js", "Express", "APIs", "Databases"],
      category: "Backend"
    },
    {
      id: 4,
      title: "System Design Principles",
      description: "Architecture patterns, scalability, and design considerations",
      difficulty: "Advanced",
      duration: "90 minutes",
      questions: 20,
      passRate: 58,
      attempts: 892,
      avgScore: 73,
      skills: ["Architecture", "Scalability", "Design Patterns", "Databases"],
      category: "System Design"
    }
  ];

  const completedTests = [
    {
      title: "JavaScript Fundamentals",
      score: 87,
      completedDate: "2024-06-10",
      rank: "Top 15%",
      certificate: true
    },
    {
      title: "CSS Advanced Styling",
      score: 92,
      completedDate: "2024-06-05",
      rank: "Top 8%",
      certificate: true
    },
    {
      title: "HTML5 & Semantics",
      score: 89,
      completedDate: "2024-05-28",
      rank: "Top 12%",
      certificate: true
    }
  ];

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case "Beginner":
        return "bg-green-100 text-green-600";
      case "Intermediate":
        return "bg-yellow-100 text-yellow-600";
      case "Advanced":
        return "bg-red-100 text-red-600";
      default:
        return "bg-gray-100 text-gray-600";
    }
  };

  const getCategoryColor = (category: string) => {
    switch (category) {
      case "Frontend":
        return "bg-blue-100 text-blue-600";
      case "Backend":
        return "bg-green-100 text-green-600";
      case "System Design":
        return "bg-purple-100 text-purple-600";
      default:
        return "bg-gray-100 text-gray-600";
    }
  };

  return (
    <PlatformLayout
      sidebarTitle={config.sidebarTitle}
      sidebarSubtitle={config.sidebarSubtitle}
      sidebarSections={config.sidebarSections}
      usageData={config.usageData}
    >
      <div className="max-w-6xl mx-auto px-6 py-8">
        {/* Header */}
        <div className="mb-8">
          <h2 className="text-3xl font-bold text-neutral-600 mb-2">Skill Tests</h2>
          <p className="text-neutral-500">Assess your technical skills with comprehensive tests and earn certificates.</p>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card className="shadow-sm">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                  <CheckCircle className="w-6 h-6 text-green-600" />
                </div>
                <Badge variant="outline">Completed</Badge>
              </div>
              <h3 className="text-2xl font-bold text-neutral-600 mb-1">3</h3>
              <p className="text-sm text-neutral-500">Tests Passed</p>
            </CardContent>
          </Card>

          <Card className="shadow-sm">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                  <Trophy className="w-6 h-6 text-blue-600" />
                </div>
                <Badge variant="outline">Average</Badge>
              </div>
              <h3 className="text-2xl font-bold text-neutral-600 mb-1">89%</h3>
              <p className="text-sm text-neutral-500">Score</p>
            </CardContent>
          </Card>

          <Card className="shadow-sm">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
                  <Award className="w-6 h-6 text-purple-600" />
                </div>
                <Badge variant="outline">Earned</Badge>
              </div>
              <h3 className="text-2xl font-bold text-neutral-600 mb-1">3</h3>
              <p className="text-sm text-neutral-500">Certificates</p>
            </CardContent>
          </Card>

          <Card className="shadow-sm">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center">
                  <Star className="w-6 h-6 text-orange-600" />
                </div>
                <Badge variant="outline">Ranking</Badge>
              </div>
              <h3 className="text-2xl font-bold text-neutral-600 mb-1">Top 15%</h3>
              <p className="text-sm text-neutral-500">Global Rank</p>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Available Tests */}
          <div className="lg:col-span-2">
            <Card className="shadow-sm">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="text-xl">Available Tests</CardTitle>
                  <Button variant="ghost" size="sm">Filter</Button>
                </div>
                <CardDescription>
                  Choose from various skill assessments to test your knowledge
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {availableTests.map((test: any) => (
                    <div key={test.id} className="border border-neutral-200 rounded-lg p-4 hover:bg-neutral-50 transition-colors">
                      <div className="flex items-start justify-between mb-3">
                        <div className="flex-1">
                          <div className="flex items-center space-x-2 mb-2">
                            <h3 className="font-semibold text-neutral-600">{test.title}</h3>
                            <Badge className={getDifficultyColor(test.difficulty)}>
                              {test.difficulty}
                            </Badge>
                            <Badge className={getCategoryColor(test.category)} variant="outline">
                              {test.category}
                            </Badge>
                          </div>
                          <p className="text-sm text-neutral-500 mb-3">{test.description}</p>
                          <div className="flex items-center space-x-4 text-xs text-neutral-400 mb-3">
                            <div className="flex items-center">
                              <Clock className="w-3 h-3 mr-1" />
                              {test.duration} min
                            </div>
                            <div className="flex items-center">
                              <Brain className="w-3 h-3 mr-1" />
                              {test.totalQuestions || test.questions} questions
                            </div>
                            <div className="flex items-center">
                              <Users className="w-3 h-3 mr-1" />
                              {(test.attempts || 0).toLocaleString()} attempts
                            </div>
                          </div>
                          <div className="flex items-center space-x-2">
                            {(test.tags || test.skills || []).map((skill: string, index: number) => (
                              <Badge key={index} variant="outline" className="text-xs">
                                {skill}
                              </Badge>
                            ))}
                          </div>
                        </div>
                        <div className="text-right">
                          <p className="text-sm text-neutral-500 mb-1">Pass Rate</p>
                          <p className="text-lg font-bold text-green-600">{test.passRate || test.passingScore || 70}%</p>
                          <p className="text-xs text-neutral-400">Avg: {test.avgScore || 75}%</p>
                        </div>
                      </div>
                      <div className="flex items-center justify-between pt-3 border-t border-neutral-200">
                        <div className="flex items-center space-x-2">
                          <Star className="w-4 h-4 text-yellow-500 fill-current" />
                          <span className="text-xs text-neutral-500">Industry recognized</span>
                        </div>
                        <Button 
                          className="bg-blue-500 hover:bg-blue-600" 
                          size="sm"
                          onClick={() => window.location.href = `/candidate/test-runner/${test.id}`}
                        >
                          <Play className="w-4 h-4 mr-1" />
                          Start Test
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar Content */}
          <div className="space-y-6">
            {/* Completed Tests */}
            <Card className="shadow-sm">
              <CardHeader>
                <CardTitle className="text-lg">Completed Tests</CardTitle>
                <CardDescription>
                  Your recent test results and achievements
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {completedTests.map((test, index) => (
                    <div key={index} className="border border-neutral-200 rounded-lg p-3">
                      <h4 className="font-medium text-neutral-600 mb-2">{test.title}</h4>
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center space-x-2">
                          <Badge className="bg-green-100 text-green-600">
                            {test.score}%
                          </Badge>
                          {test.certificate && (
                            <Badge className="bg-purple-100 text-purple-600">
                              <Award className="w-3 h-3 mr-1" />
                              Certified
                            </Badge>
                          )}
                        </div>
                        <span className="text-xs text-neutral-400">{test.completedDate}</span>
                      </div>
                      <p className="text-xs text-neutral-500">{test.rank} globally</p>
                    </div>
                  ))}
                </div>
                <Button variant="outline" className="w-full mt-4">
                  <BarChart3 className="w-4 h-4 mr-2" />
                  View All Results
                </Button>
              </CardContent>
            </Card>

            {/* Test Categories */}
            <Card className="shadow-sm">
              <CardHeader>
                <CardTitle className="text-lg">Test Categories</CardTitle>
                <CardDescription>
                  Explore different skill domains
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="border border-neutral-200 rounded-lg p-3">
                    <div className="flex items-center space-x-2 mb-2">
                      <div className="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center">
                        <BookOpen className="w-4 h-4 text-blue-600" />
                      </div>
                      <span className="text-sm font-medium">Frontend Development</span>
                    </div>
                    <p className="text-xs text-neutral-500 mb-2">React, Vue, CSS, JavaScript</p>
                    <Progress value={75} className="h-2" />
                    <p className="text-xs text-neutral-400 mt-1">3/4 tests completed</p>
                  </div>
                  <div className="border border-neutral-200 rounded-lg p-3">
                    <div className="flex items-center space-x-2 mb-2">
                      <div className="w-8 h-8 bg-green-100 rounded-lg flex items-center justify-center">
                        <Zap className="w-4 h-4 text-green-600" />
                      </div>
                      <span className="text-sm font-medium">Backend Development</span>
                    </div>
                    <p className="text-xs text-neutral-500 mb-2">Node.js, APIs, Databases</p>
                    <Progress value={25} className="h-2" />
                    <p className="text-xs text-neutral-400 mt-1">1/4 tests completed</p>
                  </div>
                  <div className="border border-neutral-200 rounded-lg p-3">
                    <div className="flex items-center space-x-2 mb-2">
                      <div className="w-8 h-8 bg-purple-100 rounded-lg flex items-center justify-center">
                        <Target className="w-4 h-4 text-purple-600" />
                      </div>
                      <span className="text-sm font-medium">System Design</span>
                    </div>
                    <p className="text-xs text-neutral-500 mb-2">Architecture, Scalability</p>
                    <Progress value={0} className="h-2" />
                    <p className="text-xs text-neutral-400 mt-1">0/3 tests completed</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </PlatformLayout>
  );
}