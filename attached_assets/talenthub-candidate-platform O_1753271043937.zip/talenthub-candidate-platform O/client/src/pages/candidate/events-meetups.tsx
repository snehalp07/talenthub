import PlatformLayout from "@/components/layout/platform-layout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Calendar, MapPin, Users, Clock, Search, Filter, Star, ChevronRight, Globe, Video, Coffee, Briefcase, Code, Zap } from "lucide-react";
import { platformConfigs } from "@/config/complete-navigation";

export default function EventsMeetups() {
  const config = platformConfigs.candidate;
  const upcomingEvents = [
    {
      id: 1,
      title: "Tech Leaders Summit 2025",
      type: "Conference",
      date: "June 28, 2025",
      time: "9:00 AM - 6:00 PM",
      location: "San Francisco Convention Center",
      attendees: 2500,
      price: "Free",
      category: "Technology",
      organizer: "TechCorp Inc.",
      image: "https://images.unsplash.com/photo-1540575467063-178a50c2df87?w=300&h=200&fit=crop",
      tags: ["AI", "Leadership", "Innovation"],
      virtual: false,
      featured: true
    },
    {
      id: 2,
      title: "Frontend Development Masterclass",
      type: "Workshop",
      date: "June 25, 2025",
      time: "2:00 PM - 5:00 PM",
      location: "Virtual Event",
      attendees: 150,
      price: "$49",
      category: "Development",
      organizer: "Code Academy",
      image: "https://images.unsplash.com/photo-1522202176988-66273c2fd55f?w=300&h=200&fit=crop",
      tags: ["React", "JavaScript", "CSS"],
      virtual: true,
      featured: false
    },
    {
      id: 3,
      title: "Career Networking Night",
      type: "Networking",
      date: "June 30, 2025",
      time: "6:00 PM - 9:00 PM",
      location: "Downtown Business District",
      attendees: 200,
      price: "Free",
      category: "Career",
      organizer: "Professional Network Hub",
      image: "https://images.unsplash.com/photo-1511578314322-379afb476865?w=300&h=200&fit=crop",
      tags: ["Networking", "Career", "Business"],
      virtual: false,
      featured: true
    }
  ];

  const categories = [
    { name: "Technology", count: 45, color: "bg-blue-500", icon: Code },
    { name: "Career", count: 32, color: "bg-green-500", icon: Briefcase },
    { name: "Networking", count: 28, color: "bg-purple-500", icon: Users },
    { name: "Leadership", count: 18, color: "bg-orange-500", icon: Star },
    { name: "Innovation", count: 15, color: "bg-pink-500", icon: Zap },
    { name: "Virtual", count: 22, color: "bg-indigo-500", icon: Video }
  ];

  const myEvents = [
    {
      id: 1,
      title: "AI in Healthcare Symposium",
      date: "July 5, 2025",
      status: "Registered",
      type: "Conference"
    },
    {
      id: 2,
      title: "Startup Pitch Night",
      date: "July 10, 2025", 
      status: "Interested",
      type: "Networking"
    },
    {
      id: 3,
      title: "Data Science Workshop",
      date: "July 15, 2025",
      status: "Attending",
      type: "Workshop"
    }
  ];

  return (
    <PlatformLayout
      sidebarTitle={config.sidebarTitle}
      sidebarSubtitle={config.sidebarSubtitle}
      sidebarSections={config.sidebarSections}
      usageData={config.usageData}
    >
      <div className="p-6 max-w-7xl mx-auto space-y-6">
      {/* Header */}
      <div className="text-center space-y-4">
        <div className="flex items-center justify-center space-x-3">
          <div className="p-3 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full">
            <Calendar className="h-8 w-8 text-white" />
          </div>
          <h1 className="text-4xl font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
            Events & Meetups
          </h1>
        </div>
        <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
          Discover professional events, workshops, and networking opportunities to advance your career
        </p>
      </div>

      {/* Search and Filter */}
      <Card className="bg-gradient-to-r from-purple-50 to-pink-50 border-purple-200">
        <CardContent className="p-6">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
              <Input placeholder="Search events, workshops, conferences..." className="pl-10 bg-white" />
            </div>
            <div className="flex gap-2">
              <Button variant="outline" className="border-purple-300 hover:bg-purple-50">
                <Filter className="h-4 w-4 mr-2" />
                Filter
              </Button>
              <Button variant="outline" className="border-purple-300 hover:bg-purple-50">
                <MapPin className="h-4 w-4 mr-2" />
                Location
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      <Tabs defaultValue="discover" className="space-y-6">
        <TabsList className="grid w-full grid-cols-4 bg-purple-100">
          <TabsTrigger value="discover" className="data-[state=active]:bg-purple-500 data-[state=active]:text-white">
            Discover Events
          </TabsTrigger>
          <TabsTrigger value="categories" className="data-[state=active]:bg-purple-500 data-[state=active]:text-white">
            Categories
          </TabsTrigger>
          <TabsTrigger value="my-events" className="data-[state=active]:bg-purple-500 data-[state=active]:text-white">
            My Events
          </TabsTrigger>
          <TabsTrigger value="create" className="data-[state=active]:bg-purple-500 data-[state=active]:text-white">
            Create Event
          </TabsTrigger>
        </TabsList>

        <TabsContent value="discover" className="space-y-6">
          {/* Featured Events */}
          <div className="space-y-4">
            <h2 className="text-2xl font-bold text-purple-700">Featured Events</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {upcomingEvents.map((event) => (
                <Card key={event.id} className="group hover:shadow-lg transition-all duration-300 border-l-4 border-l-purple-500">
                  <div className="relative">
                    <img 
                      src={event.image} 
                      alt={event.title}
                      className="w-full h-48 object-cover rounded-t-lg"
                    />
                    <div className="absolute top-3 right-3 flex gap-2">
                      {event.featured && (
                        <Badge className="bg-gradient-to-r from-yellow-400 to-orange-500 text-white">
                          <Star className="h-3 w-3 mr-1" />
                          Featured
                        </Badge>
                      )}
                      {event.virtual && (
                        <Badge variant="secondary" className="bg-blue-100 text-blue-700">
                          <Video className="h-3 w-3 mr-1" />
                          Virtual
                        </Badge>
                      )}
                    </div>
                  </div>
                  <CardHeader className="pb-3">
                    <div className="flex justify-between items-start">
                      <CardTitle className="text-lg group-hover:text-purple-600 transition-colors">
                        {event.title}
                      </CardTitle>
                      <Badge variant="outline" className="text-xs">
                        {event.type}
                      </Badge>
                    </div>
                    <CardDescription className="space-y-2">
                      <div className="flex items-center text-sm text-muted-foreground">
                        <Calendar className="h-4 w-4 mr-2 text-purple-500" />
                        {event.date}
                      </div>
                      <div className="flex items-center text-sm text-muted-foreground">
                        <Clock className="h-4 w-4 mr-2 text-purple-500" />
                        {event.time}
                      </div>
                      <div className="flex items-center text-sm text-muted-foreground">
                        <MapPin className="h-4 w-4 mr-2 text-purple-500" />
                        {event.location}
                      </div>
                      <div className="flex items-center text-sm text-muted-foreground">
                        <Users className="h-4 w-4 mr-2 text-purple-500" />
                        {event.attendees} attendees
                      </div>
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="pt-0 space-y-4">
                    <div className="flex flex-wrap gap-1">
                      {event.tags.map((tag) => (
                        <Badge key={tag} variant="secondary" className="text-xs bg-purple-100 text-purple-700">
                          {tag}
                        </Badge>
                      ))}
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="font-bold text-lg text-purple-600">{event.price}</span>
                      <Button className="bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600">
                        Register
                        <ChevronRight className="h-4 w-4 ml-1" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </TabsContent>

        <TabsContent value="categories" className="space-y-6">
          <h2 className="text-2xl font-bold text-purple-700">Event Categories</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {categories.map((category) => {
              const IconComponent = category.icon;
              return (
                <Card key={category.name} className="group hover:shadow-lg transition-all duration-300 cursor-pointer">
                  <CardContent className="p-6 text-center space-y-4">
                    <div className={`w-16 h-16 ${category.color} rounded-full flex items-center justify-center mx-auto group-hover:scale-110 transition-transform`}>
                      <IconComponent className="h-8 w-8 text-white" />
                    </div>
                    <h3 className="text-xl font-bold group-hover:text-purple-600 transition-colors">
                      {category.name}
                    </h3>
                    <p className="text-3xl font-bold text-purple-600">{category.count}</p>
                    <p className="text-muted-foreground">events available</p>
                    <Button variant="outline" className="w-full border-purple-300 hover:bg-purple-50">
                      Explore Events
                    </Button>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </TabsContent>

        <TabsContent value="my-events" className="space-y-6">
          <h2 className="text-2xl font-bold text-purple-700">My Events</h2>
          <div className="space-y-4">
            {myEvents.map((event) => (
              <Card key={event.id} className="border-l-4 border-l-purple-500">
                <CardContent className="p-6">
                  <div className="flex justify-between items-center">
                    <div>
                      <h3 className="text-lg font-semibold">{event.title}</h3>
                      <p className="text-muted-foreground">{event.date} • {event.type}</p>
                    </div>
                    <div className="flex items-center gap-3">
                      <Badge 
                        variant={event.status === 'Attending' ? 'default' : 'secondary'}
                        className={event.status === 'Attending' ? 'bg-green-500' : ''}
                      >
                        {event.status}
                      </Badge>
                      <Button variant="outline" size="sm">
                        View Details
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="create" className="space-y-6">
          <div className="max-w-2xl mx-auto">
            <Card className="border-purple-200">
              <CardHeader className="text-center">
                <CardTitle className="text-2xl text-purple-700">Create Your Event</CardTitle>
                <CardDescription>Host your own professional event or meetup</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium mb-2">Event Title</label>
                    <Input placeholder="Enter event title" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2">Event Type</label>
                    <Input placeholder="Workshop, Conference, Meetup..." />
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2">Description</label>
                  <Input placeholder="Describe your event..." />
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium mb-2">Date</label>
                    <Input type="date" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2">Time</label>
                    <Input type="time" />
                  </div>
                </div>
                <Button className="w-full bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600">
                  Create Event
                </Button>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
      </div>
    </PlatformLayout>
  );
}