import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import PlatformLayout from "@/components/layout/platform-layout";
import { platformConfigs } from "@/config/complete-navigation";
import { BookOpen, CheckCircle, Clock, Target, Star, TrendingUp } from "lucide-react";

export default function LearningPath() {
  const config = platformConfigs.candidate;

  const learningPaths = [
    {
      title: "Frontend Development Mastery",
      description: "Complete path from basics to advanced React development",
      progress: 65,
      totalModules: 12,
      completedModules: 8,
      estimatedTime: "3 months",
      difficulty: "Intermediate",
      skills: ["React", "JavaScript", "CSS", "TypeScript"],
      status: "In Progress"
    },
    {
      title: "Full Stack JavaScript",
      description: "End-to-end JavaScript development with Node.js and MongoDB",
      progress: 25,
      totalModules: 16,
      completedModules: 4,
      estimatedTime: "4 months",
      difficulty: "Advanced",
      skills: ["Node.js", "MongoDB", "Express", "React"],
      status: "Started"
    },
    {
      title: "DevOps Fundamentals",
      description: "Learn CI/CD, Docker, and cloud deployment strategies",
      progress: 0,
      totalModules: 10,
      completedModules: 0,
      estimatedTime: "2 months",
      difficulty: "Intermediate",
      skills: ["Docker", "AWS", "CI/CD", "Kubernetes"],
      status: "Not Started"
    }
  ];

  const currentModule = {
    title: "Advanced React Patterns",
    description: "Learn render props, higher-order components, and custom hooks",
    progress: 40,
    timeLeft: "2 hours 30 minutes",
    nextLesson: "Custom Hooks Deep Dive"
  };

  const achievements = [
    { title: "React Fundamentals", completed: true, date: "2024-05-15" },
    { title: "JavaScript ES6+", completed: true, date: "2024-05-10" },
    { title: "Component Architecture", completed: true, date: "2024-05-20" },
    { title: "State Management", completed: false, progress: 60 }
  ];

  return (
    <PlatformLayout
      sidebarTitle={config.sidebarTitle}
      sidebarSubtitle={config.sidebarSubtitle}
      sidebarSections={config.sidebarSections}
      usageData={config.usageData}
    >
      <div className="max-w-6xl mx-auto px-6 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Learning Path</h1>
          <p className="text-gray-600">Personalized learning journeys to advance your career</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Current Progress */}
          <div className="lg:col-span-2">
            <div className="mb-6">
              <h2 className="text-xl font-semibold mb-4">Continue Learning</h2>
              <Card className="border-l-4 border-l-blue-500">
                <CardHeader>
                  <div className="flex justify-between items-start">
                    <div>
                      <CardTitle className="text-lg">{currentModule.title}</CardTitle>
                      <CardDescription>{currentModule.description}</CardDescription>
                    </div>
                    <Badge variant="outline">In Progress</Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div>
                      <div className="flex justify-between text-sm mb-2">
                        <span>Progress</span>
                        <span>{currentModule.progress}%</span>
                      </div>
                      <Progress value={currentModule.progress} className="h-2" />
                    </div>
                    <div className="flex items-center text-sm text-gray-600">
                      <Clock className="w-4 h-4 mr-2" />
                      {currentModule.timeLeft} remaining
                    </div>
                    <div className="flex gap-2">
                      <Button>Continue Learning</Button>
                      <Button variant="outline">View Syllabus</Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Learning Paths */}
            <h2 className="text-xl font-semibold mb-4">Available Learning Paths</h2>
            <div className="space-y-4">
              {learningPaths.map((path, index) => (
                <Card key={index}>
                  <CardHeader>
                    <div className="flex justify-between items-start">
                      <div>
                        <CardTitle className="text-lg">{path.title}</CardTitle>
                        <CardDescription>{path.description}</CardDescription>
                      </div>
                      <Badge 
                        variant={path.status === 'In Progress' ? 'default' : 
                                path.status === 'Started' ? 'secondary' : 'outline'}
                      >
                        {path.status}
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="grid grid-cols-3 gap-4 text-sm">
                        <div>
                          <span className="text-gray-600">Progress</span>
                          <div className="font-medium">{path.completedModules}/{path.totalModules} modules</div>
                        </div>
                        <div>
                          <span className="text-gray-600">Duration</span>
                          <div className="font-medium">{path.estimatedTime}</div>
                        </div>
                        <div>
                          <span className="text-gray-600">Level</span>
                          <div className="font-medium">{path.difficulty}</div>
                        </div>
                      </div>
                      
                      <div>
                        <div className="flex justify-between text-sm mb-2">
                          <span>Overall Progress</span>
                          <span>{path.progress}%</span>
                        </div>
                        <Progress value={path.progress} className="h-2" />
                      </div>

                      <div className="flex flex-wrap gap-1">
                        {path.skills.map((skill, i) => (
                          <Badge key={i} variant="outline" className="text-xs">
                            {skill}
                          </Badge>
                        ))}
                      </div>

                      <div className="flex gap-2">
                        <Button size="sm" disabled={path.status === 'Not Started'}>
                          {path.status === 'Not Started' ? 'Start Path' : 'Continue'}
                        </Button>
                        <Button size="sm" variant="outline">View Details</Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>

          {/* Achievements & Stats */}
          <div>
            <h2 className="text-xl font-semibold mb-4">Achievements</h2>
            <Card className="mb-6">
              <CardHeader>
                <CardTitle>Learning Stats</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-600">Completed Modules</span>
                    <span className="font-medium">12</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-600">Study Hours</span>
                    <span className="font-medium">48h</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-600">Current Streak</span>
                    <span className="font-medium">7 days</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-600">Average Score</span>
                    <span className="font-medium">87%</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Recent Achievements</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {achievements.map((achievement, index) => (
                    <div key={index} className="flex items-center space-x-3">
                      {achievement.completed ? (
                        <CheckCircle className="w-5 h-5 text-green-500" />
                      ) : (
                        <div className="w-5 h-5 border-2 border-gray-300 rounded-full flex items-center justify-center">
                          <div className="w-2 h-2 bg-gray-300 rounded-full"></div>
                        </div>
                      )}
                      <div className="flex-1">
                        <div className="text-sm font-medium">{achievement.title}</div>
                        {achievement.completed ? (
                          <div className="text-xs text-gray-500">{achievement.date}</div>
                        ) : (
                          <div className="text-xs text-gray-500">{achievement.progress}% complete</div>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </PlatformLayout>
  );
}