import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import PlatformLayout from "@/components/layout/platform-layout";
import { candidateNavigation } from "@/config/complete-navigation";
import { useLocation } from "wouter";
import { 
  BarChart3, 
  Users, 
  FileText, 
  TrendingUp, 
  Brain, 
  Award, 
  Briefcase, 
  Clock, 
  CheckCircle, 
  Target, 
  Star, 
  MapPin,
  Calendar,
  DollarSign,
  Send,
  Eye,
  ArrowRight,
  Play,
  BookOpen,
  Trophy,
  Zap,
  Filter,
  Heart,
  Building2,
  TrendingDown,
  Search,
  MessageSquare,
  User,
  PlusCircle
} from "lucide-react";

export default function CandidateDashboard() {
  const [, navigate] = useLocation();

  // Job Matching Data
  const jobMatchingScore = 92;
  const topJobMatches = [
    {
      id: 1,
      company: "TechCorp Solutions",
      position: "Senior Full Stack Developer",
      match: 95,
      salary: "₹15-25 LPA",
      location: "Bangalore",
      type: "Full-time",
      posted: "2 days ago",
      skills: ["React", "Node.js", "TypeScript"],
      companyLogo: "bg-blue-500"
    },
    {
      id: 2,
      company: "Innovation Labs",
      position: "Frontend Engineer",
      match: 89,
      salary: "₹12-20 LPA",
      location: "Mumbai",
      type: "Full-time", 
      posted: "1 day ago",
      skills: ["React", "Vue.js", "CSS"],
      companyLogo: "bg-green-500"
    },
    {
      id: 3,
      company: "StartupXYZ",
      position: "React Developer",
      match: 87,
      salary: "₹10-18 LPA",
      location: "Pune",
      type: "Remote",
      posted: "3 days ago",
      skills: ["React", "Redux", "Jest"],
      companyLogo: "bg-purple-500"
    }
  ];

  // Application Pipeline Data
  const applicationStats = [
    { stage: "Applied", count: 15, color: "bg-blue-500", icon: Send },
    { stage: "Screening", count: 8, color: "bg-yellow-500", icon: Eye },
    { stage: "Interview", count: 4, color: "bg-orange-500", icon: Users },
    { stage: "Offer", count: 2, color: "bg-green-500", icon: Trophy }
  ];

  // Skill Radar Chart Data
  const skillCategories = [
    { category: "Frontend", score: 88, color: "text-blue-600", bgColor: "bg-blue-500" },
    { category: "Backend", score: 72, color: "text-green-600", bgColor: "bg-green-500" },
    { category: "Database", score: 65, color: "text-purple-600", bgColor: "bg-purple-500" },
    { category: "DevOps", score: 45, color: "text-orange-600", bgColor: "bg-orange-500" },
    { category: "Mobile", score: 38, color: "text-pink-600", bgColor: "bg-pink-500" },
    { category: "Testing", score: 78, color: "text-indigo-600", bgColor: "bg-indigo-500" }
  ];

  // Certification Progress
  const certificationProgress = [
    { name: "React Developer", progress: 85, icon: "⚛️", color: "bg-blue-500" },
    { name: "AWS Solutions", progress: 60, icon: "☁️", color: "bg-orange-500" },
    { name: "Node.js Expert", progress: 45, icon: "🟢", color: "bg-green-500" }
  ];

  // Recent Activities
  const recentActivities = [
    {
      id: 1,
      type: "assessment",
      title: "JavaScript Advanced Test",
      description: "Scored 92% in JavaScript assessment",
      time: "2 hours ago",
      icon: Brain,
      color: "text-purple-600",
      bgColor: "bg-purple-100"
    },
    {
      id: 2,
      type: "application",
      title: "Applied to TechCorp",
      description: "Senior Full Stack Developer position",
      time: "1 day ago",
      icon: Send,
      color: "text-blue-600",
      bgColor: "bg-blue-100"
    },
    {
      id: 3,
      type: "interview",
      title: "Mock Interview Completed",
      description: "Technical interview simulation with AI",
      time: "2 days ago",
      icon: Users,
      color: "text-green-600",
      bgColor: "bg-green-100"
    }
  ];

  // Salary Analytics
  const salaryData = [
    { role: "Your Target", amount: 18, color: "bg-sky-500" },
    { role: "Market Average", amount: 15, color: "bg-gray-400" },
    { role: "Top 10%", amount: 25, color: "bg-green-500" }
  ];

  // Personalized Job Recommendations
  const recommendedJobs = [
    {
      id: 1,
      title: "Senior Frontend Developer",
      company: "TechFlow Solutions",
      logo: "🚀",
      location: "Bangalore",
      salary: "₹18-28 LPA",
      type: "Full-time",
      posted: "1 day ago",
      match: 94,
      skills: ["React", "TypeScript", "GraphQL"],
      benefits: ["Health Insurance", "Stock Options"]
    },
    {
      id: 2,
      title: "Full Stack Engineer",
      company: "InnovateLabs",
      logo: "💡",
      location: "Mumbai",
      salary: "₹15-22 LPA",
      type: "Remote",
      posted: "2 days ago",
      match: 89,
      skills: ["React", "Node.js", "AWS"],
      benefits: ["Remote Work", "Learning Budget"]
    },
    {
      id: 3,
      title: "React Developer",
      company: "CodeCraft Inc",
      logo: "⚡",
      location: "Pune",
      salary: "₹12-20 LPA",
      type: "Hybrid",
      posted: "3 days ago",
      match: 87,
      skills: ["React", "Redux", "Jest"],
      benefits: ["Flexible Hours", "Team Events"]
    }
  ];

  return (
    <PlatformLayout
      sidebarTitle="Candidate Platform"
      sidebarSubtitle="Your Career Dashboard"
      sidebarSections={candidateNavigation}
    >
      {/* Header Section */}
      <div className="bg-gradient-to-r from-sky-50 to-blue-50 p-6 rounded-lg mb-6">
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 mb-2">Welcome back, Alex!</h1>
            <p className="text-gray-600">Track your progress, discover opportunities, and advance your career</p>
          </div>
          
          <div className="mt-4 lg:mt-0 flex flex-col sm:flex-row gap-3">
            <Button 
              className="bg-sky-600 hover:bg-sky-700 text-white"
              onClick={() => navigate('/candidate/job-board')}
            >
              <PlusCircle className="w-4 h-4 mr-2" />
              New Application
            </Button>
            <Button 
              variant="outline" 
              className="border-gray-300 text-gray-600"
              onClick={() => navigate('/candidate/interview-communication')}
            >
              <Calendar className="w-4 h-4 mr-2" />
              Schedule Interview
            </Button>
          </div>
        </div>
      </div>

      {/* Stats Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
        <Card className="bg-white border-l-4 border-l-sky-500">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Active Applications</p>
                <p className="text-2xl font-bold text-gray-900">12</p>
                <p className="text-xs text-green-600 flex items-center mt-1">
                  <TrendingUp className="w-3 h-3 mr-1" />
                  +2 this week
                </p>
              </div>
              <div className="p-3 bg-sky-100 rounded-full">
                <Briefcase className="w-6 h-6 text-sky-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-white border-l-4 border-l-green-500">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Interview Rate</p>
                <p className="text-2xl font-bold text-gray-900">68%</p>
                <p className="text-xs text-green-600 flex items-center mt-1">
                  <TrendingUp className="w-3 h-3 mr-1" />
                  +5% from last month
                </p>
              </div>
              <div className="p-3 bg-green-100 rounded-full">
                <Users className="w-6 h-6 text-green-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-white border-l-4 border-l-purple-500">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Skills Score</p>
                <p className="text-2xl font-bold text-gray-900">94/100</p>
                <p className="text-xs text-green-600 flex items-center mt-1">
                  <Award className="w-3 h-3 mr-1" />
                  Top 10%
                </p>
              </div>
              <div className="p-3 bg-purple-100 rounded-full">
                <Target className="w-6 h-6 text-purple-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-white border-l-4 border-l-orange-500">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Profile Views</p>
                <p className="text-2xl font-bold text-gray-900">245</p>
                <p className="text-xs text-green-600 flex items-center mt-1">
                  <Eye className="w-3 h-3 mr-1" />
                  +12 today
                </p>
              </div>
              <div className="p-3 bg-orange-100 rounded-full">
                <BarChart3 className="w-6 h-6 text-orange-600" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Quick Actions */}
      <Card className="bg-white mb-6">
        <CardHeader>
          <CardTitle className="text-xl text-gray-800">Quick Actions</CardTitle>
          <CardDescription>Fast access to your most-used features</CardDescription>
        </CardHeader>
        <CardContent className="p-6 bg-white">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <Button 
              variant="outline" 
              className="flex flex-col items-center p-4 h-auto space-y-2 hover:bg-sky-50 hover:border-sky-300 group"
              onClick={() => navigate('/candidate/job-board')}
            >
              <div className="p-2 bg-sky-100 rounded-lg group-hover:bg-sky-200 transition-colors">
                <Search className="w-5 h-5 text-sky-600" />
              </div>
              <span className="text-sm font-medium text-gray-700 group-hover:text-sky-700">Find Jobs</span>
            </Button>
            
            <Button 
              variant="outline" 
              className="flex flex-col items-center p-4 h-auto space-y-2 hover:bg-green-50 hover:border-green-300 group"
              onClick={() => navigate('/candidate/skill-tests')}
            >
              <div className="p-2 bg-green-100 rounded-lg group-hover:bg-green-200 transition-colors">
                <FileText className="w-5 h-5 text-green-600" />
              </div>
              <span className="text-sm font-medium text-gray-700 group-hover:text-green-700">Take Test</span>
            </Button>
            
            <Button 
              variant="outline" 
              className="flex flex-col items-center p-4 h-auto space-y-2 hover:bg-purple-50 hover:border-purple-300 group"
              onClick={() => navigate('/candidate/ai-mock-interviews')}
            >
              <div className="p-2 bg-purple-100 rounded-lg group-hover:bg-purple-200 transition-colors">
                <MessageSquare className="w-5 h-5 text-purple-600" />
              </div>
              <span className="text-sm font-medium text-gray-700 group-hover:text-purple-700">Mock Interview</span>
            </Button>
            
            <Button 
              variant="outline" 
              className="flex flex-col items-center p-4 h-auto space-y-2 hover:bg-orange-50 hover:border-orange-300 group"
              onClick={() => navigate('/candidate/profile-builder')}
            >
              <div className="p-2 bg-orange-100 rounded-lg group-hover:bg-orange-200 transition-colors">
                <User className="w-5 h-5 text-orange-600" />
              </div>
              <span className="text-sm font-medium text-gray-700 group-hover:text-orange-700">Edit Profile</span>
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Main Content - Three Column Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 mb-6">
        {/* Left Column - Progress & Skills */}
        <div className="lg:col-span-4 space-y-6">
          {/* Progress Overview */}
          <Card className="bg-white">
            <CardHeader>
              <CardTitle className="text-xl text-gray-800">Your Progress</CardTitle>
              <CardDescription>Track your journey</CardDescription>
            </CardHeader>
            <CardContent className="p-6 bg-white">
              <div className="space-y-4">
                <div className="space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="font-medium text-gray-700">Profile Completion</span>
                    <span className="text-sm text-gray-600">85%</span>
                  </div>
                  <Progress value={85} className="h-2" />
                </div>
                
                <div className="space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="font-medium text-gray-700">Skill Assessment</span>
                    <span className="text-sm text-gray-600">70%</span>
                  </div>
                  <Progress value={70} className="h-2" />
                </div>
                
                <div className="space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="font-medium text-gray-700">Interview Prep</span>
                    <span className="text-sm text-gray-600">67%</span>
                  </div>
                  <Progress value={67} className="h-2" />
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Skills Assessment */}
          <Card className="bg-white">
            <CardHeader>
              <CardTitle className="text-lg text-gray-800">Skill Categories</CardTitle>
              <CardDescription>Your technical proficiency</CardDescription>
            </CardHeader>
            <CardContent className="p-6 bg-white">
              <div className="space-y-4">
                {skillCategories.map((skill, index) => (
                  <div key={index} className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <div className={`w-3 h-3 ${skill.bgColor} rounded-full`}></div>
                      <span className="text-sm font-medium text-gray-700">{skill.category}</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <div className={`h-2 ${skill.bgColor} rounded`} style={{width: `${skill.score}px`}}></div>
                      <span className="text-sm font-bold text-gray-900 min-w-[40px]">{skill.score}%</span>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Middle Column - Jobs & Applications */}
        <div className="lg:col-span-5 space-y-6">
          {/* Top Job Matches */}
          <Card className="bg-white">
            <CardHeader>
              <CardTitle className="text-xl text-gray-800">Top Job Matches</CardTitle>
              <CardDescription>Jobs tailored to your profile</CardDescription>
            </CardHeader>
            <CardContent className="p-6 bg-white">
              <div className="space-y-4">
                {topJobMatches.map((job, index) => (
                  <div 
                    key={job.id} 
                    className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow cursor-pointer"
                    onClick={() => navigate('/candidate/job-board')}
                  >
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex items-center space-x-3">
                        <div className={`w-10 h-10 ${job.companyLogo} rounded-lg flex items-center justify-center text-white font-bold`}>
                          {job.company.charAt(0)}
                        </div>
                        <div>
                          <h4 className="font-semibold text-gray-900">{job.position}</h4>
                          <p className="text-sm text-gray-600">{job.company}</p>
                        </div>
                      </div>
                      <Badge variant="secondary" className="bg-green-100 text-green-800">
                        {job.match}% match
                      </Badge>
                    </div>
                    
                    <div className="flex items-center text-sm text-gray-600 mb-3">
                      <MapPin className="w-4 h-4 mr-1" />
                      {job.location}
                      <span className="mx-2">•</span>
                      <DollarSign className="w-4 h-4 mr-1" />
                      {job.salary}
                    </div>

                    <div className="flex gap-1 mb-3">
                      {job.skills.map((skill, skillIndex) => (
                        <Badge key={skillIndex} variant="outline" className="text-xs">
                          {skill}
                        </Badge>
                      ))}
                    </div>

                    <div className="flex space-x-2">
                      <Button 
                        size="sm" 
                        className="flex-1 bg-sky-600 hover:bg-sky-700"
                        onClick={() => navigate('/candidate/application-tracker')}
                      >
                        Apply Now
                      </Button>
                      <Button 
                        size="sm" 
                        variant="outline"
                        onClick={() => navigate('/candidate/saved-jobs')}
                      >
                        <Heart className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Application Pipeline */}
          <Card className="bg-white">
            <CardHeader>
              <CardTitle className="text-xl text-gray-800">Application Pipeline</CardTitle>
              <CardDescription>Track your application status</CardDescription>
            </CardHeader>
            <CardContent className="p-6 bg-white">
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {applicationStats.map((stat, index) => {
                  const IconComponent = stat.icon;
                  return (
                    <div key={index} className="text-center">
                      <div className={`w-12 h-12 ${stat.color} rounded-full flex items-center justify-center mx-auto mb-2`}>
                        <IconComponent className="w-6 h-6 text-white" />
                      </div>
                      <div className="text-2xl font-bold text-gray-900">{stat.count}</div>
                      <div className="text-sm text-gray-600">{stat.stage}</div>
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Right Column - Activities & Certifications */}
        <div className="lg:col-span-3 space-y-6">
          {/* Recent Activities */}
          <Card className="bg-white">
            <CardHeader>
              <CardTitle className="text-lg text-gray-800">Recent Activity</CardTitle>
              <CardDescription>Your latest actions</CardDescription>
            </CardHeader>
            <CardContent className="p-6 bg-white">
              <div className="space-y-4">
                {recentActivities.map((activity) => {
                  const IconComponent = activity.icon;
                  return (
                    <div 
                      key={activity.id} 
                      className="flex items-start space-x-3 p-2 rounded-lg hover:bg-gray-50 cursor-pointer transition-colors"
                      onClick={() => {
                        if (activity.type === 'assessment') {
                          navigate('/candidate/skill-tests');
                        } else if (activity.type === 'application') {
                          navigate('/candidate/application-tracker');
                        } else if (activity.type === 'interview') {
                          navigate('/candidate/ai-mock-interviews');
                        }
                      }}
                    >
                      <div className={`p-2 ${activity.bgColor} rounded-lg`}>
                        <IconComponent className={`w-4 h-4 ${activity.color}`} />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium text-gray-900">{activity.title}</p>
                        <p className="text-xs text-gray-600">{activity.description}</p>
                        <p className="text-xs text-gray-500 mt-1">{activity.time}</p>
                      </div>
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>

          {/* Certification Progress */}
          <Card className="bg-white">
            <CardHeader>
              <CardTitle className="text-lg text-gray-800">Certifications</CardTitle>
              <CardDescription>Your progress</CardDescription>
            </CardHeader>
            <CardContent className="p-6 bg-white">
              <div className="space-y-4">
                {certificationProgress.map((cert, index) => (
                  <div key={index} className="space-y-2">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        <span className="text-lg">{cert.icon}</span>
                        <span className="text-sm font-medium text-gray-700">{cert.name}</span>
                      </div>
                      <span className="text-xs text-gray-600">{cert.progress}%</span>
                    </div>
                    <Progress value={cert.progress} className="h-2" />
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Bottom Section - Salary Analytics & Recommendations */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Salary Analytics - 2 columns */}
        <Card className="bg-white lg:col-span-2">
          <CardHeader>
            <CardTitle className="text-xl text-gray-800">Salary Analytics</CardTitle>
            <CardDescription>Compare your target with market rates</CardDescription>
          </CardHeader>
          <CardContent className="bg-white">
            <div className="space-y-4">
              {salaryData.map((item, index) => (
                <div key={index} className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <div className={`w-4 h-4 ${item.color} rounded`}></div>
                    <span className="font-medium text-gray-700">{item.role}</span>
                  </div>
                  <div className="flex items-center space-x-4">
                    <div className={`h-8 ${item.color} rounded`} style={{width: `${(item.amount / 25) * 200}px`}}></div>
                    <span className="font-bold text-gray-900 min-w-[60px]">₹{item.amount}L</span>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Recommended Jobs - 1 column */}
        <Card className="bg-white">
          <CardHeader>
            <CardTitle className="text-xl text-gray-800">Recommended for You</CardTitle>
            <CardDescription>Top job matches</CardDescription>
          </CardHeader>
          <CardContent className="p-6 bg-white">
            <div className="space-y-4">
              {recommendedJobs.slice(0, 3).map((job) => (
                <div key={job.id} className="border border-gray-200 rounded-lg p-3 hover:shadow-md transition-shadow cursor-pointer group">
                  <div className="flex items-start justify-between mb-2">
                    <div className="flex items-center space-x-2">
                      <div className="w-8 h-8 bg-gray-100 rounded-lg flex items-center justify-center text-sm">
                        {job.logo}
                      </div>
                      <div>
                        <h4 className="font-semibold text-gray-900 group-hover:text-sky-600 transition-colors text-sm">{job.title}</h4>
                        <p className="text-xs text-gray-600">{job.company}</p>
                      </div>
                    </div>
                    <div className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${
                      job.match >= 90 ? 'bg-green-100 text-green-800' :
                      job.match >= 85 ? 'bg-blue-100 text-blue-800' :
                      'bg-yellow-100 text-yellow-800'
                    }`}>
                      {job.match}%
                    </div>
                  </div>
                  
                  <div className="text-xs text-gray-600 mb-2 space-y-1">
                    <div className="flex items-center">
                      <MapPin className="w-3 h-3 mr-1" />
                      {job.location}
                    </div>
                    <div className="flex items-center font-medium text-green-600">
                      <DollarSign className="w-3 h-3 mr-1" />
                      {job.salary}
                    </div>
                  </div>

                  <div className="flex gap-1 mb-2">
                    <Button 
                      size="sm" 
                      className="flex-1 bg-sky-600 hover:bg-sky-700 text-xs"
                      onClick={() => navigate('/candidate/application-tracker')}
                    >
                      Apply
                    </Button>
                    <Button 
                      size="sm" 
                      variant="outline" 
                      className="px-2"
                      onClick={() => navigate('/candidate/saved-jobs')}
                    >
                      <Heart className="w-3 h-3" />
                    </Button>
                  </div>
                </div>
              ))}
              <div className="mt-4 flex justify-center">
                <Button 
                  variant="outline" 
                  size="sm" 
                  className="text-gray-600 border-gray-300 text-xs"
                  onClick={() => navigate('/candidate/job-board')}
                >
                  <Eye className="w-3 h-3 mr-1" />
                  View All
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </PlatformLayout>
  );
}