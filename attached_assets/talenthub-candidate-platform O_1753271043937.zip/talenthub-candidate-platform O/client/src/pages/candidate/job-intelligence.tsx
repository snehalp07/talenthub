import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import PlatformLayout from "@/components/layout/platform-layout";
import { candidateNavigation } from "@/config/complete-navigation";
import { 
  Target, Briefcase, TrendingUp, MapPin, DollarSign,
  Calendar, Clock, Users, Star, CheckCircle,
  ArrowUp, ArrowDown, BarChart3, PieChart,
  Zap, AlertTriangle, Award, Globe, Filter
} from "lucide-react";

const JobIntelligence: React.FC = () => {
  const [timeRange, setTimeRange] = useState('30d');
  
  const applicationMetrics = {
    totalApplications: { value: 47, change: +12, trend: 'up' },
    responseRate: { value: 68, change: +15, trend: 'up' },
    interviewRate: { value: 34, change: +8, trend: 'up' },
    offerRate: { value: 23, change: +5, trend: 'up' }
  };

  const jobMatchData = [
    { company: 'Google', role: 'Senior React Developer', match: 94, salary: '$165k', status: 'applied', color: 'from-emerald-400 to-emerald-600' },
    { company: 'Microsoft', role: 'Full-Stack Engineer', match: 91, salary: '$155k', status: 'interviewing', color: 'from-blue-400 to-blue-600' },
    { company: 'Meta', role: 'Frontend Lead', match: 89, salary: '$170k', status: 'reviewing', color: 'from-purple-400 to-purple-600' },
    { company: 'Netflix', role: 'Software Engineer', match: 87, salary: '$160k', status: 'shortlisted', color: 'from-orange-400 to-orange-600' },
    { company: 'Amazon', role: 'Web Developer', match: 85, salary: '$145k', status: 'new', color: 'from-cyan-400 to-cyan-600' }
  ];

  const marketInsights = {
    demandTrends: [
      { skill: 'React.js', demand: 95, growth: '+18%', openings: 2847 },
      { skill: 'TypeScript', demand: 89, growth: '+25%', openings: 1923 },
      { skill: 'Node.js', demand: 87, growth: '+12%', openings: 2134 },
      { skill: 'Python', demand: 83, growth: '+22%', openings: 3456 },
      { skill: 'AWS', demand: 78, growth: '+35%', openings: 1567 }
    ],
    salaryRanges: {
      'Junior (0-2 years)': { min: 85, max: 120, avg: 102 },
      'Mid-level (3-5 years)': { min: 120, max: 165, avg: 142 },
      'Senior (6-8 years)': { min: 155, max: 210, avg: 182 },
      'Principal (9+ years)': { min: 200, max: 280, avg: 240 }
    }
  };

  const applicationAnalysis = [
    { stage: 'Applications Sent', count: 47, conversion: 100, color: 'bg-blue-500' },
    { stage: 'Initial Response', count: 32, conversion: 68, color: 'bg-emerald-500' },
    { stage: 'Phone Screening', count: 24, conversion: 51, color: 'bg-purple-500' },
    { stage: 'Technical Interview', count: 16, conversion: 34, color: 'bg-orange-500' },
    { stage: 'Final Interview', count: 11, conversion: 23, color: 'bg-cyan-500' },
    { stage: 'Offers Received', count: 7, conversion: 15, color: 'bg-emerald-600' }
  ];

  const competitiveAnalysis = [
    { metric: 'Profile Strength', yourScore: 92, market: 78, advantage: '+14' },
    { metric: 'Skill Relevance', yourScore: 89, market: 72, advantage: '+17' },
    { metric: 'Experience Level', yourScore: 85, market: 68, advantage: '+17' },
    { metric: 'Portfolio Quality', yourScore: 91, market: 65, advantage: '+26' },
    { metric: 'Certification Level', yourScore: 87, market: 58, advantage: '+29' }
  ];

  return (
    <PlatformLayout 
      sidebarTitle="Candidate Platform"
      sidebarSubtitle="Professional Development Hub"
      sidebarSections={candidateNavigation}
    >
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-orange-50 to-red-50 p-6">
        {/* Header Section */}
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-2">
            <div className="p-2 bg-gradient-to-br from-orange-500 to-red-600 rounded-lg text-white">
              <Target className="h-6 w-6" />
            </div>
            <h1 className="text-3xl font-bold bg-gradient-to-r from-orange-600 to-red-600 bg-clip-text text-transparent">
              Job Search Intelligence
            </h1>
          </div>
          <p className="text-gray-600 text-lg">
            Strategic insights into your job search performance and market opportunities
          </p>
        </div>

        {/* Time Range Selector */}
        <div className="flex gap-2 mb-6">
          {['7d', '30d', '90d', '1y'].map((period) => (
            <Button
              key={period}
              variant={timeRange === period ? "default" : "outline"}
              size="sm"
              onClick={() => setTimeRange(period)}
              className={timeRange === period ? "bg-gradient-to-r from-orange-500 to-red-600" : ""}
            >
              {period === '7d' ? '7 Days' : period === '30d' ? '30 Days' : period === '90d' ? '90 Days' : '1 Year'}
            </Button>
          ))}
        </div>

        {/* Key Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {Object.entries(applicationMetrics).map(([key, metric], index) => {
            const icons = [Briefcase, Users, CheckCircle, Award];
            const IconComponent = icons[index];
            const colors = ['from-orange-500 to-orange-600', 'from-blue-500 to-blue-600', 'from-emerald-500 to-emerald-600', 'from-purple-500 to-purple-600'];
            
            return (
              <Card key={key} className="border-0 shadow-lg bg-white/80 backdrop-blur-sm">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between mb-4">
                    <div className={`p-3 bg-gradient-to-br ${colors[index]} rounded-lg text-white`}>
                      <IconComponent className="h-6 w-6" />
                    </div>
                    <div className={`flex items-center gap-1 px-2 py-1 rounded-full text-sm ${
                      metric.trend === 'up' ? 'bg-emerald-100 text-emerald-700' : 'bg-red-100 text-red-700'
                    }`}>
                      {metric.trend === 'up' ? <ArrowUp className="h-3 w-3" /> : <ArrowDown className="h-3 w-3" />}
                      {metric.change}
                    </div>
                  </div>
                  <div className="text-2xl font-bold text-gray-900 mb-1">
                    {key.includes('Rate') ? `${metric.value}%` : metric.value}
                  </div>
                  <div className="text-sm text-gray-600 capitalize">
                    {key.replace(/([A-Z])/g, ' $1').toLowerCase()}
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>

        <Tabs defaultValue="matching" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4 bg-white/80 backdrop-blur-sm">
            <TabsTrigger value="matching">Job Matching</TabsTrigger>
            <TabsTrigger value="funnel">Application Funnel</TabsTrigger>
            <TabsTrigger value="market">Market Analysis</TabsTrigger>
            <TabsTrigger value="competitive">Competitive Edge</TabsTrigger>
          </TabsList>

          <TabsContent value="matching" className="space-y-6">
            <Card className="border-0 shadow-lg bg-white/80 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Star className="h-5 w-5 text-orange-500" />
                  AI-Powered Job Matching
                </CardTitle>
                <CardDescription>
                  Intelligent job recommendations based on your skills and career goals
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  {jobMatchData.map((job, index) => (
                    <div key={index} className="p-6 bg-gradient-to-br from-gray-50 to-gray-100 rounded-lg">
                      <div className="flex items-start justify-between mb-4">
                        <div className="flex-1">
                          <div className="flex items-center gap-3 mb-2">
                            <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-purple-600 rounded-lg flex items-center justify-center text-white font-bold">
                              {job.company.charAt(0)}
                            </div>
                            <div>
                              <div className="font-semibold text-gray-900 text-lg">{job.role}</div>
                              <div className="text-gray-600">{job.company}</div>
                            </div>
                          </div>
                          <div className="flex items-center gap-4 mb-3">
                            <div className="flex items-center gap-2">
                              <DollarSign className="h-4 w-4 text-emerald-600" />
                              <span className="font-semibold text-emerald-600">{job.salary}</span>
                            </div>
                            <Badge className={`${
                              job.status === 'applied' ? 'bg-blue-600' :
                              job.status === 'interviewing' ? 'bg-purple-600' :
                              job.status === 'reviewing' ? 'bg-orange-600' :
                              job.status === 'shortlisted' ? 'bg-emerald-600' : 'bg-gray-600'
                            } text-white`}>
                              {job.status}
                            </Badge>
                          </div>
                        </div>
                        <div className="text-right">
                          <div className="text-2xl font-bold text-gray-900">{job.match}%</div>
                          <div className="text-sm text-gray-600">Match Score</div>
                        </div>
                      </div>
                      
                      <div className="mb-4">
                        <div className="flex items-center justify-between mb-2">
                          <span className="text-sm font-medium text-gray-700">Compatibility</span>
                          <span className="text-sm text-gray-600">{job.match}%</span>
                        </div>
                        <Progress value={job.match} className="h-3 bg-gray-200">
                          <div className={`h-full bg-gradient-to-r ${job.color} rounded-full transition-all duration-500`} 
                               style={{ width: `${job.match}%` }} />
                        </Progress>
                      </div>
                      
                      <div className="flex gap-2">
                        <Button size="sm" className="bg-gradient-to-r from-orange-500 to-red-600">
                          View Details
                        </Button>
                        <Button size="sm" variant="outline">
                          Save Job
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="funnel" className="space-y-6">
            <Card className="border-0 shadow-lg bg-white/80 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <BarChart3 className="h-5 w-5 text-blue-500" />
                  Application Funnel Analysis
                </CardTitle>
                <CardDescription>
                  Track your application journey from submission to offer
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  {applicationAnalysis.map((stage, index) => (
                    <div key={index} className="space-y-3">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <div className={`w-4 h-4 rounded-full ${stage.color}`} />
                          <span className="font-semibold text-gray-900">{stage.stage}</span>
                        </div>
                        <div className="flex items-center gap-4">
                          <span className="text-lg font-bold text-gray-900">{stage.count}</span>
                          <span className="text-sm text-gray-600">{stage.conversion}%</span>
                        </div>
                      </div>
                      <div className="flex items-center gap-3">
                        <Progress value={stage.conversion} className="flex-1 h-3 bg-gray-200">
                          <div className={`h-full ${stage.color} rounded-full transition-all duration-500`} 
                               style={{ width: `${stage.conversion}%` }} />
                        </Progress>
                        <span className="text-sm text-gray-600 min-w-[80px]">
                          {index > 0 ? `${Math.round((stage.count / applicationAnalysis[index - 1].count) * 100)}% conversion` : ''}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>

                <div className="mt-8 p-6 bg-gradient-to-r from-blue-50 to-indigo-100 rounded-lg">
                  <div className="font-semibold text-blue-900 mb-4">Funnel Performance Insights</div>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="text-center p-4 bg-white rounded-lg">
                      <div className="text-2xl font-bold text-blue-600 mb-1">68%</div>
                      <div className="text-sm text-blue-700">Response Rate</div>
                      <div className="text-xs text-gray-600">Above average</div>
                    </div>
                    <div className="text-center p-4 bg-white rounded-lg">
                      <div className="text-2xl font-bold text-emerald-600 mb-1">34%</div>
                      <div className="text-sm text-emerald-700">Interview Rate</div>
                      <div className="text-xs text-gray-600">Excellent</div>
                    </div>
                    <div className="text-center p-4 bg-white rounded-lg">
                      <div className="text-2xl font-bold text-purple-600 mb-1">15%</div>
                      <div className="text-sm text-purple-700">Offer Rate</div>
                      <div className="text-xs text-gray-600">Strong performance</div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="market" className="space-y-6">
            <Card className="border-0 shadow-lg bg-white/80 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Globe className="h-5 w-5 text-emerald-500" />
                  Market Demand & Salary Intelligence
                </CardTitle>
                <CardDescription>
                  Real-time market insights for your skills and experience level
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-8">
                  {/* Skill Demand Trends */}
                  <div>
                    <div className="font-semibold text-gray-900 mb-4">Skill Demand Trends</div>
                    <div className="space-y-4">
                      {marketInsights.demandTrends.map((skill, index) => (
                        <div key={index} className="p-4 bg-gradient-to-r from-gray-50 to-gray-100 rounded-lg">
                          <div className="flex items-center justify-between mb-3">
                            <div className="flex items-center gap-3">
                              <span className="font-semibold text-gray-900">{skill.skill}</span>
                              <Badge variant="outline" className="text-emerald-600 border-emerald-200">
                                {skill.growth} growth
                              </Badge>
                            </div>
                            <div className="text-right">
                              <div className="font-bold text-gray-900">{skill.openings.toLocaleString()}</div>
                              <div className="text-xs text-gray-600">open positions</div>
                            </div>
                          </div>
                          <Progress value={skill.demand} className="h-2 bg-gray-200">
                            <div className="h-full bg-gradient-to-r from-emerald-400 to-emerald-600 rounded-full transition-all duration-500" 
                                 style={{ width: `${skill.demand}%` }} />
                          </Progress>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Salary Ranges */}
                  <div>
                    <div className="font-semibold text-gray-900 mb-4">Market Salary Ranges (Annual)</div>
                    <div className="space-y-4">
                      {Object.entries(marketInsights.salaryRanges).map(([level, range], index) => (
                        <div key={index} className="p-4 bg-gradient-to-r from-blue-50 to-indigo-100 rounded-lg">
                          <div className="flex items-center justify-between mb-3">
                            <span className="font-semibold text-blue-900">{level}</span>
                            <span className="text-lg font-bold text-blue-600">${range.avg}k avg</span>
                          </div>
                          <div className="flex items-center gap-4 text-sm text-blue-700">
                            <span>Min: ${range.min}k</span>
                            <span>Max: ${range.max}k</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="competitive" className="space-y-6">
            <Card className="border-0 shadow-lg bg-white/80 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Zap className="h-5 w-5 text-purple-500" />
                  Competitive Advantage Analysis
                </CardTitle>
                <CardDescription>
                  How you stack up against other candidates in the market
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  {competitiveAnalysis.map((item, index) => (
                    <div key={index} className="p-6 bg-gradient-to-br from-gray-50 to-gray-100 rounded-lg">
                      <div className="flex items-center justify-between mb-4">
                        <span className="font-semibold text-gray-900">{item.metric}</span>
                        <div className="flex items-center gap-4">
                          <div className="text-right">
                            <div className="text-sm text-gray-600">You</div>
                            <div className="text-lg font-bold text-purple-600">{item.yourScore}</div>
                          </div>
                          <div className="text-right">
                            <div className="text-sm text-gray-600">Market Avg</div>
                            <div className="text-lg font-bold text-gray-500">{item.market}</div>
                          </div>
                          <div className="text-right">
                            <div className="text-sm text-emerald-600">Advantage</div>
                            <div className="text-lg font-bold text-emerald-600">{item.advantage}</div>
                          </div>
                        </div>
                      </div>
                      
                      <div className="space-y-2">
                        <div className="flex items-center gap-2">
                          <span className="text-xs text-purple-600 w-12">You</span>
                          <Progress value={item.yourScore} className="flex-1 h-2 bg-gray-200">
                            <div className="h-full bg-gradient-to-r from-purple-400 to-purple-600 rounded-full transition-all duration-500" 
                                 style={{ width: `${item.yourScore}%` }} />
                          </Progress>
                        </div>
                        <div className="flex items-center gap-2">
                          <span className="text-xs text-gray-500 w-12">Market</span>
                          <Progress value={item.market} className="flex-1 h-2 bg-gray-200">
                            <div className="h-full bg-gray-400 rounded-full transition-all duration-500" 
                                 style={{ width: `${item.market}%` }} />
                          </Progress>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>

                <div className="mt-8 p-6 bg-gradient-to-r from-emerald-50 to-green-100 rounded-lg">
                  <div className="flex items-center gap-3 mb-4">
                    <Award className="h-6 w-6 text-emerald-600" />
                    <div className="font-semibold text-emerald-900">Competitive Summary</div>
                  </div>
                  <div className="text-emerald-800 mb-4">
                    You consistently outperform market averages across all key metrics. Your portfolio quality 
                    (+26 points) and certification level (+29 points) are particularly strong differentiators.
                  </div>
                  <div className="flex gap-2">
                    <Badge className="bg-emerald-600 text-white">Top 15% Candidate</Badge>
                    <Badge variant="outline" className="text-emerald-600 border-emerald-300">Strong positioning</Badge>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </PlatformLayout>
  );
};

export default JobIntelligence;