import PlatformLayout from "@/components/layout/platform-layout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { Award, Search, Filter, Star, Clock, Users, CheckCircle, ArrowRight, Target, Trophy, Code, Globe, Database, Smartphone } from "lucide-react";
import { platformConfigs } from "@/config/complete-navigation";

export default function CertificationTracks() {
  const config = platformConfigs.candidate;

  const certificationTracks = [
    {
      id: 1,
      name: "Frontend Developer Certification",
      description: "Master modern frontend development with React, TypeScript, and advanced UI/UX patterns",
      level: "Intermediate to Advanced",
      duration: "12-16 weeks",
      projects: 8,
      skills: ["React", "TypeScript", "CSS/Sass", "JavaScript", "UI/UX Design"],
      prerequisites: ["Basic HTML/CSS", "JavaScript Fundamentals"],
      completionRate: 85,
      enrolledCount: 2341,
      rating: 4.8,
      color: "from-blue-500 to-indigo-500",
      icon: Globe,
      status: "available"
    },
    {
      id: 2,
      name: "Backend Developer Certification",
      description: "Build scalable server-side applications with Node.js, databases, and cloud deployment",
      level: "Beginner to Advanced",
      duration: "14-18 weeks",
      projects: 10,
      skills: ["Node.js", "Express", "MongoDB", "PostgreSQL", "AWS/Cloud"],
      prerequisites: ["JavaScript Basics", "Programming Fundamentals"],
      completionRate: 78,
      enrolledCount: 1897,
      rating: 4.7,
      color: "from-green-500 to-emerald-500",
      icon: Database,
      status: "available"
    },
    {
      id: 3,
      name: "Full-Stack Developer Certification",
      description: "Complete web development mastery combining frontend and backend technologies",
      level: "Advanced",
      duration: "20-24 weeks",
      projects: 15,
      skills: ["React", "Node.js", "Databases", "DevOps", "System Design"],
      prerequisites: ["Frontend Certification", "Backend Experience"],
      completionRate: 72,
      enrolledCount: 1456,
      rating: 4.9,
      color: "from-purple-500 to-pink-500",
      icon: Code,
      status: "available"
    },
    {
      id: 4,
      name: "Mobile App Developer Certification",
      description: "Create cross-platform mobile applications with React Native and Flutter",
      level: "Intermediate",
      duration: "16-20 weeks",
      projects: 12,
      skills: ["React Native", "Flutter", "Mobile UI/UX", "App Store Deployment"],
      prerequisites: ["JavaScript/Dart", "Mobile Development Basics"],
      completionRate: 81,
      enrolledCount: 1203,
      rating: 4.6,
      color: "from-orange-500 to-red-500",
      icon: Smartphone,
      status: "available"
    },
    {
      id: 5,
      name: "DevOps Engineer Certification",
      description: "Master infrastructure automation, CI/CD, and cloud deployment strategies",
      level: "Advanced",
      duration: "18-22 weeks",
      projects: 14,
      skills: ["Docker", "Kubernetes", "AWS", "CI/CD", "Infrastructure as Code"],
      prerequisites: ["Linux Basics", "Programming Experience", "Cloud Fundamentals"],
      completionRate: 69,
      enrolledCount: 892,
      rating: 4.8,
      color: "from-cyan-500 to-blue-500",
      icon: Target,
      status: "coming-soon"
    },
    {
      id: 6,
      name: "AI/ML Engineer Certification",
      description: "Build intelligent applications with machine learning and deep learning frameworks",
      level: "Advanced",
      duration: "22-26 weeks",
      projects: 16,
      skills: ["Python", "TensorFlow", "PyTorch", "Data Science", "Model Deployment"],
      prerequisites: ["Python Programming", "Statistics", "Linear Algebra"],
      completionRate: 65,
      enrolledCount: 734,
      rating: 4.9,
      color: "from-yellow-500 to-orange-500",
      icon: Trophy,
      status: "coming-soon"
    }
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case "available": return "bg-green-100 text-green-800 border-green-200";
      case "coming-soon": return "bg-blue-100 text-blue-800 border-blue-200";
      case "enrolled": return "bg-purple-100 text-purple-800 border-purple-200";
      default: return "bg-gray-100 text-gray-800 border-gray-200";
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case "available": return "Available";
      case "coming-soon": return "Coming Soon";
      case "enrolled": return "Enrolled";
      default: return "Unknown";
    }
  };

  return (
    <PlatformLayout
      sidebarTitle={config.sidebarTitle}
      sidebarSubtitle={config.sidebarSubtitle}
      sidebarSections={config.sidebarSections}
      usageData={config.usageData}
    >
      <div className="p-6 max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="text-center space-y-4">
          <div className="flex items-center justify-center space-x-3">
            <div className="p-3 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full">
              <Award className="h-8 w-8 text-white" />
            </div>
            <h1 className="text-4xl font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
              Certification Tracks
            </h1>
          </div>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Earn industry-recognized certifications through structured learning paths with hands-on projects and expert mentorship
          </p>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card className="bg-gradient-to-r from-purple-50 to-pink-50 border-purple-200">
            <CardContent className="p-4 text-center">
              <Award className="h-8 w-8 text-purple-500 mx-auto mb-2" />
              <p className="text-2xl font-bold text-purple-600">6</p>
              <p className="text-sm text-muted-foreground">Certification Tracks</p>
            </CardContent>
          </Card>
          <Card className="bg-gradient-to-r from-blue-50 to-indigo-50 border-blue-200">
            <CardContent className="p-4 text-center">
              <Users className="h-8 w-8 text-blue-500 mx-auto mb-2" />
              <p className="text-2xl font-bold text-blue-600">8.5K</p>
              <p className="text-sm text-muted-foreground">Total Enrolled</p>
            </CardContent>
          </Card>
          <Card className="bg-gradient-to-r from-green-50 to-emerald-50 border-green-200">
            <CardContent className="p-4 text-center">
              <CheckCircle className="h-8 w-8 text-green-500 mx-auto mb-2" />
              <p className="text-2xl font-bold text-green-600">75%</p>
              <p className="text-sm text-muted-foreground">Avg. Completion Rate</p>
            </CardContent>
          </Card>
          <Card className="bg-gradient-to-r from-orange-50 to-red-50 border-orange-200">
            <CardContent className="p-4 text-center">
              <Star className="h-8 w-8 text-orange-500 mx-auto mb-2" />
              <p className="text-2xl font-bold text-orange-600">4.8</p>
              <p className="text-sm text-muted-foreground">Avg. Rating</p>
            </CardContent>
          </Card>
        </div>

        {/* Search and Filters */}
        <div className="flex flex-col sm:flex-row gap-4 items-center justify-between">
          <div className="flex items-center space-x-2 flex-1">
            <div className="relative flex-1 max-w-md">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
              <Input
                placeholder="Search certification tracks..."
                className="pl-10"
              />
            </div>
          </div>
          <div className="flex items-center space-x-2">
            <Select defaultValue="all">
              <SelectTrigger className="w-40">
                <SelectValue placeholder="Level" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Levels</SelectItem>
                <SelectItem value="beginner">Beginner</SelectItem>
                <SelectItem value="intermediate">Intermediate</SelectItem>
                <SelectItem value="advanced">Advanced</SelectItem>
              </SelectContent>
            </Select>
            <Select defaultValue="all">
              <SelectTrigger className="w-40">
                <SelectValue placeholder="Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="available">Available</SelectItem>
                <SelectItem value="coming-soon">Coming Soon</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <Tabs defaultValue="tracks" className="space-y-6">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="tracks">Certification Tracks</TabsTrigger>
            <TabsTrigger value="progress">My Progress</TabsTrigger>
            <TabsTrigger value="certificates">Earned Certificates</TabsTrigger>
          </TabsList>

          <TabsContent value="tracks" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {certificationTracks.map((track) => {
                const IconComponent = track.icon;
                return (
                  <Card key={track.id} className="group hover:shadow-lg transition-all duration-300 hover:-translate-y-1 border-l-4 border-l-purple-500">
                    <CardHeader className="pb-3">
                      <div className="flex items-start justify-between">
                        <div className={`p-2 bg-gradient-to-r ${track.color} rounded-lg`}>
                          <IconComponent className="h-6 w-6 text-white" />
                        </div>
                        <Badge className={getStatusColor(track.status)}>
                          {getStatusText(track.status)}
                        </Badge>
                      </div>
                      <CardTitle className="text-xl">{track.name}</CardTitle>
                      <CardDescription>{track.description}</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="grid grid-cols-2 gap-4 text-sm text-muted-foreground">
                        <div className="flex items-center gap-1">
                          <Clock className="h-4 w-4" />
                          <span>{track.duration}</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <Target className="h-4 w-4" />
                          <span>{track.projects} Projects</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <Users className="h-4 w-4" />
                          <span>{track.enrolledCount.toLocaleString()} Enrolled</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <Star className="h-4 w-4 text-yellow-500" />
                          <span>{track.rating} Rating</span>
                        </div>
                      </div>

                      <div className="space-y-2">
                        <div className="flex justify-between text-sm">
                          <span className="text-muted-foreground">Completion Rate</span>
                          <span className="font-medium">{track.completionRate}%</span>
                        </div>
                        <Progress value={track.completionRate} className="h-2" />
                      </div>

                      <div className="space-y-3">
                        <div>
                          <h4 className="text-sm font-medium mb-2">Key Skills</h4>
                          <div className="flex flex-wrap gap-1">
                            {track.skills.slice(0, 4).map((skill, index) => (
                              <Badge key={index} variant="outline" className="text-xs">
                                {skill}
                              </Badge>
                            ))}
                            {track.skills.length > 4 && (
                              <Badge variant="outline" className="text-xs">
                                +{track.skills.length - 4}
                              </Badge>
                            )}
                          </div>
                        </div>

                        <div>
                          <h4 className="text-sm font-medium mb-2">Prerequisites</h4>
                          <ul className="text-xs text-muted-foreground space-y-1">
                            {track.prerequisites.map((prereq, index) => (
                              <li key={index} className="flex items-center gap-1">
                                <div className="w-1 h-1 bg-purple-500 rounded-full" />
                                {prereq}
                              </li>
                            ))}
                          </ul>
                        </div>
                      </div>

                      <div className="flex items-center gap-2 pt-2">
                        {track.status === "available" ? (
                          <Button className="flex-1 bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600">
                            <Award className="h-4 w-4 mr-2" />
                            Enroll Now
                          </Button>
                        ) : (
                          <Button className="flex-1" variant="outline" disabled>
                            <Clock className="h-4 w-4 mr-2" />
                            Coming Soon
                          </Button>
                        )}
                        <Button variant="outline">
                          <ArrowRight className="h-4 w-4" />
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </TabsContent>

          <TabsContent value="progress" className="space-y-6">
            <h3 className="text-xl font-bold text-purple-700">My Certification Progress</h3>
            
            <Card>
              <CardHeader>
                <CardTitle>Currently Enrolled</CardTitle>
                <CardDescription>Track your active certification progress</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="border rounded-lg p-4">
                    <div className="flex items-center justify-between mb-3">
                      <div>
                        <h4 className="font-semibold">Frontend Developer Certification</h4>
                        <p className="text-sm text-muted-foreground">Started 6 weeks ago</p>
                      </div>
                      <Badge className="bg-blue-100 text-blue-800">In Progress</Badge>
                    </div>
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span>Progress</span>
                        <span>5/8 Projects Complete</span>
                      </div>
                      <Progress value={62} className="h-2" />
                    </div>
                    <div className="mt-3 flex gap-2">
                      <Button size="sm" className="bg-purple-500 hover:bg-purple-600">
                        Continue Learning
                      </Button>
                      <Button size="sm" variant="outline">
                        View Details
                      </Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="certificates" className="space-y-6">
            <h3 className="text-xl font-bold text-purple-700">Earned Certificates</h3>
            
            <div className="text-center py-12">
              <Award className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-lg font-semibold mb-2">No Certificates Yet</h3>
              <p className="text-muted-foreground mb-4">
                Complete certification tracks to earn your first certificate
              </p>
              <Button className="bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600">
                Browse Tracks
              </Button>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </PlatformLayout>
  );
}