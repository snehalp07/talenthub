import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import CertificateViewer from "@/components/certificate-viewer";
import { 
  ArrowLeft,
  CheckCircle,
  Clock,
  MessageSquare,
  Award,
  BarChart3,
  FileText,
  Download,
  Share2,
  Video,
  Mic,
  Star,
  ThumbsUp,
  AlertCircle,
  Play
} from "lucide-react";
import PlatformLayout from "@/components/layout/platform-layout";
import { platformConfigs } from "@/config/complete-navigation";

interface MockInterviewCertification {
  id: string;
  interviewTitle: string;
  certificationTitle: string;
  description: string;
  completedDate: string;
  overallScore: number;
  passingScore: number;
  duration: number;
  difficulty: string;
  skills: string[];
  certificate: any;
  interviewDetails: {
    type: string;
    position: string;
    company: string;
    interviewer: string;
    questions: number;
    totalQuestions: number;
    evaluation: {
      communication: number;
      technicalKnowledge: number;
      problemSolving: number;
      culturalFit: number;
      presentation: number;
    };
    feedback: {
      strengths: string[];
      improvements: string[];
      recommendations: string[];
    };
  };
  performance: {
    responseTime: number;
    clarity: number;
    confidence: number;
    completeness: number;
  };
  videoAnalysis?: {
    eyeContact: number;
    posture: number;
    gestures: number;
    speaking: number;
  };
}

function MockInterviewCertificationViewContent() {
  const [, setLocation] = useLocation();
  
  // Get certification ID from URL params
  const urlParams = new URLSearchParams(window.location.search);
  const certificationId = urlParams.get('id') || '1';

  const { data: certification, isLoading } = useQuery<MockInterviewCertification>({
    queryKey: [`/api/candidate/certifications/interview/${certificationId}`]
  });

  // Mock data for development
  const mockCertification: MockInterviewCertification = {
    id: certificationId,
    interviewTitle: "Senior Frontend Developer Technical Interview",
    certificationTitle: "Mock Interview Excellence Certification",
    description: "Comprehensive technical interview simulation covering frontend development concepts, system design, behavioral questions, and coding challenges. Evaluated on communication skills, technical competency, and professional presentation.",
    completedDate: "2024-06-08T10:30:00Z",
    overallScore: 88,
    passingScore: 70,
    duration: 45,
    difficulty: "Senior Level",
    skills: ["React", "JavaScript", "System Design", "Communication", "Problem Solving", "Leadership"],
    interviewDetails: {
      type: "Technical + Behavioral",
      position: "Senior Frontend Developer",
      company: "Tech Innovations Inc.",
      interviewer: "Sarah Chen - Engineering Manager",
      questions: 12,
      totalQuestions: 12,
      evaluation: {
        communication: 92,
        technicalKnowledge: 85,
        problemSolving: 90,
        culturalFit: 88,
        presentation: 86
      },
      feedback: {
        strengths: [
          "Excellent communication and articulation of technical concepts",
          "Strong problem-solving approach with clear reasoning",
          "Good understanding of React ecosystem and modern frontend practices",
          "Professional demeanor and confident presentation"
        ],
        improvements: [
          "Could benefit from more detailed system design explanations",
          "Consider providing more specific examples when discussing past projects",
          "Work on time management for coding challenges"
        ],
        recommendations: [
          "Practice system design interviews with focus on scalability",
          "Prepare more concrete examples for behavioral questions",
          "Continue developing leadership and mentoring experiences"
        ]
      }
    },
    performance: {
      responseTime: 85,
      clarity: 90,
      confidence: 88,
      completeness: 82
    },
    videoAnalysis: {
      eyeContact: 87,
      posture: 90,
      gestures: 82,
      speaking: 89
    },
    certificate: {
      id: `cert-interview-${certificationId}`,
      title: "Mock Interview Excellence Certification",
      description: "This certification validates exceptional performance in a comprehensive technical interview simulation, demonstrating strong communication skills, technical competency, and professional presentation.",
      type: 'mock_interview',
      issuedDate: "2024-06-08T10:30:00Z",
      issuer: {
        name: "TalentHub Interview Academy",
        logo: "/api/placeholder/32/32",
        website: "https://interviews.talenthub.com"
      },
      recipient: {
        name: "Alex Johnson",
        email: "alex.johnson@email.com",
        id: "user-123"
      },
      skills: ["React", "JavaScript", "System Design", "Communication", "Problem Solving", "Leadership"],
      score: 88,
      passingScore: 70,
      credentialId: `TH-INT-${certificationId}-2024`,
      verificationUrl: `https://verify.talenthub.com/cert-interview-${certificationId}`,
      status: 'active',
      metadata: {
        duration: "45 minutes",
        difficulty: "Senior Level",
        topics: ["Technical Knowledge", "Problem Solving", "Communication", "Cultural Fit", "Leadership"],
        grade: "A-"
      }
    }
  };

  const currentCertification = certification || mockCertification;

  if (isLoading) {
    return <div className="flex items-center justify-center h-64">Loading certification details...</div>;
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <Button
            variant="ghost"
            onClick={() => setLocation('/candidate/browse-certifications')}
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Certifications
          </Button>
          
          <div>
            <h1 className="text-3xl font-bold text-gray-900">{currentCertification.certificationTitle}</h1>
            <p className="text-gray-600">Mock Interview Certification</p>
          </div>
        </div>

        <div className="flex items-center space-x-2">
          <Button variant="outline">
            <Download className="w-4 h-4 mr-2" />
            Download
          </Button>
          <Button variant="outline">
            <Share2 className="w-4 h-4 mr-2" />
            Share
          </Button>
        </div>
      </div>

      <Tabs defaultValue="overview" className="space-y-4">
        <TabsList>
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="performance">Performance</TabsTrigger>
          <TabsTrigger value="feedback">Feedback</TabsTrigger>
          <TabsTrigger value="certificate">Certificate</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          {/* Quick Stats */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Overall Score</CardTitle>
                <Star className="h-4 w-4 text-yellow-600" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-green-600">{currentCertification.overallScore}%</div>
                <p className="text-xs text-muted-foreground">
                  Pass: {currentCertification.passingScore}%
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Interview Duration</CardTitle>
                <Clock className="h-4 w-4 text-blue-600" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{currentCertification.duration}m</div>
                <p className="text-xs text-muted-foreground">
                  Full interview session
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Questions Answered</CardTitle>
                <MessageSquare className="h-4 w-4 text-green-600" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {currentCertification.interviewDetails.questions}/{currentCertification.interviewDetails.totalQuestions}
                </div>
                <p className="text-xs text-muted-foreground">
                  Complete responses
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Difficulty Level</CardTitle>
                <Award className="h-4 w-4 text-purple-600" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{currentCertification.difficulty}</div>
                <p className="text-xs text-muted-foreground">
                  Interview complexity
                </p>
              </CardContent>
            </Card>
          </div>

          {/* Interview Overview */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Interview Overview</CardTitle>
                <CardDescription>{currentCertification.interviewTitle}</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <h4 className="font-medium mb-2">Description</h4>
                  <p className="text-gray-600">{currentCertification.description}</p>
                </div>

                <div>
                  <h4 className="font-medium mb-2">Interview Details</h4>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-gray-600">Position:</span>
                      <span>{currentCertification.interviewDetails.position}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Company:</span>
                      <span>{currentCertification.interviewDetails.company}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Interviewer:</span>
                      <span>{currentCertification.interviewDetails.interviewer}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Interview Type:</span>
                      <span>{currentCertification.interviewDetails.type}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Completed:</span>
                      <span>{new Date(currentCertification.completedDate).toLocaleDateString()}</span>
                    </div>
                  </div>
                </div>

                <div>
                  <h4 className="font-medium mb-2">Recording Available</h4>
                  <Button variant="outline" size="sm">
                    <Play className="w-4 h-4 mr-2" />
                    View Interview Recording
                  </Button>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Skills Assessment</CardTitle>
                <CardDescription>Competencies evaluated during the interview</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <h4 className="font-medium mb-2">Skills Validated</h4>
                  <div className="flex flex-wrap gap-2">
                    {currentCertification.skills.map((skill, index) => (
                      <Badge key={index} variant="secondary">
                        {skill}
                      </Badge>
                    ))}
                  </div>
                </div>

                <div>
                  <h4 className="font-medium mb-2">Evaluation Categories</h4>
                  <div className="space-y-3">
                    {Object.entries(currentCertification.interviewDetails.evaluation).map(([category, score]) => (
                      <div key={category} className="flex items-center justify-between">
                        <span className="text-sm font-medium capitalize">
                          {category.replace(/([A-Z])/g, ' $1').trim()}
                        </span>
                        <div className="flex items-center space-x-2">
                          <div className="w-20 bg-gray-200 rounded-full h-2">
                            <div 
                              className="bg-blue-600 h-2 rounded-full" 
                              style={{ width: `${score}%` }}
                            ></div>
                          </div>
                          <span className="text-sm font-medium w-8">{score}%</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="performance" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <BarChart3 className="w-5 h-5 mr-2" />
                  Interview Performance
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div>
                  <h3 className="font-medium mb-4">Core Performance Metrics</h3>
                  <div className="space-y-3">
                    {Object.entries(currentCertification.performance).map(([metric, score]) => (
                      <div key={metric} className="flex items-center justify-between">
                        <span className="text-sm font-medium capitalize">
                          {metric.replace(/([A-Z])/g, ' $1').trim()}
                        </span>
                        <div className="flex items-center space-x-2">
                          <div className="w-24 bg-gray-200 rounded-full h-2">
                            <div 
                              className="bg-green-600 h-2 rounded-full" 
                              style={{ width: `${score}%` }}
                            ></div>
                          </div>
                          <span className="text-sm font-medium w-8">{score}%</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                <div>
                  <h3 className="font-medium mb-4">Evaluation Breakdown</h3>
                  <div className="space-y-3">
                    {Object.entries(currentCertification.interviewDetails.evaluation).map(([category, score]) => (
                      <div key={category} className="flex items-center justify-between">
                        <span className="text-sm font-medium capitalize">
                          {category.replace(/([A-Z])/g, ' $1').trim()}
                        </span>
                        <div className="flex items-center space-x-2">
                          <div className="w-24 bg-gray-200 rounded-full h-2">
                            <div 
                              className={`h-2 rounded-full ${
                                score >= 90 ? 'bg-green-600' :
                                score >= 75 ? 'bg-blue-600' :
                                score >= 60 ? 'bg-yellow-600' : 'bg-red-600'
                              }`}
                              style={{ width: `${score}%` }}
                            ></div>
                          </div>
                          <span className="text-sm font-medium w-8">{score}%</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>

            {currentCertification.videoAnalysis && (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Video className="w-5 h-5 mr-2" />
                    Video Analysis
                  </CardTitle>
                  <CardDescription>AI-powered analysis of presentation skills</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {Object.entries(currentCertification.videoAnalysis).map(([aspect, score]) => (
                      <div key={aspect} className="flex items-center justify-between">
                        <span className="text-sm font-medium capitalize">
                          {aspect.replace(/([A-Z])/g, ' $1').trim()}
                        </span>
                        <div className="flex items-center space-x-2">
                          <div className="w-24 bg-gray-200 rounded-full h-2">
                            <div 
                              className="bg-purple-600 h-2 rounded-full" 
                              style={{ width: `${score}%` }}
                            ></div>
                          </div>
                          <span className="text-sm font-medium w-8">{score}%</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}
          </div>

          {/* Performance Summary */}
          <Card>
            <CardHeader>
              <CardTitle>Performance Summary</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="text-center p-4 bg-green-50 rounded-lg">
                  <ThumbsUp className="w-8 h-8 text-green-600 mx-auto mb-2" />
                  <div className="text-lg font-bold text-green-700">Excellent</div>
                  <div className="text-sm text-green-600">Communication & Presentation</div>
                </div>
                
                <div className="text-center p-4 bg-blue-50 rounded-lg">
                  <Star className="w-8 h-8 text-blue-600 mx-auto mb-2" />
                  <div className="text-lg font-bold text-blue-700">Strong</div>
                  <div className="text-sm text-blue-600">Technical Knowledge</div>
                </div>
                
                <div className="text-center p-4 bg-yellow-50 rounded-lg">
                  <AlertCircle className="w-8 h-8 text-yellow-600 mx-auto mb-2" />
                  <div className="text-lg font-bold text-yellow-700">Good</div>
                  <div className="text-sm text-yellow-600">System Design</div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="feedback" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center text-green-700">
                  <ThumbsUp className="w-5 h-5 mr-2" />
                  Strengths
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2">
                  {currentCertification.interviewDetails.feedback.strengths.map((strength, index) => (
                    <li key={index} className="flex items-start space-x-2">
                      <CheckCircle className="w-4 h-4 text-green-600 mt-0.5" />
                      <span className="text-sm">{strength}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center text-blue-700">
                  <AlertCircle className="w-5 h-5 mr-2" />
                  Areas for Improvement
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-2">
                  {currentCertification.interviewDetails.feedback.improvements.map((improvement, index) => (
                    <li key={index} className="flex items-start space-x-2">
                      <AlertCircle className="w-4 h-4 text-blue-600 mt-0.5" />
                      <span className="text-sm">{improvement}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center text-purple-700">
                <FileText className="w-5 h-5 mr-2" />
                Recommendations
              </CardTitle>
              <CardDescription>Actionable steps for continued improvement</CardDescription>
            </CardHeader>
            <CardContent>
              <ul className="space-y-2">
                {currentCertification.interviewDetails.feedback.recommendations.map((recommendation, index) => (
                  <li key={index} className="flex items-start space-x-2">
                    <Star className="w-4 h-4 text-purple-600 mt-0.5" />
                    <span className="text-sm">{recommendation}</span>
                  </li>
                ))}
              </ul>
            </CardContent>
          </Card>

          {/* Next Steps */}
          <Card>
            <CardHeader>
              <CardTitle>Next Steps</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Button variant="outline" className="justify-start">
                  <MessageSquare className="w-4 h-4 mr-2" />
                  Schedule Follow-up Interview
                </Button>
                
                <Button variant="outline" className="justify-start">
                  <FileText className="w-4 h-4 mr-2" />
                  Practice System Design
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="certificate">
          <Card>
            <CardHeader>
              <CardTitle>Official Certificate</CardTitle>
              <CardDescription>Your verified mock interview certification document</CardDescription>
            </CardHeader>
            <CardContent>
              <CertificateViewer certificate={currentCertification.certificate} />
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}

export default function MockInterviewCertificationView() {
  const config = platformConfigs.candidate;
  
  const usageData = [
    { label: "Mock Interviews", current: 15, max: 25 },
    { label: "Certifications", current: 8, max: 15 },
    { label: "Video Analysis", current: 12, max: 20 },
  ];

  return (
    <PlatformLayout
      sidebarTitle={config.sidebarTitle}
      sidebarSubtitle={config.sidebarSubtitle}
      sidebarSections={config.sidebarSections}
      usageData={usageData}
    >
      <MockInterviewCertificationViewContent />
    </PlatformLayout>
  );
}