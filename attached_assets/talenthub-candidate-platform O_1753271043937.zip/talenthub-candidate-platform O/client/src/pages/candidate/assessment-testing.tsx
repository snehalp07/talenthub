import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import PlatformLayout from "@/components/layout/platform-layout";
import { candidateNavigation } from "@/config/complete-navigation";
import { 
  Target, Play, Clock, Trophy, Brain, CheckCircle, Star,
  Code, Monitor, Server, Database, Cloud, Layers, Zap,
  BarChart3, Users, TrendingUp, Award, History, Eye
} from "lucide-react";

const AssessmentTesting: React.FC = () => {
  const [activeTab, setActiveTab] = useState('skill-assessment');

  const testModes = [
    {
      id: 'skill-assessment',
      title: 'Skill Assessment Tests',
      icon: Target,
      color: 'from-blue-500 to-blue-600',
      description: 'Evaluate your current skill level across different technologies',
      features: ['Real-time scoring', 'Skill gap analysis', 'Personalized feedback', 'Industry benchmarking']
    },
    {
      id: 'practice-mode',
      title: 'Practice Mode',
      icon: Play,
      color: 'from-green-500 to-green-600',
      description: 'Learn and improve with unlimited practice sessions',
      features: ['No time limits', 'Instant explanations', 'Progress tracking', 'Mistake analysis']
    },
    {
      id: 'certification-mode',
      title: 'Certification Mode',
      icon: Trophy,
      color: 'from-purple-500 to-purple-600',
      description: 'Take official certification exams with proctoring',
      features: ['Timed exams', 'Official scoring', 'Certificate generation', 'Blockchain verification']
    },
    {
      id: 'ai-adaptive',
      title: 'AI Adaptive Testing',
      icon: Brain,
      color: 'from-pink-500 to-pink-600',
      description: 'Intelligent testing that adapts to your skill level',
      features: ['Dynamic difficulty', 'Personalized questions', 'Optimal learning path', 'Smart recommendations']
    }
  ];

  const skillCategories = [
    {
      name: 'Frontend Development',
      icon: Monitor,
      color: 'bg-blue-100 text-blue-800',
      tests: 24,
      avgTime: '45 min',
      difficulty: 'Intermediate',
      technologies: ['React', 'Vue', 'Angular', 'TypeScript', 'CSS3']
    },
    {
      name: 'Backend Development',
      icon: Server,
      color: 'bg-green-100 text-green-800',
      tests: 28,
      avgTime: '60 min',
      difficulty: 'Advanced',
      technologies: ['Node.js', 'Python', 'Java', 'APIs', 'Databases']
    },
    {
      name: 'Full-Stack Development',
      icon: Layers,
      color: 'bg-purple-100 text-purple-800',
      tests: 18,
      avgTime: '90 min',
      difficulty: 'Expert',
      technologies: ['MERN', 'MEAN', 'Django', 'Spring', 'DevOps']
    },
    {
      name: 'Cloud & DevOps',
      icon: Cloud,
      color: 'bg-orange-100 text-orange-800',
      tests: 16,
      avgTime: '50 min',
      difficulty: 'Intermediate',
      technologies: ['AWS', 'Docker', 'Kubernetes', 'CI/CD', 'Terraform']
    },
    {
      name: 'Data Science',
      icon: Database,
      color: 'bg-emerald-100 text-emerald-800',
      tests: 12,
      avgTime: '75 min',
      difficulty: 'Advanced',
      technologies: ['Python', 'R', 'SQL', 'ML', 'Statistics']
    },
    {
      name: 'AI & Machine Learning',
      icon: Brain,
      color: 'bg-indigo-100 text-indigo-800',
      tests: 14,
      avgTime: '85 min',
      difficulty: 'Expert',
      technologies: ['TensorFlow', 'PyTorch', 'NLP', 'Computer Vision', 'Deep Learning']
    }
  ];

  const recentTests = [
    {
      name: 'React Advanced Patterns',
      score: 87,
      date: '2 hours ago',
      status: 'completed',
      duration: '42 min',
      category: 'Frontend'
    },
    {
      name: 'Node.js API Development',
      score: 92,
      date: 'Yesterday',
      status: 'completed',
      duration: '55 min',
      category: 'Backend'
    },
    {
      name: 'AWS Solutions Architect',
      score: 0,
      date: 'In Progress',
      status: 'in-progress',
      duration: '25 min elapsed',
      category: 'Cloud'
    }
  ];

  const testStatistics = {
    totalTests: 156,
    completedTests: 43,
    averageScore: 85,
    timeSpent: '24 hours',
    certificates: 7,
    rank: 'Top 15%'
  };

  return (
    <PlatformLayout
      sidebarTitle="Skills Certification Hub"
      sidebarSubtitle="Assessment & Testing"
      sidebarSections={candidateNavigation}
    >
      <div className="min-h-screen bg-gradient-to-br from-green-50 via-white to-blue-50">
        {/* Header Section */}
        <div className="bg-gradient-to-r from-green-600 to-blue-600 text-white p-8">
          <div className="max-w-7xl mx-auto">
            <div className="flex items-center gap-3 mb-4">
              <Target className="h-8 w-8" />
              <h1 className="text-3xl font-bold">Assessment & Testing Center</h1>
            </div>
            <p className="text-green-100 text-lg">
              Comprehensive skill evaluation with multiple testing modes and real-time feedback
            </p>
          </div>
        </div>

        <div className="max-w-7xl mx-auto p-8">
          {/* Statistics Dashboard */}
          <div className="grid grid-cols-2 lg:grid-cols-6 gap-4 mb-8">
            <Card className="text-center">
              <CardContent className="p-4">
                <Target className="h-6 w-6 text-blue-600 mx-auto mb-2" />
                <div className="text-xl font-bold">{testStatistics.totalTests}</div>
                <div className="text-xs text-gray-600">Available Tests</div>
              </CardContent>
            </Card>
            <Card className="text-center">
              <CardContent className="p-4">
                <CheckCircle className="h-6 w-6 text-green-600 mx-auto mb-2" />
                <div className="text-xl font-bold">{testStatistics.completedTests}</div>
                <div className="text-xs text-gray-600">Completed</div>
              </CardContent>
            </Card>
            <Card className="text-center">
              <CardContent className="p-4">
                <Star className="h-6 w-6 text-yellow-600 mx-auto mb-2" />
                <div className="text-xl font-bold">{testStatistics.averageScore}%</div>
                <div className="text-xs text-gray-600">Avg Score</div>
              </CardContent>
            </Card>
            <Card className="text-center">
              <CardContent className="p-4">
                <Clock className="h-6 w-6 text-purple-600 mx-auto mb-2" />
                <div className="text-xl font-bold">{testStatistics.timeSpent}</div>
                <div className="text-xs text-gray-600">Time Spent</div>
              </CardContent>
            </Card>
            <Card className="text-center">
              <CardContent className="p-4">
                <Trophy className="h-6 w-6 text-orange-600 mx-auto mb-2" />
                <div className="text-xl font-bold">{testStatistics.certificates}</div>
                <div className="text-xs text-gray-600">Certificates</div>
              </CardContent>
            </Card>
            <Card className="text-center">
              <CardContent className="p-4">
                <TrendingUp className="h-6 w-6 text-indigo-600 mx-auto mb-2" />
                <div className="text-xl font-bold">{testStatistics.rank}</div>
                <div className="text-xs text-gray-600">Global Rank</div>
              </CardContent>
            </Card>
          </div>

          <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
            <TabsList className="grid w-full grid-cols-4">
              {testModes.map(mode => {
                const Icon = mode.icon;
                return (
                  <TabsTrigger key={mode.id} value={mode.id} className="flex items-center gap-2">
                    <Icon className="h-4 w-4" />
                    {mode.title}
                  </TabsTrigger>
                );
              })}
            </TabsList>

            {testModes.map(mode => {
              const Icon = mode.icon;
              return (
                <TabsContent key={mode.id} value={mode.id} className="space-y-6">
                  {/* Mode Header */}
                  <Card className={`bg-gradient-to-r ${mode.color} text-white`}>
                    <CardContent className="p-6">
                      <div className="flex items-center gap-4">
                        <Icon className="h-12 w-12" />
                        <div>
                          <h2 className="text-2xl font-bold">{mode.title}</h2>
                          <p className="text-white/90">{mode.description}</p>
                        </div>
                      </div>
                      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mt-6">
                        {mode.features.map((feature, index) => (
                          <div key={index} className="flex items-center gap-2">
                            <CheckCircle className="h-4 w-4" />
                            <span className="text-sm">{feature}</span>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>

                  {/* Skill Categories Grid */}
                  <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
                    {skillCategories.map((category, index) => {
                      const CategoryIcon = category.icon;
                      return (
                        <Card key={index} className="hover:shadow-lg transition-all duration-300 group">
                          <CardHeader className="pb-3">
                            <div className="flex items-center justify-between">
                              <CategoryIcon className="h-8 w-8 text-gray-600 group-hover:text-blue-600 transition-colors" />
                              <Badge className={category.color}>{category.difficulty}</Badge>
                            </div>
                            <CardTitle className="text-lg">{category.name}</CardTitle>
                            <CardDescription>
                              {category.tests} tests available • Avg time: {category.avgTime}
                            </CardDescription>
                          </CardHeader>
                          <CardContent className="space-y-4">
                            <div className="flex flex-wrap gap-1">
                              {category.technologies.map((tech, techIndex) => (
                                <Badge key={techIndex} variant="secondary" className="text-xs">
                                  {tech}
                                </Badge>
                              ))}
                            </div>
                            <div className="flex gap-2">
                              <Button 
                                className="flex-1"
                                onClick={() => window.location.href = '/candidate/browse-tests'}
                              >
                                <Play className="h-4 w-4 mr-2" />
                                Start Test
                              </Button>
                              <Button variant="outline" size="sm">
                                <Eye className="h-4 w-4" />
                              </Button>
                            </div>
                          </CardContent>
                        </Card>
                      );
                    })}
                  </div>
                </TabsContent>
              );
            })}
          </Tabs>

          {/* Recent Test Activity */}
          <Card className="mt-8">
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="flex items-center gap-2">
                    <History className="h-5 w-5" />
                    Recent Test Activity
                  </CardTitle>
                  <CardDescription>Your latest test attempts and results</CardDescription>
                </div>
                <Button variant="outline" onClick={() => window.location.href = '/candidate/test-results'}>
                  View All Results
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {recentTests.map((test, index) => (
                  <div key={index} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                    <div className="flex items-center gap-4">
                      <div className={`w-12 h-12 rounded-lg flex items-center justify-center ${
                        test.status === 'completed' ? 'bg-green-100' : 'bg-blue-100'
                      }`}>
                        {test.status === 'completed' ? (
                          <CheckCircle className="h-6 w-6 text-green-600" />
                        ) : (
                          <Clock className="h-6 w-6 text-blue-600" />
                        )}
                      </div>
                      <div>
                        <div className="font-medium">{test.name}</div>
                        <div className="text-sm text-gray-600">
                          {test.category} • {test.duration}
                        </div>
                      </div>
                    </div>
                    <div className="text-right">
                      {test.status === 'completed' ? (
                        <div className="text-lg font-bold text-green-600">{test.score}%</div>
                      ) : (
                        <Badge className="bg-blue-100 text-blue-800">In Progress</Badge>
                      )}
                      <div className="text-sm text-gray-600">{test.date}</div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Quick Actions */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mt-8">
            <Card className="bg-gradient-to-br from-blue-500 to-blue-600 text-white">
              <CardContent className="p-6 text-center">
                <Brain className="h-12 w-12 mx-auto mb-4" />
                <h3 className="text-xl font-bold mb-2">AI Skill Assessment</h3>
                <p className="text-blue-100 mb-4">Get personalized skill evaluation with AI</p>
                <Button className="bg-white text-blue-600 hover:bg-gray-100">
                  Start Assessment
                </Button>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-br from-green-500 to-green-600 text-white">
              <CardContent className="p-6 text-center">
                <Target className="h-12 w-12 mx-auto mb-4" />
                <h3 className="text-xl font-bold mb-2">Browse All Tests</h3>
                <p className="text-green-100 mb-4">Explore our complete test library</p>
                <Button 
                  className="bg-white text-green-600 hover:bg-gray-100"
                  onClick={() => window.location.href = '/candidate/browse-tests'}
                >
                  Browse Tests
                </Button>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-br from-purple-500 to-purple-600 text-white">
              <CardContent className="p-6 text-center">
                <Trophy className="h-12 w-12 mx-auto mb-4" />
                <h3 className="text-xl font-bold mb-2">Certification Mode</h3>
                <p className="text-purple-100 mb-4">Take official certification exams</p>
                <Button className="bg-white text-purple-600 hover:bg-gray-100">
                  View Certifications
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </PlatformLayout>
  );
};

export default AssessmentTesting;