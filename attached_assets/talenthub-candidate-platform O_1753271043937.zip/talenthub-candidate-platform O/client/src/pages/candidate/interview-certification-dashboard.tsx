import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import PlatformLayout from "@/components/layout/platform-layout";
import { candidateNavigation } from "@/config/complete-navigation";
import { 
  Monitor, Server, Layers, Cloud, Database, Play, CheckCircle, Award, Target, TrendingUp, 
  Star, Clock, Code, Users, Zap, BookOpen, Trophy, ArrowRight, ChevronDown, Lock, Unlock
} from "lucide-react";

const InterviewCertificationDashboard: React.FC = () => {
  const [selectedTrack, setSelectedTrack] = useState({
    frontend: 'react',
    backend: 'nodejs',
    fullstack: 'mern',
    devops: 'aws',
    datascience: 'python'
  });

  const certificationData = {
    frontend: {
      icon: Monitor,
      color: 'from-slate-600 to-slate-700',
      accentColor: 'from-blue-50 to-blue-100',
      borderColor: 'border-blue-200',
      textColor: 'text-blue-700',
      title: 'Frontend Development Certification',
      description: 'Master modern frontend technologies and frameworks',
      tracks: [
        {
          id: 'react',
          name: 'React Developer',
          duration: '8-12 weeks',
          enrolled: 15420,
          completion: 68,
          rating: 4.8,
          modules: [
            { name: 'React Fundamentals', status: 'completed', progress: 100, duration: '2 weeks' },
            { name: 'Component Lifecycle', status: 'completed', progress: 100, duration: '1.5 weeks' },
            { name: 'State Management', status: 'current', progress: 75, duration: '2 weeks' },
            { name: 'React Hooks', status: 'locked', progress: 0, duration: '2 weeks' },
            { name: 'Performance Optimization', status: 'locked', progress: 0, duration: '1.5 weeks' },
            { name: 'Testing & Deployment', status: 'locked', progress: 0, duration: '2 weeks' }
          ]
        },
        {
          id: 'vue',
          name: 'Vue.js Developer',
          duration: '6-10 weeks',
          enrolled: 8730,
          completion: 45,
          rating: 4.7,
          modules: [
            { name: 'Vue Basics', status: 'completed', progress: 100, duration: '1.5 weeks' },
            { name: 'Directives & Data Binding', status: 'current', progress: 60, duration: '1.5 weeks' },
            { name: 'Component Architecture', status: 'locked', progress: 0, duration: '2 weeks' },
            { name: 'Vuex State Management', status: 'locked', progress: 0, duration: '1.5 weeks' },
            { name: 'Vue Router', status: 'locked', progress: 0, duration: '1 week' }
          ]
        },
        {
          id: 'angular',
          name: 'Angular Developer',
          duration: '10-14 weeks',
          enrolled: 12560,
          completion: 38,
          rating: 4.6,
          modules: [
            { name: 'TypeScript Foundation', status: 'available', progress: 0, duration: '2 weeks' },
            { name: 'Angular Fundamentals', status: 'locked', progress: 0, duration: '3 weeks' },
            { name: 'Services & Dependency Injection', status: 'locked', progress: 0, duration: '2 weeks' },
            { name: 'Routing & Guards', status: 'locked', progress: 0, duration: '2 weeks' },
            { name: 'Forms & Validation', status: 'locked', progress: 0, duration: '1.5 weeks' }
          ]
        }
      ]
    },
    backend: {
      icon: Server,
      color: 'from-slate-600 to-slate-700',
      accentColor: 'from-emerald-50 to-emerald-100',
      borderColor: 'border-emerald-200',
      textColor: 'text-emerald-700',
      title: 'Backend Development Certification',
      description: 'Build robust server-side applications and APIs',
      tracks: [
        {
          id: 'nodejs',
          name: 'Node.js Developer',
          duration: '10-14 weeks',
          enrolled: 18750,
          completion: 72,
          rating: 4.9,
          modules: [
            { name: 'JavaScript ES6+ Mastery', status: 'completed', progress: 100, duration: '2 weeks' },
            { name: 'Node.js Fundamentals', status: 'completed', progress: 100, duration: '2 weeks' },
            { name: 'Express.js & Middleware', status: 'current', progress: 85, duration: '2.5 weeks' },
            { name: 'Database Integration', status: 'locked', progress: 0, duration: '2 weeks' },
            { name: 'Authentication & Security', status: 'locked', progress: 0, duration: '2 weeks' },
            { name: 'API Design & Testing', status: 'locked', progress: 0, duration: '2.5 weeks' }
          ]
        },
        {
          id: 'python',
          name: 'Python Developer',
          duration: '8-12 weeks',
          enrolled: 22340,
          completion: 45,
          rating: 4.8,
          modules: [
            { name: 'Python Core Concepts', status: 'completed', progress: 100, duration: '2 weeks' },
            { name: 'Object-Oriented Programming', status: 'current', progress: 60, duration: '2 weeks' },
            { name: 'Django Framework', status: 'locked', progress: 0, duration: '3 weeks' },
            { name: 'Database & ORM', status: 'locked', progress: 0, duration: '2 weeks' },
            { name: 'API Development', status: 'locked', progress: 0, duration: '1.5 weeks' }
          ]
        },
        {
          id: 'java',
          name: 'Java Developer',
          duration: '12-16 weeks',
          enrolled: 14890,
          completion: 52,
          rating: 4.7,
          modules: [
            { name: 'Java Fundamentals', status: 'available', progress: 0, duration: '3 weeks' },
            { name: 'Spring Framework', status: 'locked', progress: 0, duration: '4 weeks' },
            { name: 'Spring Boot', status: 'locked', progress: 0, duration: '3 weeks' },
            { name: 'JPA & Hibernate', status: 'locked', progress: 0, duration: '2 weeks' },
            { name: 'Microservices Architecture', status: 'locked', progress: 0, duration: '2 weeks' }
          ]
        }
      ]
    },
    fullstack: {
      icon: Layers,
      color: 'from-slate-600 to-slate-700',
      accentColor: 'from-purple-50 to-purple-100',
      borderColor: 'border-purple-200',
      textColor: 'text-purple-700',
      title: 'Full-Stack Development Certification',
      description: 'Complete end-to-end web application development',
      tracks: [
        {
          id: 'mern',
          name: 'MERN Stack Developer',
          duration: '16-20 weeks',
          enrolled: 24680,
          completion: 58,
          rating: 4.9,
          modules: [
            { name: 'MongoDB Database Design', status: 'completed', progress: 100, duration: '2 weeks' },
            { name: 'Express.js Backend', status: 'completed', progress: 100, duration: '3 weeks' },
            { name: 'React Frontend', status: 'current', progress: 70, duration: '4 weeks' },
            { name: 'Node.js Integration', status: 'locked', progress: 0, duration: '3 weeks' },
            { name: 'Authentication & Security', status: 'locked', progress: 0, duration: '2 weeks' },
            { name: 'Deployment & DevOps', status: 'locked', progress: 0, duration: '2 weeks' }
          ]
        },
        {
          id: 'mean',
          name: 'MEAN Stack Developer',
          duration: '14-18 weeks',
          enrolled: 16420,
          completion: 42,
          rating: 4.6,
          modules: [
            { name: 'MongoDB Fundamentals', status: 'completed', progress: 100, duration: '2 weeks' },
            { name: 'Express.js Framework', status: 'current', progress: 55, duration: '3 weeks' },
            { name: 'Angular Development', status: 'locked', progress: 0, duration: '5 weeks' },
            { name: 'Node.js Backend', status: 'locked', progress: 0, duration: '3 weeks' },
            { name: 'Full-Stack Integration', status: 'locked', progress: 0, duration: '2 weeks' }
          ]
        },
        {
          id: 'django',
          name: 'Django Full-Stack',
          duration: '12-16 weeks',
          enrolled: 19330,
          completion: 48,
          rating: 4.8,
          modules: [
            { name: 'Python Advanced Concepts', status: 'available', progress: 0, duration: '2 weeks' },
            { name: 'Django Framework', status: 'locked', progress: 0, duration: '4 weeks' },
            { name: 'Database Models & ORM', status: 'locked', progress: 0, duration: '2 weeks' },
            { name: 'Frontend Integration', status: 'locked', progress: 0, duration: '3 weeks' },
            { name: 'Authentication & Permissions', status: 'locked', progress: 0, duration: '2 weeks' }
          ]
        }
      ]
    },
    devops: {
      icon: Cloud,
      color: 'from-slate-600 to-slate-700',
      accentColor: 'from-orange-50 to-orange-100',
      borderColor: 'border-orange-200',
      textColor: 'text-orange-700',
      title: 'DevOps Engineering Certification',
      description: 'Master infrastructure automation and deployment pipelines',
      tracks: [
        {
          id: 'aws',
          name: 'AWS DevOps Engineer',
          duration: '14-18 weeks',
          enrolled: 21750,
          completion: 62,
          rating: 4.8,
          modules: [
            { name: 'AWS Core Services', status: 'completed', progress: 100, duration: '3 weeks' },
            { name: 'EC2 & Auto Scaling', status: 'completed', progress: 100, duration: '2 weeks' },
            { name: 'CI/CD with CodePipeline', status: 'current', progress: 80, duration: '3 weeks' },
            { name: 'Infrastructure as Code', status: 'locked', progress: 0, duration: '3 weeks' },
            { name: 'Monitoring & Logging', status: 'locked', progress: 0, duration: '2 weeks' },
            { name: 'Container Orchestration', status: 'locked', progress: 0, duration: '2 weeks' }
          ]
        },
        {
          id: 'kubernetes',
          name: 'Kubernetes Administrator',
          duration: '10-14 weeks',
          enrolled: 18920,
          completion: 45,
          rating: 4.9,
          modules: [
            { name: 'Container Fundamentals', status: 'completed', progress: 100, duration: '2 weeks' },
            { name: 'Kubernetes Architecture', status: 'current', progress: 65, duration: '2.5 weeks' },
            { name: 'Pod & Service Management', status: 'locked', progress: 0, duration: '2 weeks' },
            { name: 'Storage & Networking', status: 'locked', progress: 0, duration: '2 weeks' },
            { name: 'Security & RBAC', status: 'locked', progress: 0, duration: '1.5 weeks' }
          ]
        },
        {
          id: 'docker',
          name: 'Docker Specialist',
          duration: '6-8 weeks',
          enrolled: 25640,
          completion: 73,
          rating: 4.7,
          modules: [
            { name: 'Docker Fundamentals', status: 'available', progress: 0, duration: '1.5 weeks' },
            { name: 'Image Creation & Management', status: 'locked', progress: 0, duration: '2 weeks' },
            { name: 'Docker Compose', status: 'locked', progress: 0, duration: '1.5 weeks' },
            { name: 'Docker Swarm', status: 'locked', progress: 0, duration: '1 week' }
          ]
        }
      ]
    },
    datascience: {
      icon: Database,
      color: 'from-slate-600 to-slate-700',
      accentColor: 'from-indigo-50 to-indigo-100',
      borderColor: 'border-indigo-200',
      textColor: 'text-indigo-700',
      title: 'Data Science Certification',
      description: 'Master data analysis, machine learning, and AI technologies',
      tracks: [
        {
          id: 'python',
          name: 'Python Data Scientist',
          duration: '16-20 weeks',
          enrolled: 28940,
          completion: 54,
          rating: 4.9,
          modules: [
            { name: 'Python for Data Science', status: 'completed', progress: 100, duration: '3 weeks' },
            { name: 'NumPy & Pandas', status: 'completed', progress: 100, duration: '3 weeks' },
            { name: 'Data Visualization', status: 'current', progress: 75, duration: '2.5 weeks' },
            { name: 'Statistical Analysis', status: 'locked', progress: 0, duration: '3 weeks' },
            { name: 'Machine Learning', status: 'locked', progress: 0, duration: '4 weeks' },
            { name: 'Deep Learning & Neural Networks', status: 'locked', progress: 0, duration: '3 weeks' }
          ]
        },
        {
          id: 'ml',
          name: 'Machine Learning Engineer',
          duration: '14-18 weeks',
          enrolled: 22180,
          completion: 41,
          rating: 4.8,
          modules: [
            { name: 'ML Fundamentals', status: 'completed', progress: 100, duration: '2 weeks' },
            { name: 'Supervised Learning', status: 'current', progress: 50, duration: '3 weeks' },
            { name: 'Unsupervised Learning', status: 'locked', progress: 0, duration: '3 weeks' },
            { name: 'Model Evaluation & Tuning', status: 'locked', progress: 0, duration: '2.5 weeks' },
            { name: 'MLOps & Deployment', status: 'locked', progress: 0, duration: '3 weeks' }
          ]
        },
        {
          id: 'tensorflow',
          name: 'TensorFlow Developer',
          duration: '12-16 weeks',
          enrolled: 19750,
          completion: 47,
          rating: 4.7,
          modules: [
            { name: 'TensorFlow Basics', status: 'available', progress: 0, duration: '2 weeks' },
            { name: 'Neural Network Architecture', status: 'locked', progress: 0, duration: '3 weeks' },
            { name: 'Computer Vision', status: 'locked', progress: 0, duration: '3 weeks' },
            { name: 'Natural Language Processing', status: 'locked', progress: 0, duration: '3 weeks' },
            { name: 'Model Optimization', status: 'locked', progress: 0, duration: '2 weeks' }
          ]
        }
      ]
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed': return 'text-green-600 bg-green-50';
      case 'current': return 'text-blue-600 bg-blue-50';
      case 'available': return 'text-purple-600 bg-purple-50';
      case 'locked': return 'text-gray-400 bg-gray-50';
      default: return 'text-gray-600 bg-gray-50';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed': return <CheckCircle className="h-4 w-4" />;
      case 'current': return <Play className="h-4 w-4" />;
      case 'available': return <Unlock className="h-4 w-4" />;
      case 'locked': return <Lock className="h-4 w-4" />;
      default: return <Clock className="h-4 w-4" />;
    }
  };

  const renderCertificationTab = (domain: keyof typeof certificationData) => {
    const data = certificationData[domain];
    const currentTrack = data.tracks.find(track => track.id === selectedTrack[domain]) || data.tracks[0];
    const IconComponent = data.icon;

    return (
      <div className="space-y-8">
        {/* Professional Header with Subtle Effects */}
        <div className="relative text-center space-y-6">
          <div className={`absolute inset-0 bg-gradient-to-r ${data.accentColor} opacity-30 rounded-2xl blur-2xl`}></div>
          <div className="relative">
            <div className={`inline-flex items-center gap-3 px-6 py-3 bg-gradient-to-r ${data.accentColor} rounded-xl border ${data.borderColor} backdrop-blur-sm shadow-sm hover:shadow-md transition-all duration-300`}>
              <div className={`p-2 bg-gradient-to-r ${data.color} rounded-lg shadow-sm`}>
                <IconComponent className="h-5 w-5 text-white" />
              </div>
              <span className={`text-sm font-semibold ${data.textColor}`}>
                {data.title}
              </span>
            </div>
            <h2 className={`text-3xl font-bold ${data.textColor} mt-4 mb-2`}>
              {data.title}
            </h2>
            <div className={`w-16 h-0.5 bg-gradient-to-r ${data.color} rounded-full mx-auto mb-4 opacity-60`}></div>
            <p className="text-base text-gray-600 max-w-2xl mx-auto leading-relaxed">
              {data.description}
            </p>
          </div>
        </div>

        {/* Professional Track Selection Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {data.tracks.map((track, index) => (
            <Card 
              key={track.id}
              className={`group cursor-pointer transition-all duration-300 hover:translate-y-[-2px] ${
                selectedTrack[domain] === track.id 
                  ? `ring-2 ${data.borderColor} bg-gradient-to-br ${data.accentColor} shadow-lg` 
                  : 'hover:shadow-md border-gray-200 bg-white'
              }`}
              onClick={() => setSelectedTrack(prev => ({ ...prev, [domain]: track.id }))}
            >
              <CardContent className="p-5 relative">
                <div className="space-y-3">
                  <div className="flex items-start justify-between">
                    <h3 className={`font-semibold text-base ${
                      selectedTrack[domain] === track.id 
                        ? data.textColor
                        : 'text-gray-800'
                    }`}>
                      {track.name}
                    </h3>
                    {selectedTrack[domain] === track.id && (
                      <div className={`p-1.5 bg-gradient-to-r ${data.color} rounded-lg`}>
                        <CheckCircle className="h-3.5 w-3.5 text-white" />
                      </div>
                    )}
                  </div>
                  
                  <div className="space-y-2">
                    <div className="flex items-center gap-2 text-xs text-gray-600">
                      <Clock className="h-3.5 w-3.5" />
                      <span>{track.duration}</span>
                    </div>
                    
                    <div className="flex items-center gap-2 text-xs text-gray-600">
                      <Users className="h-3.5 w-3.5" />
                      <span>{track.enrolled.toLocaleString()} enrolled</span>
                    </div>
                    
                    <div className="flex items-center gap-2 text-xs">
                      <div className="flex gap-0.5">
                        {[...Array(5)].map((_, i) => (
                          <Star key={i} className={`h-3 w-3 ${i < Math.floor(track.rating) ? 'text-amber-400 fill-current' : 'text-gray-300'}`} />
                        ))}
                      </div>
                      <span className="text-gray-600">{track.rating}/5</span>
                    </div>
                  </div>
                  
                  {selectedTrack[domain] === track.id && (
                    <div className={`mt-3 p-2 bg-gradient-to-r ${data.accentColor} rounded-md border-l-2 ${data.borderColor}`}>
                      <p className="text-xs font-medium text-gray-700">Active Selection</p>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Professional Learning Path with Clean Design */}
        <Card className="border border-gray-200 shadow-sm">
          <CardHeader className="pb-4">
            <div className="flex items-center justify-between">
              <CardTitle className="flex items-center gap-3">
                <div className={`p-2.5 bg-gradient-to-r ${data.color} rounded-lg`}>
                  <IconComponent className="h-5 w-5 text-white" />
                </div>
                <div>
                  <div className={`text-xl font-bold ${data.textColor}`}>
                    {currentTrack.name}
                  </div>
                  <div className="text-sm text-gray-500 font-medium">Learning Path</div>
                </div>
              </CardTitle>
              <div className={`px-3 py-1.5 bg-gradient-to-r ${data.accentColor} rounded-lg border ${data.borderColor}`}>
                <span className="text-sm font-medium text-gray-700">
                  {currentTrack.modules.filter(m => m.status === 'completed').length} / {currentTrack.modules.length} modules
                </span>
              </div>
            </div>
            <CardDescription className="text-sm text-gray-600 mt-2">
              Progress through structured learning modules designed for professional development
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {currentTrack.modules.map((module, index) => (
                <div 
                  key={index} 
                  className={`relative flex items-center gap-4 p-4 rounded-lg border transition-all duration-200 hover:shadow-sm ${
                    module.status === 'current' 
                      ? `bg-gradient-to-r ${data.accentColor} border-2 ${data.borderColor}` 
                      : 'bg-white border-gray-200'
                  }`}
                >
                  {/* Module Status Icon */}
                  <div className="relative flex-shrink-0">
                    <div className={`flex items-center justify-center w-10 h-10 rounded-lg transition-all duration-200 ${
                      module.status === 'completed' 
                        ? 'bg-green-100 text-green-700' 
                        : module.status === 'current'
                        ? `bg-gradient-to-r ${data.color} text-white`
                        : module.status === 'available'
                        ? 'bg-blue-100 text-blue-700'
                        : 'bg-gray-100 text-gray-400'
                    }`}>
                      {getStatusIcon(module.status)}
                    </div>
                    <div className={`absolute -top-1 -right-1 w-5 h-5 rounded-full text-xs font-medium flex items-center justify-center text-white ${
                      module.status === 'completed' ? 'bg-green-500' :
                      module.status === 'current' ? data.textColor.replace('text-', 'bg-') :
                      'bg-gray-400'
                    }`}>
                      {index + 1}
                    </div>
                  </div>

                  {/* Module Content */}
                  <div className="flex-1 min-w-0">
                    <div className="flex justify-between items-start mb-2">
                      <div className="flex-1">
                        <h4 className={`font-semibold text-base ${
                          module.status === 'current' 
                            ? data.textColor
                            : 'text-gray-800'
                        }`}>
                          {module.name}
                        </h4>
                        <div className="flex items-center gap-3 mt-1">
                          <Badge variant="outline" className="text-xs">
                            {module.duration}
                          </Badge>
                          <span className={`text-xs px-2 py-1 rounded-md ${getStatusColor(module.status)}`}>
                            {module.status.charAt(0).toUpperCase() + module.status.slice(1)}
                          </span>
                        </div>
                      </div>
                      <Button 
                        variant={module.status === 'locked' ? 'ghost' : 'default'}
                        size="sm"
                        disabled={module.status === 'locked'}
                        className={`ml-4 transition-all duration-200 ${
                          module.status === 'current' 
                            ? `bg-gradient-to-r ${data.color} hover:opacity-90` 
                            : module.status === 'completed'
                            ? 'bg-green-600 hover:bg-green-700 text-white'
                            : ''
                        }`}
                      >
                        {module.status === 'completed' ? 'Review' : 
                         module.status === 'current' ? 'Continue' :
                         module.status === 'available' ? 'Start' : 'Locked'}
                      </Button>
                    </div>
                    
                    {/* Progress Bar */}
                    <div className="space-y-1">
                      <div className="flex justify-between text-xs">
                        <span className="text-gray-500">Progress</span>
                        <span className={`font-medium ${
                          module.progress === 100 ? 'text-green-600' :
                          module.progress > 0 ? data.textColor : 'text-gray-400'
                        }`}>
                          {module.progress}%
                        </span>
                      </div>
                      <Progress value={module.progress} className="h-2" />
                    </div>
                  </div>

                  {/* Connection Line */}
                  {index < currentTrack.modules.length - 1 && (
                    <div className={`absolute left-7 top-12 w-px h-6 ${
                      currentTrack.modules[index + 1].status !== 'locked' 
                        ? data.textColor.replace('text-', 'bg-').replace('-700', '-300')
                        : 'bg-gray-200'
                    }`}></div>
                  )}
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Enhanced Statistics with Colorful Interactive Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card className="group relative overflow-hidden border-0 shadow-xl hover:shadow-2xl transition-all duration-500 hover:scale-105">
            <div className="absolute inset-0 bg-gradient-to-br from-blue-500 to-cyan-500 opacity-10"></div>
            <CardContent className="relative p-8 text-center">
              <div className="space-y-4">
                <div className="p-4 bg-gradient-to-r from-blue-500 to-cyan-500 rounded-2xl w-16 h-16 flex items-center justify-center mx-auto shadow-lg">
                  <Target className="h-8 w-8 text-white" />
                </div>
                <div>
                  <div className="text-4xl font-bold bg-gradient-to-r from-blue-600 to-cyan-600 bg-clip-text text-transparent mb-2">
                    {currentTrack.completion}%
                  </div>
                  <div className="text-sm font-semibold text-gray-700 uppercase tracking-wide">Overall Progress</div>
                  <div className="mt-3 w-full bg-gray-200 rounded-full h-2">
                    <div 
                      className="bg-gradient-to-r from-blue-500 to-cyan-500 h-2 rounded-full transition-all duration-1000"
                      style={{ width: `${currentTrack.completion}%` }}
                    ></div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border border-gray-200 shadow-sm hover:shadow-md transition-shadow duration-200">
            <CardContent className="p-6 text-center">
              <div className="space-y-3">
                <div className="p-3 bg-gradient-to-r from-slate-600 to-slate-700 rounded-lg w-12 h-12 flex items-center justify-center mx-auto">
                  <Users className="h-6 w-6 text-white" />
                </div>
                <div>
                  <div className="text-2xl font-bold text-gray-800 mb-1">
                    {currentTrack.enrolled.toLocaleString()}
                  </div>
                  <div className="text-sm text-gray-600">Students Enrolled</div>
                  <div className="mt-2 flex items-center justify-center gap-2">
                    <TrendingUp className="h-3 w-3 text-green-500" />
                    <span className="text-xs text-green-600 font-medium">+12% this month</span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border border-gray-200 shadow-sm hover:shadow-md transition-shadow duration-200">
            <CardContent className="p-6 text-center">
              <div className="space-y-3">
                <div className="p-3 bg-gradient-to-r from-slate-600 to-slate-700 rounded-lg w-12 h-12 flex items-center justify-center mx-auto">
                  <Star className="h-6 w-6 text-white" />
                </div>
                <div>
                  <div className="text-2xl font-bold text-gray-800 mb-1">
                    {currentTrack.rating}/5
                  </div>
                  <div className="text-sm text-gray-600">Course Rating</div>
                  <div className="mt-2 flex justify-center gap-1">
                    {[...Array(5)].map((_, i) => (
                      <Star 
                        key={i} 
                        className={`h-4 w-4 ${
                          i < Math.floor(currentTrack.rating) 
                            ? 'text-amber-400 fill-current' 
                            : 'text-gray-300'
                        }`} 
                      />
                    ))}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  };

  return (
    <PlatformLayout 
      sidebarTitle="Candidate Platform"
      sidebarSubtitle="Professional Development Hub"
      sidebarSections={candidateNavigation}
    >
      <div className="max-w-7xl mx-auto p-6 space-y-8">
        <div className="text-center space-y-4">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-gray-100 rounded-lg border border-gray-200">
            <Trophy className="h-5 w-5 text-gray-700" />
            <span className="text-sm font-medium text-gray-800">Interview Certification Hub</span>
          </div>
          <h1 className="text-3xl font-bold text-gray-800">
            Professional Certification Dashboard
          </h1>
          <p className="text-base text-gray-600 max-w-3xl mx-auto">
            Master technology stacks through comprehensive certification programs designed for career advancement
          </p>
        </div>

        <Tabs defaultValue="frontend" className="space-y-8">
          <div className="relative">
            <TabsList className="grid w-full grid-cols-5 h-12 bg-gray-50 rounded-lg p-1 border border-gray-200">
              <TabsTrigger 
                value="frontend" 
                className="flex items-center gap-2 h-10 rounded-md data-[state=active]:bg-white data-[state=active]:text-blue-700 data-[state=active]:shadow-sm data-[state=active]:font-medium transition-all duration-200"
              >
                <Monitor className="h-4 w-4" />
                <span className="text-sm">Frontend</span>
              </TabsTrigger>
              <TabsTrigger 
                value="backend" 
                className="flex items-center gap-2 h-10 rounded-md data-[state=active]:bg-white data-[state=active]:text-emerald-700 data-[state=active]:shadow-sm data-[state=active]:font-medium transition-all duration-200"
              >
                <Server className="h-4 w-4" />
                <span className="text-sm">Backend</span>
              </TabsTrigger>
              <TabsTrigger 
                value="fullstack" 
                className="flex items-center gap-2 h-10 rounded-md data-[state=active]:bg-white data-[state=active]:text-purple-700 data-[state=active]:shadow-sm data-[state=active]:font-medium transition-all duration-200"
              >
                <Layers className="h-4 w-4" />
                <span className="text-sm">Full-Stack</span>
              </TabsTrigger>
              <TabsTrigger 
                value="devops" 
                className="flex items-center gap-2 h-10 rounded-md data-[state=active]:bg-white data-[state=active]:text-orange-700 data-[state=active]:shadow-sm data-[state=active]:font-medium transition-all duration-200"
              >
                <Cloud className="h-4 w-4" />
                <span className="text-sm">DevOps</span>
              </TabsTrigger>
              <TabsTrigger 
                value="datascience" 
                className="flex items-center gap-2 h-10 rounded-md data-[state=active]:bg-white data-[state=active]:text-indigo-700 data-[state=active]:shadow-sm data-[state=active]:font-medium transition-all duration-200"
              >
                <Database className="h-4 w-4" />
                <span className="text-sm">Data Science</span>
              </TabsTrigger>
            </TabsList>
          </div>

          <TabsContent value="frontend">{renderCertificationTab('frontend')}</TabsContent>
          <TabsContent value="backend">{renderCertificationTab('backend')}</TabsContent>
          <TabsContent value="fullstack">{renderCertificationTab('fullstack')}</TabsContent>
          <TabsContent value="devops">{renderCertificationTab('devops')}</TabsContent>
          <TabsContent value="datascience">{renderCertificationTab('datascience')}</TabsContent>
        </Tabs>
      </div>
    </PlatformLayout>
  );
};

export default InterviewCertificationDashboard;