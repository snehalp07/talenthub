import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import CertificateViewer from "@/components/certificate-viewer";
import { 
  ArrowLeft,
  CheckCircle,
  Clock,
  Code,
  Award,
  BarChart3,
  FileText,
  Download,
  Share2,
  Github,
  ExternalLink,
  Star,
  GitBranch,
  Folder
} from "lucide-react";
import PlatformLayout from "@/components/layout/platform-layout";
import { platformConfigs } from "@/config/complete-navigation";

interface ProjectCertification {
  id: string;
  projectTitle: string;
  certificationTitle: string;
  description: string;
  completedDate: string;
  score: number;
  passingScore: number;
  timeSpent: number;
  difficulty: string;
  skills: string[];
  certificate: any;
  projectDetails: {
    type: string;
    technologies: string[];
    features: string[];
    codeMetrics: {
      linesOfCode: number;
      files: number;
      commits: number;
      testCoverage: number;
    };
    evaluation: {
      codeQuality: number;
      functionality: number;
      design: number;
      documentation: number;
      testing: number;
    };
  };
  submissionDetails: {
    repositoryUrl?: string;
    liveUrl?: string;
    documentation?: string;
    videoDemo?: string;
  };
}

function ProjectCertificationViewContent() {
  const [, setLocation] = useLocation();
  
  // Get certification ID from URL params
  const urlParams = new URLSearchParams(window.location.search);
  const certificationId = urlParams.get('id') || '1';

  const { data: certification, isLoading } = useQuery<ProjectCertification>({
    queryKey: [`/api/candidate/certifications/project/${certificationId}`]
  });

  // Mock data for development
  const mockCertification: ProjectCertification = {
    id: certificationId,
    projectTitle: "E-commerce React Application",
    certificationTitle: "Full-Stack Developer Project Certification",
    description: "Complete e-commerce application built with React, Node.js, and MongoDB. Features include user authentication, product catalog, shopping cart, payment integration, and admin dashboard.",
    completedDate: "2024-06-05T16:45:00Z",
    score: 95,
    passingScore: 75,
    timeSpent: 240, // 4 hours
    difficulty: "Advanced",
    skills: ["React", "Node.js", "MongoDB", "Express", "JWT", "Stripe API", "CSS", "JavaScript"],
    projectDetails: {
      type: "Full-Stack Web Application",
      technologies: ["React", "Node.js", "Express", "MongoDB", "Stripe", "JWT", "CSS3", "JavaScript ES6+"],
      features: [
        "User Authentication & Authorization",
        "Product Catalog with Search & Filtering", 
        "Shopping Cart & Checkout Process",
        "Payment Integration (Stripe)",
        "Admin Dashboard",
        "Order Management",
        "Responsive Design",
        "Email Notifications"
      ],
      codeMetrics: {
        linesOfCode: 3542,
        files: 45,
        commits: 28,
        testCoverage: 85
      },
      evaluation: {
        codeQuality: 92,
        functionality: 98,
        design: 94,
        documentation: 90,
        testing: 85
      }
    },
    submissionDetails: {
      repositoryUrl: "https://github.com/alexjohnson/ecommerce-app",
      liveUrl: "https://ecommerce-demo.alexjohnson.dev",
      documentation: "https://docs.alexjohnson.dev/ecommerce",
      videoDemo: "https://youtube.com/watch?v=demo123"
    },
    certificate: {
      id: `cert-proj-${certificationId}`,
      title: "Full-Stack Developer Project Certification",
      description: "This certification validates the ability to design, develop, and deploy a complete full-stack web application using modern technologies and best practices.",
      type: 'project',
      issuedDate: "2024-06-05T16:45:00Z",
      issuer: {
        name: "TalentHub Certification Authority",
        logo: "/api/placeholder/32/32",
        website: "https://talenthub.com"
      },
      recipient: {
        name: "Alex Johnson",
        email: "alex.johnson@email.com",
        id: "user-123"
      },
      skills: ["React", "Node.js", "MongoDB", "Express", "JWT", "Stripe API", "CSS", "JavaScript"],
      score: 95,
      passingScore: 75,
      credentialId: `TH-PROJ-${certificationId}-2024`,
      verificationUrl: `https://verify.talenthub.com/cert-proj-${certificationId}`,
      status: 'active',
      metadata: {
        duration: "4 hours",
        difficulty: "Advanced",
        topics: ["Full-Stack Development", "React", "Node.js", "Database Design", "API Integration"],
        grade: "A+"
      }
    }
  };

  const currentCertification = certification || mockCertification;

  if (isLoading) {
    return <div className="flex items-center justify-center h-64">Loading certification details...</div>;
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <Button
            variant="ghost"
            onClick={() => setLocation('/candidate/browse-certifications')}
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Certifications
          </Button>
          
          <div>
            <h1 className="text-3xl font-bold text-gray-900">{currentCertification.certificationTitle}</h1>
            <p className="text-gray-600">Project-based Certification</p>
          </div>
        </div>

        <div className="flex items-center space-x-2">
          <Button variant="outline">
            <Download className="w-4 h-4 mr-2" />
            Download
          </Button>
          <Button variant="outline">
            <Share2 className="w-4 h-4 mr-2" />
            Share
          </Button>
        </div>
      </div>

      <Tabs defaultValue="overview" className="space-y-4">
        <TabsList>
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="project">Project Details</TabsTrigger>
          <TabsTrigger value="evaluation">Evaluation</TabsTrigger>
          <TabsTrigger value="certificate">Certificate</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          {/* Quick Stats */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Final Score</CardTitle>
                <Star className="h-4 w-4 text-yellow-600" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-green-600">{currentCertification.score}%</div>
                <p className="text-xs text-muted-foreground">
                  Pass: {currentCertification.passingScore}%
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Development Time</CardTitle>
                <Clock className="h-4 w-4 text-blue-600" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{Math.floor(currentCertification.timeSpent / 60)}h</div>
                <p className="text-xs text-muted-foreground">
                  Total project time
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Code Quality</CardTitle>
                <Code className="h-4 w-4 text-green-600" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{currentCertification.projectDetails.evaluation.codeQuality}%</div>
                <p className="text-xs text-muted-foreground">
                  Code quality score
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Difficulty</CardTitle>
                <Award className="h-4 w-4 text-purple-600" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{currentCertification.difficulty}</div>
                <p className="text-xs text-muted-foreground">
                  Project complexity
                </p>
              </CardContent>
            </Card>
          </div>

          {/* Project Overview */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Project Overview</CardTitle>
                <CardDescription>{currentCertification.projectTitle}</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <h4 className="font-medium mb-2">Description</h4>
                  <p className="text-gray-600">{currentCertification.description}</p>
                </div>

                <div>
                  <h4 className="font-medium mb-2">Project Type</h4>
                  <Badge variant="outline">{currentCertification.projectDetails.type}</Badge>
                </div>

                <div>
                  <h4 className="font-medium mb-2">Completion Details</h4>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-gray-600">Completed:</span>
                      <span>{new Date(currentCertification.completedDate).toLocaleDateString()}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Development Time:</span>
                      <span>{Math.floor(currentCertification.timeSpent / 60)} hours</span>
                    </div>
                  </div>
                </div>

                {/* Project Links */}
                <div className="space-y-2">
                  {currentCertification.submissionDetails.repositoryUrl && (
                    <Button variant="outline" size="sm" className="w-full justify-start">
                      <Github className="w-4 h-4 mr-2" />
                      View Source Code
                    </Button>
                  )}
                  
                  {currentCertification.submissionDetails.liveUrl && (
                    <Button variant="outline" size="sm" className="w-full justify-start">
                      <ExternalLink className="w-4 h-4 mr-2" />
                      View Live Demo
                    </Button>
                  )}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Technologies & Skills</CardTitle>
                <CardDescription>Technical stack and competencies demonstrated</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <h4 className="font-medium mb-2">Technologies Used</h4>
                  <div className="flex flex-wrap gap-2">
                    {currentCertification.projectDetails.technologies.map((tech, index) => (
                      <Badge key={index} variant="secondary">
                        {tech}
                      </Badge>
                    ))}
                  </div>
                </div>

                <div>
                  <h4 className="font-medium mb-2">Skills Validated</h4>
                  <div className="flex flex-wrap gap-2">
                    {currentCertification.skills.map((skill, index) => (
                      <Badge key={index} variant="outline">
                        {skill}
                      </Badge>
                    ))}
                  </div>
                </div>

                <div>
                  <h4 className="font-medium mb-2">Code Metrics</h4>
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div className="flex items-center justify-between">
                      <span className="text-gray-600">Lines of Code:</span>
                      <span className="font-medium">{currentCertification.projectDetails.codeMetrics.linesOfCode.toLocaleString()}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-gray-600">Files:</span>
                      <span className="font-medium">{currentCertification.projectDetails.codeMetrics.files}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-gray-600">Commits:</span>
                      <span className="font-medium">{currentCertification.projectDetails.codeMetrics.commits}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-gray-600">Test Coverage:</span>
                      <span className="font-medium">{currentCertification.projectDetails.codeMetrics.testCoverage}%</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="project" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Folder className="w-5 h-5 mr-2" />
                Project Features & Implementation
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div>
                <h3 className="font-medium mb-4">Key Features Implemented</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {currentCertification.projectDetails.features.map((feature, index) => (
                    <div key={index} className="flex items-center space-x-2">
                      <CheckCircle className="w-4 h-4 text-green-600" />
                      <span className="text-sm">{feature}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div>
                <h3 className="font-medium mb-4">Technical Architecture</h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="p-4 bg-blue-50 rounded-lg">
                    <h4 className="font-medium text-blue-900 mb-2">Frontend</h4>
                    <ul className="text-sm text-blue-700 space-y-1">
                      <li>• React with Hooks</li>
                      <li>• Component Architecture</li>
                      <li>• State Management</li>
                      <li>• Responsive Design</li>
                    </ul>
                  </div>
                  
                  <div className="p-4 bg-green-50 rounded-lg">
                    <h4 className="font-medium text-green-900 mb-2">Backend</h4>
                    <ul className="text-sm text-green-700 space-y-1">
                      <li>• Node.js & Express</li>
                      <li>• RESTful API Design</li>
                      <li>• Authentication (JWT)</li>
                      <li>• Error Handling</li>
                    </ul>
                  </div>
                  
                  <div className="p-4 bg-purple-50 rounded-lg">
                    <h4 className="font-medium text-purple-900 mb-2">Database</h4>
                    <ul className="text-sm text-purple-700 space-y-1">
                      <li>• MongoDB</li>
                      <li>• Schema Design</li>
                      <li>• Indexing Strategy</li>
                      <li>• Data Validation</li>
                    </ul>
                  </div>
                </div>
              </div>

              {/* Submission Materials */}
              <div>
                <h3 className="font-medium mb-4">Submission Materials</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {currentCertification.submissionDetails.repositoryUrl && (
                    <Card>
                      <CardContent className="pt-4">
                        <div className="flex items-center space-x-3">
                          <Github className="w-8 h-8 text-gray-600" />
                          <div>
                            <h4 className="font-medium">Source Code Repository</h4>
                            <p className="text-sm text-gray-600">Complete project codebase</p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  )}

                  {currentCertification.submissionDetails.liveUrl && (
                    <Card>
                      <CardContent className="pt-4">
                        <div className="flex items-center space-x-3">
                          <ExternalLink className="w-8 h-8 text-gray-600" />
                          <div>
                            <h4 className="font-medium">Live Deployment</h4>
                            <p className="text-sm text-gray-600">Working application demo</p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="evaluation" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <BarChart3 className="w-5 h-5 mr-2" />
                Project Evaluation Breakdown
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div>
                <h3 className="font-medium mb-4">Evaluation Criteria</h3>
                <div className="space-y-4">
                  {Object.entries(currentCertification.projectDetails.evaluation).map(([criteria, score]) => (
                    <div key={criteria} className="flex items-center justify-between">
                      <span className="text-sm font-medium capitalize">{criteria.replace(/([A-Z])/g, ' $1').trim()}</span>
                      <div className="flex items-center space-x-2">
                        <div className="w-32 bg-gray-200 rounded-full h-2">
                          <div 
                            className="bg-blue-600 h-2 rounded-full" 
                            style={{ width: `${score}%` }}
                          ></div>
                        </div>
                        <span className="text-sm font-medium w-8">{score}%</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Feedback */}
              <div>
                <h3 className="font-medium mb-4">Evaluator Feedback</h3>
                <div className="space-y-4">
                  <div className="p-4 bg-green-50 rounded-lg border border-green-200">
                    <h4 className="font-medium text-green-900 mb-2">Strengths</h4>
                    <ul className="text-sm text-green-800 space-y-1">
                      <li>• Excellent code organization and component structure</li>
                      <li>• Comprehensive error handling and validation</li>
                      <li>• Clean and intuitive user interface design</li>
                      <li>• Proper implementation of security best practices</li>
                      <li>• Good test coverage and documentation</li>
                    </ul>
                  </div>

                  <div className="p-4 bg-blue-50 rounded-lg border border-blue-200">
                    <h4 className="font-medium text-blue-900 mb-2">Areas for Improvement</h4>
                    <ul className="text-sm text-blue-800 space-y-1">
                      <li>• Consider implementing more advanced caching strategies</li>
                      <li>• Add more comprehensive integration tests</li>
                      <li>• Explore performance optimization opportunities</li>
                    </ul>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="certificate">
          <Card>
            <CardHeader>
              <CardTitle>Official Certificate</CardTitle>
              <CardDescription>Your verified project certification document</CardDescription>
            </CardHeader>
            <CardContent>
              <CertificateViewer certificate={currentCertification.certificate} />
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}

export default function ProjectCertificationView() {
  const config = platformConfigs.candidate;
  
  const usageData = [
    { label: "Project Certifications", current: 6, max: 15 },
    { label: "Code Reviews", current: 11, max: 20 },
    { label: "Skills Validated", current: 14, max: 25 },
  ];

  return (
    <PlatformLayout
      sidebarTitle={config.sidebarTitle}
      sidebarSubtitle={config.sidebarSubtitle}
      sidebarSections={config.sidebarSections}
      usageData={usageData}
    >
      <ProjectCertificationViewContent />
    </PlatformLayout>
  );
}