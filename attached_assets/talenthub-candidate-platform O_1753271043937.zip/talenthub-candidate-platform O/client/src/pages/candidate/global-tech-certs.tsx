import PlatformLayout from "@/components/layout/platform-layout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Globe, Award, TrendingUp, Users, Star, Building } from "lucide-react";
import { candidateNavigation } from "@/config/complete-navigation";

export default function GlobalTechCerts() {
  return (
    <PlatformLayout 
      sidebarTitle="Candidate Platform"
      sidebarSubtitle="Professional Development Hub"
      sidebarSections={candidateNavigation}
    >
      <div className="max-w-7xl mx-auto p-6 space-y-8">
        <div className="text-center space-y-4">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-blue-100 to-cyan-100 rounded-full">
            <Globe className="h-5 w-5 text-blue-600" />
            <span className="text-sm font-medium text-blue-900">Global Tech Certifications</span>
          </div>
          <h1 className="text-4xl font-bold bg-gradient-to-r from-blue-600 to-cyan-600 bg-clip-text text-transparent">
            Worldwide Tech Certification Analytics
          </h1>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            Track global certification trends, industry demand, and career impact across technology domains
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <Card className="hover:shadow-md transition-shadow">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="p-3 rounded-lg bg-blue-500 text-white">
                  <Award className="h-6 w-6" />
                </div>
                <div className="text-2xl font-bold text-blue-600">247</div>
              </div>
              <div className="text-sm text-gray-600">Active Global Certifications</div>
            </CardContent>
          </Card>

          <Card className="hover:shadow-md transition-shadow">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="p-3 rounded-lg bg-green-500 text-white">
                  <TrendingUp className="h-6 w-6" />
                </div>
                <div className="text-2xl font-bold text-green-600">+23%</div>
              </div>
              <div className="text-sm text-gray-600">Annual Growth Rate</div>
            </CardContent>
          </Card>

          <Card className="hover:shadow-md transition-shadow">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="p-3 rounded-lg bg-purple-500 text-white">
                  <Users className="h-6 w-6" />
                </div>
                <div className="text-2xl font-bold text-purple-600">2.4M</div>
              </div>
              <div className="text-sm text-gray-600">Certified Professionals</div>
            </CardContent>
          </Card>

          <Card className="hover:shadow-md transition-shadow">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="p-3 rounded-lg bg-orange-500 text-white">
                  <Building className="h-6 w-6" />
                </div>
                <div className="text-2xl font-bold text-orange-600">156</div>
              </div>
              <div className="text-sm text-gray-600">Issuing Organizations</div>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="trending" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="trending">Trending Certifications</TabsTrigger>
            <TabsTrigger value="providers">Top Providers</TabsTrigger>
            <TabsTrigger value="regions">Regional Demand</TabsTrigger>
            <TabsTrigger value="salary">Salary Impact</TabsTrigger>
          </TabsList>

          <TabsContent value="trending" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              <Card className="border-blue-200">
                <CardHeader>
                  <div className="flex justify-between items-start">
                    <div>
                      <CardTitle className="text-lg">AWS Certified Solutions Architect</CardTitle>
                      <CardDescription>Amazon Web Services</CardDescription>
                    </div>
                    <Badge className="bg-green-100 text-green-700">+156% demand</Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex justify-between text-sm">
                      <span>Global professionals</span>
                      <span className="font-medium">847,293</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>Avg salary increase</span>
                      <span className="font-medium">+$18,500</span>
                    </div>
                    <Progress value={92} className="h-2" />
                    <div className="flex items-center gap-2">
                      <Star className="h-4 w-4 text-yellow-500" />
                      <span className="text-sm">4.8/5 career impact</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-purple-200">
                <CardHeader>
                  <div className="flex justify-between items-start">
                    <div>
                      <CardTitle className="text-lg">Google Cloud Professional</CardTitle>
                      <CardDescription>Google Cloud Platform</CardDescription>
                    </div>
                    <Badge className="bg-blue-100 text-blue-700">+134% demand</Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex justify-between text-sm">
                      <span>Global professionals</span>
                      <span className="font-medium">623,847</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>Avg salary increase</span>
                      <span className="font-medium">+$16,200</span>
                    </div>
                    <Progress value={87} className="h-2" />
                    <div className="flex items-center gap-2">
                      <Star className="h-4 w-4 text-yellow-500" />
                      <span className="text-sm">4.7/5 career impact</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-orange-200">
                <CardHeader>
                  <div className="flex justify-between items-start">
                    <div>
                      <CardTitle className="text-lg">Certified Kubernetes Administrator</CardTitle>
                      <CardDescription>Cloud Native Computing Foundation</CardDescription>
                    </div>
                    <Badge className="bg-purple-100 text-purple-700">+289% demand</Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex justify-between text-sm">
                      <span>Global professionals</span>
                      <span className="font-medium">234,567</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>Avg salary increase</span>
                      <span className="font-medium">+$22,800</span>
                    </div>
                    <Progress value={95} className="h-2" />
                    <div className="flex items-center gap-2">
                      <Star className="h-4 w-4 text-yellow-500" />
                      <span className="text-sm">4.9/5 career impact</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-green-200">
                <CardHeader>
                  <div className="flex justify-between items-start">
                    <div>
                      <CardTitle className="text-lg">Azure DevOps Engineer Expert</CardTitle>
                      <CardDescription>Microsoft Azure</CardDescription>
                    </div>
                    <Badge className="bg-orange-100 text-orange-700">+178% demand</Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex justify-between text-sm">
                      <span>Global professionals</span>
                      <span className="font-medium">456,123</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>Avg salary increase</span>
                      <span className="font-medium">+$19,700</span>
                    </div>
                    <Progress value={89} className="h-2" />
                    <div className="flex items-center gap-2">
                      <Star className="h-4 w-4 text-yellow-500" />
                      <span className="text-sm">4.6/5 career impact</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-cyan-200">
                <CardHeader>
                  <div className="flex justify-between items-start">
                    <div>
                      <CardTitle className="text-lg">Certified Ethical Hacker</CardTitle>
                      <CardDescription>EC-Council</CardDescription>
                    </div>
                    <Badge className="bg-red-100 text-red-700">+245% demand</Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex justify-between text-sm">
                      <span>Global professionals</span>
                      <span className="font-medium">189,456</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>Avg salary increase</span>
                      <span className="font-medium">+$26,400</span>
                    </div>
                    <Progress value={97} className="h-2" />
                    <div className="flex items-center gap-2">
                      <Star className="h-4 w-4 text-yellow-500" />
                      <span className="text-sm">4.8/5 career impact</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-indigo-200">
                <CardHeader>
                  <div className="flex justify-between items-start">
                    <div>
                      <CardTitle className="text-lg">TensorFlow Developer Certificate</CardTitle>
                      <CardDescription>Google AI</CardDescription>
                    </div>
                    <Badge className="bg-emerald-100 text-emerald-700">+312% demand</Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex justify-between text-sm">
                      <span>Global professionals</span>
                      <span className="font-medium">156,789</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>Avg salary increase</span>
                      <span className="font-medium">+$28,900</span>
                    </div>
                    <Progress value={94} className="h-2" />
                    <div className="flex items-center gap-2">
                      <Star className="h-4 w-4 text-yellow-500" />
                      <span className="text-sm">4.9/5 career impact</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="providers" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Top Certification Providers</CardTitle>
                  <CardDescription>Leading organizations by market share and career impact</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between p-3 bg-blue-50 rounded-lg">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center text-white text-sm font-bold">1</div>
                      <div>
                        <div className="font-medium">Amazon Web Services</div>
                        <div className="text-sm text-gray-600">Cloud Computing</div>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="font-bold text-blue-600">1.2M+ certified</div>
                      <div className="text-sm text-gray-600">32% market share</div>
                    </div>
                  </div>

                  <div className="flex items-center justify-between p-3 bg-green-50 rounded-lg">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 bg-green-500 rounded-full flex items-center justify-center text-white text-sm font-bold">2</div>
                      <div>
                        <div className="font-medium">Microsoft</div>
                        <div className="text-sm text-gray-600">Azure & Office 365</div>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="font-bold text-green-600">980K+ certified</div>
                      <div className="text-sm text-gray-600">26% market share</div>
                    </div>
                  </div>

                  <div className="flex items-center justify-between p-3 bg-purple-50 rounded-lg">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 bg-purple-500 rounded-full flex items-center justify-center text-white text-sm font-bold">3</div>
                      <div>
                        <div className="font-medium">Google Cloud</div>
                        <div className="text-sm text-gray-600">GCP & AI/ML</div>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="font-bold text-purple-600">650K+ certified</div>
                      <div className="text-sm text-gray-600">17% market share</div>
                    </div>
                  </div>

                  <div className="flex items-center justify-between p-3 bg-orange-50 rounded-lg">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 bg-orange-500 rounded-full flex items-center justify-center text-white text-sm font-bold">4</div>
                      <div>
                        <div className="font-medium">Oracle</div>
                        <div className="text-sm text-gray-600">Database & Java</div>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="font-bold text-orange-600">420K+ certified</div>
                      <div className="text-sm text-gray-600">11% market share</div>
                    </div>
                  </div>

                  <div className="flex items-center justify-between p-3 bg-cyan-50 rounded-lg">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 bg-cyan-500 rounded-full flex items-center justify-center text-white text-sm font-bold">5</div>
                      <div>
                        <div className="font-medium">Cisco</div>
                        <div className="text-sm text-gray-600">Networking & Security</div>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="font-bold text-cyan-600">380K+ certified</div>
                      <div className="text-sm text-gray-600">10% market share</div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Fastest Growing Domains</CardTitle>
                  <CardDescription>Technology areas with highest certification growth</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-3">
                    <div className="flex justify-between items-center">
                      <span className="text-sm font-medium">Artificial Intelligence & ML</span>
                      <span className="text-sm text-green-600 font-bold">+387%</span>
                    </div>
                    <Progress value={95} className="h-2" />
                  </div>

                  <div className="space-y-3">
                    <div className="flex justify-between items-center">
                      <span className="text-sm font-medium">Cybersecurity</span>
                      <span className="text-sm text-green-600 font-bold">+298%</span>
                    </div>
                    <Progress value={87} className="h-2" />
                  </div>

                  <div className="space-y-3">
                    <div className="flex justify-between items-center">
                      <span className="text-sm font-medium">Cloud Architecture</span>
                      <span className="text-sm text-green-600 font-bold">+245%</span>
                    </div>
                    <Progress value={78} className="h-2" />
                  </div>

                  <div className="space-y-3">
                    <div className="flex justify-between items-center">
                      <span className="text-sm font-medium">DevOps & Site Reliability</span>
                      <span className="text-sm text-green-600 font-bold">+223%</span>
                    </div>
                    <Progress value={71} className="h-2" />
                  </div>

                  <div className="space-y-3">
                    <div className="flex justify-between items-center">
                      <span className="text-sm font-medium">Data Engineering</span>
                      <span className="text-sm text-green-600 font-bold">+189%</span>
                    </div>
                    <Progress value={65} className="h-2" />
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="regions" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>North America</CardTitle>
                  <CardDescription>Leading in cloud and AI certifications</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="text-center">
                    <div className="text-3xl font-bold text-blue-600">1.2M</div>
                    <div className="text-sm text-gray-600">Certified professionals</div>
                  </div>
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>AWS Solutions Architect</span>
                      <span className="font-medium">23%</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>Azure Administrator</span>
                      <span className="font-medium">18%</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>Google Cloud Professional</span>
                      <span className="font-medium">15%</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Europe</CardTitle>
                  <CardDescription>Strong focus on data protection and security</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="text-center">
                    <div className="text-3xl font-bold text-green-600">890K</div>
                    <div className="text-sm text-gray-600">Certified professionals</div>
                  </div>
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>CISSP Security</span>
                      <span className="font-medium">21%</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>Azure Security Engineer</span>
                      <span className="font-medium">19%</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>Certified Ethical Hacker</span>
                      <span className="font-medium">16%</span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Asia Pacific</CardTitle>
                  <CardDescription>Rapid growth in cloud and DevOps</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="text-center">
                    <div className="text-3xl font-bold text-purple-600">750K</div>
                    <div className="text-sm text-gray-600">Certified professionals</div>
                  </div>
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>Kubernetes Administrator</span>
                      <span className="font-medium">25%</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>AWS Developer</span>
                      <span className="font-medium">22%</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>TensorFlow Developer</span>
                      <span className="font-medium">18%</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="salary" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Highest Salary Impact Certifications</CardTitle>
                  <CardDescription>Average salary increase after certification</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between p-3 bg-green-50 rounded-lg">
                    <div>
                      <div className="font-medium">AWS Solutions Architect Professional</div>
                      <div className="text-sm text-gray-600">Senior Level</div>
                    </div>
                    <div className="text-right">
                      <div className="font-bold text-green-600">+$32,400</div>
                      <div className="text-sm text-gray-600">avg increase</div>
                    </div>
                  </div>

                  <div className="flex items-center justify-between p-3 bg-blue-50 rounded-lg">
                    <div>
                      <div className="font-medium">Google Cloud Architect</div>
                      <div className="text-sm text-gray-600">Professional Level</div>
                    </div>
                    <div className="text-right">
                      <div className="font-bold text-blue-600">+$29,800</div>
                      <div className="text-sm text-gray-600">avg increase</div>
                    </div>
                  </div>

                  <div className="flex items-center justify-between p-3 bg-purple-50 rounded-lg">
                    <div>
                      <div className="font-medium">Certified Kubernetes Expert</div>
                      <div className="text-sm text-gray-600">Expert Level</div>
                    </div>
                    <div className="text-right">
                      <div className="font-bold text-purple-600">+$28,600</div>
                      <div className="text-sm text-gray-600">avg increase</div>
                    </div>
                  </div>

                  <div className="flex items-center justify-between p-3 bg-orange-50 rounded-lg">
                    <div>
                      <div className="font-medium">CISSP Security Professional</div>
                      <div className="text-sm text-gray-600">Expert Level</div>
                    </div>
                    <div className="text-right">
                      <div className="font-bold text-orange-600">+$27,200</div>
                      <div className="text-sm text-gray-600">avg increase</div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Salary Ranges by Experience</CardTitle>
                  <CardDescription>Annual compensation with certifications</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-3">
                    <div className="flex justify-between items-center">
                      <span className="text-sm font-medium">Entry Level (0-2 years)</span>
                      <span className="text-sm font-bold">$65K - $85K</span>
                    </div>
                    <Progress value={35} className="h-2" />
                  </div>

                  <div className="space-y-3">
                    <div className="flex justify-between items-center">
                      <span className="text-sm font-medium">Mid Level (3-5 years)</span>
                      <span className="text-sm font-bold">$95K - $125K</span>
                    </div>
                    <Progress value={55} className="h-2" />
                  </div>

                  <div className="space-y-3">
                    <div className="flex justify-between items-center">
                      <span className="text-sm font-medium">Senior Level (6-10 years)</span>
                      <span className="text-sm font-bold">$135K - $175K</span>
                    </div>
                    <Progress value={75} className="h-2" />
                  </div>

                  <div className="space-y-3">
                    <div className="flex justify-between items-center">
                      <span className="text-sm font-medium">Expert Level (10+ years)</span>
                      <span className="text-sm font-bold">$185K - $250K</span>
                    </div>
                    <Progress value={95} className="h-2" />
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </PlatformLayout>
  );
}