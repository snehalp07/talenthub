import { useState } from "react";
import { useAuth } from "@/hooks/use-auth";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import PlatformLayout from "@/components/layout/platform-layout";
import { platformConfigs } from "@/config/complete-navigation";
import { useThemeClasses } from "@/lib/theme-config";
import { 
  FileText, 
  CheckCircle, 
  AlertTriangle, 
  Lightbulb, 
  Star, 
  Download,
  Eye,
  BookOpen,
  Target,
  TrendingUp,
  Award,
  Brain,
  Zap,
  BarChart3
} from "lucide-react";

function ResumeTipsContent() {
  const { user } = useAuth();
  const [selectedTemplate, setSelectedTemplate] = useState("modern");

  const { data: resumeAnalysis } = useQuery({
    queryKey: ["/api/resume/analysis"],
    initialData: {
      score: 78,
      strengths: [
        "Strong technical skills section",
        "Quantified achievements",
        "Clean formatting",
        "Relevant work experience"
      ],
      improvements: [
        "Add more action verbs",
        "Include soft skills",
        "Optimize for ATS scanning",
        "Add portfolio links"
      ],
      sections: {
        contact: { score: 90, status: "excellent" },
        summary: { score: 75, status: "good" },
        experience: { score: 80, status: "good" },
        skills: { score: 85, status: "excellent" },
        education: { score: 70, status: "average" },
        projects: { score: 60, status: "needs_improvement" }
      }
    }
  });

  const { data: industryTips } = useQuery({
    queryKey: ["/api/resume/industry-tips"],
    initialData: [
      {
        category: "Technical Skills",
        tips: [
          "List programming languages in order of proficiency",
          "Include specific frameworks and libraries you've used",
          "Mention years of experience with each technology",
          "Add certifications and their validity dates"
        ]
      },
      {
        category: "Project Descriptions",
        tips: [
          "Start each bullet with a strong action verb",
          "Quantify impact wherever possible (e.g., '20% performance improvement')",
          "Mention team size and your role",
          "Include technologies used and challenges overcome"
        ]
      },
      {
        category: "Work Experience",
        tips: [
          "Focus on achievements, not just responsibilities",
          "Use the STAR method (Situation, Task, Action, Result)",
          "Tailor experience to match job requirements",
          "Include relevant internships and freelance work"
        ]
      }
    ]
  });

  const templates = [
    {
      id: "modern",
      name: "Modern Professional",
      description: "Clean, contemporary design perfect for tech roles",
      preview: "/templates/modern.jpg",
      atsScore: 95,
      industries: ["Technology", "Startups", "Digital Marketing"]
    },
    {
      id: "executive",
      name: "Executive",
      description: "Sophisticated layout for senior positions", 
      preview: "/templates/executive.jpg",
      atsScore: 90,
      industries: ["Finance", "Consulting", "Management"]
    },
    {
      id: "creative",
      name: "Creative Portfolio",
      description: "Visually appealing for design and creative roles",
      preview: "/templates/creative.jpg",
      atsScore: 75,
      industries: ["Design", "Marketing", "Media"]
    }
  ];

  const getScoreColor = (score: number) => {
    if (score >= 80) return "text-green-600";
    if (score >= 60) return "text-yellow-600";
    return "text-red-600";
  };

  const getStatusBadge = (status: string) => {
    const variants = {
      excellent: "bg-green-100 text-green-800",
      good: "bg-blue-100 text-blue-800", 
      average: "bg-yellow-100 text-yellow-800",
      needs_improvement: "bg-red-100 text-red-800"
    };
    return variants[status as keyof typeof variants] || variants.average;
  };

  return (
    <div className="max-w-7xl mx-auto p-6">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Resume Enhancement</h1>
        <p className="text-muted-foreground">AI-powered resume analysis and optimization tips</p>
      </div>

      <Tabs defaultValue="analysis" className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="analysis">AI Analysis</TabsTrigger>
          <TabsTrigger value="tips">Industry Tips</TabsTrigger>
          <TabsTrigger value="templates">Templates</TabsTrigger>
          <TabsTrigger value="examples">Examples</TabsTrigger>
        </TabsList>

        <TabsContent value="analysis" className="space-y-6">
          {/* Overall Score */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Target className="w-5 h-5 mr-2 text-sky-600" />
                Resume Score Analysis
              </CardTitle>
              <CardDescription>
                AI-powered evaluation of your resume effectiveness
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between mb-4">
                <div>
                  <div className={`text-4xl font-bold ${getScoreColor(resumeAnalysis.score)}`}>
                    {resumeAnalysis.score}/100
                  </div>
                  <p className="text-sm text-gray-600">Overall Resume Score</p>
                </div>
                <div className="text-right">
                  <Badge className="bg-sky-100 text-sky-800 mb-2">
                    Above Average
                  </Badge>
                  <p className="text-xs text-gray-500">Top 25% of candidates</p>
                </div>
              </div>
              <Progress value={resumeAnalysis.score} className="mb-4" />
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <h4 className="font-medium text-green-600 mb-2 flex items-center">
                    <CheckCircle className="w-4 h-4 mr-1" />
                    Strengths
                  </h4>
                  <ul className="space-y-1">
                    {resumeAnalysis.strengths.map((strength: string, index: number) => (
                      <li key={index} className="text-sm text-gray-600 flex items-start">
                        <span className="w-1 h-1 bg-green-500 rounded-full mt-2 mr-2 flex-shrink-0"></span>
                        {strength}
                      </li>
                    ))}
                  </ul>
                </div>
                <div>
                  <h4 className="font-medium text-orange-600 mb-2 flex items-center">
                    <AlertTriangle className="w-4 h-4 mr-1" />
                    Areas for Improvement
                  </h4>
                  <ul className="space-y-1">
                    {resumeAnalysis.improvements.map((improvement: string, index: number) => (
                      <li key={index} className="text-sm text-gray-600 flex items-start">
                        <span className="w-1 h-1 bg-orange-500 rounded-full mt-2 mr-2 flex-shrink-0"></span>
                        {improvement}
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Section Analysis */}
          <Card>
            <CardHeader>
              <CardTitle>Section-by-Section Analysis</CardTitle>
              <CardDescription>
                Detailed breakdown of each resume section
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {Object.entries(resumeAnalysis.sections).map(([section, data]: [string, any]) => (
                  <div key={section} className="p-4 bg-gray-50 rounded-lg">
                    <div className="flex items-center justify-between mb-2">
                      <h4 className="font-medium capitalize">{section.replace('_', ' ')}</h4>
                      <Badge className={getStatusBadge(data.status)}>
                        {data.status.replace('_', ' ')}
                      </Badge>
                    </div>
                    <div className="flex items-center">
                      <div className={`text-lg font-bold ${getScoreColor(data.score)} mr-2`}>
                        {data.score}%
                      </div>
                      <Progress value={data.score} className="flex-1" />
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="tips" className="space-y-6">
          <div className="grid gap-6">
            {industryTips.map((category: any, index: number) => (
              <Card key={index}>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Lightbulb className="w-5 h-5 mr-2 text-yellow-500" />
                    {category.category}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-3">
                    {category.tips.map((tip: string, tipIndex: number) => (
                      <li key={tipIndex} className="flex items-start">
                        <Star className="w-4 h-4 text-yellow-500 mr-2 mt-0.5 flex-shrink-0" />
                        <span className="text-gray-700">{tip}</span>
                      </li>
                    ))}
                  </ul>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* ATS Optimization Tips */}
          <Card className="bg-gradient-to-br from-blue-50 to-sky-50 border-blue-200">
            <CardHeader>
              <CardTitle className="flex items-center text-blue-800">
                <TrendingUp className="w-5 h-5 mr-2" />
                ATS Optimization Tips
              </CardTitle>
              <CardDescription className="text-blue-700">
                Ensure your resume passes Applicant Tracking Systems
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <h4 className="font-medium text-blue-800 mb-2">Keywords</h4>
                  <ul className="text-sm text-blue-700 space-y-1">
                    <li>• Use job-specific keywords from the posting</li>
                    <li>• Include both spelled-out and abbreviated terms</li>
                    <li>• Match exact phrases when possible</li>
                  </ul>
                </div>
                <div>
                  <h4 className="font-medium text-blue-800 mb-2">Formatting</h4>
                  <ul className="text-sm text-blue-700 space-y-1">
                    <li>• Use standard section headings</li>
                    <li>• Avoid images, graphics, or tables</li>
                    <li>• Stick to common fonts (Arial, Calibri)</li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="templates" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {templates.map((template) => (
              <Card key={template.id} className={`cursor-pointer transition-all ${selectedTemplate === template.id ? 'ring-2 ring-sky-500' : ''}`}>
                <CardHeader>
                  <div className="aspect-[3/4] bg-gray-100 rounded-lg mb-4 flex items-center justify-center">
                    <FileText className="w-16 h-16 text-gray-400" />
                  </div>
                  <CardTitle className="text-lg">{template.name}</CardTitle>
                  <CardDescription>{template.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-gray-600">ATS Score</span>
                      <Badge className="bg-green-100 text-green-800">
                        {template.atsScore}%
                      </Badge>
                    </div>
                    <div>
                      <span className="text-sm text-gray-600 block mb-1">Best for:</span>
                      <div className="flex flex-wrap gap-1">
                        {template.industries.map((industry) => (
                          <Badge key={industry} variant="outline" className="text-xs">
                            {industry}
                          </Badge>
                        ))}
                      </div>
                    </div>
                    <div className="flex gap-2 pt-2">
                      <Button 
                        size="sm" 
                        variant="outline"
                        onClick={() => setSelectedTemplate(template.id)}
                      >
                        <Eye className="w-3 h-3 mr-1" />
                        Preview
                      </Button>
                      <Button size="sm" className="bg-sky-500 hover:bg-sky-600">
                        <Download className="w-3 h-3 mr-1" />
                        Use Template
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="examples" className="space-y-6">
          <div className="grid gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Award className="w-5 h-5 mr-2 text-yellow-500" />
                  Before & After Examples
                </CardTitle>
                <CardDescription>
                  See how our recommendations transform resumes
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  <div>
                    <h4 className="font-medium text-red-600 mb-3">❌ Before (Score: 45/100)</h4>
                    <div className="bg-red-50 p-4 rounded-lg border border-red-200">
                      <p className="text-sm text-gray-700 mb-2">
                        <strong>Experience:</strong><br />
                        "Worked on various projects using different technologies."
                      </p>
                      <p className="text-xs text-red-600">
                        Too vague, no quantification, no specific achievements
                      </p>
                    </div>
                  </div>
                  <div>
                    <h4 className="font-medium text-green-600 mb-3">✅ After (Score: 85/100)</h4>
                    <div className="bg-green-50 p-4 rounded-lg border border-green-200">
                      <p className="text-sm text-gray-700 mb-2">
                        <strong>Experience:</strong><br />
                        "Led development of 3 React.js applications serving 10K+ users, improving load times by 40% through code optimization and implementing responsive design."
                      </p>
                      <p className="text-xs text-green-600">
                        Specific, quantified, shows impact and technical skills
                      </p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Industry-Specific Examples</CardTitle>
              </CardHeader>
              <CardContent>
                <Tabs defaultValue="software" className="space-y-4">
                  <TabsList>
                    <TabsTrigger value="software">Software Development</TabsTrigger>
                    <TabsTrigger value="data">Data Science</TabsTrigger>
                    <TabsTrigger value="design">UI/UX Design</TabsTrigger>
                  </TabsList>
                  
                  <TabsContent value="software">
                    <div className="space-y-4">
                      <div className="p-4 bg-sky-50 rounded-lg">
                        <h5 className="font-medium mb-2">Strong Technical Summary</h5>
                        <p className="text-sm text-gray-700">
                          "Full-stack developer with 5+ years experience building scalable web applications. 
                          Proficient in React, Node.js, and Python. Led teams of 4+ developers and delivered 
                          15+ successful projects with 99.9% uptime."
                        </p>
                      </div>
                      <div className="p-4 bg-sky-50 rounded-lg">
                        <h5 className="font-medium mb-2">Project Description Example</h5>
                        <p className="text-sm text-gray-700">
                          "Developed real-time chat application using Socket.io and React, supporting 500+ 
                          concurrent users with sub-100ms message delivery. Implemented Redis caching, 
                          reducing database load by 60%."
                        </p>
                      </div>
                    </div>
                  </TabsContent>
                  
                  <TabsContent value="data">
                    <div className="space-y-4">
                      <div className="p-4 bg-green-50 rounded-lg">
                        <h5 className="font-medium mb-2">Data Science Achievement</h5>
                        <p className="text-sm text-gray-700">
                          "Built machine learning model to predict customer churn with 94% accuracy, 
                          resulting in $2M revenue retention. Used Python, scikit-learn, and deployed 
                          on AWS with real-time inference capabilities."
                        </p>
                      </div>
                    </div>
                  </TabsContent>
                  
                  <TabsContent value="design">
                    <div className="space-y-4">
                      <div className="p-4 bg-purple-50 rounded-lg">
                        <h5 className="font-medium mb-2">Design Impact Statement</h5>
                        <p className="text-sm text-gray-700">
                          "Redesigned e-commerce checkout flow, increasing conversion rate by 25% and 
                          reducing cart abandonment by 30%. Conducted user research with 200+ participants 
                          and A/B tested 5 design variants."
                        </p>
                      </div>
                    </div>
                  </TabsContent>
                </Tabs>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}

export default function ResumeTips() {
  const config = platformConfigs.candidate;
  const theme = useThemeClasses('candidate');
  
  const usageData = [
    { label: "Resume Score", current: 87, max: 100 },
    { label: "Tips Applied", current: 12, max: 20 },
    { label: "Profile Completeness", current: 78, max: 100 },
  ];

  return (
    <PlatformLayout
      sidebarTitle={config.sidebarTitle}
      sidebarSubtitle={config.sidebarSubtitle}
      sidebarSections={config.sidebarSections}
      usageData={usageData}
    >
      <ResumeTipsContent />
    </PlatformLayout>
  );
}