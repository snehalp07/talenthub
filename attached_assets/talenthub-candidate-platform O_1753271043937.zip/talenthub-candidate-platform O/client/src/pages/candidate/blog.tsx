import PlatformLayout from "@/components/layout/platform-layout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { PenTool, Eye, Heart, MessageCircle, Share2, Calendar, TrendingUp, Edit3, Plus, Search } from "lucide-react";
import { platformConfigs } from "@/config/complete-navigation";

export default function Blog() {
  const config = platformConfigs.candidate;
  
  const myPosts = [
    {
      id: 1,
      title: "The Future of Remote Work: Lessons from 2024",
      excerpt: "Exploring how remote work has evolved and what it means for career development...",
      category: "Career Development",
      publishedAt: "2024-06-15",
      views: 1247,
      likes: 89,
      comments: 23,
      status: "published",
      readTime: "5 min read"
    },
    {
      id: 2,
      title: "Building Scalable React Applications: Best Practices",
      excerpt: "A comprehensive guide to architecting React apps that can grow with your team...",
      category: "Technology",
      publishedAt: "2024-06-10",
      views: 2156,
      likes: 134,
      comments: 41,
      status: "published",
      readTime: "8 min read"
    },
    {
      id: 3,
      title: "Leadership in Tech: My Journey from Developer to Manager",
      excerpt: "Sharing insights from my transition into technical leadership...",
      category: "Leadership",
      publishedAt: null,
      views: 0,
      likes: 0,
      comments: 0,
      status: "draft",
      readTime: "6 min read"
    }
  ];

  const trendingTopics = [
    { tag: "Remote Work", posts: 234 },
    { tag: "AI in Tech", posts: 189 },
    { tag: "Career Growth", posts: 156 },
    { tag: "Leadership", posts: 98 },
    { tag: "Web Development", posts: 267 }
  ];

  const featuredPosts = [
    {
      id: 4,
      title: "How AI is Transforming Software Development",
      author: "Sarah Chen",
      authorAvatar: "/api/placeholder/40/40",
      category: "Technology",
      publishedAt: "2024-06-18",
      views: 3420,
      likes: 298,
      readTime: "7 min read"
    },
    {
      id: 5,
      title: "Building Your Personal Brand as a Developer",
      author: "Michael Rodriguez",
      authorAvatar: "/api/placeholder/40/40",
      category: "Career",
      publishedAt: "2024-06-17",
      views: 2876,
      likes: 201,
      readTime: "5 min read"
    }
  ];

  return (
    <PlatformLayout
      sidebarTitle={config.sidebarTitle}
      sidebarSubtitle={config.sidebarSubtitle}
      sidebarSections={config.sidebarSections}
      usageData={config.usageData}
    >
      <div className="space-y-6">
        {/* Blog Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card className="bg-gradient-to-br from-blue-50 to-blue-100 border-blue-200">
            <CardHeader className="pb-2">
              <CardTitle className="text-lg text-blue-700">Total Views</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-blue-800">12.4K</div>
              <p className="text-sm text-blue-600">+23% this month</p>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-green-50 to-green-100 border-green-200">
            <CardHeader className="pb-2">
              <CardTitle className="text-lg text-green-700">Published Posts</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-green-800">18</div>
              <p className="text-sm text-green-600">2 this month</p>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-purple-50 to-purple-100 border-purple-200">
            <CardHeader className="pb-2">
              <CardTitle className="text-lg text-purple-700">Followers</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-purple-800">847</div>
              <p className="text-sm text-purple-600">+38 this week</p>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-orange-50 to-orange-100 border-orange-200">
            <CardHeader className="pb-2">
              <CardTitle className="text-lg text-orange-700">Engagement Rate</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-orange-800">8.2%</div>
              <p className="text-sm text-orange-600">above average</p>
            </CardContent>
          </Card>
        </div>

        {/* Quick Actions */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <PenTool className="h-5 w-5 text-blue-600" />
              Create Content
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex gap-4">
              <Button className="bg-blue-600 hover:bg-blue-700">
                <Plus className="h-4 w-4 mr-2" />
                New Post
              </Button>
              <Button variant="outline">
                <Edit3 className="h-4 w-4 mr-2" />
                Continue Draft
              </Button>
              <Button variant="outline">
                <Search className="h-4 w-4 mr-2" />
                Browse Topics
              </Button>
            </div>
          </CardContent>
        </Card>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Main Content */}
          <div className="lg:col-span-2">
            <Tabs defaultValue="my-posts" className="w-full">
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="my-posts">My Posts</TabsTrigger>
                <TabsTrigger value="drafts">Drafts (1)</TabsTrigger>
                <TabsTrigger value="analytics">Analytics</TabsTrigger>
              </TabsList>

              <TabsContent value="my-posts" className="space-y-4">
                <div className="space-y-4">
                  {myPosts.filter(post => post.status === 'published').map((post) => (
                    <Card key={post.id} className="hover:shadow-md transition-shadow">
                      <CardContent className="p-6">
                        <div className="space-y-3">
                          <div className="flex justify-between items-start">
                            <Badge variant="secondary" className="bg-blue-100 text-blue-800">
                              {post.category}
                            </Badge>
                            <span className="text-sm text-gray-500">{post.readTime}</span>
                          </div>
                          <h3 className="text-xl font-semibold hover:text-blue-600 cursor-pointer">
                            {post.title}
                          </h3>
                          <p className="text-gray-600">{post.excerpt}</p>
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-4 text-sm text-gray-500">
                              <div className="flex items-center gap-1">
                                <Calendar className="h-4 w-4" />
                                {post.publishedAt}
                              </div>
                              <div className="flex items-center gap-1">
                                <Eye className="h-4 w-4" />
                                {post.views.toLocaleString()}
                              </div>
                              <div className="flex items-center gap-1">
                                <Heart className="h-4 w-4" />
                                {post.likes}
                              </div>
                              <div className="flex items-center gap-1">
                                <MessageCircle className="h-4 w-4" />
                                {post.comments}
                              </div>
                            </div>
                            <div className="flex gap-2">
                              <Button variant="outline" size="sm">
                                <Edit3 className="h-4 w-4 mr-1" />
                                Edit
                              </Button>
                              <Button variant="outline" size="sm">
                                <Share2 className="h-4 w-4 mr-1" />
                                Share
                              </Button>
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </TabsContent>

              <TabsContent value="drafts" className="space-y-4">
                <div className="space-y-4">
                  {myPosts.filter(post => post.status === 'draft').map((post) => (
                    <Card key={post.id} className="border-dashed border-2 hover:shadow-md transition-shadow">
                      <CardContent className="p-6">
                        <div className="space-y-3">
                          <div className="flex justify-between items-start">
                            <Badge variant="outline" className="border-orange-300 text-orange-600">
                              Draft
                            </Badge>
                            <span className="text-sm text-gray-500">{post.readTime}</span>
                          </div>
                          <h3 className="text-xl font-semibold text-gray-700">
                            {post.title}
                          </h3>
                          <p className="text-gray-600">{post.excerpt}</p>
                          <div className="flex gap-2">
                            <Button className="bg-blue-600 hover:bg-blue-700" size="sm">
                              <Edit3 className="h-4 w-4 mr-1" />
                              Continue Writing
                            </Button>
                            <Button variant="outline" size="sm">
                              Preview
                            </Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </TabsContent>

              <TabsContent value="analytics" className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <TrendingUp className="h-5 w-5 text-green-600" />
                      Content Performance
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="grid grid-cols-2 gap-4">
                        <div className="p-4 bg-blue-50 rounded-lg">
                          <div className="text-2xl font-bold text-blue-800">3,403</div>
                          <div className="text-sm text-blue-600">Total Views (30 days)</div>
                        </div>
                        <div className="p-4 bg-green-50 rounded-lg">
                          <div className="text-2xl font-bold text-green-800">423</div>
                          <div className="text-sm text-green-600">Total Likes (30 days)</div>
                        </div>
                      </div>
                      <div className="space-y-2">
                        <h4 className="font-medium">Top Performing Posts</h4>
                        <div className="space-y-2">
                          {myPosts.filter(post => post.status === 'published').map((post) => (
                            <div key={post.id} className="flex justify-between items-center p-2 bg-gray-50 rounded">
                              <span className="text-sm font-medium">{post.title}</span>
                              <span className="text-sm text-gray-600">{post.views} views</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Trending Topics */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Trending Topics</CardTitle>
                <CardDescription>Popular topics in your network</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {trendingTopics.map((topic) => (
                    <div key={topic.tag} className="flex justify-between items-center p-2 hover:bg-gray-50 rounded cursor-pointer">
                      <span className="font-medium">#{topic.tag}</span>
                      <span className="text-sm text-gray-500">{topic.posts} posts</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Featured Posts */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Featured Posts</CardTitle>
                <CardDescription>Popular in your network</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {featuredPosts.map((post) => (
                    <div key={post.id} className="space-y-2">
                      <h4 className="font-medium text-sm hover:text-blue-600 cursor-pointer line-clamp-2">
                        {post.title}
                      </h4>
                      <div className="flex items-center gap-2">
                        <Avatar className="h-6 w-6">
                          <AvatarImage src={post.authorAvatar} />
                          <AvatarFallback>{post.author.split(' ').map(n => n[0]).join('')}</AvatarFallback>
                        </Avatar>
                        <span className="text-xs text-gray-600">{post.author}</span>
                      </div>
                      <div className="flex items-center gap-3 text-xs text-gray-500">
                        <span>{post.readTime}</span>
                        <span>{post.likes} likes</span>
                      </div>
                      <hr className="border-gray-200" />
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </PlatformLayout>
  );
}