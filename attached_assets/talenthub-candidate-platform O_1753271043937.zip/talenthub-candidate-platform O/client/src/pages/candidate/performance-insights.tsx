import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import PlatformLayout from "@/components/layout/platform-layout";
import { platformConfigs } from "@/config/complete-navigation";
import { useThemeClasses } from "@/lib/theme-config";
import { 
  Zap, 
  TrendingUp, 
  TrendingDown,
  Target,
  Eye,
  Clock,
  Award,
  Users,
  BarChart3,
  Calendar,
  CheckCircle,
  AlertTriangle,
  Star,
  Briefcase,
  MessageSquare,
  ArrowRight,
  Filter,
  Download
} from "lucide-react";

function PerformanceInsightsContent() {
  const [selectedTimeframe, setSelectedTimeframe] = useState("30days");

  const performanceMetrics = {
    jobSearchEfficiency: {
      score: 78,
      trend: "up",
      change: "+12%",
      description: "Your job search is 12% more efficient than last month"
    },
    networkingActivity: {
      score: 85,
      trend: "up", 
      change: "+8%",
      description: "Strong networking performance with consistent growth"
    },
    skillDevelopment: {
      score: 67,
      trend: "down",
      change: "-5%",
      description: "Skill development has slowed, consider new learning paths"
    },
    marketAlignment: {
      score: 92,
      trend: "up",
      change: "+15%",
      description: "Your profile strongly aligns with current market demands"
    }
  };

  const weeklyProgress = [
    { week: "Week 1", applications: 8, interviews: 2, responses: 5, networking: 12 },
    { week: "Week 2", applications: 12, interviews: 3, responses: 7, networking: 15 },
    { week: "Week 3", applications: 10, interviews: 4, responses: 6, networking: 18 },
    { week: "Week 4", applications: 15, interviews: 5, responses: 9, networking: 22 }
  ];

  const skillsAnalysis = [
    {
      skill: "React Development",
      currentLevel: 85,
      marketDemand: 92,
      growthPotential: "High",
      recommendation: "Focus on advanced patterns and performance optimization"
    },
    {
      skill: "TypeScript",
      currentLevel: 70,
      marketDemand: 88,
      growthPotential: "High",
      recommendation: "Increase practice to match market demand"
    },
    {
      skill: "System Design",
      currentLevel: 45,
      marketDemand: 85,
      growthPotential: "Very High",
      recommendation: "Priority skill gap - invest in learning immediately"
    },
    {
      skill: "Leadership",
      currentLevel: 75,
      marketDemand: 78,
      growthPotential: "Medium",
      recommendation: "Good alignment, maintain current level"
    }
  ];

  const competitorAnalysis = {
    averageApplications: 10,
    averageInterviews: 2.5,
    averageResponseRate: 25,
    yourPerformance: {
      applications: 15,
      interviews: 4,
      responseRate: 35
    }
  };

  const actionableInsights = [
    {
      category: "Job Applications",
      insight: "You receive 40% more interview requests than average",
      action: "Continue current application strategy, focus on quality over quantity",
      impact: "High",
      timeframe: "Immediate"
    },
    {
      category: "Skill Development",
      insight: "System Design skills gap identified",
      action: "Enroll in system design course or practice design interviews",
      impact: "Very High",
      timeframe: "2-4 weeks"
    },
    {
      category: "Networking",
      insight: "Strong networking growth but low conversion to referrals",
      action: "Follow up with recent connections and request informational interviews",
      impact: "Medium",
      timeframe: "1-2 weeks"
    },
    {
      category: "Market Positioning",
      insight: "Your profile ranks in top 15% for target roles",
      action: "Apply to more senior positions to maximize earning potential",
      impact: "High",
      timeframe: "Immediate"
    }
  ];

  const goalTracking = [
    {
      goal: "Land Senior Developer Role",
      progress: 65,
      deadline: "2024-03-01",
      status: "on-track",
      milestones: [
        { task: "Complete system design course", completed: true },
        { task: "Apply to 20 target companies", completed: true },
        { task: "Complete 5 technical interviews", completed: false },
        { task: "Negotiate offer", completed: false }
      ]
    },
    {
      goal: "Build Professional Network",
      progress: 80,
      deadline: "2024-02-15",
      status: "ahead",
      milestones: [
        { task: "Connect with 50 industry professionals", completed: true },
        { task: "Attend 3 networking events", completed: true },
        { task: "Get 2 referrals", completed: true },
        { task: "Schedule 5 coffee chats", completed: false }
      ]
    }
  ];

  const getTrendIcon = (trend: string) => {
    return trend === "up" ? (
      <TrendingUp className="h-4 w-4 text-green-600" />
    ) : (
      <TrendingDown className="h-4 w-4 text-red-600" />
    );
  };

  const getTrendColor = (trend: string) => {
    return trend === "up" ? "text-green-600" : "text-red-600";
  };

  const getScoreColor = (score: number) => {
    if (score >= 80) return "text-green-600";
    if (score >= 60) return "text-yellow-600";
    return "text-red-600";
  };

  const getImpactColor = (impact: string) => {
    switch (impact.toLowerCase()) {
      case "very high": return "bg-red-100 text-red-700";
      case "high": return "bg-orange-100 text-orange-700";
      case "medium": return "bg-yellow-100 text-yellow-700";
      case "low": return "bg-green-100 text-green-700";
      default: return "bg-gray-100 text-gray-700";
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "ahead": return "bg-green-100 text-green-700";
      case "on-track": return "bg-blue-100 text-blue-700";
      case "behind": return "bg-red-100 text-red-700";
      default: return "bg-gray-100 text-gray-700";
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-sky-50 to-white p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Performance Insights</h1>
          <p className="text-gray-600">AI-powered analytics to optimize your career development and job search strategy</p>
        </div>

        {/* Key Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {Object.entries(performanceMetrics).map(([key, metric]) => (
            <Card key={key} className="border-2">
              <CardContent className="p-6">
                <div className="flex justify-between items-start mb-4">
                  <div>
                    <div className={`text-2xl font-bold ${getScoreColor(metric.score)}`}>
                      {metric.score}%
                    </div>
                    <h3 className="text-sm font-medium text-gray-900 capitalize">
                      {key.replace(/([A-Z])/g, ' $1').trim()}
                    </h3>
                  </div>
                  <div className="flex items-center gap-1">
                    {getTrendIcon(metric.trend)}
                    <span className={`text-sm font-medium ${getTrendColor(metric.trend)}`}>
                      {metric.change}
                    </span>
                  </div>
                </div>
                <Progress value={metric.score} className="h-2 mb-3" />
                <p className="text-xs text-gray-600">{metric.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>

        <Tabs defaultValue="overview" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="skills-analysis">Skills Analysis</TabsTrigger>
            <TabsTrigger value="goal-tracking">Goal Tracking</TabsTrigger>
            <TabsTrigger value="actionable-insights">Action Items</TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Weekly Progress Chart */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <BarChart3 className="h-5 w-5 text-sky-600" />
                    Weekly Activity Trends
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {weeklyProgress.map((week, index) => (
                      <div key={index} className="space-y-2">
                        <div className="flex justify-between items-center">
                          <span className="text-sm font-medium">{week.week}</span>
                          <span className="text-sm text-gray-600">
                            {week.applications + week.interviews + week.networking} activities
                          </span>
                        </div>
                        <div className="grid grid-cols-4 gap-2 text-xs">
                          <div className="bg-blue-100 p-2 rounded text-center">
                            <div className="font-medium text-blue-700">{week.applications}</div>
                            <div className="text-blue-600">Apps</div>
                          </div>
                          <div className="bg-green-100 p-2 rounded text-center">
                            <div className="font-medium text-green-700">{week.interviews}</div>
                            <div className="text-green-600">Interviews</div>
                          </div>
                          <div className="bg-purple-100 p-2 rounded text-center">
                            <div className="font-medium text-purple-700">{week.responses}</div>
                            <div className="text-purple-600">Responses</div>
                          </div>
                          <div className="bg-orange-100 p-2 rounded text-center">
                            <div className="font-medium text-orange-700">{week.networking}</div>
                            <div className="text-orange-600">Network</div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* Competitive Analysis */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Users className="h-5 w-5 text-sky-600" />
                    Competitive Analysis
                  </CardTitle>
                  <CardDescription>How you compare to other candidates</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-6">
                    <div className="grid grid-cols-2 gap-4">
                      <div className="text-center p-4 bg-gray-50 rounded-lg">
                        <div className="text-2xl font-bold text-gray-600">
                          {competitorAnalysis.averageApplications}
                        </div>
                        <div className="text-sm text-gray-600">Avg Applications/Week</div>
                      </div>
                      <div className="text-center p-4 bg-sky-50 rounded-lg">
                        <div className="text-2xl font-bold text-sky-700">
                          {competitorAnalysis.yourPerformance.applications}
                        </div>
                        <div className="text-sm text-sky-600">Your Applications/Week</div>
                      </div>
                    </div>

                    <div className="space-y-3">
                      <div className="flex justify-between items-center">
                        <span className="text-sm">Interview Rate</span>
                        <span className="text-sm font-medium text-green-600">
                          {((competitorAnalysis.yourPerformance.interviews / competitorAnalysis.yourPerformance.applications) * 100).toFixed(0)}% 
                          (vs {((competitorAnalysis.averageInterviews / competitorAnalysis.averageApplications) * 100).toFixed(0)}% avg)
                        </span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-sm">Response Rate</span>
                        <span className="text-sm font-medium text-green-600">
                          {competitorAnalysis.yourPerformance.responseRate}% 
                          (vs {competitorAnalysis.averageResponseRate}% avg)
                        </span>
                      </div>
                    </div>

                    <div className="p-3 bg-green-50 rounded-lg">
                      <div className="text-sm font-medium text-green-800">Performance Summary</div>
                      <div className="text-sm text-green-700">
                        You're performing 40% better than average candidates in your field
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Skills Analysis Tab */}
          <TabsContent value="skills-analysis">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Target className="h-5 w-5 text-sky-600" />
                  Skills Gap Analysis
                </CardTitle>
                <CardDescription>Identify skill gaps and growth opportunities</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  {skillsAnalysis.map((skill, index) => (
                    <Card key={index} className="border-2">
                      <CardContent className="p-6">
                        <div className="flex justify-between items-start mb-4">
                          <h3 className="font-semibold text-gray-900">{skill.skill}</h3>
                          <Badge className={
                            skill.growthPotential === "Very High" ? "bg-red-100 text-red-700" :
                            skill.growthPotential === "High" ? "bg-orange-100 text-orange-700" :
                            "bg-green-100 text-green-700"
                          }>
                            {skill.growthPotential} Growth Potential
                          </Badge>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-4">
                          <div>
                            <div className="flex justify-between mb-2">
                              <span className="text-sm">Your Level</span>
                              <span className="text-sm font-medium">{skill.currentLevel}%</span>
                            </div>
                            <Progress value={skill.currentLevel} className="h-2" />
                          </div>
                          <div>
                            <div className="flex justify-between mb-2">
                              <span className="text-sm">Market Demand</span>
                              <span className="text-sm font-medium">{skill.marketDemand}%</span>
                            </div>
                            <Progress value={skill.marketDemand} className="h-2" />
                          </div>
                        </div>

                        <div className="p-3 bg-blue-50 rounded-lg">
                          <div className="text-sm font-medium text-blue-800 mb-1">Recommendation</div>
                          <div className="text-sm text-blue-700">{skill.recommendation}</div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Goal Tracking Tab */}
          <TabsContent value="goal-tracking">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Award className="h-5 w-5 text-sky-600" />
                  Goal Progress Tracking
                </CardTitle>
                <CardDescription>Monitor your career development goals and milestones</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  {goalTracking.map((goal, index) => (
                    <Card key={index} className="border-2">
                      <CardContent className="p-6">
                        <div className="flex justify-between items-start mb-4">
                          <div>
                            <h3 className="font-semibold text-gray-900 mb-1">{goal.goal}</h3>
                            <div className="text-sm text-gray-600">Deadline: {goal.deadline}</div>
                          </div>
                          <Badge className={getStatusColor(goal.status)}>
                            {goal.status.replace('-', ' ')}
                          </Badge>
                        </div>

                        <div className="mb-4">
                          <div className="flex justify-between mb-2">
                            <span className="text-sm">Progress</span>
                            <span className="text-sm font-medium">{goal.progress}%</span>
                          </div>
                          <Progress value={goal.progress} className="h-3" />
                        </div>

                        <div className="space-y-2">
                          <h4 className="font-medium text-gray-900 mb-2">Milestones</h4>
                          {goal.milestones.map((milestone, milestoneIndex) => (
                            <div key={milestoneIndex} className="flex items-center gap-3">
                              {milestone.completed ? (
                                <CheckCircle className="h-4 w-4 text-green-600" />
                              ) : (
                                <div className="w-4 h-4 border-2 border-gray-300 rounded-full" />
                              )}
                              <span className={`text-sm ${
                                milestone.completed ? 'text-gray-900 line-through' : 'text-gray-700'
                              }`}>
                                {milestone.task}
                              </span>
                            </div>
                          ))}
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Action Items Tab */}
          <TabsContent value="actionable-insights">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Zap className="h-5 w-5 text-sky-600" />
                  Actionable Insights
                </CardTitle>
                <CardDescription>AI-generated recommendations to improve your performance</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  {actionableInsights.map((insight, index) => (
                    <Card key={index} className="border-2">
                      <CardContent className="p-6">
                        <div className="flex justify-between items-start mb-4">
                          <div>
                            <h3 className="font-semibold text-gray-900 mb-1">{insight.category}</h3>
                            <Badge className={getImpactColor(insight.impact)}>
                              {insight.impact} Impact
                            </Badge>
                          </div>
                          <div className="text-sm text-gray-600">{insight.timeframe}</div>
                        </div>

                        <div className="space-y-3">
                          <div className="p-3 bg-blue-50 rounded-lg">
                            <div className="text-sm font-medium text-blue-800 mb-1">Insight</div>
                            <div className="text-sm text-blue-700">{insight.insight}</div>
                          </div>

                          <div className="p-3 bg-green-50 rounded-lg">
                            <div className="text-sm font-medium text-green-800 mb-1">Recommended Action</div>
                            <div className="text-sm text-green-700">{insight.action}</div>
                          </div>
                        </div>

                        <div className="mt-4">
                          <Button className="bg-sky-600 hover:bg-sky-700">
                            <ArrowRight className="h-4 w-4 mr-2" />
                            Take Action
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Export Options */}
        <Card className="mt-8">
          <CardHeader>
            <CardTitle>Export & Share</CardTitle>
            <CardDescription>Download your performance insights and share with mentors or coaches</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-4">
              <Button variant="outline">
                <Download className="h-4 w-4 mr-2" />
                Download PDF Report
              </Button>
              <Button variant="outline">
                <BarChart3 className="h-4 w-4 mr-2" />
                Export Data
              </Button>
              <Button variant="outline">
                <Calendar className="h-4 w-4 mr-2" />
                Schedule Review
              </Button>
              <Button className="bg-sky-600 hover:bg-sky-700">
                <MessageSquare className="h-4 w-4 mr-2" />
                Share with Mentor
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

export default function PerformanceInsights() {
  const config = platformConfigs.candidate;
  const theme = useThemeClasses('candidate');
  
  const usageData = [
    { label: "Performance Score", current: 87, max: 100 },
    { label: "Goals Achieved", current: 6, max: 10 },
    { label: "Analytics Depth", current: 92, max: 100 },
  ];

  return (
    <PlatformLayout
      sidebarTitle={config.sidebarTitle}
      sidebarSubtitle={config.sidebarSubtitle}
      sidebarSections={config.sidebarSections}
      usageData={usageData}
    >
      <PerformanceInsightsContent />
    </PlatformLayout>
  );
}