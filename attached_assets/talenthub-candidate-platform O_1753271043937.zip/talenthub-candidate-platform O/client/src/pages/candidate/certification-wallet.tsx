import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Progress } from "@/components/ui/progress";
import PlatformLayout from "@/components/layout/platform-layout";
import { candidateNavigation } from "@/config/complete-navigation";
import { 
  Wallet, Award, Shield, Download, Share, Eye, QrCode,
  Star, Calendar, CheckCircle, Globe, Lock, Zap,
  Trophy, Target, Brain, Code, Server, Database, Cloud,
  ExternalLink, Copy, Search, Filter, TrendingUp
} from "lucide-react";

const CertificationWallet: React.FC = () => {
  const [activeTab, setActiveTab] = useState('certificates');
  const [searchTerm, setSearchTerm] = useState('');

  const certificates = [
    {
      id: 1,
      title: 'React Professional Developer',
      issuer: 'TalentHub Academy',
      issueDate: '2024-06-15',
      expiryDate: '2026-06-15',
      credentialId: 'TH-REACT-2024-001',
      score: 95,
      level: 'Professional',
      category: 'Frontend',
      icon: Code,
      color: 'from-blue-500 to-blue-600',
      blockchain: {
        verified: true,
        hash: '0x1a2b3c4d5e6f7g8h9i0j',
        network: 'Ethereum'
      },
      skills: ['React Hooks', 'State Management', 'Component Design', 'Testing'],
      verification: 'https://verify.talenthub.com/cert/TH-REACT-2024-001'
    },
    {
      id: 2,
      title: 'AWS Certified Cloud Practitioner',
      issuer: 'Amazon Web Services',
      issueDate: '2024-05-20',
      expiryDate: '2027-05-20',
      credentialId: 'AWS-CCP-2024-789',
      score: 88,
      level: 'Foundation',
      category: 'Cloud',
      icon: Cloud,
      color: 'from-orange-500 to-orange-600',
      blockchain: {
        verified: true,
        hash: '0x9i8h7g6f5e4d3c2b1a0',
        network: 'Polygon'
      },
      skills: ['Cloud Computing', 'AWS Services', 'Security', 'Billing'],
      verification: 'https://aws.amazon.com/verification/AWS-CCP-2024-789'
    },
    {
      id: 3,
      title: 'Node.js Backend Specialist',
      issuer: 'TalentHub Academy',
      issueDate: '2024-04-10',
      expiryDate: '2026-04-10',
      credentialId: 'TH-NODE-2024-045',
      score: 92,
      level: 'Expert',
      category: 'Backend',
      icon: Server,
      color: 'from-green-500 to-green-600',
      blockchain: {
        verified: true,
        hash: '0xa1b2c3d4e5f6g7h8i9j0',
        network: 'Ethereum'
      },
      skills: ['Express.js', 'API Design', 'Database Integration', 'Microservices'],
      verification: 'https://verify.talenthub.com/cert/TH-NODE-2024-045'
    },
    {
      id: 4,
      title: 'Data Science Fundamentals',
      issuer: 'Python Institute',
      issueDate: '2024-03-15',
      expiryDate: '2025-03-15',
      credentialId: 'PI-DS-2024-156',
      score: 86,
      level: 'Foundation',
      category: 'Data Science',
      icon: Database,
      color: 'from-purple-500 to-purple-600',
      blockchain: {
        verified: false,
        hash: null,
        network: null
      },
      skills: ['Python', 'Pandas', 'Data Analysis', 'Visualization'],
      verification: 'https://pythoninstitute.org/verify/PI-DS-2024-156'
    }
  ];

  const digitalBadges = [
    {
      id: 1,
      name: 'Full-Stack Developer',
      description: 'Completed comprehensive full-stack development program',
      earnedDate: '2024-06-01',
      rarity: 'Rare',
      icon: Trophy,
      color: 'from-yellow-400 to-yellow-600'
    },
    {
      id: 2,
      name: 'Cloud Architecture Expert',
      description: 'Demonstrated expertise in cloud infrastructure design',
      earnedDate: '2024-05-15',
      rarity: 'Epic',
      icon: Cloud,
      color: 'from-indigo-500 to-purple-600'
    },
    {
      id: 3,
      name: 'AI/ML Pioneer',
      description: 'Early adopter of machine learning technologies',
      earnedDate: '2024-04-20',
      rarity: 'Legendary',
      icon: Brain,
      color: 'from-pink-500 to-red-600'
    }
  ];

  const skillCredentials = [
    { skill: 'React', level: 'Expert', score: 95, verified: true },
    { skill: 'Node.js', level: 'Advanced', score: 92, verified: true },
    { skill: 'AWS', level: 'Intermediate', score: 88, verified: true },
    { skill: 'Python', level: 'Intermediate', score: 86, verified: false },
    { skill: 'TypeScript', level: 'Advanced', score: 90, verified: true },
    { skill: 'MongoDB', level: 'Intermediate', score: 84, verified: true }
  ];

  const walletStats = {
    totalCertificates: certificates.length,
    verifiedOnBlockchain: certificates.filter(c => c.blockchain.verified).length,
    averageScore: Math.round(certificates.reduce((sum, cert) => sum + cert.score, 0) / certificates.length),
    credibilityScore: 95,
    portfolioViews: 1247,
    employerVerifications: 23
  };

  const filteredCertificates = certificates.filter(cert =>
    cert.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    cert.issuer.toLowerCase().includes(searchTerm.toLowerCase()) ||
    cert.category.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const LevelBadge = ({ level }: { level: string }) => {
    const colors = {
      'Foundation': 'bg-green-100 text-green-800',
      'Professional': 'bg-blue-100 text-blue-800',
      'Expert': 'bg-purple-100 text-purple-800'
    };
    return <Badge className={colors[level as keyof typeof colors] || colors.Foundation}>{level}</Badge>;
  };

  const RarityBadge = ({ rarity }: { rarity: string }) => {
    const colors = {
      'Common': 'bg-gray-100 text-gray-800',
      'Rare': 'bg-blue-100 text-blue-800',
      'Epic': 'bg-purple-100 text-purple-800',
      'Legendary': 'bg-yellow-100 text-yellow-800'
    };
    return <Badge className={colors[rarity as keyof typeof colors] || colors.Common}>{rarity}</Badge>;
  };

  return (
    <PlatformLayout
      sidebarTitle="Skills Certification Hub"
      sidebarSubtitle="Certification Wallet"
      sidebarSections={candidateNavigation}
    >
      <div className="min-h-screen bg-gradient-to-br from-purple-50 via-white to-blue-50">
        {/* Header Section */}
        <div className="bg-gradient-to-r from-purple-600 to-blue-600 text-white p-8">
          <div className="max-w-7xl mx-auto">
            <div className="flex items-center gap-3 mb-4">
              <Wallet className="h-8 w-8" />
              <h1 className="text-3xl font-bold">Certification Wallet</h1>
            </div>
            <p className="text-purple-100 text-lg mb-6">
              Your digital credential portfolio with blockchain verification and professional sharing
            </p>
            
            {/* Search Bar */}
            <div className="relative max-w-md">
              <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
              <Input
                placeholder="Search certificates..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 bg-white/10 border-white/20 text-white placeholder:text-white/70"
              />
            </div>
          </div>
        </div>

        <div className="max-w-7xl mx-auto p-8">
          {/* Wallet Statistics */}
          <div className="grid grid-cols-2 lg:grid-cols-6 gap-4 mb-8">
            <Card className="text-center">
              <CardContent className="p-4">
                <Award className="h-6 w-6 text-purple-600 mx-auto mb-2" />
                <div className="text-xl font-bold">{walletStats.totalCertificates}</div>
                <div className="text-xs text-gray-600">Certificates</div>
              </CardContent>
            </Card>
            <Card className="text-center">
              <CardContent className="p-4">
                <Shield className="h-6 w-6 text-green-600 mx-auto mb-2" />
                <div className="text-xl font-bold">{walletStats.verifiedOnBlockchain}</div>
                <div className="text-xs text-gray-600">Blockchain Verified</div>
              </CardContent>
            </Card>
            <Card className="text-center">
              <CardContent className="p-4">
                <Star className="h-6 w-6 text-yellow-600 mx-auto mb-2" />
                <div className="text-xl font-bold">{walletStats.averageScore}%</div>
                <div className="text-xs text-gray-600">Avg Score</div>
              </CardContent>
            </Card>
            <Card className="text-center">
              <CardContent className="p-4">
                <TrendingUp className="h-6 w-6 text-blue-600 mx-auto mb-2" />
                <div className="text-xl font-bold">{walletStats.credibilityScore}</div>
                <div className="text-xs text-gray-600">Credibility Score</div>
              </CardContent>
            </Card>
            <Card className="text-center">
              <CardContent className="p-4">
                <Eye className="h-6 w-6 text-indigo-600 mx-auto mb-2" />
                <div className="text-xl font-bold">{walletStats.portfolioViews}</div>
                <div className="text-xs text-gray-600">Portfolio Views</div>
              </CardContent>
            </Card>
            <Card className="text-center">
              <CardContent className="p-4">
                <CheckCircle className="h-6 w-6 text-emerald-600 mx-auto mb-2" />
                <div className="text-xl font-bold">{walletStats.employerVerifications}</div>
                <div className="text-xs text-gray-600">Employer Checks</div>
              </CardContent>
            </Card>
          </div>

          <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="certificates" className="flex items-center gap-2">
                <Award className="h-4 w-4" />
                Earned Certificates
              </TabsTrigger>
              <TabsTrigger value="badges" className="flex items-center gap-2">
                <Trophy className="h-4 w-4" />
                Digital Badges
              </TabsTrigger>
              <TabsTrigger value="credentials" className="flex items-center gap-2">
                <Target className="h-4 w-4" />
                Skill Credentials
              </TabsTrigger>
            </TabsList>

            {/* Certificates Tab */}
            <TabsContent value="certificates" className="space-y-6">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {filteredCertificates.map(cert => {
                  const Icon = cert.icon;
                  return (
                    <Card key={cert.id} className="hover:shadow-lg transition-all duration-300">
                      <div className={`h-24 bg-gradient-to-r ${cert.color} flex items-center justify-center`}>
                        <Icon className="h-12 w-12 text-white" />
                      </div>
                      
                      <CardHeader className="pb-2">
                        <div className="flex items-start justify-between">
                          <CardTitle className="text-lg">{cert.title}</CardTitle>
                          {cert.blockchain.verified && (
                            <Shield className="h-5 w-5 text-green-600" />
                          )}
                        </div>
                        <CardDescription>{cert.issuer}</CardDescription>
                        <div className="flex items-center gap-2">
                          <LevelBadge level={cert.level} />
                          <Badge variant="outline">{cert.category}</Badge>
                          <Badge className="bg-green-100 text-green-800">{cert.score}%</Badge>
                        </div>
                      </CardHeader>
                      
                      <CardContent className="space-y-4">
                        <div className="grid grid-cols-2 gap-2 text-sm">
                          <div>
                            <div className="text-gray-600">Issued</div>
                            <div className="font-medium">{new Date(cert.issueDate).toLocaleDateString()}</div>
                          </div>
                          <div>
                            <div className="text-gray-600">Expires</div>
                            <div className="font-medium">{new Date(cert.expiryDate).toLocaleDateString()}</div>
                          </div>
                        </div>
                        
                        <div>
                          <div className="text-sm text-gray-600 mb-2">Credential ID:</div>
                          <div className="flex items-center gap-2">
                            <code className="text-xs bg-gray-100 p-1 rounded flex-1">{cert.credentialId}</code>
                            <Button size="sm" variant="outline">
                              <Copy className="h-3 w-3" />
                            </Button>
                          </div>
                        </div>
                        
                        <div>
                          <div className="text-sm text-gray-600 mb-2">Skills Verified:</div>
                          <div className="flex flex-wrap gap-1">
                            {cert.skills.map((skill, index) => (
                              <Badge key={index} variant="secondary" className="text-xs">
                                {skill}
                              </Badge>
                            ))}
                          </div>
                        </div>
                        
                        {cert.blockchain.verified && (
                          <div className="bg-green-50 p-3 rounded-lg">
                            <div className="flex items-center gap-2 mb-2">
                              <Shield className="h-4 w-4 text-green-600" />
                              <span className="text-sm font-medium text-green-800">Blockchain Verified</span>
                            </div>
                            <div className="text-xs text-green-700">
                              Network: {cert.blockchain.network} • Hash: {cert.blockchain.hash?.substring(0, 10)}...
                            </div>
                          </div>
                        )}
                        
                        <div className="flex gap-2 pt-2">
                          <Button size="sm" className="flex-1">
                            <Download className="h-3 w-3 mr-2" />
                            Download
                          </Button>
                          <Button size="sm" variant="outline">
                            <Share className="h-3 w-3 mr-2" />
                            Share
                          </Button>
                          <Button size="sm" variant="outline">
                            <ExternalLink className="h-3 w-3 mr-2" />
                            Verify
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  );
                })}
              </div>
            </TabsContent>

            {/* Digital Badges Tab */}
            <TabsContent value="badges" className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {digitalBadges.map(badge => {
                  const Icon = badge.icon;
                  return (
                    <Card key={badge.id} className="text-center hover:shadow-lg transition-all duration-300">
                      <CardContent className="p-6">
                        <div className={`w-20 h-20 mx-auto mb-4 rounded-full bg-gradient-to-r ${badge.color} flex items-center justify-center`}>
                          <Icon className="h-10 w-10 text-white" />
                        </div>
                        <h3 className="text-lg font-bold mb-2">{badge.name}</h3>
                        <p className="text-gray-600 text-sm mb-4">{badge.description}</p>
                        <div className="flex justify-center gap-2 mb-4">
                          <RarityBadge rarity={badge.rarity} />
                        </div>
                        <div className="text-sm text-gray-500">
                          Earned: {new Date(badge.earnedDate).toLocaleDateString()}
                        </div>
                      </CardContent>
                    </Card>
                  );
                })}
              </div>
            </TabsContent>

            {/* Skill Credentials Tab */}
            <TabsContent value="credentials" className="space-y-6">
              <div className="grid gap-4">
                {skillCredentials.map((skill, index) => (
                  <Card key={index}>
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-4">
                          <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                            <Code className="h-6 w-6 text-blue-600" />
                          </div>
                          <div>
                            <div className="font-medium text-lg">{skill.skill}</div>
                            <div className="text-gray-600">{skill.level} Level</div>
                          </div>
                        </div>
                        <div className="text-right">
                          <div className="flex items-center gap-2 mb-1">
                            <div className="text-lg font-bold">{skill.score}%</div>
                            {skill.verified && <CheckCircle className="h-4 w-4 text-green-600" />}
                          </div>
                          <Progress value={skill.score} className="w-24" />
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>
          </Tabs>

          {/* Portfolio Sharing Section */}
          <Card className="mt-8 bg-gradient-to-r from-indigo-500 to-purple-600 text-white">
            <CardContent className="p-8">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
                <div>
                  <h3 className="text-2xl font-bold mb-4">Share Your Credential Portfolio</h3>
                  <p className="text-indigo-100 mb-6">
                    Generate shareable links and QR codes for employers to verify your credentials instantly
                  </p>
                  <div className="flex gap-4">
                    <Button className="bg-white text-indigo-600 hover:bg-gray-100">
                      <Share className="h-4 w-4 mr-2" />
                      Generate Share Link
                    </Button>
                    <Button variant="outline" className="border-white text-white hover:bg-white/10">
                      <QrCode className="h-4 w-4 mr-2" />
                      QR Code
                    </Button>
                  </div>
                </div>
                <div className="text-center">
                  <div className="w-32 h-32 bg-white/10 rounded-lg mx-auto mb-4 flex items-center justify-center">
                    <QrCode className="h-16 w-16" />
                  </div>
                  <div className="text-sm text-indigo-100">
                    Instant verification for employers
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </PlatformLayout>
  );
};

export default CertificationWallet;