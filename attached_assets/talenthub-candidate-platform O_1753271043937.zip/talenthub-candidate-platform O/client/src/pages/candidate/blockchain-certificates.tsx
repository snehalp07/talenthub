import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Alert, AlertDescription } from "@/components/ui/alert";
import PlatformLayout from "@/components/layout/platform-layout";
import { platformConfigs } from "@/config/complete-navigation";
import { useThemeClasses } from "@/lib/theme-config";
import { 
  Shield, 
  Link2, 
  Download, 
  Copy, 
  ExternalLink, 
  CheckCircle, 
  AlertTriangle,
  Clock,
  Users,
  Globe,
  Lock,
  Key,
  QrCode,
  Share,
  Eye,
  Wallet,
  FileText,
  Search
} from "lucide-react";

function BlockchainCertificatesContent() {
  const [selectedCredential, setSelectedCredential] = useState<string | null>(null);
  const [verificationHash, setVerificationHash] = useState("");

  const blockchainCredentials = [
    {
      id: "bc-001",
      name: "AWS Solutions Architect Professional",
      issuer: "Amazon Web Services",
      issueDate: "2024-01-15",
      blockchainNetwork: "Ethereum",
      transactionHash: "0x1a2b3c4d5e6f7890abcdef1234567890abcdef1234567890abcdef1234567890",
      contractAddress: "0xABC123456789012345678901234567890ABC12345",
      tokenId: "12345",
      ipfsHash: "QmYjh5NsDc5kjf7DGHytg4FGhjk3k4mL7jNm8kLp9qR7XZ",
      status: "verified",
      verificationCount: 47,
      lastVerified: "2024-02-18 14:30",
      credentialData: {
        recipient: "John Doe",
        score: 850,
        credentialId: "AWS-SAA-2024-001567",
        skills: ["Cloud Architecture", "AWS Services", "Security", "Cost Optimization"]
      }
    },
    {
      id: "bc-002",
      name: "React Advanced Developer",
      issuer: "Platform Native",
      issueDate: "2024-01-08",
      blockchainNetwork: "Polygon",
      transactionHash: "0x9f8e7d6c5b4a3021fedcba0987654321fedcba0987654321fedcba0987654321",
      contractAddress: "0XYZ789012345678901234567890XYZ78901234567",
      tokenId: "67890",
      ipfsHash: "QmRtY8NkDc3kjf2DGAytg7FGhjk8k9mL2jNm5kLp4qR9XA",
      status: "verified",
      verificationCount: 23,
      lastVerified: "2024-02-17 09:15",
      credentialData: {
        recipient: "John Doe",
        score: 94,
        credentialId: "REACT-ADV-2024-002134",
        skills: ["React Hooks", "Performance Optimization", "Component Architecture", "Testing"]
      }
    },
    {
      id: "bc-003",
      name: "Machine Learning Specialist",
      issuer: "Platform Native",
      issueDate: "2023-12-20",
      blockchainNetwork: "Ethereum",
      transactionHash: "0x5f4e3d2c1b0a9081fedc7890ba654321fedc7890ba654321fedc7890ba654321",
      contractAddress: "0DEF456789012345678901234567890DEF45678901",
      tokenId: "11111",
      ipfsHash: "QmPqW7LkDc9kjf5DGEytg2FGhjk6k7mL8jNm3kLp7qR2XB",
      status: "pending",
      verificationCount: 12,
      lastVerified: "2024-02-16 16:45",
      credentialData: {
        recipient: "John Doe",
        score: 91,
        credentialId: "ML-SPEC-2023-003789",
        skills: ["Python", "TensorFlow", "Data Analysis", "Deep Learning"]
      }
    }
  ];

  const verificationHistory = [
    {
      id: 1,
      verifierName: "Google HR Department",
      verifierType: "Corporate",
      credentialName: "AWS Solutions Architect Professional",
      verificationDate: "2024-02-18 14:30",
      verificationResult: "Valid",
      blockchainConfirmations: 15
    },
    {
      id: 2,
      verifierName: "Microsoft Recruiting",
      verifierType: "Corporate",
      credentialName: "React Advanced Developer",
      verificationDate: "2024-02-17 09:15",
      verificationResult: "Valid",
      blockchainConfirmations: 22
    },
    {
      id: 3,
      verifierName: "Stanford University",
      verifierType: "Academic",
      credentialName: "Machine Learning Specialist",
      verificationDate: "2024-02-16 16:45",
      verificationResult: "Valid",
      blockchainConfirmations: 8
    }
  ];

  const publicVerifications = [
    {
      id: "pub-001",
      credentialName: "AWS Solutions Architect Professional",
      verificationHash: "0x1a2b3c4d5e6f7890abcdef1234567890abcdef1234567890abcdef1234567890",
      verifierType: "Public Verification",
      timestamp: "2024-02-20 10:30",
      status: "verified"
    },
    {
      id: "pub-002",
      credentialName: "React Advanced Developer", 
      verificationHash: "0x9f8e7d6c5b4a3021fedcba0987654321fedcba0987654321fedcba0987654321",
      verifierType: "Employer Verification",
      timestamp: "2024-02-19 15:20",
      status: "verified"
    }
  ];

  const blockchainStats = {
    totalCredentials: 3,
    verifiedCredentials: 2,
    pendingCredentials: 1,
    totalVerifications: 82,
    uniqueVerifiers: 15,
    networkReliability: 99.9
  };

  const supportedNetworks = [
    {
      name: "Ethereum",
      symbol: "ETH",
      gasPrice: "25 Gwei",
      confirmationTime: "2-5 minutes",
      securityLevel: "Very High",
      usage: 67
    },
    {
      name: "Polygon",
      symbol: "MATIC", 
      gasPrice: "0.01 Gwei",
      confirmationTime: "10-30 seconds",
      securityLevel: "High",
      usage: 28
    },
    {
      name: "Binance Smart Chain",
      symbol: "BNB",
      gasPrice: "5 Gwei",
      confirmationTime: "3-10 seconds", 
      securityLevel: "High",
      usage: 5
    }
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'verified':
        return 'bg-green-100 text-green-800';
      case 'pending':
        return 'bg-yellow-100 text-yellow-800';
      case 'failed':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getNetworkColor = (network: string) => {
    switch (network) {
      case 'Ethereum':
        return 'bg-blue-100 text-blue-800';
      case 'Polygon':
        return 'bg-purple-100 text-purple-800';
      case 'Binance Smart Chain':
        return 'bg-yellow-100 text-yellow-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
  };

  const truncateHash = (hash: string) => {
    return `${hash.substring(0, 10)}...${hash.substring(hash.length - 8)}`;
  };

  return (
    <div className="p-8 space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Blockchain Credential Center</h1>
          <p className="text-gray-600 mt-1">Immutable, verifiable digital credentials powered by blockchain technology</p>
        </div>
        <Button className="flex items-center gap-2">
          <Share className="w-4 h-4" />
          Share Portfolio
        </Button>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600 mb-1">Blockchain Credentials</p>
                <p className="text-2xl font-bold text-blue-600">{blockchainStats.totalCredentials}</p>
              </div>
              <Shield className="w-8 h-8 text-blue-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600 mb-1">Total Verifications</p>
                <p className="text-2xl font-bold text-green-600">{blockchainStats.totalVerifications}</p>
              </div>
              <CheckCircle className="w-8 h-8 text-green-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600 mb-1">Network Reliability</p>
                <p className="text-2xl font-bold text-purple-600">{blockchainStats.networkReliability}%</p>
              </div>
              <Globe className="w-8 h-8 text-purple-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="credentials" className="space-y-6">
        <TabsList className="grid grid-cols-5 w-full max-w-3xl">
          <TabsTrigger value="credentials">My Credentials</TabsTrigger>
          <TabsTrigger value="verification">Verification Portal</TabsTrigger>
          <TabsTrigger value="history">Verification History</TabsTrigger>
          <TabsTrigger value="networks">Blockchain Networks</TabsTrigger>
          <TabsTrigger value="wallet">Digital Wallet</TabsTrigger>
        </TabsList>

        <TabsContent value="credentials" className="space-y-6">
          <div className="space-y-4">
            {blockchainCredentials.map((credential) => (
              <Card key={credential.id} className="hover:shadow-lg transition-shadow">
                <CardContent className="p-6">
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex-1">
                      <h3 className="text-lg font-semibold text-gray-900 mb-1">{credential.name}</h3>
                      <p className="text-gray-600 mb-2">Issued by {credential.issuer}</p>
                      <div className="flex items-center gap-3 text-sm text-gray-500">
                        <span>Issue Date: {credential.issueDate}</span>
                        <span>•</span>
                        <span>ID: {credential.credentialData.credentialId}</span>
                      </div>
                    </div>
                    <div className="flex flex-col gap-2 items-end">
                      <Badge className={getStatusColor(credential.status)}>
                        {credential.status}
                      </Badge>
                      <Badge className={getNetworkColor(credential.blockchainNetwork)}>
                        {credential.blockchainNetwork}
                      </Badge>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-4">
                    <div className="space-y-3">
                      <div>
                        <label className="text-xs font-medium text-gray-500 uppercase tracking-wide">
                          Blockchain Details
                        </label>
                        <div className="mt-1 space-y-2">
                          <div className="flex items-center justify-between">
                            <span className="text-sm text-gray-600">Transaction Hash:</span>
                            <div className="flex items-center gap-2">
                              <code className="text-xs bg-gray-100 px-2 py-1 rounded">
                                {truncateHash(credential.transactionHash)}
                              </code>
                              <Button
                                size="sm"
                                variant="ghost"
                                className="h-6 w-6 p-0"
                                onClick={() => copyToClipboard(credential.transactionHash)}
                              >
                                <Copy className="w-3 h-3" />
                              </Button>
                            </div>
                          </div>
                          <div className="flex items-center justify-between">
                            <span className="text-sm text-gray-600">Contract Address:</span>
                            <div className="flex items-center gap-2">
                              <code className="text-xs bg-gray-100 px-2 py-1 rounded">
                                {truncateHash(credential.contractAddress)}
                              </code>
                              <Button
                                size="sm"
                                variant="ghost"
                                className="h-6 w-6 p-0"
                                onClick={() => copyToClipboard(credential.contractAddress)}
                              >
                                <Copy className="w-3 h-3" />
                              </Button>
                            </div>
                          </div>
                          <div className="flex items-center justify-between">
                            <span className="text-sm text-gray-600">Token ID:</span>
                            <span className="text-sm font-mono">{credential.tokenId}</span>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="space-y-3">
                      <div>
                        <label className="text-xs font-medium text-gray-500 uppercase tracking-wide">
                          Verification Stats
                        </label>
                        <div className="mt-1 space-y-2">
                          <div className="flex items-center justify-between">
                            <span className="text-sm text-gray-600">Total Verifications:</span>
                            <span className="text-sm font-semibold text-green-600">{credential.verificationCount}</span>
                          </div>
                          <div className="flex items-center justify-between">
                            <span className="text-sm text-gray-600">Last Verified:</span>
                            <span className="text-sm">{credential.lastVerified}</span>
                          </div>
                          <div className="flex items-center justify-between">
                            <span className="text-sm text-gray-600">Score:</span>
                            <span className="text-sm font-semibold text-blue-600">{credential.credentialData.score}</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="mb-4">
                    <label className="text-xs font-medium text-gray-500 uppercase tracking-wide mb-2 block">
                      Skills Verified
                    </label>
                    <div className="flex flex-wrap gap-2">
                      {credential.credentialData.skills.map((skill, index) => (
                        <Badge key={index} variant="outline" className="text-xs">
                          {skill}
                        </Badge>
                      ))}
                    </div>
                  </div>

                  <div className="flex gap-3 pt-4 border-t border-gray-200">
                    <Button size="sm" className="flex items-center gap-2">
                      <Eye className="w-4 h-4" />
                      View on Blockchain
                    </Button>
                    <Button size="sm" variant="outline" className="flex items-center gap-2">
                      <Download className="w-4 h-4" />
                      Download Certificate
                    </Button>
                    <Button size="sm" variant="outline" className="flex items-center gap-2">
                      <Share className="w-4 h-4" />
                      Share
                    </Button>
                    <Button size="sm" variant="outline" className="flex items-center gap-2">
                      <QrCode className="w-4 h-4" />
                      QR Code
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="verification" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Shield className="w-5 h-5 text-blue-600" />
                Credential Verification Portal
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <Alert>
                <CheckCircle className="h-4 w-4" />
                <AlertDescription>
                  Enter a blockchain transaction hash or credential ID to verify any credential from our platform.
                </AlertDescription>
              </Alert>

              <div className="space-y-4">
                <div>
                  <label className="text-sm font-medium text-gray-700 mb-2 block">
                    Verification Hash or Credential ID
                  </label>
                  <div className="flex gap-2">
                    <Input
                      value={verificationHash}
                      onChange={(e) => setVerificationHash(e.target.value)}
                      placeholder="Enter transaction hash or credential ID..."
                      className="flex-1"
                    />
                    <Button className="flex items-center gap-2">
                      <Search className="w-4 h-4" />
                      Verify
                    </Button>
                  </div>
                </div>

                {verificationHash && (
                  <div className="border border-green-200 rounded-lg p-4 bg-green-50">
                    <div className="flex items-center gap-2 mb-3">
                      <CheckCircle className="w-5 h-5 text-green-600" />
                      <span className="font-semibold text-green-900">Credential Verified</span>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                      <div>
                        <span className="text-green-700 font-medium">Credential Name:</span>
                        <p className="text-green-900">AWS Solutions Architect Professional</p>
                      </div>
                      <div>
                        <span className="text-green-700 font-medium">Issue Date:</span>
                        <p className="text-green-900">January 15, 2024</p>
                      </div>
                      <div>
                        <span className="text-green-700 font-medium">Issuer:</span>
                        <p className="text-green-900">Amazon Web Services</p>
                      </div>
                      <div>
                        <span className="text-green-700 font-medium">Blockchain:</span>
                        <p className="text-green-900">Ethereum Network</p>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Globe className="w-5 h-5 text-purple-600" />
                Public Verification Feed
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {publicVerifications.map((verification) => (
                  <div key={verification.id} className="flex items-center justify-between p-3 border border-gray-200 rounded-lg">
                    <div>
                      <h4 className="font-medium text-gray-900">{verification.credentialName}</h4>
                      <p className="text-sm text-gray-600">
                        {verification.verifierType} • {verification.timestamp}
                      </p>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge className={getStatusColor(verification.status)}>
                        {verification.status}
                      </Badge>
                      <Button size="sm" variant="outline">
                        <ExternalLink className="w-3 h-3" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="history" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Clock className="w-5 h-5 text-orange-600" />
                Verification History
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {verificationHistory.map((verification) => (
                  <div key={verification.id} className="border border-gray-200 rounded-lg p-4">
                    <div className="flex items-start justify-between mb-3">
                      <div>
                        <h4 className="font-semibold text-gray-900">{verification.verifierName}</h4>
                        <p className="text-sm text-gray-600">{verification.verifierType}</p>
                      </div>
                      <Badge className={getStatusColor(verification.verificationResult.toLowerCase())}>
                        {verification.verificationResult}
                      </Badge>
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                      <div>
                        <span className="text-gray-600">Credential:</span>
                        <p className="font-medium">{verification.credentialName}</p>
                      </div>
                      <div>
                        <span className="text-gray-600">Verification Date:</span>
                        <p className="font-medium">{verification.verificationDate}</p>
                      </div>
                      <div>
                        <span className="text-gray-600">Confirmations:</span>
                        <p className="font-medium">{verification.blockchainConfirmations}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="networks" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {supportedNetworks.map((network, index) => (
              <Card key={index}>
                <CardHeader>
                  <CardTitle className="flex items-center justify-between">
                    <span>{network.name}</span>
                    <Badge variant="outline">{network.symbol}</Badge>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-3">
                    <div className="flex justify-between">
                      <span className="text-sm text-gray-600">Gas Price:</span>
                      <span className="text-sm font-medium">{network.gasPrice}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm text-gray-600">Confirmation Time:</span>
                      <span className="text-sm font-medium">{network.confirmationTime}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm text-gray-600">Security Level:</span>
                      <Badge variant="outline" className="text-xs">
                        {network.securityLevel}
                      </Badge>
                    </div>
                  </div>
                  
                  <div>
                    <div className="flex justify-between text-sm mb-1">
                      <span className="text-gray-600">Platform Usage</span>
                      <span className="font-medium">{network.usage}%</span>
                    </div>
                    <Progress value={network.usage} className="h-2" />
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Link2 className="w-5 h-5 text-blue-600" />
                Network Comparison
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <Alert>
                  <CheckCircle className="h-4 w-4" />
                  <AlertDescription>
                    All credentials are issued on secure blockchain networks with cryptographic verification. 
                    Ethereum provides maximum security while Polygon offers faster transactions.
                  </AlertDescription>
                </Alert>
                
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="text-center p-4 bg-blue-50 rounded-lg">
                    <h4 className="font-semibold text-blue-900 mb-2">Total Transactions</h4>
                    <div className="text-2xl font-bold text-blue-600">1,247</div>
                  </div>
                  <div className="text-center p-4 bg-green-50 rounded-lg">
                    <h4 className="font-semibold text-green-900 mb-2">Average Confirmation</h4>
                    <div className="text-2xl font-bold text-green-600">2.3 min</div>
                  </div>
                  <div className="text-center p-4 bg-purple-50 rounded-lg">
                    <h4 className="font-semibold text-purple-900 mb-2">Success Rate</h4>
                    <div className="text-2xl font-bold text-purple-600">99.8%</div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="wallet" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Wallet className="w-5 h-5 text-green-600" />
                Digital Credential Wallet
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <h4 className="font-semibold text-gray-900">Wallet Address</h4>
                  <div className="flex items-center gap-2">
                    <code className="flex-1 text-sm bg-gray-100 px-3 py-2 rounded">
                      0x742d35Cc6524c6bcfF5FecE9E4CAC4D8A8b1234567
                    </code>
                    <Button size="sm" variant="outline">
                      <Copy className="w-4 h-4" />
                    </Button>
                  </div>
                  
                  <h4 className="font-semibold text-gray-900">Public Key</h4>
                  <div className="flex items-center gap-2">
                    <code className="flex-1 text-xs bg-gray-100 px-3 py-2 rounded break-all">
                      04a34b99f22c790c4e36b2b3c2c35a36db06226e41c692fc82b8b56ac1c540c5bd
                    </code>
                    <Button size="sm" variant="outline">
                      <Copy className="w-4 h-4" />
                    </Button>
                  </div>
                </div>

                <div className="space-y-4">
                  <h4 className="font-semibold text-gray-900">Wallet Statistics</h4>
                  <div className="space-y-3">
                    <div className="flex justify-between">
                      <span className="text-gray-600">Total Credentials:</span>
                      <span className="font-semibold">3</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Verified Credentials:</span>
                      <span className="font-semibold text-green-600">2</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Total Verifications:</span>
                      <span className="font-semibold">82</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Wallet Created:</span>
                      <span className="font-semibold">Dec 15, 2023</span>
                    </div>
                  </div>
                </div>
              </div>

              <div className="border-t pt-6">
                <h4 className="font-semibold text-gray-900 mb-4">Backup & Security</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <Button variant="outline" className="flex items-center gap-2">
                    <Download className="w-4 h-4" />
                    Download Backup
                  </Button>
                  <Button variant="outline" className="flex items-center gap-2">
                    <Key className="w-4 h-4" />
                    Export Private Key
                  </Button>
                  <Button variant="outline" className="flex items-center gap-2">
                    <QrCode className="w-4 h-4" />
                    Wallet QR Code
                  </Button>
                  <Button variant="outline" className="flex items-center gap-2">
                    <FileText className="w-4 h-4" />
                    Recovery Phrase
                  </Button>
                </div>
              </div>

              <Alert>
                <Lock className="h-4 w-4" />
                <AlertDescription>
                  Your private keys are encrypted and stored securely. Never share your private key or recovery phrase with anyone.
                </AlertDescription>
              </Alert>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}

export default function BlockchainCertificates() {
  const config = platformConfigs.candidate;
  const theme = useThemeClasses('candidate');
  
  const usageData = [
    { label: "Verified Certificates", current: 8, max: 15 },
    { label: "Blockchain Security", current: 95, max: 100 },
    { label: "Verification Rate", current: 98, max: 100 },
  ];

  return (
    <PlatformLayout
      sidebarTitle={config.sidebarTitle}
      sidebarSubtitle={config.sidebarSubtitle}
      sidebarSections={config.sidebarSections}
      usageData={usageData}
    >
      <BlockchainCertificatesContent />
    </PlatformLayout>
  );
}