import PlatformLayout from "@/components/layout/platform-layout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Grid3X3, Search, Filter, Star, Eye, GitBranch, Download, Heart, TrendingUp, Calendar, Users, Code, Globe, Zap, Smartphone, Database, Cpu } from "lucide-react";
import { platformConfigs } from "@/config/complete-navigation";

export default function ProjectGallery() {
  const config = platformConfigs.candidate;

  const featuredProjects = [
    {
      id: 1,
      name: "TaskFlow - Project Management",
      author: "Sarah Chen",
      authorAvatar: "/api/placeholder/40/40",
      description: "Modern project management app with Kanban boards, real-time collaboration, and advanced analytics",
      image: "/api/placeholder/300/200",
      tech: ["React", "Node.js", "Socket.io", "PostgreSQL", "Redux"],
      category: "Full-Stack",
      difficulty: "Advanced",
      stars: 234,
      forks: 89,
      views: 5420,
      lastUpdated: "2024-02-15",
      demoUrl: "https://taskflow-demo.com",
      githubUrl: "https://github.com/sarahchen/taskflow",
      color: "from-blue-500 to-indigo-500",
      featured: true
    },
    {
      id: 2,
      name: "EcoTracker - Carbon Footprint",
      author: "Alex Rodriguez",
      authorAvatar: "/api/placeholder/40/40",
      description: "Mobile app for tracking personal carbon footprint with AI recommendations and community challenges",
      image: "/api/placeholder/300/200",
      tech: ["React Native", "Expo", "Firebase", "TensorFlow", "Charts.js"],
      category: "Mobile",
      difficulty: "Intermediate",
      stars: 156,
      forks: 34,
      views: 2890,
      lastUpdated: "2024-02-12",
      demoUrl: "https://ecotracker.app",
      githubUrl: "https://github.com/alexr/ecotracker",
      color: "from-green-500 to-emerald-500",
      featured: true
    },
    {
      id: 3,
      name: "CryptoWatch - Portfolio Tracker",
      author: "Michael Kim",
      authorAvatar: "/api/placeholder/40/40",
      description: "Real-time cryptocurrency portfolio tracker with advanced charts and market analysis",
      image: "/api/placeholder/300/200",
      tech: ["Vue.js", "Python", "FastAPI", "Redis", "D3.js"],
      category: "Frontend",
      difficulty: "Intermediate",
      stars: 189,
      forks: 67,
      views: 4210,
      lastUpdated: "2024-02-10",
      demoUrl: "https://cryptowatch.dev",
      githubUrl: "https://github.com/mkim/cryptowatch",
      color: "from-yellow-500 to-orange-500",
      featured: true
    }
  ];

  const communityProjects = [
    {
      id: 4,
      name: "DevBlog CMS",
      author: "Lisa Wang",
      authorAvatar: "/api/placeholder/30/30",
      description: "Headless CMS for developer blogs with markdown support",
      tech: ["Next.js", "Strapi", "GraphQL"],
      category: "Backend",
      difficulty: "Intermediate",
      stars: 78,
      views: 1450,
      color: "from-purple-500 to-pink-500"
    },
    {
      id: 5,
      name: "AI Code Reviewer",
      author: "David Park",
      authorAvatar: "/api/placeholder/30/30",
      description: "AI-powered code review tool with smart suggestions",
      tech: ["Python", "OpenAI", "Docker"],
      category: "AI/ML",
      difficulty: "Advanced",
      stars: 92,
      views: 2100,
      color: "from-cyan-500 to-blue-500"
    },
    {
      id: 6,
      name: "Weather Dashboard",
      author: "Emma Johnson",
      authorAvatar: "/api/placeholder/30/30",
      description: "Beautiful weather dashboard with data visualizations",
      tech: ["React", "D3.js", "Weather API"],
      category: "Frontend",
      difficulty: "Beginner",
      stars: 45,
      views: 890,
      color: "from-indigo-500 to-purple-500"
    },
    {
      id: 7,
      name: "Fitness Tracker API",
      author: "James Wilson",
      authorAvatar: "/api/placeholder/30/30",
      description: "RESTful API for fitness and health data tracking",
      tech: ["Express", "MongoDB", "JWT"],
      category: "Backend",
      difficulty: "Beginner",
      stars: 67,
      views: 1200,
      color: "from-red-500 to-pink-500"
    },
    {
      id: 8,
      name: "Recipe Finder App",
      author: "Sofia Martinez",
      authorAvatar: "/api/placeholder/30/30",
      description: "Mobile app for finding recipes based on ingredients",
      tech: ["Flutter", "Firebase", "ML Kit"],
      category: "Mobile",
      difficulty: "Intermediate",
      stars: 123,
      views: 1800,
      color: "from-orange-500 to-red-500"
    },
    {
      id: 9,
      name: "Smart Home Controller",
      author: "Ryan Chen",
      authorAvatar: "/api/placeholder/30/30",
      description: "IoT dashboard for smart home device management",
      tech: ["React", "MQTT", "Arduino"],
      category: "IoT",
      difficulty: "Advanced",
      stars: 156,
      views: 2400,
      color: "from-teal-500 to-green-500"
    }
  ];

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case "Beginner": return "bg-green-100 text-green-800 border-green-200";
      case "Intermediate": return "bg-yellow-100 text-yellow-800 border-yellow-200";
      case "Advanced": return "bg-red-100 text-red-800 border-red-200";
      default: return "bg-gray-100 text-gray-800 border-gray-200";
    }
  };

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case "Frontend": return <Globe className="h-4 w-4" />;
      case "Backend": return <Database className="h-4 w-4" />;
      case "Full-Stack": return <Code className="h-4 w-4" />;
      case "Mobile": return <Smartphone className="h-4 w-4" />;
      case "AI/ML": return <Cpu className="h-4 w-4" />;
      case "IoT": return <Zap className="h-4 w-4" />;
      default: return <Code className="h-4 w-4" />;
    }
  };

  return (
    <PlatformLayout
      sidebarTitle={config.sidebarTitle}
      sidebarSubtitle={config.sidebarSubtitle}
      sidebarSections={config.sidebarSections}
      usageData={config.usageData}
    >
      <div className="p-6 max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="text-center space-y-4">
          <div className="flex items-center justify-center space-x-3">
            <div className="p-3 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full">
              <Grid3X3 className="h-8 w-8 text-white" />
            </div>
            <h1 className="text-4xl font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
              Project Gallery
            </h1>
          </div>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Discover inspiring projects from the community, fork templates, and collaborate with developers worldwide
          </p>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card className="bg-gradient-to-r from-purple-50 to-pink-50 border-purple-200">
            <CardContent className="p-4 text-center">
              <Grid3X3 className="h-8 w-8 text-purple-500 mx-auto mb-2" />
              <p className="text-2xl font-bold text-purple-600">2.4K</p>
              <p className="text-sm text-muted-foreground">Community Projects</p>
            </CardContent>
          </Card>
          <Card className="bg-gradient-to-r from-blue-50 to-indigo-50 border-blue-200">
            <CardContent className="p-4 text-center">
              <Star className="h-8 w-8 text-blue-500 mx-auto mb-2" />
              <p className="text-2xl font-bold text-blue-600">15.6K</p>
              <p className="text-sm text-muted-foreground">Total Stars</p>
            </CardContent>
          </Card>
          <Card className="bg-gradient-to-r from-green-50 to-emerald-50 border-green-200">
            <CardContent className="p-4 text-center">
              <GitBranch className="h-8 w-8 text-green-500 mx-auto mb-2" />
              <p className="text-2xl font-bold text-green-600">890</p>
              <p className="text-sm text-muted-foreground">Projects Forked</p>
            </CardContent>
          </Card>
          <Card className="bg-gradient-to-r from-orange-50 to-red-50 border-orange-200">
            <CardContent className="p-4 text-center">
              <TrendingUp className="h-8 w-8 text-orange-500 mx-auto mb-2" />
              <p className="text-2xl font-bold text-orange-600">48</p>
              <p className="text-sm text-muted-foreground">Trending This Week</p>
            </CardContent>
          </Card>
        </div>

        {/* Search and Filters */}
        <div className="flex flex-col sm:flex-row gap-4 items-center justify-between">
          <div className="flex items-center space-x-2 flex-1">
            <div className="relative flex-1 max-w-md">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
              <Input
                placeholder="Search projects..."
                className="pl-10"
              />
            </div>
          </div>
          <div className="flex items-center space-x-2">
            <Select defaultValue="all">
              <SelectTrigger className="w-40">
                <SelectValue placeholder="Category" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Categories</SelectItem>
                <SelectItem value="frontend">Frontend</SelectItem>
                <SelectItem value="backend">Backend</SelectItem>
                <SelectItem value="fullstack">Full-Stack</SelectItem>
                <SelectItem value="mobile">Mobile</SelectItem>
                <SelectItem value="ai">AI/ML</SelectItem>
                <SelectItem value="iot">IoT</SelectItem>
              </SelectContent>
            </Select>
            <Select defaultValue="popular">
              <SelectTrigger className="w-40">
                <SelectValue placeholder="Sort by" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="popular">Most Popular</SelectItem>
                <SelectItem value="recent">Most Recent</SelectItem>
                <SelectItem value="stars">Most Stars</SelectItem>
                <SelectItem value="forks">Most Forks</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <Tabs defaultValue="featured" className="space-y-6">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="featured">Featured Projects</TabsTrigger>
            <TabsTrigger value="community">Community Projects</TabsTrigger>
            <TabsTrigger value="trending">Trending</TabsTrigger>
          </TabsList>

          <TabsContent value="featured" className="space-y-6">
            <h2 className="text-2xl font-bold text-purple-700">Featured Projects</h2>
            
            <div className="space-y-6">
              {featuredProjects.map((project) => (
                <Card key={project.id} className="group hover:shadow-lg transition-all duration-300 border-l-4 border-l-purple-500">
                  <CardContent className="p-6">
                    <div className="flex flex-col lg:flex-row gap-6">
                      <div className="lg:w-80 flex-shrink-0">
                        <img 
                          src={project.image} 
                          alt={project.name}
                          className="w-full h-48 object-cover rounded-lg bg-gray-100"
                        />
                      </div>
                      <div className="flex-1 space-y-4">
                        <div>
                          <div className="flex items-start justify-between mb-2">
                            <div>
                              <h3 className="text-xl font-bold text-gray-900">{project.name}</h3>
                              <div className="flex items-center gap-2 mt-1">
                                <img 
                                  src={project.authorAvatar} 
                                  alt={project.author}
                                  className="w-5 h-5 rounded-full"
                                />
                                <span className="text-sm text-muted-foreground">by {project.author}</span>
                                <Badge className={getDifficultyColor(project.difficulty)}>
                                  {project.difficulty}
                                </Badge>
                              </div>
                            </div>
                            <Badge variant="secondary" className="flex items-center gap-1">
                              {getCategoryIcon(project.category)}
                              {project.category}
                            </Badge>
                          </div>
                          <p className="text-muted-foreground">{project.description}</p>
                        </div>

                        <div className="flex flex-wrap gap-1">
                          {project.tech.map((tech, index) => (
                            <Badge key={index} variant="outline" className="text-xs">
                              {tech}
                            </Badge>
                          ))}
                        </div>

                        <div className="flex items-center gap-6 text-sm text-muted-foreground">
                          <div className="flex items-center gap-1">
                            <Star className="h-4 w-4 text-yellow-500" />
                            <span>{project.stars}</span>
                          </div>
                          <div className="flex items-center gap-1">
                            <GitBranch className="h-4 w-4" />
                            <span>{project.forks}</span>
                          </div>
                          <div className="flex items-center gap-1">
                            <Eye className="h-4 w-4" />
                            <span>{project.views}</span>
                          </div>
                          <div className="flex items-center gap-1">
                            <Calendar className="h-4 w-4" />
                            <span>Updated {new Date(project.lastUpdated).toLocaleDateString()}</span>
                          </div>
                        </div>

                        <div className="flex items-center gap-2">
                          <Button className="bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600">
                            <Eye className="h-4 w-4 mr-2" />
                            View Project
                          </Button>
                          <Button variant="outline">
                            <GitBranch className="h-4 w-4 mr-2" />
                            Fork
                          </Button>
                          <Button variant="outline">
                            <Globe className="h-4 w-4 mr-2" />
                            Demo
                          </Button>
                          <Button variant="outline" size="icon">
                            <Heart className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="community" className="space-y-6">
            <h2 className="text-2xl font-bold text-purple-700">Community Projects</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {communityProjects.map((project) => (
                <Card key={project.id} className="group hover:shadow-lg transition-all duration-300 hover:-translate-y-1 border-l-4 border-l-purple-500">
                  <CardHeader className="pb-3">
                    <div className="flex items-start justify-between">
                      <div className={`p-2 bg-gradient-to-r ${project.color} rounded-lg`}>
                        {getCategoryIcon(project.category)}
                      </div>
                      <Badge className={getDifficultyColor(project.difficulty)}>
                        {project.difficulty}
                      </Badge>
                    </div>
                    <CardTitle className="text-lg">{project.name}</CardTitle>
                    <CardDescription className="text-sm">{project.description}</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex items-center gap-2">
                      <img 
                        src={project.authorAvatar} 
                        alt={project.author}
                        className="w-6 h-6 rounded-full"
                      />
                      <span className="text-sm text-muted-foreground">by {project.author}</span>
                    </div>

                    <div className="flex items-center gap-4 text-sm text-muted-foreground">
                      <div className="flex items-center gap-1">
                        <Star className="h-4 w-4 text-yellow-500" />
                        <span>{project.stars}</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <Eye className="h-4 w-4" />
                        <span>{project.views}</span>
                      </div>
                      <Badge variant="secondary" className="text-xs">
                        {project.category}
                      </Badge>
                    </div>

                    <div className="flex flex-wrap gap-1">
                      {project.tech.slice(0, 3).map((tech, index) => (
                        <Badge key={index} variant="outline" className="text-xs">
                          {tech}
                        </Badge>
                      ))}
                      {project.tech.length > 3 && (
                        <Badge variant="outline" className="text-xs">
                          +{project.tech.length - 3}
                        </Badge>
                      )}
                    </div>

                    <div className="flex items-center gap-2">
                      <Button size="sm" className="flex-1 bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600">
                        <Eye className="h-4 w-4 mr-1" />
                        View
                      </Button>
                      <Button size="sm" variant="outline">
                        <GitBranch className="h-4 w-4" />
                      </Button>
                      <Button size="sm" variant="outline">
                        <Heart className="h-4 w-4" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="trending" className="space-y-6">
            <h2 className="text-2xl font-bold text-purple-700">Trending This Week</h2>
            
            <div className="space-y-4">
              {communityProjects.slice(0, 5).map((project, index) => (
                <Card key={project.id} className="hover:shadow-md transition-shadow">
                  <CardContent className="p-4">
                    <div className="flex items-center gap-4">
                      <div className="w-8 h-8 bg-gradient-to-r from-purple-500 to-pink-500 rounded-full flex items-center justify-center text-white font-bold">
                        {index + 1}
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <h3 className="font-semibold">{project.name}</h3>
                          <Badge variant="secondary" className="text-xs">
                            {project.category}
                          </Badge>
                          <Badge className={getDifficultyColor(project.difficulty)}>
                            {project.difficulty}
                          </Badge>
                        </div>
                        <p className="text-sm text-muted-foreground">{project.description}</p>
                      </div>
                      <div className="text-right">
                        <div className="flex items-center gap-4 text-sm text-muted-foreground">
                          <div className="flex items-center gap-1">
                            <Star className="h-4 w-4 text-yellow-500" />
                            <span>{project.stars}</span>
                          </div>
                          <div className="flex items-center gap-1">
                            <TrendingUp className="h-4 w-4 text-green-500" />
                            <span>+{Math.floor(Math.random() * 50)}%</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </PlatformLayout>
  );
}