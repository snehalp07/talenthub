import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import PlatformLayout from "@/components/layout/platform-layout";
import { platformConfigs } from "@/config/complete-navigation";
import { useThemeClasses } from "@/lib/theme-config";
import { 
  TrendingUp, 
  TrendingDown,
  Activity,
  Target,
  Users,
  Briefcase,
  Code,
  Brain,
  Zap,
  Globe,
  BarChart3,
  Calendar,
  AlertTriangle,
  CheckCircle,
  Building
} from "lucide-react";

function MarketTrendsContent() {
  const [selectedIndustry, setSelectedIndustry] = useState("technology");
  const [selectedTimeframe, setSelectedTimeframe] = useState("6months");

  const trendingSkills = [
    {
      skill: "Artificial Intelligence",
      growth: "+45%",
      demand: "Very High",
      avgSalary: "$145,000",
      trend: "up",
      category: "Emerging Tech"
    },
    {
      skill: "React",
      growth: "+25%", 
      demand: "High",
      avgSalary: "$125,000",
      trend: "up",
      category: "Frontend"
    },
    {
      skill: "DevOps",
      growth: "+32%",
      demand: "Very High", 
      avgSalary: "$140,000",
      trend: "up",
      category: "Infrastructure"
    },
    {
      skill: "Cloud Computing",
      growth: "+38%",
      demand: "Very High",
      avgSalary: "$135,000", 
      trend: "up",
      category: "Infrastructure"
    },
    {
      skill: "Cybersecurity",
      growth: "+28%",
      demand: "High",
      avgSalary: "$130,000",
      trend: "up",
      category: "Security"
    },
    {
      skill: "Data Science",
      growth: "+22%",
      demand: "High", 
      avgSalary: "$128,000",
      trend: "up",
      category: "Analytics"
    }
  ];

  const industryTrends = [
    {
      industry: "Technology",
      growth: "+15.2%",
      hiring: "Strong",
      outlook: "Excellent",
      topRoles: ["Software Engineer", "Product Manager", "Data Scientist"],
      avgSalary: "$135,000",
      trend: "up"
    },
    {
      industry: "Healthcare",
      growth: "+12.8%", 
      hiring: "Strong",
      outlook: "Very Good",
      topRoles: ["Healthcare IT", "Medical Research", "Telehealth"],
      avgSalary: "$95,000",
      trend: "up"
    },
    {
      industry: "Finance",
      growth: "+8.5%",
      hiring: "Moderate", 
      outlook: "Good",
      topRoles: ["FinTech Developer", "Risk Analyst", "Blockchain"],
      avgSalary: "$115,000",
      trend: "stable"
    },
    {
      industry: "E-commerce",
      growth: "+18.3%",
      hiring: "Very Strong",
      outlook: "Excellent", 
      topRoles: ["Frontend Developer", "DevOps", "Mobile Developer"],
      avgSalary: "$125,000",
      trend: "up"
    }
  ];

  const marketInsights = [
    {
      insight: "Remote Work Adoption",
      impact: "High",
      description: "85% of companies now offer remote or hybrid options",
      trend: "Growing",
      effect: "Increased competition across geographic boundaries"
    },
    {
      insight: "AI Integration",
      impact: "Very High", 
      description: "Companies investing heavily in AI capabilities",
      trend: "Accelerating",
      effect: "New roles emerging, traditional roles evolving"
    },
    {
      insight: "Skills-Based Hiring",
      impact: "Medium",
      description: "Focus shifting from degrees to demonstrable skills",
      trend: "Growing",
      effect: "Opportunities for self-taught professionals"
    },
    {
      insight: "Startup Activity",
      impact: "High",
      description: "Venture funding remains strong despite market conditions", 
      trend: "Stable",
      effect: "Continued demand for early-stage talent"
    }
  ];

  const futureSkills = [
    {
      skill: "Quantum Computing",
      timeframe: "2-3 years",
      potential: "Very High",
      readiness: 15
    },
    {
      skill: "Extended Reality (XR)",
      timeframe: "1-2 years", 
      potential: "High",
      readiness: 35
    },
    {
      skill: "Blockchain Development",
      timeframe: "6-12 months",
      potential: "High", 
      readiness: 60
    },
    {
      skill: "Edge Computing",
      timeframe: "1-2 years",
      potential: "High",
      readiness: 40
    }
  ];

  const getDemandColor = (demand: string) => {
    switch (demand.toLowerCase()) {
      case "very high": return "bg-red-100 text-red-700";
      case "high": return "bg-orange-100 text-orange-700";
      case "medium": return "bg-yellow-100 text-yellow-700";
      case "low": return "bg-blue-100 text-blue-700";
      default: return "bg-gray-100 text-gray-700";
    }
  };

  const getTrendIcon = (trend: string) => {
    switch (trend) {
      case "up": return <TrendingUp className="h-4 w-4 text-green-600" />;
      case "down": return <TrendingDown className="h-4 w-4 text-red-600" />;
      default: return <Activity className="h-4 w-4 text-blue-600" />;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-sky-50 to-white p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Market Trends</h1>
          <p className="text-gray-600">Stay ahead with real-time market insights and future predictions</p>
        </div>

        {/* Key Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card className="border-green-200">
            <CardContent className="p-6 text-center">
              <TrendingUp className="h-8 w-8 text-green-600 mx-auto mb-2" />
              <div className="text-2xl font-bold text-green-700">+15.2%</div>
              <div className="text-sm text-gray-600">Job Market Growth</div>
            </CardContent>
          </Card>
          <Card className="border-blue-200">
            <CardContent className="p-6 text-center">
              <Users className="h-8 w-8 text-blue-600 mx-auto mb-2" />
              <div className="text-2xl font-bold text-blue-700">2.1M</div>
              <div className="text-sm text-gray-600">Open Positions</div>
            </CardContent>
          </Card>
          <Card className="border-purple-200">
            <CardContent className="p-6 text-center">
              <Brain className="h-8 w-8 text-purple-600 mx-auto mb-2" />
              <div className="text-2xl font-bold text-purple-700">85%</div>
              <div className="text-sm text-gray-600">Remote-Friendly</div>
            </CardContent>
          </Card>
          <Card className="border-orange-200">
            <CardContent className="p-6 text-center">
              <Zap className="h-8 w-8 text-orange-600 mx-auto mb-2" />
              <div className="text-2xl font-bold text-orange-700">23</div>
              <div className="text-sm text-gray-600">Emerging Skills</div>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="trending-skills" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="trending-skills">Trending Skills</TabsTrigger>
            <TabsTrigger value="industry-outlook">Industry Outlook</TabsTrigger>
            <TabsTrigger value="market-insights">Market Insights</TabsTrigger>
            <TabsTrigger value="future-skills">Future Skills</TabsTrigger>
          </TabsList>

          {/* Trending Skills Tab */}
          <TabsContent value="trending-skills">
            <div className="space-y-6">
              {/* Filters */}
              <Card>
                <CardContent className="p-6">
                  <div className="flex gap-4">
                    <Select value={selectedIndustry} onValueChange={setSelectedIndustry}>
                      <SelectTrigger className="w-48">
                        <SelectValue placeholder="Select Industry" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="technology">Technology</SelectItem>
                        <SelectItem value="healthcare">Healthcare</SelectItem>
                        <SelectItem value="finance">Finance</SelectItem>
                        <SelectItem value="e-commerce">E-commerce</SelectItem>
                      </SelectContent>
                    </Select>
                    <Select value={selectedTimeframe} onValueChange={setSelectedTimeframe}>
                      <SelectTrigger className="w-48">
                        <SelectValue placeholder="Select Timeframe" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="3months">Last 3 Months</SelectItem>
                        <SelectItem value="6months">Last 6 Months</SelectItem>
                        <SelectItem value="1year">Last Year</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </CardContent>
              </Card>

              {/* Skills Grid */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {trendingSkills.map((skill, index) => (
                  <Card key={index} className="hover:shadow-lg transition-shadow">
                    <CardContent className="p-6">
                      <div className="flex items-center justify-between mb-4">
                        <div className="flex items-center gap-3">
                          <div className="w-12 h-12 bg-sky-100 rounded-lg flex items-center justify-center">
                            <Code className="h-6 w-6 text-sky-600" />
                          </div>
                          <div>
                            <h3 className="font-semibold text-gray-900">{skill.skill}</h3>
                            <Badge variant="outline" className="text-xs">
                              {skill.category}
                            </Badge>
                          </div>
                        </div>
                        <div className="text-right">
                          <div className="flex items-center gap-1 mb-1">
                            {getTrendIcon(skill.trend)}
                            <span className="font-bold text-green-600">{skill.growth}</span>
                          </div>
                          <div className="text-xs text-gray-500">Growth</div>
                        </div>
                      </div>

                      <div className="grid grid-cols-2 gap-4 mb-4">
                        <div>
                          <div className="text-sm text-gray-600">Market Demand</div>
                          <Badge className={getDemandColor(skill.demand)}>
                            {skill.demand}
                          </Badge>
                        </div>
                        <div>
                          <div className="text-sm text-gray-600">Avg Salary</div>
                          <div className="font-bold text-green-600">{skill.avgSalary}</div>
                        </div>
                      </div>

                      <div className="space-y-2">
                        <div className="flex justify-between text-sm">
                          <span>Market Saturation</span>
                          <span>Low</span>
                        </div>
                        <Progress value={25} className="h-2" />
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          </TabsContent>

          {/* Industry Outlook Tab */}
          <TabsContent value="industry-outlook">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {industryTrends.map((industry, index) => (
                <Card key={index} className="border-2">
                  <CardHeader>
                    <div className="flex justify-between items-start">
                      <CardTitle className="flex items-center gap-2">
                        <Building className="h-5 w-5 text-sky-600" />
                        {industry.industry}
                      </CardTitle>
                      <Badge className={industry.trend === 'up' ? 'bg-green-100 text-green-700' : 'bg-blue-100 text-blue-700'}>
                        {getTrendIcon(industry.trend)}
                        {industry.growth}
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <div className="text-sm text-gray-600">Hiring Activity</div>
                        <Badge className={getDemandColor(industry.hiring)}>
                          {industry.hiring}
                        </Badge>
                      </div>
                      <div>
                        <div className="text-sm text-gray-600">12-Month Outlook</div>
                        <Badge className="bg-green-100 text-green-700">
                          {industry.outlook}
                        </Badge>
                      </div>
                    </div>

                    <div>
                      <div className="text-sm text-gray-600 mb-2">Average Salary</div>
                      <div className="text-2xl font-bold text-green-600">{industry.avgSalary}</div>
                    </div>

                    <div>
                      <div className="text-sm text-gray-600 mb-2">Top Roles in Demand</div>
                      <div className="flex flex-wrap gap-2">
                        {industry.topRoles.map((role) => (
                          <Badge key={role} variant="outline" className="text-xs">
                            {role}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Market Insights Tab */}
          <TabsContent value="market-insights">
            <div className="space-y-6">
              {marketInsights.map((insight, index) => (
                <Card key={index}>
                  <CardContent className="p-6">
                    <div className="flex items-start justify-between mb-4">
                      <div className="flex items-center gap-3">
                        <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center">
                          <BarChart3 className="h-6 w-6 text-orange-600" />
                        </div>
                        <div>
                          <h3 className="font-semibold text-gray-900">{insight.insight}</h3>
                          <Badge className={getDemandColor(insight.impact)}>
                            {insight.impact} Impact
                          </Badge>
                        </div>
                      </div>
                      <Badge variant="outline" className="text-green-600 border-green-200">
                        {insight.trend}
                      </Badge>
                    </div>

                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                      <div>
                        <h4 className="font-medium text-gray-900 mb-2">Market Analysis</h4>
                        <p className="text-gray-600">{insight.description}</p>
                      </div>
                      <div>
                        <h4 className="font-medium text-gray-900 mb-2">Career Impact</h4>
                        <p className="text-gray-600">{insight.effect}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Future Skills Tab */}
          <TabsContent value="future-skills">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Globe className="h-5 w-5 text-sky-600" />
                  Emerging Skills to Watch
                </CardTitle>
                <CardDescription>Skills that will be in high demand in the coming years</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  {futureSkills.map((skill, index) => (
                    <div key={index} className="flex items-center justify-between p-4 border rounded-lg">
                      <div className="flex items-center gap-4">
                        <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
                          <Zap className="h-6 w-6 text-purple-600" />
                        </div>
                        <div>
                          <h4 className="font-medium text-gray-900">{skill.skill}</h4>
                          <div className="flex items-center gap-4 text-sm text-gray-600">
                            <div className="flex items-center gap-1">
                              <Calendar className="h-4 w-4" />
                              <span>Timeline: {skill.timeframe}</span>
                            </div>
                            <Badge className={getDemandColor(skill.potential)}>
                              {skill.potential} Potential
                            </Badge>
                          </div>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="text-sm text-gray-600 mb-2">Market Readiness</div>
                        <div className="w-32">
                          <Progress value={skill.readiness} className="h-2" />
                          <div className="text-xs text-gray-500 mt-1">{skill.readiness}%</div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>

                <div className="mt-8 p-6 bg-blue-50 rounded-lg border border-blue-200">
                  <div className="flex items-start gap-3">
                    <CheckCircle className="h-5 w-5 text-blue-600 mt-0.5" />
                    <div>
                      <h4 className="font-medium text-blue-900">Recommendation</h4>
                      <p className="text-sm text-blue-700 mt-1">
                        Start building skills in AI and machine learning now. These technologies are 
                        rapidly becoming essential across all industries, not just tech.
                      </p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}

export default function MarketTrends() {
  const config = platformConfigs.candidate;
  const theme = useThemeClasses('candidate');
  
  const usageData = [
    { label: "Market Analysis", current: 12, max: 20 },
    { label: "Trending Skills", current: 8, max: 15 },
    { label: "Industry Insights", current: 75, max: 100 },
  ];

  return (
    <PlatformLayout
      sidebarTitle={config.sidebarTitle}
      sidebarSubtitle={config.sidebarSubtitle}
      sidebarSections={config.sidebarSections}
      usageData={usageData}
    >
      <MarketTrendsContent />
    </PlatformLayout>
  );
}