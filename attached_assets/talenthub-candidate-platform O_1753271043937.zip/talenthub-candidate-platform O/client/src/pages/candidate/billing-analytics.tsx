import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import PlatformLayout from "@/components/layout/platform-layout";
import { candidateNavigation } from "@/config/complete-navigation";
import { 
  BarChart3, TrendingUp, TrendingDown, PieChart, DollarSign,
  Calendar, Target, Zap, Coins, AlertTriangle, CheckCircle,
  ArrowUp, ArrowDown, Activity, Clock, Award, Brain,
  Video, FileText, Briefcase, Users, Shield, Globe,
  LineChart, Settings, Download, Share, Lightbulb
} from "lucide-react";

const BillingAnalytics: React.FC = () => {
  const [activeTab, setActiveTab] = useState('overview');
  const [selectedPeriod, setSelectedPeriod] = useState('current');

  // Comprehensive analytics data
  const analyticsData = {
    current: {
      period: 'December 2024',
      totalSpent: 287.50,
      subscriptionCost: 299.00,
      creditsCost: 147.50,
      creditsUsed: 245,
      costPerCredit: 0.60,
      projectedMonthlySpend: 320.00,
      savingsOpportunity: 85.50,
      utilizationRate: 73,
      features: {
        skillsCertification: { credits: 89, cost: 53.40, sessions: 12, avgCostPerSession: 4.45 },
        assessmentTesting: { credits: 67, cost: 40.20, sessions: 8, avgCostPerSession: 5.03 },
        profileBranding: { credits: 45, cost: 27.00, sessions: 3, avgCostPerSession: 9.00 },
        interviewPrep: { credits: 38, cost: 22.80, sessions: 4, avgCostPerSession: 5.70 },
        jobSearchEnhancement: { credits: 23, cost: 13.80, sessions: 15, avgCostPerSession: 0.92 },
        projectPortfolio: { credits: 18, cost: 10.80, sessions: 2, avgCostPerSession: 5.40 },
        networking: { credits: 15, cost: 9.00, sessions: 6, avgCostPerSession: 1.50 }
      }
    },
    previous: {
      period: 'November 2024',
      totalSpent: 234.75,
      creditsUsed: 198,
      features: {
        skillsCertification: { credits: 72, cost: 43.20, sessions: 9 },
        assessmentTesting: { credits: 54, cost: 32.40, sessions: 6 },
        profileBranding: { credits: 38, cost: 22.80, sessions: 2 },
        interviewPrep: { credits: 22, cost: 13.20, sessions: 3 },
        jobSearchEnhancement: { credits: 18, cost: 10.80, sessions: 12 },
        projectPortfolio: { credits: 12, cost: 7.20, sessions: 1 },
        networking: { credits: 10, cost: 6.00, sessions: 4 }
      }
    }
  };

  const currentData = analyticsData.current;
  const previousData = analyticsData.previous;

  // Usage trends and predictions
  const usageTrends = [
    { month: 'Aug', credits: 156, cost: 93.60 },
    { month: 'Sep', credits: 178, cost: 106.80 },
    { month: 'Oct', credits: 189, cost: 113.40 },
    { month: 'Nov', credits: 198, cost: 118.80 },
    { month: 'Dec', credits: 245, cost: 147.00 },
    { month: 'Jan (Proj)', credits: 267, cost: 160.20 }
  ];

  const optimizationRecommendations = [
    {
      category: 'Subscription Upgrade',
      impact: 'High',
      savings: '$45/month',
      description: 'Upgrade to Enterprise plan for better value on job applications',
      color: 'from-green-500 to-green-600',
      icon: TrendingUp
    },
    {
      category: 'Feature Bundling',
      impact: 'Medium',
      savings: '$25/month',
      description: 'Bundle profile and interview features for 20% discount',
      color: 'from-blue-500 to-blue-600',
      icon: Target
    },
    {
      category: 'Credit Purchase Timing',
      impact: 'Medium',
      savings: '$15/month',
      description: 'Buy credits in bulk during promotional periods',
      color: 'from-purple-500 to-purple-600',
      icon: Calendar
    },
    {
      category: 'Usage Optimization',
      impact: 'Low',
      savings: '$8/month',
      description: 'Optimize feature usage timing for maximum effectiveness',
      color: 'from-orange-500 to-orange-600',
      icon: Clock
    }
  ];

  const featureAnalytics = [
    {
      name: 'Skills Certification',
      icon: Award,
      color: 'text-blue-600',
      bgColor: 'from-blue-500 to-blue-600',
      credits: currentData.features.skillsCertification.credits,
      cost: currentData.features.skillsCertification.cost,
      sessions: currentData.features.skillsCertification.sessions,
      avgCost: currentData.features.skillsCertification.avgCostPerSession,
      growth: ((currentData.features.skillsCertification.credits - previousData.features.skillsCertification.credits) / previousData.features.skillsCertification.credits * 100),
      efficiency: 85,
      roi: 'High',
      recommendations: [
        'Consider certification packages for better value',
        'Bundle multiple skills for discounts'
      ]
    },
    {
      name: 'Assessment Testing',
      icon: Target,
      color: 'text-green-600',
      bgColor: 'from-green-500 to-green-600',
      credits: currentData.features.assessmentTesting.credits,
      cost: currentData.features.assessmentTesting.cost,
      sessions: currentData.features.assessmentTesting.sessions,
      avgCost: currentData.features.assessmentTesting.avgCostPerSession,
      growth: ((currentData.features.assessmentTesting.credits - previousData.features.assessmentTesting.credits) / previousData.features.assessmentTesting.credits * 100),
      efficiency: 78,
      roi: 'High',
      recommendations: [
        'Focus on premium assessments for better insights',
        'Schedule assessments for optimal performance'
      ]
    },
    {
      name: 'Profile & Branding',
      icon: Video,
      color: 'text-purple-600',
      bgColor: 'from-purple-500 to-purple-600',
      credits: currentData.features.profileBranding.credits,
      cost: currentData.features.profileBranding.cost,
      sessions: currentData.features.profileBranding.sessions,
      avgCost: currentData.features.profileBranding.avgCostPerSession,
      growth: ((currentData.features.profileBranding.credits - previousData.features.profileBranding.credits) / previousData.features.profileBranding.credits * 100),
      efficiency: 92,
      roi: 'Very High',
      recommendations: [
        'Video CV shows excellent engagement rates',
        'Consider AI optimization for better results'
      ]
    },
    {
      name: 'Interview Preparation',
      icon: Brain,
      color: 'text-orange-600',
      bgColor: 'from-orange-500 to-orange-600',
      credits: currentData.features.interviewPrep.credits,
      cost: currentData.features.interviewPrep.cost,
      sessions: currentData.features.interviewPrep.sessions,
      avgCost: currentData.features.interviewPrep.avgCostPerSession,
      growth: ((currentData.features.interviewPrep.credits - previousData.features.interviewPrep.credits) / previousData.features.interviewPrep.credits * 100),
      efficiency: 73,
      roi: 'High',
      recommendations: [
        'AI mock interviews provide best value',
        'Schedule practice sessions before applications'
      ]
    },
    {
      name: 'Job Search Enhancement',
      icon: Briefcase,
      color: 'text-cyan-600',
      bgColor: 'from-cyan-500 to-cyan-600',
      credits: currentData.features.jobSearchEnhancement.credits,
      cost: currentData.features.jobSearchEnhancement.cost,
      sessions: currentData.features.jobSearchEnhancement.sessions,
      avgCost: currentData.features.jobSearchEnhancement.avgCostPerSession,
      growth: ((currentData.features.jobSearchEnhancement.credits - previousData.features.jobSearchEnhancement.credits) / previousData.features.jobSearchEnhancement.credits * 100),
      efficiency: 67,
      roi: 'Medium',
      recommendations: [
        'Focus on quality over quantity for applications',
        'Use AI matching for better results'
      ]
    },
    {
      name: 'Project Portfolio',
      icon: FileText,
      color: 'text-pink-600',
      bgColor: 'from-pink-500 to-pink-600',
      credits: currentData.features.projectPortfolio.credits,
      cost: currentData.features.projectPortfolio.cost,
      sessions: currentData.features.projectPortfolio.sessions,
      avgCost: currentData.features.projectPortfolio.avgCostPerSession,
      growth: ((currentData.features.projectPortfolio.credits - previousData.features.projectPortfolio.credits) / previousData.features.projectPortfolio.credits * 100),
      efficiency: 88,
      roi: 'Very High',
      recommendations: [
        'Code analysis provides excellent career value',
        'Consider project certification for credibility'
      ]
    }
  ];

  const costBreakdown = [
    { category: 'Skills & Certification', percentage: 36, amount: 53.40, color: 'bg-blue-500' },
    { category: 'Assessment & Testing', percentage: 27, amount: 40.20, color: 'bg-green-500' },
    { category: 'Profile & Branding', percentage: 18, amount: 27.00, color: 'bg-purple-500' },
    { category: 'Interview Preparation', percentage: 15, amount: 22.80, color: 'bg-orange-500' },
    { category: 'Job Search', percentage: 9, amount: 13.80, color: 'bg-cyan-500' },
    { category: 'Others', percentage: 13, amount: 19.80, color: 'bg-gray-500' }
  ];

  const getRoiBadge = (roi: string) => {
    const colors = {
      'Very High': 'bg-green-100 text-green-800',
      'High': 'bg-blue-100 text-blue-800',
      'Medium': 'bg-yellow-100 text-yellow-800',
      'Low': 'bg-red-100 text-red-800'
    };
    return <Badge className={colors[roi as keyof typeof colors] || colors.Medium}>{roi} ROI</Badge>;
  };

  const getGrowthIndicator = (growth: number) => {
    if (growth > 0) {
      return (
        <div className="flex items-center text-green-600">
          <ArrowUp className="h-4 w-4 mr-1" />
          <span className="text-sm">+{growth.toFixed(1)}%</span>
        </div>
      );
    } else {
      return (
        <div className="flex items-center text-red-600">
          <ArrowDown className="h-4 w-4 mr-1" />
          <span className="text-sm">{growth.toFixed(1)}%</span>
        </div>
      );
    }
  };

  return (
    <PlatformLayout
      sidebarTitle="Candidate Platform"
      sidebarSubtitle="Billing Analytics"
      sidebarSections={candidateNavigation}
    >
      <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-white to-cyan-50">
        {/* Header Section */}
        <div className="bg-gradient-to-r from-indigo-600 to-cyan-600 text-white p-8">
          <div className="max-w-7xl mx-auto">
            <div className="flex items-center gap-3 mb-4">
              <BarChart3 className="h-8 w-8" />
              <h1 className="text-3xl font-bold">Billing Analytics & Insights</h1>
            </div>
            <p className="text-indigo-100 text-lg">
              Comprehensive analytics for hybrid billing model with pay-per-usage optimization
            </p>
          </div>
        </div>

        <div className="max-w-7xl mx-auto p-8">
          {/* Key Metrics Overview */}
          <div className="grid grid-cols-2 lg:grid-cols-6 gap-4 mb-8">
            <Card className="text-center">
              <CardContent className="p-4">
                <DollarSign className="h-6 w-6 text-green-600 mx-auto mb-2" />
                <div className="text-xl font-bold">${currentData.totalSpent}</div>
                <div className="text-xs text-gray-600">Total Spent</div>
              </CardContent>
            </Card>
            <Card className="text-center">
              <CardContent className="p-4">
                <Coins className="h-6 w-6 text-blue-600 mx-auto mb-2" />
                <div className="text-xl font-bold">{currentData.creditsUsed}</div>
                <div className="text-xs text-gray-600">Credits Used</div>
              </CardContent>
            </Card>
            <Card className="text-center">
              <CardContent className="p-4">
                <TrendingUp className="h-6 w-6 text-purple-600 mx-auto mb-2" />
                <div className="text-xl font-bold">{currentData.utilizationRate}%</div>
                <div className="text-xs text-gray-600">Utilization</div>
              </CardContent>
            </Card>
            <Card className="text-center">
              <CardContent className="p-4">
                <Target className="h-6 w-6 text-orange-600 mx-auto mb-2" />
                <div className="text-xl font-bold">${currentData.costPerCredit.toFixed(2)}</div>
                <div className="text-xs text-gray-600">Cost/Credit</div>
              </CardContent>
            </Card>
            <Card className="text-center">
              <CardContent className="p-4">
                <Calendar className="h-6 w-6 text-cyan-600 mx-auto mb-2" />
                <div className="text-xl font-bold">${currentData.projectedMonthlySpend}</div>
                <div className="text-xs text-gray-600">Projected</div>
              </CardContent>
            </Card>
            <Card className="text-center">
              <CardContent className="p-4">
                <Lightbulb className="h-6 w-6 text-yellow-600 mx-auto mb-2" />
                <div className="text-xl font-bold">${currentData.savingsOpportunity}</div>
                <div className="text-xs text-gray-600">Savings Opp.</div>
              </CardContent>
            </Card>
          </div>

          <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="overview" className="flex items-center gap-2">
                <PieChart className="h-4 w-4" />
                Cost Overview
              </TabsTrigger>
              <TabsTrigger value="features" className="flex items-center gap-2">
                <Activity className="h-4 w-4" />
                Feature Analytics
              </TabsTrigger>
              <TabsTrigger value="trends" className="flex items-center gap-2">
                <LineChart className="h-4 w-4" />
                Usage Trends
              </TabsTrigger>
              <TabsTrigger value="optimize" className="flex items-center gap-2">
                <Zap className="h-4 w-4" />
                Optimization
              </TabsTrigger>
            </TabsList>

            {/* Cost Overview Tab */}
            <TabsContent value="overview" className="space-y-6">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Cost Breakdown */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <PieChart className="h-5 w-5 text-blue-600" />
                      Cost Breakdown by Category
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {costBreakdown.map((item, index) => (
                      <div key={index}>
                        <div className="flex justify-between text-sm mb-1">
                          <span>{item.category}</span>
                          <span className="font-medium">${item.amount}</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <Progress value={item.percentage} className="flex-1 h-2" />
                          <span className="text-xs text-gray-600 w-12">{item.percentage}%</span>
                        </div>
                      </div>
                    ))}
                  </CardContent>
                </Card>

                {/* Monthly Comparison */}
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <TrendingUp className="h-5 w-5 text-green-600" />
                      Month-over-Month Comparison
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div className="text-center p-4 bg-blue-50 rounded-lg">
                        <div className="text-2xl font-bold text-blue-600">${currentData.totalSpent}</div>
                        <div className="text-sm text-gray-600">This Month</div>
                      </div>
                      <div className="text-center p-4 bg-gray-50 rounded-lg">
                        <div className="text-2xl font-bold text-gray-600">${previousData.totalSpent}</div>
                        <div className="text-sm text-gray-600">Last Month</div>
                      </div>
                    </div>
                    <div className="text-center">
                      <div className="flex items-center justify-center gap-2">
                        <TrendingUp className="h-5 w-5 text-orange-600" />
                        <span className="text-lg font-bold text-orange-600">
                          +{((currentData.totalSpent - previousData.totalSpent) / previousData.totalSpent * 100).toFixed(1)}%
                        </span>
                      </div>
                      <div className="text-sm text-gray-600">Increase from last month</div>
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Subscription vs Credits */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <BarChart3 className="h-5 w-5 text-purple-600" />
                    Hybrid Billing Model Analysis
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                    <div className="text-center p-6 bg-gradient-to-r from-blue-500 to-blue-600 text-white rounded-lg">
                      <div className="text-2xl font-bold">${currentData.subscriptionCost}</div>
                      <div className="text-blue-100">Annual Subscription</div>
                      <div className="text-sm text-blue-200 mt-2">Base platform access</div>
                    </div>
                    <div className="text-center p-6 bg-gradient-to-r from-purple-500 to-purple-600 text-white rounded-lg">
                      <div className="text-2xl font-bold">${currentData.creditsCost}</div>
                      <div className="text-purple-100">Credits This Month</div>
                      <div className="text-sm text-purple-200 mt-2">Premium features</div>
                    </div>
                    <div className="text-center p-6 bg-gradient-to-r from-green-500 to-green-600 text-white rounded-lg">
                      <div className="text-2xl font-bold">{currentData.utilizationRate}%</div>
                      <div className="text-green-100">Utilization Rate</div>
                      <div className="text-sm text-green-200 mt-2">Feature efficiency</div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Feature Analytics Tab */}
            <TabsContent value="features" className="space-y-6">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {featureAnalytics.map((feature, index) => {
                  const Icon = feature.icon;
                  return (
                    <Card key={index} className="hover:shadow-lg transition-all duration-300">
                      <div className={`h-16 bg-gradient-to-r ${feature.bgColor} flex items-center justify-center`}>
                        <Icon className="h-8 w-8 text-white" />
                      </div>
                      
                      <CardHeader className="pb-2">
                        <div className="flex items-center justify-between">
                          <CardTitle className="text-lg">{feature.name}</CardTitle>
                          {getRoiBadge(feature.roi)}
                        </div>
                      </CardHeader>
                      
                      <CardContent className="space-y-4">
                        <div className="grid grid-cols-2 gap-4 text-sm">
                          <div>
                            <div className="text-gray-600">Credits Used</div>
                            <div className="font-bold text-lg flex items-center gap-2">
                              {feature.credits}
                              {getGrowthIndicator(feature.growth)}
                            </div>
                          </div>
                          <div>
                            <div className="text-gray-600">Total Cost</div>
                            <div className="font-bold text-lg">${feature.cost}</div>
                          </div>
                          <div>
                            <div className="text-gray-600">Sessions</div>
                            <div className="font-medium">{feature.sessions}</div>
                          </div>
                          <div>
                            <div className="text-gray-600">Avg Cost/Session</div>
                            <div className="font-medium">${feature.avgCost.toFixed(2)}</div>
                          </div>
                        </div>
                        
                        <div>
                          <div className="flex justify-between text-sm mb-1">
                            <span>Efficiency Score</span>
                            <span>{feature.efficiency}%</span>
                          </div>
                          <Progress value={feature.efficiency} className="h-2" />
                        </div>
                        
                        <div>
                          <div className="text-sm font-medium text-gray-700 mb-2">Recommendations:</div>
                          <ul className="text-sm space-y-1">
                            {feature.recommendations.map((rec, recIndex) => (
                              <li key={recIndex} className="flex items-start gap-2">
                                <CheckCircle className="h-3 w-3 text-green-600 mt-1 flex-shrink-0" />
                                {rec}
                              </li>
                            ))}
                          </ul>
                        </div>
                      </CardContent>
                    </Card>
                  );
                })}
              </div>
            </TabsContent>

            {/* Usage Trends Tab */}
            <TabsContent value="trends" className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <LineChart className="h-5 w-5 text-blue-600" />
                    Usage Trends & Projections
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-6">
                    {usageTrends.map((trend, index) => (
                      <div key={index} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                        <div className="flex items-center gap-4">
                          <div className="text-sm font-medium w-20">{trend.month}</div>
                          <div className="flex-1">
                            <div className="flex justify-between text-sm mb-1">
                              <span>Credits: {trend.credits}</span>
                              <span>Cost: ${trend.cost}</span>
                            </div>
                            <Progress value={(trend.credits / 300) * 100} className="h-2" />
                          </div>
                        </div>
                        {index === usageTrends.length - 1 && (
                          <Badge className="bg-blue-100 text-blue-800">Projected</Badge>
                        )}
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Optimization Tab */}
            <TabsContent value="optimize" className="space-y-6">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {optimizationRecommendations.map((rec, index) => {
                  const Icon = rec.icon;
                  return (
                    <Card key={index} className="hover:shadow-lg transition-all duration-300">
                      <div className={`h-20 bg-gradient-to-r ${rec.color} flex items-center justify-center`}>
                        <Icon className="h-10 w-10 text-white" />
                      </div>
                      
                      <CardHeader>
                        <div className="flex items-center justify-between">
                          <CardTitle className="text-lg">{rec.category}</CardTitle>
                          <Badge className={`${rec.impact === 'High' ? 'bg-red-100 text-red-800' : rec.impact === 'Medium' ? 'bg-yellow-100 text-yellow-800' : 'bg-green-100 text-green-800'}`}>
                            {rec.impact} Impact
                          </Badge>
                        </div>
                        <div className="text-2xl font-bold text-green-600">{rec.savings}</div>
                      </CardHeader>
                      
                      <CardContent>
                        <p className="text-gray-700 mb-4">{rec.description}</p>
                        <Button className="w-full">
                          Apply Optimization
                        </Button>
                      </CardContent>
                    </Card>
                  );
                })}
              </div>

              {/* Smart Insights */}
              <Card className="bg-gradient-to-r from-indigo-500 to-purple-600 text-white">
                <CardContent className="p-8">
                  <h3 className="text-2xl font-bold mb-4 flex items-center gap-2">
                    <Brain className="h-8 w-8" />
                    AI-Powered Billing Insights
                  </h3>
                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    <div>
                      <h4 className="font-semibold mb-3">Smart Recommendations</h4>
                      <ul className="space-y-2 text-indigo-100">
                        <li>• Your profile features show 92% efficiency - continue investing</li>
                        <li>• Consider upgrading to Enterprise for 25% savings on job applications</li>
                        <li>• Best time to buy credits: End of month promotions</li>
                        <li>• Bundle interview + assessment features for 20% discount</li>
                      </ul>
                    </div>
                    <div>
                      <h4 className="font-semibold mb-3">Predicted Outcomes</h4>
                      <ul className="space-y-2 text-indigo-100">
                        <li>• With current usage: $3,840 annual spend projected</li>
                        <li>• Optimization potential: Save $1,026 annually</li>
                        <li>• ROI improvement: 34% with recommended changes</li>
                        <li>• Career advancement probability: 87% within 6 months</li>
                      </ul>
                    </div>
                  </div>
                  <div className="flex gap-4 mt-6">
                    <Button className="bg-white text-indigo-600 hover:bg-gray-100">
                      <Download className="h-4 w-4 mr-2" />
                      Download Report
                    </Button>
                    <Button variant="outline" className="border-white text-white hover:bg-white/10">
                      <Share className="h-4 w-4 mr-2" />
                      Share Insights
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </PlatformLayout>
  );
};

export default BillingAnalytics;