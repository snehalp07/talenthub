import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import PlatformLayout from "@/components/layout/platform-layout";
import { platformConfigs } from "@/config/complete-navigation";
import { useThemeClasses } from "@/lib/theme-config";
import { 
  Users, 
  UserPlus, 
  MessageSquare,
  Calendar,
  Search,
  Filter,
  MapPin,
  Briefcase,
  Star,
  Eye,
  Send,
  Phone,
  Mail,
  Linkedin,
  Coffee,
  Video,
  Plus,
  TrendingUp,
  Award,
  Target
} from "lucide-react";

function NetworkingContent() {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("all");

  const networkingStats = {
    totalConnections: 247,
    newThisMonth: 18,
    messagesSent: 45,
    eventsAttended: 3,
    referralsReceived: 7
  };

  const connections = [
    {
      id: "1",
      name: "Sarah Johnson",
      title: "Senior Engineering Manager",
      company: "TechCorp Inc.",
      location: "San Francisco, CA",
      mutualConnections: 12,
      lastInteraction: "2 days ago",
      connectionStrength: "strong",
      skills: ["React", "Leadership", "System Design"],
      profileImage: "/api/placeholder/100/100",
      canRefer: true,
      relationship: "Former colleague"
    },
    {
      id: "2",
      name: "Mike Chen",
      title: "CTO",
      company: "StartupXYZ",
      location: "Remote",
      mutualConnections: 8,
      lastInteraction: "1 week ago",
      connectionStrength: "medium",
      skills: ["Full Stack", "Product Strategy", "Team Building"],
      profileImage: "/api/placeholder/100/100",
      canRefer: true,
      relationship: "Interview contact"
    },
    {
      id: "3",
      name: "Emma Davis",
      title: "Design Director",
      company: "Design Studio",
      location: "New York, NY",
      mutualConnections: 15,
      lastInteraction: "3 days ago",
      connectionStrength: "strong",
      skills: ["UI/UX", "Design Systems", "Mentoring"],
      profileImage: "/api/placeholder/100/100",
      canRefer: false,
      relationship: "Industry mentor"
    },
    {
      id: "4",
      name: "Alex Rodriguez",
      title: "Frontend Developer",
      company: "WebDev Co.",
      location: "Austin, TX",
      mutualConnections: 5,
      lastInteraction: "2 weeks ago",
      connectionStrength: "weak",
      skills: ["JavaScript", "Vue.js", "CSS"],
      profileImage: "/api/placeholder/100/100",
      canRefer: false,
      relationship: "Conference connection"
    }
  ];

  const recommendedConnections = [
    {
      id: "r1",
      name: "Jennifer Liu",
      title: "Senior React Developer",
      company: "Meta",
      mutualConnections: 23,
      reason: "Similar skills and 23 mutual connections",
      skills: ["React", "TypeScript", "GraphQL"],
      profileImage: "/api/placeholder/100/100"
    },
    {
      id: "r2",
      name: "David Park",
      title: "Engineering Lead",
      company: "Google",
      mutualConnections: 18,
      reason: "Works at companies you're interested in",
      skills: ["JavaScript", "Node.js", "Cloud Architecture"],
      profileImage: "/api/placeholder/100/100"
    },
    {
      id: "r3",
      name: "Lisa Wang",
      title: "Product Manager",
      company: "Apple",
      mutualConnections: 14,
      reason: "Similar career interests and location",
      skills: ["Product Strategy", "User Research", "Analytics"],
      profileImage: "/api/placeholder/100/100"
    }
  ];

  const networkingEvents = [
    {
      id: "e1",
      name: "Frontend Developers Meetup",
      date: "2024-01-30",
      time: "6:00 PM",
      location: "San Francisco, CA",
      type: "In-person",
      attendees: 85,
      organizer: "SF Tech Community",
      description: "Monthly meetup for frontend developers to share knowledge and network",
      isRegistered: true,
      tags: ["React", "JavaScript", "Networking"]
    },
    {
      id: "e2",
      name: "Women in Tech Conference",
      date: "2024-02-15",
      time: "9:00 AM",
      location: "Virtual",
      type: "Online",
      attendees: 500,
      organizer: "WIT Organization",
      description: "Annual conference focusing on diversity and inclusion in technology",
      isRegistered: false,
      tags: ["Diversity", "Career Growth", "Leadership"]
    },
    {
      id: "e3",
      name: "Startup Networking Happy Hour",
      date: "2024-02-05",
      time: "5:30 PM",
      location: "SOMA, San Francisco",
      type: "In-person",
      attendees: 120,
      organizer: "Startup Grind",
      description: "Casual networking event for startup professionals and entrepreneurs",
      isRegistered: false,
      tags: ["Startups", "Entrepreneurship", "Casual"]
    }
  ];

  const recentMessages = [
    {
      id: "m1",
      sender: "Sarah Johnson",
      message: "Thanks for the introduction! The coffee chat was very insightful.",
      timestamp: "2 hours ago",
      type: "received"
    },
    {
      id: "m2",
      sender: "Mike Chen",
      message: "I'd be happy to refer you for the open position. Let's schedule a call to discuss.",
      timestamp: "1 day ago",
      type: "received"
    },
    {
      id: "m3",
      sender: "Emma Davis",
      message: "Great meeting you at the design conference! Looking forward to collaborating.",
      timestamp: "3 days ago",
      type: "sent"
    }
  ];

  const getConnectionStrengthColor = (strength: string) => {
    switch (strength) {
      case "strong": return "bg-green-100 text-green-700";
      case "medium": return "bg-yellow-100 text-yellow-700";
      case "weak": return "bg-gray-100 text-gray-700";
      default: return "bg-gray-100 text-gray-700";
    }
  };

  const getEventTypeIcon = (type: string) => {
    return type === "Online" ? <Video className="h-4 w-4" /> : <MapPin className="h-4 w-4" />;
  };

  const filteredConnections = connections.filter(connection =>
    connection.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    connection.company.toLowerCase().includes(searchTerm.toLowerCase()) ||
    connection.title.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-sky-50 to-white p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Professional Network</h1>
          <p className="text-gray-600">Build meaningful connections and advance your career through networking</p>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-5 gap-6 mb-8">
          <Card className="border-blue-200">
            <CardContent className="p-6 text-center">
              <Users className="h-8 w-8 text-blue-600 mx-auto mb-2" />
              <div className="text-2xl font-bold text-blue-700">{networkingStats.totalConnections}</div>
              <div className="text-sm text-gray-600">Total Connections</div>
            </CardContent>
          </Card>
          <Card className="border-green-200">
            <CardContent className="p-6 text-center">
              <UserPlus className="h-8 w-8 text-green-600 mx-auto mb-2" />
              <div className="text-2xl font-bold text-green-700">{networkingStats.newThisMonth}</div>
              <div className="text-sm text-gray-600">New This Month</div>
            </CardContent>
          </Card>
          <Card className="border-purple-200">
            <CardContent className="p-6 text-center">
              <MessageSquare className="h-8 w-8 text-purple-600 mx-auto mb-2" />
              <div className="text-2xl font-bold text-purple-700">{networkingStats.messagesSent}</div>
              <div className="text-sm text-gray-600">Messages Sent</div>
            </CardContent>
          </Card>
          <Card className="border-orange-200">
            <CardContent className="p-6 text-center">
              <Calendar className="h-8 w-8 text-orange-600 mx-auto mb-2" />
              <div className="text-2xl font-bold text-orange-700">{networkingStats.eventsAttended}</div>
              <div className="text-sm text-gray-600">Events Attended</div>
            </CardContent>
          </Card>
          <Card className="border-teal-200">
            <CardContent className="p-6 text-center">
              <Award className="h-8 w-8 text-teal-600 mx-auto mb-2" />
              <div className="text-2xl font-bold text-teal-700">{networkingStats.referralsReceived}</div>
              <div className="text-sm text-gray-600">Referrals Received</div>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="my-network" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="my-network">My Network</TabsTrigger>
            <TabsTrigger value="discover">Discover People</TabsTrigger>
            <TabsTrigger value="events">Networking Events</TabsTrigger>
            <TabsTrigger value="messages">Messages</TabsTrigger>
          </TabsList>

          {/* My Network Tab */}
          <TabsContent value="my-network">
            <div className="space-y-6">
              {/* Search and Filter */}
              <Card>
                <CardContent className="p-6">
                  <div className="flex gap-4">
                    <div className="flex-1 relative">
                      <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                      <Input
                        placeholder="Search your network..."
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        className="pl-10"
                      />
                    </div>
                    <Button variant="outline">
                      <Filter className="h-4 w-4 mr-2" />
                      Filter
                    </Button>
                  </div>
                </CardContent>
              </Card>

              {/* Connections List */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {filteredConnections.map((connection) => (
                  <Card key={connection.id} className="hover:shadow-lg transition-shadow">
                    <CardContent className="p-6">
                      <div className="flex items-start gap-4">
                        <Avatar className="h-16 w-16">
                          <AvatarImage src={connection.profileImage} alt={connection.name} />
                          <AvatarFallback>{connection.name.split(' ').map(n => n[0]).join('')}</AvatarFallback>
                        </Avatar>
                        
                        <div className="flex-1 min-w-0">
                          <div className="flex items-start justify-between mb-2">
                            <div>
                              <h3 className="font-semibold text-gray-900 truncate">{connection.name}</h3>
                              <p className="text-sm text-gray-600 truncate">{connection.title}</p>
                              <p className="text-sm text-gray-500">{connection.company}</p>
                            </div>
                            <Badge className={getConnectionStrengthColor(connection.connectionStrength)}>
                              {connection.connectionStrength}
                            </Badge>
                          </div>

                          <div className="space-y-2 mb-4">
                            <div className="flex items-center gap-2 text-sm text-gray-600">
                              <MapPin className="h-3 w-3" />
                              {connection.location}
                            </div>
                            <div className="flex items-center gap-2 text-sm text-gray-600">
                              <Users className="h-3 w-3" />
                              {connection.mutualConnections} mutual connections
                            </div>
                            <div className="text-sm text-gray-500">
                              Last interaction: {connection.lastInteraction}
                            </div>
                          </div>

                          <div className="mb-4">
                            <div className="flex flex-wrap gap-1">
                              {connection.skills.slice(0, 3).map((skill) => (
                                <Badge key={skill} variant="outline" className="text-xs">
                                  {skill}
                                </Badge>
                              ))}
                            </div>
                          </div>

                          <div className="flex gap-2">
                            <Button size="sm" variant="outline" className="flex-1">
                              <MessageSquare className="h-4 w-4 mr-2" />
                              Message
                            </Button>
                            {connection.canRefer && (
                              <Button size="sm" className="flex-1 bg-sky-600 hover:bg-sky-700">
                                <Target className="h-4 w-4 mr-2" />
                                Request Referral
                              </Button>
                            )}
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          </TabsContent>

          {/* Discover People Tab */}
          <TabsContent value="discover">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <UserPlus className="h-5 w-5 text-sky-600" />
                  Recommended Connections
                </CardTitle>
                <CardDescription>People you should know based on your profile and interests</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  {recommendedConnections.map((person) => (
                    <Card key={person.id} className="border-2">
                      <CardContent className="p-6">
                        <div className="flex items-start gap-4">
                          <Avatar className="h-14 w-14">
                            <AvatarImage src={person.profileImage} alt={person.name} />
                            <AvatarFallback>{person.name.split(' ').map(n => n[0]).join('')}</AvatarFallback>
                          </Avatar>
                          
                          <div className="flex-1">
                            <h3 className="font-semibold text-gray-900 mb-1">{person.name}</h3>
                            <p className="text-sm text-gray-600 mb-1">{person.title}</p>
                            <p className="text-sm text-gray-500 mb-3">{person.company}</p>
                            
                            <div className="mb-3">
                              <div className="flex items-center gap-2 text-sm text-gray-600 mb-2">
                                <Users className="h-3 w-3" />
                                {person.mutualConnections} mutual connections
                              </div>
                              <p className="text-xs text-blue-600">{person.reason}</p>
                            </div>

                            <div className="mb-4">
                              <div className="flex flex-wrap gap-1">
                                {person.skills.map((skill) => (
                                  <Badge key={skill} variant="outline" className="text-xs">
                                    {skill}
                                  </Badge>
                                ))}
                              </div>
                            </div>

                            <div className="flex gap-2">
                              <Button size="sm" className="flex-1 bg-sky-600 hover:bg-sky-700">
                                <UserPlus className="h-4 w-4 mr-2" />
                                Connect
                              </Button>
                              <Button size="sm" variant="outline" className="flex-1">
                                <Eye className="h-4 w-4 mr-2" />
                                View Profile
                              </Button>
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Events Tab */}
          <TabsContent value="events">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Calendar className="h-5 w-5 text-sky-600" />
                  Networking Events
                </CardTitle>
                <CardDescription>Discover and attend professional networking events</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  {networkingEvents.map((event) => (
                    <Card key={event.id} className="border-2">
                      <CardContent className="p-6">
                        <div className="flex justify-between items-start mb-4">
                          <div>
                            <h3 className="font-semibold text-gray-900 mb-2">{event.name}</h3>
                            <div className="flex items-center gap-4 text-sm text-gray-600 mb-2">
                              <div className="flex items-center gap-1">
                                <Calendar className="h-4 w-4" />
                                {event.date} at {event.time}
                              </div>
                              <div className="flex items-center gap-1">
                                {getEventTypeIcon(event.type)}
                                {event.location}
                              </div>
                            </div>
                            <div className="flex items-center gap-4 text-sm text-gray-600">
                              <span>{event.attendees} attendees</span>
                              <span>•</span>
                              <span>by {event.organizer}</span>
                            </div>
                          </div>
                          <div className="text-right">
                            {event.isRegistered ? (
                              <Badge className="bg-green-100 text-green-700">Registered</Badge>
                            ) : (
                              <Badge variant="outline">Available</Badge>
                            )}
                          </div>
                        </div>

                        <p className="text-gray-700 mb-4">{event.description}</p>

                        <div className="flex items-center justify-between">
                          <div className="flex flex-wrap gap-2">
                            {event.tags.map((tag) => (
                              <Badge key={tag} variant="outline" className="text-xs">
                                {tag}
                              </Badge>
                            ))}
                          </div>
                          
                          <div className="flex gap-2">
                            {!event.isRegistered ? (
                              <Button size="sm" className="bg-sky-600 hover:bg-sky-700">
                                <Plus className="h-4 w-4 mr-2" />
                                Register
                              </Button>
                            ) : (
                              <Button size="sm" variant="outline">
                                <Calendar className="h-4 w-4 mr-2" />
                                View Details
                              </Button>
                            )}
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Messages Tab */}
          <TabsContent value="messages">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <Card className="lg:col-span-2">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <MessageSquare className="h-5 w-5 text-sky-600" />
                    Recent Messages
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {recentMessages.map((message) => (
                      <div key={message.id} className={`p-4 rounded-lg ${
                        message.type === "received" ? "bg-gray-50" : "bg-sky-50"
                      }`}>
                        <div className="flex items-start gap-3">
                          <Avatar className="h-10 w-10">
                            <AvatarFallback>{message.sender.split(' ').map(n => n[0]).join('')}</AvatarFallback>
                          </Avatar>
                          <div className="flex-1">
                            <div className="flex justify-between items-start mb-2">
                              <h4 className="font-medium text-gray-900">{message.sender}</h4>
                              <span className="text-xs text-gray-500">{message.timestamp}</span>
                            </div>
                            <p className="text-gray-700">{message.message}</p>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Quick Actions</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <Button variant="outline" className="w-full justify-start">
                    <Coffee className="h-4 w-4 mr-2" />
                    Schedule Coffee Chat
                  </Button>
                  <Button variant="outline" className="w-full justify-start">
                    <Phone className="h-4 w-4 mr-2" />
                    Request Phone Call
                  </Button>
                  <Button variant="outline" className="w-full justify-start">
                    <Linkedin className="h-4 w-4 mr-2" />
                    Connect on LinkedIn
                  </Button>
                  <Button variant="outline" className="w-full justify-start">
                    <Send className="h-4 w-4 mr-2" />
                    Send Introduction
                  </Button>
                  <Button className="w-full bg-sky-600 hover:bg-sky-700">
                    <Plus className="h-4 w-4 mr-2" />
                    Compose Message
                  </Button>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}

export default function Networking() {
  const config = platformConfigs.candidate;
  const theme = useThemeClasses('candidate');
  
  const usageData = [
    { label: "Professional Connections", current: 45, max: 100 },
    { label: "Network Growth", current: 78, max: 100 },
    { label: "Event Participation", current: 5, max: 12 },
  ];

  return (
    <PlatformLayout
      sidebarTitle={config.sidebarTitle}
      sidebarSubtitle={config.sidebarSubtitle}
      sidebarSections={config.sidebarSections}
      usageData={usageData}
    >
      <NetworkingContent />
    </PlatformLayout>
  );
}