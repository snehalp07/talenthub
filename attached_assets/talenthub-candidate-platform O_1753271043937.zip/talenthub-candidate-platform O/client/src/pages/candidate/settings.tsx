import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import PlatformLayout from "@/components/layout/platform-layout";
import { platformConfigs } from "@/config/complete-navigation";
import { useThemeClasses } from "@/lib/theme-config";
import { 
  User, 
  Bell, 
  Shield, 
  Globe, 
  Eye, 
  Key,
  Mail,
  Phone,
  MapPin,
  Calendar,
  Briefcase,
  GraduationCap,
  Save,
  Trash2
} from "lucide-react";

interface UserSettings {
  profile: {
    firstName: string;
    lastName: string;
    email: string;
    phone: string;
    location: string;
    bio: string;
    website: string;
    linkedin: string;
    github: string;
  };
  preferences: {
    emailNotifications: boolean;
    smsNotifications: boolean;
    profilePublic: boolean;
    showSalaryExpectations: boolean;
    allowRecruiterContact: boolean;
    theme: string;
    language: string;
    timezone: string;
  };
  privacy: {
    profileVisibility: string;
    contactPreference: string;
    dataSharing: boolean;
    activityTracking: boolean;
  };
  jobPreferences: {
    jobTypes: string[];
    preferredLocations: string[];
    salaryRange: { min: number; max: number };
    experienceLevel: string;
    remoteWork: string;
    availability: string;
  };
}

function SettingsContent() {
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("profile");

  const { data: settings, isLoading } = useQuery<UserSettings>({
    queryKey: ["/api/candidate/settings"]
  });

  const updateSettingsMutation = useMutation({
    mutationFn: async (updates: Partial<UserSettings>) => {
      const res = await apiRequest("PUT", "/api/candidate/settings", updates);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/candidate/settings"] });
      toast({
        title: "Settings updated",
        description: "Your preferences have been saved successfully.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Update failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Mock data for development
  const mockSettings: UserSettings = {
    profile: {
      firstName: "Alex",
      lastName: "Johnson",
      email: "alex.johnson@email.com",
      phone: "+1 (555) 123-4567",
      location: "San Francisco, CA",
      bio: "Full-stack developer with 5+ years experience in React and Node.js",
      website: "https://alexjohnson.dev",
      linkedin: "https://linkedin.com/in/alexjohnson",
      github: "https://github.com/alexjohnson"
    },
    preferences: {
      emailNotifications: true,
      smsNotifications: false,
      profilePublic: true,
      showSalaryExpectations: true,
      allowRecruiterContact: true,
      theme: "light",
      language: "en",
      timezone: "America/Los_Angeles"
    },
    privacy: {
      profileVisibility: "public",
      contactPreference: "email",
      dataSharing: true,
      activityTracking: true
    },
    jobPreferences: {
      jobTypes: ["full-time", "contract"],
      preferredLocations: ["San Francisco", "Remote"],
      salaryRange: { min: 100000, max: 150000 },
      experienceLevel: "senior",
      remoteWork: "hybrid",
      availability: "immediately"
    }
  };

  const currentSettings = settings || mockSettings;

  const handleSave = (section: keyof UserSettings, data: any) => {
    updateSettingsMutation.mutate({ [section]: data });
  };

  if (isLoading) {
    return <div className="flex items-center justify-center h-64">Loading settings...</div>;
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Settings</h1>
          <p className="text-gray-600">Manage your account preferences and privacy</p>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="profile">Profile</TabsTrigger>
          <TabsTrigger value="preferences">Preferences</TabsTrigger>
          <TabsTrigger value="privacy">Privacy</TabsTrigger>
          <TabsTrigger value="job-preferences">Job Preferences</TabsTrigger>
        </TabsList>

        <TabsContent value="profile" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <User className="w-5 h-5 mr-2" />
                Profile Information
              </CardTitle>
              <CardDescription>Update your personal information and professional details</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="firstName">First Name</Label>
                  <Input id="firstName" defaultValue={currentSettings.profile.firstName} />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="lastName">Last Name</Label>
                  <Input id="lastName" defaultValue={currentSettings.profile.lastName} />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="email">Email</Label>
                  <Input id="email" type="email" defaultValue={currentSettings.profile.email} />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="phone">Phone</Label>
                  <Input id="phone" defaultValue={currentSettings.profile.phone} />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="location">Location</Label>
                <Input id="location" defaultValue={currentSettings.profile.location} />
              </div>

              <div className="space-y-2">
                <Label htmlFor="bio">Bio</Label>
                <Textarea id="bio" defaultValue={currentSettings.profile.bio} rows={3} />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="website">Website</Label>
                  <Input id="website" defaultValue={currentSettings.profile.website} />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="linkedin">LinkedIn</Label>
                  <Input id="linkedin" defaultValue={currentSettings.profile.linkedin} />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="github">GitHub</Label>
                  <Input id="github" defaultValue={currentSettings.profile.github} />
                </div>
              </div>

              <Button onClick={() => handleSave('profile', currentSettings.profile)}>
                <Save className="w-4 h-4 mr-2" />
                Save Profile
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="preferences" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Bell className="w-5 h-5 mr-2" />
                Notification Preferences
              </CardTitle>
              <CardDescription>Choose how you want to be notified</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label>Email Notifications</Label>
                  <p className="text-sm text-gray-600">Receive updates via email</p>
                </div>
                <Switch defaultChecked={currentSettings.preferences.emailNotifications} />
              </div>

              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label>SMS Notifications</Label>
                  <p className="text-sm text-gray-600">Receive urgent updates via SMS</p>
                </div>
                <Switch defaultChecked={currentSettings.preferences.smsNotifications} />
              </div>

              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label>Public Profile</Label>
                  <p className="text-sm text-gray-600">Make your profile visible to recruiters</p>
                </div>
                <Switch defaultChecked={currentSettings.preferences.profilePublic} />
              </div>

              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label>Show Salary Expectations</Label>
                  <p className="text-sm text-gray-600">Display your salary range on profile</p>
                </div>
                <Switch defaultChecked={currentSettings.preferences.showSalaryExpectations} />
              </div>

              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label>Allow Recruiter Contact</Label>
                  <p className="text-sm text-gray-600">Let recruiters contact you directly</p>
                </div>
                <Switch defaultChecked={currentSettings.preferences.allowRecruiterContact} />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Globe className="w-5 h-5 mr-2" />
                Display Preferences
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label>Theme</Label>
                  <Select defaultValue={currentSettings.preferences.theme}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="light">Light</SelectItem>
                      <SelectItem value="dark">Dark</SelectItem>
                      <SelectItem value="system">System</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>Language</Label>
                  <Select defaultValue={currentSettings.preferences.language}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="en">English</SelectItem>
                      <SelectItem value="es">Spanish</SelectItem>
                      <SelectItem value="fr">French</SelectItem>
                      <SelectItem value="de">German</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label>Timezone</Label>
                  <Select defaultValue={currentSettings.preferences.timezone}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="America/Los_Angeles">Pacific Time</SelectItem>
                      <SelectItem value="America/New_York">Eastern Time</SelectItem>
                      <SelectItem value="Europe/London">London Time</SelectItem>
                      <SelectItem value="Asia/Tokyo">Tokyo Time</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <Button onClick={() => handleSave('preferences', currentSettings.preferences)}>
                <Save className="w-4 h-4 mr-2" />
                Save Preferences
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="privacy" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Shield className="w-5 h-5 mr-2" />
                Privacy & Security
              </CardTitle>
              <CardDescription>Control your privacy and data sharing settings</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Profile Visibility</Label>
                <Select defaultValue={currentSettings.privacy.profileVisibility}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="public">Public - Visible to all</SelectItem>
                    <SelectItem value="recruiters">Recruiters Only</SelectItem>
                    <SelectItem value="private">Private - Hidden</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>Contact Preference</Label>
                <Select defaultValue={currentSettings.privacy.contactPreference}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="email">Email Only</SelectItem>
                    <SelectItem value="phone">Phone Only</SelectItem>
                    <SelectItem value="both">Both Email & Phone</SelectItem>
                    <SelectItem value="platform">Platform Messages Only</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label>Data Sharing</Label>
                  <p className="text-sm text-gray-600">Share anonymized data for platform improvement</p>
                </div>
                <Switch defaultChecked={currentSettings.privacy.dataSharing} />
              </div>

              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label>Activity Tracking</Label>
                  <p className="text-sm text-gray-600">Track your activity for personalized recommendations</p>
                </div>
                <Switch defaultChecked={currentSettings.privacy.activityTracking} />
              </div>

              <Button onClick={() => handleSave('privacy', currentSettings.privacy)}>
                <Save className="w-4 h-4 mr-2" />
                Save Privacy Settings
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="job-preferences" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Briefcase className="w-5 h-5 mr-2" />
                Job Preferences
              </CardTitle>
              <CardDescription>Set your job search preferences and requirements</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Job Types</Label>
                <div className="flex flex-wrap gap-2">
                  {['full-time', 'part-time', 'contract', 'freelance', 'internship'].map((type) => (
                    <Badge 
                      key={type} 
                      variant={currentSettings.jobPreferences.jobTypes.includes(type) ? "default" : "outline"}
                      className="cursor-pointer"
                    >
                      {type.replace('-', ' ')}
                    </Badge>
                  ))}
                </div>
              </div>

              <div className="space-y-2">
                <Label>Experience Level</Label>
                <Select defaultValue={currentSettings.jobPreferences.experienceLevel}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="entry">Entry Level</SelectItem>
                    <SelectItem value="mid">Mid Level</SelectItem>
                    <SelectItem value="senior">Senior Level</SelectItem>
                    <SelectItem value="lead">Lead/Principal</SelectItem>
                    <SelectItem value="executive">Executive</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>Remote Work Preference</Label>
                <Select defaultValue={currentSettings.jobPreferences.remoteWork}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="on-site">On-site Only</SelectItem>
                    <SelectItem value="remote">Remote Only</SelectItem>
                    <SelectItem value="hybrid">Hybrid</SelectItem>
                    <SelectItem value="flexible">Flexible</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Minimum Salary ($)</Label>
                  <Input 
                    type="number" 
                    defaultValue={currentSettings.jobPreferences.salaryRange.min}
                    placeholder="100,000"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Maximum Salary ($)</Label>
                  <Input 
                    type="number" 
                    defaultValue={currentSettings.jobPreferences.salaryRange.max}
                    placeholder="150,000"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label>Availability</Label>
                <Select defaultValue={currentSettings.jobPreferences.availability}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="immediately">Immediately</SelectItem>
                    <SelectItem value="2-weeks">2 Weeks Notice</SelectItem>
                    <SelectItem value="1-month">1 Month</SelectItem>
                    <SelectItem value="3-months">3 Months</SelectItem>
                    <SelectItem value="not-looking">Not Currently Looking</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <Button onClick={() => handleSave('jobPreferences', currentSettings.jobPreferences)}>
                <Save className="w-4 h-4 mr-2" />
                Save Job Preferences
              </Button>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Danger Zone */}
      <Card className="border-red-200">
        <CardHeader>
          <CardTitle className="flex items-center text-red-600">
            <Trash2 className="w-5 h-5 mr-2" />
            Danger Zone
          </CardTitle>
          <CardDescription>Irreversible account actions</CardDescription>
        </CardHeader>
        <CardContent>
          <Button variant="destructive">
            Delete Account
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}

export default function Settings() {
  const config = platformConfigs.candidate;
  const theme = useThemeClasses('candidate');
  
  const usageData = [
    { label: "Profile Completion", current: 85, max: 100 },
    { label: "Privacy Settings", current: 90, max: 100 },
    { label: "Notifications", current: 70, max: 100 },
  ];

  return (
    <PlatformLayout
      sidebarTitle={config.sidebarTitle}
      sidebarSubtitle={config.sidebarSubtitle}
      sidebarSections={config.sidebarSections}
      usageData={usageData}
    >
      <SettingsContent />
    </PlatformLayout>
  );
}