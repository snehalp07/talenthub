import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import PlatformLayout from "@/components/layout/platform-layout";
import { platformConfigs } from "@/config/complete-navigation";
import { useThemeClasses } from "@/lib/theme-config";
import { 
  CheckCircle, 
  Clock, 
  Calendar, 
  Award, 
  Target, 
  TrendingUp,
  BookOpen,
  AlertCircle,
  Download,
  Eye,
  BarChart3
} from "lucide-react";

function CertificationTrackerContent() {
  const [activeTab, setActiveTab] = useState("progress");

  const certifications = [
    {
      id: 1,
      title: "AWS Certified Developer Associate",
      provider: "Amazon Web Services",
      status: "completed",
      progress: 100,
      startDate: "2025-01-15",
      completionDate: "2025-03-10",
      expiryDate: "2028-03-10",
      certificateId: "AWS-DEV-2025-001",
      skills: ["AWS Lambda", "DynamoDB", "S3", "API Gateway"],
      timeSpent: "42 hours",
      score: 87,
      validity: "3 years"
    },
    {
      id: 2,
      title: "Google Cloud Professional Developer",
      provider: "Google Cloud",
      status: "in-progress",
      progress: 75,
      startDate: "2025-02-01",
      completionDate: null,
      estimatedCompletion: "2025-06-15",
      skills: ["GCP", "Kubernetes", "Cloud Functions", "BigQuery"],
      timeSpent: "38 hours",
      totalHours: "60 hours",
      nextMilestone: "Complete Practice Tests"
    },
    {
      id: 3,
      title: "Microsoft Azure Fundamentals",
      provider: "Microsoft",
      status: "completed",
      progress: 100,
      startDate: "2024-11-01",
      completionDate: "2024-12-15",
      expiryDate: "2027-12-15",
      certificateId: "AZ-900-2024-456",
      skills: ["Azure", "VM", "Storage", "Networking"],
      timeSpent: "18 hours",
      score: 92,
      validity: "3 years"
    },
    {
      id: 4,
      title: "React Advanced Patterns",
      provider: "Meta",
      status: "in-progress",
      progress: 45,
      startDate: "2025-03-01",
      completionDate: null,
      estimatedCompletion: "2025-07-01",
      skills: ["React", "Hooks", "Context", "Performance"],
      timeSpent: "16 hours",
      totalHours: "35 hours",
      nextMilestone: "Advanced Hooks Module"
    },
    {
      id: 5,
      title: "Certified Kubernetes Administrator",
      provider: "CNCF",
      status: "planned",
      progress: 0,
      plannedStart: "2025-07-01",
      estimatedCompletion: "2025-10-01",
      skills: ["Kubernetes", "Docker", "Container Orchestration"],
      estimatedHours: "80 hours"
    }
  ];

  const stats = {
    completed: certifications.filter(c => c.status === "completed").length,
    inProgress: certifications.filter(c => c.status === "in-progress").length,
    planned: certifications.filter(c => c.status === "planned").length,
    totalHours: certifications.reduce((acc, cert) => {
      if (cert.timeSpent) {
        return acc + parseInt(cert.timeSpent.split(' ')[0]);
      }
      return acc;
    }, 0),
    avgScore: Math.round(
      certifications
        .filter(c => c.score)
        .reduce((acc, cert) => acc + cert.score, 0) / 
      certifications.filter(c => c.score).length
    )
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "completed": return "bg-green-100 text-green-800";
      case "in-progress": return "bg-blue-100 text-blue-800";
      case "planned": return "bg-gray-100 text-gray-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "completed": return <CheckCircle className="w-4 h-4" />;
      case "in-progress": return <Clock className="w-4 h-4" />;
      case "planned": return <Calendar className="w-4 h-4" />;
      default: return <AlertCircle className="w-4 h-4" />;
    }
  };

  const isExpiringSoon = (expiryDate: string) => {
    if (!expiryDate) return false;
    const expiry = new Date(expiryDate);
    const sixMonthsFromNow = new Date();
    sixMonthsFromNow.setMonth(sixMonthsFromNow.getMonth() + 6);
    return expiry < sixMonthsFromNow;
  };

  return (
    <div className="max-w-7xl mx-auto px-6 py-8">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-sky-800 mb-2">Certification Tracker</h1>
        <p className="text-sky-600">Track your certification progress and manage your professional development</p>
      </div>

      {/* Statistics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-5 gap-6 mb-8">
        <Card className="border-sky-200">
          <CardContent className="p-6 text-center">
            <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mx-auto mb-3">
              <Award className="w-6 h-6 text-green-600" />
            </div>
            <h3 className="text-2xl font-bold text-sky-800">{stats.completed}</h3>
            <p className="text-sm text-sky-600">Completed</p>
          </CardContent>
        </Card>

        <Card className="border-sky-200">
          <CardContent className="p-6 text-center">
            <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mx-auto mb-3">
              <BookOpen className="w-6 h-6 text-blue-600" />
            </div>
            <h3 className="text-2xl font-bold text-sky-800">{stats.inProgress}</h3>
            <p className="text-sm text-sky-600">In Progress</p>
          </CardContent>
        </Card>

        <Card className="border-sky-200">
          <CardContent className="p-6 text-center">
            <div className="w-12 h-12 bg-gray-100 rounded-lg flex items-center justify-center mx-auto mb-3">
              <Target className="w-6 h-6 text-gray-600" />
            </div>
            <h3 className="text-2xl font-bold text-sky-800">{stats.planned}</h3>
            <p className="text-sm text-sky-600">Planned</p>
          </CardContent>
        </Card>

        <Card className="border-sky-200">
          <CardContent className="p-6 text-center">
            <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center mx-auto mb-3">
              <Clock className="w-6 h-6 text-purple-600" />
            </div>
            <h3 className="text-2xl font-bold text-sky-800">{stats.totalHours}</h3>
            <p className="text-sm text-sky-600">Hours Studied</p>
          </CardContent>
        </Card>

        <Card className="border-sky-200">
          <CardContent className="p-6 text-center">
            <div className="w-12 h-12 bg-yellow-100 rounded-lg flex items-center justify-center mx-auto mb-3">
              <TrendingUp className="w-6 h-6 text-yellow-600" />
            </div>
            <h3 className="text-2xl font-bold text-sky-800">{stats.avgScore}%</h3>
            <p className="text-sm text-sky-600">Avg Score</p>
          </CardContent>
        </Card>
      </div>

      {/* Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="progress">Progress Tracking</TabsTrigger>
          <TabsTrigger value="certificates">Certificates</TabsTrigger>
          <TabsTrigger value="analytics">Analytics</TabsTrigger>
        </TabsList>

        {/* Progress Tracking Tab */}
        <TabsContent value="progress" className="space-y-6">
          <div className="grid gap-6">
            {certifications.map((cert) => (
              <Card key={cert.id} className="shadow-sm border-sky-200">
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <CardTitle className="text-xl text-sky-800 mb-2">{cert.title}</CardTitle>
                      <CardDescription className="text-sky-600 mb-3">
                        {cert.provider}
                      </CardDescription>
                      <div className="flex items-center gap-2">
                        <Badge className={getStatusColor(cert.status)}>
                          {getStatusIcon(cert.status)}
                          <span className="ml-1 capitalize">{cert.status.replace('-', ' ')}</span>
                        </Badge>
                        {cert.status === "completed" && isExpiringSoon(cert.expiryDate) && (
                          <Badge variant="destructive">
                            <AlertCircle className="w-3 h-3 mr-1" />
                            Expires Soon
                          </Badge>
                        )}
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-2xl font-bold text-sky-800">{cert.progress}%</div>
                      {cert.score && (
                        <div className="text-sm text-gray-600">Score: {cert.score}%</div>
                      )}
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  {/* Progress Bar */}
                  <div className="mb-4">
                    <Progress value={cert.progress} className="h-3" />
                  </div>

                  {/* Details Grid */}
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                    <div>
                      <p className="text-sm font-medium text-gray-700">Start Date</p>
                      <p className="text-sm text-gray-600">
                        {cert.startDate ? new Date(cert.startDate).toLocaleDateString() : 
                         cert.plannedStart ? `Planned: ${new Date(cert.plannedStart).toLocaleDateString()}` : 'TBD'}
                      </p>
                    </div>
                    <div>
                      <p className="text-sm font-medium text-gray-700">
                        {cert.status === "completed" ? "Completed" : "Est. Completion"}
                      </p>
                      <p className="text-sm text-gray-600">
                        {cert.completionDate ? new Date(cert.completionDate).toLocaleDateString() :
                         cert.estimatedCompletion ? new Date(cert.estimatedCompletion).toLocaleDateString() : 'TBD'}
                      </p>
                    </div>
                    <div>
                      <p className="text-sm font-medium text-gray-700">Time Investment</p>
                      <p className="text-sm text-gray-600">
                        {cert.timeSpent || cert.estimatedHours || 'TBD'}
                        {cert.totalHours && ` / ${cert.totalHours}`}
                      </p>
                    </div>
                  </div>

                  {/* Skills */}
                  <div className="mb-4">
                    <p className="text-sm font-medium text-gray-700 mb-2">Skills Covered:</p>
                    <div className="flex flex-wrap gap-1">
                      {cert.skills.map((skill, index) => (
                        <Badge key={index} variant="secondary" className="text-xs">
                          {skill}
                        </Badge>
                      ))}
                    </div>
                  </div>

                  {/* Next Milestone */}
                  {cert.nextMilestone && (
                    <div className="mb-4">
                      <p className="text-sm font-medium text-gray-700">Next Milestone:</p>
                      <p className="text-sm text-sky-600">{cert.nextMilestone}</p>
                    </div>
                  )}

                  {/* Action Buttons */}
                  <div className="flex gap-2">
                    {cert.status === "completed" ? (
                      <>
                        <Button size="sm" className="bg-sky-600 hover:bg-sky-700">
                          <Eye className="w-4 h-4 mr-2" />
                          View Certificate
                        </Button>
                        <Button variant="outline" size="sm">
                          <Download className="w-4 h-4 mr-2" />
                          Download
                        </Button>
                      </>
                    ) : cert.status === "in-progress" ? (
                      <Button size="sm" className="bg-sky-600 hover:bg-sky-700">
                        Continue Learning
                      </Button>
                    ) : (
                      <Button size="sm" className="bg-sky-600 hover:bg-sky-700">
                        Start Certification
                      </Button>
                    )}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* Certificates Tab */}
        <TabsContent value="certificates" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {certifications
              .filter(cert => cert.status === "completed")
              .map((cert) => (
                <Card key={cert.id} className="shadow-sm border-sky-200">
                  <CardHeader>
                    <div className="w-16 h-16 bg-sky-100 rounded-lg flex items-center justify-center mx-auto mb-4">
                      <Award className="w-8 h-8 text-sky-600" />
                    </div>
                    <CardTitle className="text-lg text-center text-sky-800">{cert.title}</CardTitle>
                    <CardDescription className="text-center">{cert.provider}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3 text-sm">
                      <div className="flex justify-between">
                        <span className="text-gray-600">Certificate ID:</span>
                        <span className="font-mono text-sky-800">{cert.certificateId}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">Completed:</span>
                        <span className="text-sky-800">{new Date(cert.completionDate).toLocaleDateString()}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">Score:</span>
                        <span className="text-sky-800 font-semibold">{cert.score}%</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">Valid Until:</span>
                        <span className={`${isExpiringSoon(cert.expiryDate) ? 'text-red-600 font-semibold' : 'text-sky-800'}`}>
                          {new Date(cert.expiryDate).toLocaleDateString()}
                        </span>
                      </div>
                    </div>
                    <div className="mt-4 space-y-2">
                      <Button className="w-full bg-sky-600 hover:bg-sky-700">
                        <Eye className="w-4 h-4 mr-2" />
                        View Certificate
                      </Button>
                      <Button variant="outline" className="w-full">
                        <Download className="w-4 h-4 mr-2" />
                        Download PDF
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
          </div>
        </TabsContent>

        {/* Analytics Tab */}
        <TabsContent value="analytics" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card className="shadow-sm border-sky-200">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <BarChart3 className="w-5 h-5" />
                  Learning Progress Over Time
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-64 flex items-center justify-center bg-gray-50 rounded-lg">
                  <p className="text-gray-500">Progress chart visualization would go here</p>
                </div>
              </CardContent>
            </Card>

            <Card className="shadow-sm border-sky-200">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <TrendingUp className="w-5 h-5" />
                  Skills Distribution
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-64 flex items-center justify-center bg-gray-50 rounded-lg">
                  <p className="text-gray-500">Skills distribution chart would go here</p>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}

export default function CertificationTracker() {
  const config = platformConfigs.candidate;
  const theme = useThemeClasses('candidate');
  
  const usageData = [
    { label: "Certifications Progress", current: 4, max: 10 },
    { label: "Study Hours", current: 75, max: 120 },
    { label: "Completion Rate", current: 67, max: 100 },
  ];

  return (
    <PlatformLayout
      sidebarTitle={config.sidebarTitle}
      sidebarSubtitle={config.sidebarSubtitle}
      sidebarSections={config.sidebarSections}
      usageData={usageData}
    >
      <CertificationTrackerContent />
    </PlatformLayout>
  );
}