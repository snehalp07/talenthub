import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import PlatformLayout from "@/components/layout/platform-layout";
import { candidateNavigation } from "@/config/complete-navigation";
import { 
  Monitor, Play, CheckCircle, Award, Target, TrendingUp, 
  Star, Clock, Code, Users, Zap, BookOpen, Trophy,
  ArrowRight, ChevronDown, Lock, Unlock
} from "lucide-react";

const FrontendCertification: React.FC = () => {
  const [selectedTrack, setSelectedTrack] = useState('react');

  const certificationTracks = [
    {
      id: 'react',
      name: 'React Developer',
      icon: Monitor,
      color: 'from-blue-500 to-cyan-500',
      level: 'Foundation → Expert',
      duration: '8-12 weeks',
      enrolled: 15420,
      completion: 68,
      rating: 4.8,
      modules: [
        { name: 'React Fundamentals', status: 'completed', progress: 100, duration: '2 weeks' },
        { name: 'Component Lifecycle', status: 'completed', progress: 100, duration: '1.5 weeks' },
        { name: 'State Management', status: 'current', progress: 75, duration: '2 weeks' },
        { name: 'React Hooks', status: 'locked', progress: 0, duration: '2 weeks' },
        { name: 'Performance Optimization', status: 'locked', progress: 0, duration: '1.5 weeks' },
        { name: 'Testing & Deployment', status: 'locked', progress: 0, duration: '2 weeks' }
      ]
    },
    {
      id: 'vue',
      name: 'Vue.js Developer',
      icon: Monitor,
      color: 'from-green-500 to-emerald-500',
      level: 'Foundation → Expert',
      duration: '6-10 weeks',
      enrolled: 8730,
      completion: 45,
      rating: 4.7,
      modules: [
        { name: 'Vue Basics', status: 'completed', progress: 100, duration: '1.5 weeks' },
        { name: 'Directives & Data Binding', status: 'current', progress: 60, duration: '1.5 weeks' },
        { name: 'Component System', status: 'locked', progress: 0, duration: '2 weeks' },
        { name: 'Vuex State Management', status: 'locked', progress: 0, duration: '2 weeks' },
        { name: 'Vue Router', status: 'locked', progress: 0, duration: '1.5 weeks' },
        { name: 'Vue 3 Composition API', status: 'locked', progress: 0, duration: '2 weeks' }
      ]
    },
    {
      id: 'angular',
      name: 'Angular Developer',
      icon: Monitor,
      color: 'from-red-500 to-pink-500',
      level: 'Foundation → Expert',
      duration: '10-14 weeks',
      enrolled: 12150,
      completion: 22,
      rating: 4.6,
      modules: [
        { name: 'TypeScript Fundamentals', status: 'not-started', progress: 0, duration: '2 weeks' },
        { name: 'Angular CLI & Project Setup', status: 'not-started', progress: 0, duration: '1 week' },
        { name: 'Components & Templates', status: 'not-started', progress: 0, duration: '2.5 weeks' },
        { name: 'Services & Dependency Injection', status: 'not-started', progress: 0, duration: '2 weeks' },
        { name: 'Routing & Navigation', status: 'not-started', progress: 0, duration: '1.5 weeks' },
        { name: 'RxJS & Observables', status: 'not-started', progress: 0, duration: '2 weeks' }
      ]
    }
  ];

  const achievements = [
    { name: 'First Component', icon: Trophy, earned: true, date: '2 weeks ago' },
    { name: 'State Master', icon: Award, earned: true, date: '1 week ago' },
    { name: 'Hook Specialist', icon: Star, earned: false, date: null },
    { name: 'Performance Guru', icon: Zap, earned: false, date: null },
    { name: 'Testing Champion', icon: CheckCircle, earned: false, date: null }
  ];

  const upcomingInterviews = [
    { company: 'TechCorp', role: 'Frontend Developer', date: '2 days', difficulty: 'Intermediate' },
    { company: 'StartupX', role: 'React Developer', date: '1 week', difficulty: 'Advanced' },
    { company: 'Enterprise Co', role: 'Senior Frontend Engineer', date: '2 weeks', difficulty: 'Expert' }
  ];

  const selectedTrackData = certificationTracks.find(track => track.id === selectedTrack);

  return (
    <PlatformLayout
      sidebarTitle="Candidate Platform"
      sidebarSubtitle="Interview Preparation"
      sidebarSections={candidateNavigation}
    >
      <div className="min-h-screen bg-gradient-to-br from-emerald-50 via-white to-green-50 p-6">
        <div className="max-w-7xl mx-auto space-y-8">
          {/* Header */}
          <div className="text-center space-y-4">
            <div className="inline-flex items-center space-x-2 bg-emerald-100 text-emerald-800 px-4 py-2 rounded-full text-sm font-medium">
              <Monitor className="h-4 w-4" />
              <span>Frontend Development Certification</span>
            </div>
            <h1 className="text-4xl font-bold text-gray-900">
              Master Frontend Technologies
            </h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Get certified in React, Vue.js, or Angular through structured learning paths with 
              hands-on projects and real interview preparation.
            </p>
          </div>

          <Tabs value={selectedTrack} onValueChange={setSelectedTrack} className="space-y-6">
            {/* Track Selection */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {certificationTracks.map((track) => {
                const IconComponent = track.icon;
                return (
                  <Card 
                    key={track.id} 
                    className={`cursor-pointer transition-all duration-300 hover:shadow-lg border-2 ${
                      selectedTrack === track.id 
                        ? 'border-emerald-500 shadow-lg' 
                        : 'border-gray-200 hover:border-emerald-300'
                    }`}
                    onClick={() => setSelectedTrack(track.id)}
                  >
                    <CardHeader className="pb-3">
                      <div className="flex items-center justify-between">
                        <div className={`p-3 rounded-lg bg-gradient-to-r ${track.color}`}>
                          <IconComponent className="h-6 w-6 text-white" />
                        </div>
                        <div className="flex items-center space-x-1">
                          <Star className="h-4 w-4 text-yellow-500 fill-current" />
                          <span className="text-sm font-medium">{track.rating}</span>
                        </div>
                      </div>
                      <CardTitle className="text-lg">{track.name}</CardTitle>
                      <CardDescription className="text-sm">{track.level}</CardDescription>
                    </CardHeader>
                    <CardContent className="pt-0">
                      <div className="space-y-3">
                        <div className="flex justify-between text-sm">
                          <span>Progress</span>
                          <span className="font-medium">{track.completion}%</span>
                        </div>
                        <Progress value={track.completion} className="h-2" />
                        <div className="grid grid-cols-2 gap-2 text-xs text-gray-600">
                          <div className="flex items-center space-x-1">
                            <Clock className="h-3 w-3" />
                            <span>{track.duration}</span>
                          </div>
                          <div className="flex items-center space-x-1">
                            <Users className="h-3 w-3" />
                            <span>{track.enrolled.toLocaleString()}</span>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>

            {/* Selected Track Details */}
            {selectedTrackData && (
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                {/* Learning Path */}
                <div className="lg:col-span-2">
                  <Card>
                    <CardHeader className={`bg-gradient-to-r ${selectedTrackData.color} text-white`}>
                      <CardTitle className="text-xl flex items-center space-x-3">
                        <selectedTrackData.icon className="h-6 w-6" />
                        <span>{selectedTrackData.name} Learning Path</span>
                      </CardTitle>
                      <CardDescription className="text-white/80">
                        Structured curriculum from fundamentals to advanced concepts
                      </CardDescription>
                    </CardHeader>
                    <CardContent className="p-6">
                      <div className="space-y-4">
                        {selectedTrackData.modules.map((module, index) => (
                          <div 
                            key={index} 
                            className={`p-4 rounded-lg border-2 transition-all ${
                              module.status === 'completed' 
                                ? 'bg-green-50 border-green-200' 
                                : module.status === 'current'
                                ? 'bg-blue-50 border-blue-200'
                                : 'bg-gray-50 border-gray-200'
                            }`}
                          >
                            <div className="flex items-center justify-between mb-2">
                              <div className="flex items-center space-x-3">
                                {module.status === 'completed' ? (
                                  <CheckCircle className="h-5 w-5 text-green-500" />
                                ) : module.status === 'current' ? (
                                  <Play className="h-5 w-5 text-blue-500" />
                                ) : (
                                  <Lock className="h-5 w-5 text-gray-400" />
                                )}
                                <span className="font-medium">{module.name}</span>
                              </div>
                              <div className="flex items-center space-x-2">
                                <Badge variant={
                                  module.status === 'completed' ? 'default' :
                                  module.status === 'current' ? 'secondary' : 'outline'
                                }>
                                  {module.duration}
                                </Badge>
                                {module.status !== 'locked' && (
                                  <Button variant="ghost" size="sm">
                                    <ArrowRight className="h-4 w-4" />
                                  </Button>
                                )}
                              </div>
                            </div>
                            {module.status !== 'not-started' && module.status !== 'locked' && (
                              <div className="space-y-1">
                                <div className="flex justify-between text-sm">
                                  <span>Progress</span>
                                  <span>{module.progress}%</span>
                                </div>
                                <Progress value={module.progress} className="h-1" />
                              </div>
                            )}
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                </div>

                {/* Sidebar Info */}
                <div className="space-y-6">
                  {/* Achievements */}
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center space-x-2">
                        <Trophy className="h-5 w-5" />
                        <span>Achievements</span>
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      {achievements.map((achievement, index) => (
                        <div key={index} className="flex items-center justify-between">
                          <div className="flex items-center space-x-3">
                            <div className={`p-2 rounded-lg ${
                              achievement.earned ? 'bg-yellow-100' : 'bg-gray-100'
                            }`}>
                              <achievement.icon className={`h-4 w-4 ${
                                achievement.earned ? 'text-yellow-600' : 'text-gray-400'
                              }`} />
                            </div>
                            <div>
                              <div className="font-medium text-sm">{achievement.name}</div>
                              {achievement.earned && (
                                <div className="text-xs text-gray-500">{achievement.date}</div>
                              )}
                            </div>
                          </div>
                          {achievement.earned && (
                            <CheckCircle className="h-4 w-4 text-green-500" />
                          )}
                        </div>
                      ))}
                    </CardContent>
                  </Card>

                  {/* Upcoming Interviews */}
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center space-x-2">
                        <Target className="h-5 w-5" />
                        <span>Interview Prep</span>
                      </CardTitle>
                      <CardDescription>Apply your skills</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      {upcomingInterviews.map((interview, index) => (
                        <div key={index} className="p-3 bg-gray-50 rounded-lg">
                          <div className="font-medium text-sm">{interview.company}</div>
                          <div className="text-xs text-gray-600">{interview.role}</div>
                          <div className="flex items-center justify-between mt-2">
                            <span className="text-xs text-blue-600">in {interview.date}</span>
                            <Badge variant="outline" className="text-xs">
                              {interview.difficulty}
                            </Badge>
                          </div>
                        </div>
                      ))}
                    </CardContent>
                  </Card>

                  {/* Action Buttons */}
                  <div className="space-y-3">
                    <Button size="lg" className="w-full bg-gradient-to-r from-emerald-600 to-green-600 hover:from-emerald-700 hover:to-green-700">
                      <Play className="h-4 w-4 mr-2" />
                      Continue Learning
                    </Button>
                    <Button variant="outline" size="lg" className="w-full">
                      <Target className="h-4 w-4 mr-2" />
                      Practice Interview
                    </Button>
                    <Button variant="outline" size="lg" className="w-full">
                      <BookOpen className="h-4 w-4 mr-2" />
                      View Certificate
                    </Button>
                  </div>
                </div>
              </div>
            )}
          </Tabs>
        </div>
      </div>
    </PlatformLayout>
  );
};

export default FrontendCertification;