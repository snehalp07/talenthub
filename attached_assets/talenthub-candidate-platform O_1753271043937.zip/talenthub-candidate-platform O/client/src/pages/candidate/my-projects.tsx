import PlatformLayout from "@/components/layout/platform-layout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { FolderOpen, Search, Filter, Star, Calendar, GitBranch, Eye, Edit, Trash2, Download, Share, Play, Pause, CheckCircle, Clock, Globe, Users, Code } from "lucide-react";
import { platformConfigs } from "@/config/complete-navigation";

export default function MyProjects() {
  const config = platformConfigs.candidate;

  const projects = [
    {
      id: 1,
      name: "E-commerce Dashboard",
      description: "React-based admin panel with real-time analytics",
      status: "completed",
      progress: 100,
      tech: ["React", "TypeScript", "Chart.js", "Tailwind"],
      createdAt: "2024-01-15",
      lastUpdated: "2024-02-10",
      deployUrl: "https://ecom-dash.vercel.app",
      githubUrl: "https://github.com/user/ecom-dashboard",
      color: "from-green-500 to-emerald-500",
      views: 245,
      stars: 12,
      type: "Frontend"
    },
    {
      id: 2,
      name: "Task Management API",
      description: "RESTful API with authentication and real-time features",
      status: "in-progress",
      progress: 75,
      tech: ["Node.js", "Express", "MongoDB", "Socket.io"],
      createdAt: "2024-02-01",
      lastUpdated: "2024-02-15",
      deployUrl: null,
      githubUrl: "https://github.com/user/task-api",
      color: "from-blue-500 to-indigo-500",
      views: 89,
      stars: 7,
      type: "Backend"
    },
    {
      id: 3,
      name: "Mobile Weather App",
      description: "Cross-platform weather app with beautiful UI",
      status: "paused",
      progress: 45,
      tech: ["React Native", "Expo", "OpenWeather API"],
      createdAt: "2024-01-20",
      lastUpdated: "2024-01-30",
      deployUrl: null,
      githubUrl: "https://github.com/user/weather-app",
      color: "from-orange-500 to-red-500",
      views: 156,
      stars: 5,
      type: "Mobile"
    },
    {
      id: 4,
      name: "AI Chat Interface",
      description: "Modern chat UI with OpenAI integration",
      status: "planning",
      progress: 20,
      tech: ["Next.js", "OpenAI API", "Prisma", "PostgreSQL"],
      createdAt: "2024-02-10",
      lastUpdated: "2024-02-12",
      deployUrl: null,
      githubUrl: "https://github.com/user/ai-chat",
      color: "from-purple-500 to-pink-500",
      views: 34,
      stars: 2,
      type: "Full-Stack"
    },
    {
      id: 5,
      name: "Portfolio Website",
      description: "Personal portfolio with dark mode and animations",
      status: "completed",
      progress: 100,
      tech: ["Next.js", "Framer Motion", "MDX"],
      createdAt: "2023-12-01",
      lastUpdated: "2024-01-05",
      deployUrl: "https://portfolio.dev",
      githubUrl: "https://github.com/user/portfolio",
      color: "from-cyan-500 to-blue-500",
      views: 892,
      stars: 28,
      type: "Frontend"
    }
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case "completed": return "bg-green-100 text-green-800 border-green-200";
      case "in-progress": return "bg-blue-100 text-blue-800 border-blue-200";
      case "paused": return "bg-orange-100 text-orange-800 border-orange-200";
      case "planning": return "bg-purple-100 text-purple-800 border-purple-200";
      default: return "bg-gray-100 text-gray-800 border-gray-200";
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "completed": return <CheckCircle className="h-4 w-4" />;
      case "in-progress": return <Play className="h-4 w-4" />;
      case "paused": return <Pause className="h-4 w-4" />;
      case "planning": return <Clock className="h-4 w-4" />;
      default: return <Clock className="h-4 w-4" />;
    }
  };

  return (
    <PlatformLayout
      sidebarTitle={config.sidebarTitle}
      sidebarSubtitle={config.sidebarSubtitle}
      sidebarSections={config.sidebarSections}
      usageData={config.usageData}
    >
      <div className="p-6 max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="text-center space-y-4">
          <div className="flex items-center justify-center space-x-3">
            <div className="p-3 bg-gradient-to-r from-green-500 to-emerald-500 rounded-full">
              <FolderOpen className="h-8 w-8 text-white" />
            </div>
            <h1 className="text-4xl font-bold bg-gradient-to-r from-green-600 to-emerald-600 bg-clip-text text-transparent">
              My Projects
            </h1>
          </div>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Manage and showcase your development projects with comprehensive tracking and analytics
          </p>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card className="bg-gradient-to-r from-green-50 to-emerald-50 border-green-200">
            <CardContent className="p-4 text-center">
              <FolderOpen className="h-8 w-8 text-green-500 mx-auto mb-2" />
              <p className="text-2xl font-bold text-green-600">5</p>
              <p className="text-sm text-muted-foreground">Total Projects</p>
            </CardContent>
          </Card>
          <Card className="bg-gradient-to-r from-blue-50 to-indigo-50 border-blue-200">
            <CardContent className="p-4 text-center">
              <CheckCircle className="h-8 w-8 text-blue-500 mx-auto mb-2" />
              <p className="text-2xl font-bold text-blue-600">2</p>
              <p className="text-sm text-muted-foreground">Completed</p>
            </CardContent>
          </Card>
          <Card className="bg-gradient-to-r from-purple-50 to-pink-50 border-purple-200">
            <CardContent className="p-4 text-center">
              <Eye className="h-8 w-8 text-purple-500 mx-auto mb-2" />
              <p className="text-2xl font-bold text-purple-600">1.4K</p>
              <p className="text-sm text-muted-foreground">Total Views</p>
            </CardContent>
          </Card>
          <Card className="bg-gradient-to-r from-orange-50 to-red-50 border-orange-200">
            <CardContent className="p-4 text-center">
              <Star className="h-8 w-8 text-orange-500 mx-auto mb-2" />
              <p className="text-2xl font-bold text-orange-600">54</p>
              <p className="text-sm text-muted-foreground">Total Stars</p>
            </CardContent>
          </Card>
        </div>

        {/* Search and Filters */}
        <div className="flex flex-col sm:flex-row gap-4 items-center justify-between">
          <div className="flex items-center space-x-2 flex-1">
            <div className="relative flex-1 max-w-md">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
              <Input
                placeholder="Search projects..."
                className="pl-10"
              />
            </div>
            <Button variant="outline" size="icon">
              <Filter className="h-4 w-4" />
            </Button>
          </div>
          <div className="flex items-center space-x-2">
            <Button className="bg-gradient-to-r from-green-500 to-emerald-500 hover:from-green-600 hover:to-emerald-600">
              <FolderOpen className="h-4 w-4 mr-2" />
              New Project
            </Button>
          </div>
        </div>

        <Tabs defaultValue="grid" className="space-y-6">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="grid">Grid View</TabsTrigger>
            <TabsTrigger value="list">List View</TabsTrigger>
            <TabsTrigger value="analytics">Analytics</TabsTrigger>
          </TabsList>

          <TabsContent value="grid" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {projects.map((project) => (
                <Card key={project.id} className="group hover:shadow-lg transition-all duration-300 hover:-translate-y-1 border-l-4 border-l-green-500">
                  <CardHeader className="pb-3">
                    <div className="flex items-start justify-between">
                      <div className={`p-2 bg-gradient-to-r ${project.color} rounded-lg`}>
                        <Code className="h-5 w-5 text-white" />
                      </div>
                      <Badge className={getStatusColor(project.status)}>
                        {getStatusIcon(project.status)}
                        <span className="ml-1 capitalize">{project.status.replace('-', ' ')}</span>
                      </Badge>
                    </div>
                    <CardTitle className="text-lg">{project.name}</CardTitle>
                    <CardDescription className="text-sm">{project.description}</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span className="text-muted-foreground">Progress</span>
                        <span className="font-medium">{project.progress}%</span>
                      </div>
                      <Progress value={project.progress} className="h-2" />
                    </div>
                    
                    <div className="flex items-center gap-4 text-sm text-muted-foreground">
                      <div className="flex items-center gap-1">
                        <Eye className="h-4 w-4" />
                        <span>{project.views}</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <Star className="h-4 w-4" />
                        <span>{project.stars}</span>
                      </div>
                      <Badge variant="secondary" className="text-xs">
                        {project.type}
                      </Badge>
                    </div>

                    <div className="flex flex-wrap gap-1">
                      {project.tech.slice(0, 3).map((tech, index) => (
                        <Badge key={index} variant="outline" className="text-xs">
                          {tech}
                        </Badge>
                      ))}
                      {project.tech.length > 3 && (
                        <Badge variant="outline" className="text-xs">
                          +{project.tech.length - 3}
                        </Badge>
                      )}
                    </div>

                    <div className="flex items-center gap-2">
                      <Button size="sm" className="flex-1 bg-gradient-to-r from-green-500 to-emerald-500 hover:from-green-600 hover:to-emerald-600">
                        <Edit className="h-4 w-4 mr-1" />
                        Edit
                      </Button>
                      {project.deployUrl && (
                        <Button size="sm" variant="outline">
                          <Globe className="h-4 w-4" />
                        </Button>
                      )}
                      <Button size="sm" variant="outline">
                        <GitBranch className="h-4 w-4" />
                      </Button>
                      <Button size="sm" variant="outline">
                        <Share className="h-4 w-4" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="list" className="space-y-4">
            <div className="space-y-4">
              {projects.map((project) => (
                <Card key={project.id} className="hover:shadow-md transition-shadow">
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-4 flex-1">
                        <div className={`p-2 bg-gradient-to-r ${project.color} rounded-lg`}>
                          <Code className="h-5 w-5 text-white" />
                        </div>
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-1">
                            <h3 className="font-semibold text-lg">{project.name}</h3>
                            <Badge className={getStatusColor(project.status)}>
                              {getStatusIcon(project.status)}
                              <span className="ml-1 capitalize">{project.status.replace('-', ' ')}</span>
                            </Badge>
                          </div>
                          <p className="text-muted-foreground text-sm mb-2">{project.description}</p>
                          <div className="flex items-center gap-4 text-sm text-muted-foreground">
                            <span>Updated: {new Date(project.lastUpdated).toLocaleDateString()}</span>
                            <div className="flex items-center gap-1">
                              <Eye className="h-4 w-4" />
                              <span>{project.views}</span>
                            </div>
                            <div className="flex items-center gap-1">
                              <Star className="h-4 w-4" />
                              <span>{project.stars}</span>
                            </div>
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <div className="text-right mr-4">
                          <div className="text-sm font-medium">{project.progress}%</div>
                          <Progress value={project.progress} className="h-2 w-20" />
                        </div>
                        <Button size="sm" variant="outline">
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button size="sm" variant="outline">
                          <Eye className="h-4 w-4" />
                        </Button>
                        <Button size="sm" variant="outline">
                          <Share className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="analytics" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Project Performance</CardTitle>
                  <CardDescription>Views and engagement over time</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-muted-foreground">This Month</span>
                      <span className="font-semibold">+24% views</span>
                    </div>
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span>Portfolio Website</span>
                        <span>892 views</span>
                      </div>
                      <Progress value={75} className="h-2" />
                    </div>
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span>E-commerce Dashboard</span>
                        <span>245 views</span>
                      </div>
                      <Progress value={45} className="h-2" />
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Technology Usage</CardTitle>
                  <CardDescription>Most used technologies</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {["React", "TypeScript", "Node.js", "Next.js", "MongoDB"].map((tech, index) => (
                      <div key={tech} className="space-y-2">
                        <div className="flex justify-between text-sm">
                          <span>{tech}</span>
                          <span>{5 - index} projects</span>
                        </div>
                        <Progress value={(5 - index) * 20} className="h-2" />
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Completion Rate</CardTitle>
                  <CardDescription>Project completion statistics</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="text-center">
                      <div className="text-3xl font-bold text-green-600">40%</div>
                      <div className="text-sm text-muted-foreground">Overall completion rate</div>
                    </div>
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span>Completed</span>
                        <span>2 projects</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span>In Progress</span>
                        <span>1 project</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span>Paused</span>
                        <span>1 project</span>
                      </div>
                      <div className="flex justify-between text-sm">
                        <span>Planning</span>
                        <span>1 project</span>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </PlatformLayout>
  );
}