import PlatformLayout from "@/components/layout/platform-layout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Users, UserPlus, MessageCircle, Star, MapPin, Building, Search, Filter } from "lucide-react";
import { platformConfigs } from "@/config/complete-navigation";

export default function ProfessionalNetwork() {
  const config = platformConfigs.candidate;
  
  const connections = [
    {
      id: 1,
      name: "Sarah Chen",
      title: "Senior Software Engineer",
      company: "TechCorp",
      location: "San Francisco, CA",
      avatar: "/api/placeholder/60/60",
      mutualConnections: 12,
      isConnected: true,
      expertise: ["React", "TypeScript", "Node.js"]
    },
    {
      id: 2,
      name: "Michael Rodriguez",
      title: "Product Manager",
      company: "InnovateLabs",
      location: "Austin, TX",
      avatar: "/api/placeholder/60/60",
      mutualConnections: 8,
      isConnected: true,
      expertise: ["Product Strategy", "Agile", "Analytics"]
    },
    {
      id: 3,
      name: "Emma Thompson",
      title: "UX Designer",
      company: "DesignStudio",
      location: "New York, NY",
      avatar: "/api/placeholder/60/60",
      mutualConnections: 5,
      isConnected: false,
      expertise: ["UI/UX", "Figma", "User Research"]
    }
  ];

  const suggestedConnections = [
    {
      id: 4,
      name: "David Kim",
      title: "Data Scientist",
      company: "DataTech",
      location: "Seattle, WA",
      avatar: "/api/placeholder/60/60",
      mutualConnections: 15,
      reason: "Works at similar companies"
    },
    {
      id: 5,
      name: "Lisa Anderson",
      title: "Engineering Manager",
      company: "CloudSoft",
      location: "Denver, CO",
      avatar: "/api/placeholder/60/60",
      mutualConnections: 7,
      reason: "Similar interests in leadership"
    }
  ];

  return (
    <PlatformLayout
      sidebarTitle={config.sidebarTitle}
      sidebarSubtitle={config.sidebarSubtitle}
      sidebarSections={config.sidebarSections}
      usageData={config.usageData}
    >
      <div className="space-y-6">
        {/* Network Overview */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card className="bg-gradient-to-br from-blue-50 to-blue-100 border-blue-200">
            <CardHeader className="pb-2">
              <CardTitle className="text-lg text-blue-700">Total Connections</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-blue-800">342</div>
              <p className="text-sm text-blue-600">+12 this month</p>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-green-50 to-green-100 border-green-200">
            <CardHeader className="pb-2">
              <CardTitle className="text-lg text-green-700">Network Growth</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-green-800">+15%</div>
              <p className="text-sm text-green-600">vs last month</p>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-purple-50 to-purple-100 border-purple-200">
            <CardHeader className="pb-2">
              <CardTitle className="text-lg text-purple-700">Active Conversations</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-purple-800">28</div>
              <p className="text-sm text-purple-600">ongoing chats</p>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-orange-50 to-orange-100 border-orange-200">
            <CardHeader className="pb-2">
              <CardTitle className="text-lg text-orange-700">Referrals Received</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-orange-800">7</div>
              <p className="text-sm text-orange-600">this quarter</p>
            </CardContent>
          </Card>
        </div>

        {/* Search and Filter */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Search className="h-5 w-5 text-blue-600" />
              Find Professionals
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex gap-4">
              <Input 
                placeholder="Search by name, company, or skills..." 
                className="flex-1"
              />
              <Button variant="outline" size="icon">
                <Filter className="h-4 w-4" />
              </Button>
              <Button className="bg-blue-600 hover:bg-blue-700">
                Search
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Network Tabs */}
        <Tabs defaultValue="connections" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="connections">My Connections</TabsTrigger>
            <TabsTrigger value="suggestions">Suggestions</TabsTrigger>
            <TabsTrigger value="requests">Requests (3)</TabsTrigger>
          </TabsList>

          <TabsContent value="connections" className="space-y-4">
            <div className="grid gap-4">
              {connections.map((connection) => (
                <Card key={connection.id} className="hover:shadow-md transition-shadow">
                  <CardContent className="p-6">
                    <div className="flex items-start justify-between">
                      <div className="flex gap-4">
                        <Avatar className="h-16 w-16">
                          <AvatarImage src={connection.avatar} />
                          <AvatarFallback>{connection.name.split(' ').map(n => n[0]).join('')}</AvatarFallback>
                        </Avatar>
                        <div className="space-y-2">
                          <div>
                            <h3 className="font-semibold text-lg">{connection.name}</h3>
                            <p className="text-gray-600">{connection.title}</p>
                            <div className="flex items-center gap-2 text-sm text-gray-500">
                              <Building className="h-4 w-4" />
                              {connection.company}
                              <MapPin className="h-4 w-4 ml-2" />
                              {connection.location}
                            </div>
                          </div>
                          <div className="flex flex-wrap gap-1">
                            {connection.expertise.map((skill) => (
                              <Badge key={skill} variant="secondary" className="text-xs">
                                {skill}
                              </Badge>
                            ))}
                          </div>
                          <p className="text-sm text-gray-500">
                            {connection.mutualConnections} mutual connections
                          </p>
                        </div>
                      </div>
                      <div className="flex gap-2">
                        <Button variant="outline" size="sm">
                          <MessageCircle className="h-4 w-4 mr-1" />
                          Message
                        </Button>
                        <Button variant="outline" size="sm">
                          <Star className="h-4 w-4 mr-1" />
                          Endorse
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="suggestions" className="space-y-4">
            <div className="grid gap-4">
              {suggestedConnections.map((suggestion) => (
                <Card key={suggestion.id} className="hover:shadow-md transition-shadow">
                  <CardContent className="p-6">
                    <div className="flex items-start justify-between">
                      <div className="flex gap-4">
                        <Avatar className="h-16 w-16">
                          <AvatarImage src={suggestion.avatar} />
                          <AvatarFallback>{suggestion.name.split(' ').map(n => n[0]).join('')}</AvatarFallback>
                        </Avatar>
                        <div className="space-y-2">
                          <div>
                            <h3 className="font-semibold text-lg">{suggestion.name}</h3>
                            <p className="text-gray-600">{suggestion.title}</p>
                            <div className="flex items-center gap-2 text-sm text-gray-500">
                              <Building className="h-4 w-4" />
                              {suggestion.company}
                              <MapPin className="h-4 w-4 ml-2" />
                              {suggestion.location}
                            </div>
                          </div>
                          <p className="text-sm text-blue-600 font-medium">
                            {suggestion.reason}
                          </p>
                          <p className="text-sm text-gray-500">
                            {suggestion.mutualConnections} mutual connections
                          </p>
                        </div>
                      </div>
                      <div className="flex gap-2">
                        <Button className="bg-blue-600 hover:bg-blue-700" size="sm">
                          <UserPlus className="h-4 w-4 mr-1" />
                          Connect
                        </Button>
                        <Button variant="outline" size="sm">
                          View Profile
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="requests" className="space-y-4">
            <Card>
              <CardContent className="p-6">
                <div className="text-center py-8">
                  <Users className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                  <h3 className="text-lg font-medium text-gray-600 mb-2">Connection Requests</h3>
                  <p className="text-gray-500">You have 3 pending connection requests</p>
                  <Button className="mt-4 bg-blue-600 hover:bg-blue-700">
                    View All Requests
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </PlatformLayout>
  );
}