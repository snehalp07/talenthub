import PlatformLayout from "@/components/layout/platform-layout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { Search, Upload, Github, AlertTriangle, CheckCircle, Star, TrendingUp, Code, FileText, Bug, Shield, Zap } from "lucide-react";
import { platformConfigs } from "@/config/complete-navigation";

export default function CodeAnalysis() {
  const config = platformConfigs.candidate;

  const analysisResults = [
    {
      id: 1,
      projectName: "E-commerce React App",
      language: "JavaScript",
      analyzedAt: "2024-02-15",
      overallScore: 85,
      linesOfCode: 2450,
      files: 34,
      issues: {
        critical: 2,
        major: 5,
        minor: 12,
        suggestions: 8
      },
      metrics: {
        maintainability: 78,
        reliability: 92,
        security: 85,
        performance: 80
      },
      topIssues: [
        { type: "Security", message: "Potential XSS vulnerability in user input", severity: "critical", line: 45 },
        { type: "Performance", message: "Large bundle size detected", severity: "major", line: null },
        { type: "Code Quality", message: "Complex function exceeds recommended length", severity: "minor", line: 123 }
      ]
    },
    {
      id: 2,
      projectName: "Node.js API Server",
      language: "JavaScript",
      analyzedAt: "2024-02-12",
      overallScore: 92,
      linesOfCode: 1850,
      files: 28,
      issues: {
        critical: 0,
        major: 2,
        minor: 6,
        suggestions: 4
      },
      metrics: {
        maintainability: 95,
        reliability: 88,
        security: 94,
        performance: 90
      },
      topIssues: [
        { type: "Performance", message: "Database query could be optimized", severity: "major", line: 67 },
        { type: "Code Quality", message: "Consider extracting utility function", severity: "minor", line: 89 }
      ]
    }
  ];

  const codeMetrics = [
    { metric: "Code Coverage", value: 78, target: 85, unit: "%" },
    { metric: "Cyclomatic Complexity", value: 12, target: 10, unit: "" },
    { metric: "Technical Debt", value: 2.3, target: 1.5, unit: "hours" },
    { metric: "Duplicated Code", value: 5.2, target: 3.0, unit: "%" }
  ];

  const getScoreColor = (score: number) => {
    if (score >= 90) return "text-green-600";
    if (score >= 75) return "text-blue-600";
    if (score >= 60) return "text-orange-600";
    return "text-red-600";
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case "critical": return "bg-red-100 text-red-800 border-red-200";
      case "major": return "bg-orange-100 text-orange-800 border-orange-200";
      case "minor": return "bg-yellow-100 text-yellow-800 border-yellow-200";
      case "suggestion": return "bg-blue-100 text-blue-800 border-blue-200";
      default: return "bg-gray-100 text-gray-800 border-gray-200";
    }
  };

  const getSeverityIcon = (severity: string) => {
    switch (severity) {
      case "critical": return <AlertTriangle className="h-4 w-4" />;
      case "major": return <AlertTriangle className="h-4 w-4" />;
      case "minor": return <AlertTriangle className="h-4 w-4" />;
      default: return <CheckCircle className="h-4 w-4" />;
    }
  };

  return (
    <PlatformLayout
      sidebarTitle={config.sidebarTitle}
      sidebarSubtitle={config.sidebarSubtitle}
      sidebarSections={config.sidebarSections}
      usageData={config.usageData}
    >
      <div className="p-6 max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="text-center space-y-4">
          <div className="flex items-center justify-center space-x-3">
            <div className="p-3 bg-gradient-to-r from-indigo-500 to-purple-500 rounded-full">
              <Search className="h-8 w-8 text-white" />
            </div>
            <h1 className="text-4xl font-bold bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent">
              Code Analysis
            </h1>
          </div>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            AI-powered code analysis to identify issues, improve quality, and optimize performance
          </p>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card className="bg-gradient-to-r from-indigo-50 to-purple-50 border-indigo-200">
            <CardContent className="p-4 text-center">
              <Search className="h-8 w-8 text-indigo-500 mx-auto mb-2" />
              <p className="text-2xl font-bold text-indigo-600">2</p>
              <p className="text-sm text-muted-foreground">Projects Analyzed</p>
            </CardContent>
          </Card>
          <Card className="bg-gradient-to-r from-green-50 to-emerald-50 border-green-200">
            <CardContent className="p-4 text-center">
              <CheckCircle className="h-8 w-8 text-green-500 mx-auto mb-2" />
              <p className="text-2xl font-bold text-green-600">89%</p>
              <p className="text-sm text-muted-foreground">Avg. Quality Score</p>
            </CardContent>
          </Card>
          <Card className="bg-gradient-to-r from-orange-50 to-red-50 border-orange-200">
            <CardContent className="p-4 text-center">
              <Bug className="h-8 w-8 text-orange-500 mx-auto mb-2" />
              <p className="text-2xl font-bold text-orange-600">29</p>
              <p className="text-sm text-muted-foreground">Issues Identified</p>
            </CardContent>
          </Card>
          <Card className="bg-gradient-to-r from-blue-50 to-cyan-50 border-blue-200">
            <CardContent className="p-4 text-center">
              <TrendingUp className="h-8 w-8 text-blue-500 mx-auto mb-2" />
              <p className="text-2xl font-bold text-blue-600">+15%</p>
              <p className="text-sm text-muted-foreground">Quality Improvement</p>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="analyze" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="analyze">New Analysis</TabsTrigger>
            <TabsTrigger value="results">Analysis Results</TabsTrigger>
            <TabsTrigger value="metrics">Code Metrics</TabsTrigger>
            <TabsTrigger value="insights">AI Insights</TabsTrigger>
          </TabsList>

          <TabsContent value="analyze" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Github className="h-5 w-5" />
                    Repository Analysis
                  </CardTitle>
                  <CardDescription>Analyze code from GitHub repository</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Repository URL</label>
                    <Input placeholder="https://github.com/username/repository" />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Branch (optional)</label>
                    <Input placeholder="main" />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Analysis Type</label>
                    <Select defaultValue="full">
                      <SelectTrigger>
                        <SelectValue placeholder="Select analysis type" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="full">Full Analysis</SelectItem>
                        <SelectItem value="security">Security Focus</SelectItem>
                        <SelectItem value="performance">Performance Focus</SelectItem>
                        <SelectItem value="quality">Code Quality Focus</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <Button className="w-full bg-gradient-to-r from-indigo-500 to-purple-500 hover:from-indigo-600 hover:to-purple-600">
                    <Search className="h-4 w-4 mr-2" />
                    Analyze Repository
                  </Button>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Upload className="h-5 w-5" />
                    File Upload Analysis
                  </CardTitle>
                  <CardDescription>Upload files for direct analysis</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center">
                    <Upload className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                    <p className="text-sm text-muted-foreground mb-2">
                      Drop code files here or click to upload
                    </p>
                    <p className="text-xs text-muted-foreground mb-4">
                      Supports: .js, .ts, .jsx, .tsx, .py, .java, .go
                    </p>
                    <Button variant="outline">
                      Choose Files
                    </Button>
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Project Language</label>
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="Select language" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="javascript">JavaScript</SelectItem>
                        <SelectItem value="typescript">TypeScript</SelectItem>
                        <SelectItem value="python">Python</SelectItem>
                        <SelectItem value="java">Java</SelectItem>
                        <SelectItem value="go">Go</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <Button className="w-full bg-gradient-to-r from-green-500 to-emerald-500 hover:from-green-600 hover:to-emerald-600">
                    <Upload className="h-4 w-4 mr-2" />
                    Upload & Analyze
                  </Button>
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Code className="h-5 w-5" />
                  Inline Code Analysis
                </CardTitle>
                <CardDescription>Paste code snippet for quick analysis</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium">Code Snippet</label>
                  <Textarea 
                    placeholder="Paste your code here..."
                    className="min-h-[200px] font-mono text-sm"
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <Select>
                    <SelectTrigger>
                      <SelectValue placeholder="Language" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="javascript">JavaScript</SelectItem>
                      <SelectItem value="typescript">TypeScript</SelectItem>
                      <SelectItem value="python">Python</SelectItem>
                      <SelectItem value="java">Java</SelectItem>
                    </SelectContent>
                  </Select>
                  <Button className="bg-gradient-to-r from-blue-500 to-cyan-500 hover:from-blue-600 hover:to-cyan-600">
                    <Search className="h-4 w-4 mr-2" />
                    Analyze Code
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="results" className="space-y-6">
            <h3 className="text-xl font-bold text-indigo-700">Analysis Results</h3>
            
            <div className="space-y-6">
              {analysisResults.map((result) => (
                <Card key={result.id} className="border-l-4 border-l-indigo-500">
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div>
                        <CardTitle className="text-xl">{result.projectName}</CardTitle>
                        <CardDescription>
                          {result.language} • {result.files} files • {result.linesOfCode.toLocaleString()} lines
                        </CardDescription>
                      </div>
                      <div className="text-right">
                        <div className={`text-2xl font-bold ${getScoreColor(result.overallScore)}`}>
                          {result.overallScore}
                        </div>
                        <div className="text-sm text-muted-foreground">Overall Score</div>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                      <div className="text-center">
                        <div className="text-lg font-semibold text-green-600">{result.metrics.maintainability}</div>
                        <div className="text-sm text-muted-foreground">Maintainability</div>
                        <Progress value={result.metrics.maintainability} className="h-2 mt-1" />
                      </div>
                      <div className="text-center">
                        <div className="text-lg font-semibold text-blue-600">{result.metrics.reliability}</div>
                        <div className="text-sm text-muted-foreground">Reliability</div>
                        <Progress value={result.metrics.reliability} className="h-2 mt-1" />
                      </div>
                      <div className="text-center">
                        <div className="text-lg font-semibold text-purple-600">{result.metrics.security}</div>
                        <div className="text-sm text-muted-foreground">Security</div>
                        <Progress value={result.metrics.security} className="h-2 mt-1" />
                      </div>
                      <div className="text-center">
                        <div className="text-lg font-semibold text-orange-600">{result.metrics.performance}</div>
                        <div className="text-sm text-muted-foreground">Performance</div>
                        <Progress value={result.metrics.performance} className="h-2 mt-1" />
                      </div>
                    </div>

                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                      <div className="text-center p-3 bg-red-50 border border-red-200 rounded-lg">
                        <div className="text-lg font-bold text-red-600">{result.issues.critical}</div>
                        <div className="text-sm text-red-800">Critical</div>
                      </div>
                      <div className="text-center p-3 bg-orange-50 border border-orange-200 rounded-lg">
                        <div className="text-lg font-bold text-orange-600">{result.issues.major}</div>
                        <div className="text-sm text-orange-800">Major</div>
                      </div>
                      <div className="text-center p-3 bg-yellow-50 border border-yellow-200 rounded-lg">
                        <div className="text-lg font-bold text-yellow-600">{result.issues.minor}</div>
                        <div className="text-sm text-yellow-800">Minor</div>
                      </div>
                      <div className="text-center p-3 bg-blue-50 border border-blue-200 rounded-lg">
                        <div className="text-lg font-bold text-blue-600">{result.issues.suggestions}</div>
                        <div className="text-sm text-blue-800">Suggestions</div>
                      </div>
                    </div>

                    <div>
                      <h4 className="font-medium mb-3">Top Issues</h4>
                      <div className="space-y-2">
                        {result.topIssues.map((issue, index) => (
                          <div key={index} className="flex items-start gap-3 p-3 border rounded-lg">
                            <Badge className={getSeverityColor(issue.severity)}>
                              {getSeverityIcon(issue.severity)}
                              <span className="ml-1 capitalize">{issue.severity}</span>
                            </Badge>
                            <div className="flex-1">
                              <div className="font-medium text-sm">{issue.type}</div>
                              <div className="text-sm text-muted-foreground">{issue.message}</div>
                              {issue.line && (
                                <div className="text-xs text-muted-foreground">Line {issue.line}</div>
                              )}
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>

                    <div className="flex gap-2">
                      <Button className="bg-indigo-500 hover:bg-indigo-600">
                        <FileText className="h-4 w-4 mr-2" />
                        View Full Report
                      </Button>
                      <Button variant="outline">
                        <Star className="h-4 w-4 mr-2" />
                        Export Report
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="metrics" className="space-y-6">
            <h3 className="text-xl font-bold text-indigo-700">Code Quality Metrics</h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {codeMetrics.map((metric, index) => (
                <Card key={index}>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between mb-4">
                      <h4 className="font-semibold">{metric.metric}</h4>
                      <div className="text-right">
                        <div className="text-lg font-bold">{metric.value}{metric.unit}</div>
                        <div className="text-sm text-muted-foreground">Target: {metric.target}{metric.unit}</div>
                      </div>
                    </div>
                    <Progress 
                      value={metric.unit === "%" ? metric.value : (metric.value / metric.target) * 100} 
                      className="h-3" 
                    />
                    <div className="flex justify-between text-xs text-muted-foreground mt-2">
                      <span>Current</span>
                      <span>Target</span>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            <Card>
              <CardHeader>
                <CardTitle>Code Quality Trends</CardTitle>
                <CardDescription>Quality metrics over time</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-center py-8">
                  <TrendingUp className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
                  <h3 className="text-lg font-semibold mb-2">Quality Improving</h3>
                  <p className="text-muted-foreground">
                    Your code quality has improved by 15% over the last month
                  </p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="insights" className="space-y-6">
            <h3 className="text-xl font-bold text-indigo-700">AI-Powered Insights</h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Shield className="h-5 w-5 text-blue-500" />
                    Security Recommendations
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="p-3 bg-red-50 border border-red-200 rounded-lg">
                      <h4 className="font-medium text-red-800">High Priority</h4>
                      <p className="text-sm text-red-600">Address XSS vulnerability in user input validation</p>
                    </div>
                    <div className="p-3 bg-orange-50 border border-orange-200 rounded-lg">
                      <h4 className="font-medium text-orange-800">Medium Priority</h4>
                      <p className="text-sm text-orange-600">Implement rate limiting for API endpoints</p>
                    </div>
                    <div className="p-3 bg-yellow-50 border border-yellow-200 rounded-lg">
                      <h4 className="font-medium text-yellow-800">Low Priority</h4>
                      <p className="text-sm text-yellow-600">Update dependencies to latest versions</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Zap className="h-5 w-5 text-orange-500" />
                    Performance Optimizations
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="p-3 bg-blue-50 border border-blue-200 rounded-lg">
                      <h4 className="font-medium text-blue-800">Bundle Optimization</h4>
                      <p className="text-sm text-blue-600">Reduce bundle size by 30% with code splitting</p>
                    </div>
                    <div className="p-3 bg-green-50 border border-green-200 rounded-lg">
                      <h4 className="font-medium text-green-800">Database Queries</h4>
                      <p className="text-sm text-green-600">Optimize database queries for 40% faster response</p>
                    </div>
                    <div className="p-3 bg-purple-50 border border-purple-200 rounded-lg">
                      <h4 className="font-medium text-purple-800">Caching Strategy</h4>
                      <p className="text-sm text-purple-600">Implement Redis caching for API responses</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </PlatformLayout>
  );
}