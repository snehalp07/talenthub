import { useState } from "react";
import { useAuth } from "@/hooks/use-auth";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { 
  HeadphonesIcon, 
  Clock, 
  MessageSquare, 
  Phone, 
  Video, 
  CheckCircle,
  AlertCircle,
  Crown,
  Zap,
  Calendar
} from "lucide-react";
import PlatformLayout from "@/components/layout/platform-layout";
import { platformConfigs } from "@/config/complete-navigation";

function PrioritySupportContent() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [selectedCategory, setSelectedCategory] = useState("");
  const [priority, setPriority] = useState("medium");
  const [subject, setSubject] = useState("");
  const [description, setDescription] = useState("");

  const { data: supportTickets = [] } = useQuery({
    queryKey: ["/api/support/tickets"],
    initialData: [
      {
        id: "ticket-001",
        subject: "Job Application Issue",
        category: "technical",
        priority: "high",
        status: "in_progress",
        createdAt: "2024-06-08T10:30:00Z",
        responseTime: "2 hours",
        assignedAgent: "Sarah Wilson"
      },
      {
        id: "ticket-002",
        subject: "Certification Query",
        category: "account",
        priority: "medium",
        status: "resolved",
        createdAt: "2024-06-06T14:20:00Z",
        responseTime: "4 hours",
        assignedAgent: "Mike Johnson"
      }
    ]
  });

  const createTicketMutation = useMutation({
    mutationFn: async (ticketData: any) => {
      return apiRequest("POST", "/api/support/tickets", ticketData);
    },
    onSuccess: () => {
      toast({
        title: "Support Ticket Created",
        description: "Your priority support ticket has been submitted successfully.",
      });
      setSubject("");
      setDescription("");
      setSelectedCategory("");
      queryClient.invalidateQueries({ queryKey: ["/api/support/tickets"] });
    },
  });

  const handleSubmitTicket = () => {
    if (!subject || !description || !selectedCategory) {
      toast({
        title: "Missing Information",
        description: "Please fill in all required fields.",
        variant: "destructive",
      });
      return;
    }

    createTicketMutation.mutate({
      subject,
      description,
      category: selectedCategory,
      priority,
    });
  };

  const getPriorityBadge = (priority: string) => {
    const variants = {
      low: "bg-green-100 text-green-800",
      medium: "bg-yellow-100 text-yellow-800",
      high: "bg-red-100 text-red-800",
      urgent: "bg-purple-100 text-purple-800"
    };
    return variants[priority as keyof typeof variants] || variants.medium;
  };

  const getStatusBadge = (status: string) => {
    const variants = {
      open: "bg-blue-100 text-blue-800",
      in_progress: "bg-yellow-100 text-yellow-800",
      resolved: "bg-green-100 text-green-800",
      closed: "bg-gray-100 text-gray-800"
    };
    return variants[status as keyof typeof variants] || variants.open;
  };

  return (
    <div className="max-w-7xl mx-auto p-6">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Priority Support</h1>
        <p className="text-muted-foreground">Get immediate assistance from our expert support team</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
        <Card className="bg-gradient-to-br from-sky-50 to-blue-50 border-sky-200">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Average Response</p>
                <p className="text-2xl font-bold text-sky-600">&lt; 2 Hours</p>
              </div>
              <Clock className="w-8 h-8 text-sky-600" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-green-50 to-emerald-50 border-green-200">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Resolution Rate</p>
                <p className="text-2xl font-bold text-green-600">99.8%</p>
              </div>
              <CheckCircle className="w-8 h-8 text-green-600" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-purple-50 to-violet-50 border-purple-200">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Active Tickets</p>
                <p className="text-2xl font-bold text-purple-600">{supportTickets.filter(t => t.status !== 'resolved' && t.status !== 'closed').length}</p>
              </div>
              <AlertCircle className="w-8 h-8 text-purple-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Create New Ticket */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Crown className="w-5 h-5 mr-2 text-yellow-500" />
              Create Priority Ticket
            </CardTitle>
            <CardDescription>
              Submit a priority support request for immediate assistance
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <label className="text-sm font-medium mb-2 block">Category</label>
              <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                <SelectTrigger>
                  <SelectValue placeholder="Select category" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="technical">Technical Issue</SelectItem>
                  <SelectItem value="account">Account & Billing</SelectItem>
                  <SelectItem value="job_board">Job Board</SelectItem>
                  <SelectItem value="certification">Certification</SelectItem>
                  <SelectItem value="other">Other</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <label className="text-sm font-medium mb-2 block">Priority Level</label>
              <Select value={priority} onValueChange={setPriority}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="low">Low</SelectItem>
                  <SelectItem value="medium">Medium</SelectItem>
                  <SelectItem value="high">High</SelectItem>
                  <SelectItem value="urgent">Urgent</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <label className="text-sm font-medium mb-2 block">Subject</label>
              <Input
                placeholder="Brief description of your issue"
                value={subject}
                onChange={(e) => setSubject(e.target.value)}
              />
            </div>

            <div>
              <label className="text-sm font-medium mb-2 block">Description</label>
              <Textarea
                placeholder="Detailed description of your issue..."
                rows={4}
                value={description}
                onChange={(e) => setDescription(e.target.value)}
              />
            </div>

            <Button 
              onClick={handleSubmitTicket}
              className="w-full bg-sky-500 hover:bg-sky-600"
              disabled={createTicketMutation.isPending}
            >
              <Zap className="w-4 h-4 mr-2" />
              {createTicketMutation.isPending ? "Submitting..." : "Submit Priority Ticket"}
            </Button>
          </CardContent>
        </Card>

        {/* Quick Support Options */}
        <Card>
          <CardHeader>
            <CardTitle>Quick Support Options</CardTitle>
            <CardDescription>
              Get immediate help through multiple channels
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <Button variant="outline" className="w-full justify-start">
              <MessageSquare className="w-4 h-4 mr-2" />
              Live Chat Support
              <Badge className="ml-auto bg-green-100 text-green-800">Online</Badge>
            </Button>

            <Button variant="outline" className="w-full justify-start">
              <Phone className="w-4 h-4 mr-2" />
              Priority Phone Support
              <Badge className="ml-auto bg-sky-100 text-sky-800">Available</Badge>
            </Button>

            <Button variant="outline" className="w-full justify-start">
              <Video className="w-4 h-4 mr-2" />
              Screen Share Session
              <Badge className="ml-auto bg-purple-100 text-purple-800">Premium</Badge>
            </Button>

            <Button variant="outline" className="w-full justify-start">
              <Calendar className="w-4 h-4 mr-2" />
              Schedule Call Back
              <Badge className="ml-auto bg-yellow-100 text-yellow-800">24/7</Badge>
            </Button>

            <div className="mt-6 p-4 bg-sky-50 rounded-lg">
              <h4 className="font-medium text-sky-900 mb-2">Premium Support Hours</h4>
              <p className="text-sm text-sky-700">
                Monday - Friday: 24/7<br />
                Weekend: 9 AM - 6 PM IST<br />
                Emergency: Always Available
              </p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Support Tickets History */}
      <Card className="mt-6">
        <CardHeader>
          <CardTitle>Your Support Tickets</CardTitle>
          <CardDescription>
            Track the status of your submitted tickets
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {supportTickets.map((ticket: any) => (
              <div key={ticket.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                <div className="flex-1">
                  <h4 className="font-medium text-gray-900">{ticket.subject}</h4>
                  <p className="text-sm text-gray-600">
                    {ticket.category} • Created {new Date(ticket.createdAt).toLocaleDateString()}
                  </p>
                  {ticket.assignedAgent && (
                    <p className="text-xs text-gray-500 mt-1">
                      Assigned to: {ticket.assignedAgent}
                    </p>
                  )}
                </div>
                <div className="text-right space-y-2">
                  <div className="flex gap-2">
                    <Badge className={getPriorityBadge(ticket.priority)}>
                      {ticket.priority.toUpperCase()}
                    </Badge>
                    <Badge className={getStatusBadge(ticket.status)}>
                      {ticket.status.replace('_', ' ').toUpperCase()}
                    </Badge>
                  </div>
                  <p className="text-xs text-gray-500">
                    Response: {ticket.responseTime}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

export default function PrioritySupport() {
  const config = platformConfigs.candidate;
  
  const usageData = [
    { label: "Priority Tickets", current: 5, max: 10 },
    { label: "Express Support", current: 3, max: 8 },
    { label: "Escalation Credits", current: 2, max: 5 },
  ];

  return (
    <PlatformLayout
      sidebarTitle={config.sidebarTitle}
      sidebarSubtitle={config.sidebarSubtitle}
      sidebarSections={config.sidebarSections}
      usageData={usageData}
    >
      <PrioritySupportContent />
    </PlatformLayout>
  );
}