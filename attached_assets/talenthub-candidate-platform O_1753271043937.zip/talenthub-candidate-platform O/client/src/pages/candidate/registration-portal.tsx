import { useState } from "react";
import PlatformLayout from "@/components/layout/platform-layout";
import { candidateNavigation } from "@/config/complete-navigation";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Progress } from "@/components/ui/progress";
import { UserPlus, Upload, CreditCard, CheckCircle, Clock, FileText, GraduationCap, Building, MapPin, Phone, Mail } from "lucide-react";

export default function RegistrationPortal() {
  const [currentStep, setCurrentStep] = useState(1);
  const [formData, setFormData] = useState({
    personalInfo: {
      firstName: "",
      lastName: "",
      email: "",
      phone: "",
      dateOfBirth: "",
      gender: "",
      address: "",
      city: "",
      state: "",
      zipCode: "",
      country: ""
    },
    education: {
      highestDegree: "",
      institution: "",
      fieldOfStudy: "",
      graduationYear: "",
      gpa: "",
      additionalCertifications: ""
    },
    experience: {
      yearsOfExperience: "",
      currentCompany: "",
      currentPosition: "",
      currentSalary: "",
      expectedSalary: "",
      noticePeriod: "",
      keySkills: "",
      resume: null
    },
    preferences: {
      jobType: "",
      workMode: "",
      preferredLocations: [],
      industryPreference: "",
      willingnessToRelocate: false,
      availabilityToStart: ""
    }
  });

  // Sample registration forms data
  const availableForms = [
    {
      id: 1,
      title: "Software Developer Registration",
      company: "TechCorp Inc",
      description: "Join our innovative software development team",
      price: 25,
      currency: "USD",
      estimatedTime: "15 minutes",
      fields: ["Personal Info", "Education", "Technical Skills", "Portfolio"],
      benefits: ["Priority screening", "Direct HR contact", "Skill assessment access"],
      deadline: "2024-04-15",
      applicants: 156,
      status: "active"
    },
    {
      id: 2,
      title: "Finance Professional Program",
      company: "Global Finance Solutions",
      description: "Comprehensive finance career opportunities",
      price: 50,
      currency: "USD",
      estimatedTime: "20 minutes",
      fields: ["Personal Info", "Education", "Finance Experience", "Certifications"],
      benefits: ["CFA preparation resources", "Mentorship program", "Networking events"],
      deadline: "2024-04-30",
      applicants: 89,
      status: "active"
    },
    {
      id: 3,
      title: "Marketing Specialist Track",
      company: "Creative Marketing Agency",
      description: "Creative marketing roles for digital natives",
      price: 30,
      currency: "USD",
      estimatedTime: "12 minutes",
      fields: ["Personal Info", "Education", "Marketing Portfolio", "Campaign Examples"],
      benefits: ["Portfolio review", "Industry insights", "Creative challenges"],
      deadline: "2024-04-20",
      applicants: 112,
      status: "active"
    }
  ];

  const steps = [
    { id: 1, title: "Personal Information", icon: UserPlus },
    { id: 2, title: "Education Details", icon: GraduationCap },
    { id: 3, title: "Work Experience", icon: Building },
    { id: 4, title: "Preferences", icon: CheckCircle },
    { id: 5, title: "Payment", icon: CreditCard }
  ];

  const progress = (currentStep - 1) / (steps.length - 1) * 100;

  const handleNext = () => {
    if (currentStep < steps.length) {
      setCurrentStep(currentStep + 1);
    }
  };

  const handlePrevious = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1);
    }
  };

  return (
    <PlatformLayout
      sidebarTitle="Candidate Platform"
      sidebarSubtitle="Registration Portal"
      sidebarSections={candidateNavigation}
    >
      <div className="min-h-screen bg-gradient-to-br from-cyan-50 via-white to-cyan-50 p-6">
        <div className="max-w-7xl mx-auto space-y-8">
          {/* Header */}
          <div className="text-center space-y-4">
            <div className="inline-flex items-center gap-3 px-6 py-3 bg-cyan-100 rounded-full">
              <div className="w-8 h-8 bg-cyan-500 rounded-full flex items-center justify-center">
                <UserPlus className="w-4 h-4 text-white" />
              </div>
              <span className="text-cyan-800 font-semibold">Candidate Registration Portal</span>
            </div>
            <h1 className="text-4xl font-bold bg-gradient-to-r from-cyan-600 to-cyan-800 bg-clip-text text-transparent">
              Register for Opportunities
            </h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Complete your professional registration to access exclusive job opportunities and career development resources
            </p>
          </div>

          <Tabs defaultValue="forms" className="space-y-6">
            <TabsList className="bg-cyan-100 p-1">
              <TabsTrigger value="forms" className="data-[state=active]:bg-white data-[state=active]:text-cyan-700">
                Available Forms
              </TabsTrigger>
              <TabsTrigger value="register" className="data-[state=active]:bg-white data-[state=active]:text-cyan-700">
                Registration Process
              </TabsTrigger>
              <TabsTrigger value="status" className="data-[state=active]:bg-white data-[state=active]:text-cyan-700">
                Application Status
              </TabsTrigger>
            </TabsList>

            <TabsContent value="forms">
              <div className="grid gap-6">
                {availableForms.map((form) => (
                  <Card key={form.id} className="border-cyan-200 shadow-lg hover:shadow-xl transition-all duration-300">
                    <CardHeader>
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <CardTitle className="text-xl text-cyan-800 flex items-center gap-3">
                            {form.title}
                            <Badge className="bg-green-100 text-green-800">
                              {form.status}
                            </Badge>
                          </CardTitle>
                          <CardDescription className="text-lg mt-2">
                            {form.company} • {form.description}
                          </CardDescription>
                        </div>
                        <div className="text-right">
                          <div className="text-2xl font-bold text-cyan-800">${form.price}</div>
                          <div className="text-sm text-gray-600">{form.currency}</div>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent className="space-y-6">
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                        <div className="space-y-4">
                          <div className="flex items-center gap-3">
                            <div className="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center">
                              <Clock className="w-4 h-4 text-blue-600" />
                            </div>
                            <div>
                              <div className="font-medium text-blue-800">Estimated Time</div>
                              <div className="text-sm text-gray-600">{form.estimatedTime}</div>
                            </div>
                          </div>

                          <div className="flex items-center gap-3">
                            <div className="w-8 h-8 bg-purple-100 rounded-lg flex items-center justify-center">
                              <FileText className="w-4 h-4 text-purple-600" />
                            </div>
                            <div>
                              <div className="font-medium text-purple-800">Application Deadline</div>
                              <div className="text-sm text-gray-600">
                                {new Date(form.deadline).toLocaleDateString()}
                              </div>
                            </div>
                          </div>
                        </div>

                        <div className="space-y-4">
                          <div>
                            <div className="font-medium text-gray-800 mb-2">Required Fields</div>
                            <div className="space-y-1">
                              {form.fields.map((field, index) => (
                                <div key={index} className="text-sm text-gray-600 flex items-center gap-2">
                                  <CheckCircle className="w-3 h-3 text-green-500" />
                                  {field}
                                </div>
                              ))}
                            </div>
                          </div>
                        </div>

                        <div className="space-y-4">
                          <div>
                            <div className="font-medium text-gray-800 mb-2">Benefits Included</div>
                            <div className="space-y-1">
                              {form.benefits.map((benefit, index) => (
                                <div key={index} className="text-sm text-gray-600 flex items-center gap-2">
                                  <CheckCircle className="w-3 h-3 text-cyan-500" />
                                  {benefit}
                                </div>
                              ))}
                            </div>
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center justify-between p-4 bg-cyan-50 rounded-lg">
                        <div className="flex items-center gap-3">
                          <div className="w-10 h-10 bg-cyan-100 rounded-lg flex items-center justify-center">
                            <UserPlus className="w-5 h-5 text-cyan-600" />
                          </div>
                          <div>
                            <div className="font-medium text-cyan-800">{form.applicants} candidates registered</div>
                            <div className="text-sm text-gray-600">High demand opportunity</div>
                          </div>
                        </div>
                        <Button className="bg-cyan-600 hover:bg-cyan-700">
                          Register Now
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="register">
              <Card className="border-cyan-200 shadow-lg">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle className="text-xl text-cyan-800">Registration Process</CardTitle>
                      <CardDescription className="mt-2">
                        Complete all steps to finalize your registration
                      </CardDescription>
                    </div>
                    <div className="text-right">
                      <div className="text-sm text-gray-600">Step {currentStep} of {steps.length}</div>
                      <div className="text-xs text-gray-500">{Math.round(progress)}% complete</div>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="space-y-8">
                  {/* Progress Bar */}
                  <div className="space-y-4">
                    <Progress value={progress} className="h-2" />
                    <div className="flex justify-between">
                      {steps.map((step) => {
                        const StepIcon = step.icon;
                        const isActive = currentStep === step.id;
                        const isCompleted = currentStep > step.id;
                        
                        return (
                          <div key={step.id} className="flex flex-col items-center">
                            <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                              isCompleted ? 'bg-green-500 text-white' :
                              isActive ? 'bg-cyan-500 text-white' :
                              'bg-gray-200 text-gray-500'
                            }`}>
                              {isCompleted ? (
                                <CheckCircle className="w-5 h-5" />
                              ) : (
                                <StepIcon className="w-5 h-5" />
                              )}
                            </div>
                            <div className={`text-xs mt-2 text-center ${
                              isActive ? 'text-cyan-800 font-medium' : 'text-gray-500'
                            }`}>
                              {step.title}
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>

                  {/* Form Content */}
                  <div className="space-y-6">
                    {currentStep === 1 && (
                      <div className="space-y-6">
                        <h3 className="text-lg font-semibold text-cyan-800 flex items-center gap-2">
                          <UserPlus className="w-5 h-5" />
                          Personal Information
                        </h3>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div className="space-y-2">
                            <label className="text-sm font-medium text-gray-700">First Name</label>
                            <Input placeholder="Enter your first name" className="border-cyan-200" />
                          </div>
                          <div className="space-y-2">
                            <label className="text-sm font-medium text-gray-700">Last Name</label>
                            <Input placeholder="Enter your last name" className="border-cyan-200" />
                          </div>
                          <div className="space-y-2">
                            <label className="text-sm font-medium text-gray-700">Email Address</label>
                            <Input type="email" placeholder="your.email@example.com" className="border-cyan-200" />
                          </div>
                          <div className="space-y-2">
                            <label className="text-sm font-medium text-gray-700">Phone Number</label>
                            <Input placeholder="+1 (555) 123-4567" className="border-cyan-200" />
                          </div>
                          <div className="space-y-2">
                            <label className="text-sm font-medium text-gray-700">City</label>
                            <Input placeholder="Your current city" className="border-cyan-200" />
                          </div>
                          <div className="space-y-2">
                            <label className="text-sm font-medium text-gray-700">State/Province</label>
                            <Input placeholder="Your state or province" className="border-cyan-200" />
                          </div>
                        </div>
                      </div>
                    )}

                    {currentStep === 2 && (
                      <div className="space-y-6">
                        <h3 className="text-lg font-semibold text-cyan-800 flex items-center gap-2">
                          <GraduationCap className="w-5 h-5" />
                          Education Details
                        </h3>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div className="space-y-2">
                            <label className="text-sm font-medium text-gray-700">Highest Degree</label>
                            <Select>
                              <SelectTrigger className="border-cyan-200">
                                <SelectValue placeholder="Select your highest degree" />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="bachelors">Bachelor's Degree</SelectItem>
                                <SelectItem value="masters">Master's Degree</SelectItem>
                                <SelectItem value="phd">PhD</SelectItem>
                                <SelectItem value="diploma">Diploma</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                          <div className="space-y-2">
                            <label className="text-sm font-medium text-gray-700">Institution</label>
                            <Input placeholder="University/College name" className="border-cyan-200" />
                          </div>
                          <div className="space-y-2">
                            <label className="text-sm font-medium text-gray-700">Field of Study</label>
                            <Input placeholder="e.g., Computer Science" className="border-cyan-200" />
                          </div>
                          <div className="space-y-2">
                            <label className="text-sm font-medium text-gray-700">Graduation Year</label>
                            <Input placeholder="YYYY" className="border-cyan-200" />
                          </div>
                        </div>
                      </div>
                    )}

                    {currentStep === 3 && (
                      <div className="space-y-6">
                        <h3 className="text-lg font-semibold text-cyan-800 flex items-center gap-2">
                          <Building className="w-5 h-5" />
                          Work Experience
                        </h3>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div className="space-y-2">
                            <label className="text-sm font-medium text-gray-700">Years of Experience</label>
                            <Select>
                              <SelectTrigger className="border-cyan-200">
                                <SelectValue placeholder="Select experience level" />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="0-1">0-1 years</SelectItem>
                                <SelectItem value="1-3">1-3 years</SelectItem>
                                <SelectItem value="3-5">3-5 years</SelectItem>
                                <SelectItem value="5-10">5-10 years</SelectItem>
                                <SelectItem value="10+">10+ years</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                          <div className="space-y-2">
                            <label className="text-sm font-medium text-gray-700">Current Company</label>
                            <Input placeholder="Current employer" className="border-cyan-200" />
                          </div>
                          <div className="space-y-2">
                            <label className="text-sm font-medium text-gray-700">Current Position</label>
                            <Input placeholder="Your current role" className="border-cyan-200" />
                          </div>
                          <div className="space-y-2">
                            <label className="text-sm font-medium text-gray-700">Expected Salary</label>
                            <Input placeholder="$75,000" className="border-cyan-200" />
                          </div>
                        </div>
                        <div className="space-y-2">
                          <label className="text-sm font-medium text-gray-700">Resume Upload</label>
                          <div className="border-2 border-dashed border-cyan-300 rounded-lg p-6 text-center">
                            <Upload className="w-8 h-8 text-cyan-500 mx-auto mb-2" />
                            <div className="text-sm text-gray-600">
                              Drop your resume here or <span className="text-cyan-600 cursor-pointer">browse files</span>
                            </div>
                            <div className="text-xs text-gray-500 mt-1">PDF, DOC, DOCX up to 10MB</div>
                          </div>
                        </div>
                      </div>
                    )}

                    {currentStep === 4 && (
                      <div className="space-y-6">
                        <h3 className="text-lg font-semibold text-cyan-800 flex items-center gap-2">
                          <CheckCircle className="w-5 h-5" />
                          Job Preferences
                        </h3>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div className="space-y-2">
                            <label className="text-sm font-medium text-gray-700">Job Type</label>
                            <Select>
                              <SelectTrigger className="border-cyan-200">
                                <SelectValue placeholder="Select job type" />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="full-time">Full-time</SelectItem>
                                <SelectItem value="part-time">Part-time</SelectItem>
                                <SelectItem value="contract">Contract</SelectItem>
                                <SelectItem value="freelance">Freelance</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                          <div className="space-y-2">
                            <label className="text-sm font-medium text-gray-700">Work Mode</label>
                            <Select>
                              <SelectTrigger className="border-cyan-200">
                                <SelectValue placeholder="Select work mode" />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="remote">Remote</SelectItem>
                                <SelectItem value="hybrid">Hybrid</SelectItem>
                                <SelectItem value="onsite">On-site</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Checkbox id="relocate" />
                          <label htmlFor="relocate" className="text-sm font-medium text-gray-700">
                            I am willing to relocate for the right opportunity
                          </label>
                        </div>
                      </div>
                    )}

                    {currentStep === 5 && (
                      <div className="space-y-6">
                        <h3 className="text-lg font-semibold text-cyan-800 flex items-center gap-2">
                          <CreditCard className="w-5 h-5" />
                          Payment Information
                        </h3>
                        <div className="p-6 bg-cyan-50 rounded-lg border border-cyan-200">
                          <div className="text-center space-y-4">
                            <div className="text-2xl font-bold text-cyan-800">Registration Fee: $25.00</div>
                            <div className="text-gray-600">
                              This one-time fee includes access to premium features and priority placement
                            </div>
                          </div>
                        </div>
                        <div className="space-y-4">
                          <div className="space-y-2">
                            <label className="text-sm font-medium text-gray-700">Card Number</label>
                            <Input placeholder="1234 5678 9012 3456" className="border-cyan-200" />
                          </div>
                          <div className="grid grid-cols-2 gap-4">
                            <div className="space-y-2">
                              <label className="text-sm font-medium text-gray-700">Expiry Date</label>
                              <Input placeholder="MM/YY" className="border-cyan-200" />
                            </div>
                            <div className="space-y-2">
                              <label className="text-sm font-medium text-gray-700">CVV</label>
                              <Input placeholder="123" className="border-cyan-200" />
                            </div>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Navigation Buttons */}
                  <div className="flex justify-between pt-6">
                    <Button 
                      variant="outline" 
                      onClick={handlePrevious}
                      disabled={currentStep === 1}
                      className="border-cyan-200 text-cyan-600"
                    >
                      Previous
                    </Button>
                    <Button 
                      onClick={handleNext}
                      className={`${currentStep === steps.length ? 'bg-green-600 hover:bg-green-700' : 'bg-cyan-600 hover:bg-cyan-700'}`}
                    >
                      {currentStep === steps.length ? 'Complete Registration' : 'Next Step'}
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="status">
              <Card className="border-cyan-200 shadow-lg">
                <CardHeader>
                  <CardTitle className="text-xl text-cyan-800">Application Status</CardTitle>
                  <CardDescription>
                    Track your registration submissions and payments
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                      <div className="flex items-center gap-3">
                        <CheckCircle className="w-5 h-5 text-green-600" />
                        <div>
                          <div className="font-medium text-green-800">Software Developer Registration</div>
                          <div className="text-sm text-gray-600">Completed on March 15, 2024 • Payment processed</div>
                        </div>
                      </div>
                    </div>
                    <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                      <div className="flex items-center gap-3">
                        <Clock className="w-5 h-5 text-yellow-600" />
                        <div>
                          <div className="font-medium text-yellow-800">Marketing Specialist Track</div>
                          <div className="text-sm text-gray-600">In progress • Payment pending</div>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </PlatformLayout>
  );
}