import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Bell, BellRing, Check, CheckCheck, Trash2, Briefcase, Calendar, Trophy, AlertCircle, Info, Star } from "lucide-react";
import { cn } from "@/lib/utils";
import PlatformLayout from "@/components/layout/platform-layout";
import { platformConfigs } from "@/config/complete-navigation";

interface Notification {
  id: string;
  userId: string;
  type: 'job_match' | 'application_status' | 'test_reminder' | 'certification' | 'system' | 'promotion';
  title: string;
  message: string;
  isRead: boolean;
  priority: 'low' | 'medium' | 'high' | 'urgent';
  metadata?: {
    jobId?: string;
    testId?: string;
    applicationId?: string;
    actionUrl?: string;
  };
  createdAt: string;
}

const sampleNotifications: Notification[] = [
  {
    id: "1",
    userId: "user-1749456625601-hn858q09q",
    type: "job_match",
    title: "New Job Match Found!",
    message: "We found 3 new job opportunities matching your React Developer preferences. Check them out now to apply before the deadline.",
    isRead: false,
    priority: "high",
    metadata: {
      actionUrl: "/job-board"
    },
    createdAt: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString()
  },
  {
    id: "2", 
    userId: "user-1749456625601-hn858q09q",
    type: "application_status",
    title: "Application Status Update",
    message: "Your application for Senior Software Engineer at TechCorp has been reviewed. The recruiter wants to schedule an interview with you.",
    isRead: false,
    priority: "urgent",
    metadata: {
      jobId: "1",
      actionUrl: "/job-board"
    },
    createdAt: new Date(Date.now() - 4 * 60 * 60 * 1000).toISOString()
  },
  {
    id: "3",
    userId: "user-1749456625601-hn858q09q", 
    type: "test_reminder",
    title: "Test Attempt Reminder",
    message: "Don't forget to complete your React Fundamentals Assessment. You have 2 days remaining before it expires.",
    isRead: true,
    priority: "medium",
    metadata: {
      testId: "8b92f413-2afc-432b-94bd-e29fb35ecd9b",
      actionUrl: "/tests"
    },
    createdAt: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString()
  },
  {
    id: "4",
    userId: "user-1749456625601-hn858q09q",
    type: "certification",
    title: "Certification Achievement!",
    message: "Congratulations! You've earned the Java Programming Certification with a score of 85%. Your certificate is now available for download.",
    isRead: true,
    priority: "medium",
    metadata: {
      actionUrl: "/profile"
    },
    createdAt: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000).toISOString()
  },
  {
    id: "5",
    userId: "user-1749456625601-hn858q09q",
    type: "system",
    title: "Profile Enhancement Suggestion",
    message: "Complete your Personal Interview to unlock premium job recommendations and increase your profile visibility to recruiters by 75%.",
    isRead: false,
    priority: "low",
    metadata: {
      actionUrl: "/personal-interview"
    },
    createdAt: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString()
  },
  {
    id: "6",
    userId: "user-1749456625601-hn858q09q",
    type: "promotion",
    title: "Weekend Flash Sale!",
    message: "Get 50% off on Premium Subscription this weekend! Unlock unlimited test attempts, priority job matching, and advanced analytics.",
    isRead: false,
    priority: "medium",
    metadata: {
      actionUrl: "/subscription"
    },
    createdAt: new Date(Date.now() - 6 * 60 * 60 * 1000).toISOString()
  }
];

function NotificationsContent() {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [selectedTab, setSelectedTab] = useState("all");

  // Using sample data for now - in production this would fetch from API
  const { data: notifications = sampleNotifications, isLoading } = useQuery({
    queryKey: ["/api/notifications"],
    enabled: !!user,
    initialData: sampleNotifications
  });

  const markAsReadMutation = useMutation({
    mutationFn: async (notificationId: string) => {
      // In production: await apiRequest("PATCH", `/api/notifications/${notificationId}/read`);
      return { success: true };
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/notifications"] });
      toast({
        title: "Notification marked as read",
        duration: 2000,
      });
    }
  });

  const markAllAsReadMutation = useMutation({
    mutationFn: async () => {
      // In production: await apiRequest("PATCH", "/api/notifications/mark-all-read");
      return { success: true };
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/notifications"] });
      toast({
        title: "All notifications marked as read",
        duration: 2000,
      });
    }
  });

  const deleteNotificationMutation = useMutation({
    mutationFn: async (notificationId: string) => {
      // In production: await apiRequest("DELETE", `/api/notifications/${notificationId}`);
      return { success: true };
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/notifications"] });
      toast({
        title: "Notification deleted",
        duration: 2000,
      });
    }
  });

  const getNotificationIcon = (type: string) => {
    switch (type) {
      case 'job_match': return <Briefcase className="h-5 w-5 text-sky-500" />;
      case 'application_status': return <Calendar className="h-5 w-5 text-green-500" />;
      case 'test_reminder': return <AlertCircle className="h-5 w-5 text-orange-500" />;
      case 'certification': return <Trophy className="h-5 w-5 text-yellow-500" />;
      case 'system': return <Info className="h-5 w-5 text-blue-500" />;
      case 'promotion': return <Star className="h-5 w-5 text-purple-500" />;
      default: return <Bell className="h-5 w-5 text-gray-500" />;
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'urgent': return 'bg-red-100 text-red-800 border-red-200';
      case 'high': return 'bg-orange-100 text-orange-800 border-orange-200';
      case 'medium': return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'low': return 'bg-gray-100 text-gray-800 border-gray-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getFilteredNotifications = () => {
    switch (selectedTab) {
      case 'unread': return notifications.filter(n => !n.isRead);
      case 'read': return notifications.filter(n => n.isRead);
      case 'jobs': return notifications.filter(n => n.type === 'job_match' || n.type === 'application_status');
      case 'tests': return notifications.filter(n => n.type === 'test_reminder' || n.type === 'certification');
      default: return notifications;
    }
  };

  const unreadCount = notifications.filter(n => !n.isRead).length;

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="relative">
            <BellRing className="h-8 w-8 text-sky-500" />
            {unreadCount > 0 && (
              <Badge className="absolute -top-2 -right-2 h-6 w-6 rounded-full bg-red-500 text-white text-xs flex items-center justify-center">
                {unreadCount}
              </Badge>
            )}
          </div>
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Notifications</h1>
            <p className="text-gray-600">
              {unreadCount > 0 ? `You have ${unreadCount} unread notifications` : "You're all caught up!"}
            </p>
          </div>
        </div>
        
        {unreadCount > 0 && (
          <Button
            onClick={() => markAllAsReadMutation.mutate()}
            disabled={markAllAsReadMutation.isPending}
            variant="outline"
            className="flex items-center gap-2"
          >
            <CheckCheck className="h-4 w-4" />
            Mark All Read
          </Button>
        )}
      </div>

      {/* Notification Tabs */}
      <Tabs value={selectedTab} onValueChange={setSelectedTab}>
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="all">All ({notifications.length})</TabsTrigger>
          <TabsTrigger value="unread">Unread ({unreadCount})</TabsTrigger>
          <TabsTrigger value="jobs">Jobs</TabsTrigger>
          <TabsTrigger value="tests">Tests</TabsTrigger>
          <TabsTrigger value="read">Read</TabsTrigger>
        </TabsList>

        <TabsContent value={selectedTab} className="space-y-4">
          {getFilteredNotifications().length === 0 ? (
            <Card>
              <CardContent className="flex flex-col items-center justify-center py-16">
                <Bell className="h-12 w-12 text-gray-400 mb-4" />
                <h3 className="text-lg font-semibold text-gray-600 mb-2">No notifications</h3>
                <p className="text-gray-500 text-center">
                  {selectedTab === 'unread' ? "All caught up! No unread notifications." : "No notifications in this category."}
                </p>
              </CardContent>
            </Card>
          ) : (
            getFilteredNotifications().map((notification) => (
              <Card key={notification.id} className={cn(
                "transition-all duration-200 hover:shadow-md border-l-4 bg-white",
                !notification.isRead ? "bg-blue-50 border-l-sky-500" : "bg-white border-l-gray-200"
              )}>
                <CardContent className="p-6">
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex items-start gap-4 flex-1">
                      <div className="mt-1">
                        {getNotificationIcon(notification.type)}
                      </div>
                      
                      <div className="flex-1 space-y-2">
                        <div className="flex items-start justify-between">
                          <h3 className={cn(
                            "font-semibold text-lg",
                            !notification.isRead ? "text-gray-900" : "text-gray-700"
                          )}>
                            {notification.title}
                          </h3>
                          <div className="flex items-center gap-2">
                            <Badge className={getPriorityColor(notification.priority)}>
                              {notification.priority}
                            </Badge>
                            {!notification.isRead && (
                              <div className="w-3 h-3 bg-sky-500 rounded-full"></div>
                            )}
                          </div>
                        </div>
                        
                        <p className="text-gray-600 leading-relaxed">
                          {notification.message}
                        </p>
                        
                        <div className="flex items-center justify-between mt-4">
                          <span className="text-sm text-gray-500">
                            {new Date(notification.createdAt).toLocaleString()}
                          </span>
                          
                          <div className="flex items-center gap-2">
                            {notification.metadata?.actionUrl && (
                              <Button
                                size="sm"
                                className="bg-sky-500 hover:bg-sky-600 text-white"
                                onClick={() => window.location.href = notification.metadata.actionUrl}
                              >
                                Take Action
                              </Button>
                            )}
                            
                            {!notification.isRead && (
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => markAsReadMutation.mutate(notification.id)}
                                disabled={markAsReadMutation.isPending}
                              >
                                <Check className="h-4 w-4" />
                              </Button>
                            )}
                            
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => deleteNotificationMutation.mutate(notification.id)}
                              disabled={deleteNotificationMutation.isPending}
                              className="text-red-600 hover:text-red-700 hover:bg-red-50"
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}

export default function Notifications() {
  const config = platformConfigs.candidate;
  
  const usageData = [
    { label: "Unread Notifications", current: 7, max: 50 },
    { label: "Alert Settings", current: 85, max: 100 },
    { label: "Email Frequency", current: 3, max: 7 },
  ];

  return (
    <PlatformLayout
      sidebarTitle={config.sidebarTitle}
      sidebarSubtitle={config.sidebarSubtitle}
      sidebarSections={config.sidebarSections}
      usageData={usageData}
    >
      <NotificationsContent />
    </PlatformLayout>
  );
}