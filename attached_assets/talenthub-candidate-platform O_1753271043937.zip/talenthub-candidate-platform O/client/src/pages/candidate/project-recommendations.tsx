import PlatformLayout from "@/components/layout/platform-layout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { Lightbulb, Search, Brain, Target, Star, Clock, Users, TrendingUp, Code, Globe, Database, Smartphone, Zap, BookOpen } from "lucide-react";
import { platformConfigs } from "@/config/complete-navigation";

export default function ProjectRecommendations() {
  const config = platformConfigs.candidate;

  const recommendations = [
    {
      id: 1,
      title: "Real-time Chat Application",
      description: "Build a modern chat app with WebSocket integration, user authentication, and message persistence",
      difficulty: "Intermediate",
      estimatedTime: "3-4 weeks",
      technologies: ["React", "Node.js", "Socket.io", "MongoDB"],
      category: "Full-Stack",
      matchScore: 95,
      reasons: ["Matches your React skills", "Builds on your Node.js experience", "Introduces real-time concepts"],
      learningGoals: ["WebSocket communication", "Real-time state management", "Database optimization"],
      marketDemand: "High",
      color: "from-blue-500 to-indigo-500",
      icon: Globe,
      trending: true
    },
    {
      id: 2,
      title: "Machine Learning Dashboard",
      description: "Create an interactive dashboard for ML model visualization and data analysis",
      difficulty: "Advanced",
      estimatedTime: "4-5 weeks",
      technologies: ["Python", "FastAPI", "React", "D3.js", "TensorFlow"],
      category: "AI/ML",
      matchScore: 88,
      reasons: ["Growing AI/ML market", "Combines frontend and data skills", "High industry demand"],
      learningGoals: ["ML model integration", "Data visualization", "Python web frameworks"],
      marketDemand: "Very High",
      color: "from-purple-500 to-pink-500",
      icon: Brain,
      trending: true
    },
    {
      id: 3,
      title: "E-commerce Mobile App",
      description: "Develop a cross-platform mobile e-commerce application with payment integration",
      difficulty: "Intermediate",
      estimatedTime: "5-6 weeks",
      technologies: ["React Native", "Expo", "Stripe", "Firebase"],
      category: "Mobile",
      matchScore: 82,
      reasons: ["Mobile development is growing", "E-commerce skills are valuable", "Payment integration experience"],
      learningGoals: ["Mobile UI/UX patterns", "Payment processing", "Cross-platform development"],
      marketDemand: "High",
      color: "from-orange-500 to-red-500",
      icon: Smartphone,
      trending: false
    },
    {
      id: 4,
      title: "DevOps Automation Pipeline",
      description: "Build a complete CI/CD pipeline with Docker, Kubernetes, and automated testing",
      difficulty: "Advanced",
      estimatedTime: "6-8 weeks",
      technologies: ["Docker", "Kubernetes", "Jenkins", "AWS", "Terraform"],
      category: "DevOps",
      matchScore: 78,
      reasons: ["DevOps skills are in demand", "Complements development skills", "Career advancement opportunity"],
      learningGoals: ["Infrastructure as Code", "Container orchestration", "Cloud deployment"],
      marketDemand: "Very High",
      color: "from-green-500 to-emerald-500",
      icon: Zap,
      trending: true
    },
    {
      id: 5,
      title: "Blockchain Voting System",
      description: "Create a secure voting system using blockchain technology and smart contracts",
      difficulty: "Expert",
      estimatedTime: "7-9 weeks",
      technologies: ["Solidity", "Web3.js", "React", "Ethereum", "IPFS"],
      category: "Blockchain",
      matchScore: 72,
      reasons: ["Emerging technology", "Unique portfolio piece", "High technical complexity"],
      learningGoals: ["Smart contract development", "Blockchain concepts", "Decentralized applications"],
      marketDemand: "Growing",
      color: "from-yellow-500 to-orange-500",
      icon: Target,
      trending: false
    },
    {
      id: 6,
      title: "Educational Platform API",
      description: "Design and implement a comprehensive API for an online learning management system",
      difficulty: "Intermediate",
      estimatedTime: "4-5 weeks",
      technologies: ["Node.js", "Express", "PostgreSQL", "Redis", "GraphQL"],
      category: "Backend",
      matchScore: 86,
      reasons: ["Education sector growth", "API design skills", "Database optimization experience"],
      learningGoals: ["API architecture", "GraphQL implementation", "Performance optimization"],
      marketDemand: "High",
      color: "from-cyan-500 to-blue-500",
      icon: Database,
      trending: false
    }
  ];

  const skillGaps = [
    { skill: "TypeScript", importance: "High", currentLevel: 60, targetLevel: 85 },
    { skill: "System Design", importance: "High", currentLevel: 40, targetLevel: 75 },
    { skill: "DevOps", importance: "Medium", currentLevel: 30, targetLevel: 70 },
    { skill: "Testing", importance: "High", currentLevel: 55, targetLevel: 80 },
    { skill: "AI/ML", importance: "Medium", currentLevel: 25, targetLevel: 65 }
  ];

  const getMatchColor = (score: number) => {
    if (score >= 90) return "text-green-600";
    if (score >= 80) return "text-blue-600";
    if (score >= 70) return "text-orange-600";
    return "text-gray-600";
  };

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case "Beginner": return "bg-green-100 text-green-800 border-green-200";
      case "Intermediate": return "bg-yellow-100 text-yellow-800 border-yellow-200";
      case "Advanced": return "bg-orange-100 text-orange-800 border-orange-200";
      case "Expert": return "bg-red-100 text-red-800 border-red-200";
      default: return "bg-gray-100 text-gray-800 border-gray-200";
    }
  };

  const getMarketDemandColor = (demand: string) => {
    switch (demand) {
      case "Very High": return "bg-green-100 text-green-800 border-green-200";
      case "High": return "bg-blue-100 text-blue-800 border-blue-200";
      case "Growing": return "bg-purple-100 text-purple-800 border-purple-200";
      default: return "bg-gray-100 text-gray-800 border-gray-200";
    }
  };

  return (
    <PlatformLayout
      sidebarTitle={config.sidebarTitle}
      sidebarSubtitle={config.sidebarSubtitle}
      sidebarSections={config.sidebarSections}
      usageData={config.usageData}
    >
      <div className="p-6 max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="text-center space-y-4">
          <div className="flex items-center justify-center space-x-3">
            <div className="p-3 bg-gradient-to-r from-purple-500 to-blue-500 rounded-full">
              <Lightbulb className="h-8 w-8 text-white" />
            </div>
            <h1 className="text-4xl font-bold bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent">
              Project Recommendations
            </h1>
          </div>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            AI-powered project suggestions tailored to your skills, goals, and market trends
          </p>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card className="bg-gradient-to-r from-purple-50 to-blue-50 border-purple-200">
            <CardContent className="p-4 text-center">
              <Lightbulb className="h-8 w-8 text-purple-500 mx-auto mb-2" />
              <p className="text-2xl font-bold text-purple-600">6</p>
              <p className="text-sm text-muted-foreground">Recommendations</p>
            </CardContent>
          </Card>
          <Card className="bg-gradient-to-r from-green-50 to-emerald-50 border-green-200">
            <CardContent className="p-4 text-center">
              <TrendingUp className="h-8 w-8 text-green-500 mx-auto mb-2" />
              <p className="text-2xl font-bold text-green-600">3</p>
              <p className="text-sm text-muted-foreground">Trending Projects</p>
            </CardContent>
          </Card>
          <Card className="bg-gradient-to-r from-blue-50 to-indigo-50 border-blue-200">
            <CardContent className="p-4 text-center">
              <Target className="h-8 w-8 text-blue-500 mx-auto mb-2" />
              <p className="text-2xl font-bold text-blue-600">85%</p>
              <p className="text-sm text-muted-foreground">Avg. Match Score</p>
            </CardContent>
          </Card>
          <Card className="bg-gradient-to-r from-orange-50 to-red-50 border-orange-200">
            <CardContent className="p-4 text-center">
              <Brain className="h-8 w-8 text-orange-500 mx-auto mb-2" />
              <p className="text-2xl font-bold text-orange-600">5</p>
              <p className="text-sm text-muted-foreground">Skill Gaps Identified</p>
            </CardContent>
          </Card>
        </div>

        {/* Search and Filters */}
        <div className="flex flex-col sm:flex-row gap-4 items-center justify-between">
          <div className="flex items-center space-x-2 flex-1">
            <div className="relative flex-1 max-w-md">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
              <Input
                placeholder="Search recommendations..."
                className="pl-10"
              />
            </div>
          </div>
          <div className="flex items-center space-x-2">
            <Select defaultValue="all">
              <SelectTrigger className="w-40">
                <SelectValue placeholder="Category" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Categories</SelectItem>
                <SelectItem value="frontend">Frontend</SelectItem>
                <SelectItem value="backend">Backend</SelectItem>
                <SelectItem value="fullstack">Full-Stack</SelectItem>
                <SelectItem value="mobile">Mobile</SelectItem>
                <SelectItem value="ai">AI/ML</SelectItem>
                <SelectItem value="devops">DevOps</SelectItem>
              </SelectContent>
            </Select>
            <Select defaultValue="match">
              <SelectTrigger className="w-40">
                <SelectValue placeholder="Sort by" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="match">Best Match</SelectItem>
                <SelectItem value="trending">Trending</SelectItem>
                <SelectItem value="demand">Market Demand</SelectItem>
                <SelectItem value="difficulty">Difficulty</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <Tabs defaultValue="recommendations" className="space-y-6">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="recommendations">AI Recommendations</TabsTrigger>
            <TabsTrigger value="gaps">Skill Gap Analysis</TabsTrigger>
            <TabsTrigger value="trends">Market Trends</TabsTrigger>
          </TabsList>

          <TabsContent value="recommendations" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {recommendations.map((rec) => {
                const IconComponent = rec.icon;
                return (
                  <Card key={rec.id} className="group hover:shadow-lg transition-all duration-300 hover:-translate-y-1 border-l-4 border-l-purple-500">
                    <CardHeader className="pb-3">
                      <div className="flex items-start justify-between">
                        <div className={`p-2 bg-gradient-to-r ${rec.color} rounded-lg`}>
                          <IconComponent className="h-6 w-6 text-white" />
                        </div>
                        <div className="flex gap-2">
                          {rec.trending && (
                            <Badge className="bg-green-100 text-green-800 border-green-200">
                              <TrendingUp className="h-3 w-3 mr-1" />
                              Trending
                            </Badge>
                          )}
                          <Badge className={getDifficultyColor(rec.difficulty)}>
                            {rec.difficulty}
                          </Badge>
                        </div>
                      </div>
                      <CardTitle className="text-xl">{rec.title}</CardTitle>
                      <CardDescription>{rec.description}</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-medium">AI Match Score</span>
                        <span className={`text-lg font-bold ${getMatchColor(rec.matchScore)}`}>
                          {rec.matchScore}%
                        </span>
                      </div>
                      <Progress value={rec.matchScore} className="h-2" />

                      <div className="grid grid-cols-2 gap-4 text-sm text-muted-foreground">
                        <div className="flex items-center gap-1">
                          <Clock className="h-4 w-4" />
                          <span>{rec.estimatedTime}</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <Target className="h-4 w-4" />
                          <span>{rec.category}</span>
                        </div>
                      </div>

                      <div className="space-y-3">
                        <div>
                          <h4 className="text-sm font-medium mb-2">Technologies</h4>
                          <div className="flex flex-wrap gap-1">
                            {rec.technologies.map((tech, index) => (
                              <Badge key={index} variant="outline" className="text-xs">
                                {tech}
                              </Badge>
                            ))}
                          </div>
                        </div>

                        <div>
                          <h4 className="text-sm font-medium mb-2">Why Recommended</h4>
                          <ul className="space-y-1">
                            {rec.reasons.slice(0, 2).map((reason, index) => (
                              <li key={index} className="flex items-start gap-2 text-xs text-muted-foreground">
                                <div className="w-1 h-1 bg-purple-500 rounded-full mt-2" />
                                {reason}
                              </li>
                            ))}
                          </ul>
                        </div>

                        <div>
                          <h4 className="text-sm font-medium mb-2">Learning Goals</h4>
                          <div className="flex flex-wrap gap-1">
                            {rec.learningGoals.slice(0, 2).map((goal, index) => (
                              <Badge key={index} variant="outline" className="text-xs bg-purple-50 text-purple-700 border-purple-200">
                                {goal}
                              </Badge>
                            ))}
                          </div>
                        </div>

                        <div className="flex items-center justify-between">
                          <span className="text-sm font-medium">Market Demand</span>
                          <Badge className={getMarketDemandColor(rec.marketDemand)}>
                            {rec.marketDemand}
                          </Badge>
                        </div>
                      </div>

                      <div className="flex items-center gap-2 pt-2">
                        <Button className="flex-1 bg-gradient-to-r from-purple-500 to-blue-500 hover:from-purple-600 hover:to-blue-600">
                          <Code className="h-4 w-4 mr-2" />
                          Start Project
                        </Button>
                        <Button variant="outline">
                          <BookOpen className="h-4 w-4" />
                        </Button>
                        <Button variant="outline">
                          <Star className="h-4 w-4" />
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </TabsContent>

          <TabsContent value="gaps" className="space-y-6">
            <h3 className="text-xl font-bold text-purple-700">Skill Gap Analysis</h3>
            
            <Card>
              <CardHeader>
                <CardTitle>Recommended Skills to Develop</CardTitle>
                <CardDescription>Based on market demand and your career goals</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  {skillGaps.map((gap, index) => (
                    <div key={index} className="space-y-3">
                      <div className="flex items-center justify-between">
                        <div>
                          <h4 className="font-medium">{gap.skill}</h4>
                          <p className="text-sm text-muted-foreground">Importance: {gap.importance}</p>
                        </div>
                        <div className="text-right">
                          <div className="text-sm font-medium">{gap.currentLevel}% → {gap.targetLevel}%</div>
                          <div className="text-xs text-muted-foreground">Current → Target</div>
                        </div>
                      </div>
                      <div className="space-y-2">
                        <div className="flex justify-between text-xs text-muted-foreground">
                          <span>Current Level</span>
                          <span>Target Level</span>
                        </div>
                        <div className="relative">
                          <Progress value={gap.targetLevel} className="h-2 bg-gray-200" />
                          <Progress 
                            value={gap.currentLevel} 
                            className="h-2 absolute top-0 left-0" 
                          />
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="trends" className="space-y-6">
            <h3 className="text-xl font-bold text-purple-700">Technology & Market Trends</h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Trending Technologies</CardTitle>
                  <CardDescription>Most in-demand skills this quarter</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {[
                      { tech: "AI/ML", growth: "+45%", demand: "Very High" },
                      { tech: "React/Next.js", growth: "+28%", demand: "High" },
                      { tech: "DevOps/Cloud", growth: "+35%", demand: "Very High" },
                      { tech: "TypeScript", growth: "+22%", demand: "High" },
                      { tech: "Blockchain", growth: "+15%", demand: "Growing" }
                    ].map((item, index) => (
                      <div key={index} className="flex items-center justify-between">
                        <span className="font-medium">{item.tech}</span>
                        <div className="text-right">
                          <div className="text-sm font-medium text-green-600">{item.growth}</div>
                          <div className="text-xs text-muted-foreground">{item.demand}</div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Industry Insights</CardTitle>
                  <CardDescription>Key trends shaping the market</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="p-3 bg-blue-50 border border-blue-200 rounded-lg">
                      <h4 className="font-medium text-blue-800">Remote Work Acceleration</h4>
                      <p className="text-sm text-blue-600">Cloud and collaboration tools see 40% growth</p>
                    </div>
                    <div className="p-3 bg-green-50 border border-green-200 rounded-lg">
                      <h4 className="font-medium text-green-800">AI Integration Boom</h4>
                      <p className="text-sm text-green-600">Companies investing heavily in AI capabilities</p>
                    </div>
                    <div className="p-3 bg-purple-50 border border-purple-200 rounded-lg">
                      <h4 className="font-medium text-purple-800">Security Focus</h4>
                      <p className="text-sm text-purple-600">Cybersecurity skills increasingly critical</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </PlatformLayout>
  );
}