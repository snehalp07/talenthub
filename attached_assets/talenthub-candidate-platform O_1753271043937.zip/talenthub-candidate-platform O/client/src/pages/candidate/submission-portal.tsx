import PlatformLayout from "@/components/layout/platform-layout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { ArrowUp, FileText, Github, Globe, Clock, CheckCircle, AlertCircle, Calendar, Star, Trophy, Code, Upload, Link } from "lucide-react";
import { platformConfigs } from "@/config/complete-navigation";

export default function SubmissionPortal() {
  const config = platformConfigs.candidate;

  const submissionTypes = [
    {
      id: "project",
      name: "Project Submission",
      description: "Submit completed projects for certification review",
      icon: Code,
      color: "from-blue-500 to-indigo-500",
      requirements: ["GitHub repository", "Live demo", "Documentation", "Test coverage"]
    },
    {
      id: "challenge",
      name: "Challenge Submission",
      description: "Submit challenge solutions and implementations",
      icon: Trophy,
      color: "from-orange-500 to-red-500",
      requirements: ["Solution code", "Explanation", "Performance metrics", "Edge cases"]
    },
    {
      id: "portfolio",
      name: "Portfolio Review",
      description: "Submit portfolio for expert evaluation",
      icon: Star,
      color: "from-purple-500 to-pink-500",
      requirements: ["Portfolio website", "Project showcase", "Technical skills", "Experience summary"]
    }
  ];

  const recentSubmissions = [
    {
      id: 1,
      title: "E-commerce React Application",
      type: "Project Submission",
      submittedAt: "2024-02-15",
      status: "under-review",
      reviewer: "Sarah Johnson",
      estimatedReview: "3-5 days",
      feedback: null,
      score: null
    },
    {
      id: 2,
      title: "API Building Marathon - Day 7",
      type: "Challenge Submission",
      submittedAt: "2024-02-12",
      status: "approved",
      reviewer: "Michael Chen",
      estimatedReview: null,
      feedback: "Excellent implementation with proper error handling and documentation.",
      score: 95
    },
    {
      id: 3,
      title: "Full-Stack Developer Portfolio",
      type: "Portfolio Review",
      submittedAt: "2024-02-10",
      status: "needs-revision",
      reviewer: "Emily Rodriguez",
      estimatedReview: null,
      feedback: "Good project diversity, but needs more detailed technical documentation.",
      score: 78
    }
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case "approved": return "bg-green-100 text-green-800 border-green-200";
      case "under-review": return "bg-blue-100 text-blue-800 border-blue-200";
      case "needs-revision": return "bg-orange-100 text-orange-800 border-orange-200";
      case "rejected": return "bg-red-100 text-red-800 border-red-200";
      default: return "bg-gray-100 text-gray-800 border-gray-200";
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "approved": return <CheckCircle className="h-4 w-4" />;
      case "under-review": return <Clock className="h-4 w-4" />;
      case "needs-revision": return <AlertCircle className="h-4 w-4" />;
      case "rejected": return <AlertCircle className="h-4 w-4" />;
      default: return <Clock className="h-4 w-4" />;
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case "approved": return "Approved";
      case "under-review": return "Under Review";
      case "needs-revision": return "Needs Revision";
      case "rejected": return "Rejected";
      default: return "Unknown";
    }
  };

  return (
    <PlatformLayout
      sidebarTitle={config.sidebarTitle}
      sidebarSubtitle={config.sidebarSubtitle}
      sidebarSections={config.sidebarSections}
      usageData={config.usageData}
    >
      <div className="p-6 max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="text-center space-y-4">
          <div className="flex items-center justify-center space-x-3">
            <div className="p-3 bg-gradient-to-r from-green-500 to-emerald-500 rounded-full">
              <ArrowUp className="h-8 w-8 text-white" />
            </div>
            <h1 className="text-4xl font-bold bg-gradient-to-r from-green-600 to-emerald-600 bg-clip-text text-transparent">
              Submission Portal
            </h1>
          </div>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Submit your projects, challenges, and portfolios for expert review and certification
          </p>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card className="bg-gradient-to-r from-green-50 to-emerald-50 border-green-200">
            <CardContent className="p-4 text-center">
              <ArrowUp className="h-8 w-8 text-green-500 mx-auto mb-2" />
              <p className="text-2xl font-bold text-green-600">3</p>
              <p className="text-sm text-muted-foreground">Total Submissions</p>
            </CardContent>
          </Card>
          <Card className="bg-gradient-to-r from-blue-50 to-indigo-50 border-blue-200">
            <CardContent className="p-4 text-center">
              <Clock className="h-8 w-8 text-blue-500 mx-auto mb-2" />
              <p className="text-2xl font-bold text-blue-600">1</p>
              <p className="text-sm text-muted-foreground">Under Review</p>
            </CardContent>
          </Card>
          <Card className="bg-gradient-to-r from-purple-50 to-pink-50 border-purple-200">
            <CardContent className="p-4 text-center">
              <CheckCircle className="h-8 w-8 text-purple-500 mx-auto mb-2" />
              <p className="text-2xl font-bold text-purple-600">1</p>
              <p className="text-sm text-muted-foreground">Approved</p>
            </CardContent>
          </Card>
          <Card className="bg-gradient-to-r from-orange-50 to-red-50 border-orange-200">
            <CardContent className="p-4 text-center">
              <Star className="h-8 w-8 text-orange-500 mx-auto mb-2" />
              <p className="text-2xl font-bold text-orange-600">86</p>
              <p className="text-sm text-muted-foreground">Avg. Score</p>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="submit" className="space-y-6">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="submit">New Submission</TabsTrigger>
            <TabsTrigger value="history">Submission History</TabsTrigger>
            <TabsTrigger value="guidelines">Guidelines</TabsTrigger>
          </TabsList>

          <TabsContent value="submit" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
              {submissionTypes.map((type) => {
                const IconComponent = type.icon;
                return (
                  <Card key={type.id} className="group hover:shadow-lg transition-all duration-300 hover:-translate-y-1 cursor-pointer border-l-4 border-l-green-500">
                    <CardHeader className="pb-3">
                      <div className={`p-2 bg-gradient-to-r ${type.color} rounded-lg w-fit`}>
                        <IconComponent className="h-6 w-6 text-white" />
                      </div>
                      <CardTitle className="text-lg">{type.name}</CardTitle>
                      <CardDescription>{type.description}</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-3">
                        <h4 className="text-sm font-medium">Requirements:</h4>
                        <ul className="space-y-1">
                          {type.requirements.map((req, index) => (
                            <li key={index} className="flex items-center gap-2 text-xs text-muted-foreground">
                              <CheckCircle className="h-3 w-3 text-green-500" />
                              {req}
                            </li>
                          ))}
                        </ul>
                        <Button className="w-full mt-4 bg-gradient-to-r from-green-500 to-emerald-500 hover:from-green-600 hover:to-emerald-600">
                          Start Submission
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>

            <Card>
              <CardHeader>
                <CardTitle>Project Submission Form</CardTitle>
                <CardDescription>Submit your project for certification review</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Project Title</label>
                    <Input placeholder="My Awesome Project" />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Submission Type</label>
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="Select type" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="project">Project Submission</SelectItem>
                        <SelectItem value="challenge">Challenge Submission</SelectItem>
                        <SelectItem value="portfolio">Portfolio Review</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium">Project Description</label>
                  <Textarea 
                    placeholder="Describe your project, technologies used, and key features..."
                    className="min-h-[100px]"
                  />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className="text-sm font-medium">GitHub Repository</label>
                    <div className="relative">
                      <Github className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                      <Input placeholder="https://github.com/username/project" className="pl-10" />
                    </div>
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Live Demo URL</label>
                    <div className="relative">
                      <Globe className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                      <Input placeholder="https://myproject.vercel.app" className="pl-10" />
                    </div>
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium">Additional Documentation</label>
                  <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center">
                    <Upload className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                    <p className="text-sm text-muted-foreground mb-2">
                      Drop files here or click to upload
                    </p>
                    <p className="text-xs text-muted-foreground">
                      Supports: PDF, DOC, ZIP (Max 10MB)
                    </p>
                    <Button variant="outline" className="mt-4">
                      Choose Files
                    </Button>
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium">Technical Notes</label>
                  <Textarea 
                    placeholder="Any additional technical details, challenges faced, or special features to highlight..."
                    className="min-h-[80px]"
                  />
                </div>

                <div className="flex gap-4">
                  <Button className="flex-1 bg-gradient-to-r from-green-500 to-emerald-500 hover:from-green-600 hover:to-emerald-600">
                    <ArrowUp className="h-4 w-4 mr-2" />
                    Submit for Review
                  </Button>
                  <Button variant="outline">
                    Save Draft
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="history" className="space-y-6">
            <h3 className="text-xl font-bold text-green-700">Submission History</h3>
            
            <div className="space-y-4">
              {recentSubmissions.map((submission) => (
                <Card key={submission.id} className="hover:shadow-md transition-shadow">
                  <CardContent className="p-6">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-3 mb-2">
                          <h4 className="font-semibold text-lg">{submission.title}</h4>
                          <Badge className={getStatusColor(submission.status)}>
                            {getStatusIcon(submission.status)}
                            <span className="ml-1">{getStatusText(submission.status)}</span>
                          </Badge>
                        </div>
                        
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm text-muted-foreground mb-3">
                          <div className="flex items-center gap-1">
                            <FileText className="h-4 w-4" />
                            <span>{submission.type}</span>
                          </div>
                          <div className="flex items-center gap-1">
                            <Calendar className="h-4 w-4" />
                            <span>Submitted {submission.submittedAt}</span>
                          </div>
                          <div className="flex items-center gap-1">
                            <Star className="h-4 w-4" />
                            <span>Reviewer: {submission.reviewer}</span>
                          </div>
                        </div>

                        {submission.feedback && (
                          <div className="bg-gray-50 p-3 rounded-lg mb-3">
                            <h5 className="text-sm font-medium mb-1">Reviewer Feedback:</h5>
                            <p className="text-sm text-muted-foreground">{submission.feedback}</p>
                          </div>
                        )}

                        {submission.estimatedReview && (
                          <div className="text-sm text-blue-600">
                            Estimated review time: {submission.estimatedReview}
                          </div>
                        )}
                      </div>

                      <div className="text-right">
                        {submission.score && (
                          <div className="mb-2">
                            <div className="text-2xl font-bold text-green-600">{submission.score}%</div>
                            <div className="text-xs text-muted-foreground">Score</div>
                          </div>
                        )}
                        <div className="flex gap-2">
                          <Button size="sm" variant="outline">
                            View Details
                          </Button>
                          {submission.status === "needs-revision" && (
                            <Button size="sm" className="bg-green-500 hover:bg-green-600">
                              Resubmit
                            </Button>
                          )}
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="guidelines" className="space-y-6">
            <h3 className="text-xl font-bold text-green-700">Submission Guidelines</h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <CheckCircle className="h-5 w-5 text-green-500" />
                    Best Practices
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-3 text-sm">
                    <li className="flex items-start gap-2">
                      <div className="w-2 h-2 bg-green-500 rounded-full mt-2" />
                      <span>Ensure your code is well-documented and follows best practices</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <div className="w-2 h-2 bg-green-500 rounded-full mt-2" />
                      <span>Include comprehensive README with setup instructions</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <div className="w-2 h-2 bg-green-500 rounded-full mt-2" />
                      <span>Provide working live demo with all features functional</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <div className="w-2 h-2 bg-green-500 rounded-full mt-2" />
                      <span>Test your application thoroughly before submission</span>
                    </li>
                  </ul>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <AlertCircle className="h-5 w-5 text-orange-500" />
                    Common Issues
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-3 text-sm">
                    <li className="flex items-start gap-2">
                      <div className="w-2 h-2 bg-orange-500 rounded-full mt-2" />
                      <span>Broken or inaccessible demo links</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <div className="w-2 h-2 bg-orange-500 rounded-full mt-2" />
                      <span>Missing or incomplete documentation</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <div className="w-2 h-2 bg-orange-500 rounded-full mt-2" />
                      <span>Code without proper error handling</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <div className="w-2 h-2 bg-orange-500 rounded-full mt-2" />
                      <span>Insufficient technical explanation</span>
                    </li>
                  </ul>
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardHeader>
                <CardTitle>Review Process</CardTitle>
                <CardDescription>How submissions are evaluated</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center gap-4">
                    <div className="w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center text-white font-bold text-sm">1</div>
                    <div>
                      <h4 className="font-medium">Initial Review (1-2 days)</h4>
                      <p className="text-sm text-muted-foreground">Basic requirements and functionality check</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-4">
                    <div className="w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center text-white font-bold text-sm">2</div>
                    <div>
                      <h4 className="font-medium">Technical Evaluation (3-5 days)</h4>
                      <p className="text-sm text-muted-foreground">Code quality, architecture, and best practices assessment</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-4">
                    <div className="w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center text-white font-bold text-sm">3</div>
                    <div>
                      <h4 className="font-medium">Final Review (1-2 days)</h4>
                      <p className="text-sm text-muted-foreground">Overall scoring and certification decision</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </PlatformLayout>
  );
}