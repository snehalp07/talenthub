import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import PlatformLayout from "@/components/layout/platform-layout";
import { candidateNavigation } from "@/config/complete-navigation";
import { 
  Cloud, Play, CheckCircle, Award, Target, TrendingUp, 
  Star, Clock, Code, Users, Zap, BookOpen, Trophy,
  ArrowRight, Database, Server, Shield, Globe,
  GitBranch, Container, Settings
} from "lucide-react";

const DevOpsCertification: React.FC = () => {
  const [selectedPath, setSelectedPath] = useState('aws');

  const devOpsPaths = [
    {
      id: 'aws',
      name: 'AWS DevOps',
      description: 'Amazon Web Services Cloud Infrastructure',
      icon: Cloud,
      color: 'from-orange-500 to-red-500',
      duration: '12-16 weeks',
      enrolled: 9840,
      completion: 42,
      rating: 4.8,
      modules: [
        { name: 'AWS Fundamentals', status: 'completed', progress: 100, difficulty: 'Foundation' },
        { name: 'EC2 & Auto Scaling', status: 'completed', progress: 100, difficulty: 'Intermediate' },
        { name: 'Docker & Containers', status: 'current', progress: 65, difficulty: 'Intermediate' },
        { name: 'Kubernetes Orchestration', status: 'locked', progress: 0, difficulty: 'Advanced' },
        { name: 'CI/CD Pipelines', status: 'locked', progress: 0, difficulty: 'Advanced' },
        { name: 'Monitoring & Logging', status: 'locked', progress: 0, difficulty: 'Expert' }
      ]
    },
    {
      id: 'docker',
      name: 'Docker & Kubernetes',
      description: 'Container Orchestration & Management',
      icon: Container,
      color: 'from-blue-500 to-cyan-500',
      duration: '8-12 weeks',
      enrolled: 12560,
      completion: 28,
      rating: 4.7,
      modules: [
        { name: 'Docker Fundamentals', status: 'current', progress: 45, difficulty: 'Foundation' },
        { name: 'Container Networks', status: 'locked', progress: 0, difficulty: 'Intermediate' },
        { name: 'Kubernetes Basics', status: 'locked', progress: 0, difficulty: 'Intermediate' },
        { name: 'Pod Management', status: 'locked', progress: 0, difficulty: 'Advanced' },
        { name: 'Service Mesh', status: 'locked', progress: 0, difficulty: 'Expert' },
        { name: 'Production Deployment', status: 'locked', progress: 0, difficulty: 'Expert' }
      ]
    },
    {
      id: 'cicd',
      name: 'CI/CD Specialist',
      description: 'Continuous Integration & Deployment',
      icon: GitBranch,
      color: 'from-green-500 to-emerald-500',
      duration: '6-10 weeks',
      enrolled: 7230,
      completion: 15,
      rating: 4.6,
      modules: [
        { name: 'Git & Version Control', status: 'not-started', progress: 0, difficulty: 'Foundation' },
        { name: 'Jenkins Automation', status: 'not-started', progress: 0, difficulty: 'Intermediate' },
        { name: 'GitHub Actions', status: 'not-started', progress: 0, difficulty: 'Intermediate' },
        { name: 'Testing Automation', status: 'not-started', progress: 0, difficulty: 'Advanced' },
        { name: 'Deployment Strategies', status: 'not-started', progress: 0, difficulty: 'Advanced' },
        { name: 'Infrastructure as Code', status: 'not-started', progress: 0, difficulty: 'Expert' }
      ]
    }
  ];

  const cloudProviders = [
    { name: 'AWS', market: 85, learning: 70, jobs: 90, color: 'bg-orange-500' },
    { name: 'Azure', market: 75, learning: 80, jobs: 85, color: 'bg-blue-500' },
    { name: 'GCP', market: 60, learning: 85, jobs: 70, color: 'bg-green-500' }
  ];

  const practicalLabs = [
    { name: 'Microservices Deployment', status: 'completed', score: 88, duration: '4 hours' },
    { name: 'Auto-Scaling Setup', status: 'current', score: 0, duration: '3 hours' },
    { name: 'CI/CD Pipeline Build', status: 'upcoming', score: 0, duration: '5 hours' },
    { name: 'Monitoring Dashboard', status: 'upcoming', score: 0, duration: '4 hours' }
  ];

  const certificationBadges = [
    { name: 'Container Expert', earned: true, icon: Container },
    { name: 'Cloud Architect', earned: true, icon: Cloud },
    { name: 'Pipeline Master', earned: false, icon: GitBranch },
    { name: 'Security Specialist', earned: false, icon: Shield },
    { name: 'Monitoring Pro', earned: false, icon: TrendingUp }
  ];

  const selectedPathData = devOpsPaths.find(path => path.id === selectedPath);

  return (
    <PlatformLayout
      sidebarTitle="Candidate Platform"
      sidebarSubtitle="Interview Preparation"
      sidebarSections={candidateNavigation}
    >
      <div className="min-h-screen bg-gradient-to-br from-cyan-50 via-white to-blue-50 p-6">
        <div className="max-w-7xl mx-auto space-y-8">
          {/* Header */}
          <div className="text-center space-y-4">
            <div className="inline-flex items-center space-x-2 bg-cyan-100 text-cyan-800 px-4 py-2 rounded-full text-sm font-medium">
              <Cloud className="h-4 w-4" />
              <span>DevOps & Cloud Certification</span>
            </div>
            <h1 className="text-4xl font-bold text-gray-900">
              Master DevOps & Cloud Technologies
            </h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Build scalable infrastructure with AWS, Docker, Kubernetes, and CI/CD pipelines. 
              Master cloud architecture and deployment automation for modern applications.
            </p>
          </div>

          <Tabs value={selectedPath} onValueChange={setSelectedPath} className="space-y-6">
            {/* Path Selection */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {devOpsPaths.map((path) => {
                const IconComponent = path.icon;
                return (
                  <Card 
                    key={path.id} 
                    className={`cursor-pointer transition-all duration-300 hover:shadow-lg border-2 ${
                      selectedPath === path.id 
                        ? 'border-cyan-500 shadow-lg' 
                        : 'border-gray-200 hover:border-cyan-300'
                    }`}
                    onClick={() => setSelectedPath(path.id)}
                  >
                    <CardHeader className="pb-3">
                      <div className="flex items-center justify-between">
                        <div className={`p-3 rounded-lg bg-gradient-to-r ${path.color}`}>
                          <IconComponent className="h-6 w-6 text-white" />
                        </div>
                        <div className="flex items-center space-x-1">
                          <Star className="h-4 w-4 text-yellow-500 fill-current" />
                          <span className="text-sm font-medium">{path.rating}</span>
                        </div>
                      </div>
                      <CardTitle className="text-lg">{path.name}</CardTitle>
                      <CardDescription className="text-sm">{path.description}</CardDescription>
                    </CardHeader>
                    <CardContent className="pt-0">
                      <div className="space-y-3">
                        <div className="flex justify-between text-sm">
                          <span>Progress</span>
                          <span className="font-medium">{path.completion}%</span>
                        </div>
                        <Progress value={path.completion} className="h-2" />
                        <div className="grid grid-cols-2 gap-4 text-sm">
                          <div className="flex items-center space-x-2">
                            <Clock className="h-4 w-4 text-gray-500" />
                            <span>{path.duration}</span>
                          </div>
                          <div className="flex items-center space-x-2">
                            <Users className="h-4 w-4 text-gray-500" />
                            <span>{(path.enrolled / 1000).toFixed(1)}k</span>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>

            {/* Selected Path Details */}
            {selectedPathData && (
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                {/* Learning Path */}
                <div className="lg:col-span-2 space-y-6">
                  <Card>
                    <CardHeader className={`bg-gradient-to-r ${selectedPathData.color} text-white`}>
                      <CardTitle className="text-xl flex items-center space-x-3">
                        <selectedPathData.icon className="h-6 w-6" />
                        <span>{selectedPathData.name} Learning Path</span>
                      </CardTitle>
                      <CardDescription className="text-white/80">
                        {selectedPathData.description} • {selectedPathData.duration}
                      </CardDescription>
                    </CardHeader>
                    <CardContent className="p-6">
                      <div className="space-y-4">
                        {selectedPathData.modules.map((module, index) => (
                          <div 
                            key={index} 
                            className={`p-4 rounded-lg border-2 transition-all ${
                              module.status === 'completed' 
                                ? 'bg-green-50 border-green-200' 
                                : module.status === 'current'
                                ? 'bg-cyan-50 border-cyan-200'
                                : 'bg-gray-50 border-gray-200'
                            }`}
                          >
                            <div className="flex items-center justify-between mb-2">
                              <div className="flex items-center space-x-3">
                                {module.status === 'completed' ? (
                                  <CheckCircle className="h-5 w-5 text-green-500" />
                                ) : module.status === 'current' ? (
                                  <Play className="h-5 w-5 text-cyan-500" />
                                ) : (
                                  <Clock className="h-5 w-5 text-gray-400" />
                                )}
                                <span className="font-medium">{module.name}</span>
                              </div>
                              <Badge variant={
                                module.difficulty === 'Expert' ? 'destructive' :
                                module.difficulty === 'Advanced' ? 'default' :
                                module.difficulty === 'Intermediate' ? 'secondary' : 'outline'
                              }>
                                {module.difficulty}
                              </Badge>
                            </div>
                            {module.status !== 'not-started' && module.status !== 'locked' && (
                              <div className="space-y-1 mb-3">
                                <div className="flex justify-between text-sm">
                                  <span>Progress</span>
                                  <span>{module.progress}%</span>
                                </div>
                                <Progress value={module.progress} className="h-1.5" />
                              </div>
                            )}
                            <Button 
                              variant={module.status === 'current' ? 'default' : 'ghost'} 
                              size="sm"
                              className="w-full"
                              disabled={module.status === 'locked' || module.status === 'not-started'}
                            >
                              {module.status === 'completed' ? 'Review & Practice' :
                               module.status === 'current' ? 'Continue Learning' : 
                               module.status === 'locked' ? 'Locked' : 'Start Module'}
                            </Button>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>

                  {/* Cloud Provider Comparison */}
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center space-x-2">
                        <Globe className="h-5 w-5" />
                        <span>Cloud Provider Analysis</span>
                      </CardTitle>
                      <CardDescription>Market share, learning curve, and job opportunities</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        {cloudProviders.map((provider, index) => (
                          <div key={index} className="space-y-3">
                            <div className="flex items-center justify-between">
                              <span className="font-medium">{provider.name}</span>
                              <div className={`w-4 h-4 rounded-full ${provider.color}`} />
                            </div>
                            <div className="grid grid-cols-3 gap-4">
                              <div className="space-y-1">
                                <div className="flex justify-between text-sm">
                                  <span>Market Share</span>
                                  <span>{provider.market}%</span>
                                </div>
                                <Progress value={provider.market} className="h-1.5" />
                              </div>
                              <div className="space-y-1">
                                <div className="flex justify-between text-sm">
                                  <span>Learning Ease</span>
                                  <span>{provider.learning}%</span>
                                </div>
                                <Progress value={provider.learning} className="h-1.5" />
                              </div>
                              <div className="space-y-1">
                                <div className="flex justify-between text-sm">
                                  <span>Job Market</span>
                                  <span>{provider.jobs}%</span>
                                </div>
                                <Progress value={provider.jobs} className="h-1.5" />
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                </div>

                {/* Sidebar */}
                <div className="space-y-6">
                  {/* Practical Labs */}
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center space-x-2">
                        <Settings className="h-5 w-5" />
                        <span>Hands-on Labs</span>
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      {practicalLabs.map((lab, index) => (
                        <div key={index} className="p-3 bg-gray-50 rounded-lg">
                          <div className="flex items-center justify-between mb-2">
                            <span className="font-medium text-sm">{lab.name}</span>
                            <Badge variant="outline" className="text-xs">
                              {lab.duration}
                            </Badge>
                          </div>
                          <div className="flex items-center justify-between">
                            <span className={`text-xs px-2 py-1 rounded ${
                              lab.status === 'completed' ? 'bg-green-100 text-green-800' :
                              lab.status === 'current' ? 'bg-blue-100 text-blue-800' :
                              'bg-gray-100 text-gray-800'
                            }`}>
                              {lab.status}
                            </span>
                            {lab.status === 'completed' && (
                              <span className="text-sm font-semibold text-green-600">
                                {lab.score}%
                              </span>
                            )}
                          </div>
                        </div>
                      ))}
                    </CardContent>
                  </Card>

                  {/* Certification Badges */}
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center space-x-2">
                        <Trophy className="h-5 w-5" />
                        <span>Certifications</span>
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      {certificationBadges.map((badge, index) => (
                        <div key={index} className="flex items-center space-x-3">
                          <div className={`p-2 rounded-lg ${
                            badge.earned ? 'bg-yellow-100' : 'bg-gray-100'
                          }`}>
                            <badge.icon className={`h-4 w-4 ${
                              badge.earned ? 'text-yellow-600' : 'text-gray-400'
                            }`} />
                          </div>
                          <div className="flex-1">
                            <div className="font-medium text-sm">{badge.name}</div>
                          </div>
                          {badge.earned && (
                            <CheckCircle className="h-4 w-4 text-green-500" />
                          )}
                        </div>
                      ))}
                    </CardContent>
                  </Card>

                  {/* Action Buttons */}
                  <div className="space-y-3">
                    <Button size="lg" className="w-full bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-700 hover:to-blue-700">
                      <Play className="h-4 w-4 mr-2" />
                      Continue Learning
                    </Button>
                    <Button variant="outline" size="lg" className="w-full">
                      <Settings className="h-4 w-4 mr-2" />
                      Practice Lab
                    </Button>
                    <Button variant="outline" size="lg" className="w-full">
                      <Cloud className="h-4 w-4 mr-2" />
                      Cloud Sandbox
                    </Button>
                  </div>
                </div>
              </div>
            )}
          </Tabs>
        </div>
      </div>
    </PlatformLayout>
  );
};

export default DevOpsCertification;