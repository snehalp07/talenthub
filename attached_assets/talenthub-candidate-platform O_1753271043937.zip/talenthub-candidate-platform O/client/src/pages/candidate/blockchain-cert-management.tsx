import PlatformLayout from "@/components/layout/platform-layout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Shield, Link, Award, Lock } from "lucide-react";
import { candidateNavigation } from "@/config/complete-navigation";

export default function BlockchainCertManagement() {
  return (
    <PlatformLayout 
      sidebarTitle="Candidate Platform"
      sidebarSubtitle="Professional Development Hub"
      sidebarSections={candidateNavigation}
    >
      <div className="max-w-7xl mx-auto p-6 space-y-8">
        <div className="text-center space-y-4">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-orange-100 to-amber-100 rounded-full">
            <Shield className="h-5 w-5 text-orange-600" />
            <span className="text-sm font-medium text-orange-900">Blockchain Certificate Management</span>
          </div>
          <h1 className="text-4xl font-bold bg-gradient-to-r from-orange-600 to-amber-600 bg-clip-text text-transparent">
            Blockchain Credential Analytics
          </h1>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            Manage and verify blockchain-secured certifications with immutable credential tracking
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <Card className="hover:shadow-md transition-shadow">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="p-3 rounded-lg bg-orange-500 text-white">
                  <Shield className="h-6 w-6" />
                </div>
                <div className="text-2xl font-bold text-orange-600">15</div>
              </div>
              <div className="text-sm text-gray-600">Blockchain Certificates</div>
            </CardContent>
          </Card>

          <Card className="hover:shadow-md transition-shadow">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="p-3 rounded-lg bg-blue-500 text-white">
                  <Link className="h-6 w-6" />
                </div>
                <div className="text-2xl font-bold text-blue-600">100%</div>
              </div>
              <div className="text-sm text-gray-600">Verification Rate</div>
            </CardContent>
          </Card>

          <Card className="hover:shadow-md transition-shadow">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="p-3 rounded-lg bg-green-500 text-white">
                  <Award className="h-6 w-6" />
                </div>
                <div className="text-2xl font-bold text-green-600">7</div>
              </div>
              <div className="text-sm text-gray-600">Verified This Month</div>
            </CardContent>
          </Card>

          <Card className="hover:shadow-md transition-shadow">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="p-3 rounded-lg bg-purple-500 text-white">
                  <Lock className="h-6 w-6" />
                </div>
                <div className="text-2xl font-bold text-purple-600">256</div>
              </div>
              <div className="text-sm text-gray-600">Security Level (bits)</div>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle>Blockchain Certificates Portfolio</CardTitle>
              <CardDescription>Your blockchain-secured certification credentials</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="p-4 bg-orange-50 rounded-lg">
                <div className="flex justify-between items-start mb-3">
                  <div>
                    <h3 className="font-semibold text-orange-900">AWS Solutions Architect Professional</h3>
                    <p className="text-sm text-orange-700">Issued: March 2024 • Block #0x7A4B...</p>
                  </div>
                  <Badge className="bg-orange-100 text-orange-700">Verified</Badge>
                </div>
                <div className="text-sm text-orange-600 mb-2">Ethereum blockchain • Smart contract: 0x1a2b...</div>
                <div className="text-xs text-orange-500">Last verified: 2 hours ago</div>
              </div>

              <div className="p-4 bg-blue-50 rounded-lg">
                <div className="flex justify-between items-start mb-3">
                  <div>
                    <h3 className="font-semibold text-blue-900">Certified Kubernetes Administrator</h3>
                    <p className="text-sm text-blue-700">Issued: January 2024 • Block #0x9C2D...</p>
                  </div>
                  <Badge className="bg-blue-100 text-blue-700">Verified</Badge>
                </div>
                <div className="text-sm text-blue-600 mb-2">Polygon blockchain • Smart contract: 0x3e4f...</div>
                <div className="text-xs text-blue-500">Last verified: 1 day ago</div>
              </div>

              <div className="p-4 bg-green-50 rounded-lg">
                <div className="flex justify-between items-start mb-3">
                  <div>
                    <h3 className="font-semibold text-green-900">TensorFlow Developer Certificate</h3>
                    <p className="text-sm text-green-700">Issued: December 2023 • Block #0x5F8A...</p>
                  </div>
                  <Badge className="bg-green-100 text-green-700">Verified</Badge>
                </div>
                <div className="text-sm text-green-600 mb-2">BSC blockchain • Smart contract: 0x6g7h...</div>
                <div className="text-xs text-green-500">Last verified: 3 days ago</div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Blockchain Security & Analytics</CardTitle>
              <CardDescription>Your credential security and verification metrics</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="text-center p-3 bg-orange-50 rounded-lg">
                  <div className="text-2xl font-bold text-orange-600">100%</div>
                  <div className="text-sm text-orange-700">Verification Rate</div>
                </div>
                <div className="text-center p-3 bg-blue-50 rounded-lg">
                  <div className="text-2xl font-bold text-blue-600">256-bit</div>
                  <div className="text-sm text-blue-700">Encryption Level</div>
                </div>
                <div className="text-center p-3 bg-green-50 rounded-lg">
                  <div className="text-2xl font-bold text-green-600">847</div>
                  <div className="text-sm text-green-700">Verification Checks</div>
                </div>
                <div className="text-center p-3 bg-purple-50 rounded-lg">
                  <div className="text-2xl font-bold text-purple-600">0</div>
                  <div className="text-sm text-purple-700">Security Breaches</div>
                </div>
              </div>

              <div className="space-y-3">
                <div>
                  <div className="flex justify-between items-center mb-1">
                    <span className="text-sm font-medium">Blockchain Integrity</span>
                    <span className="text-sm text-green-600">100%</span>
                  </div>
                  <Progress value={100} className="h-2" />
                </div>

                <div>
                  <div className="flex justify-between items-center mb-1">
                    <span className="text-sm font-medium">Smart Contract Health</span>
                    <span className="text-sm text-blue-600">98%</span>
                  </div>
                  <Progress value={98} className="h-2" />
                </div>

                <div>
                  <div className="flex justify-between items-center mb-1">
                    <span className="text-sm font-medium">Network Uptime</span>
                    <span className="text-sm text-green-600">99.9%</span>
                  </div>
                  <Progress value={99.9} className="h-2" />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Blockchain Certificate Services</CardTitle>
            <CardDescription>Secure blockchain-based credential management and verification</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              <div className="p-4 border border-orange-200 rounded-lg hover:shadow-md transition-shadow">
                <div className="flex items-center gap-3 mb-3">
                  <div className="w-10 h-10 bg-orange-500 rounded-lg flex items-center justify-center">
                    <Shield className="h-5 w-5 text-white" />
                  </div>
                  <div>
                    <h3 className="font-semibold">Issue Certificate</h3>
                    <p className="text-sm text-gray-600">Create blockchain certificate</p>
                  </div>
                </div>
                <div className="space-y-2 mb-4">
                  <div className="flex justify-between text-sm">
                    <span>Processing Time</span>
                    <span className="font-medium">5-10 minutes</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span>Gas Fee</span>
                    <span className="font-medium">~$2.50</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span>Blockchain</span>
                    <span className="font-medium">Ethereum</span>
                  </div>
                </div>
                <Button className="w-full bg-orange-600 hover:bg-orange-700">Issue Certificate</Button>
              </div>

              <div className="p-4 border border-blue-200 rounded-lg hover:shadow-md transition-shadow">
                <div className="flex items-center gap-3 mb-3">
                  <div className="w-10 h-10 bg-blue-500 rounded-lg flex items-center justify-center">
                    <Link className="h-5 w-5 text-white" />
                  </div>
                  <div>
                    <h3 className="font-semibold">Verify Certificate</h3>
                    <p className="text-sm text-gray-600">Check certificate authenticity</p>
                  </div>
                </div>
                <div className="space-y-2 mb-4">
                  <div className="flex justify-between text-sm">
                    <span>Verification Time</span>
                    <span className="font-medium">Instant</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span>Cost</span>
                    <span className="font-medium">Free</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span>Success Rate</span>
                    <span className="font-medium text-green-600">100%</span>
                  </div>
                </div>
                <Button className="w-full bg-blue-600 hover:bg-blue-700">Verify Certificate</Button>
              </div>

              <div className="p-4 border border-green-200 rounded-lg hover:shadow-md transition-shadow">
                <div className="flex items-center gap-3 mb-3">
                  <div className="w-10 h-10 bg-green-500 rounded-lg flex items-center justify-center">
                    <Award className="h-5 w-5 text-white" />
                  </div>
                  <div>
                    <h3 className="font-semibold">Share Certificate</h3>
                    <p className="text-sm text-gray-600">Generate shareable proof</p>
                  </div>
                </div>
                <div className="space-y-2 mb-4">
                  <div className="flex justify-between text-sm">
                    <span>Format</span>
                    <span className="font-medium">QR Code + Link</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span>Validity</span>
                    <span className="font-medium">Lifetime</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span>Privacy</span>
                    <span className="font-medium">Configurable</span>
                  </div>
                </div>
                <Button className="w-full bg-green-600 hover:bg-green-700">Share Certificate</Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </PlatformLayout>
  );
}