import PlatformLayout from "@/components/layout/platform-layout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Video, Play, Upload, Eye, ThumbsUp, MessageCircle, Share2, Calendar, TrendingUp, Camera, Settings } from "lucide-react";
import { platformConfigs } from "@/config/complete-navigation";

export default function ProfessionalVlogs() {
  const config = platformConfigs.candidate;
  
  const myVideos = [
    {
      id: 1,
      title: "5 Tips for Technical Interviews in 2024",
      description: "Sharing my experience and insights on acing technical interviews",
      thumbnail: "/api/placeholder/320/180",
      duration: "8:42",
      uploadedAt: "2024-06-15",
      views: 2847,
      likes: 156,
      comments: 34,
      status: "published",
      category: "Career Tips"
    },
    {
      id: 2,
      title: "Building My First React Native App",
      description: "A walkthrough of developing a mobile app from scratch",
      thumbnail: "/api/placeholder/320/180",
      duration: "12:15",
      uploadedAt: "2024-06-10",
      views: 1923,
      likes: 89,
      comments: 21,
      status: "published",
      category: "Development"
    },
    {
      id: 3,
      title: "Day in the Life of a Software Engineer",
      description: "Behind the scenes of my daily work routine",
      thumbnail: "/api/placeholder/320/180",
      duration: "6:33",
      uploadedAt: "2024-06-08",
      views: 4521,
      likes: 267,
      comments: 58,
      status: "published",
      category: "Lifestyle"
    }
  ];

  const draftVideos = [
    {
      id: 4,
      title: "Advanced JavaScript Concepts Explained",
      description: "Deep dive into closures, prototypes, and async programming",
      thumbnail: "/api/placeholder/320/180",
      duration: "15:20",
      status: "editing",
      category: "Education"
    }
  ];

  const trendingChannels = [
    {
      name: "TechCareer Pro",
      subscribers: "125K",
      avatar: "/api/placeholder/40/40",
      specialty: "Career Guidance"
    },
    {
      name: "CodeWith Sarah",
      subscribers: "89K",
      avatar: "/api/placeholder/40/40",
      specialty: "Web Development"
    },
    {
      name: "Leadership Lab",
      subscribers: "67K",
      avatar: "/api/placeholder/40/40",
      specialty: "Management"
    }
  ];

  return (
    <PlatformLayout
      sidebarTitle={config.sidebarTitle}
      sidebarSubtitle={config.sidebarSubtitle}
      sidebarSections={config.sidebarSections}
      usageData={config.usageData}
    >
      <div className="space-y-6">
        {/* Channel Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card className="bg-gradient-to-br from-red-50 to-red-100 border-red-200">
            <CardHeader className="pb-2">
              <CardTitle className="text-lg text-red-700">Total Views</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-red-800">9.3K</div>
              <p className="text-sm text-red-600">+18% this month</p>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-blue-50 to-blue-100 border-blue-200">
            <CardHeader className="pb-2">
              <CardTitle className="text-lg text-blue-700">Subscribers</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-blue-800">247</div>
              <p className="text-sm text-blue-600">+12 this week</p>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-green-50 to-green-100 border-green-200">
            <CardHeader className="pb-2">
              <CardTitle className="text-lg text-green-700">Published Videos</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-green-800">23</div>
              <p className="text-sm text-green-600">3 this month</p>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-purple-50 to-purple-100 border-purple-200">
            <CardHeader className="pb-2">
              <CardTitle className="text-lg text-purple-700">Avg. Watch Time</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-purple-800">4:32</div>
              <p className="text-sm text-purple-600">+0:45 vs last month</p>
            </CardContent>
          </Card>
        </div>

        {/* Quick Actions */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Camera className="h-5 w-5 text-red-600" />
              Create Video Content
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex gap-4">
              <Button className="bg-red-600 hover:bg-red-700">
                <Upload className="h-4 w-4 mr-2" />
                Upload Video
              </Button>
              <Button variant="outline">
                <Video className="h-4 w-4 mr-2" />
                Record Live
              </Button>
              <Button variant="outline">
                <Settings className="h-4 w-4 mr-2" />
                Channel Settings
              </Button>
            </div>
          </CardContent>
        </Card>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Main Content */}
          <div className="lg:col-span-2">
            <Tabs defaultValue="published" className="w-full">
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="published">Published</TabsTrigger>
                <TabsTrigger value="drafts">Drafts (1)</TabsTrigger>
                <TabsTrigger value="analytics">Analytics</TabsTrigger>
              </TabsList>

              <TabsContent value="published" className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {myVideos.map((video) => (
                    <Card key={video.id} className="hover:shadow-md transition-shadow">
                      <div className="relative">
                        <img 
                          src={video.thumbnail} 
                          alt={video.title}
                          className="w-full h-48 object-cover rounded-t-lg"
                        />
                        <div className="absolute bottom-2 right-2 bg-black bg-opacity-75 text-white px-2 py-1 rounded text-sm">
                          {video.duration}
                        </div>
                        <div className="absolute inset-0 flex items-center justify-center opacity-0 hover:opacity-100 transition-opacity bg-black bg-opacity-50 rounded-t-lg">
                          <Button size="lg" className="bg-red-600 hover:bg-red-700">
                            <Play className="h-6 w-6 mr-2" />
                            Play
                          </Button>
                        </div>
                      </div>
                      <CardContent className="p-4">
                        <div className="space-y-2">
                          <Badge variant="secondary" className="bg-blue-100 text-blue-800">
                            {video.category}
                          </Badge>
                          <h3 className="font-semibold line-clamp-2">{video.title}</h3>
                          <p className="text-sm text-gray-600 line-clamp-2">{video.description}</p>
                          <div className="flex items-center justify-between text-sm text-gray-500">
                            <div className="flex items-center gap-3">
                              <div className="flex items-center gap-1">
                                <Eye className="h-4 w-4" />
                                {video.views.toLocaleString()}
                              </div>
                              <div className="flex items-center gap-1">
                                <ThumbsUp className="h-4 w-4" />
                                {video.likes}
                              </div>
                              <div className="flex items-center gap-1">
                                <MessageCircle className="h-4 w-4" />
                                {video.comments}
                              </div>
                            </div>
                            <div className="flex items-center gap-1">
                              <Calendar className="h-4 w-4" />
                              {video.uploadedAt}
                            </div>
                          </div>
                          <div className="flex gap-2 pt-2">
                            <Button variant="outline" size="sm" className="flex-1">
                              Edit
                            </Button>
                            <Button variant="outline" size="sm">
                              <Share2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </TabsContent>

              <TabsContent value="drafts" className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {draftVideos.map((video) => (
                    <Card key={video.id} className="border-dashed border-2 hover:shadow-md transition-shadow">
                      <div className="relative">
                        <img 
                          src={video.thumbnail} 
                          alt={video.title}
                          className="w-full h-48 object-cover rounded-t-lg opacity-75"
                        />
                        <div className="absolute bottom-2 right-2 bg-black bg-opacity-75 text-white px-2 py-1 rounded text-sm">
                          {video.duration}
                        </div>
                        <div className="absolute top-2 left-2">
                          <Badge variant="outline" className="border-orange-300 text-orange-600 bg-white">
                            Draft
                          </Badge>
                        </div>
                      </div>
                      <CardContent className="p-4">
                        <div className="space-y-2">
                          <Badge variant="secondary" className="bg-gray-100 text-gray-800">
                            {video.category}
                          </Badge>
                          <h3 className="font-semibold line-clamp-2">{video.title}</h3>
                          <p className="text-sm text-gray-600 line-clamp-2">{video.description}</p>
                          <div className="flex gap-2 pt-2">
                            <Button className="bg-red-600 hover:bg-red-700 flex-1" size="sm">
                              Continue Editing
                            </Button>
                            <Button variant="outline" size="sm">
                              Preview
                            </Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </TabsContent>

              <TabsContent value="analytics" className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <TrendingUp className="h-5 w-5 text-green-600" />
                      Video Performance
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="grid grid-cols-2 gap-4">
                        <div className="p-4 bg-red-50 rounded-lg">
                          <div className="text-2xl font-bold text-red-800">9,291</div>
                          <div className="text-sm text-red-600">Total Views (30 days)</div>
                        </div>
                        <div className="p-4 bg-blue-50 rounded-lg">
                          <div className="text-2xl font-bold text-blue-800">512</div>
                          <div className="text-sm text-blue-600">Total Likes (30 days)</div>
                        </div>
                      </div>
                      <div className="space-y-2">
                        <h4 className="font-medium">Top Performing Videos</h4>
                        <div className="space-y-2">
                          {myVideos.map((video) => (
                            <div key={video.id} className="flex justify-between items-center p-2 bg-gray-50 rounded">
                              <span className="text-sm font-medium line-clamp-1">{video.title}</span>
                              <span className="text-sm text-gray-600">{video.views} views</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Trending Channels */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Trending Channels</CardTitle>
                <CardDescription>Popular creators in your field</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {trendingChannels.map((channel) => (
                    <div key={channel.name} className="flex items-center gap-3">
                      <Avatar className="h-10 w-10">
                        <AvatarImage src={channel.avatar} />
                        <AvatarFallback>{channel.name.split(' ').map(n => n[0]).join('')}</AvatarFallback>
                      </Avatar>
                      <div className="flex-1">
                        <h4 className="font-medium text-sm">{channel.name}</h4>
                        <p className="text-xs text-gray-500">{channel.subscribers} subscribers</p>
                        <p className="text-xs text-blue-600">{channel.specialty}</p>
                      </div>
                      <Button variant="outline" size="sm">
                        Follow
                      </Button>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Video Ideas */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Content Ideas</CardTitle>
                <CardDescription>Trending topics for your next video</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {[
                    "React Best Practices 2024",
                    "Remote Work Setup Tour",
                    "Code Review Process",
                    "Career Transition Story",
                    "Tech Stack Comparison"
                  ].map((idea) => (
                    <div key={idea} className="p-2 hover:bg-gray-50 rounded cursor-pointer">
                      <span className="text-sm font-medium">{idea}</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </PlatformLayout>
  );
}