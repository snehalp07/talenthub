import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import PlatformLayout from "@/components/layout/platform-layout";
import { candidateNavigation } from "@/config/complete-navigation";
import { 
  Layers, Play, CheckCircle, Award, Target, TrendingUp, 
  Star, Clock, Code, Users, Zap, BookOpen, Trophy,
  ArrowRight, Database, Monitor, Server, Globe
} from "lucide-react";

const FullStackCertification: React.FC = () => {
  const [selectedStack, setSelectedStack] = useState('mern');

  const fullStackPaths = [
    {
      id: 'mern',
      name: 'MERN Stack',
      description: 'MongoDB, Express, React, Node.js',
      icon: Layers,
      color: 'from-purple-500 to-pink-500',
      duration: '16-20 weeks',
      enrolled: 12840,
      completion: 58,
      rating: 4.9,
      modules: [
        { name: 'MongoDB & Database Design', status: 'completed', progress: 100, weeks: 3 },
        { name: 'Express.js Backend', status: 'completed', progress: 100, weeks: 3 },
        { name: 'React Frontend', status: 'current', progress: 70, weeks: 4 },
        { name: 'Node.js Integration', status: 'locked', progress: 0, weeks: 3 },
        { name: 'Full Stack Project', status: 'locked', progress: 0, weeks: 4 },
        { name: 'Deployment & DevOps', status: 'locked', progress: 0, weeks: 2 }
      ]
    },
    {
      id: 'mean',
      name: 'MEAN Stack',
      description: 'MongoDB, Express, Angular, Node.js',
      icon: Layers,
      color: 'from-red-500 to-orange-500',
      duration: '18-22 weeks',
      enrolled: 8650,
      completion: 25,
      rating: 4.7,
      modules: [
        { name: 'Angular Fundamentals', status: 'current', progress: 40, weeks: 4 },
        { name: 'TypeScript Mastery', status: 'locked', progress: 0, weeks: 2 },
        { name: 'Express API Development', status: 'locked', progress: 0, weeks: 3 },
        { name: 'MongoDB Integration', status: 'locked', progress: 0, weeks: 3 },
        { name: 'MEAN Stack Project', status: 'locked', progress: 0, weeks: 4 },
        { name: 'Testing & Deployment', status: 'locked', progress: 0, weeks: 3 }
      ]
    },
    {
      id: 'django',
      name: 'Django Full-Stack',
      description: 'Python, Django, PostgreSQL, React',
      icon: Code,
      color: 'from-green-500 to-blue-500',
      duration: '14-18 weeks',
      enrolled: 6720,
      completion: 15,
      rating: 4.8,
      modules: [
        { name: 'Django Framework', status: 'not-started', progress: 0, weeks: 4 },
        { name: 'Django REST Framework', status: 'not-started', progress: 0, weeks: 3 },
        { name: 'PostgreSQL & ORM', status: 'not-started', progress: 0, weeks: 2 },
        { name: 'React Integration', status: 'not-started', progress: 0, weeks: 3 },
        { name: 'Authentication & Security', status: 'not-started', progress: 0, weeks: 2 },
        { name: 'Production Deployment', status: 'not-started', progress: 0, weeks: 2 }
      ]
    }
  ];

  const projectMilestones = [
    { name: 'E-commerce Platform', status: 'completed', score: 92, tech: 'MERN' },
    { name: 'Social Media App', status: 'current', score: 0, tech: 'MERN' },
    { name: 'Task Management Tool', status: 'upcoming', score: 0, tech: 'MEAN' },
    { name: 'Blog Platform', status: 'upcoming', score: 0, tech: 'Django' }
  ];

  const techStackComparison = [
    { 
      aspect: 'Learning Curve', 
      mern: 85, 
      mean: 70, 
      django: 75,
      description: 'Ease of learning for beginners'
    },
    { 
      aspect: 'Job Market', 
      mern: 90, 
      mean: 75, 
      django: 80,
      description: 'Industry demand and opportunities'
    },
    { 
      aspect: 'Performance', 
      mern: 80, 
      mean: 85, 
      django: 88,
      description: 'Runtime performance and scalability'
    },
    { 
      aspect: 'Community Support', 
      mern: 95, 
      mean: 80, 
      django: 85,
      description: 'Developer community and resources'
    }
  ];

  const selectedStackData = fullStackPaths.find(stack => stack.id === selectedStack);

  return (
    <PlatformLayout
      sidebarTitle="Candidate Platform"
      sidebarSubtitle="Interview Preparation"
      sidebarSections={candidateNavigation}
    >
      <div className="min-h-screen bg-gradient-to-br from-purple-50 via-white to-pink-50 p-6">
        <div className="max-w-7xl mx-auto space-y-8">
          {/* Header */}
          <div className="text-center space-y-4">
            <div className="inline-flex items-center space-x-2 bg-purple-100 text-purple-800 px-4 py-2 rounded-full text-sm font-medium">
              <Layers className="h-4 w-4" />
              <span>Full-Stack Development Certification</span>
            </div>
            <h1 className="text-4xl font-bold text-gray-900">
              Master Full-Stack Development
            </h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Build complete web applications from database to deployment. 
              Choose your stack and master end-to-end development with real-world projects.
            </p>
          </div>

          <Tabs value={selectedStack} onValueChange={setSelectedStack} className="space-y-6">
            {/* Stack Selection */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {fullStackPaths.map((stack) => {
                const IconComponent = stack.icon;
                return (
                  <Card 
                    key={stack.id} 
                    className={`cursor-pointer transition-all duration-300 hover:shadow-lg border-2 ${
                      selectedStack === stack.id 
                        ? 'border-purple-500 shadow-lg' 
                        : 'border-gray-200 hover:border-purple-300'
                    }`}
                    onClick={() => setSelectedStack(stack.id)}
                  >
                    <CardHeader className="pb-3">
                      <div className="flex items-center justify-between">
                        <div className={`p-3 rounded-lg bg-gradient-to-r ${stack.color}`}>
                          <IconComponent className="h-6 w-6 text-white" />
                        </div>
                        <div className="flex items-center space-x-1">
                          <Star className="h-4 w-4 text-yellow-500 fill-current" />
                          <span className="text-sm font-medium">{stack.rating}</span>
                        </div>
                      </div>
                      <CardTitle className="text-lg">{stack.name}</CardTitle>
                      <CardDescription className="text-sm">{stack.description}</CardDescription>
                    </CardHeader>
                    <CardContent className="pt-0">
                      <div className="space-y-3">
                        <div className="flex justify-between text-sm">
                          <span>Progress</span>
                          <span className="font-medium">{stack.completion}%</span>
                        </div>
                        <Progress value={stack.completion} className="h-2" />
                        <div className="grid grid-cols-2 gap-4 text-sm">
                          <div className="flex items-center space-x-2">
                            <Clock className="h-4 w-4 text-gray-500" />
                            <span>{stack.duration}</span>
                          </div>
                          <div className="flex items-center space-x-2">
                            <Users className="h-4 w-4 text-gray-500" />
                            <span>{(stack.enrolled / 1000).toFixed(1)}k</span>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>

            {/* Selected Stack Details */}
            {selectedStackData && (
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                {/* Learning Path */}
                <div className="lg:col-span-2 space-y-6">
                  <Card>
                    <CardHeader className={`bg-gradient-to-r ${selectedStackData.color} text-white`}>
                      <CardTitle className="text-xl flex items-center space-x-3">
                        <selectedStackData.icon className="h-6 w-6" />
                        <span>{selectedStackData.name} Learning Path</span>
                      </CardTitle>
                      <CardDescription className="text-white/80">
                        {selectedStackData.description} • {selectedStackData.duration}
                      </CardDescription>
                    </CardHeader>
                    <CardContent className="p-6">
                      <div className="space-y-4">
                        {selectedStackData.modules.map((module, index) => (
                          <div 
                            key={index} 
                            className={`p-4 rounded-lg border-2 transition-all ${
                              module.status === 'completed' 
                                ? 'bg-green-50 border-green-200' 
                                : module.status === 'current'
                                ? 'bg-purple-50 border-purple-200'
                                : 'bg-gray-50 border-gray-200'
                            }`}
                          >
                            <div className="flex items-center justify-between mb-2">
                              <div className="flex items-center space-x-3">
                                {module.status === 'completed' ? (
                                  <CheckCircle className="h-5 w-5 text-green-500" />
                                ) : module.status === 'current' ? (
                                  <Play className="h-5 w-5 text-purple-500" />
                                ) : (
                                  <Clock className="h-5 w-5 text-gray-400" />
                                )}
                                <span className="font-medium">{module.name}</span>
                              </div>
                              <Badge variant="outline">
                                {module.weeks} weeks
                              </Badge>
                            </div>
                            {module.status !== 'not-started' && module.status !== 'locked' && (
                              <div className="space-y-1 mb-3">
                                <div className="flex justify-between text-sm">
                                  <span>Progress</span>
                                  <span>{module.progress}%</span>
                                </div>
                                <Progress value={module.progress} className="h-1.5" />
                              </div>
                            )}
                            <Button 
                              variant={module.status === 'current' ? 'default' : 'ghost'} 
                              size="sm"
                              className="w-full"
                              disabled={module.status === 'locked' || module.status === 'not-started'}
                            >
                              {module.status === 'completed' ? 'Review Module' :
                               module.status === 'current' ? 'Continue Learning' : 
                               module.status === 'locked' ? 'Locked' : 'Start Module'}
                            </Button>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>

                  {/* Stack Comparison */}
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center space-x-2">
                        <TrendingUp className="h-5 w-5" />
                        <span>Stack Comparison</span>
                      </CardTitle>
                      <CardDescription>Compare different full-stack technologies</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        {techStackComparison.map((comparison, index) => (
                          <div key={index} className="space-y-2">
                            <div className="flex justify-between items-center">
                              <span className="font-medium">{comparison.aspect}</span>
                              <span className="text-sm text-gray-500">{comparison.description}</span>
                            </div>
                            <div className="grid grid-cols-3 gap-4">
                              <div className="space-y-1">
                                <div className="flex justify-between text-sm">
                                  <span>MERN</span>
                                  <span>{comparison.mern}%</span>
                                </div>
                                <Progress value={comparison.mern} className="h-1.5" />
                              </div>
                              <div className="space-y-1">
                                <div className="flex justify-between text-sm">
                                  <span>MEAN</span>
                                  <span>{comparison.mean}%</span>
                                </div>
                                <Progress value={comparison.mean} className="h-1.5" />
                              </div>
                              <div className="space-y-1">
                                <div className="flex justify-between text-sm">
                                  <span>Django</span>
                                  <span>{comparison.django}%</span>
                                </div>
                                <Progress value={comparison.django} className="h-1.5" />
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                </div>

                {/* Sidebar */}
                <div className="space-y-6">
                  {/* Project Milestones */}
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center space-x-2">
                        <Trophy className="h-5 w-5" />
                        <span>Project Milestones</span>
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      {projectMilestones.map((project, index) => (
                        <div key={index} className="p-3 bg-gray-50 rounded-lg">
                          <div className="flex items-center justify-between mb-2">
                            <span className="font-medium text-sm">{project.name}</span>
                            <Badge variant="outline" className="text-xs">
                              {project.tech}
                            </Badge>
                          </div>
                          <div className="flex items-center justify-between">
                            <span className={`text-xs px-2 py-1 rounded ${
                              project.status === 'completed' ? 'bg-green-100 text-green-800' :
                              project.status === 'current' ? 'bg-blue-100 text-blue-800' :
                              'bg-gray-100 text-gray-800'
                            }`}>
                              {project.status}
                            </span>
                            {project.status === 'completed' && (
                              <span className="text-sm font-semibold text-green-600">
                                {project.score}%
                              </span>
                            )}
                          </div>
                        </div>
                      ))}
                    </CardContent>
                  </Card>

                  {/* Technology Icons */}
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center space-x-2">
                        <Code className="h-5 w-5" />
                        <span>Tech Stack</span>
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="grid grid-cols-2 gap-4">
                        <div className="flex items-center space-x-2 p-2 bg-blue-50 rounded-lg">
                          <Monitor className="h-5 w-5 text-blue-600" />
                          <span className="text-sm font-medium">Frontend</span>
                        </div>
                        <div className="flex items-center space-x-2 p-2 bg-green-50 rounded-lg">
                          <Server className="h-5 w-5 text-green-600" />
                          <span className="text-sm font-medium">Backend</span>
                        </div>
                        <div className="flex items-center space-x-2 p-2 bg-purple-50 rounded-lg">
                          <Database className="h-5 w-5 text-purple-600" />
                          <span className="text-sm font-medium">Database</span>
                        </div>
                        <div className="flex items-center space-x-2 p-2 bg-orange-50 rounded-lg">
                          <Globe className="h-5 w-5 text-orange-600" />
                          <span className="text-sm font-medium">Deployment</span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  {/* Action Buttons */}
                  <div className="space-y-3">
                    <Button size="lg" className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700">
                      <Play className="h-4 w-4 mr-2" />
                      Continue Learning
                    </Button>
                    <Button variant="outline" size="lg" className="w-full">
                      <Target className="h-4 w-4 mr-2" />
                      System Design
                    </Button>
                    <Button variant="outline" size="lg" className="w-full">
                      <Trophy className="h-4 w-4 mr-2" />
                      Build Project
                    </Button>
                  </div>
                </div>
              </div>
            )}
          </Tabs>
        </div>
      </div>
    </PlatformLayout>
  );
};

export default FullStackCertification;