import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import PlatformLayout from "@/components/layout/platform-layout";
import { platformConfigs } from "@/config/complete-navigation";
import { useThemeClasses } from "@/lib/theme-config";
import { 
  Trophy, 
  Award, 
  TrendingUp, 
  Clock, 
  Target, 
  BarChart3,
  Calendar,
  CheckCircle,
  Star,
  Download,
  Share,
  RotateCcw
} from "lucide-react";

interface TestResult {
  id: string;
  testId: string;
  score: number;
  passed: boolean;
  completedAt: string;
  timeSpent: number;
  correctAnswers: number;
  totalQuestions: number;
}

interface Certificate {
  id: string;
  title: string;
  description: string;
  earnedAt: string;
  verificationCode: string;
  issuedBy: string;
}

interface Badge {
  id: string;
  testId: string;
  title: string;
  earnedAt: string;
  score: number;
  type: string;
}

function TestResultsContent() {
  const [selectedTab, setSelectedTab] = useState("overview");

  // Fetch test results
  const { data: results, isLoading: resultsLoading } = useQuery<TestResult[]>({
    queryKey: ["/api/candidate/test-results"],
    queryFn: () => fetch("/api/candidate/test-results").then(res => res.json()),
  });

  // Fetch analytics
  const { data: analytics, isLoading: analyticsLoading } = useQuery({
    queryKey: ["/api/candidate/test-analytics"],
    queryFn: () => fetch("/api/candidate/test-analytics").then(res => res.json()),
  });

  // Fetch certificates and badges
  const { data: achievements, isLoading: achievementsLoading } = useQuery({
    queryKey: ["/api/candidate/certificates"],
    queryFn: () => fetch("/api/candidate/certificates").then(res => res.json()),
  });

  const formatTime = (seconds: number) => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    return hours > 0 ? `${hours}h ${minutes}m` : `${minutes}m`;
  };

  const getScoreColor = (score: number) => {
    if (score >= 80) return "text-green-600 bg-green-50";
    if (score >= 60) return "text-yellow-600 bg-yellow-50";
    return "text-red-600 bg-red-50";
  };

  if (resultsLoading || analyticsLoading || achievementsLoading) {
    return (
      <div className="max-w-7xl mx-auto p-6">
        <div className="animate-pulse space-y-6">
          <div className="h-8 bg-gray-200 rounded w-1/3"></div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[1, 2, 3].map(i => (
              <div key={i} className="h-32 bg-gray-200 rounded"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Test Results & Analytics</h1>
          <p className="text-muted-foreground">Track your progress and achievements</p>
        </div>
      </div>

      {/* Overview Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Total Tests</p>
                <p className="text-2xl font-bold">{analytics?.totalTests || 0}</p>
              </div>
              <Target className="h-8 w-8 text-sky-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Pass Rate</p>
                <p className="text-2xl font-bold">{analytics?.passRate || 0}%</p>
              </div>
              <CheckCircle className="h-8 w-8 text-green-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Avg Score</p>
                <p className="text-2xl font-bold">{analytics?.averageScore || 0}%</p>
              </div>
              <BarChart3 className="h-8 w-8 text-sky-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Time Spent</p>
                <p className="text-2xl font-bold">{formatTime(analytics?.totalTimeSpent || 0)}</p>
              </div>
              <Clock className="h-8 w-8 text-sky-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Main Content Tabs */}
      <Tabs defaultValue="overview" className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="results">Test History</TabsTrigger>
          <TabsTrigger value="certificates">Certificates</TabsTrigger>
          <TabsTrigger value="analytics">Analytics</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Recent Results */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Calendar className="h-5 w-5" />
                  Recent Test Results
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {analytics?.recentResults?.map((result: TestResult) => (
                  <div key={result.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                    <div>
                      <p className="font-medium">{result.testId.replace('-', ' ').toUpperCase()}</p>
                      <p className="text-sm text-muted-foreground">
                        {new Date(result.completedAt).toLocaleDateString()}
                      </p>
                    </div>
                    <div className="text-right">
                      <Badge className={getScoreColor(result.score)}>
                        {result.score}%
                      </Badge>
                      <p className="text-sm text-muted-foreground mt-1">
                        {result.correctAnswers}/{result.totalQuestions}
                      </p>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>

            {/* Achievement Summary */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Trophy className="h-5 w-5" />
                  Achievements
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="text-center p-4 bg-yellow-50 rounded-lg">
                    <Award className="h-8 w-8 text-yellow-600 mx-auto mb-2" />
                    <p className="text-2xl font-bold text-yellow-600">
                      {achievements?.totalCertificates || 0}
                    </p>
                    <p className="text-sm text-muted-foreground">Certificates</p>
                  </div>
                  <div className="text-center p-4 bg-sky-50 rounded-lg">
                    <Star className="h-8 w-8 text-sky-600 mx-auto mb-2" />
                    <p className="text-2xl font-bold text-sky-600">
                      {achievements?.totalBadges || 0}
                    </p>
                    <p className="text-sm text-muted-foreground">Badges</p>
                  </div>
                </div>

                {analytics?.improvementTrend !== undefined && (
                  <div className="p-4 bg-green-50 rounded-lg">
                    <div className="flex items-center gap-2 mb-2">
                      <TrendingUp className="h-5 w-5 text-green-600" />
                      <span className="font-medium text-green-600">Improvement Trend</span>
                    </div>
                    <p className="text-sm text-muted-foreground">
                      {analytics.improvementTrend > 0 
                        ? `+${analytics.improvementTrend}% improvement` 
                        : analytics.improvementTrend < 0 
                        ? `${analytics.improvementTrend}% decline` 
                        : "Stable performance"}
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="results" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Complete Test History</CardTitle>
              <CardDescription>
                Detailed view of all your test attempts
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {results?.map((result) => (
                  <div key={result.id} className="border rounded-lg p-4">
                    <div className="flex items-center justify-between mb-2">
                      <h3 className="font-semibold">
                        {result.testId.replace('-', ' ').toUpperCase()}
                      </h3>
                      <Badge variant={result.passed ? "default" : "destructive"}>
                        {result.passed ? "Passed" : "Failed"}
                      </Badge>
                    </div>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                      <div>
                        <p className="text-muted-foreground">Score</p>
                        <p className="font-medium">{result.score}%</p>
                      </div>
                      <div>
                        <p className="text-muted-foreground">Correct Answers</p>
                        <p className="font-medium">{result.correctAnswers}/{result.totalQuestions}</p>
                      </div>
                      <div>
                        <p className="text-muted-foreground">Time Taken</p>
                        <p className="font-medium">{formatTime(result.timeSpent)}</p>
                      </div>
                      <div>
                        <p className="text-muted-foreground">Date</p>
                        <p className="font-medium">{new Date(result.completedAt).toLocaleDateString()}</p>
                      </div>
                    </div>
                    <div className="mt-3 flex gap-2">
                      <Button variant="outline" size="sm">
                        <RotateCcw className="h-4 w-4 mr-2" />
                        Retake Test
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="certificates" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Certificates */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Award className="h-5 w-5" />
                  Earned Certificates
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {achievements?.certificates?.map((cert: Certificate) => (
                  <div key={cert.id} className="border rounded-lg p-4 bg-gradient-to-r from-yellow-50 to-orange-50">
                    <div className="flex items-start justify-between">
                      <div>
                        <h3 className="font-semibold text-yellow-800">{cert.title}</h3>
                        <p className="text-sm text-yellow-600 mb-2">{cert.description}</p>
                        <p className="text-xs text-muted-foreground">
                          Issued by {cert.issuedBy} • {new Date(cert.earnedAt).toLocaleDateString()}
                        </p>
                        <p className="text-xs font-mono mt-1">ID: {cert.verificationCode}</p>
                      </div>
                      <Trophy className="h-8 w-8 text-yellow-600" />
                    </div>
                    <div className="mt-3 flex gap-2">
                      <Button variant="outline" size="sm">
                        <Download className="h-4 w-4 mr-2" />
                        Download
                      </Button>
                      <Button variant="outline" size="sm">
                        <Share className="h-4 w-4 mr-2" />
                        Share
                      </Button>
                    </div>
                  </div>
                )) || (
                  <div className="text-center py-8 text-muted-foreground">
                    <Award className="h-12 w-12 mx-auto mb-4 text-gray-300" />
                    <p>No certificates earned yet</p>
                    <p className="text-sm">Complete test tracks to earn certificates</p>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Badges */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Star className="h-5 w-5" />
                  Test Completion Badges
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 gap-4">
                  {achievements?.badges?.map((badge: Badge) => (
                    <div key={badge.id} className="text-center p-4 border rounded-lg bg-sky-50">
                      <Star className="h-8 w-8 text-sky-600 mx-auto mb-2" />
                      <p className="font-medium text-sm">{badge.title}</p>
                      <p className="text-xs text-muted-foreground">
                        Score: {badge.score}%
                      </p>
                      <p className="text-xs text-muted-foreground">
                        {new Date(badge.earnedAt).toLocaleDateString()}
                      </p>
                    </div>
                  )) || (
                    <div className="col-span-2 text-center py-8 text-muted-foreground">
                      <Star className="h-12 w-12 mx-auto mb-4 text-gray-300" />
                      <p>No badges earned yet</p>
                      <p className="text-sm">Pass tests to earn badges</p>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="analytics" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Category Performance */}
            <Card>
              <CardHeader>
                <CardTitle>Performance by Category</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {Object.entries(analytics?.categoryBreakdown || {}).map(([category, data]: [string, any]) => (
                  <div key={category} className="space-y-2">
                    <div className="flex justify-between items-center">
                      <span className="font-medium capitalize">{category}</span>
                      <span className="text-sm text-muted-foreground">
                        {data.passed}/{data.total} passed
                      </span>
                    </div>
                    <Progress value={(data.passed / data.total) * 100} className="h-2" />
                    <p className="text-sm text-muted-foreground">
                      Average Score: {data.avgScore}%
                    </p>
                  </div>
                ))}
              </CardContent>
            </Card>

            {/* Performance Insights */}
            <Card>
              <CardHeader>
                <CardTitle>Performance Insights</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3">
                  <div className="p-3 bg-blue-50 rounded-lg">
                    <p className="font-medium text-blue-800">Strength Areas</p>
                    <p className="text-sm text-blue-600">
                      Categories where you consistently score above 80%
                    </p>
                  </div>
                  <div className="p-3 bg-yellow-50 rounded-lg">
                    <p className="font-medium text-yellow-800">Improvement Areas</p>
                    <p className="text-sm text-yellow-600">
                      Focus on categories with lower pass rates
                    </p>
                  </div>
                  <div className="p-3 bg-green-50 rounded-lg">
                    <p className="font-medium text-green-800">Next Goals</p>
                    <p className="text-sm text-green-600">
                      Complete remaining tests to earn certifications
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}

export default function TestResults() {
  const config = platformConfigs.candidate;
  const theme = useThemeClasses('candidate');
  
  const usageData = [
    { label: "Tests Completed", current: 15, max: 25 },
    { label: "Average Score", current: 82, max: 100 },
    { label: "Certifications Earned", current: 4, max: 10 },
  ];

  return (
    <PlatformLayout
      sidebarTitle={config.sidebarTitle}
      sidebarSubtitle={config.sidebarSubtitle}
      sidebarSections={config.sidebarSections}
      usageData={usageData}
    >
      <TestResultsContent />
    </PlatformLayout>
  );
}