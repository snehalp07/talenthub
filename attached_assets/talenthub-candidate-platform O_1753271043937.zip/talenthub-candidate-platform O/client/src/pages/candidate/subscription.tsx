import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import PlatformLayout from "@/components/layout/platform-layout";
import { candidateNavigation } from "@/config/complete-navigation";
import { 
  Crown, CreditCard, Calendar, Users, FileText, TrendingUp,
  CheckCircle, AlertCircle, Clock, Zap, Star, Award, 
  Target, Coins, Wallet, ShoppingCart, Gift, Sparkles,
  ArrowRight, BarChart3, Briefcase, Video, Brain, Settings
} from "lucide-react";

const Subscription: React.FC = () => {
  const [activeTab, setActiveTab] = useState('overview');

  // Enhanced subscription data with hybrid billing
  const currentSubscription = {
    plan: "professional",
    status: "active",
    creditsBalance: 347,
    creditsUsedThisMonth: 89,
    nextBilling: "2025-02-15",
    amount: "$299",
    yearlyDiscount: true,
    usageThisMonth: {
      jobApplications: 23,
      jobApplicationsLimit: 35,
      skillAssessments: 12,
      skillAssessmentsLimit: 20,
      aiMockInterviews: 3,
      aiMockInterviewsLimit: 5,
      videoCVs: 1,
      videoCVsLimit: 2
    }
  };

  const subscriptionPlans = [
    {
      id: 'starter',
      name: 'Starter',
      price: '$99',
      period: '/year',
      color: 'from-green-500 to-green-600',
      features: [
        '5 skill assessments/month',
        'Basic profile builder',
        '10 job applications/month',
        'Community access (read-only)',
        'Email support'
      ],
      limitations: [
        'No video CV',
        'No AI features',
        'Basic analytics only'
      ]
    },
    {
      id: 'professional',
      name: 'Professional',
      price: '$299',
      period: '/year',
      color: 'from-blue-500 to-blue-600',
      popular: true,
      features: [
        '20 skill assessments/month',
        'Video CV creation (2 videos)',
        'Advanced profile analytics',
        '35 job applications/month',
        '5 AI mock interviews/month',
        'Basic networking features',
        'Priority email support'
      ],
      limitations: [
        'Limited blockchain features',
        'Basic AI recommendations'
      ]
    },
    {
      id: 'enterprise',
      name: 'Enterprise',
      price: '$599',
      period: '/year',
      color: 'from-purple-500 to-purple-600',
      features: [
        '100 skill assessments/month',
        'Unlimited profile features',
        'Advanced job matching',
        '65 job applications/month',
        '20 AI mock interviews/month',
        'Full networking access',
        'Basic blockchain certifications',
        'Phone + chat support'
      ],
      limitations: []
    }
  ];

  const creditPackages = [
    {
      id: 'small',
      credits: 100,
      price: '$19',
      bonus: 0,
      color: 'from-emerald-500 to-emerald-600',
      popular: false
    },
    {
      id: 'medium',
      credits: 500,
      price: '$79',
      bonus: 25,
      color: 'from-blue-500 to-blue-600',
      popular: true,
      savings: '20%'
    },
    {
      id: 'large',
      credits: 1000,
      price: '$149',
      bonus: 250,
      color: 'from-purple-500 to-purple-600',
      popular: false,
      savings: '25%'
    },
    {
      id: 'xlarge',
      credits: 2500,
      price: '$349',
      bonus: 750,
      color: 'from-indigo-500 to-indigo-600',
      popular: false,
      savings: '30%'
    }
  ];

  const featureCosts = [
    { category: 'Skills & Certification', icon: Award, color: 'text-blue-600', features: [
      { name: 'Premium certification packages', cost: '10-15 credits' },
      { name: 'AI-powered skill gap analysis', cost: '5 credits' },
      { name: 'Industry certification prep', cost: '8 credits' },
      { name: 'Blockchain certificate issuance', cost: '12 credits' }
    ]},
    { category: 'Assessment & Testing', icon: Target, color: 'text-green-600', features: [
      { name: 'Advanced proctored assessments', cost: '12 credits' },
      { name: 'AI coding evaluations', cost: '10 credits' },
      { name: 'Comprehensive skill reports', cost: '5 credits' },
      { name: 'Custom assessment creation', cost: '20 credits' }
    ]},
    { category: 'Profile & Branding', icon: Video, color: 'text-purple-600', features: [
      { name: 'Professional video CV', cost: '15 credits' },
      { name: 'Infographic resume generation', cost: '8 credits' },
      { name: 'AI profile optimization', cost: '5 credits' },
      { name: 'Profile promotion/featuring', cost: '25 credits' }
    ]},
    { category: 'Interview Preparation', icon: Brain, color: 'text-orange-600', features: [
      { name: 'Premium AI mock interviews', cost: '12 credits' },
      { name: '1-on-1 expert coaching', cost: '30 credits' },
      { name: 'Company-specific interview prep', cost: '15 credits' },
      { name: 'Interview performance analytics', cost: '5 credits' }
    ]},
    { category: 'Job Search Enhancement', icon: Briefcase, color: 'text-cyan-600', features: [
      { name: 'AI job matching algorithms', cost: '8 credits' },
      { name: 'Premium job alerts', cost: '3 credits' },
      { name: 'Application tracking insights', cost: '5 credits' },
      { name: 'Recruiter visibility boost', cost: '20 credits' }
    ]},
    { category: 'Project Portfolio', icon: FileText, color: 'text-pink-600', features: [
      { name: 'AI code analysis', cost: '10 credits' },
      { name: 'Project certification', cost: '15 credits' },
      { name: 'Portfolio optimization', cost: '8 credits' },
      { name: 'Expert project review', cost: '25 credits' }
    ]}
  ];

  const getSubscriptionBadge = (status: string) => {
    switch (status) {
      case "active":
        return <Badge className="bg-green-500 text-white hover:bg-green-600 transition-colors">Active</Badge>;
      case "past_due":
        return <Badge variant="destructive">Past Due</Badge>;
      case "canceled":
        return <Badge variant="secondary">Canceled</Badge>;
      case "trial":
        return <Badge className="bg-blue-500 text-white">Trial</Badge>;
      default:
        return <Badge variant="outline">Free</Badge>;
    }
  };

  const getPlanDisplayName = (plan: string) => {
    const planNames: Record<string, string> = {
      "starter": "Starter",
      "professional": "Professional", 
      "enterprise": "Enterprise"
    };
    return planNames[plan] || plan;
  };

  return (
    <PlatformLayout
      sidebarTitle="Candidate Platform"
      sidebarSubtitle="Subscription & Billing"
      sidebarSections={candidateNavigation}
    >
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50">
        {/* Header Section */}
        <div className="bg-gradient-to-r from-blue-600 to-purple-600 text-white p-8">
          <div className="max-w-7xl mx-auto">
            <div className="flex items-center gap-3 mb-4">
              <Crown className="h-8 w-8" />
              <h1 className="text-3xl font-bold">Subscription & Billing</h1>
            </div>
            <p className="text-blue-100 text-lg">
              Hybrid billing model: Annual subscription + pay-per-usage for premium features
            </p>
          </div>
        </div>

        <div className="max-w-7xl mx-auto p-8">
          <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="overview" className="flex items-center gap-2">
                <BarChart3 className="h-4 w-4" />
                Overview
              </TabsTrigger>
              <TabsTrigger value="plans" className="flex items-center gap-2">
                <Crown className="h-4 w-4" />
                Subscription Plans
              </TabsTrigger>
              <TabsTrigger value="credits" className="flex items-center gap-2">
                <Coins className="h-4 w-4" />
                Credit Packages
              </TabsTrigger>
              <TabsTrigger value="features" className="flex items-center gap-2">
                <Zap className="h-4 w-4" />
                Feature Costs
              </TabsTrigger>
            </TabsList>

            {/* Overview Tab */}
            <TabsContent value="overview" className="space-y-6">
              {/* Current Subscription Card */}
              <Card className="bg-gradient-to-r from-blue-500 to-purple-600 text-white">
                <CardHeader>
                  <CardTitle className="flex items-center justify-between">
                    <span className="flex items-center gap-2">
                      <Crown className="h-6 w-6" />
                      Current Subscription
                    </span>
                    {getSubscriptionBadge(currentSubscription.status)}
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                    <div>
                      <div className="text-blue-100 text-sm">Plan</div>
                      <div className="text-xl font-bold">{getPlanDisplayName(currentSubscription.plan)}</div>
                    </div>
                    <div>
                      <div className="text-blue-100 text-sm">Next Billing</div>
                      <div className="text-xl font-bold">{currentSubscription.nextBilling}</div>
                    </div>
                    <div>
                      <div className="text-blue-100 text-sm">Amount</div>
                      <div className="text-xl font-bold">{currentSubscription.amount}/year</div>
                    </div>
                    <div>
                      <div className="text-blue-100 text-sm">Credits Balance</div>
                      <div className="text-xl font-bold flex items-center gap-1">
                        <Coins className="h-5 w-5" />
                        {currentSubscription.creditsBalance}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Usage Overview */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <TrendingUp className="h-5 w-5 text-blue-600" />
                      Monthly Usage Tracking
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div>
                      <div className="flex justify-between text-sm mb-1">
                        <span>Job Applications</span>
                        <span>{currentSubscription.usageThisMonth.jobApplications}/{currentSubscription.usageThisMonth.jobApplicationsLimit}</span>
                      </div>
                      <Progress value={(currentSubscription.usageThisMonth.jobApplications / currentSubscription.usageThisMonth.jobApplicationsLimit) * 100} className="h-2" />
                    </div>
                    <div>
                      <div className="flex justify-between text-sm mb-1">
                        <span>Skill Assessments</span>
                        <span>{currentSubscription.usageThisMonth.skillAssessments}/{currentSubscription.usageThisMonth.skillAssessmentsLimit}</span>
                      </div>
                      <Progress value={(currentSubscription.usageThisMonth.skillAssessments / currentSubscription.usageThisMonth.skillAssessmentsLimit) * 100} className="h-2" />
                    </div>
                    <div>
                      <div className="flex justify-between text-sm mb-1">
                        <span>AI Mock Interviews</span>
                        <span>{currentSubscription.usageThisMonth.aiMockInterviews}/{currentSubscription.usageThisMonth.aiMockInterviewsLimit}</span>
                      </div>
                      <Progress value={(currentSubscription.usageThisMonth.aiMockInterviews / currentSubscription.usageThisMonth.aiMockInterviewsLimit) * 100} className="h-2" />
                    </div>
                    <div>
                      <div className="flex justify-between text-sm mb-1">
                        <span>Video CVs Created</span>
                        <span>{currentSubscription.usageThisMonth.videoCVs}/{currentSubscription.usageThisMonth.videoCVsLimit}</span>
                      </div>
                      <Progress value={(currentSubscription.usageThisMonth.videoCVs / currentSubscription.usageThisMonth.videoCVsLimit) * 100} className="h-2" />
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Wallet className="h-5 w-5 text-green-600" />
                      Credits Activity
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-gray-600">Current Balance</span>
                      <span className="font-bold text-green-600">{currentSubscription.creditsBalance} credits</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-gray-600">Used This Month</span>
                      <span className="font-medium">{currentSubscription.creditsUsedThisMonth} credits</span>
                    </div>
                    <div className="pt-4 border-t">
                      <Button className="w-full bg-gradient-to-r from-green-500 to-blue-500 hover:from-green-600 hover:to-blue-600">
                        <ShoppingCart className="h-4 w-4 mr-2" />
                        Buy More Credits
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Smart Recommendations */}
              <Card className="bg-gradient-to-r from-orange-500 to-pink-600 text-white">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Sparkles className="h-6 w-6" />
                    Smart Billing Recommendations
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div className="flex items-center gap-3 p-3 bg-white/10 rounded-lg">
                    <AlertCircle className="h-5 w-5" />
                    <span>You've used 65% of your job applications limit. Consider upgrading to Enterprise for more allowances.</span>
                  </div>
                  <div className="flex items-center gap-3 p-3 bg-white/10 rounded-lg">
                    <Gift className="h-5 w-5" />
                    <span>Buy 500+ credits this month and get 25% bonus credits!</span>
                  </div>
                  <div className="flex gap-3 mt-4">
                    <Button className="bg-white text-orange-600 hover:bg-gray-100 flex-1">
                      <BarChart3 className="h-4 w-4 mr-2" />
                      View Detailed Analytics
                    </Button>
                    <Button variant="outline" className="border-white text-white hover:bg-white/10">
                      <Settings className="h-4 w-4 mr-2" />
                      Optimize Usage
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Subscription Plans Tab */}
            <TabsContent value="plans" className="space-y-6">
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                {subscriptionPlans.map(plan => (
                  <Card key={plan.id} className={`relative hover:shadow-lg transition-all duration-300 ${plan.popular ? 'ring-2 ring-blue-500' : ''}`}>
                    {plan.popular && (
                      <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                        <Badge className="bg-blue-500 text-white px-4 py-1">Most Popular</Badge>
                      </div>
                    )}
                    <div className={`h-24 bg-gradient-to-r ${plan.color} flex items-center justify-center`}>
                      <Crown className="h-12 w-12 text-white" />
                    </div>
                    
                    <CardHeader>
                      <CardTitle className="text-xl">{plan.name}</CardTitle>
                      <div className="flex items-baseline gap-1">
                        <span className="text-3xl font-bold">{plan.price}</span>
                        <span className="text-gray-600">{plan.period}</span>
                      </div>
                    </CardHeader>
                    
                    <CardContent className="space-y-4">
                      <div>
                        <div className="text-sm font-medium text-gray-700 mb-3">Features Included:</div>
                        <ul className="space-y-2">
                          {plan.features.map((feature, index) => (
                            <li key={index} className="flex items-start gap-2 text-sm">
                              <CheckCircle className="h-4 w-4 text-green-600 mt-0.5 flex-shrink-0" />
                              {feature}
                            </li>
                          ))}
                        </ul>
                      </div>
                      
                      {plan.limitations.length > 0 && (
                        <div>
                          <div className="text-sm font-medium text-gray-700 mb-3">Limitations:</div>
                          <ul className="space-y-2">
                            {plan.limitations.map((limitation, index) => (
                              <li key={index} className="flex items-start gap-2 text-sm text-gray-600">
                                <AlertCircle className="h-4 w-4 text-orange-500 mt-0.5 flex-shrink-0" />
                                {limitation}
                              </li>
                            ))}
                          </ul>
                        </div>
                      )}
                      
                      <Button 
                        className={`w-full ${plan.id === currentSubscription.plan ? 'bg-green-600 hover:bg-green-700' : ''}`}
                        disabled={plan.id === currentSubscription.plan}
                      >
                        {plan.id === currentSubscription.plan ? 'Current Plan' : 'Upgrade Plan'}
                      </Button>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </TabsContent>

            {/* Credit Packages Tab */}
            <TabsContent value="credits" className="space-y-6">
              <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-4 gap-6">
                {creditPackages.map(pkg => (
                  <Card key={pkg.id} className={`hover:shadow-lg transition-all duration-300 ${pkg.popular ? 'ring-2 ring-blue-500' : ''}`}>
                    {pkg.popular && (
                      <div className="absolute -top-3 left-1/2 transform -translate-x-1/2">
                        <Badge className="bg-blue-500 text-white px-3 py-1">Best Value</Badge>
                      </div>
                    )}
                    <div className={`h-32 bg-gradient-to-r ${pkg.color} flex items-center justify-center relative`}>
                      <Coins className="h-16 w-16 text-white" />
                      {pkg.savings && (
                        <Badge className="absolute top-3 right-3 bg-white text-gray-800">
                          Save {pkg.savings}
                        </Badge>
                      )}
                    </div>
                    
                    <CardHeader className="text-center">
                      <CardTitle className="text-2xl">{pkg.credits.toLocaleString()}</CardTitle>
                      <CardDescription>Credits</CardDescription>
                      {pkg.bonus > 0 && (
                        <Badge className="bg-green-100 text-green-800 w-fit mx-auto">
                          +{pkg.bonus} Bonus Credits
                        </Badge>
                      )}
                    </CardHeader>
                    
                    <CardContent className="text-center space-y-4">
                      <div className="text-3xl font-bold">{pkg.price}</div>
                      {pkg.bonus > 0 && (
                        <div className="text-sm text-gray-600">
                          Total: {(pkg.credits + pkg.bonus).toLocaleString()} credits
                        </div>
                      )}
                      <Button className="w-full">
                        <ShoppingCart className="h-4 w-4 mr-2" />
                        Purchase Credits
                      </Button>
                    </CardContent>
                  </Card>
                ))}
              </div>
              
              {/* Credit Usage Tips */}
              <Card className="bg-gradient-to-r from-cyan-500 to-teal-600 text-white">
                <CardContent className="p-6">
                  <h3 className="text-xl font-bold mb-4 flex items-center gap-2">
                    <Sparkles className="h-6 w-6" />
                    Smart Credit Tips
                  </h3>
                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                    <div className="flex items-start gap-3">
                      <Target className="h-5 w-5 mt-1" />
                      <div>
                        <div className="font-medium">Bundle Features</div>
                        <div className="text-cyan-100 text-sm">Use 3+ features together for 20% credit savings</div>
                      </div>
                    </div>
                    <div className="flex items-start gap-3">
                      <Calendar className="h-5 w-5 mt-1" />
                      <div>
                        <div className="font-medium">Monthly Predictions</div>
                        <div className="text-cyan-100 text-sm">Based on usage, expect ~120 credits/month</div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Feature Costs Tab */}
            <TabsContent value="features" className="space-y-6">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {featureCosts.map((category, index) => {
                  const Icon = category.icon;
                  return (
                    <Card key={index} className="hover:shadow-lg transition-all duration-300">
                      <CardHeader>
                        <CardTitle className="flex items-center gap-3">
                          <Icon className={`h-6 w-6 ${category.color}`} />
                          {category.category}
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-3">
                          {category.features.map((feature, featureIndex) => (
                            <div key={featureIndex} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
                              <span className="text-sm font-medium">{feature.name}</span>
                              <Badge variant="outline" className="font-bold">
                                {feature.cost}
                              </Badge>
                            </div>
                          ))}
                        </div>
                      </CardContent>
                    </Card>
                  );
                })}
              </div>

              {/* Cost Calculator CTA */}
              <Card className="bg-gradient-to-r from-indigo-500 to-purple-600 text-white">
                <CardContent className="p-8 text-center">
                  <h3 className="text-2xl font-bold mb-4">Cost Calculator & Optimizer</h3>
                  <p className="text-indigo-100 mb-6">
                    Get personalized recommendations on the most cost-effective way to use TalentHub features
                  </p>
                  <div className="flex justify-center gap-4">
                    <Button className="bg-white text-indigo-600 hover:bg-gray-100">
                      <BarChart3 className="h-4 w-4 mr-2" />
                      Calculate Costs
                    </Button>
                    <Button variant="outline" className="border-white text-white hover:bg-white/10">
                      <ArrowRight className="h-4 w-4 mr-2" />
                      View Usage Patterns
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </PlatformLayout>
  );
};

export default Subscription;