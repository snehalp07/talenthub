import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import PlatformLayout from "@/components/layout/platform-layout";
import { platformConfigs } from "@/config/complete-navigation";
import { useThemeClasses, type PlatformType } from "@/lib/theme-config";
import {
  MessageSquare,
  Calendar,
  Clock,
  MapPin,
  Phone,
  Video,
  Mail,
  Send,
  CheckCircle,
  AlertCircle,
  User,
  Building,
  Filter,
  Search,
  Plus,
  Edit,
  Trash2,
  Download,
  Eye,
  ExternalLink
} from "lucide-react";

export default function InterviewCommunication() {
  const config = platformConfigs.candidate;
  const themeClasses = useThemeClasses('candidate' as PlatformType);
  const [selectedMessage, setSelectedMessage] = useState<number | null>(null);
  const [newMessage, setNewMessage] = useState("");

  // Sample data for interview communications
  const conversations = [
    {
      id: 1,
      company: "TechCorp Solutions",
      position: "Senior Full Stack Developer",
      recruiter: "Sarah Johnson",
      avatar: "/avatars/sarah.jpg",
      lastMessage: "Thank you for your interest. We'd like to schedule an interview for next week.",
      timestamp: "2 hours ago",
      unread: 2,
      status: "active"
    },
    {
      id: 2,
      company: "InnovateTech Inc",
      position: "React Developer",
      recruiter: "Mike Chen",
      avatar: "/avatars/mike.jpg",
      lastMessage: "Please confirm your availability for Tuesday at 3 PM.",
      timestamp: "1 day ago",
      unread: 0,
      status: "pending"
    },
    {
      id: 3,
      company: "DataFlow Systems",
      position: "Frontend Engineer",
      recruiter: "Lisa Wang",
      avatar: "/avatars/lisa.jpg",
      lastMessage: "We've reviewed your application and would like to proceed to the next round.",
      timestamp: "3 days ago",
      unread: 1,
      status: "active"
    }
  ];

  const messages = [
    {
      id: 1,
      sender: "recruiter",
      name: "Sarah Johnson",
      message: "Hi! Thank you for applying to our Senior Full Stack Developer position. We're impressed with your background.",
      timestamp: "Yesterday 2:30 PM"
    },
    {
      id: 2,
      sender: "candidate",
      name: "You",
      message: "Thank you for considering my application. I'm very interested in this opportunity.",
      timestamp: "Yesterday 3:15 PM"
    },
    {
      id: 3,
      sender: "recruiter",
      name: "Sarah Johnson",
      message: "Great! We'd like to schedule a technical interview. Are you available next Tuesday or Wednesday?",
      timestamp: "Today 10:00 AM"
    }
  ];

  // Handler functions for message functionality
  const handleSendMessage = () => {
    if (!newMessage.trim()) return;
    
    // In a real app, this would send the message to the backend
    console.log('Sending message:', newMessage);
    
    // Clear the message input
    setNewMessage("");
    
    // Show success feedback (optional)
    // You could add a toast notification here if desired
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const upcomingInterviews = [
    {
      id: 1,
      company: "TechCorp Solutions",
      position: "Senior Full Stack Developer",
      date: "2024-01-25",
      time: "2:00 PM",
      duration: "60 minutes",
      type: "Technical Interview",
      format: "Video Call",
      interviewer: "John Smith",
      status: "confirmed",
      meetingLink: "https://meet.google.com/abc-def-ghi"
    },
    {
      id: 2,
      company: "InnovateTech Inc",
      position: "React Developer",
      date: "2024-01-27",
      time: "10:30 AM",
      duration: "45 minutes",
      type: "HR Interview",
      format: "Phone Call",
      interviewer: "Emily Davis",
      status: "pending",
      phone: "+1 (555) 123-4567"
    }
  ];

  const availabilitySlots = [
    { date: "2024-01-29", time: "9:00 AM", available: true },
    { date: "2024-01-29", time: "2:00 PM", available: false },
    { date: "2024-01-30", time: "10:00 AM", available: true },
    { date: "2024-01-30", time: "3:00 PM", available: true },
    { date: "2024-01-31", time: "11:00 AM", available: true },
    { date: "2024-01-31", time: "4:00 PM", available: false }
  ];

  return (
    <PlatformLayout
      sidebarTitle={config.sidebarTitle}
      sidebarSubtitle={config.sidebarSubtitle}
      sidebarSections={config.sidebarSections}
      usageData={config.usageData}
    >
      <div className="space-y-6">
        {/* Header */}
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Interview Communication</h1>
          <p className="text-gray-600 mt-2">
            Manage all your interview communications, scheduling, and status in one place
          </p>
        </div>

        {/* Tabs */}
        <Tabs defaultValue="communication" className="space-y-6">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="communication" className="flex items-center gap-2">
              <MessageSquare className="w-4 h-4" />
              Communication
              <Badge variant="secondary" className="ml-1">3</Badge>
            </TabsTrigger>
            <TabsTrigger value="scheduling" className="flex items-center gap-2">
              <Calendar className="w-4 h-4" />
              Scheduling
              <Badge variant="secondary" className="ml-1">2</Badge>
            </TabsTrigger>
            <TabsTrigger value="status" className="flex items-center gap-2">
              <CheckCircle className="w-4 h-4" />
              Status
              <Badge variant="secondary" className="ml-1">5</Badge>
            </TabsTrigger>
          </TabsList>

          {/* Communication Tab */}
          <TabsContent value="communication" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Conversations List */}
              <div className="lg:col-span-1">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center justify-between">
                      Conversations
                      <Button size="sm" variant="outline">
                        <Filter className="w-4 h-4" />
                      </Button>
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="p-0">
                    <div className="space-y-0">
                      {conversations.map((conv) => (
                        <div
                          key={conv.id}
                          className={`p-4 border-b cursor-pointer hover:bg-gray-50 transition-colors ${
                            selectedMessage === conv.id ? 'bg-sky-50 border-r-4 border-r-sky-500' : ''
                          }`}
                          onClick={() => setSelectedMessage(conv.id)}
                        >
                          <div className="flex items-start gap-3">
                            <Avatar className="w-10 h-10">
                              <AvatarFallback>{conv.recruiter.split(' ').map(n => n[0]).join('')}</AvatarFallback>
                            </Avatar>
                            <div className="flex-1 min-w-0">
                              <div className="flex items-center justify-between mb-1">
                                <p className="font-medium text-sm truncate">{conv.company}</p>
                                {conv.unread > 0 && (
                                  <Badge variant="default" className="text-xs px-1.5 py-0.5">
                                    {conv.unread}
                                  </Badge>
                                )}
                              </div>
                              <p className="text-xs text-gray-600 truncate">{conv.position}</p>
                              <p className="text-xs text-gray-500 truncate mt-1">{conv.lastMessage}</p>
                              <p className="text-xs text-gray-400 mt-1">{conv.timestamp}</p>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Message Thread */}
              <div className="lg:col-span-2">
                <Card className="h-[600px] flex flex-col">
                  {selectedMessage ? (
                    <>
                      {/* Message Header */}
                      <CardHeader className="border-b">
                        <div className="flex items-center justify-between">
                          <div>
                            <CardTitle className="text-lg">TechCorp Solutions</CardTitle>
                            <CardDescription>Senior Full Stack Developer • Sarah Johnson</CardDescription>
                          </div>
                          <div className="flex gap-2">
                            <Button size="sm" variant="outline">
                              <Phone className="w-4 h-4" />
                            </Button>
                            <Button size="sm" variant="outline">
                              <Video className="w-4 h-4" />
                            </Button>
                          </div>
                        </div>
                      </CardHeader>

                      {/* Messages */}
                      <CardContent className="flex-1 overflow-y-auto p-4">
                        <div className="space-y-4">
                          {messages.map((msg) => (
                            <div
                              key={msg.id}
                              className={`flex ${msg.sender === 'candidate' ? 'justify-end' : 'justify-start'}`}
                            >
                              <div className={`max-w-xs lg:max-w-md px-4 py-2 rounded-lg ${
                                msg.sender === 'candidate'
                                  ? 'bg-sky-500 text-white'
                                  : 'bg-gray-100 text-gray-900'
                              }`}>
                                <p className="text-sm">{msg.message}</p>
                                <p className={`text-xs mt-1 ${
                                  msg.sender === 'candidate' ? 'text-sky-100' : 'text-gray-500'
                                }`}>
                                  {msg.timestamp}
                                </p>
                              </div>
                            </div>
                          ))}
                        </div>
                      </CardContent>

                      {/* Message Input */}
                      <div className="border-t p-4">
                        <div className="flex gap-2">
                          <Textarea
                            placeholder="Type your message..."
                            value={newMessage}
                            onChange={(e) => setNewMessage(e.target.value)}
                            onKeyDown={handleKeyPress}
                            className="flex-1 min-h-[60px]"
                          />
                          <Button 
                            size="sm" 
                            className="self-end bg-sky-600 hover:bg-sky-700"
                            onClick={handleSendMessage}
                            disabled={!newMessage.trim()}
                          >
                            <Send className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                    </>
                  ) : (
                    <div className="flex-1 flex items-center justify-center text-gray-500">
                      <div className="text-center">
                        <MessageSquare className="w-12 h-12 mx-auto mb-4 text-gray-300" />
                        <p>Select a conversation to start messaging</p>
                      </div>
                    </div>
                  )}
                </Card>
              </div>
            </div>
          </TabsContent>

          {/* Scheduling Tab */}
          <TabsContent value="scheduling" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Upcoming Interviews */}
              <Card>
                <CardHeader>
                  <CardTitle>Upcoming Interviews</CardTitle>
                  <CardDescription>Your confirmed and pending interviews</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  {upcomingInterviews.map((interview) => (
                    <div key={interview.id} className="border rounded-lg p-4">
                      <div className="flex items-start justify-between mb-3">
                        <div>
                          <h4 className="font-medium">{interview.company}</h4>
                          <p className="text-sm text-gray-600">{interview.position}</p>
                        </div>
                        <Badge variant={interview.status === 'confirmed' ? 'default' : 'secondary'}>
                          {interview.status}
                        </Badge>
                      </div>
                      
                      <div className="space-y-2 text-sm">
                        <div className="flex items-center gap-2">
                          <Calendar className="w-4 h-4 text-gray-400" />
                          <span>{interview.date} at {interview.time}</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <Clock className="w-4 h-4 text-gray-400" />
                          <span>{interview.duration} • {interview.type}</span>
                        </div>
                        <div className="flex items-center gap-2">
                          {interview.format === 'Video Call' ? (
                            <Video className="w-4 h-4 text-gray-400" />
                          ) : (
                            <Phone className="w-4 h-4 text-gray-400" />
                          )}
                          <span>{interview.format}</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <User className="w-4 h-4 text-gray-400" />
                          <span>with {interview.interviewer}</span>
                        </div>
                      </div>

                      <div className="flex gap-2 mt-4">
                        {interview.meetingLink && (
                          <Button size="sm" variant="outline" className="flex items-center gap-1">
                            <ExternalLink className="w-3 h-3" />
                            Join Call
                          </Button>
                        )}
                        <Button size="sm" variant="outline" className="flex items-center gap-1">
                          <Edit className="w-3 h-3" />
                          Reschedule
                        </Button>
                      </div>
                    </div>
                  ))}
                </CardContent>
              </Card>

              {/* Availability Management */}
              <Card>
                <CardHeader>
                  <CardTitle>Set Your Availability</CardTitle>
                  <CardDescription>Update your available time slots for interviews</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="start-date">Start Date</Label>
                      <Input type="date" id="start-date" />
                    </div>
                    <div>
                      <Label htmlFor="end-date">End Date</Label>
                      <Input type="date" id="end-date" />
                    </div>
                  </div>

                  <div>
                    <Label>Preferred Time Slots</Label>
                    <div className="grid grid-cols-2 gap-2 mt-2">
                      {['9:00 AM', '10:00 AM', '11:00 AM', '2:00 PM', '3:00 PM', '4:00 PM'].map((time) => (
                        <Button
                          key={time}
                          variant="outline"
                          size="sm"
                          className="justify-start"
                        >
                          {time}
                        </Button>
                      ))}
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="timezone">Timezone</Label>
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="Select timezone" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="ist">India Standard Time (IST)</SelectItem>
                        <SelectItem value="pst">Pacific Standard Time (PST)</SelectItem>
                        <SelectItem value="est">Eastern Standard Time (EST)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <Button className="w-full">
                    <Plus className="w-4 h-4 mr-2" />
                    Update Availability
                  </Button>

                  {/* Current Availability */}
                  <div className="border-t pt-4">
                    <h4 className="font-medium mb-3">Current Availability</h4>
                    <div className="space-y-2">
                      {availabilitySlots.map((slot, index) => (
                        <div key={index} className="flex items-center justify-between text-sm">
                          <span>{slot.date} at {slot.time}</span>
                          <Badge variant={slot.available ? 'default' : 'secondary'}>
                            {slot.available ? 'Available' : 'Booked'}
                          </Badge>
                        </div>
                      ))}
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Status Tab */}
          <TabsContent value="status" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Interview Pipeline */}
              <Card>
                <CardHeader>
                  <CardTitle>Interview Pipeline</CardTitle>
                  <CardDescription>Track your progress across different companies</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  {[
                    { company: "TechCorp Solutions", stage: "Technical Interview", status: "scheduled", date: "Jan 25" },
                    { company: "InnovateTech Inc", stage: "HR Screen", status: "completed", date: "Jan 20" },
                    { company: "DataFlow Systems", stage: "Final Round", status: "pending", date: "Jan 30" },
                    { company: "CloudTech Ltd", stage: "Application Review", status: "in-progress", date: "Jan 15" },
                    { company: "StartupXYZ", stage: "Rejected", status: "rejected", date: "Jan 18" }
                  ].map((item, index) => (
                    <div key={index} className="flex items-center justify-between p-3 border rounded-lg">
                      <div>
                        <p className="font-medium">{item.company}</p>
                        <p className="text-sm text-gray-600">{item.stage}</p>
                        <p className="text-xs text-gray-500">{item.date}</p>
                      </div>
                      <Badge 
                        variant={
                          item.status === 'completed' ? 'default' :
                          item.status === 'scheduled' ? 'secondary' :
                          item.status === 'rejected' ? 'destructive' : 'outline'
                        }
                      >
                        {item.status}
                      </Badge>
                    </div>
                  ))}
                </CardContent>
              </Card>

              {/* Interview History */}
              <Card>
                <CardHeader>
                  <CardTitle>Interview History</CardTitle>
                  <CardDescription>Your completed interviews and feedback</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  {[
                    { 
                      company: "TechFlow Inc", 
                      position: "Frontend Developer",
                      date: "Jan 15, 2024",
                      feedback: "Strong technical skills, good communication",
                      rating: 4.5,
                      outcome: "Offer Extended"
                    },
                    { 
                      company: "DevCorp", 
                      position: "React Developer",
                      date: "Jan 10, 2024",
                      feedback: "Excellent problem-solving abilities",
                      rating: 4.8,
                      outcome: "Offer Extended"
                    },
                    { 
                      company: "WebTech Solutions", 
                      position: "Full Stack Developer",
                      date: "Jan 5, 2024",
                      feedback: "Good technical knowledge, needs more experience",
                      rating: 3.5,
                      outcome: "Not Selected"
                    }
                  ].map((interview, index) => (
                    <div key={index} className="border rounded-lg p-4">
                      <div className="flex items-start justify-between mb-2">
                        <div>
                          <h4 className="font-medium">{interview.company}</h4>
                          <p className="text-sm text-gray-600">{interview.position}</p>
                          <p className="text-xs text-gray-500">{interview.date}</p>
                        </div>
                        <Badge variant={interview.outcome === 'Offer Extended' ? 'default' : 'secondary'}>
                          {interview.outcome}
                        </Badge>
                      </div>
                      
                      <div className="space-y-2">
                        <div className="flex items-center gap-2">
                          <span className="text-sm font-medium">Rating:</span>
                          <div className="flex items-center gap-1">
                            <span className="text-sm">{interview.rating}/5</span>
                            <div className="flex">
                              {[1,2,3,4,5].map((star) => (
                                <div
                                  key={star}
                                  className={`w-3 h-3 ${
                                    star <= interview.rating ? 'text-yellow-400' : 'text-gray-300'
                                  }`}
                                >
                                  ⭐
                                </div>
                              ))}
                            </div>
                          </div>
                        </div>
                        <div>
                          <span className="text-sm font-medium">Feedback:</span>
                          <p className="text-sm text-gray-600 mt-1">{interview.feedback}</p>
                        </div>
                      </div>

                      <div className="flex gap-2 mt-3">
                        <Button size="sm" variant="outline">
                          <Eye className="w-3 h-3 mr-1" />
                          View Details
                        </Button>
                        <Button size="sm" variant="outline">
                          <Download className="w-3 h-3 mr-1" />
                          Export
                        </Button>
                      </div>
                    </div>
                  ))}
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </PlatformLayout>
  );
}