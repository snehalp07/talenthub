import { useState } from "react";
import { useAuth } from "@/hooks/use-auth";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { useToast } from "@/hooks/use-toast";
import { 
  Compass, 
  Target, 
  TrendingUp, 
  Star, 
  BookOpen,
  Users,
  Calendar,
  MessageSquare,
  CheckCircle,
  ArrowRight,
  Lightbulb,
  Award,
  Briefcase,
  GraduationCap,
  Clock,
  MapPin,
  DollarSign,
  BarChart3,
  Zap,
  Brain,
  Rocket,
  Shield
} from "lucide-react";
import PlatformLayout from "@/components/layout/platform-layout";
import { platformConfigs } from "@/config/complete-navigation";

function CareerGuidanceContent() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [selectedGoal, setSelectedGoal] = useState("");
  const [currentStep, setCurrentStep] = useState(1);

  const { data: careerAssessment } = useQuery({
    queryKey: ["/api/career/assessment"],
    initialData: {
      currentRole: "Full Stack Developer",
      experienceLevel: "Mid-level",
      strengths: ["Problem Solving", "Technical Skills", "Leadership"],
      areasForImprovement: ["Public Speaking", "Project Management", "Data Analytics"],
      careerGoals: ["Senior Developer", "Tech Lead", "Engineering Manager"],
      timeframe: "2-3 years",
      preferredIndustries: ["Technology", "FinTech", "Healthcare"],
      skillGaps: [
        { skill: "System Design", currentLevel: 3, targetLevel: 5, priority: "high" },
        { skill: "Team Leadership", currentLevel: 2, targetLevel: 4, priority: "medium" },
        { skill: "Cloud Architecture", currentLevel: 3, targetLevel: 5, priority: "high" }
      ]
    }
  });

  const { data: careerPaths } = useQuery({
    queryKey: ["/api/career/paths"],
    initialData: [
      {
        id: "tech-lead",
        title: "Technical Lead",
        description: "Lead technical decisions and mentor development teams",
        timeToAchieve: "18-24 months",
        difficulty: "Medium",
        averageSalary: "₹25-35 LPA",
        demandLevel: "High",
        requiredSkills: ["System Design", "Team Leadership", "Architecture", "Mentoring"],
        steps: [
          "Master system design principles",
          "Lead 2-3 major projects",
          "Mentor junior developers",
          "Obtain cloud certifications"
        ],
        companies: ["Google", "Microsoft", "Amazon", "Flipkart", "Zomato"]
      },
      {
        id: "senior-dev",
        title: "Senior Software Engineer",
        description: "Expert-level individual contributor role",
        timeToAchieve: "12-18 months",
        difficulty: "Medium",
        averageSalary: "₹20-30 LPA",
        demandLevel: "Very High",
        requiredSkills: ["Advanced Programming", "System Design", "Performance Optimization"],
        steps: [
          "Deepen technical expertise",
          "Contribute to open source",
          "Lead technical initiatives",
          "Master multiple technologies"
        ],
        companies: ["Swiggy", "PayTM", "Razorpay", "Ola", "PhonePe"]
      },
      {
        id: "product-manager",
        title: "Product Manager",
        description: "Drive product strategy and development",
        timeToAchieve: "24-36 months",
        difficulty: "High",
        averageSalary: "₹30-50 LPA",
        demandLevel: "High",
        requiredSkills: ["Product Strategy", "Analytics", "User Research", "Business Acumen"],
        steps: [
          "Learn product management fundamentals",
          "Work closely with product teams",
          "Develop business analysis skills",
          "Get PM certification"
        ],
        companies: ["Spotify", "Airbnb", "Uber", "BookMyShow", "Myntra"]
      }
    ]
  });

  const { data: learningPath } = useQuery({
    queryKey: ["/api/career/learning-path"],
    initialData: {
      currentProgress: 35,
      totalMilestones: 12,
      completedMilestones: 4,
      nextMilestone: {
        title: "System Design Mastery",
        description: "Complete advanced system design course and projects",
        estimatedTime: "6 weeks",
        resources: [
          "System Design Interview Course",
          "Designing Data-Intensive Applications Book", 
          "3 Hands-on Projects"
        ]
      },
      upcomingMilestones: [
        {
          title: "Leadership Skills Development",
          description: "Complete leadership training and mentor 2 junior developers",
          estimatedTime: "8 weeks"
        },
        {
          title: "Cloud Architecture Certification",
          description: "Obtain AWS Solutions Architect certification",
          estimatedTime: "10 weeks"
        }
      ]
    }
  });

  const { data: mentorshipProgram } = useQuery({
    queryKey: ["/api/career/mentorship"],
    initialData: {
      currentMentor: {
        name: "Priya Sharma",
        role: "Senior Engineering Manager",
        company: "Microsoft",
        experience: "12 years",
        expertise: ["System Design", "Team Leadership", "Career Growth"],
        rating: 4.9,
        sessions: 8,
        nextSession: "2024-06-12T15:00:00Z"
      },
      availableMentors: [
        {
          name: "Rajesh Kumar",
          role: "Principal Engineer",
          company: "Google",
          experience: "15 years",
          expertise: ["Distributed Systems", "Microservices", "Performance"],
          rating: 4.8,
          price: "₹2,000/hour"
        },
        {
          name: "Sneha Patel",
          role: "VP Engineering",
          company: "Zomato",
          experience: "18 years",
          expertise: ["Engineering Leadership", "Scaling Teams", "Product Development"],
          rating: 4.9,
          price: "₹3,500/hour"
        }
      ]
    }
  });

  const { data: industryInsights } = useQuery({
    queryKey: ["/api/career/industry-insights"],
    initialData: {
      trending: [
        {
          skill: "AI/Machine Learning",
          growth: "+45%",
          demandLevel: "Very High",
          averageSalary: "₹35-60 LPA"
        },
        {
          skill: "Cloud Architecture",
          growth: "+38%",
          demandLevel: "High",
          averageSalary: "₹25-45 LPA"
        },
        {
          skill: "DevOps/SRE",
          growth: "+32%",
          demandLevel: "High",
          averageSalary: "₹20-40 LPA"
        }
      ],
      marketAnalysis: {
        totalJobs: "2.4M+",
        growthRate: "22%",
        topCities: ["Bangalore", "Hyderabad", "Pune", "Mumbai", "Chennai"],
        topCompanies: ["TCS", "Infosys", "Wipro", "Tech Mahindra", "Amazon"]
      }
    }
  });

  const bookMentorSessionMutation = useMutation({
    mutationFn: async (mentorData: any) => {
      return apiRequest("POST", "/api/career/book-mentor", mentorData);
    },
    onSuccess: () => {
      toast({
        title: "Session Booked",
        description: "Your mentorship session has been scheduled successfully.",
      });
    },
  });

  const getDifficultyColor = (difficulty: string) => {
    const colors = {
      "Easy": "bg-green-100 text-green-800",
      "Medium": "bg-yellow-100 text-yellow-800", 
      "Hard": "bg-red-100 text-red-800",
      "High": "bg-red-100 text-red-800"
    };
    return colors[difficulty as keyof typeof colors] || colors.Medium;
  };

  const getDemandColor = (demand: string) => {
    const colors = {
      "Low": "bg-gray-100 text-gray-800",
      "Medium": "bg-blue-100 text-blue-800",
      "High": "bg-green-100 text-green-800",
      "Very High": "bg-purple-100 text-purple-800"
    };
    return colors[demand as keyof typeof colors] || colors.Medium;
  };

  return (
    <div className="max-w-7xl mx-auto p-6">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Career Guidance Center</h1>
        <p className="text-muted-foreground">Personalized career roadmaps and expert guidance for your professional growth</p>
      </div>

      <Tabs defaultValue="roadmap" className="space-y-6">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="roadmap">Career Roadmap</TabsTrigger>
          <TabsTrigger value="paths">Career Paths</TabsTrigger>
          <TabsTrigger value="mentorship">Mentorship</TabsTrigger>
          <TabsTrigger value="insights">Industry Insights</TabsTrigger>
          <TabsTrigger value="assessment">Assessment</TabsTrigger>
        </TabsList>

        <TabsContent value="roadmap" className="space-y-6">
          {/* Progress Overview */}
          <Card className="bg-gradient-to-r from-blue-50 to-sky-50 border-blue-200">
            <CardHeader>
              <CardTitle className="flex items-center">
                <Target className="w-5 h-5 mr-2 text-blue-600" />
                Your Career Progress
              </CardTitle>
              <CardDescription>
                Track your journey toward your career goals
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
                <div className="text-center">
                  <div className="text-3xl font-bold text-blue-600 mb-1">
                    {learningPath.currentProgress}%
                  </div>
                  <div className="text-sm text-gray-600">Overall Progress</div>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold text-green-600 mb-1">
                    {learningPath.completedMilestones}/{learningPath.totalMilestones}
                  </div>
                  <div className="text-sm text-gray-600">Milestones Completed</div>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold text-purple-600 mb-1">
                    {careerAssessment.timeframe}
                  </div>
                  <div className="text-sm text-gray-600">Target Timeline</div>
                </div>
              </div>
              <Progress value={learningPath.currentProgress} className="mb-4" />
              <p className="text-sm text-gray-600 text-center">
                You're on track to achieve your goal of becoming a {careerAssessment.careerGoals[0]}
              </p>
            </CardContent>
          </Card>

          {/* Next Milestone */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Rocket className="w-5 h-5 mr-2 text-orange-600" />
                Next Milestone
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-start space-x-4">
                <div className="w-12 h-12 bg-orange-100 rounded-full flex items-center justify-center">
                  <Brain className="w-6 h-6 text-orange-600" />
                </div>
                <div className="flex-1">
                  <h3 className="text-lg font-semibold mb-2">{learningPath.nextMilestone.title}</h3>
                  <p className="text-gray-600 mb-4">{learningPath.nextMilestone.description}</p>
                  <div className="flex items-center space-x-4 mb-4">
                    <Badge className="bg-orange-100 text-orange-800">
                      <Clock className="w-3 h-3 mr-1" />
                      {learningPath.nextMilestone.estimatedTime}
                    </Badge>
                  </div>
                  <div>
                    <h4 className="font-medium text-sm mb-2">Required Resources:</h4>
                    <ul className="space-y-1">
                      {learningPath.nextMilestone.resources.map((resource: string, index: number) => (
                        <li key={index} className="text-sm text-gray-600 flex items-center">
                          <CheckCircle className="w-3 h-3 text-green-500 mr-2" />
                          {resource}
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
                <Button className="bg-orange-600 hover:bg-orange-700">
                  Start Milestone
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Skill Gap Analysis */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <BarChart3 className="w-5 h-5 mr-2 text-green-600" />
                Skill Gap Analysis
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {careerAssessment.skillGaps.map((skill: any, index: number) => (
                  <div key={index} className="p-4 bg-gray-50 rounded-lg">
                    <div className="flex items-center justify-between mb-2">
                      <h4 className="font-medium">{skill.skill}</h4>
                      <Badge className={skill.priority === 'high' ? 'bg-red-100 text-red-800' : 'bg-yellow-100 text-yellow-800'}>
                        {skill.priority} priority
                      </Badge>
                    </div>
                    <div className="flex items-center space-x-4">
                      <div className="flex-1">
                        <div className="flex justify-between text-sm text-gray-600 mb-1">
                          <span>Current: {skill.currentLevel}/5</span>
                          <span>Target: {skill.targetLevel}/5</span>
                        </div>
                        <div className="w-full bg-gray-200 rounded-full h-2">
                          <div 
                            className="bg-green-500 h-2 rounded-full relative"
                            style={{ width: `${(skill.currentLevel / 5) * 100}%` }}
                          >
                            <div 
                              className="absolute top-0 right-0 w-1 h-2 bg-red-500"
                              style={{ right: `${100 - (skill.targetLevel / 5) * 100}%` }}
                            ></div>
                          </div>
                        </div>
                      </div>
                      <Button size="sm" variant="outline">
                        <BookOpen className="w-3 h-3 mr-1" />
                        Learn
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="paths" className="space-y-6">
          <div className="grid gap-6">
            {careerPaths.map((path: any) => (
              <Card key={path.id} className="hover:shadow-lg transition-shadow">
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div>
                      <CardTitle className="text-xl">{path.title}</CardTitle>
                      <CardDescription className="mt-1">
                        {path.description}
                      </CardDescription>
                    </div>
                    <div className="flex flex-col space-y-2">
                      <Badge className={getDifficultyColor(path.difficulty)}>
                        {path.difficulty}
                      </Badge>
                      <Badge className={getDemandColor(path.demandLevel)}>
                        {path.demandLevel} Demand
                      </Badge>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
                    <div className="flex items-center space-x-2">
                      <Clock className="w-4 h-4 text-gray-500" />
                      <span className="text-sm text-gray-600">{path.timeToAchieve}</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <DollarSign className="w-4 h-4 text-gray-500" />
                      <span className="text-sm text-gray-600">{path.averageSalary}</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <TrendingUp className="w-4 h-4 text-gray-500" />
                      <span className="text-sm text-gray-600">{path.demandLevel} Growth</span>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    <div>
                      <h4 className="font-medium text-sm mb-3">Required Skills</h4>
                      <div className="flex flex-wrap gap-2">
                        {path.requiredSkills.map((skill: string) => (
                          <Badge key={skill} variant="outline" className="text-xs">
                            {skill}
                          </Badge>
                        ))}
                      </div>
                    </div>

                    <div>
                      <h4 className="font-medium text-sm mb-3">Key Steps</h4>
                      <ul className="space-y-1">
                        {path.steps.map((step: string, index: number) => (
                          <li key={index} className="text-sm text-gray-600 flex items-start">
                            <ArrowRight className="w-3 h-3 text-blue-500 mr-2 mt-0.5 flex-shrink-0" />
                            {step}
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>

                  <div className="mt-6 pt-4 border-t">
                    <div className="flex items-center justify-between">
                      <div>
                        <h4 className="font-medium text-sm mb-1">Top Hiring Companies</h4>
                        <div className="flex flex-wrap gap-1">
                          {path.companies.slice(0, 3).map((company: string) => (
                            <Badge key={company} variant="outline" className="text-xs">
                              {company}
                            </Badge>
                          ))}
                          {path.companies.length > 3 && (
                            <Badge variant="outline" className="text-xs">
                              +{path.companies.length - 3} more
                            </Badge>
                          )}
                        </div>
                      </div>
                      <Button className="bg-blue-600 hover:bg-blue-700">
                        <Target className="w-3 h-3 mr-1" />
                        Set as Goal
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="mentorship" className="space-y-6">
          {/* Current Mentor */}
          {mentorshipProgram.currentMentor && (
            <Card className="bg-gradient-to-r from-green-50 to-emerald-50 border-green-200">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Users className="w-5 h-5 mr-2 text-green-600" />
                  Your Current Mentor
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-start space-x-4">
                  <div className="w-16 h-16 bg-green-200 rounded-full flex items-center justify-center">
                    <Users className="w-8 h-8 text-green-600" />
                  </div>
                  <div className="flex-1">
                    <h3 className="text-lg font-semibold">{mentorshipProgram.currentMentor.name}</h3>
                    <p className="text-green-600 font-medium">{mentorshipProgram.currentMentor.role}</p>
                    <p className="text-sm text-gray-600 mb-2">{mentorshipProgram.currentMentor.company} • {mentorshipProgram.currentMentor.experience}</p>
                    
                    <div className="flex items-center space-x-4 mb-4">
                      <div className="flex items-center">
                        <Star className="w-4 h-4 text-yellow-500 mr-1" />
                        <span className="text-sm font-medium">{mentorshipProgram.currentMentor.rating}</span>
                      </div>
                      <div className="text-sm text-gray-600">
                        {mentorshipProgram.currentMentor.sessions} sessions completed
                      </div>
                    </div>

                    <div className="flex flex-wrap gap-2 mb-4">
                      {mentorshipProgram.currentMentor.expertise.map((skill: string) => (
                        <Badge key={skill} variant="outline" className="text-xs">
                          {skill}
                        </Badge>
                      ))}
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-sm text-gray-600 mb-2">Next Session</p>
                    <p className="font-medium">{new Date(mentorshipProgram.currentMentor.nextSession).toLocaleDateString()}</p>
                    <Button size="sm" className="mt-2 bg-green-600 hover:bg-green-700">
                      <Calendar className="w-3 h-3 mr-1" />
                      Join Session
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Available Mentors */}
          <Card>
            <CardHeader>
              <CardTitle>Explore More Mentors</CardTitle>
              <CardDescription>
                Connect with industry experts for personalized guidance
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid gap-4">
                {mentorshipProgram.availableMentors.map((mentor: any, index: number) => (
                  <div key={index} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                    <div className="flex items-center space-x-4">
                      <div className="w-12 h-12 bg-blue-200 rounded-full flex items-center justify-center">
                        <Users className="w-6 h-6 text-blue-600" />
                      </div>
                      <div>
                        <h4 className="font-medium">{mentor.name}</h4>
                        <p className="text-sm text-blue-600">{mentor.role}</p>
                        <p className="text-xs text-gray-600">{mentor.company} • {mentor.experience}</p>
                        <div className="flex items-center space-x-2 mt-1">
                          <div className="flex items-center">
                            <Star className="w-3 h-3 text-yellow-500 mr-1" />
                            <span className="text-xs">{mentor.rating}</span>
                          </div>
                          <span className="text-xs text-gray-500">•</span>
                          <span className="text-xs text-gray-600">{mentor.price}</span>
                        </div>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="flex flex-wrap gap-1 mb-2">
                        {mentor.expertise.slice(0, 2).map((skill: string) => (
                          <Badge key={skill} variant="outline" className="text-xs">
                            {skill}
                          </Badge>
                        ))}
                      </div>
                      <Button size="sm" variant="outline">
                        Book Session
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="insights" className="space-y-6">
          {/* Trending Skills */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <TrendingUp className="w-5 h-5 mr-2 text-purple-600" />
                Trending Skills in Tech
              </CardTitle>
              <CardDescription>
                High-demand skills with significant growth potential
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid gap-4">
                {industryInsights.trending.map((trend: any, index: number) => (
                  <div key={index} className="flex items-center justify-between p-4 bg-purple-50 rounded-lg">
                    <div>
                      <h4 className="font-medium">{trend.skill}</h4>
                      <div className="flex items-center space-x-4 mt-1">
                        <Badge className="bg-purple-100 text-purple-800">
                          {trend.growth} growth
                        </Badge>
                        <Badge className={getDemandColor(trend.demandLevel)}>
                          {trend.demandLevel}
                        </Badge>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="font-medium text-purple-600">{trend.averageSalary}</p>
                      <p className="text-xs text-gray-600">Average Salary</p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Market Analysis */}
          <Card>
            <CardHeader>
              <CardTitle>Market Analysis</CardTitle>
              <CardDescription>
                Current state of the tech job market in India
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <h4 className="font-medium mb-4">Job Market Overview</h4>
                  <div className="space-y-3">
                    <div className="flex justify-between">
                      <span className="text-gray-600">Total Jobs Available</span>
                      <span className="font-medium">{industryInsights.marketAnalysis.totalJobs}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Year-over-Year Growth</span>
                      <span className="font-medium text-green-600">+{industryInsights.marketAnalysis.growthRate}</span>
                    </div>
                  </div>
                </div>

                <div>
                  <h4 className="font-medium mb-4">Top Hiring Cities</h4>
                  <div className="space-y-2">
                    {industryInsights.marketAnalysis.topCities.map((city: string, index: number) => (
                      <div key={index} className="flex items-center">
                        <MapPin className="w-3 h-3 text-gray-400 mr-2" />
                        <span className="text-sm">{city}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="assessment" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Compass className="w-5 h-5 mr-2 text-indigo-600" />
                Career Assessment Summary
              </CardTitle>
              <CardDescription>
                Your current career profile and recommendations
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <h4 className="font-medium mb-3">Current Profile</h4>
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-gray-600">Current Role</span>
                      <span className="font-medium">{careerAssessment.currentRole}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Experience Level</span>
                      <span className="font-medium">{careerAssessment.experienceLevel}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Target Timeline</span>
                      <span className="font-medium">{careerAssessment.timeframe}</span>
                    </div>
                  </div>
                </div>

                <div>
                  <h4 className="font-medium mb-3">Top Strengths</h4>
                  <div className="space-y-2">
                    {careerAssessment.strengths.map((strength: string, index: number) => (
                      <div key={index} className="flex items-center">
                        <CheckCircle className="w-4 h-4 text-green-500 mr-2" />
                        <span className="text-sm">{strength}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              <div className="mt-6 pt-6 border-t">
                <h4 className="font-medium mb-3">Recommended Career Goals</h4>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {careerAssessment.careerGoals.map((goal: string, index: number) => (
                    <div key={index} className="p-3 bg-indigo-50 rounded-lg text-center">
                      <Award className="w-6 h-6 text-indigo-600 mx-auto mb-2" />
                      <p className="font-medium text-indigo-900">{goal}</p>
                    </div>
                  ))}
                </div>
              </div>

              <div className="mt-6 pt-6 border-t">
                <Button className="w-full bg-indigo-600 hover:bg-indigo-700">
                  <Zap className="w-4 h-4 mr-2" />
                  Retake Career Assessment
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}

export default function CareerGuidance() {
  const config = platformConfigs.candidate;
  
  const usageData = [
    { label: "Career Assessments", current: 6, max: 12 },
    { label: "Goal Progress", current: 75, max: 100 },
    { label: "Mentoring Sessions", current: 4, max: 8 },
  ];

  return (
    <PlatformLayout
      sidebarTitle={config.sidebarTitle}
      sidebarSubtitle={config.sidebarSubtitle}
      sidebarSections={config.sidebarSections}
      usageData={usageData}
    >
      <CareerGuidanceContent />
    </PlatformLayout>
  );
}