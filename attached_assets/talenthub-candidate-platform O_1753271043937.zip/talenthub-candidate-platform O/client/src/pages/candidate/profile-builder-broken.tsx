import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Link } from "wouter";
import { candidateNavigation } from "@/config/complete-navigation";
import PlatformLayout from "@/components/layout/platform-layout";
import { useThemeClasses } from "@/lib/theme-config";
import { 
  Save, Plus, X, Eye, Share, ExternalLink, Mail, ChevronLeft,
  User, MapPin, Phone, Globe, Linkedin, Briefcase, GraduationCap,
  Award, Calendar, Building, Code, Sparkles, CheckCircle, AlertTriangle,
  TrendingUp, Star, Target, Upload, Camera, Edit3, Trash2, Move,
  Copy, QrCode, Facebook, Twitter
} from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { useLocation } from "wouter";

// Types
type ProfileFormData = {
  bio: string;
  professionalSummary: string;
  phone: string;
  location: string;
  linkedinUrl: string;
  profilePhoto: string;
};

type ExperienceFormData = {
  company: string;
  position: string;
  startDate: string;
  endDate: string;
  description: string;
  current: boolean;
};

type EducationFormData = {
  institution: string;
  degree: string;
  fieldOfStudy: string;
  startDate: string;
  endDate: string;
  description: string;
};

type SkillFormData = {
  name: string;
  level: number;
  category: string;
};

export default function ProfileBuilder() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [activeTab, setActiveTab] = useState("personal");
  const [isAutoSaving, setIsAutoSaving] = useState(false);
  const [hasUnsavedChanges, setHasUnsavedChanges] = useState(false);
  const [showShareDialog, setShowShareDialog] = useState(false);
  
  // Modal states for add forms
  const [showAddExperienceModal, setShowAddExperienceModal] = useState(false);
  const [showAddEducationModal, setShowAddEducationModal] = useState(false);
  const [showAddSkillModal, setShowAddSkillModal] = useState(false);
  const [showAddProjectModal, setShowAddProjectModal] = useState(false);

  // Multiple entry addition states
  const [pendingExperiences, setPendingExperiences] = useState<ExperienceFormData[]>([]);
  const [pendingEducations, setPendingEducations] = useState<EducationFormData[]>([]);
  const [pendingSkills, setPendingSkills] = useState<SkillFormData[]>([]);
  const [pendingProjects, setPendingProjects] = useState<any[]>([]);
  
  // Batch save loading states
  const [isSavingExperiences, setIsSavingExperiences] = useState(false);
  const [isSavingEducations, setIsSavingEducations] = useState(false);
  const [isSavingSkills, setIsSavingSkills] = useState(false);
  const [isSavingProjects, setIsSavingProjects] = useState(false);

  // Form data for modals
  const [newExperience, setNewExperience] = useState<ExperienceFormData>({
    company: "",
    position: "",
    startDate: "",
    endDate: "",
    current: false,
    description: ""
  });

  const [newEducation, setNewEducation] = useState<EducationFormData>({
    institution: "",
    degree: "",
    fieldOfStudy: "",
    startDate: "",
    endDate: "",
    description: ""
  });

  const [newSkill, setNewSkill] = useState<SkillFormData>({
    name: "",
    level: 50,
    category: "Programming"
  });

  const [newProject, setNewProject] = useState({
    name: "",
    description: "",
    technologies: [] as string[],
    liveUrl: "",
    githubUrl: "",
    featured: false
  });
  
  const [, setLocation] = useLocation();

  // Share handlers
  const handlePreview = () => {
    setLocation("/candidate/profile-preview");
  };

  const handleShare = () => {
    setShowShareDialog(true);
  };

  const handleCopyLink = async () => {
    const profileUrl = `${window.location.origin}/candidate/profile-preview`;
    try {
      if (navigator.clipboard && navigator.clipboard.writeText) {
        await navigator.clipboard.writeText(profileUrl);
        toast({
          title: "Link Copied!",
          description: "Profile link copied to clipboard.",
        });
      } else {
        // Fallback for browsers without clipboard API
        toast({
          title: "Copy Link",
          description: "Please copy this link manually: " + profileUrl,
        });
      }
      setShowShareDialog(false);
    } catch (error) {
      console.error('Failed to copy to clipboard:', error);
      toast({
        title: "Copy Failed",
        description: "Please copy the link manually: " + profileUrl,
        variant: "destructive",
      });
    }
  };

  const handleLinkedInShare = () => {
    const text = encodeURIComponent("Check out my professional profile on TalentHub");
    const url = encodeURIComponent(`${window.location.origin}/candidate/profile-preview`);
    window.open(`https://www.linkedin.com/sharing/share-offsite/?url=${url}&text=${text}`, '_blank');
    setShowShareDialog(false);
  };

  const handleEmailShare = () => {
    const subject = encodeURIComponent("My Professional Profile");
    const body = encodeURIComponent(`Hi,\n\nI'd like to share my professional profile with you: ${window.location.origin}/candidate/profile-preview\n\nBest regards`);
    window.location.href = `mailto:?subject=${subject}&body=${body}`;
    setShowShareDialog(false);
  };

  const handleTwitterShare = () => {
    const text = encodeURIComponent("Check out my professional profile on TalentHub");
    const url = encodeURIComponent(`${window.location.origin}/candidate/profile-preview`);
    window.open(`https://twitter.com/intent/tweet?text=${text}&url=${url}`, '_blank');
    setShowShareDialog(false);
  };

  // Form handlers for each tab
  const handleProfilePhotoUpload = () => {
    try {
      const input = document.createElement('input');
      input.type = 'file';
      input.accept = 'image/*';
      input.onchange = (e) => {
        try {
          const file = (e.target as HTMLInputElement).files?.[0];
          if (file) {
            const reader = new FileReader();
            reader.onload = (e) => {
              try {
                const result = e.target?.result as string;
                setProfileData({...profileData, profilePhoto: result});
                setHasUnsavedChanges(true);
                toast({
                  title: "Photo Uploaded",
                  description: "Profile photo has been updated successfully.",
                });
              } catch (error) {
                console.error('Error processing file:', error);
                toast({
                  title: "Upload Failed",
                  description: "Failed to process the image file.",
                  variant: "destructive",
                });
              }
            };
            reader.onerror = () => {
              toast({
                title: "Upload Failed",
                description: "Failed to read the image file.",
                variant: "destructive",
              });
            };
            reader.readAsDataURL(file);
          }
        } catch (error) {
          console.error('Error handling file upload:', error);
          toast({
            title: "Upload Failed",
            description: "Failed to upload the image.",
            variant: "destructive",
          });
        }
      };
      input.click();
    } catch (error) {
      console.error('Error creating file input:', error);
      toast({
        title: "Upload Failed",
        description: "Failed to initialize file upload.",
        variant: "destructive",
      });
    }
  };

  const handleAddExperience = () => {
    setShowAddExperienceModal(true);
  };

  const handleSaveExperience = () => {
    if (!newExperience.company || !newExperience.position) {
      toast({
        title: "Missing Information",
        description: "Please fill in company and position fields.",
        variant: "destructive",
      });
      return;
    }
    
    // Add to pending experiences instead of directly to experiences
    setPendingExperiences([...pendingExperiences, newExperience]);
    setNewExperience({
      company: "",
      position: "",
      startDate: "",
      endDate: "",
      current: false,
      description: ""
    });
    toast({
      title: "Experience Added to Queue",
      description: "Experience added to pending list. Click 'Save All' to save permanently.",
    });
  };

  const handleSaveAllExperiences = async () => {
    if (pendingExperiences.length === 0) {
      toast({
        title: "No Pending Experiences",
        description: "Add some experiences first before saving.",
        variant: "destructive",
      });
      return;
    }

    setIsSavingExperiences(true);
    try {
      // Add all pending experiences to the main list
      setExperiences([...experiences, ...pendingExperiences]);
      setPendingExperiences([]);
      setHasUnsavedChanges(true);
      setShowAddExperienceModal(false);
      
      toast({
        title: "Experiences Saved",
        description: `${pendingExperiences.length} experience(s) have been saved successfully.`,
      });
    } catch (error) {
      toast({
        title: "Save Failed",
        description: "Failed to save experiences. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsSavingExperiences(false);
    }
  };

  const handleClearPendingExperiences = () => {
    setPendingExperiences([]);
    toast({
      title: "Pending Experiences Cleared",
      description: "All pending experiences have been removed.",
    });
  };

  const handleRemovePendingExperience = (index: number) => {
    const updatedPending = pendingExperiences.filter((_, i) => i !== index);
    setPendingExperiences(updatedPending);
    toast({
      title: "Experience Removed",
      description: "Pending experience entry has been removed.",
    });
  };

  const handleRemoveExperience = (index: number) => {
    const updatedExperiences = experiences.filter((_, i) => i !== index);
    setExperiences(updatedExperiences);
    setHasUnsavedChanges(true);
    toast({
      title: "Experience Removed",
      description: "Experience entry has been removed.",
    });
  };

  const handleAddEducation = () => {
    setShowAddEducationModal(true);
  };

  const handleSaveEducation = () => {
    if (!newEducation.institution || !newEducation.degree) {
      toast({
        title: "Missing Information",
        description: "Please fill in institution and degree fields.",
        variant: "destructive",
      });
      return;
    }
    
    // Add to pending educations instead of directly to educations
    setPendingEducations([...pendingEducations, newEducation]);
    setNewEducation({
      institution: "",
      degree: "",
      fieldOfStudy: "",
      startDate: "",
      endDate: "",
      description: ""
    });
    toast({
      title: "Education Added to Queue",
      description: "Education added to pending list. Click 'Save All' to save permanently.",
    });
  };

  const handleSaveAllEducations = async () => {
    if (pendingEducations.length === 0) {
      toast({
        title: "No Pending Educations",
        description: "Add some education entries first before saving.",
        variant: "destructive",
      });
      return;
    }

    setIsSavingEducations(true);
    try {
      setEducations([...educations, ...pendingEducations]);
      setPendingEducations([]);
      setHasUnsavedChanges(true);
      setShowAddEducationModal(false);
      
      toast({
        title: "Educations Saved",
        description: `${pendingEducations.length} education(s) have been saved successfully.`,
      });
    } catch (error) {
      toast({
        title: "Save Failed",
        description: "Failed to save educations. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsSavingEducations(false);
    }
  };

  const handleClearPendingEducations = () => {
    setPendingEducations([]);
    toast({
      title: "Pending Educations Cleared",
      description: "All pending education entries have been removed.",
    });
  };

  const handleRemovePendingEducation = (index: number) => {
    const updatedPending = pendingEducations.filter((_, i) => i !== index);
    setPendingEducations(updatedPending);
    toast({
      title: "Education Removed",
      description: "Pending education entry has been removed.",
    });
  };

  const handleRemoveEducation = (index: number) => {
    const updatedEducations = educations.filter((_, i) => i !== index);
    setEducations(updatedEducations);
    setHasUnsavedChanges(true);
    toast({
      title: "Education Removed",
      description: "Education entry has been removed.",
    });
  };

  const handleAddSkill = () => {
    setShowAddSkillModal(true);
  };

  const handleSaveSkill = () => {
    if (!newSkill.name) {
      toast({
        title: "Missing Information",
        description: "Please enter a skill name.",
        variant: "destructive",
      });
      return;
    }
    
    // Add to pending skills instead of directly to skills
    setPendingSkills([...pendingSkills, newSkill]);
    setNewSkill({
      name: "",
      level: 50,
      category: "Programming"
    });
    toast({
      title: "Skill Added to Queue",
      description: "Skill added to pending list. Click 'Save All' to save permanently.",
    });
  };

  const handleSaveAllSkills = async () => {
    if (pendingSkills.length === 0) {
      toast({
        title: "No Pending Skills",
        description: "Add some skills first before saving.",
        variant: "destructive",
      });
      return;
    }

    setIsSavingSkills(true);
    try {
      setSkills([...skills, ...pendingSkills]);
      setPendingSkills([]);
      setHasUnsavedChanges(true);
      setShowAddSkillModal(false);
      
      toast({
        title: "Skills Saved",
        description: `${pendingSkills.length} skill(s) have been saved successfully.`,
      });
    } catch (error) {
      toast({
        title: "Save Failed",
        description: "Failed to save skills. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsSavingSkills(false);
    }
  };

  const handleClearPendingSkills = () => {
    setPendingSkills([]);
    toast({
      title: "Pending Skills Cleared",
      description: "All pending skill entries have been removed.",
    });
  };

  const handleRemovePendingSkill = (index: number) => {
    const updatedPending = pendingSkills.filter((_, i) => i !== index);
    setPendingSkills(updatedPending);
    toast({
      title: "Skill Removed",
      description: "Pending skill entry has been removed.",
    });
  };

  const handleRemoveSkill = (index: number) => {
    const updatedSkills = skills.filter((_, i) => i !== index);
    setSkills(updatedSkills);
    setHasUnsavedChanges(true);
    toast({
      title: "Skill Removed",
      description: "Skill has been removed.",
    });
  };

  const handleAddProject = () => {
    setShowAddProjectModal(true);
  };

  const handleSaveProject = () => {
    if (!newProject.name) {
      toast({
        title: "Missing Information",
        description: "Please enter a project name.",
        variant: "destructive",
      });
      return;
    }
    
    // Add to pending projects instead of directly to projects
    setPendingProjects([...pendingProjects, newProject]);
    setNewProject({
      name: "",
      description: "",
      technologies: [],
      liveUrl: "",
      githubUrl: "",
      featured: false
    });
    toast({
      title: "Project Added to Queue",
      description: "Project added to pending list. Click 'Save All' to save permanently.",
    });
  };

  const handleSaveAllProjects = async () => {
    if (pendingProjects.length === 0) {
      toast({
        title: "No Pending Projects",
        description: "Add some projects first before saving.",
        variant: "destructive",
      });
      return;
    }

    setIsSavingProjects(true);
    try {
      setProjects([...projects, ...pendingProjects]);
      setPendingProjects([]);
      setHasUnsavedChanges(true);
      setShowAddProjectModal(false);
      
      toast({
        title: "Projects Saved",
        description: `${pendingProjects.length} project(s) have been saved successfully.`,
      });
    } catch (error) {
      toast({
        title: "Save Failed",
        description: "Failed to save projects. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsSavingProjects(false);
    }
  };

  const handleClearPendingProjects = () => {
    setPendingProjects([]);
    toast({
      title: "Pending Projects Cleared",
      description: "All pending project entries have been removed.",
    });
  };

  const handleRemovePendingProject = (index: number) => {
    const updatedPending = pendingProjects.filter((_, i) => i !== index);
    setPendingProjects(updatedPending);
    toast({
      title: "Project Removed",
      description: "Pending project entry has been removed.",
    });
  };

  const handleRemoveProject = (index: number) => {
    const updatedProjects = projects.filter((_, i) => i !== index);
    setProjects(updatedProjects);
    setHasUnsavedChanges(true);
    toast({
      title: "Project Removed",
      description: "Project has been removed.",
    });
  };

  // Profile completion tracking
  const [completionStats, setCompletionStats] = useState({
    personal: 45,
    experience: 85,
    education: 90,
    skills: 95,
    projects: 80,
    overall: 79
  });

  // Form states
  const [profileData, setProfileData] = useState<ProfileFormData>({
    bio: "",
    professionalSummary: "",
    phone: "",
    location: "",
    linkedinUrl: "",
    profilePhoto: ""
  });

  const [experiences, setExperiences] = useState<ExperienceFormData[]>([
    {
      company: "TechCorp Solutions",
      position: "Senior Frontend Developer",
      startDate: "2022-03",
      endDate: "",
      current: true,
      description: "Lead a team of 4 developers building scalable React applications. Implemented micro-frontend architecture reducing load times by 40%. Mentored junior developers and established coding standards."
    },
    {
      company: "StartupXYZ",
      position: "Full Stack Developer",
      startDate: "2020-06",
      endDate: "2022-02",
      current: false,
      description: "Built end-to-end web applications using React, Node.js, and PostgreSQL. Developed RESTful APIs handling 10k+ daily requests. Collaborated with product team to deliver features ahead of schedule."
    }
  ]);

  const [educations, setEducations] = useState<EducationFormData[]>([
    {
      institution: "Stanford University",
      degree: "Bachelor of Science",
      fieldOfStudy: "Computer Science",
      startDate: "2016-09",
      endDate: "2020-05",
      description: "Specialized in Software Engineering and Human-Computer Interaction. Graduated Magna Cum Laude with 3.8 GPA. Active in Computer Science Society and hackathons."
    },
    {
      institution: "Google",
      degree: "Professional Certificate",
      fieldOfStudy: "UX Design",
      startDate: "2021-01",
      endDate: "2021-08",
      description: "Comprehensive program covering user research, wireframing, prototyping, and usability testing. Completed capstone project designing mobile app for local businesses."
    }
  ]);

  const [skills, setSkills] = useState<SkillFormData[]>([
    { name: "JavaScript", level: 85, category: "Programming" },
    { name: "React", level: 90, category: "Frontend" },
    { name: "Node.js", level: 75, category: "Backend" },
    { name: "Python", level: 60, category: "Programming" },
    { name: "SQL", level: 70, category: "Database" }
  ]);

  const [projects, setProjects] = useState([
    {
      name: "E-commerce Platform",
      description: "Full-stack e-commerce solution with React, Node.js, and Stripe integration",
      technologies: ["React", "Node.js", "PostgreSQL", "Stripe"],
      liveUrl: "https://demo-ecommerce.com",
      githubUrl: "https://github.com/user/ecommerce",
      featured: true
    },
    {
      name: "Task Management App",
      description: "Collaborative task management tool with real-time updates and team features",
      technologies: ["Vue.js", "Firebase", "Socket.io"],
      liveUrl: "https://taskapp-demo.com",
      githubUrl: "https://github.com/user/taskapp",
      featured: false
    }
  ]);

  // Auto-save functionality
  useEffect(() => {
    if (hasUnsavedChanges) {
      const timer = setTimeout(() => {
        setIsAutoSaving(true);
        // Simulate auto-save
        setTimeout(() => {
          setIsAutoSaving(false);
          setHasUnsavedChanges(false);
          toast({
            title: "Auto-saved",
            description: "Your changes have been saved automatically.",
          });
        }, 1000);
      }, 2000);

      return () => clearTimeout(timer);
    }
  }, [hasUnsavedChanges, toast]);

  // Circular Progress Component
  const CircularProgress = ({ value, size = 80, strokeWidth = 8, color = "sky" }: {
    value: number;
    size?: number;
    strokeWidth?: number;
    color?: string;
  }) => {
    const radius = (size - strokeWidth) / 2;
    const circumference = radius * 2 * Math.PI;
    const strokeDasharray = `${(value / 100) * circumference} ${circumference}`;

    const colorMap = {
      sky: "stroke-sky-500",
      green: "stroke-green-500",
      purple: "stroke-purple-500",
      orange: "stroke-orange-500",
      indigo: "stroke-indigo-500"
    };

    return (
      <div className="relative inline-flex items-center justify-center">
        <svg
          width={size}
          height={size}
          className="transform -rotate-90"
        >
          <circle
            cx={size / 2}
            cy={size / 2}
            r={radius}
            stroke="currentColor"
            strokeWidth={strokeWidth}
            fill="transparent"
            className="text-gray-200"
          />
          <circle
            cx={size / 2}
            cy={size / 2}
            r={radius}
            stroke="currentColor"
            strokeWidth={strokeWidth}
            fill="transparent"
            strokeDasharray={strokeDasharray}
            className={`${colorMap[color as keyof typeof colorMap]} transition-all duration-1000 ease-in-out`}
            strokeLinecap="round"
          />
        </svg>
        <span className="absolute text-lg font-bold text-gray-800">
          {value}%
        </span>
      </div>
    );
  };

  // Skill Level Meter Component
  const SkillMeter = ({ skill, onUpdate, onDelete }: {
    skill: SkillFormData;
    onUpdate: (skill: SkillFormData) => void;
    onDelete: () => void;
  }) => {
    const [isEditing, setIsEditing] = useState(false);
    const [tempSkill, setTempSkill] = useState(skill);

    const handleSave = () => {
      onUpdate(tempSkill);
      setIsEditing(false);
      setHasUnsavedChanges(true);
    };

    const getSkillColor = (level: number) => {
      if (level >= 80) return "bg-green-500";
      if (level >= 60) return "bg-blue-500";
      if (level >= 40) return "bg-yellow-500";
      return "bg-gray-400";
    };

    return (
      <div className="group bg-white p-4 rounded-lg border border-gray-200 hover:border-purple-300 hover:shadow-md transition-all duration-200">
        {isEditing ? (
          <div className="space-y-3">
            <Input
              value={tempSkill.name}
              onChange={(e) => setTempSkill({...tempSkill, name: e.target.value})}
              className="font-medium"
            />
            <div className="space-y-2">
              <Label>Proficiency: {tempSkill.level}%</Label>
              <input
                type="range"
                min="0"
                max="100"
                value={tempSkill.level}
                onChange={(e) => setTempSkill({...tempSkill, level: parseInt(e.target.value)})}
                className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer slider"
              />
            </div>
            <Select
              value={tempSkill.category}
              onValueChange={(value) => setTempSkill({...tempSkill, category: value})}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="Programming">Programming</SelectItem>
                <SelectItem value="Frontend">Frontend</SelectItem>
                <SelectItem value="Backend">Backend</SelectItem>
                <SelectItem value="Database">Database</SelectItem>
                <SelectItem value="DevOps">DevOps</SelectItem>
                <SelectItem value="Design">Design</SelectItem>
              </SelectContent>
            </Select>
            <div className="flex gap-2">
              <Button size="sm" onClick={handleSave} className="bg-green-600 hover:bg-green-700">
                <CheckCircle className="w-4 h-4 mr-1" />
                Save
              </Button>
              <Button size="sm" variant="outline" onClick={() => setIsEditing(false)}>
                Cancel
              </Button>
            </div>
          </div>
        ) : (
          <>
            <div className="flex items-center justify-between mb-3">
              <div>
                <h4 className="font-medium text-gray-900">{skill.name}</h4>
                <Badge variant="secondary" className="text-xs">{skill.category}</Badge>
              </div>
              <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                <Button size="sm" variant="ghost" onClick={() => setIsEditing(true)}>
                  <Edit3 className="w-3 h-3" />
                </Button>
                <Button size="sm" variant="ghost" onClick={onDelete} className="text-red-600">
                  <Trash2 className="w-3 h-3" />
                </Button>
              </div>
            </div>
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span className="text-gray-600">Proficiency</span>
                <span className="font-medium">{skill.level}%</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2">
                <div
                  className={`h-2 rounded-full ${getSkillColor(skill.level)} transition-all duration-500 ease-out`}
                  style={{ width: `${skill.level}%` }}
                />
              </div>
            </div>
          </>
        )}
      </div>
    );
  };

  // Section completion indicator
  const SectionStatus = ({ completion, color }: { completion: number; color: string }) => {
    const getStatusInfo = (comp: number) => {
      if (comp >= 80) return { icon: CheckCircle, text: "Complete", color: "text-green-600 bg-green-100" };
      if (comp >= 50) return { icon: TrendingUp, text: "In Progress", color: "text-blue-600 bg-blue-100" };
      return { icon: AlertTriangle, text: "Needs Attention", color: "text-amber-600 bg-amber-100" };
    };

    const status = getStatusInfo(completion);
    const StatusIcon = status.icon;

    return (
      <div className={`inline-flex items-center gap-1 px-2 py-1 rounded-full text-xs font-medium ${status.color}`}>
        <StatusIcon className="w-3 h-3" />
        {status.text}
      </div>
    );
  };

  return (
    <PlatformLayout
      sidebarTitle="Candidate Platform"
      sidebarSubtitle="Your Career Dashboard"
      sidebarSections={candidateNavigation}
    >
      <div className="max-w-6xl mx-auto p-6">
        {/* Header with progress overview */}
        <div className="bg-gradient-to-r from-sky-50 via-blue-50 to-indigo-50 p-6 rounded-xl mb-8">
          <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-6">
            <div>
              <h1 className="text-3xl font-bold text-gray-900 mb-2">Profile Builder</h1>
              <p className="text-gray-600">Create a compelling professional profile that stands out to recruiters</p>
            </div>
            
            <div className="flex items-center gap-6">
              <div className="text-center">
                <CircularProgress value={completionStats.overall} size={100} color="sky" />
                <p className="text-sm font-medium text-gray-700 mt-2">Overall Progress</p>
              </div>
              
              <div className="flex gap-3">
                <Button 
                  onClick={handlePreview}
                  className="bg-sky-600 hover:bg-sky-700 text-white"
                >
                  <Eye className="w-4 h-4 mr-2" />
                  Preview Profile
                </Button>
                <Button 
                  onClick={handleShare}
                  variant="outline" 
                  className="border-sky-300 text-sky-700 hover:bg-sky-50"
                >
                  <Share className="w-4 h-4 mr-2" />
                  Share
                </Button>
              </div>
            </div>
          </div>

          {/* Section completion overview */}
          <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mt-6">
            {[
              { name: "Personal", completion: completionStats.personal, color: "sky" },
              { name: "Experience", completion: completionStats.experience, color: "green" },
              { name: "Education", completion: completionStats.education, color: "orange" },
              { name: "Skills", completion: completionStats.skills, color: "purple" },
              { name: "Projects", completion: completionStats.projects, color: "indigo" }
            ].map((section) => (
              <div key={section.name} className="text-center">
                <CircularProgress value={section.completion} size={60} color={section.color} />
                <p className="text-sm font-medium text-gray-700 mt-1">{section.name}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Auto-save indicator */}
        {(isAutoSaving || hasUnsavedChanges) && (
          <div className="fixed top-4 right-4 z-50">
            <div className={`px-4 py-2 rounded-lg shadow-lg transition-all duration-300 ${
              isAutoSaving ? 'bg-blue-500 text-white' : 'bg-amber-100 text-amber-800'
            }`}>
              <div className="flex items-center gap-2">
                {isAutoSaving ? (
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                ) : (
                  <AlertTriangle className="w-4 h-4" />
                )}
                {isAutoSaving ? 'Auto-saving...' : 'Unsaved changes'}
              </div>
            </div>
          </div>
        )}

        {/* Main Content Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-5 bg-gray-100 p-1 rounded-lg">
            <TabsTrigger 
              value="personal" 
              className="flex items-center gap-2 data-[state=active]:bg-sky-500 data-[state=active]:text-white"
            >
              <User className="w-4 h-4" />
              Personal
              <SectionStatus completion={completionStats.personal} color="sky" />
            </TabsTrigger>
            <TabsTrigger 
              value="experience"
              className="flex items-center gap-2 data-[state=active]:bg-green-500 data-[state=active]:text-white"
            >
              <Briefcase className="w-4 h-4" />
              Experience
              <SectionStatus completion={completionStats.experience} color="green" />
            </TabsTrigger>
            <TabsTrigger 
              value="education"
              className="flex items-center gap-2 data-[state=active]:bg-orange-500 data-[state=active]:text-white"
            >
              <GraduationCap className="w-4 h-4" />
              Education
              <SectionStatus completion={completionStats.education} color="orange" />
            </TabsTrigger>
            <TabsTrigger 
              value="skills"
              className="flex items-center gap-2 data-[state=active]:bg-purple-500 data-[state=active]:text-white"
            >
              <Target className="w-4 h-4" />
              Skills
              <SectionStatus completion={completionStats.skills} color="purple" />
            </TabsTrigger>
            <TabsTrigger 
              value="projects"
              className="flex items-center gap-2 data-[state=active]:bg-indigo-500 data-[state=active]:text-white"
            >
              <Code className="w-4 h-4" />
              Projects
              <SectionStatus completion={completionStats.projects} color="indigo" />
            </TabsTrigger>
          </TabsList>

          {/* Personal Information Tab */}
          <TabsContent value="personal" className="space-y-6">
            <Card className="border-l-4 border-l-sky-500 hover:shadow-lg transition-shadow duration-300">
              <CardHeader className="bg-gradient-to-r from-sky-50 to-blue-50">
                <CardTitle className="flex items-center gap-2 text-sky-800">
                  <User className="w-5 h-5" />
                  Personal Information
                </CardTitle>
              </CardHeader>
              <CardContent className="p-6 space-y-6">
                {/* Profile Photo Section */}
                <div className="flex items-center gap-6">
                  <div className="relative group">
                    <div className="w-24 h-24 bg-gradient-to-br from-sky-400 to-blue-500 rounded-full flex items-center justify-center text-white text-2xl font-bold shadow-lg">
                      A
                    </div>
                    <button className="absolute -bottom-2 -right-2 w-8 h-8 bg-sky-600 text-white rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity shadow-lg hover:bg-sky-700">
                      <Camera className="w-4 h-4" />
                    </button>
                  </div>
                  <div className="space-y-2">
                    <h3 className="font-medium text-gray-900">Profile Photo</h3>
                    <p className="text-sm text-gray-600">Upload a professional headshot to make a great first impression</p>
                    <Button 
                      onClick={handleProfilePhotoUpload}
                      variant="outline" 
                      size="sm" 
                      className="text-sky-600 border-sky-300 hover:bg-sky-50"
                    >
                      <Upload className="w-4 h-4 mr-2" />
                      Upload Photo
                    </Button>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <Label htmlFor="phone" className="flex items-center gap-2">
                      <Phone className="w-4 h-4 text-sky-600" />
                      Phone Number
                    </Label>
                    <Input
                      id="phone"
                      value={profileData.phone}
                      onChange={(e) => {
                        setProfileData({...profileData, phone: e.target.value});
                        setHasUnsavedChanges(true);
                      }}
                      placeholder="+1 (555) 123-4567"
                      className="hover:border-sky-300 focus:border-sky-500 transition-colors"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="location" className="flex items-center gap-2">
                      <MapPin className="w-4 h-4 text-sky-600" />
                      Location
                    </Label>
                    <Input
                      id="location"
                      value={profileData.location}
                      onChange={(e) => {
                        setProfileData({...profileData, location: e.target.value});
                        setHasUnsavedChanges(true);
                      }}
                      placeholder="San Francisco, CA"
                      className="hover:border-sky-300 focus:border-sky-500 transition-colors"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="linkedin" className="flex items-center gap-2">
                      <Linkedin className="w-4 h-4 text-sky-600" />
                      LinkedIn Profile
                    </Label>
                    <Input
                      id="linkedin"
                      value={profileData.linkedinUrl}
                      onChange={(e) => {
                        setProfileData({...profileData, linkedinUrl: e.target.value});
                        setHasUnsavedChanges(true);
                      }}
                      placeholder="linkedin.com/in/yourprofile"
                      className="hover:border-sky-300 focus:border-sky-500 transition-colors"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="bio" className="flex items-center gap-2">
                    <Sparkles className="w-4 h-4 text-sky-600" />
                    Professional Bio
                  </Label>
                  <Textarea
                    id="bio"
                    value={profileData.bio}
                    onChange={(e) => {
                      setProfileData({...profileData, bio: e.target.value});
                      setHasUnsavedChanges(true);
                    }}
                    placeholder="Write a compelling bio that highlights your expertise and career goals..."
                    className="min-h-[120px] hover:border-sky-300 focus:border-sky-500 transition-colors"
                  />
                  <div className="flex justify-between text-sm text-gray-500">
                    <span>Tip: Include your key skills and what makes you unique</span>
                    <span>{profileData.bio.length}/500</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Skills Tab */}
          <TabsContent value="skills" className="space-y-6">
            <Card className="border-l-4 border-l-purple-500 hover:shadow-lg transition-shadow duration-300">
              <CardHeader className="bg-gradient-to-r from-purple-50 to-violet-50">
                <CardTitle className="flex items-center gap-2 text-purple-800">
                  <Target className="w-5 h-5" />
                  Technical Skills & Expertise
                </CardTitle>
              </CardHeader>
              <CardContent className="p-6">
                <div className="flex justify-between items-center mb-6">
                  <p className="text-gray-600">Showcase your technical abilities with skill level indicators</p>
                  <Button 
                    onClick={handleAddSkill}
                    className="bg-purple-600 hover:bg-purple-700"
                  >
                    <Plus className="w-4 h-4 mr-2" />
                    Add Skill
                  </Button>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {skills.map((skill, index) => (
                    <SkillMeter
                      key={index}
                      skill={skill}
                      onUpdate={(updatedSkill) => {
                        const newSkills = [...skills];
                        newSkills[index] = updatedSkill;
                        setSkills(newSkills);
                      }}
                      onDelete={() => handleRemoveSkill(index)}
                    />
                  ))}
                </div>

                {skills.length === 0 && (
                  <div className="text-center py-12 text-gray-500">
                    <Target className="w-12 h-12 mx-auto mb-4 text-gray-300" />
                    <p>No skills added yet. Start building your skill profile!</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Experience Tab */}
          <TabsContent value="experience" className="space-y-6">
            <Card className="border-l-4 border-l-green-500 hover:shadow-lg transition-shadow duration-300">
              <CardHeader className="bg-gradient-to-r from-green-50 to-emerald-50">
                <CardTitle className="flex items-center gap-2 text-green-800">
                  <Briefcase className="w-5 h-5" />
                  Work Experience
                </CardTitle>
              </CardHeader>
              <CardContent className="p-6">
                <div className="flex justify-between items-center mb-6">
                  <p className="text-gray-600">Build credibility with your professional experience and achievements</p>
                  <Button 
                    onClick={handleAddExperience}
                    className="bg-green-600 hover:bg-green-700"
                  >
                    <Plus className="w-4 h-4 mr-2" />
                    Add Experience
                  </Button>
                </div>

                <div className="space-y-6">
                  {experiences.map((exp, index) => (
                    <div key={index} className="bg-white p-6 rounded-lg border border-gray-200 hover:border-green-300 hover:shadow-md transition-all duration-200">
                      <div className="flex items-start justify-between mb-4">
                        <div className="flex items-center gap-3">
                          <div className="w-12 h-12 bg-gradient-to-br from-green-400 to-emerald-500 rounded-lg flex items-center justify-center text-white font-bold">
                            {exp.company.charAt(0) || "C"}
                          </div>
                          <div>
                            <h3 className="font-semibold text-gray-900">{exp.position || "Position Title"}</h3>
                            <p className="text-green-600 font-medium">{exp.company || "Company Name"}</p>
                            <p className="text-sm text-gray-500">
                              {exp.startDate} - {exp.current ? "Present" : exp.endDate}
                              {exp.current && <Badge className="ml-2 bg-green-100 text-green-800">Current</Badge>}
                            </p>
                          </div>
                        </div>
                        <Button 
                          size="sm" 
                          variant="ghost" 
                          onClick={() => handleRemoveExperience(index)}
                          className="text-red-600 hover:bg-red-50"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                        <div className="space-y-2">
                          <Label>Company</Label>
                          <Input
                            value={exp.company}
                            onChange={(e) => {
                              const newExperiences = [...experiences];
                              newExperiences[index].company = e.target.value;
                              setExperiences(newExperiences);
                              setHasUnsavedChanges(true);
                            }}
                            placeholder="Company Name"
                            className="hover:border-green-300 focus:border-green-500"
                          />
                        </div>
                        <div className="space-y-2">
                          <Label>Position</Label>
                          <Input
                            value={exp.position}
                            onChange={(e) => {
                              const newExperiences = [...experiences];
                              newExperiences[index].position = e.target.value;
                              setExperiences(newExperiences);
                              setHasUnsavedChanges(true);
                            }}
                            placeholder="Job Title"
                            className="hover:border-green-300 focus:border-green-500"
                          />
                        </div>
                        <div className="space-y-2">
                          <Label>Start Date</Label>
                          <Input
                            type="month"
                            value={exp.startDate}
                            onChange={(e) => {
                              const newExperiences = [...experiences];
                              newExperiences[index].startDate = e.target.value;
                              setExperiences(newExperiences);
                              setHasUnsavedChanges(true);
                            }}
                            className="hover:border-green-300 focus:border-green-500"
                          />
                        </div>
                        <div className="space-y-2">
                          <Label>End Date</Label>
                          <Input
                            type="month"
                            value={exp.endDate}
                            onChange={(e) => {
                              const newExperiences = [...experiences];
                              newExperiences[index].endDate = e.target.value;
                              setExperiences(newExperiences);
                              setHasUnsavedChanges(true);
                            }}
                            disabled={exp.current}
                            className="hover:border-green-300 focus:border-green-500"
                          />
                        </div>
                      </div>

                      <div className="space-y-2 mb-4">
                        <div className="flex items-center gap-2">
                          <input
                            type="checkbox"
                            checked={exp.current}
                            onChange={(e) => {
                              const newExperiences = [...experiences];
                              newExperiences[index].current = e.target.checked;
                              if (e.target.checked) newExperiences[index].endDate = "";
                              setExperiences(newExperiences);
                              setHasUnsavedChanges(true);
                            }}
                            className="rounded"
                          />
                          <Label className="text-sm">I currently work here</Label>
                        </div>
                      </div>

                      <div className="space-y-2">
                        <Label>Description</Label>
                        <Textarea
                          value={exp.description}
                          onChange={(e) => {
                            const newExperiences = [...experiences];
                            newExperiences[index].description = e.target.value;
                            setExperiences(newExperiences);
                            setHasUnsavedChanges(true);
                          }}
                          placeholder="Describe your key responsibilities and achievements..."
                          className="min-h-[100px] hover:border-green-300 focus:border-green-500"
                        />
                        <div className="flex justify-between text-sm text-gray-500">
                          <span>Use bullet points to highlight achievements</span>
                          <span>{exp.description.length}/500</span>
                        </div>
                      </div>
                    </div>
                  ))}

                  {experiences.length === 0 && (
                    <div className="text-center py-12 text-gray-500">
                      <Briefcase className="w-12 h-12 mx-auto mb-4 text-gray-300" />
                      <p>No work experience added yet. Add your professional journey!</p>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Education Tab */}
          <TabsContent value="education" className="space-y-6">
            <Card className="border-l-4 border-l-orange-500 hover:shadow-lg transition-shadow duration-300">
              <CardHeader className="bg-gradient-to-r from-orange-50 to-amber-50">
                <CardTitle className="flex items-center gap-2 text-orange-800">
                  <GraduationCap className="w-5 h-5" />
                  Education & Certifications
                </CardTitle>
              </CardHeader>
              <CardContent className="p-6">
                <div className="flex justify-between items-center mb-6">
                  <p className="text-gray-600">Showcase your educational background and professional certifications</p>
                  <Button 
                    onClick={handleAddEducation}
                    className="bg-orange-600 hover:bg-orange-700"
                  >
                    <Plus className="w-4 h-4 mr-2" />
                    Add Education
                  </Button>
                </div>

                <div className="space-y-6">
                  {educations.map((edu, index) => (
                    <div key={index} className="bg-white p-6 rounded-lg border border-gray-200 hover:border-orange-300 hover:shadow-md transition-all duration-200">
                      <div className="flex items-start justify-between mb-4">
                        <div className="flex items-center gap-3">
                          <div className="w-12 h-12 bg-gradient-to-br from-orange-400 to-amber-500 rounded-lg flex items-center justify-center text-white font-bold">
                            {edu.institution.charAt(0) || "U"}
                          </div>
                          <div>
                            <h3 className="font-semibold text-gray-900">{edu.degree || "Degree"}</h3>
                            <p className="text-orange-600 font-medium">{edu.institution || "Institution"}</p>
                            <p className="text-sm text-gray-500">{edu.fieldOfStudy || "Field of Study"}</p>
                            <p className="text-sm text-gray-500">{edu.startDate} - {edu.endDate}</p>
                          </div>
                        </div>
                        <Button 
                          size="sm" 
                          variant="ghost" 
                          onClick={() => handleRemoveEducation(index)}
                          className="text-red-600 hover:bg-red-50"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                        <div className="space-y-2">
                          <Label>Institution</Label>
                          <Input
                            value={edu.institution}
                            onChange={(e) => {
                              const newEducations = [...educations];
                              newEducations[index].institution = e.target.value;
                              setEducations(newEducations);
                              setHasUnsavedChanges(true);
                            }}
                            placeholder="University or School"
                            className="hover:border-orange-300 focus:border-orange-500"
                          />
                        </div>
                        <div className="space-y-2">
                          <Label>Degree</Label>
                          <Input
                            value={edu.degree}
                            onChange={(e) => {
                              const newEducations = [...educations];
                              newEducations[index].degree = e.target.value;
                              setEducations(newEducations);
                              setHasUnsavedChanges(true);
                            }}
                            placeholder="Bachelor's, Master's, etc."
                            className="hover:border-orange-300 focus:border-orange-500"
                          />
                        </div>
                        <div className="space-y-2">
                          <Label>Field of Study</Label>
                          <Input
                            value={edu.fieldOfStudy}
                            onChange={(e) => {
                              const newEducations = [...educations];
                              newEducations[index].fieldOfStudy = e.target.value;
                              setEducations(newEducations);
                              setHasUnsavedChanges(true);
                            }}
                            placeholder="Computer Science, Business, etc."
                            className="hover:border-orange-300 focus:border-orange-500"
                          />
                        </div>
                        <div className="space-y-2">
                          <Label>Graduation Date</Label>
                          <Input
                            type="month"
                            value={edu.endDate}
                            onChange={(e) => {
                              const newEducations = [...educations];
                              newEducations[index].endDate = e.target.value;
                              setEducations(newEducations);
                              setHasUnsavedChanges(true);
                            }}
                            className="hover:border-orange-300 focus:border-orange-500"
                          />
                        </div>
                      </div>

                      <div className="space-y-2">
                        <Label>Description</Label>
                        <Textarea
                          value={edu.description}
                          onChange={(e) => {
                            const newEducations = [...educations];
                            newEducations[index].description = e.target.value;
                            setEducations(newEducations);
                            setHasUnsavedChanges(true);
                          }}
                          placeholder="Relevant coursework, achievements, honors..."
                          className="min-h-[80px] hover:border-orange-300 focus:border-orange-500"
                        />
                      </div>
                    </div>
                  ))}

                  {educations.length === 0 && (
                    <div className="text-center py-12 text-gray-500">
                      <GraduationCap className="w-12 h-12 mx-auto mb-4 text-gray-300" />
                      <p>No education added yet. Share your academic achievements!</p>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Projects Tab */}
          <TabsContent value="projects" className="space-y-6">
            <Card className="border-l-4 border-l-indigo-500 hover:shadow-lg transition-shadow duration-300">
              <CardHeader className="bg-gradient-to-r from-indigo-50 to-blue-50">
                <CardTitle className="flex items-center gap-2 text-indigo-800">
                  <Code className="w-5 h-5" />
                  Projects & Portfolio
                </CardTitle>
              </CardHeader>
              <CardContent className="p-6">
                <div className="flex justify-between items-center mb-6">
                  <p className="text-gray-600">Showcase your best work and technical projects</p>
                  <Button 
                    onClick={handleAddProject}
                    className="bg-indigo-600 hover:bg-indigo-700"
                  >
                    <Plus className="w-4 h-4 mr-2" />
                    Add Project
                  </Button>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {projects.map((project, index) => (
                    <div key={index} className="bg-white p-6 rounded-lg border border-gray-200 hover:border-indigo-300 hover:shadow-md transition-all duration-200">
                      <div className="flex items-start justify-between mb-4">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-2">
                            <h3 className="font-semibold text-gray-900">{project.name || "Project Name"}</h3>
                            {project.featured && (
                              <Badge className="bg-indigo-100 text-indigo-800">
                                <Star className="w-3 h-3 mr-1" />
                                Featured
                              </Badge>
                            )}
                          </div>
                          <p className="text-sm text-gray-600 mb-3">{project.description || "Project description..."}</p>
                          
                          <div className="flex flex-wrap gap-1 mb-3">
                            {project.technologies.map((tech, techIndex) => (
                              <Badge key={techIndex} variant="secondary" className="text-xs">
                                {tech}
                              </Badge>
                            ))}
                          </div>

                          <div className="flex gap-2">
                            {project.liveUrl && (
                              <Button size="sm" variant="outline" className="text-indigo-600 border-indigo-300">
                                <ExternalLink className="w-3 h-3 mr-1" />
                                Live Demo
                              </Button>
                            )}
                            {project.githubUrl && (
                              <Button size="sm" variant="outline" className="text-gray-600">
                                <Code className="w-3 h-3 mr-1" />
                                Code
                              </Button>
                            )}
                          </div>
                        </div>
                        
                        <Button 
                          size="sm" 
                          variant="ghost" 
                          onClick={() => handleRemoveProject(index)}
                          className="text-red-600 hover:bg-red-50"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>

                      <div className="space-y-3">
                        <div className="space-y-2">
                          <Label>Project Name</Label>
                          <Input
                            value={project.name}
                            onChange={(e) => {
                              const newProjects = [...projects];
                              newProjects[index].name = e.target.value;
                              setProjects(newProjects);
                              setHasUnsavedChanges(true);
                            }}
                            placeholder="My Awesome Project"
                            className="hover:border-indigo-300 focus:border-indigo-500"
                          />
                        </div>

                        <div className="space-y-2">
                          <Label>Description</Label>
                          <Textarea
                            value={project.description}
                            onChange={(e) => {
                              const newProjects = [...projects];
                              newProjects[index].description = e.target.value;
                              setProjects(newProjects);
                              setHasUnsavedChanges(true);
                            }}
                            placeholder="Describe what this project does and your role..."
                            className="min-h-[80px] hover:border-indigo-300 focus:border-indigo-500"
                          />
                        </div>

                        <div className="grid grid-cols-2 gap-3">
                          <div className="space-y-2">
                            <Label>Live URL</Label>
                            <Input
                              value={project.liveUrl}
                              onChange={(e) => {
                                const newProjects = [...projects];
                                newProjects[index].liveUrl = e.target.value;
                                setProjects(newProjects);
                                setHasUnsavedChanges(true);
                              }}
                              placeholder="https://..."
                              className="hover:border-indigo-300 focus:border-indigo-500"
                            />
                          </div>
                          <div className="space-y-2">
                            <Label>GitHub URL</Label>
                            <Input
                              value={project.githubUrl}
                              onChange={(e) => {
                                const newProjects = [...projects];
                                newProjects[index].githubUrl = e.target.value;
                                setProjects(newProjects);
                                setHasUnsavedChanges(true);
                              }}
                              placeholder="https://github.com/..."
                              className="hover:border-indigo-300 focus:border-indigo-500"
                            />
                          </div>
                        </div>

                        <div className="flex items-center gap-2">
                          <input
                            type="checkbox"
                            checked={project.featured}
                            onChange={(e) => {
                              const newProjects = [...projects];
                              newProjects[index].featured = e.target.checked;
                              setProjects(newProjects);
                              setHasUnsavedChanges(true);
                            }}
                            className="rounded"
                          />
                          <Label className="text-sm">Featured project</Label>
                        </div>
                      </div>
                    </div>
                  ))}

                  {projects.length === 0 && (
                    <div className="col-span-2 text-center py-12 text-gray-500">
                      <Code className="w-12 h-12 mx-auto mb-4 text-gray-300" />
                      <p>No projects added yet. Show off your technical skills!</p>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        {/* Floating Save Button */}
        <div className="fixed bottom-6 right-6 z-40">
          <Button
            size="lg"
            className={`shadow-lg transition-all duration-300 ${
              hasUnsavedChanges 
                ? 'bg-amber-500 hover:bg-amber-600 text-white animate-pulse' 
                : 'bg-green-600 hover:bg-green-700 text-white'
            }`}
            onClick={() => {
              setHasUnsavedChanges(false);
              toast({
                title: "Profile saved!",
                description: "Your profile changes have been saved successfully.",
              });
            }}
          >
            <Save className="w-5 h-5 mr-2" />
            {hasUnsavedChanges ? 'Save Changes' : 'Saved'}
          </Button>
        </div>
      </div>

      {/* Share Dialog */}
      <Dialog open={showShareDialog} onOpenChange={setShowShareDialog}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Share className="w-5 h-5 text-sky-600" />
              Share Your Profile
            </DialogTitle>
          </DialogHeader>
          
          <div className="space-y-4">
            <p className="text-sm text-gray-600">
              Share your professional profile with potential employers, colleagues, or on social media.
            </p>
            
            <div className="grid grid-cols-2 gap-3">
              <Button
                onClick={handleCopyLink}
                variant="outline"
                className="flex items-center gap-2 justify-start"
              >
                <Copy className="w-4 h-4" />
                Copy Link
              </Button>
              
              <Button
                onClick={handleLinkedInShare}
                variant="outline"
                className="flex items-center gap-2 justify-start bg-blue-50 border-blue-200 text-blue-700 hover:bg-blue-100"
              >
                <Linkedin className="w-4 h-4" />
                LinkedIn
              </Button>
              
              <Button
                onClick={handleEmailShare}
                variant="outline"
                className="flex items-center gap-2 justify-start bg-gray-50 border-gray-200 text-gray-700 hover:bg-gray-100"
              >
                <Mail className="w-4 h-4" />
                Email
              </Button>
              
              <Button
                onClick={handleTwitterShare}
                variant="outline"
                className="flex items-center gap-2 justify-start bg-sky-50 border-sky-200 text-sky-700 hover:bg-sky-100"
              >
                <Twitter className="w-4 h-4" />
                Twitter
              </Button>
            </div>
            
            <div className="border-t pt-4">
              <p className="text-xs text-gray-500 mb-2">Profile URL:</p>
              <div className="flex items-center gap-2 p-2 bg-gray-50 rounded text-xs text-gray-600 break-all">
                {window.location.origin}/candidate/profile-preview
              </div>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Add Experience Modal */}
      <Dialog open={showAddExperienceModal} onOpenChange={setShowAddExperienceModal}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-xl font-bold text-green-800">
              Add Work Experience
            </DialogTitle>
            {pendingExperiences.length > 0 && (
              <p className="text-sm text-gray-600">
                {pendingExperiences.length} experience(s) ready to save
              </p>
            )}
          </DialogHeader>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Add New Experience Form */}
            <div className="space-y-4">
              <h3 className="font-semibold text-green-700 border-b border-green-200 pb-2">Add New Experience</h3>
              <form onSubmit={(e) => { e.preventDefault(); handleSaveExperience(); }} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="experienceCompany">Company *</Label>
                <Input
                  id="experienceCompany"
                  value={newExperience.company}
                  onChange={(e) => setNewExperience({...newExperience, company: e.target.value})}
                  placeholder="Enter company name"
                  required
                />
              </div>
              <div>
                <Label htmlFor="experiencePosition">Position *</Label>
                <Input
                  id="experiencePosition"
                  value={newExperience.position}
                  onChange={(e) => setNewExperience({...newExperience, position: e.target.value})}
                  placeholder="Enter job title"
                  required
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="experienceStartDate">Start Date</Label>
                <Input
                  id="experienceStartDate"
                  type="month"
                  value={newExperience.startDate}
                  onChange={(e) => setNewExperience({...newExperience, startDate: e.target.value})}
                />
              </div>
              <div>
                <Label htmlFor="experienceEndDate">End Date</Label>
                <Input
                  id="experienceEndDate"
                  type="month"
                  value={newExperience.endDate}
                  onChange={(e) => setNewExperience({...newExperience, endDate: e.target.value})}
                  disabled={newExperience.current}
                />
              </div>
            </div>

            <div className="flex items-center space-x-2">
              <input
                type="checkbox"
                id="experienceCurrent"
                checked={newExperience.current}
                onChange={(e) => setNewExperience({...newExperience, current: e.target.checked, endDate: e.target.checked ? "" : newExperience.endDate})}
                className="rounded"
              />
              <Label htmlFor="experienceCurrent">This is my current role</Label>
            </div>

            <div>
              <Label htmlFor="experienceDescription">Description</Label>
              <Textarea
                id="experienceDescription"
                value={newExperience.description}
                onChange={(e) => setNewExperience({...newExperience, description: e.target.value})}
                placeholder="Describe your responsibilities and achievements..."
                rows={3}
              />
            </div>

                <div className="flex gap-3 pt-4">
                  <Button
                    type="submit"
                    className="w-full bg-green-600 hover:bg-green-700"
                  >
                    Add to Queue
                  </Button>
                </div>
              </form>
            </div>

            {/* Pending Experiences Grid */}
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="font-semibold text-green-700 border-b border-green-200 pb-2 flex-1">
                  Pending Experiences ({pendingExperiences.length})
                </h3>
                {pendingExperiences.length > 0 && (
                  <Button
                    onClick={handleClearPendingExperiences}
                    variant="outline"
                    size="sm"
                    className="ml-2 text-red-600 border-red-200 hover:bg-red-50"
                  >
                    Clear All
                  </Button>
                )}
              </div>

              {pendingExperiences.length === 0 ? (
                <div className="text-center py-8 text-gray-500 bg-gray-50 rounded-lg border-2 border-dashed border-gray-200">
                  <p>No pending experiences</p>
                  <p className="text-sm">Add experiences using the form to see them here</p>
                </div>
              ) : (
                <div className="space-y-3 max-h-60 overflow-y-auto">
                  {pendingExperiences.map((exp, index) => (
                    <div key={index} className="bg-green-50 p-4 rounded-lg border border-green-200">
                      <div className="flex justify-between items-start">
                        <div className="flex-1">
                          <h4 className="font-medium text-green-800">{exp.position}</h4>
                          <p className="text-green-700">{exp.company}</p>
                          <p className="text-sm text-green-600">
                            {exp.startDate} - {exp.current ? "Present" : exp.endDate}
                          </p>
                          {exp.description && (
                            <p className="text-sm text-gray-600 mt-1 line-clamp-2">{exp.description}</p>
                          )}
                        </div>
                        <Button
                          onClick={() => handleRemovePendingExperience(index)}
                          variant="ghost"
                          size="sm"
                          className="text-red-600 hover:bg-red-50"
                        >
                          <X className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {/* Save All Button */}
              {pendingExperiences.length > 0 && (
                <div className="space-y-2 pt-4 border-t border-green-200">
                  <Button
                    onClick={handleSaveAllExperiences}
                    disabled={isSavingExperiences}
                    className="w-full bg-green-600 hover:bg-green-700"
                  >
                    {isSavingExperiences ? "Saving..." : `Save All ${pendingExperiences.length} Experience(s)`}
                  </Button>
                  <Button
                    onClick={() => setShowAddExperienceModal(false)}
                    variant="outline"
                    className="w-full"
                  >
                    Close
                  </Button>
                </div>
              )}

              {pendingExperiences.length === 0 && (
                <Button
                  onClick={() => setShowAddExperienceModal(false)}
                  variant="outline"
                  className="w-full"
                >
                  Close
                </Button>
              )}
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Add Education Modal */}
      <Dialog open={showAddEducationModal} onOpenChange={setShowAddEducationModal}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-xl font-bold text-orange-800">
              Add Education
            </DialogTitle>
            {pendingEducations.length > 0 && (
              <p className="text-sm text-gray-600">
                {pendingEducations.length} education(s) ready to save
              </p>
            )}
          </DialogHeader>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="space-y-4">
              <h3 className="font-semibold text-orange-700 border-b border-orange-200 pb-2">Add New Education</h3>
              
              <form onSubmit={(e) => { e.preventDefault(); handleSaveEducation(); }} className="space-y-4">
                <div>
                  <Label htmlFor="institution">Institution *</Label>
                  <Input
                    id="institution"
                    value={newEducation.institution}
                    onChange={(e) => setNewEducation({...newEducation, institution: e.target.value})}
                    placeholder="Enter institution name"
                    required
                  />
                </div>

                <div>
                  <Label htmlFor="degree">Degree *</Label>
                  <Input
                    id="degree"
                    value={newEducation.degree}
                    onChange={(e) => setNewEducation({...newEducation, degree: e.target.value})}
                    placeholder="e.g. Bachelor's in Computer Science"
                    required
                  />
                </div>

                <div>
                  <Label htmlFor="fieldOfStudy">Field of Study</Label>
                  <Input
                    id="fieldOfStudy"
                    value={newEducation.fieldOfStudy}
                    onChange={(e) => setNewEducation({...newEducation, fieldOfStudy: e.target.value})}
                    placeholder="e.g. Computer Science"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <Label htmlFor="startDate">Start Date</Label>
                    <Input
                      id="startDate"
                      type="date"
                      value={newEducation.startDate}
                      onChange={(e) => setNewEducation({...newEducation, startDate: e.target.value})}
                    />
                  </div>
                  <div>
                    <Label htmlFor="endDate">End Date</Label>
                    <Input
                      id="endDate"
                      type="date"
                      value={newEducation.endDate}
                      onChange={(e) => setNewEducation({...newEducation, endDate: e.target.value})}
                    />
                  </div>
                </div>

                <div>
                  <Label htmlFor="description">Description</Label>
                  <Textarea
                    id="description"
                    value={newEducation.description}
                    onChange={(e) => setNewEducation({...newEducation, description: e.target.value})}
                    placeholder="Optional description, achievements, coursework, etc."
                    rows={3}
                  />
                </div>

                <div className="flex gap-3 pt-4">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => setShowAddEducationModal(false)}
                    className="flex-1"
                  >
                    Cancel
                  </Button>
                  <Button
                    type="submit"
                    className="flex-1 bg-orange-600 hover:bg-orange-700"
                  >
                    Add to Queue
                  </Button>
                </div>
              </form>
            </div>

            {/* Pending Educations Display */}
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="font-semibold text-orange-700 border-b border-orange-200 pb-2 flex-1">
                  Pending Educations ({pendingEducations.length})
                </h3>
                {pendingEducations.length > 0 && (
                  <Button
                    onClick={handleClearPendingEducations}
                    variant="outline"
                    size="sm"
                    className="ml-2 text-red-600 border-red-200 hover:bg-red-50"
                  >
                    Clear All
                  </Button>
                )}
              </div>

              {pendingEducations.length === 0 ? (
                <div className="text-center py-8 text-gray-500 bg-gray-50 rounded-lg border-2 border-dashed border-gray-200">
                  <p>No pending educations</p>
                  <p className="text-sm">Add educations using the form to see them here</p>
                </div>
              ) : (
                <div className="space-y-3 max-h-80 overflow-y-auto">
                  {pendingEducations.map((education, index) => (
                    <div key={index} className="bg-orange-50 p-3 rounded-lg border border-orange-200">
                      <div className="flex justify-between items-start">
                        <div className="flex-1">
                          <h4 className="font-medium text-orange-800">{education.degree}</h4>
                          <p className="text-sm text-orange-600">{education.institution}</p>
                          {education.fieldOfStudy && (
                            <p className="text-xs text-orange-500">{education.fieldOfStudy}</p>
                          )}
                          {education.startDate && education.endDate && (
                            <p className="text-xs text-gray-500">
                              {education.startDate} - {education.endDate}
                            </p>
                          )}
                        </div>
                        <Button
                          onClick={() => handleRemovePendingEducation(index)}
                          variant="ghost"
                          size="sm"
                          className="text-red-600 hover:bg-red-50"
                        >
                          <X className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {pendingEducations.length > 0 && (
                <Button
                  onClick={handleSaveAllEducations}
                  disabled={isSavingEducations}
                  className="w-full bg-orange-600 hover:bg-orange-700"
                >
                  {isSavingEducations ? "Saving..." : `Save All ${pendingEducations.length} Education(s)`}
                </Button>
              )}
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Add Skills Modal */}
      <Dialog open={showAddSkillModal} onOpenChange={setShowAddSkillModal}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-xl font-bold text-purple-800">
              Add Skill
            </DialogTitle>
            {pendingSkills.length > 0 && (
              <p className="text-sm text-gray-600">
                {pendingSkills.length} skill(s) ready to save
              </p>
            )}
          </DialogHeader>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="space-y-4">
              <h3 className="font-semibold text-purple-700 border-b border-purple-200 pb-2">Add New Skill</h3>
              
              <form onSubmit={(e) => { e.preventDefault(); handleSaveSkill(); }} className="space-y-4">
                <div>
                  <Label htmlFor="skillName">Skill Name *</Label>
                  <Input
                    id="skillName"
                    value={newSkill.name}
                    onChange={(e) => setNewSkill({...newSkill, name: e.target.value})}
                    placeholder="e.g. JavaScript, Python, Marketing"
                    required
                  />
                </div>

                <div>
                  <Label htmlFor="skillCategory">Category</Label>
                  <Select
                    value={newSkill.category}
                    onValueChange={(value) => setNewSkill({...newSkill, category: value})}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select category" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Technical">Technical</SelectItem>
                      <SelectItem value="Soft Skills">Soft Skills</SelectItem>
                      <SelectItem value="Language">Language</SelectItem>
                      <SelectItem value="Tools">Tools</SelectItem>
                      <SelectItem value="Frameworks">Frameworks</SelectItem>
                      <SelectItem value="Other">Other</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="skillLevel">Proficiency Level: {newSkill.level}/5</Label>
                  <input
                    type="range"
                    id="skillLevel"
                    min="1"
                    max="5"
                    value={newSkill.level}
                    onChange={(e) => setNewSkill({...newSkill, level: parseInt(e.target.value)})}
                    className="w-full h-2 bg-purple-200 rounded-lg appearance-none cursor-pointer slider"
                  />
                  <div className="flex justify-between text-xs text-gray-600 mt-1">
                    <span>Beginner</span>
                    <span>Expert</span>
                  </div>
                </div>

                <div className="flex gap-3 pt-4">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => setShowAddSkillModal(false)}
                    className="flex-1"
                  >
                    Cancel
                  </Button>
                  <Button
                    type="submit"
                    className="flex-1 bg-purple-600 hover:bg-purple-700"
                  >
                    Add to Queue
                  </Button>
                </div>
              </form>
            </div>

            {/* Pending Skills Display */}
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="font-semibold text-purple-700 border-b border-purple-200 pb-2 flex-1">
                  Pending Skills ({pendingSkills.length})
                </h3>
                {pendingSkills.length > 0 && (
                  <Button
                    onClick={handleClearPendingSkills}
                    variant="outline"
                    size="sm"
                    className="ml-2 text-red-600 border-red-200 hover:bg-red-50"
                  >
                    Clear All
                  </Button>
                )}
              </div>

              {pendingSkills.length === 0 ? (
                <div className="text-center py-8 text-gray-500 bg-gray-50 rounded-lg border-2 border-dashed border-gray-200">
                  <p>No pending skills</p>
                  <p className="text-sm">Add skills using the form to see them here</p>
                </div>
              ) : (
                <div className="space-y-3 max-h-80 overflow-y-auto">
                  {pendingSkills.map((skill, index) => (
                    <div key={index} className="bg-purple-50 p-3 rounded-lg border border-purple-200">
                      <div className="flex justify-between items-start">
                        <div className="flex-1">
                          <h4 className="font-medium text-purple-800">{skill.name}</h4>
                          <p className="text-sm text-purple-600">{skill.category}</p>
                          <div className="flex items-center gap-2 mt-1">
                            <div className="flex gap-1">
                              {[1, 2, 3, 4, 5].map((star) => (
                                <div key={star} className={`w-3 h-3 rounded-full ${star <= skill.level ? 'bg-purple-500' : 'bg-gray-200'}`} />
                              ))}
                            </div>
                            <span className="text-xs text-purple-500">Level {skill.level}</span>
                          </div>
                        </div>
                        <Button
                          onClick={() => handleRemovePendingSkill(index)}
                          variant="ghost"
                          size="sm"
                          className="text-red-600 hover:bg-red-50"
                        >
                          <X className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {pendingSkills.length > 0 && (
                <Button
                  onClick={handleSaveAllSkills}
                  disabled={isSavingSkills}
                  className="w-full bg-purple-600 hover:bg-purple-700"
                >
                  {isSavingSkills ? "Saving..." : `Save All ${pendingSkills.length} Skill(s)`}
                </Button>
              )}
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </PlatformLayout>
  );
}
                onChange={(e) => setNewSkill({...newSkill, name: e.target.value})}
                placeholder="Enter skill name"
                required
              />
            </div>

            <div>
              <Label htmlFor="skillCategory">Category</Label>
              <Select value={newSkill.category} onValueChange={(value) => setNewSkill({...newSkill, category: value})}>
                <SelectTrigger>
                  <SelectValue placeholder="Select category" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Programming">Programming</SelectItem>
                  <SelectItem value="Framework">Framework</SelectItem>
                  <SelectItem value="Database">Database</SelectItem>
                  <SelectItem value="DevOps">DevOps</SelectItem>
                  <SelectItem value="Design">Design</SelectItem>
                  <SelectItem value="Soft Skills">Soft Skills</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="skillLevel">Proficiency Level: {newSkill.level}%</Label>
              <input
                id="skillLevel"
                type="range"
                min="0"
                max="100"
                value={newSkill.level}
                onChange={(e) => setNewSkill({...newSkill, level: parseInt(e.target.value)})}
                className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer slider"
              />
              <div className="flex justify-between text-xs text-gray-500 mt-1">
                <span>Beginner</span>
                <span>Intermediate</span>
                <span>Expert</span>
              </div>
            </div>

            <div className="flex gap-3 pt-4">
              <Button
                type="button"
                variant="outline"
                onClick={() => setShowAddSkillModal(false)}
                className="flex-1"
              >
                Cancel
              </Button>
              <Button
                type="submit"
                className="flex-1 bg-purple-600 hover:bg-purple-700"
              >
                Add Skill
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>

      {/* Add Project Modal */}
      <Dialog open={showAddProjectModal} onOpenChange={setShowAddProjectModal}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle className="text-xl font-bold text-indigo-800">
              Add Project
            </DialogTitle>
          </DialogHeader>
          
          <form onSubmit={(e) => { e.preventDefault(); handleSaveProject(); }} className="space-y-4">
            <div>
              <Label htmlFor="projectName">Project Name *</Label>
              <Input
                id="projectName"
                value={newProject.name}
                onChange={(e) => setNewProject({...newProject, name: e.target.value})}
                placeholder="Enter project name"
                required
              />
            </div>

            <div>
              <Label htmlFor="projectDescription">Description</Label>
              <Textarea
                id="projectDescription"
                value={newProject.description}
                onChange={(e) => setNewProject({...newProject, description: e.target.value})}
                placeholder="Describe what this project does and your role..."
                rows={3}
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="projectLiveUrl">Live URL</Label>
                <Input
                  id="projectLiveUrl"
                  type="url"
                  value={newProject.liveUrl}
                  onChange={(e) => setNewProject({...newProject, liveUrl: e.target.value})}
                  placeholder="https://myproject.com"
                />
              </div>
              <div>
                <Label htmlFor="projectGithubUrl">GitHub URL</Label>
                <Input
                  id="projectGithubUrl"
                  type="url"
                  value={newProject.githubUrl}
                  onChange={(e) => setNewProject({...newProject, githubUrl: e.target.value})}
                  placeholder="https://github.com/username/repo"
                />
              </div>
            </div>

            <div className="flex items-center space-x-2">
              <input
                type="checkbox"
                id="projectFeatured"
                checked={newProject.featured}
                onChange={(e) => setNewProject({...newProject, featured: e.target.checked})}
                className="rounded"
              />
              <Label htmlFor="projectFeatured">Feature this project</Label>
            </div>

            <div className="flex gap-3 pt-4">
              <Button
                type="button"
                variant="outline"
                onClick={() => setShowAddProjectModal(false)}
                className="flex-1"
              >
                Cancel
              </Button>
              <Button
                type="submit"
                className="flex-1 bg-indigo-600 hover:bg-indigo-700"
              >
                Add to Queue
              </Button>
            </div>
          </form>

          {/* Pending Projects Display */}
          {pendingProjects.length > 0 && (
            <div className="mt-6 space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="font-semibold text-indigo-700">
                  Pending Projects ({pendingProjects.length})
                </h3>
                <Button
                  onClick={handleClearPendingProjects}
                  variant="outline"
                  size="sm"
                  className="text-red-600 border-red-200 hover:bg-red-50"
                >
                  Clear All
                </Button>
              </div>

              <div className="space-y-3 max-h-40 overflow-y-auto">
                {pendingProjects.map((project, index) => (
                  <div key={index} className="bg-indigo-50 p-3 rounded-lg border border-indigo-200">
                    <div className="flex justify-between items-start">
                      <div className="flex-1">
                        <h4 className="font-medium text-indigo-800">{project.name}</h4>
                        <p className="text-sm text-indigo-600">{project.description}</p>
                        {project.technologies.length > 0 && (
                          <div className="flex gap-1 mt-1">
                            {project.technologies.slice(0, 3).map((tech, i) => (
                              <Badge key={i} variant="secondary" className="text-xs">
                                {tech}
                              </Badge>
                            ))}
                          </div>
                        )}
                      </div>
                      <Button
                        onClick={() => handleRemovePendingProject(index)}
                        variant="ghost"
                        size="sm"
                        className="text-red-600 hover:bg-red-50"
                      >
                        <X className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>

              <Button
                onClick={handleSaveAllProjects}
                disabled={isSavingProjects}
                className="w-full bg-indigo-600 hover:bg-indigo-700"
              >
                {isSavingProjects ? "Saving..." : `Save All ${pendingProjects.length} Project(s)`}
              </Button>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </PlatformLayout>
  );
}