import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { BarChart3, Download, Filter, Eye, Users, Clock, Award, TrendingUp } from "lucide-react";
import PlatformLayout from "@/components/layout/platform-layout";
import { platformConfigs } from "@/config/complete-navigation";

function TestReportsContent() {
  const [selectedTest, setSelectedTest] = useState("all");
  const [dateRange, setDateRange] = useState("7days");

  const { data: testReports = [], isLoading } = useQuery({
    queryKey: ["/api/test-reports", selectedTest, dateRange],
    retry: false,
  });

  const mockReports = [
    {
      id: "1",
      testTitle: "Senior Java Developer Assessment",
      totalAttempts: 124,
      avgScore: 72.5,
      passRate: 68,
      avgTime: 45,
      completionRate: 89,
      createdDate: "2024-01-10",
      lastAttempt: "2024-01-20"
    },
    {
      id: "2", 
      testTitle: "React Advanced Concepts",
      totalAttempts: 89,
      avgScore: 78.2,
      passRate: 74,
      avgTime: 38,
      completionRate: 92,
      createdDate: "2024-01-08",
      lastAttempt: "2024-01-19"
    },
    {
      id: "3",
      testTitle: "Python Data Structures",
      totalAttempts: 156,
      avgScore: 65.8,
      passRate: 58,
      avgTime: 52,
      completionRate: 85,
      createdDate: "2024-01-05",
      lastAttempt: "2024-01-18"
    }
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
      <div className="mb-8">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Test Reports</h1>
            <p className="text-gray-600">Analyze test performance and candidate insights</p>
          </div>
          <Button className="bg-sky-primary hover:bg-sky-600 text-white">
            <Download className="mr-2 h-4 w-4" />
            Export Reports
          </Button>
        </div>
      </div>

      <Tabs defaultValue="overview" className="space-y-6">
        <TabsList>
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="detailed">Detailed Reports</TabsTrigger>
          <TabsTrigger value="analytics">Analytics</TabsTrigger>
          <TabsTrigger value="comparisons">Comparisons</TabsTrigger>
        </TabsList>

        <TabsContent value="overview">
          {/* Summary Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">Total Tests</p>
                    <p className="text-3xl font-bold text-gray-900">24</p>
                  </div>
                  <div className="w-12 h-12 bg-sky-100 rounded-lg flex items-center justify-center">
                    <BarChart3 className="w-6 h-6 text-sky-primary" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">Total Attempts</p>
                    <p className="text-3xl font-bold text-gray-900">1,247</p>
                  </div>
                  <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                    <Users className="w-6 h-6 text-green-500" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">Avg Success Rate</p>
                    <p className="text-3xl font-bold text-gray-900">72%</p>
                  </div>
                  <div className="w-12 h-12 bg-yellow-100 rounded-lg flex items-center justify-center">
                    <Award className="w-6 h-6 text-yellow-500" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">Avg Completion Time</p>
                    <p className="text-3xl font-bold text-gray-900">42m</p>
                  </div>
                  <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
                    <Clock className="w-6 h-6 text-purple-500" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Filters */}
          <Card className="mb-6">
            <CardContent className="pt-6">
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div>
                  <label className="block text-sm font-medium mb-2">Test</label>
                  <Select value={selectedTest} onValueChange={setSelectedTest}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Tests</SelectItem>
                      <SelectItem value="java-senior">Senior Java Developer</SelectItem>
                      <SelectItem value="react-advanced">React Advanced</SelectItem>
                      <SelectItem value="python-ds">Python Data Structures</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2">Date Range</label>
                  <Select value={dateRange} onValueChange={setDateRange}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="7days">Last 7 days</SelectItem>
                      <SelectItem value="30days">Last 30 days</SelectItem>
                      <SelectItem value="3months">Last 3 months</SelectItem>
                      <SelectItem value="all">All time</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2">Subject</label>
                  <Select>
                    <SelectTrigger>
                      <SelectValue placeholder="All Subjects" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Subjects</SelectItem>
                      <SelectItem value="java">Java</SelectItem>
                      <SelectItem value="react">React</SelectItem>
                      <SelectItem value="python">Python</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="flex items-end">
                  <Button variant="outline" className="w-full">
                    <Filter className="mr-2 h-4 w-4" />
                    Apply Filters
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Test Reports List */}
          <div className="space-y-4">
            {mockReports.map((report) => (
              <Card key={report.id} className="hover:shadow-md transition-shadow">
                <CardContent className="pt-6">
                  <div className="flex items-start justify-between mb-4">
                    <div>
                      <h3 className="text-lg font-semibold text-gray-900">{report.testTitle}</h3>
                      <p className="text-sm text-gray-500">Created: {report.createdDate} • Last attempt: {report.lastAttempt}</p>
                    </div>
                    <Button variant="outline" size="sm">
                      <Eye className="mr-2 h-4 w-4" />
                      View Details
                    </Button>
                  </div>
                  
                  <div className="grid grid-cols-2 md:grid-cols-6 gap-4">
                    <div className="text-center">
                      <div className="text-2xl font-bold text-sky-primary">{report.totalAttempts}</div>
                      <div className="text-xs text-gray-500">Attempts</div>
                    </div>
                    <div className="text-center">
                      <div className="text-2xl font-bold text-green-500">{report.avgScore}%</div>
                      <div className="text-xs text-gray-500">Avg Score</div>
                    </div>
                    <div className="text-center">
                      <div className="text-2xl font-bold text-yellow-500">{report.passRate}%</div>
                      <div className="text-xs text-gray-500">Pass Rate</div>
                    </div>
                    <div className="text-center">
                      <div className="text-2xl font-bold text-purple-500">{report.avgTime}m</div>
                      <div className="text-xs text-gray-500">Avg Time</div>
                    </div>
                    <div className="text-center">
                      <div className="text-2xl font-bold text-blue-500">{report.completionRate}%</div>
                      <div className="text-xs text-gray-500">Completion</div>
                    </div>
                    <div className="text-center">
                      <Badge variant={report.passRate >= 70 ? "default" : "secondary"}>
                        {report.passRate >= 70 ? "Good" : "Needs Review"}
                      </Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="detailed">
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Question-wise Performance</CardTitle>
                <CardDescription>
                  Analyze performance for each question in your tests
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {[
                    { question: "What is polymorphism in Java?", correct: 85, incorrect: 15, avgTime: "2m 30s" },
                    { question: "Explain React hooks lifecycle", correct: 72, incorrect: 28, avgTime: "4m 15s" },
                    { question: "Implement binary search algorithm", correct: 58, incorrect: 42, avgTime: "8m 45s" },
                  ].map((item, index) => (
                    <div key={index} className="border rounded-lg p-4">
                      <div className="flex items-start justify-between mb-3">
                        <div className="flex-1">
                          <h4 className="font-medium text-gray-900">{item.question}</h4>
                          <p className="text-sm text-gray-500 mt-1">Average time: {item.avgTime}</p>
                        </div>
                      </div>
                      <div className="flex items-center space-x-4">
                        <div className="flex-1">
                          <div className="flex items-center justify-between text-sm mb-1">
                            <span>Correct Answers</span>
                            <span>{item.correct}%</span>
                          </div>
                          <div className="w-full bg-gray-200 rounded-full h-2">
                            <div 
                              className="bg-green-500 h-2 rounded-full" 
                              style={{ width: `${item.correct}%` }}
                            ></div>
                          </div>
                        </div>
                        <div className="flex-1">
                          <div className="flex items-center justify-between text-sm mb-1">
                            <span>Incorrect Answers</span>
                            <span>{item.incorrect}%</span>
                          </div>
                          <div className="w-full bg-gray-200 rounded-full h-2">
                            <div 
                              className="bg-red-500 h-2 rounded-full" 
                              style={{ width: `${item.incorrect}%` }}
                            ></div>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="analytics">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Performance Trends</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">This Week</span>
                    <div className="flex items-center">
                      <TrendingUp className="w-4 h-4 text-green-500 mr-1" />
                      <span className="text-sm text-green-600">+12%</span>
                    </div>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div className="bg-sky-primary h-2 rounded-full" style={{ width: '75%' }}></div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Top Performing Tests</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {[
                    { name: "React Advanced", score: 89 },
                    { name: "Java Senior", score: 85 },
                    { name: "Python DS", score: 78 },
                  ].map((test, index) => (
                    <div key={index} className="flex items-center justify-between">
                      <span className="text-sm font-medium">{test.name}</span>
                      <span className="text-sm text-gray-600">{test.score}%</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="comparisons">
          <Card>
            <CardHeader>
              <CardTitle>Test Comparisons</CardTitle>
              <CardDescription>
                Compare performance across different tests
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <Select>
                    <SelectTrigger>
                      <SelectValue placeholder="Select first test" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="java-senior">Senior Java Developer</SelectItem>
                      <SelectItem value="react-advanced">React Advanced</SelectItem>
                    </SelectContent>
                  </Select>
                  <Select>
                    <SelectTrigger>
                      <SelectValue placeholder="Select second test" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="python-ds">Python Data Structures</SelectItem>
                      <SelectItem value="javascript-es6">JavaScript ES6</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                <div className="bg-gray-50 rounded-lg p-6">
                  <p className="text-center text-gray-500">
                    Select two tests to see detailed comparison metrics
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}

export default function TestReports() {
  const config = platformConfigs.candidate;
  
  const usageData = [
    { label: "Reports Generated", current: 45, max: 100 },
    { label: "Data Export Credits", current: 12, max: 25 },
    { label: "Advanced Analytics", current: 8, max: 15 },
  ];

  return (
    <PlatformLayout
      sidebarTitle={config.sidebarTitle}
      sidebarSubtitle={config.sidebarSubtitle}
      sidebarSections={config.sidebarSections}
      usageData={usageData}
    >
      <TestReportsContent />
    </PlatformLayout>
  );
}