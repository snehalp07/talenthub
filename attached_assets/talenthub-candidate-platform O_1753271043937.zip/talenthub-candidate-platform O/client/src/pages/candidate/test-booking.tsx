import { useState } from "react";
import PlatformLayout from "@/components/layout/platform-layout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Calendar, Clock, DollarSign, MapPin, Award, Users, Star } from "lucide-react";
import { candidateNavigation } from "@/config/complete-navigation";

export default function TestBooking() {
  const [selectedTest, setSelectedTest] = useState<string | null>(null);

  const availableTests = [
    {
      id: "js-cert",
      title: "JavaScript Certification",
      description: "Comprehensive JavaScript assessment with ES6+, frameworks, and best practices",
      duration: "90 minutes",
      price: 149,
      difficulty: "Intermediate",
      category: "Frontend Development",
      locations: ["Online Proctored", "Test Center - Downtown", "Test Center - Uptown"],
      nextAvailable: "Tomorrow 9:00 AM",
      rating: 4.8,
      candidates: 2847
    },
    {
      id: "react-advanced",
      title: "React Advanced Assessment",
      description: "Advanced React concepts including hooks, context, performance optimization",
      duration: "120 minutes", 
      price: 199,
      difficulty: "Advanced",
      category: "Frontend Development",
      locations: ["Online Proctored", "Test Center - Downtown"],
      nextAvailable: "Dec 24, 2:00 PM",
      rating: 4.9,
      candidates: 1654
    },
    {
      id: "full-stack",
      title: "Full-Stack Developer Certification",
      description: "Complete full-stack assessment covering frontend, backend, and database skills",
      duration: "180 minutes",
      price: 299,
      difficulty: "Expert",
      category: "Full-Stack Development",
      locations: ["Test Center - Downtown", "Test Center - Uptown"],
      nextAvailable: "Dec 26, 10:00 AM",
      rating: 4.7,
      candidates: 3291
    }
  ];

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case "Beginner": return "bg-green-100 text-green-800";
      case "Intermediate": return "bg-yellow-100 text-yellow-800";
      case "Advanced": return "bg-orange-100 text-orange-800";
      case "Expert": return "bg-red-100 text-red-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  return (
    <PlatformLayout
      sidebarTitle="Candidate Platform"
      sidebarSubtitle="Your Professional Journey"
      sidebarSections={candidateNavigation}
    >
      <div className="min-h-screen bg-gradient-to-br from-purple-50 via-white to-blue-50 p-6">
        <div className="max-w-6xl mx-auto">
          {/* Header */}
          <div className="mb-8">
            <div className="flex items-center gap-3 mb-4">
              <div className="bg-purple-600 p-2 rounded-lg">
                <Calendar className="h-6 w-6 text-white" />
              </div>
              <div>
                <h1 className="text-3xl font-bold bg-gradient-to-r from-purple-600 to-blue-600 bg-clip-text text-transparent">
                  Test Booking System
                </h1>
                <p className="text-gray-600">Schedule your certification assessments and skill evaluations</p>
              </div>
            </div>
          </div>

          {/* Stats Cards */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
            <Card className="bg-gradient-to-br from-purple-500 to-purple-600 text-white">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-purple-100">Available Tests</p>
                    <p className="text-2xl font-bold">24</p>
                  </div>
                  <Award className="h-8 w-8 text-purple-200" />
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-br from-blue-500 to-blue-600 text-white">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-blue-100">Test Centers</p>
                    <p className="text-2xl font-bold">8</p>
                  </div>
                  <MapPin className="h-8 w-8 text-blue-200" />
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-br from-green-500 to-green-600 text-white">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-green-100">Online Slots</p>
                    <p className="text-2xl font-bold">48</p>
                  </div>
                  <Clock className="h-8 w-8 text-green-200" />
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-br from-orange-500 to-orange-600 text-white">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-orange-100">Avg. Price</p>
                    <p className="text-2xl font-bold">$189</p>
                  </div>
                  <DollarSign className="h-8 w-8 text-orange-200" />
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Available Tests */}
          <div className="space-y-6">
            <h2 className="text-2xl font-bold text-gray-800 mb-6">Available Certification Tests</h2>
            
            {availableTests.map((test) => (
              <Card key={test.id} className="hover:shadow-lg transition-all duration-300 border-l-4 border-l-purple-500">
                <CardHeader>
                  <div className="flex justify-between items-start">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <CardTitle className="text-xl text-gray-800">{test.title}</CardTitle>
                        <Badge className={getDifficultyColor(test.difficulty)}>
                          {test.difficulty}
                        </Badge>
                        <Badge variant="outline" className="bg-purple-50 text-purple-700">
                          {test.category}
                        </Badge>
                      </div>
                      <CardDescription className="text-gray-600 mb-4">
                        {test.description}
                      </CardDescription>
                      
                      <div className="flex items-center gap-6 text-sm text-gray-600">
                        <div className="flex items-center gap-1">
                          <Clock className="h-4 w-4" />
                          <span>{test.duration}</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <Star className="h-4 w-4 text-yellow-500" />
                          <span>{test.rating}</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <Users className="h-4 w-4" />
                          <span>{test.candidates.toLocaleString()} candidates</span>
                        </div>
                      </div>
                    </div>
                    
                    <div className="text-right">
                      <div className="text-2xl font-bold text-purple-600">${test.price}</div>
                      <div className="text-sm text-gray-500">per attempt</div>
                    </div>
                  </div>
                </CardHeader>
                
                <CardContent>
                  <div className="space-y-4">
                    <div>
                      <h4 className="font-semibold text-gray-800 mb-2">Available Locations:</h4>
                      <div className="flex flex-wrap gap-2">
                        {test.locations.map((location, index) => (
                          <Badge key={index} variant="secondary" className="bg-blue-50 text-blue-700">
                            <MapPin className="h-3 w-3 mr-1" />
                            {location}
                          </Badge>
                        ))}
                      </div>
                    </div>
                    
                    <div className="flex items-center justify-between pt-4 border-t">
                      <div className="text-sm text-gray-600">
                        <span className="font-medium">Next Available:</span> {test.nextAvailable}
                      </div>
                      <div className="flex gap-3">
                        <Button 
                          variant="outline" 
                          onClick={() => setSelectedTest(test.id)}
                          className="border-purple-200 text-purple-700 hover:bg-purple-50"
                        >
                          View Details
                        </Button>
                        <Button 
                          className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
                          onClick={() => setSelectedTest(test.id)}
                        >
                          <Calendar className="h-4 w-4 mr-2" />
                          Book Now
                        </Button>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {/* Booking Information */}
          <Card className="mt-8 bg-gradient-to-r from-purple-50 to-blue-50 border-purple-200">
            <CardHeader>
              <CardTitle className="text-purple-800">Booking Information</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <h4 className="font-semibold text-gray-800 mb-2">Payment Options</h4>
                  <ul className="space-y-1 text-sm text-gray-600">
                    <li>• Credit/Debit Cards (Visa, MasterCard, AmEx)</li>
                    <li>• PayPal and digital wallets</li>
                    <li>• Corporate billing accounts</li>
                    <li>• Installment plans available for premium tests</li>
                  </ul>
                </div>
                
                <div>
                  <h4 className="font-semibold text-gray-800 mb-2">Cancellation Policy</h4>
                  <ul className="space-y-1 text-sm text-gray-600">
                    <li>• Free cancellation up to 48 hours before test</li>
                    <li>• 50% refund for cancellations within 24-48 hours</li>
                    <li>• Rescheduling available once per booking</li>
                    <li>• Emergency cancellations considered case-by-case</li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </PlatformLayout>
  );
}