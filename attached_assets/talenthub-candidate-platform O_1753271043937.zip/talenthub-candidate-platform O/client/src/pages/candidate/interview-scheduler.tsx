import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import PlatformLayout from "@/components/layout/platform-layout";
import { platformConfigs } from "@/config/complete-navigation";
import { useThemeClasses } from "@/lib/theme-config";
import { 
  Calendar, 
  Clock, 
  Video, 
  MapPin,
  Users,
  Plus,
  Edit,
  Trash2,
  CheckCircle,
  AlertCircle,
  Phone,
  Mail,
  ExternalLink,
  FileText,
  Briefcase
} from "lucide-react";

function InterviewSchedulerContent() {
  const [selectedDate, setSelectedDate] = useState("");
  const [selectedTime, setSelectedTime] = useState("");
  const [interviewType, setInterviewType] = useState("video");

  const upcomingInterviews = [
    {
      id: "1",
      jobTitle: "Senior Frontend Developer",
      company: "TechCorp Inc.",
      interviewer: "Sarah Johnson",
      interviewerRole: "Engineering Manager",
      date: "2024-01-25",
      time: "14:00",
      duration: "60 min",
      type: "video",
      status: "confirmed",
      meetingLink: "https://meet.google.com/abc-defg-hij",
      notes: "Technical interview focusing on React and system design",
      round: "Technical Round",
      location: "Online"
    },
    {
      id: "2",
      jobTitle: "Full Stack Engineer", 
      company: "StartupXYZ",
      interviewer: "Mike Chen",
      interviewerRole: "CTO",
      date: "2024-01-26",
      time: "10:30",
      duration: "45 min",
      type: "phone",
      status: "pending",
      phone: "+1 (555) 123-4567",
      notes: "Initial screening call to discuss background and experience",
      round: "Phone Screening",
      location: "Phone Call"
    },
    {
      id: "3",
      jobTitle: "UI/UX Developer",
      company: "Design Studio",
      interviewer: "Emma Davis",
      interviewerRole: "Design Director",
      date: "2024-01-27",
      time: "15:30",
      duration: "90 min",
      type: "in-person",
      status: "confirmed",
      address: "123 Design St, San Francisco, CA",
      notes: "Portfolio review and design challenge",
      round: "Final Round",
      location: "123 Design St, San Francisco, CA"
    }
  ];

  const availableSlots = [
    { date: "2024-01-28", slots: ["09:00", "10:00", "14:00", "15:00", "16:00"] },
    { date: "2024-01-29", slots: ["09:30", "11:00", "13:30", "15:30"] },
    { date: "2024-01-30", slots: ["10:00", "11:30", "14:30", "16:00"] }
  ];

  const interviewPrepTips = [
    {
      category: "Technical Preparation",
      tips: [
        "Review the job description and required skills",
        "Practice coding problems on relevant platforms",
        "Prepare examples of your past projects",
        "Research the company's tech stack"
      ]
    },
    {
      category: "Behavioral Questions",
      tips: [
        "Prepare STAR method examples",
        "Think of challenges you've overcome",
        "Research company values and culture",
        "Prepare questions about the role and team"
      ]
    },
    {
      category: "Day of Interview",
      tips: [
        "Test your technology setup 30 minutes early",
        "Have copies of your resume ready",
        "Prepare a quiet, professional space",
        "Have water and notes available"
      ]
    }
  ];

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "confirmed":
        return <Badge className="bg-green-100 text-green-700"><CheckCircle className="h-3 w-3 mr-1" />Confirmed</Badge>;
      case "pending":
        return <Badge className="bg-yellow-100 text-yellow-700"><AlertCircle className="h-3 w-3 mr-1" />Pending</Badge>;
      case "rescheduled":
        return <Badge className="bg-blue-100 text-blue-700"><Clock className="h-3 w-3 mr-1" />Rescheduled</Badge>;
      default:
        return <Badge className="bg-gray-100 text-gray-700">Unknown</Badge>;
    }
  };

  const getInterviewIcon = (type: string) => {
    switch (type) {
      case "video": return <Video className="h-4 w-4" />;
      case "phone": return <Phone className="h-4 w-4" />;
      case "in-person": return <MapPin className="h-4 w-4" />;
      default: return <Calendar className="h-4 w-4" />;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-sky-50 to-white p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Interview Scheduler</h1>
          <p className="text-gray-600">Manage your interview schedule and prepare for success</p>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card className="border-sky-200">
            <CardContent className="p-6 text-center">
              <Calendar className="h-8 w-8 text-sky-600 mx-auto mb-2" />
              <div className="text-2xl font-bold text-sky-700">{upcomingInterviews.length}</div>
              <div className="text-sm text-gray-600">Upcoming Interviews</div>
            </CardContent>
          </Card>
          <Card className="border-green-200">
            <CardContent className="p-6 text-center">
              <CheckCircle className="h-8 w-8 text-green-600 mx-auto mb-2" />
              <div className="text-2xl font-bold text-green-700">
                {upcomingInterviews.filter(i => i.status === "confirmed").length}
              </div>
              <div className="text-sm text-gray-600">Confirmed</div>
            </CardContent>
          </Card>
          <Card className="border-purple-200">
            <CardContent className="p-6 text-center">
              <Video className="h-8 w-8 text-purple-600 mx-auto mb-2" />
              <div className="text-2xl font-bold text-purple-700">
                {upcomingInterviews.filter(i => i.type === "video").length}
              </div>
              <div className="text-sm text-gray-600">Video Interviews</div>
            </CardContent>
          </Card>
          <Card className="border-orange-200">
            <CardContent className="p-6 text-center">
              <Clock className="h-8 w-8 text-orange-600 mx-auto mb-2" />
              <div className="text-2xl font-bold text-orange-700">12</div>
              <div className="text-sm text-gray-600">This Week</div>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="upcoming" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="upcoming">Upcoming Interviews</TabsTrigger>
            <TabsTrigger value="schedule">Schedule Interview</TabsTrigger>
            <TabsTrigger value="availability">Manage Availability</TabsTrigger>
            <TabsTrigger value="preparation">Interview Prep</TabsTrigger>
          </TabsList>

          {/* Upcoming Interviews Tab */}
          <TabsContent value="upcoming">
            <div className="space-y-4">
              {upcomingInterviews.map((interview) => (
                <Card key={interview.id} className="hover:shadow-lg transition-shadow">
                  <CardContent className="p-6">
                    <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
                      {/* Interview Details */}
                      <div className="flex-1">
                        <div className="flex items-start justify-between mb-3">
                          <div>
                            <h3 className="text-lg font-semibold text-gray-900 mb-1">
                              {interview.jobTitle}
                            </h3>
                            <div className="flex items-center gap-4 text-sm text-gray-600">
                              <span>{interview.company}</span>
                              <span>•</span>
                              <span>{interview.round}</span>
                            </div>
                          </div>
                          {getStatusBadge(interview.status)}
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4 text-sm">
                          <div className="flex items-center gap-2">
                            <Calendar className="h-4 w-4 text-gray-400" />
                            <span>{interview.date} at {interview.time}</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <Clock className="h-4 w-4 text-gray-400" />
                            <span>{interview.duration}</span>
                          </div>
                          <div className="flex items-center gap-2">
                            {getInterviewIcon(interview.type)}
                            <span className="capitalize">{interview.type}</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <Users className="h-4 w-4 text-gray-400" />
                            <span>{interview.interviewer} ({interview.interviewerRole})</span>
                          </div>
                        </div>

                        {/* Interview Notes */}
                        {interview.notes && (
                          <div className="mb-4 p-3 bg-gray-50 rounded-lg">
                            <h4 className="font-medium text-gray-900 mb-1">Notes:</h4>
                            <p className="text-sm text-gray-600">{interview.notes}</p>
                          </div>
                        )}

                        {/* Contact/Meeting Info */}
                        <div className="flex flex-wrap gap-3 text-sm">
                          {interview.meetingLink && (
                            <Button variant="outline" size="sm" asChild>
                              <a href={interview.meetingLink} target="_blank" rel="noopener noreferrer">
                                <Video className="h-4 w-4 mr-2" />
                                Join Video Call
                              </a>
                            </Button>
                          )}
                          {interview.phone && (
                            <Button variant="outline" size="sm" asChild>
                              <a href={`tel:${interview.phone}`}>
                                <Phone className="h-4 w-4 mr-2" />
                                {interview.phone}
                              </a>
                            </Button>
                          )}
                          {interview.address && (
                            <Button variant="outline" size="sm">
                              <MapPin className="h-4 w-4 mr-2" />
                              Get Directions
                            </Button>
                          )}
                        </div>
                      </div>

                      {/* Actions */}
                      <div className="flex flex-col gap-2 lg:w-48">
                        <Button className="w-full bg-sky-600 hover:bg-sky-700">
                          <FileText className="h-4 w-4 mr-2" />
                          View Details
                        </Button>
                        <Button variant="outline" className="w-full">
                          <Edit className="h-4 w-4 mr-2" />
                          Reschedule
                        </Button>
                        <div className="flex gap-2">
                          <Button variant="outline" size="sm" className="flex-1">
                            <Mail className="h-4 w-4 mr-2" />
                            Email
                          </Button>
                          <Button variant="outline" size="sm" className="flex-1">
                            <Calendar className="h-4 w-4 mr-2" />
                            Add to Cal
                          </Button>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          {/* Schedule Interview Tab */}
          <TabsContent value="schedule">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Plus className="h-5 w-5 text-sky-600" />
                  Schedule New Interview
                </CardTitle>
                <CardDescription>Add a new interview to your calendar</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="jobTitle">Job Title</Label>
                      <Input id="jobTitle" placeholder="e.g., Senior Frontend Developer" />
                    </div>
                    <div>
                      <Label htmlFor="company">Company</Label>
                      <Input id="company" placeholder="e.g., TechCorp Inc." />
                    </div>
                    <div>
                      <Label htmlFor="interviewer">Interviewer Name</Label>
                      <Input id="interviewer" placeholder="e.g., Sarah Johnson" />
                    </div>
                    <div>
                      <Label htmlFor="interviewerRole">Interviewer Role</Label>
                      <Input id="interviewerRole" placeholder="e.g., Engineering Manager" />
                    </div>
                  </div>

                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="date">Interview Date</Label>
                      <Input 
                        id="date" 
                        type="date" 
                        value={selectedDate}
                        onChange={(e) => setSelectedDate(e.target.value)}
                      />
                    </div>
                    <div>
                      <Label htmlFor="time">Interview Time</Label>
                      <Input 
                        id="time" 
                        type="time" 
                        value={selectedTime}
                        onChange={(e) => setSelectedTime(e.target.value)}
                      />
                    </div>
                    <div>
                      <Label>Interview Type</Label>
                      <Select value={interviewType} onValueChange={setInterviewType}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="video">Video Call</SelectItem>
                          <SelectItem value="phone">Phone Call</SelectItem>
                          <SelectItem value="in-person">In Person</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div>
                      <Label htmlFor="duration">Duration (minutes)</Label>
                      <Select>
                        <SelectTrigger>
                          <SelectValue placeholder="Select duration" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="30">30 minutes</SelectItem>
                          <SelectItem value="45">45 minutes</SelectItem>
                          <SelectItem value="60">60 minutes</SelectItem>
                          <SelectItem value="90">90 minutes</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                </div>

                <div>
                  <Label htmlFor="notes">Interview Notes</Label>
                  <Textarea 
                    id="notes" 
                    placeholder="Add any relevant notes or preparation items..."
                    rows={3}
                  />
                </div>

                <Button className="w-full bg-sky-600 hover:bg-sky-700">
                  <Calendar className="h-4 w-4 mr-2" />
                  Schedule Interview
                </Button>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Manage Availability Tab */}
          <TabsContent value="availability">
            <Card>
              <CardHeader>
                <CardTitle>Available Interview Slots</CardTitle>
                <CardDescription>Set your availability for upcoming interviews</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  {availableSlots.map((day) => (
                    <div key={day.date} className="border rounded-lg p-4">
                      <h3 className="font-medium text-gray-900 mb-3">
                        {new Date(day.date).toLocaleDateString('en-US', { 
                          weekday: 'long', 
                          year: 'numeric', 
                          month: 'long', 
                          day: 'numeric' 
                        })}
                      </h3>
                      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-2">
                        {day.slots.map((slot) => (
                          <Button 
                            key={slot}
                            variant="outline" 
                            size="sm"
                            className="hover:bg-sky-50 hover:border-sky-200"
                          >
                            {slot}
                          </Button>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Interview Preparation Tab */}
          <TabsContent value="preparation">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Preparation Checklist</CardTitle>
                  <CardDescription>Essential tips for interview success</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-6">
                    {interviewPrepTips.map((category, index) => (
                      <div key={index}>
                        <h4 className="font-medium text-gray-900 mb-3">{category.category}</h4>
                        <div className="space-y-2">
                          {category.tips.map((tip, tipIndex) => (
                            <div key={tipIndex} className="flex items-start gap-2">
                              <CheckCircle className="h-4 w-4 text-green-500 mt-0.5 flex-shrink-0" />
                              <span className="text-sm text-gray-600">{tip}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Quick Actions</CardTitle>
                  <CardDescription>Helpful tools for interview prep</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <Button variant="outline" className="w-full justify-start">
                    <Briefcase className="h-4 w-4 mr-2" />
                    Research Company
                  </Button>
                  <Button variant="outline" className="w-full justify-start">
                    <Users className="h-4 w-4 mr-2" />
                    Practice Mock Interview
                  </Button>
                  <Button variant="outline" className="w-full justify-start">
                    <FileText className="h-4 w-4 mr-2" />
                    Review Resume
                  </Button>
                  <Button variant="outline" className="w-full justify-start">
                    <ExternalLink className="h-4 w-4 mr-2" />
                    Test Video Setup
                  </Button>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}

export default function InterviewScheduler() {
  const config = platformConfigs.candidate;
  const theme = useThemeClasses('candidate');
  
  const usageData = [
    { label: "Scheduled Interviews", current: 3, max: 10 },
    { label: "Interview Success", current: 85, max: 100 },
    { label: "Prep Completion", current: 90, max: 100 },
  ];

  return (
    <PlatformLayout
      sidebarTitle={config.sidebarTitle}
      sidebarSubtitle={config.sidebarSubtitle}
      sidebarSections={config.sidebarSections}
      usageData={usageData}
    >
      <InterviewSchedulerContent />
    </PlatformLayout>
  );
}