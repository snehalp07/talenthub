import { useState } from "react";
import { useAuth } from "@/hooks/use-auth";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Slider } from "@/components/ui/slider";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import PlatformLayout from "@/components/layout/platform-layout";
import { platformConfigs } from "@/config/complete-navigation";
import { useThemeClasses } from "@/lib/theme-config";
import { 
  Palette, 
  Download, 
  Eye, 
  Share, 
  Edit,
  Save,
  Layout,
  BarChart3,
  PieChart,
  TrendingUp,
  Award,
  User,
  Briefcase,
  GraduationCap,
  Code,
  Star,
  MapPin,
  Calendar,
  Mail,
  Phone,
  Globe,
  Github,
  Linkedin,
  Image,
  Type,
  Zap,
  Copy,
  FileImage,
  Settings
} from "lucide-react";

function InfographicCVContent() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [selectedTemplate, setSelectedTemplate] = useState("modern-minimal");
  const [selectedSection, setSelectedSection] = useState("personal");
  const [colorScheme, setColorScheme] = useState("blue");

  const { data: templates } = useQuery({
    queryKey: ["/api/infographic-cv/templates"],
    initialData: [
      {
        id: "modern-minimal",
        name: "Modern Minimal",
        description: "Clean design with subtle colors and elegant typography",
        category: "Professional",
        colors: ["#2563eb", "#64748b", "#f8fafc"],
        preview: "/templates/modern-minimal.svg"
      },
      {
        id: "creative-bold",
        name: "Creative Bold",
        description: "Vibrant colors and dynamic layouts for creative roles",
        category: "Creative",
        colors: ["#7c3aed", "#f59e0b", "#ef4444"],
        preview: "/templates/creative-bold.svg"
      },
      {
        id: "tech-focused",
        name: "Tech Focused",
        description: "Data visualization heavy design for technical positions",
        category: "Technical",
        colors: ["#059669", "#0891b2", "#374151"],
        preview: "/templates/tech-focused.svg"
      },
      {
        id: "executive-premium",
        name: "Executive Premium",
        description: "Sophisticated design for senior management roles",
        category: "Executive",
        colors: ["#1f2937", "#6366f1", "#d1d5db"],
        preview: "/templates/executive-premium.svg"
      }
    ]
  });

  const { data: userProfile } = useQuery({
    queryKey: ["/api/profile/complete"],
    initialData: {
      personal: {
        fullName: "Alex Johnson",
        title: "Senior Full Stack Developer",
        email: "alex.johnson@email.com",
        phone: "+91 98765 43210",
        location: "Bangalore, India",
        website: "alexjohnson.dev",
        linkedin: "linkedin.com/in/alexjohnson",
        github: "github.com/alexjohnson",
        summary: "Experienced full-stack developer with 5+ years building scalable web applications. Passionate about clean code, user experience, and emerging technologies."
      },
      experience: [
        {
          company: "TechCorp Solutions",
          position: "Senior Full Stack Developer",
          duration: "2022 - Present",
          location: "Bangalore, India",
          achievements: [
            "Led team of 6 developers building React/Node.js applications",
            "Reduced application load time by 40% through optimization",
            "Implemented CI/CD pipeline improving deployment efficiency by 60%"
          ]
        },
        {
          company: "StartupXYZ",
          position: "Full Stack Developer",
          duration: "2020 - 2022",
          location: "Mumbai, India",
          achievements: [
            "Built MVP from scratch serving 10K+ users",
            "Integrated payment gateway processing ₹5M+ monthly",
            "Mentored 3 junior developers"
          ]
        }
      ],
      skills: {
        technical: [
          { name: "React.js", level: 90 },
          { name: "Node.js", level: 85 },
          { name: "Python", level: 80 },
          { name: "AWS", level: 75 },
          { name: "MongoDB", level: 85 },
          { name: "TypeScript", level: 88 }
        ],
        soft: [
          { name: "Leadership", level: 85 },
          { name: "Communication", level: 90 },
          { name: "Problem Solving", level: 95 },
          { name: "Team Collaboration", level: 88 }
        ]
      },
      education: [
        {
          degree: "B.Tech Computer Science",
          institution: "IIT Bombay",
          year: "2020",
          grade: "8.5 CGPA"
        }
      ],
      certifications: [
        {
          name: "AWS Solutions Architect",
          issuer: "Amazon",
          year: "2023",
          level: "Professional"
        },
        {
          name: "React Developer Certification",
          issuer: "TestEngine",
          year: "2024",
          level: "Advanced"
        }
      ],
      projects: [
        {
          name: "E-commerce Platform",
          description: "Full-stack e-commerce solution with React, Node.js, and MongoDB",
          technologies: ["React", "Node.js", "MongoDB", "Stripe"],
          metrics: "10K+ users, ₹5M+ revenue"
        },
        {
          name: "Task Management App",
          description: "Real-time collaborative task management with Socket.io",
          technologies: ["React", "Socket.io", "Redis"],
          metrics: "500+ teams, 95% uptime"
        }
      ]
    }
  });

  const { data: designElements } = useQuery({
    queryKey: ["/api/infographic-cv/elements"],
    initialData: {
      charts: ["Bar Chart", "Pie Chart", "Progress Bars", "Radar Chart", "Timeline"],
      icons: ["Professional", "Creative", "Technical", "Minimal"],
      layouts: ["Single Column", "Two Column", "Three Column", "Grid Layout"],
      fonts: ["Inter", "Roboto", "Poppins", "Montserrat", "Open Sans"],
      colorSchemes: [
        { name: "Professional Blue", primary: "#2563eb", secondary: "#64748b" },
        { name: "Creative Purple", primary: "#7c3aed", secondary: "#f59e0b" },
        { name: "Tech Green", primary: "#059669", secondary: "#0891b2" },
        { name: "Executive Gray", primary: "#1f2937", secondary: "#6366f1" }
      ]
    }
  });

  const generateInfographicMutation = useMutation({
    mutationFn: async (designData: any) => {
      return apiRequest("POST", "/api/infographic-cv/generate", designData);
    },
    onSuccess: () => {
      toast({
        title: "Infographic Generated",
        description: "Your infographic CV has been created successfully.",
      });
    },
  });

  const handleGenerate = () => {
    generateInfographicMutation.mutate({
      template: selectedTemplate,
      colorScheme,
      profile: userProfile,
      sections: ["personal", "experience", "skills", "education", "projects"]
    });
  };

  const colorSchemes = {
    blue: { primary: "#2563eb", secondary: "#64748b", accent: "#f8fafc" },
    purple: { primary: "#7c3aed", secondary: "#f59e0b", accent: "#fef3c7" },
    green: { primary: "#059669", secondary: "#0891b2", accent: "#ecfdf5" },
    gray: { primary: "#1f2937", secondary: "#6366f1", accent: "#f9fafb" }
  };

  const renderSkillChart = (skills: any[], type: string) => (
    <div className="space-y-3">
      <h4 className="font-medium text-sm">{type} Skills</h4>
      {skills.map((skill, index) => (
        <div key={index} className="flex items-center justify-between">
          <span className="text-sm">{skill.name}</span>
          <div className="flex items-center space-x-2">
            <div className="w-20 h-2 bg-gray-200 rounded-full">
              <div 
                className="h-2 bg-sky-500 rounded-full"
                style={{ width: `${skill.level}%` }}
              ></div>
            </div>
            <span className="text-xs text-gray-500">{skill.level}%</span>
          </div>
        </div>
      ))}
    </div>
  );

  return (
    <div className="max-w-7xl mx-auto p-6">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Infographic CV Creator</h1>
        <p className="text-muted-foreground">Create visually stunning infographic resumes that stand out</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Design Panel */}
        <div className="lg:col-span-1 space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Palette className="w-5 h-5 mr-2 text-purple-600" />
                Design Controls
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Template Selection */}
              <div>
                <label className="text-sm font-medium mb-3 block">Template Style</label>
                <div className="grid grid-cols-1 gap-3">
                  {templates.slice(0, 3).map((template: any) => (
                    <div
                      key={template.id}
                      className={`p-3 border rounded-lg cursor-pointer transition-all ${
                        selectedTemplate === template.id ? 'border-sky-500 bg-sky-50' : 'border-gray-200'
                      }`}
                      onClick={() => setSelectedTemplate(template.id)}
                    >
                      <div className="flex items-center space-x-3">
                        <Layout className="w-5 h-5 text-gray-400" />
                        <div>
                          <div className="font-medium text-sm">{template.name}</div>
                          <div className="text-xs text-gray-500">{template.category}</div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Color Scheme */}
              <div>
                <label className="text-sm font-medium mb-3 block">Color Scheme</label>
                <div className="grid grid-cols-2 gap-2">
                  {Object.entries(colorSchemes).map(([key, colors]) => (
                    <div
                      key={key}
                      className={`p-3 border rounded-lg cursor-pointer transition-all ${
                        colorScheme === key ? 'border-sky-500' : 'border-gray-200'
                      }`}
                      onClick={() => setColorScheme(key)}
                    >
                      <div className="flex items-center space-x-2">
                        <div 
                          className="w-4 h-4 rounded-full"
                          style={{ backgroundColor: colors.primary }}
                        ></div>
                        <div 
                          className="w-4 h-4 rounded-full"
                          style={{ backgroundColor: colors.secondary }}
                        ></div>
                        <span className="text-xs capitalize">{key}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Section Toggle */}
              <div>
                <label className="text-sm font-medium mb-3 block">Sections to Include</label>
                <div className="space-y-2">
                  {[
                    { key: "personal", label: "Personal Info", icon: User },
                    { key: "experience", label: "Work Experience", icon: Briefcase },
                    { key: "skills", label: "Skills", icon: Code },
                    { key: "education", label: "Education", icon: GraduationCap },
                    { key: "projects", label: "Projects", icon: Star }
                  ].map(({ key, label, icon: Icon }) => (
                    <div key={key} className="flex items-center space-x-2">
                      <input type="checkbox" defaultChecked className="rounded" />
                      <Icon className="w-4 h-4 text-gray-400" />
                      <span className="text-sm">{label}</span>
                    </div>
                  ))}
                </div>
              </div>

              <Button onClick={handleGenerate} className="w-full bg-purple-600 hover:bg-purple-700">
                <Zap className="w-4 h-4 mr-2" />
                Generate Infographic
              </Button>
            </CardContent>
          </Card>
        </div>

        {/* Preview Panel */}
        <div className="lg:col-span-2">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <span className="flex items-center">
                  <Eye className="w-5 h-5 mr-2 text-sky-600" />
                  Live Preview
                </span>
                <div className="flex space-x-2">
                  <Button size="sm" variant="outline">
                    <Save className="w-3 h-3 mr-1" />
                    Save
                  </Button>
                  <Button size="sm" variant="outline">
                    <Download className="w-3 h-3 mr-1" />
                    Export
                  </Button>
                  <Button size="sm" variant="outline">
                    <Share className="w-3 h-3 mr-1" />
                    Share
                  </Button>
                </div>
              </CardTitle>
            </CardHeader>
            <CardContent>
              {/* Infographic Preview */}
              <div className="bg-white border rounded-lg p-8 min-h-[800px]">
                {/* Header Section */}
                <div className="flex items-start space-x-6 mb-8">
                  <div className="w-24 h-24 bg-gradient-to-br from-sky-400 to-sky-600 rounded-full flex items-center justify-center">
                    <User className="w-12 h-12 text-white" />
                  </div>
                  <div className="flex-1">
                    <h1 className="text-3xl font-bold text-gray-900 mb-2">
                      {userProfile.personal.fullName}
                    </h1>
                    <p className="text-xl text-sky-600 mb-4">{userProfile.personal.title}</p>
                    <div className="grid grid-cols-2 gap-4 text-sm text-gray-600">
                      <div className="flex items-center">
                        <Mail className="w-4 h-4 mr-2" />
                        {userProfile.personal.email}
                      </div>
                      <div className="flex items-center">
                        <Phone className="w-4 h-4 mr-2" />
                        {userProfile.personal.phone}
                      </div>
                      <div className="flex items-center">
                        <MapPin className="w-4 h-4 mr-2" />
                        {userProfile.personal.location}
                      </div>
                      <div className="flex items-center">
                        <Globe className="w-4 h-4 mr-2" />
                        {userProfile.personal.website}
                      </div>
                    </div>
                  </div>
                </div>

                {/* Summary */}
                <div className="mb-8">
                  <h2 className="text-lg font-bold text-gray-900 mb-3 flex items-center">
                    <TrendingUp className="w-5 h-5 mr-2 text-sky-600" />
                    Professional Summary
                  </h2>
                  <p className="text-gray-700 leading-relaxed">{userProfile.personal.summary}</p>
                </div>

                {/* Skills Visualization */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
                  <div>
                    {renderSkillChart(userProfile.skills.technical, "Technical")}
                  </div>
                  <div>
                    {renderSkillChart(userProfile.skills.soft, "Soft")}
                  </div>
                </div>

                {/* Experience Timeline */}
                <div className="mb-8">
                  <h2 className="text-lg font-bold text-gray-900 mb-4 flex items-center">
                    <Briefcase className="w-5 h-5 mr-2 text-sky-600" />
                    Work Experience
                  </h2>
                  <div className="space-y-6">
                    {userProfile.experience.map((exp: any, index: number) => (
                      <div key={index} className="flex">
                        <div className="flex flex-col items-center mr-4">
                          <div className="w-3 h-3 bg-sky-600 rounded-full"></div>
                          {index < userProfile.experience.length - 1 && (
                            <div className="w-0.5 h-16 bg-sky-200 mt-2"></div>
                          )}
                        </div>
                        <div className="flex-1">
                          <h3 className="font-semibold text-gray-900">{exp.position}</h3>
                          <p className="text-sky-600 font-medium">{exp.company}</p>
                          <p className="text-sm text-gray-600 mb-2">{exp.duration} • {exp.location}</p>
                          <ul className="text-sm text-gray-700 space-y-1">
                            {exp.achievements.map((achievement: string, i: number) => (
                              <li key={i} className="flex items-start">
                                <Star className="w-3 h-3 text-yellow-500 mr-2 mt-0.5 flex-shrink-0" />
                                {achievement}
                              </li>
                            ))}
                          </ul>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Education & Certifications */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  <div>
                    <h2 className="text-lg font-bold text-gray-900 mb-4 flex items-center">
                      <GraduationCap className="w-5 h-5 mr-2 text-sky-600" />
                      Education
                    </h2>
                    {userProfile.education.map((edu: any, index: number) => (
                      <div key={index} className="p-4 bg-sky-50 rounded-lg">
                        <h3 className="font-semibold text-gray-900">{edu.degree}</h3>
                        <p className="text-sky-600">{edu.institution}</p>
                        <p className="text-sm text-gray-600">{edu.year} • {edu.grade}</p>
                      </div>
                    ))}
                  </div>

                  <div>
                    <h2 className="text-lg font-bold text-gray-900 mb-4 flex items-center">
                      <Award className="w-5 h-5 mr-2 text-sky-600" />
                      Certifications
                    </h2>
                    <div className="space-y-3">
                      {userProfile.certifications.map((cert: any, index: number) => (
                        <div key={index} className="p-4 bg-green-50 rounded-lg">
                          <h3 className="font-semibold text-gray-900">{cert.name}</h3>
                          <p className="text-green-600">{cert.issuer}</p>
                          <div className="flex items-center justify-between mt-1">
                            <span className="text-sm text-gray-600">{cert.year}</span>
                            <Badge className="bg-green-100 text-green-800">
                              {cert.level}
                            </Badge>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}

export default function InfographicCV() {
  const config = platformConfigs.candidate;
  const theme = useThemeClasses('candidate');
  
  const usageData = [
    { label: "Infographic CVs", current: 2, max: 5 },
    { label: "Template Usage", current: 78, max: 100 },
    { label: "Export Quality", current: 92, max: 100 },
  ];

  return (
    <PlatformLayout
      sidebarTitle={config.sidebarTitle}
      sidebarSubtitle={config.sidebarSubtitle}
      sidebarSections={config.sidebarSections}
      usageData={usageData}
    >
      <InfographicCVContent />
    </PlatformLayout>
  );
}