import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import PlatformLayout from "@/components/layout/platform-layout";
import { candidateNavigation } from "@/config/complete-navigation";
import { 
  History, Calendar, Clock, TrendingUp, BarChart3, Target,
  CheckCircle, XCircle, Play, RotateCcw, Award, Star,
  Code, Users, Brain, MessageSquare, Filter, Search
} from "lucide-react";

const PracticeHistory: React.FC = () => {
  const [selectedFilter, setSelectedFilter] = useState('all');
  const [selectedTimeframe, setSelectedTimeframe] = useState('month');

  const practiceHistory = [
    {
      id: 1,
      type: "Technical Interview",
      category: "Frontend",
      technology: "React",
      date: "2024-01-25",
      duration: "45 min",
      score: 92,
      status: "completed",
      difficulty: "Medium",
      interviewer: "AI Simulator",
      questions: [
        "Explain React hooks and their use cases",
        "Implement a custom hook for data fetching",
        "Optimize component performance"
      ],
      feedback: "Strong understanding of React concepts. Excellent problem-solving approach.",
      improvements: ["Error boundary implementation", "Testing strategies"]
    },
    {
      id: 2,
      type: "Behavioral Interview",
      category: "Leadership",
      technology: "Communication",
      date: "2024-01-23",
      duration: "30 min",
      score: 88,
      status: "completed",
      difficulty: "Medium",
      interviewer: "AI Simulator",
      questions: [
        "Tell me about a time you led a difficult project",
        "How do you handle conflict in a team?",
        "Describe your management style"
      ],
      feedback: "Good storytelling and structure. Clear examples with measurable outcomes.",
      improvements: ["More specific metrics", "Stakeholder management examples"]
    },
    {
      id: 3,
      type: "System Design",
      category: "Architecture",
      technology: "Scalability",
      date: "2024-01-20",
      duration: "60 min",
      score: 75,
      status: "completed",
      difficulty: "Hard",
      interviewer: "AI Simulator",
      questions: [
        "Design a URL shortening service",
        "Handle high traffic and scalability",
        "Database design and caching strategy"
      ],
      feedback: "Good initial approach. Need to consider edge cases and monitoring.",
      improvements: ["Load balancing strategies", "Monitoring and alerting"]
    },
    {
      id: 4,
      type: "Coding Challenge",
      category: "Algorithms",
      technology: "JavaScript",
      date: "2024-01-18",
      duration: "90 min",
      score: 95,
      status: "completed",
      difficulty: "Hard",
      interviewer: "Automated System",
      questions: [
        "Implement a LRU cache",
        "Binary tree traversal",
        "Dynamic programming problem"
      ],
      feedback: "Excellent coding skills and optimization. Clean, readable code.",
      improvements: ["Time complexity analysis", "Edge case handling"]
    },
    {
      id: 5,
      type: "Technical Interview",
      category: "Backend",
      technology: "Node.js",
      date: "2024-01-15",
      duration: "50 min",
      score: 82,
      status: "completed",
      difficulty: "Medium",
      interviewer: "AI Simulator",
      questions: [
        "Database optimization techniques",
        "API design best practices",
        "Security considerations"
      ],
      feedback: "Solid backend knowledge. Could improve on security best practices.",
      improvements: ["Authentication methods", "Rate limiting strategies"]
    },
    {
      id: 6,
      type: "Mock Interview",
      category: "Full-Stack",
      technology: "MERN Stack",
      date: "2024-01-12",
      duration: "120 min",
      score: 89,
      status: "completed",
      difficulty: "Hard",
      interviewer: "Human Expert",
      questions: [
        "Build a full-stack application",
        "Implement real-time features",
        "Deployment and monitoring"
      ],
      feedback: "Comprehensive full-stack skills. Great integration between frontend and backend.",
      improvements: ["Real-time optimization", "DevOps practices"]
    }
  ];

  const categories = [
    { id: 'all', name: 'All Types', count: practiceHistory.length },
    { id: 'Technical Interview', name: 'Technical', count: practiceHistory.filter(p => p.type === 'Technical Interview').length },
    { id: 'Behavioral Interview', name: 'Behavioral', count: practiceHistory.filter(p => p.type === 'Behavioral Interview').length },
    { id: 'System Design', name: 'System Design', count: practiceHistory.filter(p => p.type === 'System Design').length },
    { id: 'Coding Challenge', name: 'Coding', count: practiceHistory.filter(p => p.type === 'Coding Challenge').length },
    { id: 'Mock Interview', name: 'Full Mock', count: practiceHistory.filter(p => p.type === 'Mock Interview').length }
  ];

  const stats = {
    totalSessions: practiceHistory.length,
    totalHours: practiceHistory.reduce((sum, p) => sum + parseInt(p.duration), 0),
    averageScore: Math.round(practiceHistory.reduce((sum, p) => sum + p.score, 0) / practiceHistory.length),
    improvementRate: 12,
    currentStreak: 8
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'Technical Interview': return Code;
      case 'Behavioral Interview': return Users;
      case 'System Design': return Brain;
      case 'Coding Challenge': return Target;
      case 'Mock Interview': return MessageSquare;
      default: return Play;
    }
  };

  const getScoreColor = (score: number) => {
    if (score >= 90) return 'text-green-600';
    if (score >= 80) return 'text-blue-600';
    if (score >= 70) return 'text-yellow-600';
    return 'text-red-600';
  };

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'Easy': return 'text-green-600 bg-green-100';
      case 'Medium': return 'text-yellow-600 bg-yellow-100';
      case 'Hard': return 'text-red-600 bg-red-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  const filteredHistory = selectedFilter === 'all' 
    ? practiceHistory 
    : practiceHistory.filter(p => p.type === selectedFilter);

  return (
    <PlatformLayout
      sidebarTitle="Candidate Platform"
      sidebarSubtitle="Interview Preparation"
      sidebarSections={candidateNavigation}
    >
      <div className="min-h-screen bg-gradient-to-br from-green-50 via-white to-blue-50 p-6">
        <div className="max-w-7xl mx-auto space-y-8">
          {/* Header */}
          <div className="text-center space-y-4">
            <div className="inline-flex items-center space-x-2 bg-green-100 text-green-800 px-4 py-2 rounded-full text-sm font-medium">
              <History className="h-4 w-4" />
              <span>Practice Session History</span>
            </div>
            <h1 className="text-4xl font-bold text-gray-900">Your Practice Journey</h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Track your interview practice sessions and monitor your improvement over time
            </p>
          </div>

          {/* Statistics Overview */}
          <div className="grid grid-cols-1 md:grid-cols-5 gap-6">
            <Card className="bg-gradient-to-r from-blue-500 to-blue-600 text-white">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-blue-100">Total Sessions</p>
                    <p className="text-3xl font-bold">{stats.totalSessions}</p>
                  </div>
                  <Play className="h-12 w-12 text-blue-200" />
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-r from-green-500 to-green-600 text-white">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-green-100">Practice Hours</p>
                    <p className="text-3xl font-bold">{Math.round(stats.totalHours / 60)}h</p>
                  </div>
                  <Clock className="h-12 w-12 text-green-200" />
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-r from-purple-500 to-purple-600 text-white">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-purple-100">Avg Score</p>
                    <p className="text-3xl font-bold">{stats.averageScore}%</p>
                  </div>
                  <Star className="h-12 w-12 text-purple-200" />
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-r from-yellow-500 to-yellow-600 text-white">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-yellow-100">Improvement</p>
                    <p className="text-3xl font-bold">+{stats.improvementRate}%</p>
                  </div>
                  <TrendingUp className="h-12 w-12 text-yellow-200" />
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-r from-orange-500 to-orange-600 text-white">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-orange-100">Current Streak</p>
                    <p className="text-3xl font-bold">{stats.currentStreak} days</p>
                  </div>
                  <Award className="h-12 w-12 text-orange-200" />
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Filter and Search */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Filter className="h-5 w-5" />
                <span>Filter Practice Sessions</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-3 md:grid-cols-6 gap-4">
                {categories.map((category) => (
                  <Button
                    key={category.id}
                    variant={selectedFilter === category.id ? "default" : "outline"}
                    className={`flex flex-col items-center space-y-1 h-auto p-4 ${
                      selectedFilter === category.id ? 'bg-green-600 hover:bg-green-700' : ''
                    }`}
                    onClick={() => setSelectedFilter(category.id)}
                  >
                    <span className="font-medium text-sm">{category.name}</span>
                    <Badge variant="secondary" className="text-xs">
                      {category.count}
                    </Badge>
                  </Button>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Practice History Timeline */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Calendar className="h-5 w-5" />
                <span>Practice History Timeline</span>
              </CardTitle>
              <CardDescription>
                Showing {filteredHistory.length} sessions of {practiceHistory.length} total
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {filteredHistory.map((session) => {
                  const TypeIcon = getTypeIcon(session.type);
                  
                  return (
                    <div key={session.id} className="border rounded-lg p-6 bg-gray-50 hover:shadow-md transition-shadow">
                      <div className="flex items-start justify-between mb-4">
                        <div className="flex items-start space-x-4">
                          <div className="p-3 bg-white rounded-full border">
                            <TypeIcon className="h-6 w-6 text-blue-600" />
                          </div>
                          <div>
                            <h3 className="text-lg font-semibold text-gray-900">{session.type}</h3>
                            <p className="text-gray-600">{session.category} • {session.technology}</p>
                            <div className="flex items-center space-x-3 mt-2">
                              <Badge className={getDifficultyColor(session.difficulty)}>
                                {session.difficulty}
                              </Badge>
                              <span className="text-sm text-gray-500">{session.interviewer}</span>
                            </div>
                          </div>
                        </div>
                        <div className="text-right">
                          <div className={`text-3xl font-bold ${getScoreColor(session.score)}`}>
                            {session.score}%
                          </div>
                          <div className="text-sm text-gray-500">{session.date}</div>
                          <div className="text-sm text-gray-500">{session.duration}</div>
                        </div>
                      </div>

                      <Tabs defaultValue="questions" className="mt-4">
                        <TabsList>
                          <TabsTrigger value="questions">Questions</TabsTrigger>
                          <TabsTrigger value="feedback">Feedback</TabsTrigger>
                          <TabsTrigger value="improvements">Next Steps</TabsTrigger>
                        </TabsList>

                        <TabsContent value="questions" className="mt-4">
                          <div className="space-y-3">
                            <h4 className="font-medium text-gray-700">Interview Questions</h4>
                            {session.questions.map((question, index) => (
                              <div key={index} className="flex items-start space-x-3 p-3 bg-white rounded border-l-2 border-blue-300">
                                <span className="text-sm font-medium text-blue-600 mt-0.5">Q{index + 1}</span>
                                <span className="text-sm text-gray-700">{question}</span>
                              </div>
                            ))}
                          </div>
                        </TabsContent>

                        <TabsContent value="feedback" className="mt-4">
                          <div className="p-4 bg-green-50 rounded-lg border-l-4 border-green-400">
                            <h4 className="font-medium text-green-800 mb-2">Interviewer Feedback</h4>
                            <p className="text-green-700">{session.feedback}</p>
                          </div>
                        </TabsContent>

                        <TabsContent value="improvements" className="mt-4">
                          <div className="space-y-2">
                            <h4 className="font-medium text-gray-700">Areas for Improvement</h4>
                            {session.improvements.map((improvement, index) => (
                              <div key={index} className="flex items-center space-x-2">
                                <Target className="h-4 w-4 text-orange-500" />
                                <span className="text-sm text-gray-700">{improvement}</span>
                              </div>
                            ))}
                          </div>
                        </TabsContent>
                      </Tabs>

                      <div className="flex space-x-3 mt-4 pt-4 border-t">
                        <Button size="sm" variant="outline">
                          <RotateCcw className="h-4 w-4 mr-2" />
                          Retake Similar
                        </Button>
                        <Button size="sm" variant="outline">
                          <MessageSquare className="h-4 w-4 mr-2" />
                          Review Session
                        </Button>
                        <Button size="sm" variant="outline">
                          <TrendingUp className="h-4 w-4 mr-2" />
                          Track Progress
                        </Button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>

          {/* Progress Analytics */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <BarChart3 className="h-5 w-5" />
                  <span>Performance Trends</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-sm font-medium">Technical Interviews</span>
                    <span className="text-sm text-gray-600">87% avg</span>
                  </div>
                  <Progress value={87} className="h-2" />
                </div>
                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-sm font-medium">Behavioral Interviews</span>
                    <span className="text-sm text-gray-600">88% avg</span>
                  </div>
                  <Progress value={88} className="h-2" />
                </div>
                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-sm font-medium">System Design</span>
                    <span className="text-sm text-gray-600">75% avg</span>
                  </div>
                  <Progress value={75} className="h-2" />
                </div>
                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span className="text-sm font-medium">Coding Challenges</span>
                    <span className="text-sm text-gray-600">95% avg</span>
                  </div>
                  <Progress value={95} className="h-2" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Target className="h-5 w-5" />
                  <span>Focus Areas</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-center space-x-3 p-3 bg-red-50 rounded-lg">
                  <Target className="h-5 w-5 text-red-600" />
                  <div>
                    <div className="font-medium text-sm">System Design Patterns</div>
                    <div className="text-xs text-gray-600">Need more practice with scalability</div>
                  </div>
                </div>
                <div className="flex items-center space-x-3 p-3 bg-yellow-50 rounded-lg">
                  <Clock className="h-5 w-5 text-yellow-600" />
                  <div>
                    <div className="font-medium text-sm">Time Management</div>
                    <div className="text-xs text-gray-600">Practice completing within time limits</div>
                  </div>
                </div>
                <div className="flex items-center space-x-3 p-3 bg-blue-50 rounded-lg">
                  <Users className="h-5 w-5 text-blue-600" />
                  <div>
                    <div className="font-medium text-sm">Communication Clarity</div>
                    <div className="text-xs text-gray-600">Explain technical concepts clearly</div>
                  </div>
                </div>
                <div className="flex items-center space-x-3 p-3 bg-green-50 rounded-lg">
                  <CheckCircle className="h-5 w-5 text-green-600" />
                  <div>
                    <div className="font-medium text-sm">Coding Skills</div>
                    <div className="text-xs text-gray-600">Strong performance across all areas</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </PlatformLayout>
  );
};

export default PracticeHistory;