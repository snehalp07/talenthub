import { useState, useEffect, useRef } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useAuth } from "@/hooks/use-auth";
import PlatformLayout from "@/components/layout/platform-layout";
import { platformConfigs } from "@/config/complete-navigation";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import Editor from "@monaco-editor/react";
import { 
  Code, 
  Save, 
  Play, 
  FileText, 
  Github, 
  ExternalLink, 
  Plus, 
  Trash2, 
  FolderOpen,
  Settings,
  Eye,
  Upload,
  Download
} from "lucide-react";

interface ProjectFile {
  id: string;
  name: string;
  content: string;
  language: string;
  path: string;
}

interface Project {
  id: string;
  title: string;
  description: string;
  technology: string;
  status: "draft" | "active" | "completed" | "archived";
  githubUrl?: string;
  demoUrl?: string;
  files: ProjectFile[];
  createdAt: string;
  updatedAt: string;
}

function ProjectEditorContent() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [selectedProject, setSelectedProject] = useState<Project | null>(null);
  const [activeFile, setActiveFile] = useState<ProjectFile | null>(null);
  const [isCreating, setIsCreating] = useState(false);
  const [newProjectTitle, setNewProjectTitle] = useState("");
  const [newProjectDescription, setNewProjectDescription] = useState("");
  const [newProjectTechnology, setNewProjectTechnology] = useState("");
  const [editorTheme, setEditorTheme] = useState("talenthub-dark");
  const [editorInstance, setEditorInstance] = useState<any>(null);

  // Effect to update Monaco theme when editorTheme changes
  useEffect(() => {
    if (editorInstance && window.monaco) {
      window.monaco.editor.setTheme(editorTheme);
    }
  }, [editorTheme, editorInstance]);

  const { data: projects = [], isLoading } = useQuery<Project[]>({
    queryKey: ["/api/projects"],
    enabled: !!user,
  });

  const createProjectMutation = useMutation({
    mutationFn: async (projectData: { title: string; description: string; technology: string }) => {
      return await apiRequest("POST", "/api/projects", projectData);
    },
    onSuccess: (newProject) => {
      queryClient.invalidateQueries({ queryKey: ["/api/projects"] });
      setSelectedProject(newProject);
      setIsCreating(false);
      setNewProjectTitle("");
      setNewProjectDescription("");
      setNewProjectTechnology("");
      toast({
        title: "Project Created",
        description: "Your new project has been created successfully",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const updateProjectMutation = useMutation({
    mutationFn: async ({ projectId, updates }: { projectId: string; updates: Partial<Project> }) => {
      return await apiRequest("PATCH", `/api/projects/${projectId}`, updates);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/projects"] });
      toast({
        title: "Project Updated",
        description: "Your project has been saved successfully",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const saveFileMutation = useMutation({
    mutationFn: async ({ fileId, content }: { fileId: string; content: string }) => {
      return await apiRequest("PATCH", `/api/project-files/${fileId}`, { content });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/projects"] });
      toast({
        title: "File Saved",
        description: "Your changes have been saved",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const addFileMutation = useMutation({
    mutationFn: async ({ projectId, fileName, language }: { projectId: string; fileName: string; language: string }) => {
      return await apiRequest("POST", `/api/projects/${projectId}/files`, {
        name: fileName,
        language,
        content: getTemplateContent(language),
        path: fileName
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/projects"] });
      toast({
        title: "File Added",
        description: "New file has been added to your project",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const getTemplateContent = (language: string): string => {
    const templates = {
      javascript: `// Welcome to your new JavaScript file
console.log("Hello, World!");

function example() {
  return "Start coding here!";
}

example();`,
      typescript: `// Welcome to your new TypeScript file
interface Example {
  message: string;
}

const example: Example = {
  message: "Hello, World!"
};

console.log(example.message);`,
      python: `# Welcome to your new Python file
def hello_world():
    return "Hello, World!"

if __name__ == "__main__":
    print(hello_world())`,
      html: `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Project</title>
</head>
<body>
    <h1>Hello, World!</h1>
</body>
</html>`,
      css: `/* Welcome to your new CSS file */
body {
  font-family: Arial, sans-serif;
  margin: 0;
  padding: 20px;
  background-color: #f5f5f5;
}

h1 {
  color: #333;
  text-align: center;
}`,
      json: `{
  "name": "project",
  "version": "1.0.0",
  "description": "Your project description",
  "main": "index.js",
  "dependencies": {}
}`
    };
    return templates[language as keyof typeof templates] || "// Start coding here!";
  };

  const getStatusColor = (status: string) => {
    const colors = {
      draft: "bg-gray-100 text-gray-800",
      active: "bg-blue-100 text-blue-800",
      completed: "bg-green-100 text-green-800",
      archived: "bg-red-100 text-red-800"
    };
    return colors[status as keyof typeof colors] || "bg-gray-100 text-gray-800";
  };

  const handleCreateProject = () => {
    if (!newProjectTitle.trim()) {
      toast({
        title: "Error",
        description: "Please enter a project title",
        variant: "destructive",
      });
      return;
    }
    createProjectMutation.mutate({
      title: newProjectTitle,
      description: newProjectDescription,
      technology: newProjectTechnology
    });
  };

  const handleSaveFile = () => {
    if (activeFile) {
      saveFileMutation.mutate({
        fileId: activeFile.id,
        content: activeFile.content
      });
    }
  };

  const handleFileContentChange = (content: string) => {
    if (activeFile) {
      setActiveFile({ ...activeFile, content });
      // Update the file in the selected project as well
      if (selectedProject) {
        const updatedFiles = selectedProject.files.map(file =>
          file.id === activeFile.id ? { ...file, content } : file
        );
        setSelectedProject({ ...selectedProject, files: updatedFiles });
      }
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto p-6">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Project Editor</h1>
        <p className="text-muted-foreground">Create, edit, and manage your coding projects</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 h-[calc(100vh-200px)]">
        {/* Project List Sidebar */}
        <div className="lg:col-span-1">
          <Card className="h-full">
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <span>Projects</span>
                <Button
                  size="sm"
                  onClick={() => setIsCreating(true)}
                  className="bg-sky-500 hover:bg-sky-600 text-white"
                >
                  <Plus className="w-4 h-4 mr-1" />
                  New
                </Button>
              </CardTitle>
            </CardHeader>
            <CardContent className="p-0">
              <div className="space-y-2 max-h-[500px] overflow-y-auto">
                {isCreating && (
                  <div className="p-4 border-b bg-sky-50">
                    <div className="space-y-3">
                      <Input
                        placeholder="Project title"
                        value={newProjectTitle}
                        onChange={(e) => setNewProjectTitle(e.target.value)}
                      />
                      <Textarea
                        placeholder="Project description"
                        value={newProjectDescription}
                        onChange={(e) => setNewProjectDescription(e.target.value)}
                        rows={2}
                      />
                      <Select value={newProjectTechnology} onValueChange={setNewProjectTechnology}>
                        <SelectTrigger>
                          <SelectValue placeholder="Select technology" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="JavaScript">JavaScript</SelectItem>
                          <SelectItem value="TypeScript">TypeScript</SelectItem>
                          <SelectItem value="Python">Python</SelectItem>
                          <SelectItem value="React">React</SelectItem>
                          <SelectItem value="Node.js">Node.js</SelectItem>
                          <SelectItem value="HTML/CSS">HTML/CSS</SelectItem>
                        </SelectContent>
                      </Select>
                      <div className="flex gap-2">
                        <Button
                          size="sm"
                          onClick={handleCreateProject}
                          disabled={createProjectMutation.isPending}
                          className="bg-sky-500 hover:bg-sky-600 text-white"
                        >
                          Create
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => setIsCreating(false)}
                        >
                          Cancel
                        </Button>
                      </div>
                    </div>
                  </div>
                )}
                {projects.map((project) => (
                  <div
                    key={project.id}
                    className={`p-4 cursor-pointer hover:bg-gray-50 border-b ${
                      selectedProject?.id === project.id ? 'bg-sky-50 border-l-4 border-l-sky-500' : ''
                    }`}
                    onClick={() => {
                      setSelectedProject(project);
                      setActiveFile(project.files[0] || null);
                    }}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <h4 className="font-medium truncate">{project.title}</h4>
                      <Badge className={getStatusColor(project.status)}>
                        {project.status}
                      </Badge>
                    </div>
                    <p className="text-sm text-muted-foreground line-clamp-2 mb-2">
                      {project.description}
                    </p>
                    <div className="flex items-center gap-2 text-xs text-muted-foreground">
                      <Code className="w-3 h-3" />
                      {project.technology}
                      <span>•</span>
                      {project.files.length} files
                    </div>
                  </div>
                ))}
                {projects.length === 0 && !isCreating && (
                  <div className="p-8 text-center">
                    <FolderOpen className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
                    <p className="text-muted-foreground">No projects yet</p>
                    <Button
                      size="sm"
                      onClick={() => setIsCreating(true)}
                      className="mt-4 bg-sky-500 hover:bg-sky-600 text-white"
                    >
                      Create your first project
                    </Button>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Editor Area */}
        <div className="lg:col-span-2">
          {selectedProject ? (
            <Card className="h-full">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle>{selectedProject.title}</CardTitle>
                    <CardDescription>{selectedProject.description}</CardDescription>
                  </div>
                  <div className="flex gap-2">
                    {selectedProject.githubUrl && (
                      <Button size="sm" variant="outline" asChild>
                        <a href={selectedProject.githubUrl} target="_blank" rel="noopener noreferrer">
                          <Github className="w-4 h-4 mr-1" />
                          GitHub
                        </a>
                      </Button>
                    )}
                    {selectedProject.demoUrl && (
                      <Button size="sm" variant="outline" asChild>
                        <a href={selectedProject.demoUrl} target="_blank" rel="noopener noreferrer">
                          <ExternalLink className="w-4 h-4 mr-1" />
                          Demo
                        </a>
                      </Button>
                    )}
                  </div>
                </div>
              </CardHeader>
              <CardContent className="p-0 h-[calc(100%-120px)]">
                <Tabs defaultValue="editor" className="h-full">
                  <TabsList className="w-full justify-start rounded-none border-b">
                    <TabsTrigger value="editor">Editor</TabsTrigger>
                    <TabsTrigger value="preview">Preview</TabsTrigger>
                    <TabsTrigger value="settings">Settings</TabsTrigger>
                  </TabsList>
                  
                  <TabsContent value="editor" className="h-[calc(100%-50px)] m-0">
                    <div className="flex h-full">
                      {/* File Explorer */}
                      <div className="w-64 border-r bg-gray-50 overflow-y-auto">
                        <div className="p-3 border-b">
                          <div className="flex items-center justify-between">
                            <span className="text-sm font-medium">Files</span>
                            <Button
                              size="sm"
                              variant="ghost"
                              onClick={() => {
                                const fileName = prompt("Enter file name:");
                                const language = prompt("Enter language (javascript, typescript, python, html, css, json):");
                                if (fileName && language) {
                                  addFileMutation.mutate({
                                    projectId: selectedProject.id,
                                    fileName,
                                    language
                                  });
                                }
                              }}
                            >
                              <Plus className="w-3 h-3" />
                            </Button>
                          </div>
                        </div>
                        <div className="p-2">
                          {selectedProject.files.map((file) => (
                            <div
                              key={file.id}
                              className={`p-2 text-sm cursor-pointer rounded hover:bg-gray-100 ${
                                activeFile?.id === file.id ? 'bg-sky-100 text-sky-900' : ''
                              }`}
                              onClick={() => setActiveFile(file)}
                            >
                              <div className="flex items-center gap-2">
                                <FileText className="w-4 h-4" />
                                {file.name}
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>

                      {/* Code Editor */}
                      <div className="flex-1 flex flex-col">
                        {activeFile ? (
                          <>
                            <div className="flex items-center justify-between p-3 border-b bg-gray-50">
                              <div className="flex items-center gap-2">
                                <FileText className="w-4 h-4" />
                                <span className="text-sm font-medium">{activeFile.name}</span>
                                <Badge variant="outline" className="text-xs">
                                  {activeFile.language}
                                </Badge>
                              </div>
                              <div className="flex items-center gap-3">
                                <div className="flex items-center gap-2">
                                  <span className="text-sm font-medium text-gray-600">Theme:</span>
                                  <Select value={editorTheme} onValueChange={setEditorTheme}>
                                    <SelectTrigger className="w-40 h-8 text-xs">
                                      <SelectValue />
                                    </SelectTrigger>
                                    <SelectContent>
                                      <SelectItem value="talenthub-dark">TalentHub Dark</SelectItem>
                                      <SelectItem value="talenthub-light">TalentHub Light</SelectItem>
                                      <SelectItem value="vs-dark">VS Code Dark</SelectItem>
                                      <SelectItem value="vs">VS Code Light</SelectItem>
                                      <SelectItem value="ocean-blue">Ocean Blue</SelectItem>
                                      <SelectItem value="forest-green">Forest Green</SelectItem>
                                      <SelectItem value="purple-haze">Purple Haze</SelectItem>
                                    </SelectContent>
                                  </Select>
                                </div>
                                <Button
                                  size="sm"
                                  onClick={handleSaveFile}
                                  disabled={saveFileMutation.isPending}
                                  className="bg-sky-500 hover:bg-sky-600 text-white"
                                >
                                  <Save className="w-4 h-4 mr-1" />
                                  Save
                                </Button>
                              </div>
                            </div>
                            <div className="flex-1">
                              <Editor
                                height="100%"
                                language={activeFile.language}
                                value={activeFile.content}
                                onChange={(value) => handleFileContentChange(value || "")}
                                theme={editorTheme}
                                options={{
                                  // Display options
                                  minimap: { enabled: true, side: "right" },
                                  fontSize: 14,
                                  fontFamily: "'JetBrains Mono', 'Monaco', 'Consolas', monospace",
                                  lineNumbers: "on",
                                  lineHeight: 20,
                                  renderWhitespace: "selection",
                                  renderLineHighlight: "all",
                                  
                                  // Editor behavior
                                  roundedSelection: false,
                                  scrollBeyondLastLine: false,
                                  automaticLayout: true,
                                  smoothScrolling: true,
                                  cursorBlinking: "blink",
                                  cursorStyle: "line",
                                  
                                  // Indentation and formatting
                                  tabSize: 2,
                                  insertSpaces: true,
                                  detectIndentation: true,
                                  trimAutoWhitespace: true,
                                  
                                  // Word wrapping
                                  wordWrap: "on",
                                  wordWrapColumn: 80,
                                  wrappingIndent: "indent",
                                  
                                  // Selection and interaction
                                  contextmenu: true,
                                  selectOnLineNumbers: true,
                                  selectionHighlight: true,
                                  occurrencesHighlight: true,
                                  
                                  // Bracket matching
                                  matchBrackets: "always",
                                  autoClosingBrackets: "always",
                                  autoClosingQuotes: "always",
                                  autoClosingOvertype: "always",
                                  autoSurround: "languageDefined",
                                  
                                  // Code formatting
                                  formatOnPaste: true,
                                  formatOnType: true,
                                  
                                  // IntelliSense and suggestions
                                  suggestOnTriggerCharacters: true,
                                  acceptSuggestionOnEnter: "on",
                                  acceptSuggestionOnCommitCharacter: true,
                                  quickSuggestions: {
                                    other: true,
                                    comments: false,
                                    strings: false
                                  },
                                  quickSuggestionsDelay: 10,
                                  
                                  // Hover and parameter hints
                                  parameterHints: { 
                                    enabled: true,
                                    cycle: true
                                  },
                                  hover: { 
                                    enabled: true,
                                    delay: 300,
                                    sticky: true
                                  },
                                  
                                  // Find and replace
                                  find: {
                                    addExtraSpaceOnTop: true,
                                    autoFindInSelection: "never",
                                    seedSearchStringFromSelection: "always"
                                  },
                                  
                                  // Folding
                                  folding: true,
                                  foldingStrategy: "indentation",
                                  showFoldingControls: "mouseover",
                                  
                                  // Scrolling
                                  scrollbar: {
                                    vertical: "visible",
                                    horizontal: "visible",
                                    useShadows: false,
                                    verticalHasArrows: false,
                                    horizontalHasArrows: false,
                                    verticalScrollbarSize: 10,
                                    horizontalScrollbarSize: 10
                                  },
                                  
                                  // Multi-cursor
                                  multiCursorModifier: "alt",
                                  multiCursorMergeOverlapping: true,
                                  
                                  // Accessibility
                                  accessibilitySupport: "auto",
                                  
                                  // Advanced features
                                  codeLens: true,
                                  colorDecorators: true,
                                  links: true,
                                  mouseWheelZoom: true,
                                  dragAndDrop: true,
                                  copyWithSyntaxHighlighting: true,
                                  
                                  // Performance
                                  renderControlCharacters: false,
                                  renderFinalNewline: true,
                                  largeFileOptimizations: true
                                }}
                                beforeMount={(monaco) => {
                                  // Enhanced TypeScript/JavaScript support
                                  monaco.languages.typescript.javascriptDefaults.setCompilerOptions({
                                    target: monaco.languages.typescript.ScriptTarget.ES2020,
                                    allowNonTsExtensions: true,
                                    moduleResolution: monaco.languages.typescript.ModuleResolutionKind.NodeJs,
                                    module: monaco.languages.typescript.ModuleKind.CommonJS,
                                    noEmit: true,
                                    esModuleInterop: true,
                                    jsx: monaco.languages.typescript.JsxEmit.React,
                                    allowJs: true,
                                    typeRoots: ["node_modules/@types"]
                                  });

                                  // Add popular libraries for IntelliSense
                                  const libUri = 'ts:filename/facts.d.ts';
                                  const libSource = `
                                    declare module 'react' {
                                      export = React;
                                      export as namespace React;
                                      namespace React {
                                        interface Component<P = {}, S = {}> {}
                                        function useState<T>(initialState: T): [T, (newState: T) => void];
                                        function useEffect(effect: () => void, deps?: any[]): void;
                                      }
                                    }
                                    declare module 'lodash' {
                                      export function map<T, U>(collection: T[], iteratee: (value: T) => U): U[];
                                      export function filter<T>(collection: T[], predicate: (value: T) => boolean): T[];
                                    }
                                  `;
                                  
                                  monaco.languages.typescript.javascriptDefaults.addExtraLib(libSource, libUri);
                                  
                                  // Define multiple custom themes
                                  
                                  // TalentHub Dark Theme
                                  monaco.editor.defineTheme('talenthub-dark', {
                                    base: 'vs-dark',
                                    inherit: true,
                                    rules: [
                                      { token: 'comment', foreground: '6A9955', fontStyle: 'italic' },
                                      { token: 'keyword', foreground: '569CD6', fontStyle: 'bold' },
                                      { token: 'string', foreground: 'CE9178' },
                                      { token: 'number', foreground: 'B5CEA8' },
                                      { token: 'type', foreground: '4EC9B0' },
                                      { token: 'function', foreground: 'DCDCAA' }
                                    ],
                                    colors: {
                                      'editor.background': '#1E1E1E',
                                      'editor.foreground': '#D4D4D4',
                                      'editor.lineHighlightBackground': '#2D2D30',
                                      'editor.selectionBackground': '#264F78',
                                      'editor.selectionHighlightBackground': '#ADD6FF26'
                                    }
                                  });

                                  // TalentHub Light Theme
                                  monaco.editor.defineTheme('talenthub-light', {
                                    base: 'vs',
                                    inherit: true,
                                    rules: [
                                      { token: 'comment', foreground: '008000', fontStyle: 'italic' },
                                      { token: 'keyword', foreground: '0000FF', fontStyle: 'bold' },
                                      { token: 'string', foreground: 'A31515' },
                                      { token: 'number', foreground: '098658' },
                                      { token: 'type', foreground: '267F99' },
                                      { token: 'function', foreground: '795E26' }
                                    ],
                                    colors: {
                                      'editor.background': '#FFFFFF',
                                      'editor.foreground': '#000000',
                                      'editor.lineHighlightBackground': '#F0F0F0',
                                      'editor.selectionBackground': '#ADD6FF',
                                      'editor.selectionHighlightBackground': '#ADD6FF40'
                                    }
                                  });

                                  // Ocean Blue Theme
                                  monaco.editor.defineTheme('ocean-blue', {
                                    base: 'vs-dark',
                                    inherit: true,
                                    rules: [
                                      { token: 'comment', foreground: '7DD3FC', fontStyle: 'italic' },
                                      { token: 'keyword', foreground: '0EA5E9', fontStyle: 'bold' },
                                      { token: 'string', foreground: '22D3EE' },
                                      { token: 'number', foreground: '67E8F9' },
                                      { token: 'type', foreground: '06B6D4' },
                                      { token: 'function', foreground: 'A5F3FC' }
                                    ],
                                    colors: {
                                      'editor.background': '#0F172A',
                                      'editor.foreground': '#E2E8F0',
                                      'editor.lineHighlightBackground': '#1E293B',
                                      'editor.selectionBackground': '#0EA5E9',
                                      'editor.selectionHighlightBackground': '#0EA5E926'
                                    }
                                  });

                                  // Forest Green Theme
                                  monaco.editor.defineTheme('forest-green', {
                                    base: 'vs-dark',
                                    inherit: true,
                                    rules: [
                                      { token: 'comment', foreground: '86EFAC', fontStyle: 'italic' },
                                      { token: 'keyword', foreground: '22C55E', fontStyle: 'bold' },
                                      { token: 'string', foreground: '4ADE80' },
                                      { token: 'number', foreground: '84CC16' },
                                      { token: 'type', foreground: '65A30D' },
                                      { token: 'function', foreground: 'BBF7D0' }
                                    ],
                                    colors: {
                                      'editor.background': '#0F1C0F',
                                      'editor.foreground': '#F0F9FF',
                                      'editor.lineHighlightBackground': '#1A2B1A',
                                      'editor.selectionBackground': '#22C55E',
                                      'editor.selectionHighlightBackground': '#22C55E26'
                                    }
                                  });

                                  // Purple Haze Theme
                                  monaco.editor.defineTheme('purple-haze', {
                                    base: 'vs-dark',
                                    inherit: true,
                                    rules: [
                                      { token: 'comment', foreground: 'C4B5FD', fontStyle: 'italic' },
                                      { token: 'keyword', foreground: '8B5CF6', fontStyle: 'bold' },
                                      { token: 'string', foreground: 'A78BFA' },
                                      { token: 'number', foreground: 'DDD6FE' },
                                      { token: 'type', foreground: '7C3AED' },
                                      { token: 'function', foreground: 'E9D5FF' }
                                    ],
                                    colors: {
                                      'editor.background': '#1E1B3A',
                                      'editor.foreground': '#F3F4F6',
                                      'editor.lineHighlightBackground': '#2D2A4A',
                                      'editor.selectionBackground': '#8B5CF6',
                                      'editor.selectionHighlightBackground': '#8B5CF626'
                                    }
                                  });
                                }}
                                onMount={(editor, monaco) => {
                                  // Store editor instance for theme switching
                                  setEditorInstance(editor);
                                  
                                  // Store monaco reference globally for theme switching
                                  (window as any).monaco = monaco;
                                  
                                  // Set current theme
                                  monaco.editor.setTheme(editorTheme);
                                  
                                  // Add keyboard shortcuts
                                  editor.addCommand(monaco.KeyMod.CtrlCmd | monaco.KeyCode.KeyS, () => {
                                    handleSaveFile();
                                  });
                                  
                                  // Format document shortcut
                                  editor.addCommand(monaco.KeyMod.CtrlCmd | monaco.KeyMod.Shift | monaco.KeyCode.KeyF, () => {
                                    editor.getAction('editor.action.formatDocument')?.run();
                                  });
                                  
                                  // Auto-save functionality
                                  let saveTimeout: NodeJS.Timeout;
                                  editor.onDidChangeModelContent(() => {
                                    clearTimeout(saveTimeout);
                                    saveTimeout = setTimeout(() => {
                                      handleSaveFile();
                                    }, 2000); // Auto-save after 2 seconds of inactivity
                                  });
                                }}
                              />
                            </div>
                          </>
                        ) : (
                          <div className="flex-1 flex items-center justify-center text-muted-foreground">
                            <div className="text-center">
                              <Code className="mx-auto h-12 w-12 mb-4" />
                              <p>Select a file to start editing</p>
                            </div>
                          </div>
                        )}
                      </div>
                    </div>
                  </TabsContent>

                  <TabsContent value="preview" className="h-[calc(100%-50px)] m-0 p-4">
                    <div className="h-full border rounded-lg bg-white">
                      <div className="p-4 border-b">
                        <h3 className="font-medium">Project Preview</h3>
                        <p className="text-sm text-muted-foreground">
                          Live preview functionality would be implemented here
                        </p>
                      </div>
                      <div className="p-4 h-[calc(100%-80px)] overflow-auto">
                        <div className="text-center text-muted-foreground">
                          <Eye className="mx-auto h-12 w-12 mb-4" />
                          <p>Preview feature coming soon</p>
                        </div>
                      </div>
                    </div>
                  </TabsContent>

                  <TabsContent value="settings" className="h-[calc(100%-50px)] m-0 p-4">
                    <div className="space-y-6">
                      <div>
                        <h3 className="text-lg font-medium mb-4">Project Settings</h3>
                        <div className="space-y-4">
                          <div>
                            <label className="text-sm font-medium">Status</label>
                            <Select
                              value={selectedProject.status}
                              onValueChange={(status: "draft" | "active" | "completed" | "archived") => {
                                updateProjectMutation.mutate({
                                  projectId: selectedProject.id,
                                  updates: { status }
                                });
                              }}
                            >
                              <SelectTrigger className="mt-1">
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent>
                                <SelectItem value="draft">Draft</SelectItem>
                                <SelectItem value="active">Active</SelectItem>
                                <SelectItem value="completed">Completed</SelectItem>
                                <SelectItem value="archived">Archived</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                          <div>
                            <label className="text-sm font-medium">GitHub URL</label>
                            <Input
                              className="mt-1"
                              placeholder="https://github.com/username/repo"
                              defaultValue={selectedProject.githubUrl || ""}
                              onBlur={(e) => {
                                updateProjectMutation.mutate({
                                  projectId: selectedProject.id,
                                  updates: { githubUrl: e.target.value }
                                });
                              }}
                            />
                          </div>
                          <div>
                            <label className="text-sm font-medium">Demo URL</label>
                            <Input
                              className="mt-1"
                              placeholder="https://your-demo.com"
                              defaultValue={selectedProject.demoUrl || ""}
                              onBlur={(e) => {
                                updateProjectMutation.mutate({
                                  projectId: selectedProject.id,
                                  updates: { demoUrl: e.target.value }
                                });
                              }}
                            />
                          </div>
                        </div>
                      </div>
                    </div>
                  </TabsContent>
                </Tabs>
              </CardContent>
            </Card>
          ) : (
            <Card className="h-full">
              <CardContent className="h-full flex items-center justify-center">
                <div className="text-center text-muted-foreground">
                  <Code className="mx-auto h-16 w-16 mb-4" />
                  <h3 className="text-lg font-medium mb-2">Welcome to Project Editor</h3>
                  <p className="mb-4">Select a project from the sidebar or create a new one to get started</p>
                  <Button
                    onClick={() => setIsCreating(true)}
                    className="bg-sky-500 hover:bg-sky-600 text-white"
                  >
                    <Plus className="w-4 h-4 mr-2" />
                    Create New Project
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}

export default function ProjectEditor() {
  const config = platformConfigs.candidate;
  
  const usageData = [
    { label: "Projects", current: 3, max: 10 },
    { label: "Files", current: 12, max: 100 },
    { label: "Storage", current: 45, max: 1000 },
  ];

  return (
    <PlatformLayout
      sidebarTitle={config.sidebarTitle}
      sidebarSubtitle={config.sidebarSubtitle}
      sidebarSections={config.sidebarSections}
      usageData={usageData}
    >
      <ProjectEditorContent />
    </PlatformLayout>
  );
}