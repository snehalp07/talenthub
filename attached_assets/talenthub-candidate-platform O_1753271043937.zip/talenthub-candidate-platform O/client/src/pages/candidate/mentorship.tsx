import PlatformLayout from "@/components/layout/platform-layout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Progress } from "@/components/ui/progress";
import { GraduationCap, Star, Users, MessageSquare, Calendar, Search, Filter, Clock, Target, Award, TrendingUp, ChevronRight, MapPin, Video, Coffee, BookOpen } from "lucide-react";
import { platformConfigs } from "@/config/complete-navigation";

export default function Mentorship() {
  const config = platformConfigs.candidate;
  const mentors = [
    {
      id: 1,
      name: "Sarah Chen",
      title: "Senior Software Engineer",
      company: "Google",
      experience: "8 years",
      specialties: ["React", "Node.js", "System Design"],
      rating: 4.9,
      reviews: 127,
      price: "$75/hour",
      availability: "Available",
      image: "https://images.unsplash.com/photo-1494790108755-2616b612b786?w=150&h=150&fit=crop&crop=face",
      description: "Passionate about helping developers grow their technical skills and advance their careers",
      sessions: 450,
      featured: true
    },
    {
      id: 2,
      name: "Michael Rodriguez",
      title: "Tech Lead",
      company: "Microsoft",
      experience: "12 years",
      specialties: ["Leadership", "Architecture", "Team Management"],
      rating: 4.8,
      reviews: 89,
      price: "$90/hour",
      availability: "Busy",
      image: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&h=150&fit=crop&crop=face",
      description: "Experienced tech leader focused on career advancement and leadership development",
      sessions: 320,
      featured: false
    },
    {
      id: 3,
      name: "Emily Johnson",
      title: "Product Manager",
      company: "Amazon",
      experience: "6 years",
      specialties: ["Product Strategy", "Data Analysis", "User Experience"],
      rating: 4.9,
      reviews: 156,
      price: "$80/hour",
      availability: "Available",
      image: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=150&h=150&fit=crop&crop=face",
      description: "Helping professionals transition into product management and excel in their roles",
      sessions: 280,
      featured: true
    }
  ];

  const myMentors = [
    {
      id: 1,
      name: "David Kim",
      title: "Senior Data Scientist",
      company: "Netflix",
      nextSession: "June 25, 2025 at 2:00 PM",
      progress: 65,
      totalSessions: 8,
      currentGoal: "Machine Learning Fundamentals",
      image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&h=150&fit=crop&crop=face"
    },
    {
      id: 2,
      name: "Lisa Park",
      title: "UX Design Lead",
      company: "Adobe",
      nextSession: "June 28, 2025 at 10:00 AM",
      progress: 40,
      totalSessions: 5,
      currentGoal: "Portfolio Development",
      image: "https://images.unsplash.com/photo-1580489944761-15a19d654956?w=150&h=150&fit=crop&crop=face"
    }
  ];

  const programs = [
    {
      id: 1,
      title: "Career Acceleration Program",
      duration: "3 months",
      sessions: 12,
      type: "1-on-1",
      price: "$1,200",
      features: ["Weekly sessions", "Career roadmap", "Mock interviews", "Resume review"],
      color: "from-blue-500 to-cyan-500"
    },
    {
      id: 2,
      title: "Leadership Development",
      duration: "6 months",
      sessions: 24,
      type: "Group + 1-on-1",
      price: "$2,400",
      features: ["Bi-weekly sessions", "Leadership assessment", "360 feedback", "Action planning"],
      color: "from-purple-500 to-pink-500"
    },
    {
      id: 3,
      title: "Tech Skills Mastery",
      duration: "4 months",
      sessions: 16,
      type: "1-on-1",
      price: "$1,600",
      features: ["Hands-on projects", "Code reviews", "System design", "Best practices"],
      color: "from-green-500 to-emerald-500"
    }
  ];

  const achievements = [
    { title: "First Session Completed", icon: Target, earned: true },
    { title: "5 Sessions Milestone", icon: Star, earned: true },
    { title: "Goal Achievement", icon: Award, earned: true },
    { title: "Consistency Champion", icon: TrendingUp, earned: false },
    { title: "Mentor Favorite", icon: GraduationCap, earned: false }
  ];

  return (
    <PlatformLayout
      sidebarTitle={config.sidebarTitle}
      sidebarSubtitle={config.sidebarSubtitle}
      sidebarSections={config.sidebarSections}
      usageData={config.usageData}
    >
      <div className="p-6 max-w-7xl mx-auto space-y-6">
      {/* Header */}
      <div className="text-center space-y-4">
        <div className="flex items-center justify-center space-x-3">
          <div className="p-3 bg-gradient-to-r from-blue-500 to-cyan-500 rounded-full">
            <GraduationCap className="h-8 w-8 text-white" />
          </div>
          <h1 className="text-4xl font-bold bg-gradient-to-r from-blue-600 to-cyan-600 bg-clip-text text-transparent">
            Mentorship Program
          </h1>
        </div>
        <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
          Connect with industry experts and accelerate your career growth through personalized mentorship
        </p>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="bg-gradient-to-r from-blue-50 to-cyan-50 border-blue-200">
          <CardContent className="p-4 text-center">
            <Users className="h-8 w-8 text-blue-500 mx-auto mb-2" />
            <p className="text-2xl font-bold text-blue-600">500+</p>
            <p className="text-sm text-muted-foreground">Expert Mentors</p>
          </CardContent>
        </Card>
        <Card className="bg-gradient-to-r from-green-50 to-emerald-50 border-green-200">
          <CardContent className="p-4 text-center">
            <MessageSquare className="h-8 w-8 text-green-500 mx-auto mb-2" />
            <p className="text-2xl font-bold text-green-600">25K+</p>
            <p className="text-sm text-muted-foreground">Sessions Completed</p>
          </CardContent>
        </Card>
        <Card className="bg-gradient-to-r from-purple-50 to-pink-50 border-purple-200">
          <CardContent className="p-4 text-center">
            <Star className="h-8 w-8 text-purple-500 mx-auto mb-2" />
            <p className="text-2xl font-bold text-purple-600">4.8</p>
            <p className="text-sm text-muted-foreground">Average Rating</p>
          </CardContent>
        </Card>
        <Card className="bg-gradient-to-r from-orange-50 to-red-50 border-orange-200">
          <CardContent className="p-4 text-center">
            <TrendingUp className="h-8 w-8 text-orange-500 mx-auto mb-2" />
            <p className="text-2xl font-bold text-orange-600">85%</p>
            <p className="text-sm text-muted-foreground">Success Rate</p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="find-mentor" className="space-y-6">
        <TabsList className="grid w-full grid-cols-4 bg-blue-100">
          <TabsTrigger value="find-mentor" className="data-[state=active]:bg-blue-500 data-[state=active]:text-white">
            Find Mentors
          </TabsTrigger>
          <TabsTrigger value="my-mentorship" className="data-[state=active]:bg-blue-500 data-[state=active]:text-white">
            My Mentorship
          </TabsTrigger>
          <TabsTrigger value="programs" className="data-[state=active]:bg-blue-500 data-[state=active]:text-white">
            Programs
          </TabsTrigger>
          <TabsTrigger value="progress" className="data-[state=active]:bg-blue-500 data-[state=active]:text-white">
            Progress
          </TabsTrigger>
        </TabsList>

        <TabsContent value="find-mentor" className="space-y-6">
          {/* Search and Filter */}
          <Card className="bg-gradient-to-r from-blue-50 to-cyan-50 border-blue-200">
            <CardContent className="p-6">
              <div className="flex flex-col md:flex-row gap-4">
                <div className="flex-1 relative">
                  <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                  <Input placeholder="Search by skills, company, or expertise..." className="pl-10 bg-white" />
                </div>
                <div className="flex gap-2">
                  <Button variant="outline" className="border-blue-300 hover:bg-blue-50">
                    <Filter className="h-4 w-4 mr-2" />
                    Filter
                  </Button>
                  <Button variant="outline" className="border-blue-300 hover:bg-blue-50">
                    <Star className="h-4 w-4 mr-2" />
                    Top Rated
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Featured Mentors */}
          <div className="space-y-4">
            <h2 className="text-2xl font-bold text-blue-700">Featured Mentors</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {mentors.map((mentor) => (
                <Card key={mentor.id} className="group hover:shadow-lg transition-all duration-300 border-l-4 border-l-blue-500">
                  <CardHeader className="pb-4">
                    <div className="flex items-start gap-4">
                      <Avatar className="h-16 w-16">
                        <AvatarImage src={mentor.image} alt={mentor.name} />
                        <AvatarFallback>{mentor.name.split(' ').map(n => n[0]).join('')}</AvatarFallback>
                      </Avatar>
                      <div className="flex-1">
                        <div className="flex justify-between items-start">
                          <div>
                            <CardTitle className="text-lg group-hover:text-blue-600 transition-colors">
                              {mentor.name}
                            </CardTitle>
                            <p className="text-sm text-muted-foreground">{mentor.title}</p>
                            <p className="text-sm font-medium text-blue-600">{mentor.company}</p>
                          </div>
                          {mentor.featured && (
                            <Badge className="bg-gradient-to-r from-yellow-400 to-orange-500 text-white">
                              <Star className="h-3 w-3 mr-1" />
                              Featured
                            </Badge>
                          )}
                        </div>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <p className="text-sm text-muted-foreground">{mentor.description}</p>
                    
                    <div className="flex flex-wrap gap-1">
                      {mentor.specialties.map((specialty) => (
                        <Badge key={specialty} variant="secondary" className="text-xs bg-blue-100 text-blue-700">
                          {specialty}
                        </Badge>
                      ))}
                    </div>

                    <div className="grid grid-cols-2 gap-4 text-sm">
                      <div>
                        <p className="text-muted-foreground">Experience</p>
                        <p className="font-medium">{mentor.experience}</p>
                      </div>
                      <div>
                        <p className="text-muted-foreground">Sessions</p>
                        <p className="font-medium">{mentor.sessions}</p>
                      </div>
                    </div>

                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <div className="flex items-center">
                          <Star className="h-4 w-4 text-yellow-400 fill-current" />
                          <span className="text-sm font-medium ml-1">{mentor.rating}</span>
                        </div>
                        <span className="text-xs text-muted-foreground">({mentor.reviews} reviews)</span>
                      </div>
                      <Badge 
                        variant={mentor.availability === 'Available' ? 'default' : 'secondary'}
                        className={mentor.availability === 'Available' ? 'bg-green-500' : ''}
                      >
                        {mentor.availability}
                      </Badge>
                    </div>

                    <div className="flex justify-between items-center pt-2 border-t">
                      <span className="font-bold text-lg text-blue-600">{mentor.price}</span>
                      <Button className="bg-gradient-to-r from-blue-500 to-cyan-500 hover:from-blue-600 hover:to-cyan-600">
                        Book Session
                        <ChevronRight className="h-4 w-4 ml-1" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </TabsContent>

        <TabsContent value="my-mentorship" className="space-y-6">
          <h2 className="text-2xl font-bold text-blue-700">My Mentorship Journey</h2>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {myMentors.map((mentor) => (
              <Card key={mentor.id} className="border-l-4 border-l-blue-500">
                <CardHeader>
                  <div className="flex items-center gap-4">
                    <Avatar className="h-12 w-12">
                      <AvatarImage src={mentor.image} alt={mentor.name} />
                      <AvatarFallback>{mentor.name.split(' ').map(n => n[0]).join('')}</AvatarFallback>
                    </Avatar>
                    <div>
                      <CardTitle className="text-lg">{mentor.name}</CardTitle>
                      <p className="text-sm text-muted-foreground">{mentor.title} at {mentor.company}</p>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <div className="flex justify-between items-center mb-2">
                      <p className="text-sm font-medium">Progress: {mentor.currentGoal}</p>
                      <p className="text-sm text-muted-foreground">{mentor.progress}%</p>
                    </div>
                    <Progress value={mentor.progress} className="h-2" />
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <p className="text-muted-foreground">Next Session</p>
                      <p className="font-medium">{mentor.nextSession}</p>
                    </div>
                    <div>
                      <p className="text-muted-foreground">Total Sessions</p>
                      <p className="font-medium">{mentor.totalSessions}</p>
                    </div>
                  </div>

                  <div className="flex gap-2">
                    <Button variant="outline" size="sm" className="flex-1">
                      <MessageSquare className="h-4 w-4 mr-2" />
                      Message
                    </Button>
                    <Button variant="outline" size="sm" className="flex-1">
                      <Calendar className="h-4 w-4 mr-2" />
                      Schedule
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="programs" className="space-y-6">
          <h2 className="text-2xl font-bold text-blue-700">Mentorship Programs</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {programs.map((program) => (
              <Card key={program.id} className="group hover:shadow-lg transition-all duration-300">
                <div className={`h-2 bg-gradient-to-r ${program.color} rounded-t-lg`}></div>
                <CardHeader>
                  <CardTitle className="text-xl group-hover:text-blue-600 transition-colors">
                    {program.title}
                  </CardTitle>
                  <CardDescription className="space-y-2">
                    <div className="flex justify-between">
                      <span>Duration: {program.duration}</span>
                      <span>{program.sessions} sessions</span>
                    </div>
                    <div className="text-sm text-blue-600 font-medium">{program.type}</div>
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    {program.features.map((feature, index) => (
                      <div key={index} className="flex items-center text-sm">
                        <div className="w-2 h-2 bg-blue-500 rounded-full mr-3"></div>
                        {feature}
                      </div>
                    ))}
                  </div>
                  
                  <div className="pt-4 border-t">
                    <div className="flex justify-between items-center">
                      <span className="text-2xl font-bold text-blue-600">{program.price}</span>
                      <Button className={`bg-gradient-to-r ${program.color} hover:opacity-90`}>
                        Enroll Now
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="progress" className="space-y-6">
          <h2 className="text-2xl font-bold text-blue-700">Your Progress & Achievements</h2>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Achievement Badges</CardTitle>
                <CardDescription>Unlock badges as you progress in your mentorship journey</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 gap-4">
                  {achievements.map((achievement, index) => {
                    const IconComponent = achievement.icon;
                    return (
                      <div 
                        key={index}
                        className={`p-4 rounded-lg border text-center space-y-2 ${
                          achievement.earned 
                            ? 'bg-blue-50 border-blue-200' 
                            : 'bg-gray-50 border-gray-200 opacity-50'
                        }`}
                      >
                        <div className={`w-12 h-12 rounded-full flex items-center justify-center mx-auto ${
                          achievement.earned ? 'bg-blue-500' : 'bg-gray-400'
                        }`}>
                          <IconComponent className="h-6 w-6 text-white" />
                        </div>
                        <p className="text-sm font-medium">{achievement.title}</p>
                      </div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Learning Analytics</CardTitle>
                <CardDescription>Track your learning progress and insights</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-4">
                  <div>
                    <div className="flex justify-between items-center mb-2">
                      <p className="text-sm font-medium">Overall Progress</p>
                      <p className="text-sm text-muted-foreground">75%</p>
                    </div>
                    <Progress value={75} className="h-3" />
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <div className="text-center p-4 bg-blue-50 rounded-lg">
                      <p className="text-2xl font-bold text-blue-600">13</p>
                      <p className="text-sm text-muted-foreground">Sessions Completed</p>
                    </div>
                    <div className="text-center p-4 bg-green-50 rounded-lg">
                      <p className="text-2xl font-bold text-green-600">3</p>
                      <p className="text-sm text-muted-foreground">Goals Achieved</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
      </div>
    </PlatformLayout>
  );
}