import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Separator } from "@/components/ui/separator";
import {
  User,
  Mail,
  Phone,
  MapPin,
  Linkedin,
  Eye,
  Share2,
  Download,
  ArrowLeft,
  Briefcase,
  GraduationCap,
  Star,
  Award,
  FileText,
  ExternalLink,
  CheckCircle,
  Languages
} from "lucide-react";
import { useState } from "react";
import { Link } from "wouter";
import PlatformLayout from "@/components/layout/platform-layout";
import { platformConfigs } from "@/config/complete-navigation";
import { useThemeClasses } from "@/lib/theme-config";

function ProfilePreviewContent() {
  const [sharePopupOpen, setSharePopupOpen] = useState(false);

  // Fetch user profile data
  const { data: profileData = {}, isLoading: profileLoading } = useQuery({
    queryKey: ["/api/profile"],
  });

  // Fetch user data
  const { data: userData = {}, isLoading: userLoading } = useQuery({
    queryKey: ["/api/user"],
  });

  // Fetch analytics data
  const { data: analyticsData = {}, isLoading: analyticsLoading } = useQuery({
    queryKey: ["/api/profile/analytics"],
  });

  // Extract profile from nested structure
  const profile = (profileData as any)?.profile || {};
  const user = userData as any;
  const analytics = analyticsData as any;
  
  // Extract data from profile structure
  const skills = profile.skills || [];
  const projects = profile.projects || [];
  const certifications = profile.certifications || [];
  const languages = profile.languages || [];
  const experiences = profile.experience || [];
  const educations = profile.education || [];
  const achievements = profile.achievements || [];
  const references = profile.references || [];

  const handleShare = () => {
    setSharePopupOpen(true);
  };

  const handlePrint = () => {
    window.print();
  };

  const handleCopyLink = () => {
    const profileUrl = `${window.location.origin}/candidate/profile-preview`;
    navigator.clipboard.writeText(profileUrl);
    alert("Profile link copied to clipboard!");
  };

  const handleLinkedInShare = () => {
    const text = encodeURIComponent(`Check out ${(user as any)?.username || 'my'} professional profile on TalentHub`);
    const url = encodeURIComponent(`${window.location.origin}/candidate/profile-preview`);
    window.open(`https://www.linkedin.com/sharing/share-offsite/?url=${url}&text=${text}`, '_blank');
  };

  const handleEmailShare = () => {
    const subject = encodeURIComponent(`${(user as any)?.username || 'My'} Professional Profile`);
    const body = encodeURIComponent(`Hi,\n\nI'd like to share my professional profile with you: ${window.location.origin}/candidate/profile-preview\n\nBest regards,\n${(user as any)?.username || 'Me'}`);
    window.location.href = `mailto:?subject=${subject}&body=${body}`;
  };

  if (profileLoading || userLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin w-8 h-8 border-4 border-sky-500 border-t-transparent rounded-full mx-auto"></div>
          <p className="mt-2 text-gray-600">Loading profile...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b border-gray-200 mb-6 print:hidden">
        <div className="max-w-4xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Link href="/candidate/profile-builder">
                <Button variant="outline" size="sm" className="flex items-center gap-2">
                  <ArrowLeft className="w-4 h-4" />
                  Back to Profile Builder
                </Button>
              </Link>
              <h1 className="text-xl font-semibold text-gray-900">Profile Preview</h1>
            </div>
            <div className="flex items-center gap-2">
              <Button 
                onClick={handleShare}
                variant="outline" 
                size="sm"
                className="flex items-center gap-2"
              >
                <Share2 className="w-4 h-4" />
                Share
              </Button>
              <Button 
                onClick={handlePrint}
                variant="outline" 
                size="sm"
                className="flex items-center gap-2"
              >
                <Download className="w-4 h-4" />
                Export PDF
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Share Popup */}
      {sharePopupOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 print:hidden">
          <div className="bg-white rounded-lg p-6 max-w-md w-full mx-4">
            <h3 className="text-lg font-semibold mb-4">Share Profile</h3>
            <div className="space-y-3">
              <Button 
                onClick={handleLinkedInShare}
                className="w-full flex items-center justify-start gap-3 bg-blue-600 hover:bg-blue-700"
              >
                <Linkedin className="w-5 h-5" />
                Share on LinkedIn
              </Button>
              <Button 
                onClick={handleEmailShare}
                variant="outline"
                className="w-full flex items-center justify-start gap-3"
              >
                <Mail className="w-5 h-5" />
                Share via Email
              </Button>
              <Button 
                onClick={handleCopyLink}
                variant="outline"
                className="w-full flex items-center justify-start gap-3"
              >
                <ExternalLink className="w-5 h-5" />
                Copy Link
              </Button>
            </div>
            <Button 
              onClick={() => setSharePopupOpen(false)}
              variant="ghost"
              className="w-full mt-4"
            >
              Close
            </Button>
          </div>
        </div>
      )}

      {/* Main Content */}
      <div className="max-w-4xl mx-auto px-6 space-y-6">
        {/* Profile Header */}
        <Card>
          <CardContent className="p-6">
            <div className="flex items-start gap-6">
              <div className="w-24 h-24 bg-gray-200 rounded-full flex items-center justify-center">
                {profile.profilePhoto ? (
                  <img 
                    src={profile.profilePhoto} 
                    alt="Profile" 
                    className="w-24 h-24 rounded-full object-cover"
                  />
                ) : (
                  <User className="w-12 h-12 text-gray-400" />
                )}
              </div>
              <div className="flex-1">
                <h1 className="text-2xl font-bold text-gray-900">
                  {user?.username || "Professional Profile"}
                </h1>
                <p className="text-lg text-gray-700 mt-1">
                  {profile.professionalTitle || "Software Developer"}
                </p>

                {profile.personalBrandStatement && (
                  <p className="text-lg text-gray-700 mt-2">{profile.personalBrandStatement}</p>
                )}

                {profile.bio && (
                  <p className="text-gray-600 mt-2">{profile.bio}</p>
                )}

                {profile.professionalSummary && (
                  <p className="text-gray-700 mt-3">{profile.professionalSummary}</p>
                )}

                {/* Contact Information */}
                <div className="flex flex-wrap items-center gap-4 mt-4 text-sm text-gray-600">
                  {user?.email && (
                    <div className="flex items-center gap-1">
                      <Mail className="w-4 h-4" />
                      {user.email}
                    </div>
                  )}
                  {profile.phone && (
                    <div className="flex items-center gap-1">
                      <Phone className="w-4 h-4" />
                      {profile.phone}
                    </div>
                  )}
                  {profile.location && (
                    <div className="flex items-center gap-1">
                      <MapPin className="w-4 h-4" />
                      {profile.location}
                    </div>
                  )}
                  {profile.linkedinUrl && (
                    <a 
                      href={profile.linkedinUrl} 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="flex items-center gap-1 text-sky-600 hover:text-sky-700"
                    >
                      <Linkedin className="w-4 h-4" />
                      LinkedIn
                    </a>
                  )}
                </div>
              </div>
              <div className="text-right">
                <div className="text-sm text-gray-600 mb-2">Profile Completion</div>
                <div className="flex items-center gap-2">
                  <Progress value={profile.profileCompletionScore || 0} className="w-20" />
                  <span className="text-sm font-medium">{profile.profileCompletionScore || 0}%</span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Profile Analytics */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Eye className="w-5 h-5" />
              Profile Analytics
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="text-center">
                <div className="text-2xl font-bold text-gray-900">{analytics.totalViews || 42}</div>
                <div className="text-sm text-gray-600">Total Views</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-gray-900">{analytics.uniqueViewers || 28}</div>
                <div className="text-sm text-gray-600">Unique Viewers</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-gray-900">{profile.profileCompletionScore || 0}%</div>
                <div className="text-sm text-gray-600">Profile Complete</div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Professional Summary */}
        {profile.professionalSummary && (
          <Card>
            <CardHeader>
              <CardTitle>Professional Summary</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-700 leading-relaxed">{profile.professionalSummary}</p>
            </CardContent>
          </Card>
        )}

        {/* Bio */}
        {profile.bio && (
          <Card>
            <CardHeader>
              <CardTitle>About</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-700 leading-relaxed">{profile.bio}</p>
            </CardContent>
          </Card>
        )}

        {/* Career Objective */}
        {profile.objective && (
          <Card>
            <CardHeader>
              <CardTitle>Career Objective</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-gray-700 leading-relaxed">{profile.objective}</p>
            </CardContent>
          </Card>
        )}

        {/* Work Experience */}
        {experiences && experiences.length > 0 && (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Briefcase className="w-5 h-5" />
                Work Experience
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              {experiences.map((exp: any, index: number) => (
                <div key={index} className="relative">
                  {index > 0 && <Separator className="mb-6" />}
                  <div className="flex items-start gap-4">
                    <div className="w-2 h-2 bg-gray-400 rounded-full mt-2 flex-shrink-0"></div>
                    <div className="flex-1">
                      <h3 className="font-semibold text-gray-900">{exp.position}</h3>
                      <p className="text-gray-700 font-medium">{exp.company}</p>
                      <p className="text-sm text-gray-600">
                        {exp.startDate} - {exp.isCurrent ? "Present" : exp.endDate}
                      </p>
                      {exp.location && (
                        <p className="text-sm text-gray-600">{exp.location}</p>
                      )}
                      {exp.description && (
                        <p className="text-gray-700 mt-2 leading-relaxed">{exp.description}</p>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>
        )}

        {/* Education */}
        {educations && educations.length > 0 && (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <GraduationCap className="w-5 h-5" />
                Education
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              {educations.map((edu: any, index: number) => (
                <div key={index} className="relative">
                  {index > 0 && <Separator className="mb-6" />}
                  <div className="flex items-start gap-4">
                    <div className="w-2 h-2 bg-gray-400 rounded-full mt-2 flex-shrink-0"></div>
                    <div className="flex-1">
                      <h3 className="font-semibold text-gray-900">{edu.degree} in {edu.field}</h3>
                      <p className="text-gray-700 font-medium">{edu.institution}</p>
                      <p className="text-sm text-gray-600">
                        {edu.startDate} - {edu.endDate || "Present"}
                      </p>
                      {edu.gpa && (
                        <p className="text-sm text-gray-600">GPA: {edu.gpa}</p>
                      )}
                      {edu.description && (
                        <p className="text-gray-700 mt-2 leading-relaxed">{edu.description}</p>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>
        )}

        {/* Skills */}
        {skills && skills.length > 0 && (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Star className="w-5 h-5" />
                Skills
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex flex-wrap gap-2">
                {skills.map((skill: any, index: number) => (
                  <Badge key={index} variant="secondary" className="bg-sky-100 text-sky-700">
                    {skill.name || skill}
                    {skill.level && (
                      <span className="ml-1 text-xs">({skill.level})</span>
                    )}
                  </Badge>
                ))}
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}

export default function ProfilePreview() {
  const config = platformConfigs.candidate;
  const theme = useThemeClasses('candidate');
  
  const usageData = [
    { label: "Profile Views", current: 28, max: 50 },
    { label: "Profile Completion", current: 92, max: 100 },
    { label: "Social Shares", current: 5, max: 20 },
  ];

  return (
    <PlatformLayout
      sidebarTitle={config.sidebarTitle}
      sidebarSubtitle={config.sidebarSubtitle}
      sidebarSections={config.sidebarSections}
      usageData={usageData}
    >
      <ProfilePreviewContent />
    </PlatformLayout>
  );
}