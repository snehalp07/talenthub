import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import PlatformLayout from "@/components/layout/platform-layout";
import { platformConfigs } from "@/config/navigation";
import CertificateViewerModal from "@/components/certificate-viewer-modal";
import CertificateVerificationModal from "@/components/certificate-verification-modal";
import { 
  Award, 
  Calendar, 
  CheckCircle,
  Clock,
  Star,
  Trophy,
  Download,
  ExternalLink,
  Target,
  TrendingUp,
  BookOpen,
  Users,
  Eye,
  Shield
} from "lucide-react";
import { useState } from "react";

interface Certificate {
  id: string;
  title: string;
  issuer: string;
  issueDate: string;
  expiryDate: string;
  credentialId: string;
  verified: boolean;
  skills: string[];
  score: number;
  level: string;
  verificationCode?: string;
  certificateHash?: string;
}

export default function Certifications() {
  const config = platformConfigs.candidate;
  
  // Modal state management
  const [selectedCertificate, setSelectedCertificate] = useState<Certificate | null>(null);
  const [viewerOpen, setViewerOpen] = useState(false);
  const [verificationOpen, setVerificationOpen] = useState(false);

  const earnedCertifications: Certificate[] = [
    {
      id: "cert-react-dev-001",
      title: "React Developer Certification",
      issuer: "TalentHub Academy",
      issueDate: "2024-05-15",
      expiryDate: "2026-05-15",
      credentialId: "TH-RDC-2024-5789",
      verified: true,
      skills: ["React", "JavaScript", "JSX", "Hooks"],
      score: 94,
      level: "Advanced",
      verificationCode: "VF-TH-RDC-2024-5789",
      certificateHash: "a1b2c3d4e5f6g7h8i9j0k1l2m3n4o5p6"
    },
    {
      id: "cert-fullstack-js-002",
      title: "Full Stack JavaScript",
      issuer: "TechSkills Institute",
      issueDate: "2024-03-20",
      expiryDate: "2025-03-20",
      credentialId: "TSI-FSJ-2024-3421",
      verified: true,
      skills: ["Node.js", "Express", "MongoDB", "React"],
      score: 87,
      level: "Intermediate",
      verificationCode: "VF-TSI-FSJ-2024-3421",
      certificateHash: "b2c3d4e5f6g7h8i9j0k1l2m3n4o5p6q7"
    },
    {
      id: "cert-aws-cloud-003",
      title: "AWS Cloud Fundamentals",
      issuer: "Amazon Web Services",
      issueDate: "2024-01-10",
      expiryDate: "2025-01-10",
      credentialId: "AWS-CF-2024-1234",
      verified: true,
      skills: ["AWS", "EC2", "S3", "Lambda"],
      score: 91,
      level: "Foundation",
      verificationCode: "VF-AWS-CF-2024-1234",
      certificateHash: "c3d4e5f6g7h8i9j0k1l2m3n4o5p6q7r8"
    }
  ];

  const availableCertifications = [
    {
      title: "Advanced System Design",
      provider: "TalentHub Academy",
      duration: "6 weeks",
      difficulty: "Advanced",
      price: "₹12,999",
      rating: 4.8,
      students: 2847,
      topics: ["Scalability", "Microservices", "Load Balancing", "Caching"],
      description: "Master the art of designing large-scale distributed systems",
      prerequisites: ["Backend Development", "Database Design"]
    },
    {
      title: "Data Science with Python",
      provider: "Analytics Pro",
      duration: "8 weeks",
      difficulty: "Intermediate",
      price: "₹15,999",
      rating: 4.7,
      students: 1923,
      topics: ["Python", "Pandas", "NumPy", "Machine Learning"],
      description: "Complete data science certification with hands-on projects",
      prerequisites: ["Python Basics", "Statistics"]
    },
    {
      title: "Mobile App Development",
      provider: "Mobile Masters",
      duration: "10 weeks",
      difficulty: "Intermediate",
      price: "₹18,999",
      rating: 4.6,
      students: 1456,
      topics: ["React Native", "Flutter", "iOS", "Android"],
      description: "Build cross-platform mobile applications from scratch",
      prerequisites: ["JavaScript", "React"]
    },
    {
      title: "DevOps Engineering",
      provider: "Cloud Institute",
      duration: "12 weeks",
      difficulty: "Advanced",
      price: "₹22,999",
      rating: 4.9,
      students: 987,
      topics: ["Docker", "Kubernetes", "CI/CD", "Monitoring"],
      description: "Complete DevOps transformation and automation",
      prerequisites: ["Linux", "Cloud Basics"]
    }
  ];

  const inProgressCertifications = [
    {
      title: "Advanced React Patterns",
      provider: "TalentHub Academy",
      progress: 68,
      completedModules: 8,
      totalModules: 12,
      estimatedCompletion: "2024-07-15",
      nextDeadline: "Module 9 Quiz - June 20"
    },
    {
      title: "Blockchain Development",
      provider: "Web3 Academy",
      progress: 35,
      completedModules: 4,
      totalModules: 10,
      estimatedCompletion: "2024-08-30",
      nextDeadline: "Smart Contract Assignment - June 25"
    }
  ];

  // Modal handlers
  const handleViewCertificate = (certificate: Certificate) => {
    setSelectedCertificate(certificate);
    setViewerOpen(true);
  };

  const handleVerifyCertificate = (certificate: Certificate) => {
    setSelectedCertificate(certificate);
    setVerificationOpen(true);
  };

  const handleDownloadCertificate = (certificate: Certificate) => {
    // Simulate certificate download
    const element = document.createElement("a");
    const file = new Blob([`Certificate: ${certificate.title}\nCredential ID: ${certificate.credentialId}`], 
      { type: 'text/plain' });
    element.href = URL.createObjectURL(file);
    element.download = `${certificate.title.replace(/\s+/g, '_')}_Certificate.pdf`;
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
  };

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case "Foundation":
        return "bg-green-100 text-green-600";
      case "Intermediate":
        return "bg-yellow-100 text-yellow-600";
      case "Advanced":
        return "bg-red-100 text-red-600";
      default:
        return "bg-gray-100 text-gray-600";
    }
  };

  return (
    <PlatformLayout
      sidebarTitle={config.sidebarTitle}
      sidebarSubtitle={config.sidebarSubtitle}
      sidebarSections={config.sidebarSections}
      usageData={config.usageData}
    >
      <div className="max-w-6xl mx-auto px-6 py-8">
        {/* Header */}
        <div className="mb-8">
          <h2 className="text-3xl font-bold text-neutral-600 mb-2">Certifications</h2>
          <p className="text-neutral-500">Build your expertise with industry-recognized certifications and showcase your skills to employers.</p>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card className="shadow-sm">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                  <Award className="w-6 h-6 text-green-600" />
                </div>
                <Badge variant="outline">Earned</Badge>
              </div>
              <h3 className="text-2xl font-bold text-neutral-600 mb-1">3</h3>
              <p className="text-sm text-neutral-500">Certifications</p>
            </CardContent>
          </Card>

          <Card className="shadow-sm">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                  <Clock className="w-6 h-6 text-blue-600" />
                </div>
                <Badge variant="outline">In Progress</Badge>
              </div>
              <h3 className="text-2xl font-bold text-neutral-600 mb-1">2</h3>
              <p className="text-sm text-neutral-500">Learning Paths</p>
            </CardContent>
          </Card>

          <Card className="shadow-sm">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
                  <Star className="w-6 h-6 text-purple-600" />
                </div>
                <Badge variant="outline">Average</Badge>
              </div>
              <h3 className="text-2xl font-bold text-neutral-600 mb-1">91%</h3>
              <p className="text-sm text-neutral-500">Score</p>
            </CardContent>
          </Card>

          <Card className="shadow-sm">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center">
                  <Trophy className="w-6 h-6 text-orange-600" />
                </div>
                <Badge variant="outline">Verified</Badge>
              </div>
              <h3 className="text-2xl font-bold text-neutral-600 mb-1">100%</h3>
              <p className="text-sm text-neutral-500">Verification Rate</p>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-8">
            {/* Earned Certifications */}
            <Card className="shadow-sm">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="text-xl">Earned Certifications</CardTitle>
                  <Button variant="ghost" size="sm">
                    <Download className="w-4 h-4 mr-1" />
                    Download All
                  </Button>
                </div>
                <CardDescription>
                  Your verified professional certifications
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {earnedCertifications.map((cert, index) => (
                    <div key={index} className="border border-neutral-200 rounded-lg p-4">
                      <div className="flex items-start justify-between mb-3">
                        <div className="flex-1">
                          <div className="flex items-center space-x-2 mb-2">
                            <Award className="w-5 h-5 text-yellow-500" />
                            <h3 className="font-semibold text-neutral-600">{cert.title}</h3>
                            <Badge className="bg-green-100 text-green-600">
                              <CheckCircle className="w-3 h-3 mr-1" />
                              Verified
                            </Badge>
                          </div>
                          <p className="text-sm text-neutral-500 mb-2">{cert.issuer}</p>
                          <div className="flex items-center space-x-4 text-xs text-neutral-400 mb-3">
                            <div className="flex items-center">
                              <Calendar className="w-3 h-3 mr-1" />
                              Issued: {cert.issueDate}
                            </div>
                            <div className="flex items-center">
                              <Clock className="w-3 h-3 mr-1" />
                              Expires: {cert.expiryDate}
                            </div>
                          </div>
                          <div className="flex items-center space-x-2 mb-2">
                            {cert.skills.map((skill, skillIndex) => (
                              <Badge key={skillIndex} variant="outline" className="text-xs">
                                {skill}
                              </Badge>
                            ))}
                          </div>
                          <p className="text-xs text-neutral-400">ID: {cert.credentialId}</p>
                        </div>
                        <div className="text-right">
                          <Badge className={getDifficultyColor(cert.level)} variant="outline">
                            {cert.level}
                          </Badge>
                          <p className="text-lg font-bold text-green-600 mt-1">{cert.score}%</p>
                        </div>
                      </div>
                      <div className="flex items-center justify-between pt-3 border-t border-neutral-200">
                        <div className="flex items-center space-x-2">
                          <Star className="w-4 h-4 text-yellow-500 fill-current" />
                          <span className="text-xs text-neutral-500">Industry recognized</span>
                        </div>
                        <div className="flex space-x-2">
                          <Button 
                            variant="default" 
                            size="sm"
                            onClick={() => handleViewCertificate(cert)}
                            className="bg-blue-600 hover:bg-blue-700 text-white"
                          >
                            <Eye className="w-4 h-4 mr-1" />
                            View Certificate
                          </Button>
                          <Button 
                            variant="outline" 
                            size="sm"
                            onClick={() => handleVerifyCertificate(cert)}
                          >
                            <Shield className="w-4 h-4 mr-1" />
                            Verify
                          </Button>
                          <Button 
                            variant="outline" 
                            size="sm"
                            onClick={() => handleDownloadCertificate(cert)}
                          >
                            <Download className="w-4 h-4 mr-1" />
                            Download
                          </Button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Available Certifications */}
            <Card className="shadow-sm">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="text-xl">Available Certifications</CardTitle>
                  <Button variant="ghost" size="sm">View All</Button>
                </div>
                <CardDescription>
                  Recommended certification programs based on your profile
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {availableCertifications.map((cert, index) => (
                    <div key={index} className="border border-neutral-200 rounded-lg p-4 hover:bg-neutral-50 transition-colors">
                      <div className="flex items-start justify-between mb-3">
                        <div className="flex-1">
                          <h4 className="font-semibold text-neutral-600 mb-1">{cert.title}</h4>
                          <p className="text-sm text-neutral-500 mb-2">{cert.provider}</p>
                          <p className="text-xs text-neutral-600 mb-3">{cert.description}</p>
                          <div className="flex items-center space-x-4 text-xs text-neutral-400 mb-2">
                            <div className="flex items-center">
                              <Clock className="w-3 h-3 mr-1" />
                              {cert.duration}
                            </div>
                            <div className="flex items-center">
                              <Users className="w-3 h-3 mr-1" />
                              {cert.students.toLocaleString()}
                            </div>
                            <div className="flex items-center">
                              <Star className="w-3 h-3 mr-1" />
                              {cert.rating}
                            </div>
                          </div>
                          <div className="flex items-center space-x-2 mb-2">
                            {cert.topics.slice(0, 3).map((topic, topicIndex) => (
                              <Badge key={topicIndex} variant="outline" className="text-xs">
                                {topic}
                              </Badge>
                            ))}
                            {cert.topics.length > 3 && (
                              <span className="text-xs text-neutral-400">+{cert.topics.length - 3} more</span>
                            )}
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center justify-between pt-3 border-t border-neutral-200">
                        <div className="flex items-center space-x-2">
                          <Badge className={getDifficultyColor(cert.difficulty)}>
                            {cert.difficulty}
                          </Badge>
                          <span className="font-semibold text-neutral-600">{cert.price}</span>
                        </div>
                        <Button className="bg-blue-500 hover:bg-blue-600" size="sm">
                          Enroll Now
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* In Progress */}
            <Card className="shadow-sm">
              <CardHeader>
                <CardTitle className="text-lg">In Progress</CardTitle>
                <CardDescription>
                  Your current certification journeys
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {inProgressCertifications.map((cert, index) => (
                    <div key={index} className="border border-neutral-200 rounded-lg p-3">
                      <h4 className="font-medium text-neutral-600 mb-2">{cert.title}</h4>
                      <p className="text-sm text-neutral-500 mb-3">{cert.provider}</p>
                      <div className="space-y-2">
                        <div className="flex justify-between text-sm">
                          <span className="text-neutral-500">Progress</span>
                          <span className="font-medium">{cert.progress}%</span>
                        </div>
                        <Progress value={cert.progress} className="h-2" />
                        <div className="flex justify-between text-xs text-neutral-400">
                          <span>{cert.completedModules}/{cert.totalModules} modules</span>
                          <span>Est: {cert.estimatedCompletion}</span>
                        </div>
                        <div className="text-xs text-blue-600 mt-2">
                          Next: {cert.nextDeadline}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
                <Button variant="outline" className="w-full mt-4">
                  <BookOpen className="w-4 h-4 mr-2" />
                  Continue Learning
                </Button>
              </CardContent>
            </Card>

            {/* Recommendations */}
            <Card className="shadow-sm">
              <CardHeader>
                <CardTitle className="text-lg">Recommended Next</CardTitle>
                <CardDescription>
                  Based on your current skills
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="border border-neutral-200 rounded-lg p-3">
                    <div className="flex items-center space-x-2 mb-2">
                      <Target className="w-4 h-4 text-blue-600" />
                      <span className="text-sm font-medium">Career Goal</span>
                    </div>
                    <p className="text-sm text-neutral-600 mb-1">Senior Full Stack Developer</p>
                    <p className="text-xs text-neutral-500">Complete System Design certification</p>
                  </div>
                  <div className="border border-neutral-200 rounded-lg p-3">
                    <div className="flex items-center space-x-2 mb-2">
                      <TrendingUp className="w-4 h-4 text-green-600" />
                      <span className="text-sm font-medium">Market Demand</span>
                    </div>
                    <p className="text-sm text-neutral-600 mb-1">DevOps Skills</p>
                    <p className="text-xs text-neutral-500">High demand in current market</p>
                  </div>
                  <div className="border border-neutral-200 rounded-lg p-3">
                    <div className="flex items-center space-x-2 mb-2">
                      <Award className="w-4 h-4 text-purple-600" />
                      <span className="text-sm font-medium">Skill Gap</span>
                    </div>
                    <p className="text-sm text-neutral-600 mb-1">Data Science Basics</p>
                    <p className="text-xs text-neutral-500">Complement your tech stack</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>

      {/* Certificate Modals */}
      <CertificateViewerModal
        certificate={selectedCertificate}
        isOpen={viewerOpen}
        onClose={() => setViewerOpen(false)}
        onVerify={handleVerifyCertificate}
        onDownload={handleDownloadCertificate}
      />

      <CertificateVerificationModal
        certificate={selectedCertificate}
        isOpen={verificationOpen}
        onClose={() => setVerificationOpen(false)}
      />
    </PlatformLayout>
  );
}