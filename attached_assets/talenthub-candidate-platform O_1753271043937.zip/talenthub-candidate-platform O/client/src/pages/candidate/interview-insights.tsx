import PlatformLayout from "@/components/layout/platform-layout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { MessageCircle, Users, Star, TrendingUp } from "lucide-react";
import { candidateNavigation } from "@/config/complete-navigation";

export default function InterviewInsights() {
  return (
    <PlatformLayout 
      sidebarTitle="Candidate Platform"
      sidebarSubtitle="Professional Development Hub"
      sidebarSections={candidateNavigation}
    >
      <div className="max-w-7xl mx-auto p-6 space-y-8">
        <div className="text-center space-y-4">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-teal-100 to-cyan-100 rounded-full">
            <MessageCircle className="h-5 w-5 text-teal-600" />
            <span className="text-sm font-medium text-teal-900">Interview Performance Insights</span>
          </div>
          <h1 className="text-4xl font-bold bg-gradient-to-r from-teal-600 to-cyan-600 bg-clip-text text-transparent">
            Interview Analytics Dashboard
          </h1>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            Analyze interview performance, communication patterns, and improvement opportunities
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <Card className="hover:shadow-md transition-shadow">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="p-3 rounded-lg bg-teal-500 text-white">
                  <MessageCircle className="h-6 w-6" />
                </div>
                <div className="text-2xl font-bold text-teal-600">23</div>
              </div>
              <div className="text-sm text-gray-600">Total Interviews</div>
            </CardContent>
          </Card>

          <Card className="hover:shadow-md transition-shadow">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="p-3 rounded-lg bg-blue-500 text-white">
                  <TrendingUp className="h-6 w-6" />
                </div>
                <div className="text-2xl font-bold text-blue-600">87%</div>
              </div>
              <div className="text-sm text-gray-600">Success Rate</div>
            </CardContent>
          </Card>

          <Card className="hover:shadow-md transition-shadow">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="p-3 rounded-lg bg-green-500 text-white">
                  <Star className="h-6 w-6" />
                </div>
                <div className="text-2xl font-bold text-green-600">4.3</div>
              </div>
              <div className="text-sm text-gray-600">Avg Rating</div>
            </CardContent>
          </Card>

          <Card className="hover:shadow-md transition-shadow">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="p-3 rounded-lg bg-purple-500 text-white">
                  <Users className="h-6 w-6" />
                </div>
                <div className="text-2xl font-bold text-purple-600">12</div>
              </div>
              <div className="text-sm text-gray-600">Companies</div>
            </CardContent>
          </Card>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Interview Performance Analytics</CardTitle>
            <CardDescription>Detailed insights into your interview communication and performance patterns</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-center py-12">
              <MessageCircle className="h-16 w-16 mx-auto text-teal-500 mb-4" />
              <h3 className="text-xl font-semibold text-gray-900 mb-2">Interview Performance Tracking</h3>
              <p className="text-gray-600 mb-6">Comprehensive analysis of your interview skills and communication effectiveness</p>
              <Button className="bg-gradient-to-r from-teal-600 to-cyan-600 hover:from-teal-700 hover:to-cyan-700">
                View Detailed Analytics
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </PlatformLayout>
  );
}