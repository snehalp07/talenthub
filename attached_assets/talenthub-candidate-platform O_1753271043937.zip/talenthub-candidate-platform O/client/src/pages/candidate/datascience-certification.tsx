import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import PlatformLayout from "@/components/layout/platform-layout";
import { candidateNavigation } from "@/config/complete-navigation";
import { 
  Database, Play, CheckCircle, Award, Target, TrendingUp, 
  Star, Clock, Code, Users, Zap, BookOpen, Trophy,
  ArrowRight, BarChart3, Brain, Activity, LineChart
} from "lucide-react";

const DataScienceCertification: React.FC = () => {
  const [selectedTrack, setSelectedTrack] = useState('python-ml');

  const dataScienceTracks = [
    {
      id: 'python-ml',
      name: 'Python ML Engineer',
      description: 'Machine Learning with Python & Scikit-learn',
      icon: Database,
      color: 'from-indigo-500 to-purple-500',
      duration: '14-18 weeks',
      enrolled: 16750,
      completion: 38,
      rating: 4.9,
      modules: [
        { name: 'Python for Data Science', status: 'completed', progress: 100, projects: 3 },
        { name: 'Statistics & Probability', status: 'completed', progress: 100, projects: 2 },
        { name: 'Machine Learning Basics', status: 'current', progress: 60, projects: 4 },
        { name: 'Deep Learning Fundamentals', status: 'locked', progress: 0, projects: 3 },
        { name: 'Model Deployment', status: 'locked', progress: 0, projects: 2 },
        { name: 'MLOps & Production', status: 'locked', progress: 0, projects: 3 }
      ]
    },
    {
      id: 'data-analyst',
      name: 'Data Analyst',
      description: 'SQL, Excel, Tableau & Power BI',
      icon: BarChart3,
      color: 'from-green-500 to-teal-500',
      duration: '10-14 weeks',
      enrolled: 21340,
      completion: 55,
      rating: 4.8,
      modules: [
        { name: 'SQL Mastery', status: 'completed', progress: 100, projects: 4 },
        { name: 'Excel Advanced Analytics', status: 'current', progress: 80, projects: 3 },
        { name: 'Tableau Visualization', status: 'locked', progress: 0, projects: 4 },
        { name: 'Power BI Dashboards', status: 'locked', progress: 0, projects: 3 },
        { name: 'Statistical Analysis', status: 'locked', progress: 0, projects: 2 },
        { name: 'Business Intelligence', status: 'locked', progress: 0, projects: 3 }
      ]
    },
    {
      id: 'ai-engineer',
      name: 'AI Engineer',
      description: 'TensorFlow, PyTorch & Neural Networks',
      icon: Brain,
      color: 'from-yellow-500 to-orange-500',
      duration: '16-22 weeks',
      enrolled: 8920,
      completion: 12,
      rating: 4.7,
      modules: [
        { name: 'Neural Network Theory', status: 'not-started', progress: 0, projects: 2 },
        { name: 'TensorFlow Fundamentals', status: 'not-started', progress: 0, projects: 3 },
        { name: 'Computer Vision', status: 'not-started', progress: 0, projects: 4 },
        { name: 'Natural Language Processing', status: 'not-started', progress: 0, projects: 3 },
        { name: 'Reinforcement Learning', status: 'not-started', progress: 0, projects: 2 },
        { name: 'AI Model Optimization', status: 'not-started', progress: 0, projects: 3 }
      ]
    }
  ];

  const skillAssessments = [
    { skill: 'Python Programming', current: 85, target: 90, trend: '+8%' },
    { skill: 'Statistical Analysis', current: 78, target: 85, trend: '+12%' },
    { skill: 'Machine Learning', current: 70, target: 80, trend: '+15%' },
    { skill: 'Data Visualization', current: 82, target: 90, trend: '+6%' },
    { skill: 'SQL & Databases', current: 88, target: 95, trend: '+4%' }
  ];

  const industryProjects = [
    { 
      title: 'Customer Churn Prediction',
      industry: 'Telecom',
      status: 'completed',
      score: 94,
      techniques: ['Random Forest', 'Feature Engineering', 'Cross-validation']
    },
    { 
      title: 'Sales Forecasting Model',
      industry: 'Retail',
      status: 'current',
      score: 0,
      techniques: ['Time Series', 'ARIMA', 'Prophet']
    },
    { 
      title: 'Recommendation Engine',
      industry: 'E-commerce',
      status: 'upcoming',
      score: 0,
      techniques: ['Collaborative Filtering', 'Matrix Factorization', 'Deep Learning']
    },
    { 
      title: 'Fraud Detection System',
      industry: 'Finance',
      status: 'upcoming',
      score: 0,
      techniques: ['Anomaly Detection', 'Ensemble Methods', 'Real-time Processing']
    }
  ];

  const toolsProficiency = [
    { tool: 'Python', proficiency: 85, color: 'bg-blue-500' },
    { tool: 'R', proficiency: 60, color: 'bg-green-500' },
    { tool: 'SQL', proficiency: 90, color: 'bg-purple-500' },
    { tool: 'Tableau', proficiency: 75, color: 'bg-orange-500' },
    { tool: 'TensorFlow', proficiency: 55, color: 'bg-red-500' },
    { tool: 'Spark', proficiency: 40, color: 'bg-yellow-500' }
  ];

  const selectedTrackData = dataScienceTracks.find(track => track.id === selectedTrack);

  return (
    <PlatformLayout
      sidebarTitle="Candidate Platform"
      sidebarSubtitle="Interview Preparation"
      sidebarSections={candidateNavigation}
    >
      <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-white to-purple-50 p-6">
        <div className="max-w-7xl mx-auto space-y-8">
          {/* Header */}
          <div className="text-center space-y-4">
            <div className="inline-flex items-center space-x-2 bg-indigo-100 text-indigo-800 px-4 py-2 rounded-full text-sm font-medium">
              <Database className="h-4 w-4" />
              <span>Data Science & AI Certification</span>
            </div>
            <h1 className="text-4xl font-bold text-gray-900">
              Master Data Science & AI
            </h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Build predictive models, analyze data, and create AI solutions. 
              Master Python, machine learning, and data visualization through industry projects.
            </p>
          </div>

          <Tabs value={selectedTrack} onValueChange={setSelectedTrack} className="space-y-6">
            {/* Track Selection */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {dataScienceTracks.map((track) => {
                const IconComponent = track.icon;
                return (
                  <Card 
                    key={track.id} 
                    className={`cursor-pointer transition-all duration-300 hover:shadow-lg border-2 ${
                      selectedTrack === track.id 
                        ? 'border-indigo-500 shadow-lg' 
                        : 'border-gray-200 hover:border-indigo-300'
                    }`}
                    onClick={() => setSelectedTrack(track.id)}
                  >
                    <CardHeader className="pb-3">
                      <div className="flex items-center justify-between">
                        <div className={`p-3 rounded-lg bg-gradient-to-r ${track.color}`}>
                          <IconComponent className="h-6 w-6 text-white" />
                        </div>
                        <div className="flex items-center space-x-1">
                          <Star className="h-4 w-4 text-yellow-500 fill-current" />
                          <span className="text-sm font-medium">{track.rating}</span>
                        </div>
                      </div>
                      <CardTitle className="text-lg">{track.name}</CardTitle>
                      <CardDescription className="text-sm">{track.description}</CardDescription>
                    </CardHeader>
                    <CardContent className="pt-0">
                      <div className="space-y-3">
                        <div className="flex justify-between text-sm">
                          <span>Progress</span>
                          <span className="font-medium">{track.completion}%</span>
                        </div>
                        <Progress value={track.completion} className="h-2" />
                        <div className="grid grid-cols-2 gap-4 text-sm">
                          <div className="flex items-center space-x-2">
                            <Clock className="h-4 w-4 text-gray-500" />
                            <span>{track.duration}</span>
                          </div>
                          <div className="flex items-center space-x-2">
                            <Users className="h-4 w-4 text-gray-500" />
                            <span>{(track.enrolled / 1000).toFixed(1)}k</span>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>

            {/* Selected Track Details */}
            {selectedTrackData && (
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                {/* Learning Path */}
                <div className="lg:col-span-2 space-y-6">
                  <Card>
                    <CardHeader className={`bg-gradient-to-r ${selectedTrackData.color} text-white`}>
                      <CardTitle className="text-xl flex items-center space-x-3">
                        <selectedTrackData.icon className="h-6 w-6" />
                        <span>{selectedTrackData.name} Curriculum</span>
                      </CardTitle>
                      <CardDescription className="text-white/80">
                        {selectedTrackData.description} • {selectedTrackData.duration}
                      </CardDescription>
                    </CardHeader>
                    <CardContent className="p-6">
                      <div className="space-y-4">
                        {selectedTrackData.modules.map((module, index) => (
                          <div 
                            key={index} 
                            className={`p-4 rounded-lg border-2 transition-all ${
                              module.status === 'completed' 
                                ? 'bg-green-50 border-green-200' 
                                : module.status === 'current'
                                ? 'bg-indigo-50 border-indigo-200'
                                : 'bg-gray-50 border-gray-200'
                            }`}
                          >
                            <div className="flex items-center justify-between mb-2">
                              <div className="flex items-center space-x-3">
                                {module.status === 'completed' ? (
                                  <CheckCircle className="h-5 w-5 text-green-500" />
                                ) : module.status === 'current' ? (
                                  <Play className="h-5 w-5 text-indigo-500" />
                                ) : (
                                  <Clock className="h-5 w-5 text-gray-400" />
                                )}
                                <span className="font-medium">{module.name}</span>
                              </div>
                              <Badge variant="outline">
                                {module.projects} projects
                              </Badge>
                            </div>
                            {module.status !== 'not-started' && module.status !== 'locked' && (
                              <div className="space-y-1 mb-3">
                                <div className="flex justify-between text-sm">
                                  <span>Progress</span>
                                  <span>{module.progress}%</span>
                                </div>
                                <Progress value={module.progress} className="h-1.5" />
                              </div>
                            )}
                            <Button 
                              variant={module.status === 'current' ? 'default' : 'ghost'} 
                              size="sm"
                              className="w-full"
                              disabled={module.status === 'locked' || module.status === 'not-started'}
                            >
                              {module.status === 'completed' ? 'Review Projects' :
                               module.status === 'current' ? 'Continue Learning' : 
                               module.status === 'locked' ? 'Complete Prerequisites' : 'Start Module'}
                            </Button>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>

                  {/* Industry Projects */}
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center space-x-2">
                        <Trophy className="h-5 w-5" />
                        <span>Real-World Projects</span>
                      </CardTitle>
                      <CardDescription>Apply your skills to industry scenarios</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        {industryProjects.map((project, index) => (
                          <div key={index} className="p-4 bg-gray-50 rounded-lg">
                            <div className="flex items-center justify-between mb-2">
                              <span className="font-medium">{project.title}</span>
                              <Badge variant="outline">{project.industry}</Badge>
                            </div>
                            <div className="flex flex-wrap gap-1 mb-2">
                              {project.techniques.map((technique, techIndex) => (
                                <Badge key={techIndex} variant="secondary" className="text-xs">
                                  {technique}
                                </Badge>
                              ))}
                            </div>
                            <div className="flex items-center justify-between">
                              <span className={`text-xs px-2 py-1 rounded ${
                                project.status === 'completed' ? 'bg-green-100 text-green-800' :
                                project.status === 'current' ? 'bg-blue-100 text-blue-800' :
                                'bg-gray-100 text-gray-800'
                              }`}>
                                {project.status}
                              </span>
                              {project.status === 'completed' && (
                                <span className="text-sm font-semibold text-green-600">
                                  {project.score}%
                                </span>
                              )}
                            </div>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                </div>

                {/* Sidebar */}
                <div className="space-y-6">
                  {/* Skills Assessment */}
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center space-x-2">
                        <Target className="h-5 w-5" />
                        <span>Skill Assessment</span>
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      {skillAssessments.map((skill, index) => (
                        <div key={index} className="space-y-2">
                          <div className="flex justify-between items-center">
                            <span className="text-sm font-medium">{skill.skill}</span>
                            <div className="flex items-center space-x-2">
                              <span className="text-xs">{skill.current}%</span>
                              <Badge variant="secondary" className="text-xs bg-green-100 text-green-700">
                                {skill.trend}
                              </Badge>
                            </div>
                          </div>
                          <div className="relative">
                            <Progress value={skill.current} className="h-2" />
                            <div 
                              className="absolute top-0 h-2 w-1 bg-red-500 rounded-full"
                              style={{ left: `${skill.target}%` }}
                            />
                          </div>
                          <div className="text-xs text-gray-500">
                            Target: {skill.target}%
                          </div>
                        </div>
                      ))}
                    </CardContent>
                  </Card>

                  {/* Tools Proficiency */}
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center space-x-2">
                        <Code className="h-5 w-5" />
                        <span>Tools & Tech</span>
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-3">
                      {toolsProficiency.map((tool, index) => (
                        <div key={index} className="flex items-center justify-between">
                          <span className="text-sm font-medium">{tool.tool}</span>
                          <div className="flex items-center space-x-2">
                            <div className="w-16 bg-gray-200 rounded-full h-2">
                              <div 
                                className={`h-2 rounded-full ${tool.color}`}
                                style={{ width: `${tool.proficiency}%` }}
                              />
                            </div>
                            <span className="text-xs w-8">{tool.proficiency}%</span>
                          </div>
                        </div>
                      ))}
                    </CardContent>
                  </Card>

                  {/* Action Buttons */}
                  <div className="space-y-3">
                    <Button size="lg" className="w-full bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700">
                      <Play className="h-4 w-4 mr-2" />
                      Continue Learning
                    </Button>
                    <Button variant="outline" size="lg" className="w-full">
                      <Database className="h-4 w-4 mr-2" />
                      Practice Dataset
                    </Button>
                    <Button variant="outline" size="lg" className="w-full">
                      <LineChart className="h-4 w-4 mr-2" />
                      ML Playground
                    </Button>
                  </div>
                </div>
              </div>
            )}
          </Tabs>
        </div>
      </div>
    </PlatformLayout>
  );
};

export default DataScienceCertification;