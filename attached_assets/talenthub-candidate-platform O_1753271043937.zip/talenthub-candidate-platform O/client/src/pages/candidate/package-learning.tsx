import PlatformLayout from "@/components/layout/platform-layout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Package, BookOpen, Star, Trophy } from "lucide-react";
import { candidateNavigation } from "@/config/complete-navigation";

export default function PackageLearning() {
  return (
    <PlatformLayout 
      sidebarTitle="Candidate Platform"
      sidebarSubtitle="Professional Development Hub"
      sidebarSections={candidateNavigation}
    >
      <div className="max-w-7xl mx-auto p-6 space-y-8">
        <div className="text-center space-y-4">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-purple-100 to-indigo-100 rounded-full">
            <Package className="h-5 w-5 text-purple-600" />
            <span className="text-sm font-medium text-purple-900">Package-Based Learning</span>
          </div>
          <h1 className="text-4xl font-bold bg-gradient-to-r from-purple-600 to-indigo-600 bg-clip-text text-transparent">
            Learning Package Analytics
          </h1>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            Track progress across comprehensive learning packages and certification bundles
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <Card className="hover:shadow-md transition-shadow">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="p-3 rounded-lg bg-purple-500 text-white">
                  <Package className="h-6 w-6" />
                </div>
                <div className="text-2xl font-bold text-purple-600">8</div>
              </div>
              <div className="text-sm text-gray-600">Active Learning Packages</div>
            </CardContent>
          </Card>

          <Card className="hover:shadow-md transition-shadow">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="p-3 rounded-lg bg-blue-500 text-white">
                  <BookOpen className="h-6 w-6" />
                </div>
                <div className="text-2xl font-bold text-blue-600">24</div>
              </div>
              <div className="text-sm text-gray-600">Courses Completed</div>
            </CardContent>
          </Card>

          <Card className="hover:shadow-md transition-shadow">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="p-3 rounded-lg bg-green-500 text-white">
                  <Star className="h-6 w-6" />
                </div>
                <div className="text-2xl font-bold text-green-600">4.8</div>
              </div>
              <div className="text-sm text-gray-600">Average Rating</div>
            </CardContent>
          </Card>

          <Card className="hover:shadow-md transition-shadow">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="p-3 rounded-lg bg-orange-500 text-white">
                  <Trophy className="h-6 w-6" />
                </div>
                <div className="text-2xl font-bold text-orange-600">3</div>
              </div>
              <div className="text-sm text-gray-600">Packages Completed</div>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle>Active Learning Packages</CardTitle>
              <CardDescription>Your current certification package progress</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="p-4 bg-blue-50 rounded-lg">
                <div className="flex justify-between items-start mb-3">
                  <div>
                    <h3 className="font-semibold text-blue-900">Cloud Solutions Architect Bundle</h3>
                    <p className="text-sm text-blue-700">AWS + Azure + GCP</p>
                  </div>
                  <Badge className="bg-blue-100 text-blue-700">3/5 Complete</Badge>
                </div>
                <Progress value={60} className="h-2 mb-2" />
                <div className="text-sm text-blue-600">Next: GCP Professional Cloud Architect</div>
              </div>

              <div className="p-4 bg-green-50 rounded-lg">
                <div className="flex justify-between items-start mb-3">
                  <div>
                    <h3 className="font-semibold text-green-900">DevOps Engineer Complete</h3>
                    <p className="text-sm text-green-700">Docker + Kubernetes + CI/CD</p>
                  </div>
                  <Badge className="bg-green-100 text-green-700">2/4 Complete</Badge>
                </div>
                <Progress value={50} className="h-2 mb-2" />
                <div className="text-sm text-green-600">Next: Certified Kubernetes Administrator</div>
              </div>

              <div className="p-4 bg-purple-50 rounded-lg">
                <div className="flex justify-between items-start mb-3">
                  <div>
                    <h3 className="font-semibold text-purple-900">Data Science Mastery</h3>
                    <p className="text-sm text-purple-700">Python + ML + TensorFlow</p>
                  </div>
                  <Badge className="bg-purple-100 text-purple-700">1/3 Complete</Badge>
                </div>
                <Progress value={33} className="h-2 mb-2" />
                <div className="text-sm text-purple-600">Next: TensorFlow Developer Certificate</div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Package Learning Statistics</CardTitle>
              <CardDescription>Your package-based learning insights</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="text-center p-3 bg-blue-50 rounded-lg">
                  <div className="text-2xl font-bold text-blue-600">67%</div>
                  <div className="text-sm text-blue-700">Avg Completion Rate</div>
                </div>
                <div className="text-center p-3 bg-green-50 rounded-lg">
                  <div className="text-2xl font-bold text-green-600">4.2</div>
                  <div className="text-sm text-green-700">Months Avg Duration</div>
                </div>
                <div className="text-center p-3 bg-purple-50 rounded-lg">
                  <div className="text-2xl font-bold text-purple-600">8</div>
                  <div className="text-sm text-purple-700">Packages Started</div>
                </div>
                <div className="text-center p-3 bg-orange-50 rounded-lg">
                  <div className="text-2xl font-bold text-orange-600">3</div>
                  <div className="text-sm text-orange-700">Packages Completed</div>
                </div>
              </div>

              <div className="space-y-3">
                <div>
                  <div className="flex justify-between items-center mb-1">
                    <span className="text-sm font-medium">Study Consistency</span>
                    <span className="text-sm text-green-600">85%</span>
                  </div>
                  <Progress value={85} className="h-2" />
                </div>

                <div>
                  <div className="flex justify-between items-center mb-1">
                    <span className="text-sm font-medium">Package Retention</span>
                    <span className="text-sm text-blue-600">78%</span>
                  </div>
                  <Progress value={78} className="h-2" />
                </div>

                <div>
                  <div className="flex justify-between items-center mb-1">
                    <span className="text-sm font-medium">Time Efficiency</span>
                    <span className="text-sm text-purple-600">92%</span>
                  </div>
                  <Progress value={92} className="h-2" />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Recommended Learning Packages</CardTitle>
            <CardDescription>Curated certification bundles based on your career goals</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              <div className="p-4 border border-blue-200 rounded-lg hover:shadow-md transition-shadow">
                <div className="flex items-center gap-3 mb-3">
                  <div className="w-10 h-10 bg-blue-500 rounded-lg flex items-center justify-center">
                    <Trophy className="h-5 w-5 text-white" />
                  </div>
                  <div>
                    <h3 className="font-semibold">Full-Stack Developer Elite</h3>
                    <p className="text-sm text-gray-600">Frontend + Backend + Cloud</p>
                  </div>
                </div>
                <div className="space-y-2 mb-4">
                  <div className="flex justify-between text-sm">
                    <span>Certifications</span>
                    <span className="font-medium">6</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span>Duration</span>
                    <span className="font-medium">8-12 months</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span>Salary Impact</span>
                    <span className="font-medium text-green-600">+$32K</span>
                  </div>
                </div>
                <Button className="w-full bg-blue-600 hover:bg-blue-700">Start Package</Button>
              </div>

              <div className="p-4 border border-green-200 rounded-lg hover:shadow-md transition-shadow">
                <div className="flex items-center gap-3 mb-3">
                  <div className="w-10 h-10 bg-green-500 rounded-lg flex items-center justify-center">
                    <Trophy className="h-5 w-5 text-white" />
                  </div>
                  <div>
                    <h3 className="font-semibold">AI/ML Engineer Professional</h3>
                    <p className="text-sm text-gray-600">Machine Learning + Deep Learning</p>
                  </div>
                </div>
                <div className="space-y-2 mb-4">
                  <div className="flex justify-between text-sm">
                    <span>Certifications</span>
                    <span className="font-medium">4</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span>Duration</span>
                    <span className="font-medium">6-9 months</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span>Salary Impact</span>
                    <span className="font-medium text-green-600">+$45K</span>
                  </div>
                </div>
                <Button className="w-full bg-green-600 hover:bg-green-700">Start Package</Button>
              </div>

              <div className="p-4 border border-purple-200 rounded-lg hover:shadow-md transition-shadow">
                <div className="flex items-center gap-3 mb-3">
                  <div className="w-10 h-10 bg-purple-500 rounded-lg flex items-center justify-center">
                    <Trophy className="h-5 w-5 text-white" />
                  </div>
                  <div>
                    <h3 className="font-semibold">Cloud Security Expert</h3>
                    <p className="text-sm text-gray-600">Security + Cloud + Compliance</p>
                  </div>
                </div>
                <div className="space-y-2 mb-4">
                  <div className="flex justify-between text-sm">
                    <span>Certifications</span>
                    <span className="font-medium">5</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span>Duration</span>
                    <span className="font-medium">10-14 months</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span>Salary Impact</span>
                    <span className="font-medium text-green-600">+$38K</span>
                  </div>
                </div>
                <Button className="w-full bg-purple-600 hover:bg-purple-700">Start Package</Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </PlatformLayout>
  );
}