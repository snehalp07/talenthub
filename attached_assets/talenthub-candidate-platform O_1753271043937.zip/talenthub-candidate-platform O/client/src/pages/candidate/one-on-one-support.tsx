import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Calendar } from "@/components/ui/calendar";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { CalendarIcon, Clock, User, Video, MessageSquare, CheckCircle } from "lucide-react";
import { format } from "date-fns";
import { cn } from "@/lib/utils";
import PlatformLayout from "@/components/layout/platform-layout";
import { platformConfigs } from "@/config/complete-navigation";

function OneOnOneSupportContent() {
  const [selectedDate, setSelectedDate] = useState<Date>();
  const [selectedTime, setSelectedTime] = useState<string>();
  const [sessionType, setSessionType] = useState<string>();
  const [topic, setTopic] = useState("");
  const [description, setDescription] = useState("");

  const availableTimes = [
    "09:00", "10:00", "11:00", "14:00", "15:00", "16:00", "17:00"
  ];

  const sessionTypes = [
    { value: "career", label: "Career Guidance", description: "Get personalized career advice and planning" },
    { value: "interview", label: "Interview Prep", description: "Practice interviews and get feedback" },
    { value: "resume", label: "Resume Review", description: "Professional resume optimization" },
    { value: "skills", label: "Skills Assessment", description: "Identify and develop key skills" },
    { value: "technical", label: "Technical Support", description: "Platform help and troubleshooting" }
  ];

  const upcomingSessions = [
    {
      id: 1,
      type: "Career Guidance",
      date: "2025-06-15",
      time: "14:00",
      mentor: "Sarah Johnson",
      status: "confirmed"
    },
    {
      id: 2,
      type: "Interview Prep",
      date: "2025-06-20",
      time: "10:00",
      mentor: "Michael Chen",
      status: "pending"
    }
  ];

  const pastSessions = [
    {
      id: 1,
      type: "Resume Review",
      date: "2025-06-01",
      time: "15:00",
      mentor: "Lisa Brown",
      rating: 5,
      feedback: "Excellent session! Very helpful feedback on my resume structure."
    }
  ];

  return (
    <div className="container mx-auto px-4 py-8 space-y-8">
      {/* Header */}
      <div className="text-center">
        <h1 className="text-4xl font-bold bg-gradient-to-r from-sky-600 to-blue-600 bg-clip-text text-transparent mb-4">
          One-on-One Support
        </h1>
        <p className="text-lg text-gray-600 max-w-2xl mx-auto">
          Get personalized guidance from experienced mentors and career coaches
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Booking Form */}
        <div className="lg:col-span-2">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Calendar className="h-5 w-5 text-sky-600" />
                Book Your Session
              </CardTitle>
              <CardDescription>
                Schedule a personalized one-on-one session with our experts
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Session Type Selection */}
              <div className="space-y-3">
                <Label>Session Type</Label>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {sessionTypes.map((type) => (
                    <Card
                      key={type.value}
                      className={cn(
                        "cursor-pointer transition-all border-2",
                        sessionType === type.value
                          ? "border-sky-500 bg-sky-50"
                          : "border-gray-200 hover:border-sky-300"
                      )}
                      onClick={() => setSessionType(type.value)}
                    >
                      <CardContent className="p-4">
                        <h3 className="font-semibold text-sm">{type.label}</h3>
                        <p className="text-xs text-gray-600 mt-1">{type.description}</p>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>

              {/* Date Selection */}
              <div className="space-y-3">
                <Label>Select Date</Label>
                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      variant="outline"
                      className={cn(
                        "w-full justify-start text-left font-normal",
                        !selectedDate && "text-muted-foreground"
                      )}
                    >
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {selectedDate ? format(selectedDate, "PPP") : "Pick a date"}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0 z-50" align="start">
                    <Calendar
                      mode="single"
                      selected={selectedDate}
                      onSelect={setSelectedDate}
                      disabled={(date) => date < new Date()}
                      initialFocus
                    />
                  </PopoverContent>
                </Popover>
              </div>

              {/* Time Selection */}
              <div className="space-y-3">
                <Label>Select Time</Label>
                <div className="grid grid-cols-4 gap-2">
                  {availableTimes.map((time) => (
                    <Button
                      key={time}
                      variant={selectedTime === time ? "default" : "outline"}
                      size="sm"
                      onClick={() => setSelectedTime(time)}
                      className={selectedTime === time ? "bg-sky-600 hover:bg-sky-700" : ""}
                    >
                      {time}
                    </Button>
                  ))}
                </div>
              </div>

              {/* Topic and Description */}
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="topic">Session Topic</Label>
                  <Input
                    id="topic"
                    placeholder="What would you like to focus on?"
                    value={topic}
                    onChange={(e) => setTopic(e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="description">Additional Details</Label>
                  <Textarea
                    id="description"
                    placeholder="Provide any additional context or specific questions..."
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    rows={4}
                  />
                </div>
              </div>

              <Button 
                className="w-full bg-sky-600 hover:bg-sky-700"
                disabled={!sessionType || !selectedDate || !selectedTime}
              >
                Book Session
              </Button>
            </CardContent>
          </Card>
        </div>

        {/* Session Status */}
        <div className="space-y-6">
          {/* Upcoming Sessions */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Clock className="h-5 w-5 text-sky-600" />
                Upcoming Sessions
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {upcomingSessions.map((session) => (
                <div key={session.id} className="p-4 border rounded-lg">
                  <div className="flex justify-between items-start mb-2">
                    <h3 className="font-semibold text-sm">{session.type}</h3>
                    <Badge 
                      variant={session.status === "confirmed" ? "default" : "secondary"}
                      className={session.status === "confirmed" ? "bg-green-100 text-green-800" : ""}
                    >
                      {session.status}
                    </Badge>
                  </div>
                  <p className="text-sm text-gray-600 mb-1">
                    {format(new Date(session.date), "MMM dd, yyyy")} at {session.time}
                  </p>
                  <p className="text-sm text-gray-600 flex items-center gap-1">
                    <User className="h-3 w-3" />
                    {session.mentor}
                  </p>
                  <div className="flex gap-2 mt-3">
                    <Button size="sm" variant="outline" className="flex-1">
                      <Video className="h-3 w-3 mr-1" />
                      Join
                    </Button>
                    <Button size="sm" variant="outline" className="flex-1">
                      <MessageSquare className="h-3 w-3 mr-1" />
                      Chat
                    </Button>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>

          {/* Session History */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <CheckCircle className="h-5 w-5 text-sky-600" />
                Session History
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {pastSessions.map((session) => (
                <div key={session.id} className="p-4 border rounded-lg">
                  <h3 className="font-semibold text-sm mb-1">{session.type}</h3>
                  <p className="text-sm text-gray-600 mb-2">
                    {format(new Date(session.date), "MMM dd, yyyy")} with {session.mentor}
                  </p>
                  <div className="flex items-center gap-1 mb-2">
                    {[...Array(5)].map((_, i) => (
                      <div
                        key={i}
                        className={cn(
                          "w-3 h-3 rounded-full",
                          i < session.rating ? "bg-yellow-400" : "bg-gray-200"
                        )}
                      />
                    ))}
                  </div>
                  <p className="text-xs text-gray-600">{session.feedback}</p>
                </div>
              ))}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}

export default function OneOnOneSupport() {
  const config = platformConfigs.candidate;
  
  const usageData = [
    { label: "Support Sessions", current: 12, max: 25 },
    { label: "Monthly Credits", current: 8, max: 15 },
    { label: "Expert Consultations", current: 3, max: 5 },
  ];

  return (
    <PlatformLayout
      sidebarTitle={config.sidebarTitle}
      sidebarSubtitle={config.sidebarSubtitle}
      sidebarSections={config.sidebarSections}
      usageData={usageData}
    >
      <OneOnOneSupportContent />
    </PlatformLayout>
  );
}