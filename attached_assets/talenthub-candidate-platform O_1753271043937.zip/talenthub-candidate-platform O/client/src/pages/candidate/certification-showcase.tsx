import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import PlatformLayout from "@/components/layout/platform-layout";
import { candidateNavigation } from "@/config/complete-navigation";
import { 
  Award, Share2, Download, Eye, ExternalLink, Calendar,
  CheckCircle, Star, Trophy, Shield, Verified, Globe,
  Copy, Link, Mail, Users, Building, Code, Brain
} from "lucide-react";

const CertificationShowcase: React.FC = () => {
  const [selectedView, setSelectedView] = useState('portfolio');

  const certifications = [
    {
      id: 1,
      title: "Frontend Development Expert",
      category: "Technical",
      issuer: "TalentHub Certification",
      issuedDate: "2024-01-25",
      validUntil: "2026-01-25",
      credentialId: "FE-2024-001847",
      verified: true,
      skills: ["React", "JavaScript", "CSS", "TypeScript", "Testing"],
      score: 95,
      level: "Expert",
      shareUrl: "https://talenthub.com/verify/FE-2024-001847",
      publicProfile: true,
      downloadable: true
    },
    {
      id: 2,
      title: "Communication & Leadership",
      category: "Behavioral",
      issuer: "TalentHub Certification",
      issuedDate: "2024-01-20",
      validUntil: "2025-01-20",
      credentialId: "BH-2024-001523",
      verified: true,
      skills: ["Communication", "Leadership", "Team Management", "Problem Solving"],
      score: 92,
      level: "Advanced",
      shareUrl: "https://talenthub.com/verify/BH-2024-001523",
      publicProfile: true,
      downloadable: true
    },
    {
      id: 3,
      title: "System Design Fundamentals",
      category: "Architecture",
      issuer: "TalentHub Certification",
      issuedDate: "2024-01-15",
      validUntil: "2025-07-15",
      credentialId: "SD-2024-000892",
      verified: true,
      skills: ["System Design", "Scalability", "Database Design", "API Design"],
      score: 88,
      level: "Intermediate",
      shareUrl: "https://talenthub.com/verify/SD-2024-000892",
      publicProfile: false,
      downloadable: true
    }
  ];

  const profileStats = {
    totalCertifications: certifications.length,
    publicCertifications: certifications.filter(c => c.publicProfile).length,
    averageScore: Math.round(certifications.reduce((sum, c) => sum + c.score, 0) / certifications.length),
    profileViews: 247,
    credibilityScore: 98
  };

  const shareOptions = [
    { name: "LinkedIn", icon: Users, color: "bg-blue-600", action: "linkedin" },
    { name: "Email", icon: Mail, color: "bg-gray-600", action: "email" },
    { name: "Copy Link", icon: Copy, color: "bg-green-600", action: "copy" },
    { name: "Public Profile", icon: Globe, color: "bg-purple-600", action: "profile" }
  ];

  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'Technical': return 'text-blue-600 bg-blue-100';
      case 'Behavioral': return 'text-green-600 bg-green-100';
      case 'Architecture': return 'text-purple-600 bg-purple-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  const getLevelColor = (level: string) => {
    switch (level) {
      case 'Expert': return 'text-yellow-600 bg-yellow-100';
      case 'Advanced': return 'text-orange-600 bg-orange-100';
      case 'Intermediate': return 'text-blue-600 bg-blue-100';
      case 'Beginner': return 'text-gray-600 bg-gray-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  const handleShare = (certification: any, action: string) => {
    switch (action) {
      case 'linkedin':
        window.open(`https://linkedin.com/sharing/share-offsite/?url=${certification.shareUrl}`, '_blank');
        break;
      case 'email':
        window.open(`mailto:?subject=My ${certification.title} Certification&body=Check out my certification: ${certification.shareUrl}`);
        break;
      case 'copy':
        navigator.clipboard.writeText(certification.shareUrl);
        break;
      case 'profile':
        window.open(`/public-profile/certifications/${certification.id}`, '_blank');
        break;
    }
  };

  return (
    <PlatformLayout
      sidebarTitle="Candidate Platform"
      sidebarSubtitle="Interview Preparation"
      sidebarSections={candidateNavigation}
    >
      <div className="min-h-screen bg-gradient-to-br from-purple-50 via-white to-blue-50 p-6">
        <div className="max-w-7xl mx-auto space-y-8">
          {/* Header */}
          <div className="text-center space-y-4">
            <div className="inline-flex items-center space-x-2 bg-purple-100 text-purple-800 px-4 py-2 rounded-full text-sm font-medium">
              <Award className="h-4 w-4" />
              <span>Professional Certification Showcase</span>
            </div>
            <h1 className="text-4xl font-bold text-gray-900">Certification Portfolio</h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Share your verified certifications with employers and build professional credibility
            </p>
          </div>

          {/* Portfolio Stats */}
          <div className="grid grid-cols-1 md:grid-cols-5 gap-6">
            <Card className="bg-gradient-to-r from-purple-500 to-purple-600 text-white">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-purple-100">Certifications</p>
                    <p className="text-3xl font-bold">{profileStats.totalCertifications}</p>
                  </div>
                  <Award className="h-12 w-12 text-purple-200" />
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-r from-blue-500 to-blue-600 text-white">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-blue-100">Public Certs</p>
                    <p className="text-3xl font-bold">{profileStats.publicCertifications}</p>
                  </div>
                  <Globe className="h-12 w-12 text-blue-200" />
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-r from-green-500 to-green-600 text-white">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-green-100">Avg Score</p>
                    <p className="text-3xl font-bold">{profileStats.averageScore}%</p>
                  </div>
                  <Star className="h-12 w-12 text-green-200" />
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-r from-orange-500 to-orange-600 text-white">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-orange-100">Profile Views</p>
                    <p className="text-3xl font-bold">{profileStats.profileViews}</p>
                  </div>
                  <Eye className="h-12 w-12 text-orange-200" />
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-r from-yellow-500 to-yellow-600 text-white">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-yellow-100">Credibility</p>
                    <p className="text-3xl font-bold">{profileStats.credibilityScore}%</p>
                  </div>
                  <Shield className="h-12 w-12 text-yellow-200" />
                </div>
              </CardContent>
            </Card>
          </div>

          {/* View Toggle */}
          <Card>
            <CardHeader>
              <CardTitle>Portfolio Views</CardTitle>
              <CardDescription>Switch between different display formats</CardDescription>
            </CardHeader>
            <CardContent>
              <Tabs value={selectedView} onValueChange={setSelectedView}>
                <TabsList className="grid w-full grid-cols-3">
                  <TabsTrigger value="portfolio">Portfolio View</TabsTrigger>
                  <TabsTrigger value="compact">Compact List</TabsTrigger>
                  <TabsTrigger value="public">Public Preview</TabsTrigger>
                </TabsList>

                <TabsContent value="portfolio" className="mt-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {certifications.map((cert) => (
                      <Card key={cert.id} className="relative overflow-hidden hover:shadow-lg transition-all duration-300">
                        <div className="absolute top-4 right-4 flex space-x-2">
                          {cert.verified && (
                            <div className="p-1 bg-green-100 rounded-full">
                              <Verified className="h-4 w-4 text-green-600" />
                            </div>
                          )}
                          {cert.publicProfile && (
                            <div className="p-1 bg-blue-100 rounded-full">
                              <Globe className="h-4 w-4 text-blue-600" />
                            </div>
                          )}
                        </div>

                        <CardHeader className="pb-4">
                          <div className="space-y-2">
                            <Badge className={getCategoryColor(cert.category)}>
                              {cert.category}
                            </Badge>
                            <CardTitle className="text-lg">{cert.title}</CardTitle>
                            <p className="text-sm text-gray-600">{cert.issuer}</p>
                          </div>
                        </CardHeader>

                        <CardContent className="space-y-4">
                          <div className="grid grid-cols-2 gap-4 text-sm">
                            <div>
                              <p className="text-gray-500">Score</p>
                              <p className="font-semibold text-green-600">{cert.score}%</p>
                            </div>
                            <div>
                              <p className="text-gray-500">Level</p>
                              <Badge className={getLevelColor(cert.level)}>{cert.level}</Badge>
                            </div>
                          </div>

                          <div>
                            <p className="text-gray-500 text-sm mb-2">Skills Verified</p>
                            <div className="flex flex-wrap gap-1">
                              {cert.skills.map((skill, index) => (
                                <Badge key={index} variant="outline" className="text-xs">
                                  {skill}
                                </Badge>
                              ))}
                            </div>
                          </div>

                          <div className="pt-4 border-t">
                            <div className="flex justify-between text-xs text-gray-500 mb-2">
                              <span>Issued: {cert.issuedDate}</span>
                              <span>Valid until: {cert.validUntil}</span>
                            </div>
                            <p className="text-xs text-gray-400">ID: {cert.credentialId}</p>
                          </div>

                          <div className="flex space-x-2">
                            <Button size="sm" variant="outline" className="flex-1">
                              <Eye className="h-4 w-4 mr-1" />
                              View
                            </Button>
                            <Button size="sm" variant="outline" className="flex-1">
                              <Download className="h-4 w-4 mr-1" />
                              Download
                            </Button>
                            <Button size="sm" variant="outline" className="flex-1">
                              <Share2 className="h-4 w-4 mr-1" />
                              Share
                            </Button>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </TabsContent>

                <TabsContent value="compact" className="mt-6">
                  <div className="space-y-4">
                    {certifications.map((cert) => (
                      <Card key={cert.id} className="hover:shadow-md transition-shadow">
                        <CardContent className="p-6">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center space-x-4">
                              <div className="p-3 bg-purple-100 rounded-full">
                                <Award className="h-6 w-6 text-purple-600" />
                              </div>
                              <div>
                                <h3 className="font-semibold text-lg">{cert.title}</h3>
                                <p className="text-gray-600">{cert.issuer} • {cert.issuedDate}</p>
                                <div className="flex items-center space-x-2 mt-1">
                                  <Badge className={getCategoryColor(cert.category)}>
                                    {cert.category}
                                  </Badge>
                                  <Badge className={getLevelColor(cert.level)}>
                                    {cert.level}
                                  </Badge>
                                  {cert.verified && <Verified className="h-4 w-4 text-green-600" />}
                                </div>
                              </div>
                            </div>
                            <div className="text-right">
                              <div className="text-2xl font-bold text-green-600">{cert.score}%</div>
                              <div className="flex space-x-2 mt-2">
                                <Button size="sm" variant="outline">
                                  <Eye className="h-4 w-4" />
                                </Button>
                                <Button size="sm" variant="outline">
                                  <Download className="h-4 w-4" />
                                </Button>
                                <Button size="sm" variant="outline">
                                  <Share2 className="h-4 w-4" />
                                </Button>
                              </div>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </TabsContent>

                <TabsContent value="public" className="mt-6">
                  <Card className="bg-gradient-to-br from-blue-50 to-purple-50">
                    <CardHeader className="text-center">
                      <CardTitle className="text-2xl">Public Certification Profile</CardTitle>
                      <CardDescription>How employers and recruiters see your certifications</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-6">
                      <div className="text-center">
                        <div className="inline-flex items-center space-x-2 bg-green-100 text-green-800 px-4 py-2 rounded-full">
                          <Shield className="h-5 w-5" />
                          <span className="font-medium">Verified Professional</span>
                        </div>
                        <h2 className="text-xl font-bold mt-4">John Doe</h2>
                        <p className="text-gray-600">Frontend Developer & Technical Leader</p>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        {certifications.filter(c => c.publicProfile).map((cert) => (
                          <div key={cert.id} className="p-4 bg-white rounded-lg border">
                            <div className="flex items-center space-x-2 mb-2">
                              <Award className="h-5 w-5 text-purple-600" />
                              <h3 className="font-medium">{cert.title}</h3>
                            </div>
                            <p className="text-sm text-gray-600 mb-2">{cert.issuer}</p>
                            <div className="flex justify-between items-center">
                              <Badge className={getCategoryColor(cert.category)}>
                                {cert.category}
                              </Badge>
                              <span className="text-sm font-semibold text-green-600">{cert.score}%</span>
                            </div>
                          </div>
                        ))}
                      </div>

                      <div className="text-center">
                        <Button className="bg-purple-600 hover:bg-purple-700">
                          <ExternalLink className="h-4 w-4 mr-2" />
                          View Full Public Profile
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>

          {/* Sharing Options */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Share2 className="h-5 w-5" />
                  <span>Quick Share Options</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 gap-4">
                  {shareOptions.map((option) => (
                    <Button
                      key={option.action}
                      variant="outline"
                      className="h-auto p-4 flex flex-col items-center space-y-2"
                      onClick={() => handleShare(certifications[0], option.action)}
                    >
                      <div className={`p-2 rounded-full ${option.color}`}>
                        <option.icon className="h-5 w-5 text-white" />
                      </div>
                      <span className="text-sm">{option.name}</span>
                    </Button>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Building className="h-5 w-5" />
                  <span>Employer Benefits</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-center space-x-3 p-3 bg-blue-50 rounded-lg">
                  <CheckCircle className="h-5 w-5 text-blue-600" />
                  <div>
                    <div className="font-medium text-sm">Instant Verification</div>
                    <div className="text-xs text-gray-600">Employers can verify credentials immediately</div>
                  </div>
                </div>
                <div className="flex items-center space-x-3 p-3 bg-green-50 rounded-lg">
                  <Trophy className="h-5 w-5 text-green-600" />
                  <div>
                    <div className="font-medium text-sm">Skill Assessment</div>
                    <div className="text-xs text-gray-600">Detailed breakdown of technical abilities</div>
                  </div>
                </div>
                <div className="flex items-center space-x-3 p-3 bg-purple-50 rounded-lg">
                  <Brain className="h-5 w-5 text-purple-600" />
                  <div>
                    <div className="font-medium text-sm">Performance Metrics</div>
                    <div className="text-xs text-gray-600">Quantified interview and project scores</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </PlatformLayout>
  );
};

export default CertificationShowcase;