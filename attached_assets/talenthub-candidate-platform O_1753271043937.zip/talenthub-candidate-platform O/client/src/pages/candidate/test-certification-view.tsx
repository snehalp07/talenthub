import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import CertificateViewer from "@/components/certificate-viewer";
import { 
  ArrowLeft,
  CheckCircle,
  Clock,
  Target,
  Award,
  BarChart3,
  FileText,
  Download,
  Share2
} from "lucide-react";
import PlatformLayout from "@/components/layout/platform-layout";
import { platformConfigs } from "@/config/complete-navigation";

interface TestCertification {
  id: string;
  testTitle: string;
  certificationTitle: string;
  description: string;
  completedDate: string;
  score: number;
  passingScore: number;
  timeSpent: number;
  totalQuestions: number;
  correctAnswers: number;
  difficulty: string;
  skills: string[];
  certificate: any;
  testDetails: {
    duration: number;
    topics: string[];
    questionTypes: string[];
  };
}

function TestCertificationViewContent() {
  const [, setLocation] = useLocation();
  
  // Get certification ID from URL params
  const urlParams = new URLSearchParams(window.location.search);
  const certificationId = urlParams.get('id') || '1';

  const { data: certification, isLoading } = useQuery<TestCertification>({
    queryKey: [`/api/candidate/certifications/test/${certificationId}`]
  });

  // Mock data for development
  const mockCertification: TestCertification = {
    id: certificationId,
    testTitle: "Advanced JavaScript Fundamentals",
    certificationTitle: "JavaScript Expert Certification",
    description: "Comprehensive assessment covering advanced JavaScript concepts including ES6+, async programming, design patterns, and modern frameworks.",
    completedDate: "2024-06-10T14:30:00Z",
    score: 92,
    passingScore: 80,
    timeSpent: 45,
    totalQuestions: 50,
    correctAnswers: 46,
    difficulty: "Advanced",
    skills: ["JavaScript", "ES6+", "Async Programming", "Design Patterns", "Problem Solving"],
    testDetails: {
      duration: 60,
      topics: ["Variables & Scope", "Functions & Closures", "Promises & Async/Await", "Object-Oriented Programming", "Design Patterns"],
      questionTypes: ["Multiple Choice", "Code Analysis", "Problem Solving"]
    },
    certificate: {
      id: `cert-${certificationId}`,
      title: "JavaScript Expert Certification",
      description: "This certification validates expertise in advanced JavaScript programming concepts and best practices.",
      type: 'test',
      issuedDate: "2024-06-10T14:30:00Z",
      issuer: {
        name: "TalentHub Certification Authority",
        logo: "/api/placeholder/32/32",
        website: "https://talenthub.com"
      },
      recipient: {
        name: "Alex Johnson",
        email: "alex.johnson@email.com",
        id: "user-123"
      },
      skills: ["JavaScript", "ES6+", "Async Programming", "Design Patterns", "Problem Solving"],
      score: 92,
      passingScore: 80,
      credentialId: `TH-JS-${certificationId}-2024`,
      verificationUrl: `https://verify.talenthub.com/cert-${certificationId}`,
      status: 'active',
      metadata: {
        duration: "45 minutes",
        difficulty: "Advanced",
        topics: ["Variables & Scope", "Functions & Closures", "Promises & Async/Await", "OOP", "Design Patterns"],
        grade: "A"
      }
    }
  };

  const currentCertification = certification || mockCertification;

  if (isLoading) {
    return <div className="flex items-center justify-center h-64">Loading certification details...</div>;
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <Button
            variant="ghost"
            onClick={() => setLocation('/candidate/browse-certifications')}
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Certifications
          </Button>
          
          <div>
            <h1 className="text-3xl font-bold text-gray-900">{currentCertification.certificationTitle}</h1>
            <p className="text-gray-600">Test-based Certification</p>
          </div>
        </div>

        <div className="flex items-center space-x-2">
          <Button variant="outline">
            <Download className="w-4 h-4 mr-2" />
            Download
          </Button>
          <Button variant="outline">
            <Share2 className="w-4 h-4 mr-2" />
            Share
          </Button>
        </div>
      </div>

      <Tabs defaultValue="overview" className="space-y-4">
        <TabsList>
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="results">Test Results</TabsTrigger>
          <TabsTrigger value="certificate">Certificate</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          {/* Quick Stats */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Final Score</CardTitle>
                <Target className="h-4 w-4 text-green-600" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-green-600">{currentCertification.score}%</div>
                <p className="text-xs text-muted-foreground">
                  Pass: {currentCertification.passingScore}%
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Time Spent</CardTitle>
                <Clock className="h-4 w-4 text-blue-600" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{currentCertification.timeSpent}m</div>
                <p className="text-xs text-muted-foreground">
                  of {currentCertification.testDetails.duration}m allowed
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Correct Answers</CardTitle>
                <CheckCircle className="h-4 w-4 text-green-600" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">
                  {currentCertification.correctAnswers}/{currentCertification.totalQuestions}
                </div>
                <p className="text-xs text-muted-foreground">
                  {Math.round((currentCertification.correctAnswers / currentCertification.totalQuestions) * 100)}% accuracy
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Difficulty</CardTitle>
                <Award className="h-4 w-4 text-purple-600" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">{currentCertification.difficulty}</div>
                <p className="text-xs text-muted-foreground">
                  Certification level
                </p>
              </CardContent>
            </Card>
          </div>

          {/* Test Information */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Test Overview</CardTitle>
                <CardDescription>{currentCertification.testTitle}</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <h4 className="font-medium mb-2">Description</h4>
                  <p className="text-gray-600">{currentCertification.description}</p>
                </div>

                <div>
                  <h4 className="font-medium mb-2">Completion Details</h4>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-gray-600">Completed:</span>
                      <span>{new Date(currentCertification.completedDate).toLocaleDateString()}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Duration:</span>
                      <span>{currentCertification.testDetails.duration} minutes</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Questions:</span>
                      <span>{currentCertification.totalQuestions}</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Skills Validated</CardTitle>
                <CardDescription>Competencies demonstrated in this test</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex flex-wrap gap-2">
                  {currentCertification.skills.map((skill, index) => (
                    <Badge key={index} variant="secondary">
                      {skill}
                    </Badge>
                  ))}
                </div>

                <div>
                  <h4 className="font-medium mb-2">Topics Covered</h4>
                  <ul className="space-y-1 text-sm text-gray-600">
                    {currentCertification.testDetails.topics.map((topic, index) => (
                      <li key={index} className="flex items-center">
                        <CheckCircle className="w-3 h-3 text-green-600 mr-2" />
                        {topic}
                      </li>
                    ))}
                  </ul>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="results" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <BarChart3 className="w-5 h-5 mr-2" />
                Detailed Test Results
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Score Breakdown */}
              <div>
                <h3 className="font-medium mb-4">Performance Breakdown</h3>
                <div className="space-y-3">
                  {currentCertification.testDetails.topics.map((topic, index) => {
                    const scores = [95, 88, 92, 85, 90]; // Mock topic scores
                    const score = scores[index] || 85;
                    return (
                      <div key={index} className="flex items-center justify-between">
                        <span className="text-sm font-medium">{topic}</span>
                        <div className="flex items-center space-x-2">
                          <div className="w-32 bg-gray-200 rounded-full h-2">
                            <div 
                              className="bg-blue-600 h-2 rounded-full" 
                              style={{ width: `${score}%` }}
                            ></div>
                          </div>
                          <span className="text-sm font-medium w-8">{score}%</span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Question Types Performance */}
              <div>
                <h3 className="font-medium mb-4">Performance by Question Type</h3>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {currentCertification.testDetails.questionTypes.map((type, index) => {
                    const scores = [94, 90, 88]; // Mock scores by question type
                    const score = scores[index] || 85;
                    return (
                      <div key={index} className="text-center p-4 bg-gray-50 rounded-lg">
                        <div className="text-2xl font-bold text-blue-600">{score}%</div>
                        <div className="text-sm text-gray-600">{type}</div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Recommendations */}
              <div>
                <h3 className="font-medium mb-4">Recommendations</h3>
                <div className="space-y-2">
                  <div className="flex items-start space-x-2">
                    <CheckCircle className="w-4 h-4 text-green-600 mt-0.5" />
                    <p className="text-sm text-gray-600">
                      Excellent performance in JavaScript fundamentals and ES6+ features
                    </p>
                  </div>
                  <div className="flex items-start space-x-2">
                    <CheckCircle className="w-4 h-4 text-green-600 mt-0.5" />
                    <p className="text-sm text-gray-600">
                      Strong understanding of async programming and promises
                    </p>
                  </div>
                  <div className="flex items-start space-x-2">
                    <FileText className="w-4 h-4 text-blue-600 mt-0.5" />
                    <p className="text-sm text-gray-600">
                      Consider advancing to React or Node.js specialization tracks
                    </p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="certificate">
          <Card>
            <CardHeader>
              <CardTitle>Official Certificate</CardTitle>
              <CardDescription>Your verified certification document</CardDescription>
            </CardHeader>
            <CardContent>
              <CertificateViewer certificate={currentCertification.certificate} />
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}

export default function TestCertificationView() {
  const config = platformConfigs.candidate;
  
  const usageData = [
    { label: "Test Certifications", current: 9, max: 20 },
    { label: "Skills Verified", current: 16, max: 30 },
    { label: "Assessment Credits", current: 4, max: 10 },
  ];

  return (
    <PlatformLayout
      sidebarTitle={config.sidebarTitle}
      sidebarSubtitle={config.sidebarSubtitle}
      sidebarSections={config.sidebarSections}
      usageData={usageData}
    >
      <TestCertificationViewContent />
    </PlatformLayout>
  );
}