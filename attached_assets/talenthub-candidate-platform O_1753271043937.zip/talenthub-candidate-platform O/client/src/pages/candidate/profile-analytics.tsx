import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import PlatformLayout from "@/components/layout/platform-layout";
import { candidateNavigation } from "@/config/complete-navigation";
import { 
  Eye, Users, Video, FileText, Share, Heart,
  TrendingUp, BarChart3, MapPin, Calendar,
  ArrowUp, ArrowDown, Star, MessageCircle,
  Briefcase, Award, Globe, Clock, Zap,
  Target, Shield, ThumbsUp, Download
} from "lucide-react";

const ProfileAnalytics: React.FC = () => {
  const [timeRange, setTimeRange] = useState('30d');
  const [selectedMetric, setSelectedMetric] = useState('views');
  
  const profileMetrics = {
    totalViews: { value: 2847, change: +23, trend: 'up' },
    uniqueViewers: { value: 1923, change: +18, trend: 'up' },
    recruiterViews: { value: 467, change: +35, trend: 'up' },
    profileScore: { value: 92, change: +5, trend: 'up' }
  };

  const engagementData = [
    { type: 'Profile Views', count: 2847, color: 'from-blue-400 to-blue-600', icon: Eye },
    { type: 'Video CV Plays', count: 1234, color: 'from-purple-400 to-purple-600', icon: Video },
    { type: 'Document Downloads', count: 567, color: 'from-emerald-400 to-emerald-600', icon: Download },
    { type: 'Social Shares', count: 234, color: 'from-orange-400 to-orange-600', icon: Share },
    { type: 'Contact Requests', count: 89, color: 'from-pink-400 to-pink-600', icon: MessageCircle },
    { type: 'Endorsements', count: 156, color: 'from-cyan-400 to-cyan-600', icon: ThumbsUp }
  ];

  const audienceInsights = {
    demographics: [
      { category: 'Tech Recruiters', percentage: 34, color: 'bg-blue-500' },
      { category: 'Hiring Managers', percentage: 28, color: 'bg-purple-500' },
      { category: 'Senior Engineers', percentage: 22, color: 'bg-emerald-500' },
      { category: 'Startup Founders', percentage: 16, color: 'bg-orange-500' }
    ],
    locations: [
      { city: 'San Francisco', views: 678, percentage: 24 },
      { city: 'New York', views: 567, percentage: 20 },
      { city: 'Seattle', views: 445, percentage: 16 },
      { city: 'Austin', views: 334, percentage: 12 },
      { city: 'Boston', views: 289, percentage: 10 }
    ],
    companies: [
      { name: 'Google', views: 123, interest: 'High' },
      { name: 'Microsoft', views: 98, interest: 'High' },
      { name: 'Amazon', views: 87, interest: 'Medium' },
      { name: 'Meta', views: 76, interest: 'High' },
      { name: 'Netflix', views: 65, interest: 'Medium' }
    ]
  };

  const brandStrengthIndicators = [
    { metric: 'Professional Presence', score: 95, description: 'Complete profile with all sections filled' },
    { metric: 'Content Quality', score: 88, description: 'High-quality portfolio and descriptions' },
    { metric: 'Visual Appeal', score: 92, description: 'Professional photos and design elements' },
    { metric: 'Keyword Optimization', score: 85, description: 'Well-optimized for search discovery' },
    { metric: 'Social Proof', score: 78, description: 'Endorsements and recommendations' },
    { metric: 'Activity Level', score: 83, description: 'Regular updates and engagement' }
  ];

  const performanceInsights = [
    {
      title: 'Peak Viewing Hours',
      data: 'Tuesday-Thursday, 2-4 PM PST',
      insight: 'Schedule content updates during these high-traffic periods',
      color: 'from-blue-50 to-blue-100'
    },
    {
      title: 'Top Converting Content',
      data: 'React Portfolio Projects',
      insight: 'Projects generate 3x more recruiter engagement than certificates',
      color: 'from-emerald-50 to-emerald-100'
    },
    {
      title: 'Audience Growth Rate',
      data: '+23% month-over-month',
      insight: 'Consistent growth indicates strong personal brand momentum',
      color: 'from-purple-50 to-purple-100'
    }
  ];

  return (
    <PlatformLayout 
      sidebarTitle="Candidate Platform"
      sidebarSubtitle="Professional Development Hub"
      sidebarSections={candidateNavigation}
    >
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-purple-50 to-pink-50 p-6">
        {/* Header Section */}
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-2">
            <div className="p-2 bg-gradient-to-br from-purple-500 to-pink-600 rounded-lg text-white">
              <Eye className="h-6 w-6" />
            </div>
            <h1 className="text-3xl font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
              Profile & Brand Analytics
            </h1>
          </div>
          <p className="text-gray-600 text-lg">
            Comprehensive insights into your professional profile performance and brand visibility
          </p>
        </div>

        {/* Time Range Selector */}
        <div className="flex gap-2 mb-6">
          {['7d', '30d', '90d', '1y'].map((period) => (
            <Button
              key={period}
              variant={timeRange === period ? "default" : "outline"}
              size="sm"
              onClick={() => setTimeRange(period)}
              className={timeRange === period ? "bg-gradient-to-r from-purple-500 to-pink-600" : ""}
            >
              {period === '7d' ? '7 Days' : period === '30d' ? '30 Days' : period === '90d' ? '90 Days' : '1 Year'}
            </Button>
          ))}
        </div>

        {/* Key Metrics Overview */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {Object.entries(profileMetrics).map(([key, metric], index) => {
            const icons = [Eye, Users, Briefcase, Star];
            const IconComponent = icons[index];
            const colors = ['from-blue-500 to-blue-600', 'from-purple-500 to-purple-600', 'from-emerald-500 to-emerald-600', 'from-orange-500 to-orange-600'];
            
            return (
              <Card key={key} className="border-0 shadow-lg bg-white/80 backdrop-blur-sm">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between mb-4">
                    <div className={`p-3 bg-gradient-to-br ${colors[index]} rounded-lg text-white`}>
                      <IconComponent className="h-6 w-6" />
                    </div>
                    <div className={`flex items-center gap-1 px-2 py-1 rounded-full text-sm ${
                      metric.trend === 'up' ? 'bg-emerald-100 text-emerald-700' : 'bg-red-100 text-red-700'
                    }`}>
                      {metric.trend === 'up' ? <ArrowUp className="h-3 w-3" /> : <ArrowDown className="h-3 w-3" />}
                      {metric.change}
                    </div>
                  </div>
                  <div className="text-2xl font-bold text-gray-900 mb-1">
                    {typeof metric.value === 'number' ? metric.value.toLocaleString() : metric.value}
                  </div>
                  <div className="text-sm text-gray-600 capitalize">
                    {key.replace(/([A-Z])/g, ' $1').toLowerCase()}
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>

        <Tabs defaultValue="overview" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4 bg-white/80 backdrop-blur-sm">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="engagement">Engagement</TabsTrigger>
            <TabsTrigger value="audience">Audience</TabsTrigger>
            <TabsTrigger value="optimization">Optimization</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6">
            {/* Brand Strength Analysis */}
            <Card className="border-0 shadow-lg bg-white/80 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Shield className="h-5 w-5 text-purple-500" />
                  Professional Brand Strength
                </CardTitle>
                <CardDescription>
                  Comprehensive assessment of your professional brand components
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  {brandStrengthIndicators.map((indicator, index) => (
                    <div key={index} className="space-y-3">
                      <div className="flex items-center justify-between">
                        <div>
                          <div className="font-semibold text-gray-900">{indicator.metric}</div>
                          <div className="text-sm text-gray-600">{indicator.description}</div>
                        </div>
                        <div className="text-lg font-bold text-purple-600">{indicator.score}%</div>
                      </div>
                      <Progress value={indicator.score} className="h-3 bg-gray-200">
                        <div className="h-full bg-gradient-to-r from-purple-400 to-pink-600 rounded-full transition-all duration-500" 
                             style={{ width: `${indicator.score}%` }} />
                      </Progress>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Performance Insights */}
            <Card className="border-0 shadow-lg bg-white/80 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Zap className="h-5 w-5 text-yellow-500" />
                  Key Performance Insights
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {performanceInsights.map((insight, index) => (
                    <div key={index} className={`p-6 bg-gradient-to-r ${insight.color} rounded-lg border border-gray-200`}>
                      <div className="font-semibold text-gray-900 mb-2">{insight.title}</div>
                      <div className="text-lg font-bold text-gray-800 mb-2">{insight.data}</div>
                      <div className="text-sm text-gray-700">{insight.insight}</div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="engagement" className="space-y-6">
            <Card className="border-0 shadow-lg bg-white/80 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <BarChart3 className="h-5 w-5 text-blue-500" />
                  Engagement Metrics Dashboard
                </CardTitle>
                <CardDescription>
                  Detailed breakdown of profile interactions and content performance
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {engagementData.map((item, index) => {
                    const IconComponent = item.icon;
                    return (
                      <div key={index} className="p-6 bg-gradient-to-br from-gray-50 to-gray-100 rounded-lg">
                        <div className="flex items-center gap-3 mb-4">
                          <div className={`p-3 bg-gradient-to-r ${item.color} rounded-lg text-white`}>
                            <IconComponent className="h-6 w-6" />
                          </div>
                          <div className="font-semibold text-gray-900">{item.type}</div>
                        </div>
                        <div className="text-2xl font-bold text-gray-900 mb-2">{item.count.toLocaleString()}</div>
                        <div className="w-full bg-gray-200 rounded-full h-2">
                          <div className={`h-2 bg-gradient-to-r ${item.color} rounded-full transition-all duration-500`} 
                               style={{ width: `${Math.min((item.count / Math.max(...engagementData.map(d => d.count))) * 100, 100)}%` }} />
                        </div>
                      </div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>

            {/* Engagement Timeline */}
            <Card className="border-0 shadow-lg bg-white/80 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Calendar className="h-5 w-5 text-emerald-500" />
                  Engagement Timeline & Patterns
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  <div className="p-6 bg-gradient-to-r from-blue-50 to-indigo-100 rounded-lg">
                    <div className="font-semibold text-blue-900 mb-4">Weekly Engagement Pattern</div>
                    <div className="grid grid-cols-7 gap-2">
                      {['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'].map((day, index) => {
                        const values = [65, 85, 92, 88, 73, 45, 38];
                        return (
                          <div key={day} className="text-center">
                            <div className="text-xs text-blue-700 mb-1">{day}</div>
                            <div className="h-16 bg-white rounded flex items-end justify-center">
                              <div 
                                className="w-6 bg-gradient-to-t from-blue-400 to-blue-600 rounded-t"
                                style={{ height: `${values[index]}%` }}
                              />
                            </div>
                            <div className="text-xs text-blue-600 mt-1">{values[index]}%</div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="audience" className="space-y-6">
            {/* Audience Demographics */}
            <Card className="border-0 shadow-lg bg-white/80 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Users className="h-5 w-5 text-emerald-500" />
                  Audience Demographics & Insights
                </CardTitle>
                <CardDescription>
                  Understanding who's viewing your profile and their engagement patterns
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                  {/* Viewer Types */}
                  <div>
                    <div className="font-semibold text-gray-900 mb-4">Viewer Categories</div>
                    <div className="space-y-4">
                      {audienceInsights.demographics.map((demo, index) => (
                        <div key={index} className="flex items-center gap-4">
                          <div className="flex-1">
                            <div className="flex items-center justify-between mb-1">
                              <span className="text-sm font-medium text-gray-900">{demo.category}</span>
                              <span className="text-sm text-gray-600">{demo.percentage}%</span>
                            </div>
                            <div className="w-full bg-gray-200 rounded-full h-2">
                              <div className={`h-2 ${demo.color} rounded-full transition-all duration-500`} 
                                   style={{ width: `${demo.percentage}%` }} />
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Geographic Distribution */}
                  <div>
                    <div className="font-semibold text-gray-900 mb-4">Top Viewing Locations</div>
                    <div className="space-y-3">
                      {audienceInsights.locations.map((location, index) => (
                        <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                          <div className="flex items-center gap-3">
                            <MapPin className="h-4 w-4 text-gray-500" />
                            <span className="font-medium text-gray-900">{location.city}</span>
                          </div>
                          <div className="text-right">
                            <div className="text-sm font-bold text-gray-900">{location.views}</div>
                            <div className="text-xs text-gray-600">{location.percentage}%</div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Company Interest */}
            <Card className="border-0 shadow-lg bg-white/80 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Briefcase className="h-5 w-5 text-blue-500" />
                  Company Interest Analysis
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {audienceInsights.companies.map((company, index) => (
                    <div key={index} className="flex items-center justify-between p-4 bg-gradient-to-r from-gray-50 to-gray-100 rounded-lg">
                      <div className="flex items-center gap-4">
                        <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-purple-600 rounded-lg flex items-center justify-center text-white font-bold">
                          {company.name.charAt(0)}
                        </div>
                        <div>
                          <div className="font-semibold text-gray-900">{company.name}</div>
                          <div className="text-sm text-gray-600">{company.views} profile views</div>
                        </div>
                      </div>
                      <Badge className={`${
                        company.interest === 'High' ? 'bg-emerald-600' : 'bg-yellow-600'
                      } text-white`}>
                        {company.interest} Interest
                      </Badge>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="optimization" className="space-y-6">
            <Card className="border-0 shadow-lg bg-white/80 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Target className="h-5 w-5 text-orange-500" />
                  Profile Optimization Recommendations
                </CardTitle>
                <CardDescription>
                  AI-powered suggestions to improve your profile visibility and engagement
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  <div className="p-6 bg-gradient-to-r from-emerald-50 to-green-100 rounded-lg border border-emerald-200">
                    <div className="flex items-start gap-4">
                      <div className="p-2 bg-emerald-500 rounded-lg">
                        <TrendingUp className="h-5 w-5 text-white" />
                      </div>
                      <div>
                        <div className="font-semibold text-emerald-900 mb-2">High Impact Optimization</div>
                        <div className="text-emerald-800 mb-3">
                          Add a professional video introduction to increase profile engagement by an estimated 40%. 
                          Video profiles receive significantly more recruiter attention.
                        </div>
                        <div className="flex gap-2">
                          <Badge className="bg-emerald-600 text-white">+40% Engagement</Badge>
                          <Badge variant="outline" className="text-emerald-600 border-emerald-300">15-min setup</Badge>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="p-6 bg-gradient-to-r from-blue-50 to-indigo-100 rounded-lg border border-blue-200">
                    <div className="flex items-start gap-4">
                      <div className="p-2 bg-blue-500 rounded-lg">
                        <Globe className="h-5 w-5 text-white" />
                      </div>
                      <div>
                        <div className="font-semibold text-blue-900 mb-2">SEO Enhancement</div>
                        <div className="text-blue-800 mb-3">
                          Optimize your profile with trending keywords: "React Developer", "Full-Stack Engineer", 
                          "TypeScript Expert" to improve discovery by 25%.
                        </div>
                        <div className="flex gap-2">
                          <Badge className="bg-blue-600 text-white">+25% Discovery</Badge>
                          <Badge variant="outline" className="text-blue-600 border-blue-300">Quick fix</Badge>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="p-6 bg-gradient-to-r from-purple-50 to-violet-100 rounded-lg border border-purple-200">
                    <div className="flex items-start gap-4">
                      <div className="p-2 bg-purple-500 rounded-lg">
                        <Clock className="h-5 w-5 text-white" />
                      </div>
                      <div>
                        <div className="font-semibold text-purple-900 mb-2">Timing Optimization</div>
                        <div className="text-purple-800 mb-3">
                          Post updates on Tuesday-Thursday between 2-4 PM PST for maximum visibility. 
                          This aligns with peak recruiter activity periods.
                        </div>
                        <div className="flex gap-2">
                          <Badge className="bg-purple-600 text-white">Optimal Timing</Badge>
                          <Badge variant="outline" className="text-purple-600 border-purple-300">Schedule posts</Badge>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </PlatformLayout>
  );
};

export default ProfileAnalytics;