import PlatformLayout from "@/components/layout/platform-layout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Progress } from "@/components/ui/progress";
import { RotateCcw, Users, Star, Calendar, Search, Filter, Clock, Target, Award, TrendingUp, ChevronRight, MessageSquare, Video, Coffee, BookOpen, Code, Zap } from "lucide-react";
import { platformConfigs } from "@/config/complete-navigation";

export default function SkillExchanges() {
  const config = platformConfigs.candidate;
  const skillOffers = [
    {
      id: 1,
      user: "Alex Chen",
      userImage: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&h=150&fit=crop&crop=face",
      skillOffered: "React Development",
      skillWanted: "UI/UX Design",
      experience: "5 years",
      rating: 4.9,
      sessions: 45,
      description: "Expert in modern React patterns, hooks, and state management. Looking to learn design principles.",
      availability: "Weekends",
      format: "Video Call",
      duration: "1-2 hours",
      featured: true,
      tags: ["Frontend", "JavaScript", "Redux"]
    },
    {
      id: 2,
      user: "Sarah Kim",
      userImage: "https://images.unsplash.com/photo-1494790108755-2616b612b786?w=150&h=150&fit=crop&crop=face",
      skillOffered: "Data Science",
      skillWanted: "DevOps",
      experience: "4 years",
      rating: 4.8,
      sessions: 32,
      description: "Python expert with ML experience. Want to learn Docker, Kubernetes, and CI/CD practices.",
      availability: "Evenings",
      format: "In-person + Virtual",
      duration: "2-3 hours",
      featured: false,
      tags: ["Python", "Machine Learning", "Analytics"]
    },
    {
      id: 3,
      user: "Maria Rodriguez",
      userImage: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=150&h=150&fit=crop&crop=face",
      skillOffered: "Product Management",
      skillWanted: "Technical Writing",
      experience: "6 years",
      rating: 4.9,
      sessions: 67,
      description: "Strategic product thinking and user research expertise. Looking to improve technical documentation skills.",
      availability: "Flexible",
      format: "Video Call",
      duration: "1 hour",
      featured: true,
      tags: ["Strategy", "User Research", "Analytics"]
    }
  ];

  const myExchanges = [
    {
      id: 1,
      partner: "David Park",
      partnerImage: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&h=150&fit=crop&crop=face",
      teachingSkill: "JavaScript",
      learningSkill: "System Design",
      progress: 75,
      sessionsCompleted: 6,
      totalSessions: 8,
      nextSession: "June 26, 2025 at 3:00 PM",
      status: "Active"
    },
    {
      id: 2,
      partner: "Emily Chen",
      partnerImage: "https://images.unsplash.com/photo-1580489944761-15a19d654956?w=150&h=150&fit=crop&crop=face",
      teachingSkill: "Project Management",
      learningSkill: "React Native",
      progress: 40,
      sessionsCompleted: 3,
      totalSessions: 10,
      nextSession: "June 28, 2025 at 7:00 PM",
      status: "Active"
    }
  ];

  const skillCategories = [
    { name: "Frontend Development", offers: 45, requests: 38, color: "bg-blue-500", icon: Code },
    { name: "Backend Development", offers: 32, requests: 42, color: "bg-green-500", icon: Target },
    { name: "Data Science", offers: 28, requests: 35, color: "bg-purple-500", icon: TrendingUp },
    { name: "Design", offers: 25, requests: 48, color: "bg-pink-500", icon: Award },
    { name: "Product Management", offers: 18, requests: 25, color: "bg-orange-500", icon: Users },
    { name: "DevOps", offers: 15, requests: 32, color: "bg-indigo-500", icon: Zap }
  ];

  const successStories = [
    {
      participants: ["John Doe", "Jane Smith"],
      exchange: "React ↔ Design Systems",
      outcome: "Both landed senior roles at tech companies",
      duration: "3 months",
      rating: 5
    },
    {
      participants: ["Mike Johnson", "Lisa Wang"],
      exchange: "Data Science ↔ Product Strategy",
      outcome: "Launched successful ML product feature",
      duration: "2 months",
      rating: 5
    },
    {
      participants: ["Tom Brown", "Amy Lee"],
      exchange: "Backend ↔ Mobile Development",
      outcome: "Built full-stack mobile app together",
      duration: "4 months",
      rating: 4.8
    }
  ];

  return (
    <PlatformLayout
      sidebarTitle={config.sidebarTitle}
      sidebarSubtitle={config.sidebarSubtitle}
      sidebarSections={config.sidebarSections}
      usageData={config.usageData}
    >
      <div className="p-6 max-w-7xl mx-auto space-y-6">
      {/* Header */}
      <div className="text-center space-y-4">
        <div className="flex items-center justify-center space-x-3">
          <div className="p-3 bg-gradient-to-r from-cyan-500 to-blue-500 rounded-full">
            <RotateCcw className="h-8 w-8 text-white" />
          </div>
          <h1 className="text-4xl font-bold bg-gradient-to-r from-cyan-600 to-blue-600 bg-clip-text text-transparent">
            Skill Exchanges
          </h1>
        </div>
        <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
          Trade skills with peers, learn new technologies, and build meaningful professional relationships
        </p>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="bg-gradient-to-r from-cyan-50 to-blue-50 border-cyan-200">
          <CardContent className="p-4 text-center">
            <RotateCcw className="h-8 w-8 text-cyan-500 mx-auto mb-2" />
            <p className="text-2xl font-bold text-cyan-600">850+</p>
            <p className="text-sm text-muted-foreground">Active Exchanges</p>
          </CardContent>
        </Card>
        <Card className="bg-gradient-to-r from-green-50 to-emerald-50 border-green-200">
          <CardContent className="p-4 text-center">
            <Users className="h-8 w-8 text-green-500 mx-auto mb-2" />
            <p className="text-2xl font-bold text-green-600">1,200+</p>
            <p className="text-sm text-muted-foreground">Participants</p>
          </CardContent>
        </Card>
        <Card className="bg-gradient-to-r from-purple-50 to-pink-50 border-purple-200">
          <CardContent className="p-4 text-center">
            <Award className="h-8 w-8 text-purple-500 mx-auto mb-2" />
            <p className="text-2xl font-bold text-purple-600">95%</p>
            <p className="text-sm text-muted-foreground">Success Rate</p>
          </CardContent>
        </Card>
        <Card className="bg-gradient-to-r from-orange-50 to-red-50 border-orange-200">
          <CardContent className="p-4 text-center">
            <Star className="h-8 w-8 text-orange-500 mx-auto mb-2" />
            <p className="text-2xl font-bold text-orange-600">4.9</p>
            <p className="text-sm text-muted-foreground">Average Rating</p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="browse" className="space-y-6">
        <TabsList className="grid w-full grid-cols-4 bg-cyan-100">
          <TabsTrigger value="browse" className="data-[state=active]:bg-cyan-500 data-[state=active]:text-white">
            Browse Exchanges
          </TabsTrigger>
          <TabsTrigger value="my-exchanges" className="data-[state=active]:bg-cyan-500 data-[state=active]:text-white">
            My Exchanges
          </TabsTrigger>
          <TabsTrigger value="offer-skill" className="data-[state=active]:bg-cyan-500 data-[state=active]:text-white">
            Offer Skill
          </TabsTrigger>
          <TabsTrigger value="success-stories" className="data-[state=active]:bg-cyan-500 data-[state=active]:text-white">
            Success Stories
          </TabsTrigger>
        </TabsList>

        <TabsContent value="browse" className="space-y-6">
          {/* Search and Filter */}
          <Card className="bg-gradient-to-r from-cyan-50 to-blue-50 border-cyan-200">
            <CardContent className="p-6">
              <div className="flex flex-col md:flex-row gap-4">
                <div className="flex-1 relative">
                  <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                  <Input placeholder="Search by skill offered or wanted..." className="pl-10 bg-white" />
                </div>
                <div className="flex gap-2">
                  <Button variant="outline" className="border-cyan-300 hover:bg-cyan-50">
                    <Filter className="h-4 w-4 mr-2" />
                    Filter
                  </Button>
                  <Button variant="outline" className="border-cyan-300 hover:bg-cyan-50">
                    <Star className="h-4 w-4 mr-2" />
                    Top Rated
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Skill Categories */}
          <div className="space-y-4">
            <h2 className="text-2xl font-bold text-cyan-700">Popular Skill Categories</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {skillCategories.map((category) => {
                const IconComponent = category.icon;
                return (
                  <Card key={category.name} className="group hover:shadow-lg transition-all duration-300 cursor-pointer">
                    <CardContent className="p-4">
                      <div className="flex items-center space-x-4">
                        <div className={`w-12 h-12 ${category.color} rounded-full flex items-center justify-center group-hover:scale-110 transition-transform`}>
                          <IconComponent className="h-6 w-6 text-white" />
                        </div>
                        <div className="flex-1">
                          <h3 className="font-semibold group-hover:text-cyan-600 transition-colors">
                            {category.name}
                          </h3>
                          <div className="flex justify-between text-sm text-muted-foreground">
                            <span>{category.offers} offering</span>
                            <span>{category.requests} seeking</span>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </div>

          {/* Available Exchanges */}
          <div className="space-y-4">
            <h2 className="text-2xl font-bold text-cyan-700">Available Skill Exchanges</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {skillOffers.map((offer) => (
                <Card key={offer.id} className="group hover:shadow-lg transition-all duration-300 border-l-4 border-l-cyan-500">
                  <CardHeader className="pb-4">
                    <div className="flex items-start gap-4">
                      <Avatar className="h-12 w-12">
                        <AvatarImage src={offer.userImage} alt={offer.user} />
                        <AvatarFallback>{offer.user.split(' ').map(n => n[0]).join('')}</AvatarFallback>
                      </Avatar>
                      <div className="flex-1">
                        <div className="flex justify-between items-start">
                          <div>
                            <CardTitle className="text-lg group-hover:text-cyan-600 transition-colors">
                              {offer.user}
                            </CardTitle>
                            <p className="text-sm text-muted-foreground">{offer.experience} experience</p>
                            <div className="flex items-center gap-1 mt-1">
                              <Star className="h-4 w-4 text-yellow-400 fill-current" />
                              <span className="text-sm font-medium">{offer.rating}</span>
                              <span className="text-xs text-muted-foreground">({offer.sessions} sessions)</span>
                            </div>
                          </div>
                          {offer.featured && (
                            <Badge className="bg-gradient-to-r from-yellow-400 to-orange-500 text-white">
                              <Star className="h-3 w-3 mr-1" />
                              Featured
                            </Badge>
                          )}
                        </div>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-medium text-green-600">Offering:</span>
                        <Badge className="bg-green-100 text-green-700">{offer.skillOffered}</Badge>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-medium text-blue-600">Seeking:</span>
                        <Badge className="bg-blue-100 text-blue-700">{offer.skillWanted}</Badge>
                      </div>
                    </div>

                    <p className="text-sm text-muted-foreground">{offer.description}</p>

                    <div className="flex flex-wrap gap-1">
                      {offer.tags.map((tag) => (
                        <Badge key={tag} variant="secondary" className="text-xs bg-cyan-100 text-cyan-700">
                          {tag}
                        </Badge>
                      ))}
                    </div>

                    <div className="grid grid-cols-2 gap-4 text-xs text-muted-foreground">
                      <div>
                        <Clock className="h-3 w-3 inline mr-1" />
                        {offer.duration}
                      </div>
                      <div>
                        <Calendar className="h-3 w-3 inline mr-1" />
                        {offer.availability}
                      </div>
                    </div>

                    <div className="flex gap-2 pt-2 border-t">
                      <Button variant="outline" size="sm" className="flex-1">
                        <MessageSquare className="h-4 w-4 mr-2" />
                        Message
                      </Button>
                      <Button size="sm" className="flex-1 bg-gradient-to-r from-cyan-500 to-blue-500 hover:from-cyan-600 hover:to-blue-600">
                        Exchange
                        <ChevronRight className="h-4 w-4 ml-1" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </TabsContent>

        <TabsContent value="my-exchanges" className="space-y-6">
          <h2 className="text-2xl font-bold text-cyan-700">My Active Exchanges</h2>
          
          <div className="space-y-4">
            {myExchanges.map((exchange) => (
              <Card key={exchange.id} className="border-l-4 border-l-cyan-500">
                <CardContent className="p-6">
                  <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                    <div className="lg:col-span-2 space-y-4">
                      <div className="flex items-center gap-4">
                        <Avatar className="h-12 w-12">
                          <AvatarImage src={exchange.partnerImage} alt={exchange.partner} />
                          <AvatarFallback>{exchange.partner.split(' ').map(n => n[0]).join('')}</AvatarFallback>
                        </Avatar>
                        <div>
                          <h3 className="text-lg font-semibold">Exchange with {exchange.partner}</h3>
                          <div className="flex items-center gap-4 text-sm">
                            <span className="text-green-600">Teaching: {exchange.teachingSkill}</span>
                            <span className="text-blue-600">Learning: {exchange.learningSkill}</span>
                          </div>
                        </div>
                      </div>
                      
                      <div className="space-y-2">
                        <div className="flex justify-between text-sm">
                          <span>Progress</span>
                          <span>{exchange.progress}% ({exchange.sessionsCompleted}/{exchange.totalSessions} sessions)</span>
                        </div>
                        <Progress value={exchange.progress} className="h-2" />
                      </div>

                      <div className="text-sm">
                        <p className="text-muted-foreground">Next Session</p>
                        <p className="font-medium">{exchange.nextSession}</p>
                      </div>
                    </div>

                    <div className="space-y-4">
                      <Badge 
                        variant={exchange.status === 'Active' ? 'default' : 'secondary'}
                        className={exchange.status === 'Active' ? 'bg-green-500' : ''}
                      >
                        {exchange.status}
                      </Badge>
                      
                      <div className="flex gap-2">
                        <Button variant="outline" size="sm" className="flex-1">
                          <MessageSquare className="h-4 w-4 mr-2" />
                          Chat
                        </Button>
                        <Button size="sm" className="flex-1 bg-gradient-to-r from-cyan-500 to-blue-500">
                          <Video className="h-4 w-4 mr-2" />
                          Join
                        </Button>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="offer-skill" className="space-y-6">
          <div className="max-w-2xl mx-auto">
            <Card className="border-cyan-200">
              <CardHeader className="text-center">
                <CardTitle className="text-2xl text-cyan-700">Offer Your Skills</CardTitle>
                <CardDescription>Share your expertise and learn something new in return</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium mb-2">Skill You're Offering</label>
                    <Input placeholder="e.g., React Development" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2">Skill You Want to Learn</label>
                    <Input placeholder="e.g., UI/UX Design" />
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2">Description</label>
                  <Input placeholder="Describe your expertise and what you'd like to learn..." />
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium mb-2">Experience Level</label>
                    <Input placeholder="e.g., 3 years" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2">Availability</label>
                    <Input placeholder="e.g., Weekends" />
                  </div>
                </div>
                <Button className="w-full bg-gradient-to-r from-cyan-500 to-blue-500 hover:from-cyan-600 hover:to-blue-600">
                  Create Exchange Offer
                </Button>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="success-stories" className="space-y-6">
          <h2 className="text-2xl font-bold text-cyan-700">Success Stories</h2>
          
          <div className="space-y-4">
            {successStories.map((story, index) => (
              <Card key={index} className="border-l-4 border-l-cyan-500">
                <CardContent className="p-6">
                  <div className="flex justify-between items-start">
                    <div className="space-y-2">
                      <h3 className="text-lg font-semibold">
                        {story.participants[0]} ↔ {story.participants[1]}
                      </h3>
                      <p className="text-sm text-cyan-600 font-medium">{story.exchange}</p>
                      <p className="text-muted-foreground">{story.outcome}</p>
                      <div className="flex items-center gap-4 text-sm text-muted-foreground">
                        <span>Duration: {story.duration}</span>
                        <div className="flex items-center gap-1">
                          <Star className="h-4 w-4 text-yellow-400 fill-current" />
                          <span>{story.rating}/5</span>
                        </div>
                      </div>
                    </div>
                    <Badge className="bg-green-100 text-green-700">Success</Badge>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>
      </Tabs>
      </div>
    </PlatformLayout>
  );
}