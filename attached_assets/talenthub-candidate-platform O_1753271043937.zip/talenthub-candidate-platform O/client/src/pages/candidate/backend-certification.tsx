import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import PlatformLayout from "@/components/layout/platform-layout";
import { candidateNavigation } from "@/config/complete-navigation";
import { 
  Server, Play, CheckCircle, Award, Target, TrendingUp, 
  Star, Clock, Code, Users, Zap, BookOpen, Trophy,
  ArrowRight, Database, Shield, Globe
} from "lucide-react";

const BackendCertification: React.FC = () => {
  const [selectedTrack, setSelectedTrack] = useState('nodejs');

  const certificationTracks = [
    {
      id: 'nodejs',
      name: 'Node.js Developer',
      icon: Server,
      color: 'from-green-500 to-emerald-500',
      level: 'Foundation → Expert',
      duration: '10-14 weeks',
      enrolled: 18750,
      completion: 72,
      rating: 4.9,
      modules: [
        { name: 'JavaScript ES6+ Mastery', status: 'completed', progress: 100, duration: '2 weeks' },
        { name: 'Node.js Fundamentals', status: 'completed', progress: 100, duration: '2 weeks' },
        { name: 'Express.js & Middleware', status: 'current', progress: 85, duration: '2.5 weeks' },
        { name: 'Database Integration', status: 'locked', progress: 0, duration: '2 weeks' },
        { name: 'Authentication & Security', status: 'locked', progress: 0, duration: '2 weeks' },
        { name: 'API Design & Testing', status: 'locked', progress: 0, duration: '2.5 weeks' }
      ]
    },
    {
      id: 'python',
      name: 'Python Developer',
      icon: Code,
      color: 'from-yellow-500 to-orange-500',
      level: 'Foundation → Expert',
      duration: '8-12 weeks',
      enrolled: 22340,
      completion: 45,
      rating: 4.8,
      modules: [
        { name: 'Python Core Concepts', status: 'completed', progress: 100, duration: '2 weeks' },
        { name: 'Object-Oriented Programming', status: 'current', progress: 60, duration: '2 weeks' },
        { name: 'Django Framework', status: 'locked', progress: 0, duration: '3 weeks' },
        { name: 'Flask & Microservices', status: 'locked', progress: 0, duration: '2 weeks' },
        { name: 'Database & ORM', status: 'locked', progress: 0, duration: '1.5 weeks' },
        { name: 'Testing & Deployment', status: 'locked', progress: 0, duration: '2 weeks' }
      ]
    },
    {
      id: 'java',
      name: 'Java Developer',
      icon: Code,
      color: 'from-blue-500 to-indigo-500',
      level: 'Foundation → Expert',
      duration: '12-16 weeks',
      enrolled: 15670,
      completion: 15,
      rating: 4.7,
      modules: [
        { name: 'Java Fundamentals', status: 'not-started', progress: 0, duration: '3 weeks' },
        { name: 'Spring Framework', status: 'not-started', progress: 0, duration: '3 weeks' },
        { name: 'Spring Boot', status: 'not-started', progress: 0, duration: '2.5 weeks' },
        { name: 'JPA & Hibernate', status: 'not-started', progress: 0, duration: '2 weeks' },
        { name: 'Microservices Architecture', status: 'not-started', progress: 0, duration: '2.5 weeks' },
        { name: 'Testing & DevOps', status: 'not-started', progress: 0, duration: '2 weeks' }
      ]
    }
  ];

  const skillMetrics = [
    { skill: 'API Development', level: 85, trend: '+12%' },
    { skill: 'Database Design', level: 78, trend: '+8%' },
    { skill: 'Authentication', level: 92, trend: '+15%' },
    { skill: 'Performance Optimization', level: 65, trend: '+5%' },
    { skill: 'Testing', level: 70, trend: '+10%' }
  ];

  const interviewPrep = [
    { topic: 'System Design', difficulty: 'Expert', completed: 12, total: 20, color: 'bg-purple-500' },
    { topic: 'Database Optimization', difficulty: 'Advanced', completed: 8, total: 12, color: 'bg-blue-500' },
    { topic: 'API Architecture', difficulty: 'Intermediate', completed: 15, total: 18, color: 'bg-green-500' },
    { topic: 'Security Practices', difficulty: 'Advanced', completed: 6, total: 15, color: 'bg-red-500' }
  ];

  const selectedTrackData = certificationTracks.find(track => track.id === selectedTrack);

  return (
    <PlatformLayout
      sidebarTitle="Candidate Platform"
      sidebarSubtitle="Interview Preparation"
      sidebarSections={candidateNavigation}
    >
      <div className="min-h-screen bg-gradient-to-br from-orange-50 via-white to-yellow-50 p-6">
        <div className="max-w-7xl mx-auto space-y-8">
          {/* Header */}
          <div className="text-center space-y-4">
            <div className="inline-flex items-center space-x-2 bg-orange-100 text-orange-800 px-4 py-2 rounded-full text-sm font-medium">
              <Server className="h-4 w-4" />
              <span>Backend Development Certification</span>
            </div>
            <h1 className="text-4xl font-bold text-gray-900">
              Master Backend Technologies
            </h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Build robust server-side applications with Node.js, Python, or Java. 
              Master databases, APIs, and cloud architecture through hands-on projects.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
            {/* Track Selection */}
            <div className="lg:col-span-3">
              <Tabs value={selectedTrack} onValueChange={setSelectedTrack} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {certificationTracks.map((track) => {
                    const IconComponent = track.icon;
                    return (
                      <Card 
                        key={track.id} 
                        className={`cursor-pointer transition-all duration-300 hover:shadow-lg border-2 ${
                          selectedTrack === track.id 
                            ? 'border-orange-500 shadow-lg' 
                            : 'border-gray-200 hover:border-orange-300'
                        }`}
                        onClick={() => setSelectedTrack(track.id)}
                      >
                        <CardHeader className="pb-3">
                          <div className="flex items-center justify-between">
                            <div className={`p-2 rounded-lg bg-gradient-to-r ${track.color}`}>
                              <IconComponent className="h-5 w-5 text-white" />
                            </div>
                            <div className="flex items-center space-x-1">
                              <Star className="h-3 w-3 text-yellow-500 fill-current" />
                              <span className="text-xs font-medium">{track.rating}</span>
                            </div>
                          </div>
                          <CardTitle className="text-base">{track.name}</CardTitle>
                          <CardDescription className="text-xs">{track.level}</CardDescription>
                        </CardHeader>
                        <CardContent className="pt-0">
                          <div className="space-y-2">
                            <div className="flex justify-between text-xs">
                              <span>Progress</span>
                              <span className="font-medium">{track.completion}%</span>
                            </div>
                            <Progress value={track.completion} className="h-1.5" />
                            <div className="grid grid-cols-2 gap-1 text-xs text-gray-600">
                              <div className="flex items-center space-x-1">
                                <Clock className="h-3 w-3" />
                                <span>{track.duration}</span>
                              </div>
                              <div className="flex items-center space-x-1">
                                <Users className="h-3 w-3" />
                                <span>{(track.enrolled / 1000).toFixed(1)}k</span>
                              </div>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    );
                  })}
                </div>

                {/* Selected Track Learning Path */}
                {selectedTrackData && (
                  <Card>
                    <CardHeader className={`bg-gradient-to-r ${selectedTrackData.color} text-white`}>
                      <CardTitle className="text-xl flex items-center space-x-3">
                        <selectedTrackData.icon className="h-6 w-6" />
                        <span>{selectedTrackData.name} Curriculum</span>
                      </CardTitle>
                      <CardDescription className="text-white/80">
                        Comprehensive backend development training with real-world projects
                      </CardDescription>
                    </CardHeader>
                    <CardContent className="p-6">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {selectedTrackData.modules.map((module, index) => (
                          <div 
                            key={index} 
                            className={`p-4 rounded-lg border-2 transition-all ${
                              module.status === 'completed' 
                                ? 'bg-green-50 border-green-200' 
                                : module.status === 'current'
                                ? 'bg-orange-50 border-orange-200'
                                : 'bg-gray-50 border-gray-200'
                            }`}
                          >
                            <div className="flex items-center justify-between mb-3">
                              <div className="flex items-center space-x-2">
                                {module.status === 'completed' ? (
                                  <CheckCircle className="h-4 w-4 text-green-500" />
                                ) : module.status === 'current' ? (
                                  <Play className="h-4 w-4 text-orange-500" />
                                ) : (
                                  <Clock className="h-4 w-4 text-gray-400" />
                                )}
                                <span className="font-medium text-sm">{module.name}</span>
                              </div>
                              <Badge variant="outline" className="text-xs">
                                {module.duration}
                              </Badge>
                            </div>
                            {module.status !== 'not-started' && module.status !== 'locked' && (
                              <div className="space-y-1">
                                <div className="flex justify-between text-xs">
                                  <span>Progress</span>
                                  <span>{module.progress}%</span>
                                </div>
                                <Progress value={module.progress} className="h-1" />
                              </div>
                            )}
                            <div className="mt-3">
                              <Button 
                                variant={module.status === 'current' ? 'default' : 'ghost'} 
                                size="sm" 
                                className="w-full"
                                disabled={module.status === 'locked' || module.status === 'not-started'}
                              >
                                {module.status === 'completed' ? 'Review' :
                                 module.status === 'current' ? 'Continue' : 'Start'}
                              </Button>
                            </div>
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                )}
              </Tabs>
            </div>

            {/* Sidebar */}
            <div className="space-y-6">
              {/* Skill Progress */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2 text-base">
                    <Target className="h-4 w-4" />
                    <span>Skill Progress</span>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {skillMetrics.map((skill, index) => (
                    <div key={index} className="space-y-2">
                      <div className="flex justify-between items-center">
                        <span className="text-sm font-medium">{skill.skill}</span>
                        <div className="flex items-center space-x-2">
                          <span className="text-xs">{skill.level}%</span>
                          <Badge variant="secondary" className="text-xs bg-green-100 text-green-700">
                            {skill.trend}
                          </Badge>
                        </div>
                      </div>
                      <Progress value={skill.level} className="h-1.5" />
                    </div>
                  ))}
                </CardContent>
              </Card>

              {/* Interview Preparation */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2 text-base">
                    <Trophy className="h-4 w-4" />
                    <span>Interview Prep</span>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  {interviewPrep.map((topic, index) => (
                    <div key={index} className="space-y-2">
                      <div className="flex justify-between items-center">
                        <span className="text-sm font-medium">{topic.topic}</span>
                        <Badge variant="outline" className="text-xs">
                          {topic.difficulty}
                        </Badge>
                      </div>
                      <div className="flex items-center space-x-2">
                        <div className="flex-1 bg-gray-200 rounded-full h-2">
                          <div 
                            className={`h-2 rounded-full ${topic.color}`}
                            style={{ width: `${(topic.completed / topic.total) * 100}%` }}
                          />
                        </div>
                        <span className="text-xs text-gray-600">
                          {topic.completed}/{topic.total}
                        </span>
                      </div>
                    </div>
                  ))}
                </CardContent>
              </Card>

              {/* Action Buttons */}
              <div className="space-y-3">
                <Button size="sm" className="w-full bg-gradient-to-r from-orange-600 to-red-600 hover:from-orange-700 hover:to-red-700">
                  <Play className="h-3 w-3 mr-2" />
                  Continue Learning
                </Button>
                <Button variant="outline" size="sm" className="w-full">
                  <Target className="h-3 w-3 mr-2" />
                  System Design Practice
                </Button>
                <Button variant="outline" size="sm" className="w-full">
                  <Database className="h-3 w-3 mr-2" />
                  Database Challenges
                </Button>
                <Button variant="outline" size="sm" className="w-full">
                  <Shield className="h-3 w-3 mr-2" />
                  Security Assessment
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </PlatformLayout>
  );
};

export default BackendCertification;