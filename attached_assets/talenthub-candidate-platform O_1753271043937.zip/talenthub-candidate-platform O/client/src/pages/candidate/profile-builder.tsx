import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Link } from "wouter";
import { candidateNavigation } from "@/config/complete-navigation";
import PlatformLayout from "@/components/layout/platform-layout";
import { 
  Save, Plus, X, Eye, Share, ExternalLink, Mail, ChevronLeft,
  User, MapPin, Phone, Globe, Linkedin, Briefcase, GraduationCap,
  Award, Calendar, Edit3, Target, TrendingUp, CheckCircle, Star,
  Building, BookOpen, Code, Settings, Upload, Download, Edit2, Trash2, Github
} from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";

// Data structures for form entries
type ExperienceFormData = {
  company: string;
  position: string;
  startDate: string;
  endDate: string;
  description: string;
  current: boolean;
};

type EducationFormData = {
  institution: string;
  degree: string;
  fieldOfStudy: string;
  startDate: string;
  endDate: string;
  description: string;
};

type SkillFormData = {
  name: string;
  level: number;
  category: string;
};

type ProjectFormData = {
  name: string;
  description: string;
  url: string;
  githubUrl: string;
  technologies: string[];
  featured: boolean;
};

export default function ProfileBuilder() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Profile data state
  const [profile, setProfile] = useState({
    bio: "",
    professionalSummary: "",
    phone: "",
    location: "",
    linkedinUrl: "",
    profilePhoto: ""
  });

  // Modal states
  const [showAddExperienceModal, setShowAddExperienceModal] = useState(false);
  const [showAddEducationModal, setShowAddEducationModal] = useState(false);
  const [showAddSkillModal, setShowAddSkillModal] = useState(false);
  const [showAddProjectModal, setShowAddProjectModal] = useState(false);
  const [showEditExperienceModal, setShowEditExperienceModal] = useState(false);
  const [editingExperience, setEditingExperience] = useState<any>(null);
  const [editExperienceData, setEditExperienceData] = useState<ExperienceFormData>({
    company: "",
    position: "",
    startDate: "",
    endDate: "",
    description: "",
    current: false
  });

  // Form data states
  const [newExperience, setNewExperience] = useState<ExperienceFormData>({
    company: "",
    position: "",
    startDate: "",
    endDate: "",
    description: "",
    current: false
  });

  const [newEducation, setNewEducation] = useState<EducationFormData>({
    institution: "",
    degree: "",
    fieldOfStudy: "",
    startDate: "",
    endDate: "",
    description: ""
  });

  const [newSkill, setNewSkill] = useState<SkillFormData>({
    name: "",
    level: 1,
    category: ""
  });

  const [newProject, setNewProject] = useState<ProjectFormData>({
    name: "",
    description: "",
    url: "",
    githubUrl: "",
    technologies: [],
    featured: false
  });

  // Pending entries for batch saving
  const [pendingExperiences, setPendingExperiences] = useState<ExperienceFormData[]>([]);
  const [pendingEducations, setPendingEducations] = useState<EducationFormData[]>([]);
  const [pendingSkills, setPendingSkills] = useState<SkillFormData[]>([]);
  const [pendingProjects, setPendingProjects] = useState<ProjectFormData[]>([]);

  // Loading states for batch operations
  const [isSavingExperiences, setIsSavingExperiences] = useState(false);
  const [isSavingEducations, setIsSavingEducations] = useState(false);
  const [isSavingSkills, setIsSavingSkills] = useState(false);
  const [isSavingProjects, setIsSavingProjects] = useState(false);

  // Auto-save for profile data
  const [autoSaveStatus, setAutoSaveStatus] = useState<'idle' | 'saving' | 'saved'>('idle');

  // Progress calculation
  const [completionProgress, setCompletionProgress] = useState(0);

  // Query for existing profile data
  const { data: userProfile } = useQuery({
    queryKey: ['/api/user-profile'],
    staleTime: 5 * 60 * 1000
  });

  // Queries for saved profile entries
  const { data: savedExperiences = [], refetch: refetchExperiences } = useQuery<any[]>({
    queryKey: ['/api/user/experiences'],
    staleTime: 5 * 60 * 1000
  });

  const { data: savedEducations = [], refetch: refetchEducations } = useQuery<any[]>({
    queryKey: ['/api/user/educations'],
    staleTime: 5 * 60 * 1000
  });

  const { data: savedSkills = [], refetch: refetchSkills } = useQuery<any[]>({
    queryKey: ['/api/user/skills'],
    staleTime: 5 * 60 * 1000
  });

  const { data: savedProjects = [], refetch: refetchProjects } = useQuery<any[]>({
    queryKey: ['/api/user/projects'],
    staleTime: 5 * 60 * 1000
  });

  // Profile mutation defined later to avoid duplication

  // Experience handlers
  const handleSaveExperience = () => {
    if (!newExperience.company || !newExperience.position) {
      toast({
        title: "Missing required fields",
        description: "Please fill in company and position",
        variant: "destructive"
      });
      return;
    }

    setPendingExperiences(prev => [...prev, newExperience]);
    setNewExperience({
      company: "",
      position: "",
      startDate: "",
      endDate: "",
      description: "",
      current: false
    });
    
    toast({
      title: "Experience added to queue",
      description: "Click 'Save All' to save all pending experiences"
    });
  };

  const handleSaveAllExperiences = async () => {
    if (pendingExperiences.length === 0) return;
    
    setIsSavingExperiences(true);
    try {
      await apiRequest('POST', '/api/user/experiences/batch', { experiences: pendingExperiences });
      setPendingExperiences([]);
      setShowAddExperienceModal(false);
      queryClient.invalidateQueries({ queryKey: ['/api/user/profile'] });
      refetchExperiences(); // Refresh saved experiences
      toast({
        title: "Success",
        description: `${pendingExperiences.length} experience(s) saved successfully`
      });
    } catch (error) {
      toast({
        title: "Error saving experiences",
        description: "Please try again",
        variant: "destructive"
      });
    } finally {
      setIsSavingExperiences(false);
    }
  };

  const handleRemovePendingExperience = (index: number) => {
    setPendingExperiences(prev => prev.filter((_, i) => i !== index));
  };

  const handleClearPendingExperiences = () => {
    setPendingExperiences([]);
  };

  // Education handlers
  const handleSaveEducation = () => {
    if (!newEducation.institution || !newEducation.degree) {
      toast({
        title: "Missing required fields",
        description: "Please fill in institution and degree",
        variant: "destructive"
      });
      return;
    }

    setPendingEducations(prev => [...prev, newEducation]);
    setNewEducation({
      institution: "",
      degree: "",
      fieldOfStudy: "",
      startDate: "",
      endDate: "",
      description: ""
    });
    
    toast({
      title: "Education added to queue",
      description: "Click 'Save All' to save all pending educations"
    });
  };

  const handleSaveAllEducations = async () => {
    if (pendingEducations.length === 0) return;
    
    setIsSavingEducations(true);
    try {
      await apiRequest('POST', '/api/user/educations/batch', { educations: pendingEducations });
      setPendingEducations([]);
      setShowAddEducationModal(false);
      queryClient.invalidateQueries({ queryKey: ['/api/user/profile'] });
      refetchEducations(); // Refresh saved educations
      toast({
        title: "Success",
        description: `${pendingEducations.length} education(s) saved successfully`
      });
    } catch (error) {
      toast({
        title: "Error saving educations",
        description: "Please try again",
        variant: "destructive"
      });
    } finally {
      setIsSavingEducations(false);
    }
  };

  const handleRemovePendingEducation = (index: number) => {
    setPendingEducations(prev => prev.filter((_, i) => i !== index));
  };

  const handleClearPendingEducations = () => {
    setPendingEducations([]);
  };

  // Skill handlers
  const handleSaveSkill = () => {
    if (!newSkill.name) {
      toast({
        title: "Missing required fields",
        description: "Please enter skill name",
        variant: "destructive"
      });
      return;
    }

    setPendingSkills(prev => [...prev, newSkill]);
    setNewSkill({
      name: "",
      level: 1,
      category: ""
    });
    
    toast({
      title: "Skill added to queue",
      description: "Click 'Save All' to save all pending skills"
    });
  };

  const handleSaveAllSkills = async () => {
    if (pendingSkills.length === 0) return;
    
    setIsSavingSkills(true);
    try {
      await apiRequest('POST', '/api/user/skills/batch', { skills: pendingSkills });
      setPendingSkills([]);
      setShowAddSkillModal(false);
      queryClient.invalidateQueries({ queryKey: ['/api/user/profile'] });
      refetchSkills(); // Refresh saved skills
      toast({
        title: "Success",
        description: `${pendingSkills.length} skill(s) saved successfully`
      });
    } catch (error) {
      toast({
        title: "Error saving skills",
        description: "Please try again",
        variant: "destructive"
      });
    } finally {
      setIsSavingSkills(false);
    }
  };

  const handleRemovePendingSkill = (index: number) => {
    setPendingSkills(prev => prev.filter((_, i) => i !== index));
  };

  const handleClearPendingSkills = () => {
    setPendingSkills([]);
  };

  // Project handlers
  const handleSaveProject = () => {
    if (!newProject.name) {
      toast({
        title: "Missing required fields",
        description: "Please enter project name",
        variant: "destructive"
      });
      return;
    }

    setPendingProjects(prev => [...prev, newProject]);
    setNewProject({
      name: "",
      description: "",
      url: "",
      githubUrl: "",
      technologies: [],
      featured: false
    });
    
    toast({
      title: "Project added to queue",
      description: "Click 'Save All' to save all pending projects"
    });
  };

  const handleSaveAllProjects = async () => {
    if (pendingProjects.length === 0) return;
    
    setIsSavingProjects(true);
    try {
      await apiRequest('POST', '/api/user/projects/batch', { projects: pendingProjects });
      setPendingProjects([]);
      setShowAddProjectModal(false);
      queryClient.invalidateQueries({ queryKey: ['/api/user/profile'] });
      refetchProjects(); // Refresh saved projects
      toast({
        title: "Success",
        description: `${pendingProjects.length} project(s) saved successfully`
      });
    } catch (error) {
      toast({
        title: "Error saving projects",
        description: "Please try again",
        variant: "destructive"
      });
    } finally {
      setIsSavingProjects(false);
    }
  };

  const handleRemovePendingProject = (index: number) => {
    setPendingProjects(prev => prev.filter((_, i) => i !== index));
  };

  const handleClearPendingProjects = () => {
    setPendingProjects([]);
  };

  // Additional edit handlers
  const handleEditExperience = (experience: any) => {
    setEditExperienceData({
      company: experience.company || "",
      position: experience.position || "",
      startDate: experience.startDate || "",
      endDate: experience.endDate || "",
      description: experience.description || "",
      current: experience.current || false
    });
    setEditingExperience(experience);
    setShowEditExperienceModal(true);
  };

  const handleUpdateExperience = () => {
    if (!editingExperience) return;
    updateExperienceMutation.mutate({
      id: editingExperience.id,
      data: editExperienceData
    });
  };

  // Delete mutations
  const deleteExperienceMutation = useMutation({
    mutationFn: (id: number) => apiRequest('DELETE', `/api/user/experiences/${id}`),
    onSuccess: () => {
      refetchExperiences();
      toast({ title: "Experience deleted successfully" });
    },
    onError: () => {
      toast({
        title: "Error deleting experience",
        description: "Please try again",
        variant: "destructive"
      });
    }
  });

  const deleteEducationMutation = useMutation({
    mutationFn: (id: number) => apiRequest('DELETE', `/api/user/educations/${id}`),
    onSuccess: () => {
      refetchEducations();
      toast({ title: "Education deleted successfully" });
    },
    onError: () => {
      toast({
        title: "Error deleting education",
        description: "Please try again",
        variant: "destructive"
      });
    }
  });

  const deleteSkillMutation = useMutation({
    mutationFn: (id: number) => apiRequest('DELETE', `/api/user/skills/${id}`),
    onSuccess: () => {
      refetchSkills();
      toast({ title: "Skill deleted successfully" });
    },
    onError: () => {
      toast({
        title: "Error deleting skill",
        description: "Please try again",
        variant: "destructive"
      });
    }
  });

  const deleteProjectMutation = useMutation({
    mutationFn: (id: number) => apiRequest('DELETE', `/api/user/projects/${id}`),
    onSuccess: () => {
      refetchProjects();
      toast({ title: "Project deleted successfully" });
    },
    onError: () => {
      toast({
        title: "Error deleting project",
        description: "Please try again",
        variant: "destructive"
      });
    }
  });

  // Edit mutations
  const updateExperienceMutation = useMutation({
    mutationFn: ({ id, data }: { id: number; data: any }) => 
      apiRequest('PUT', `/api/user/experiences/${id}`, data),
    onSuccess: () => {
      refetchExperiences();
      setShowEditExperienceModal(false);
      setEditingExperience(null);
      toast({ title: "Experience updated successfully" });
    },
    onError: () => {
      toast({
        title: "Error updating experience",
        description: "Please try again",
        variant: "destructive"
      });
    }
  });

  // Auto-save mutation for profile
  const profileMutation = useMutation({
    mutationFn: (data: any) => apiRequest('PATCH', '/api/user/profile', data),
    onMutate: () => setAutoSaveStatus('saving'),
    onSuccess: () => {
      setAutoSaveStatus('saved');
      setTimeout(() => setAutoSaveStatus('idle'), 2000);
      queryClient.invalidateQueries({ queryKey: ['/api/user/profile'] });
    },
    onError: () => {
      setAutoSaveStatus('idle');
      toast({
        title: "Auto-save failed",
        description: "Please try saving manually",
        variant: "destructive"
      });
    }
  });

  // Auto-save trigger
  useEffect(() => {
    const timer = setTimeout(() => {
      if (profile.bio || profile.professionalSummary || profile.phone || profile.location || profile.linkedinUrl) {
        setAutoSaveStatus('saving');
        profileMutation.mutate(profile);
      }
    }, 2000);

    return () => clearTimeout(timer);
  }, [profile]);

  // Calculate completion progress
  useEffect(() => {
    let completed = 0;
    const total = 8; // Total sections to complete

    if (profile.bio) completed++;
    if (profile.professionalSummary) completed++;
    if (profile.phone) completed++;
    if (profile.location) completed++;
    if (profile.linkedinUrl) completed++;
    if (savedExperiences && Array.isArray(savedExperiences) && savedExperiences.length > 0) completed++;
    if (savedEducations && Array.isArray(savedEducations) && savedEducations.length > 0) completed++;
    if (savedSkills && Array.isArray(savedSkills) && savedSkills.length > 0) completed++;

    setCompletionProgress(Math.round((completed / total) * 100));
  }, [profile, userProfile]);

  return (
    <PlatformLayout
      sidebarTitle="Candidate Platform"
      sidebarSubtitle="Build Your Professional Profile"
      sidebarSections={candidateNavigation}
    >
      <div className="space-y-6">
        {/* Header Section */}
        <div className="bg-gradient-to-r from-sky-500 to-sky-600 rounded-xl p-6 text-white">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold mb-2">Profile Builder</h1>
              <p className="text-sky-100">Create a compelling professional profile that stands out</p>
            </div>
            <div className="text-right">
              <div className="text-2xl font-bold">{completionProgress}%</div>
              <div className="text-sm text-sky-100">Complete</div>
            </div>
          </div>
          <div className="mt-4">
            <Progress value={completionProgress} className="bg-sky-400" />
          </div>
        </div>

        {/* Auto-save Status */}
        {autoSaveStatus !== 'idle' && (
          <div className="flex items-center gap-2 text-sm text-gray-600">
            {autoSaveStatus === 'saving' && (
              <>
                <div className="w-3 h-3 border border-gray-400 border-t-transparent rounded-full animate-spin" />
                <span>Auto-saving...</span>
              </>
            )}
            {autoSaveStatus === 'saved' && (
              <>
                <CheckCircle className="w-4 h-4 text-green-600" />
                <span className="text-green-600">Auto-saved</span>
              </>
            )}
          </div>
        )}

        {/* Profile Tabs */}
        <Tabs defaultValue="personal" className="space-y-6">
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="personal" className="flex items-center gap-2">
              <User className="w-4 h-4" />
              Personal
            </TabsTrigger>
            <TabsTrigger value="experience" className="flex items-center gap-2">
              <Briefcase className="w-4 h-4" />
              Experience
              {pendingExperiences.length > 0 && (
                <Badge variant="secondary" className="ml-1">
                  {pendingExperiences.length}
                </Badge>
              )}
            </TabsTrigger>
            <TabsTrigger value="education" className="flex items-center gap-2">
              <GraduationCap className="w-4 h-4" />
              Education
              {pendingEducations.length > 0 && (
                <Badge variant="secondary" className="ml-1">
                  {pendingEducations.length}
                </Badge>
              )}
            </TabsTrigger>
            <TabsTrigger value="skills" className="flex items-center gap-2">
              <Award className="w-4 h-4" />
              Skills
              {pendingSkills.length > 0 && (
                <Badge variant="secondary" className="ml-1">
                  {pendingSkills.length}
                </Badge>
              )}
            </TabsTrigger>
            <TabsTrigger value="projects" className="flex items-center gap-2">
              <Code className="w-4 h-4" />
              Projects
              {pendingProjects.length > 0 && (
                <Badge variant="secondary" className="ml-1">
                  {pendingProjects.length}
                </Badge>
              )}
            </TabsTrigger>
          </TabsList>

          {/* Personal Information Tab */}
          <TabsContent value="personal">
            <Card className="border-sky-200">
              <CardHeader className="bg-gradient-to-r from-sky-50 to-sky-100">
                <CardTitle className="text-sky-800 flex items-center gap-2">
                  <User className="w-5 h-5" />
                  Personal Information
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6 pt-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="phone">Phone Number</Label>
                      <Input
                        id="phone"
                        value={profile.phone}
                        onChange={(e) => setProfile({...profile, phone: e.target.value})}
                        placeholder="+1 (555) 123-4567"
                      />
                    </div>
                    <div>
                      <Label htmlFor="location">Location</Label>
                      <Input
                        id="location"
                        value={profile.location}
                        onChange={(e) => setProfile({...profile, location: e.target.value})}
                        placeholder="City, State, Country"
                      />
                    </div>
                    <div>
                      <Label htmlFor="linkedin">LinkedIn URL</Label>
                      <Input
                        id="linkedin"
                        value={profile.linkedinUrl}
                        onChange={(e) => setProfile({...profile, linkedinUrl: e.target.value})}
                        placeholder="https://linkedin.com/in/yourprofile"
                      />
                    </div>
                  </div>
                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="bio">Bio</Label>
                      <Textarea
                        id="bio"
                        value={profile.bio}
                        onChange={(e) => setProfile({...profile, bio: e.target.value})}
                        placeholder="Brief description about yourself"
                        rows={3}
                      />
                    </div>
                    <div>
                      <Label htmlFor="summary">Professional Summary</Label>
                      <Textarea
                        id="summary"
                        value={profile.professionalSummary}
                        onChange={(e) => setProfile({...profile, professionalSummary: e.target.value})}
                        placeholder="Your professional background and key achievements"
                        rows={4}
                      />
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Experience Tab */}
          <TabsContent value="experience">
            <Card className="border-green-200">
              <CardHeader className="bg-gradient-to-r from-green-50 to-green-100">
                <CardTitle className="text-green-800 flex items-center gap-2">
                  <Briefcase className="w-5 h-5" />
                  Work Experience
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6 pt-6">
                <div className="flex justify-between items-center">
                  <p className="text-gray-600">Manage your work experience</p>
                  <Button
                    onClick={() => setShowAddExperienceModal(true)}
                    className="bg-green-600 hover:bg-green-700"
                  >
                    <Plus className="w-4 h-4 mr-2" />
                    Add Experience
                  </Button>
                </div>

                {/* Display saved experiences */}
                {savedExperiences.length > 0 ? (
                  <div className="space-y-4">
                    {savedExperiences.map((exp: any) => (
                      <Card key={exp.id} className="border-green-100">
                        <CardContent className="p-4">
                          <div className="flex justify-between items-start">
                            <div className="flex-1">
                              <h4 className="font-semibold text-green-800">{exp.position}</h4>
                              <p className="text-green-600">{exp.company}</p>
                              <p className="text-sm text-gray-500">
                                {exp.startDate} - {exp.current ? 'Present' : exp.endDate}
                              </p>
                              {exp.description && (
                                <p className="text-sm text-gray-600 mt-2">{exp.description}</p>
                              )}
                            </div>
                            <div className="flex gap-2">
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => setEditingExperience(exp)}
                                className="text-green-600 border-green-200 hover:bg-green-50"
                              >
                                <Edit3 className="w-3 h-3" />
                              </Button>
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => deleteExperienceMutation.mutate(exp.id)}
                                disabled={deleteExperienceMutation.isPending}
                                className="text-red-600 border-red-200 hover:bg-red-50"
                              >
                                <X className="w-3 h-3" />
                              </Button>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8 text-gray-500">
                    <Briefcase className="w-12 h-12 mx-auto mb-4 text-gray-300" />
                    <p>No work experience added yet</p>
                    <p className="text-sm">Click "Add Experience" to get started</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Education Tab */}
          <TabsContent value="education">
            <Card className="border-orange-200">
              <CardHeader className="bg-gradient-to-r from-orange-50 to-orange-100">
                <CardTitle className="text-orange-800 flex items-center gap-2">
                  <GraduationCap className="w-5 h-5" />
                  Education
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6 pt-6">
                <div className="flex justify-between items-center">
                  <p className="text-gray-600">Manage your educational background</p>
                  <Button
                    onClick={() => setShowAddEducationModal(true)}
                    className="bg-orange-600 hover:bg-orange-700"
                  >
                    <Plus className="w-4 h-4 mr-2" />
                    Add Education
                  </Button>
                </div>

                {/* Saved Education Entries */}
                {savedEducations && savedEducations.length > 0 ? (
                  <div className="space-y-4">
                    {savedEducations.map((edu: any) => (
                      <div key={edu.id} className="bg-orange-50 border border-orange-200 rounded-lg p-4">
                        <div className="flex justify-between items-start">
                          <div className="flex-1">
                            <h4 className="font-semibold text-orange-800">{edu.degree} in {edu.fieldOfStudy}</h4>
                            <p className="text-orange-600">{edu.institution}</p>
                            <p className="text-sm text-gray-500">
                              {edu.startDate} - {edu.endDate}
                            </p>
                            {edu.description && (
                              <p className="text-sm text-gray-600 mt-2">{edu.description}</p>
                            )}
                          </div>
                          <div className="flex gap-2">
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => {/* TODO: Edit education */}}
                              className="text-orange-600 border-orange-200 hover:bg-orange-50"
                            >
                              <Edit3 className="w-3 h-3" />
                            </Button>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => deleteEducationMutation.mutate(edu.id)}
                              disabled={deleteEducationMutation.isPending}
                              className="text-red-600 border-red-200 hover:bg-red-50"
                            >
                              <Trash2 className="w-3 h-3" />
                            </Button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8 text-gray-500">
                    <GraduationCap className="w-12 h-12 mx-auto mb-4 text-gray-300" />
                    <p>No education added yet</p>
                    <p className="text-sm">Click "Add Education" to get started</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Skills Tab */}
          <TabsContent value="skills">
            <Card className="border-purple-200">
              <CardHeader className="bg-gradient-to-r from-purple-50 to-purple-100">
                <CardTitle className="text-purple-800 flex items-center gap-2">
                  <Award className="w-5 h-5" />
                  Skills
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6 pt-6">
                <div className="flex justify-between items-center">
                  <p className="text-gray-600">Showcase your technical and soft skills</p>
                  <Button
                    onClick={() => setShowAddSkillModal(true)}
                    className="bg-purple-600 hover:bg-purple-700"
                  >
                    <Plus className="w-4 h-4 mr-2" />
                    Add Skill
                  </Button>
                </div>

                {/* Saved Skills Entries */}
                {savedSkills && savedSkills.length > 0 ? (
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {savedSkills.map((skill: any) => (
                      <div key={skill.id} className="bg-purple-50 border border-purple-200 rounded-lg p-4">
                        <div className="flex justify-between items-start mb-2">
                          <div className="flex-1">
                            <h4 className="font-semibold text-purple-800">{skill.name}</h4>
                            <p className="text-sm text-purple-600">{skill.category}</p>
                          </div>
                          <div className="flex gap-1">
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => {/* TODO: Edit skill */}}
                              className="text-purple-600 border-purple-200 hover:bg-purple-50 p-1"
                            >
                              <Edit3 className="w-3 h-3" />
                            </Button>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => deleteSkillMutation.mutate(skill.id)}
                              disabled={deleteSkillMutation.isPending}
                              className="text-red-600 border-red-200 hover:bg-red-50 p-1"
                            >
                              <Trash2 className="w-3 h-3" />
                            </Button>
                          </div>
                        </div>
                        <div className="mb-2">
                          <div className="flex justify-between text-sm text-gray-600 mb-1">
                            <span>Proficiency</span>
                            <span>{skill.level}/5</span>
                          </div>
                          <div className="w-full bg-gray-200 rounded-full h-2">
                            <div 
                              className="bg-purple-600 h-2 rounded-full transition-all duration-300"
                              style={{ width: `${(skill.level / 5) * 100}%` }}
                            />
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8 text-gray-500">
                    <Award className="w-12 h-12 mx-auto mb-4 text-gray-300" />
                    <p>No skills added yet</p>
                    <p className="text-sm">Click "Add Skill" to get started</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Projects Tab */}
          <TabsContent value="projects">
            <Card className="border-indigo-200">
              <CardHeader className="bg-gradient-to-r from-indigo-50 to-indigo-100">
                <CardTitle className="text-indigo-800 flex items-center gap-2">
                  <Code className="w-5 h-5" />
                  Projects
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6 pt-6">
                <div className="flex justify-between items-center">
                  <p className="text-gray-600">Highlight your best projects and work</p>
                  <Button
                    onClick={() => setShowAddProjectModal(true)}
                    className="bg-indigo-600 hover:bg-indigo-700"
                  >
                    <Plus className="w-4 h-4 mr-2" />
                    Add Project
                  </Button>
                </div>

                {/* Saved Projects Entries */}
                {savedProjects && savedProjects.length > 0 ? (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {savedProjects.map((project: any) => (
                      <div key={project.id} className="bg-indigo-50 border border-indigo-200 rounded-lg p-4">
                        <div className="flex justify-between items-start mb-3">
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-2">
                              <h4 className="font-semibold text-indigo-800">{project.name}</h4>
                              {project.featured && (
                                <Badge className="bg-yellow-100 text-yellow-800 border-yellow-300">Featured</Badge>
                              )}
                            </div>
                            <p className="text-sm text-gray-600 mb-3 line-clamp-2">{project.description}</p>
                            
                            {project.technologies && project.technologies.length > 0 && (
                              <div className="flex flex-wrap gap-1 mb-3">
                                {project.technologies.map((tech: string, idx: number) => (
                                  <Badge key={idx} variant="secondary" className="text-xs">
                                    {tech}
                                  </Badge>
                                ))}
                              </div>
                            )}
                            
                            <div className="flex gap-2 text-sm">
                              {project.url && (
                                <a 
                                  href={project.url} 
                                  target="_blank" 
                                  rel="noopener noreferrer"
                                  className="text-indigo-600 hover:text-indigo-800 flex items-center gap-1"
                                >
                                  <ExternalLink className="w-3 h-3" />
                                  Live Demo
                                </a>
                              )}
                              {project.githubUrl && (
                                <a 
                                  href={project.githubUrl} 
                                  target="_blank" 
                                  rel="noopener noreferrer"
                                  className="text-gray-600 hover:text-gray-800 flex items-center gap-1"
                                >
                                  <Code className="w-3 h-3" />
                                  GitHub
                                </a>
                              )}
                            </div>
                          </div>
                          <div className="flex gap-1 ml-2">
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => {/* TODO: Edit project */}}
                              className="text-indigo-600 border-indigo-200 hover:bg-indigo-50 p-1"
                            >
                              <Edit3 className="w-3 h-3" />
                            </Button>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => deleteProjectMutation.mutate(project.id)}
                              disabled={deleteProjectMutation.isPending}
                              className="text-red-600 border-red-200 hover:bg-red-50 p-1"
                            >
                              <Trash2 className="w-3 h-3" />
                            </Button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8 text-gray-500">
                    <Code className="w-12 h-12 mx-auto mb-4 text-gray-300" />
                    <p>No projects added yet</p>
                    <p className="text-sm">Click "Add Project" to get started</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>

      {/* Experience Modal */}
      <Dialog open={showAddExperienceModal} onOpenChange={setShowAddExperienceModal}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-xl font-bold text-green-800">
              Add Work Experience
            </DialogTitle>
            {pendingExperiences.length > 0 && (
              <p className="text-sm text-gray-600">
                {pendingExperiences.length} experience(s) ready to save
              </p>
            )}
          </DialogHeader>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="space-y-4">
              <h3 className="font-semibold text-green-700 border-b border-green-200 pb-2">Add New Experience</h3>
              
              <form onSubmit={(e) => { e.preventDefault(); handleSaveExperience(); }} className="space-y-4">
                <div>
                  <Label htmlFor="company">Company *</Label>
                  <Input
                    id="company"
                    value={newExperience.company}
                    onChange={(e) => setNewExperience({...newExperience, company: e.target.value})}
                    placeholder="Enter company name"
                    required
                  />
                </div>

                <div>
                  <Label htmlFor="position">Position *</Label>
                  <Input
                    id="position"
                    value={newExperience.position}
                    onChange={(e) => setNewExperience({...newExperience, position: e.target.value})}
                    placeholder="e.g. Software Engineer, Product Manager"
                    required
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <Label htmlFor="startDate">Start Date</Label>
                    <Input
                      id="startDate"
                      type="date"
                      value={newExperience.startDate}
                      onChange={(e) => setNewExperience({...newExperience, startDate: e.target.value})}
                    />
                  </div>
                  <div>
                    <Label htmlFor="endDate">End Date</Label>
                    <Input
                      id="endDate"
                      type="date"
                      value={newExperience.endDate}
                      onChange={(e) => setNewExperience({...newExperience, endDate: e.target.value})}
                      disabled={newExperience.current}
                    />
                  </div>
                </div>

                <div className="flex items-center space-x-2">
                  <input
                    type="checkbox"
                    id="current"
                    checked={newExperience.current}
                    onChange={(e) => setNewExperience({...newExperience, current: e.target.checked})}
                    className="rounded border-gray-300"
                  />
                  <Label htmlFor="current">I currently work here</Label>
                </div>

                <div>
                  <Label htmlFor="description">Description</Label>
                  <Textarea
                    id="description"
                    value={newExperience.description}
                    onChange={(e) => setNewExperience({...newExperience, description: e.target.value})}
                    placeholder="Describe your responsibilities and achievements"
                    rows={3}
                  />
                </div>

                <div className="flex gap-3 pt-4">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => setShowAddExperienceModal(false)}
                    className="flex-1"
                  >
                    Cancel
                  </Button>
                  <Button
                    type="submit"
                    className="flex-1 bg-green-600 hover:bg-green-700"
                  >
                    Add to Queue
                  </Button>
                </div>
              </form>
            </div>

            {/* Pending Experiences Display */}
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="font-semibold text-green-700 border-b border-green-200 pb-2 flex-1">
                  Pending Experiences ({pendingExperiences.length})
                </h3>
                {pendingExperiences.length > 0 && (
                  <Button
                    onClick={handleClearPendingExperiences}
                    variant="outline"
                    size="sm"
                    className="ml-2 text-red-600 border-red-200 hover:bg-red-50"
                  >
                    Clear All
                  </Button>
                )}
              </div>

              {pendingExperiences.length === 0 ? (
                <div className="text-center py-8 text-gray-500 bg-gray-50 rounded-lg border-2 border-dashed border-gray-200">
                  <p>No pending experiences</p>
                  <p className="text-sm">Add experiences using the form to see them here</p>
                </div>
              ) : (
                <div className="space-y-3 max-h-80 overflow-y-auto">
                  {pendingExperiences.map((experience, index) => (
                    <div key={index} className="bg-green-50 p-3 rounded-lg border border-green-200">
                      <div className="flex justify-between items-start">
                        <div className="flex-1">
                          <h4 className="font-medium text-green-800">{experience.position}</h4>
                          <p className="text-sm text-green-600">{experience.company}</p>
                          {experience.startDate && (
                            <p className="text-xs text-gray-500">
                              {experience.startDate} - {experience.current ? 'Present' : experience.endDate}
                            </p>
                          )}
                        </div>
                        <Button
                          onClick={() => handleRemovePendingExperience(index)}
                          variant="ghost"
                          size="sm"
                          className="text-red-600 hover:bg-red-50"
                        >
                          <X className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {pendingExperiences.length > 0 && (
                <Button
                  onClick={handleSaveAllExperiences}
                  disabled={isSavingExperiences}
                  className="w-full bg-green-600 hover:bg-green-700"
                >
                  {isSavingExperiences ? "Saving..." : `Save All ${pendingExperiences.length} Experience(s)`}
                </Button>
              )}
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Education Modal */}
      <Dialog open={showAddEducationModal} onOpenChange={setShowAddEducationModal}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-xl font-bold text-orange-800">
              Add Education
            </DialogTitle>
            {pendingEducations.length > 0 && (
              <p className="text-sm text-gray-600">
                {pendingEducations.length} education(s) ready to save
              </p>
            )}
          </DialogHeader>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="space-y-4">
              <h3 className="font-semibold text-orange-700 border-b border-orange-200 pb-2">Add New Education</h3>
              
              <form onSubmit={(e) => { e.preventDefault(); handleSaveEducation(); }} className="space-y-4">
                <div>
                  <Label htmlFor="institution">Institution *</Label>
                  <Input
                    id="institution"
                    value={newEducation.institution}
                    onChange={(e) => setNewEducation({...newEducation, institution: e.target.value})}
                    placeholder="Enter institution name"
                    required
                  />
                </div>

                <div>
                  <Label htmlFor="degree">Degree *</Label>
                  <Input
                    id="degree"
                    value={newEducation.degree}
                    onChange={(e) => setNewEducation({...newEducation, degree: e.target.value})}
                    placeholder="e.g. Bachelor's in Computer Science"
                    required
                  />
                </div>

                <div>
                  <Label htmlFor="fieldOfStudy">Field of Study</Label>
                  <Input
                    id="fieldOfStudy"
                    value={newEducation.fieldOfStudy}
                    onChange={(e) => setNewEducation({...newEducation, fieldOfStudy: e.target.value})}
                    placeholder="e.g. Computer Science"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <Label htmlFor="startDate">Start Date</Label>
                    <Input
                      id="startDate"
                      type="date"
                      value={newEducation.startDate}
                      onChange={(e) => setNewEducation({...newEducation, startDate: e.target.value})}
                    />
                  </div>
                  <div>
                    <Label htmlFor="endDate">End Date</Label>
                    <Input
                      id="endDate"
                      type="date"
                      value={newEducation.endDate}
                      onChange={(e) => setNewEducation({...newEducation, endDate: e.target.value})}
                    />
                  </div>
                </div>

                <div>
                  <Label htmlFor="description">Description</Label>
                  <Textarea
                    id="description"
                    value={newEducation.description}
                    onChange={(e) => setNewEducation({...newEducation, description: e.target.value})}
                    placeholder="Optional description, achievements, coursework, etc."
                    rows={3}
                  />
                </div>

                <div className="flex gap-3 pt-4">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => setShowAddEducationModal(false)}
                    className="flex-1"
                  >
                    Cancel
                  </Button>
                  <Button
                    type="submit"
                    className="flex-1 bg-orange-600 hover:bg-orange-700"
                  >
                    Add to Queue
                  </Button>
                </div>
              </form>
            </div>

            {/* Pending Educations Display */}
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="font-semibold text-orange-700 border-b border-orange-200 pb-2 flex-1">
                  Pending Educations ({pendingEducations.length})
                </h3>
                {pendingEducations.length > 0 && (
                  <Button
                    onClick={handleClearPendingEducations}
                    variant="outline"
                    size="sm"
                    className="ml-2 text-red-600 border-red-200 hover:bg-red-50"
                  >
                    Clear All
                  </Button>
                )}
              </div>

              {pendingEducations.length === 0 ? (
                <div className="text-center py-8 text-gray-500 bg-gray-50 rounded-lg border-2 border-dashed border-gray-200">
                  <p>No pending educations</p>
                  <p className="text-sm">Add educations using the form to see them here</p>
                </div>
              ) : (
                <div className="space-y-3 max-h-80 overflow-y-auto">
                  {pendingEducations.map((education, index) => (
                    <div key={index} className="bg-orange-50 p-3 rounded-lg border border-orange-200">
                      <div className="flex justify-between items-start">
                        <div className="flex-1">
                          <h4 className="font-medium text-orange-800">{education.degree}</h4>
                          <p className="text-sm text-orange-600">{education.institution}</p>
                          {education.fieldOfStudy && (
                            <p className="text-xs text-orange-500">{education.fieldOfStudy}</p>
                          )}
                          {education.startDate && education.endDate && (
                            <p className="text-xs text-gray-500">
                              {education.startDate} - {education.endDate}
                            </p>
                          )}
                        </div>
                        <Button
                          onClick={() => handleRemovePendingEducation(index)}
                          variant="ghost"
                          size="sm"
                          className="text-red-600 hover:bg-red-50"
                        >
                          <X className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {pendingEducations.length > 0 && (
                <Button
                  onClick={handleSaveAllEducations}
                  disabled={isSavingEducations}
                  className="w-full bg-orange-600 hover:bg-orange-700"
                >
                  {isSavingEducations ? "Saving..." : `Save All ${pendingEducations.length} Education(s)`}
                </Button>
              )}
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Skills Modal */}
      <Dialog open={showAddSkillModal} onOpenChange={setShowAddSkillModal}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-xl font-bold text-purple-800">
              Add Skill
            </DialogTitle>
            {pendingSkills.length > 0 && (
              <p className="text-sm text-gray-600">
                {pendingSkills.length} skill(s) ready to save
              </p>
            )}
          </DialogHeader>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="space-y-4">
              <h3 className="font-semibold text-purple-700 border-b border-purple-200 pb-2">Add New Skill</h3>
              
              <form onSubmit={(e) => { e.preventDefault(); handleSaveSkill(); }} className="space-y-4">
                <div>
                  <Label htmlFor="skillName">Skill Name *</Label>
                  <Input
                    id="skillName"
                    value={newSkill.name}
                    onChange={(e) => setNewSkill({...newSkill, name: e.target.value})}
                    placeholder="e.g. JavaScript, Python, Marketing"
                    required
                  />
                </div>

                <div>
                  <Label htmlFor="skillCategory">Category</Label>
                  <Select
                    value={newSkill.category}
                    onValueChange={(value) => setNewSkill({...newSkill, category: value})}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select category" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Technical">Technical</SelectItem>
                      <SelectItem value="Soft Skills">Soft Skills</SelectItem>
                      <SelectItem value="Language">Language</SelectItem>
                      <SelectItem value="Tools">Tools</SelectItem>
                      <SelectItem value="Frameworks">Frameworks</SelectItem>
                      <SelectItem value="Other">Other</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="skillLevel">Proficiency Level: {newSkill.level}/5</Label>
                  <input
                    type="range"
                    id="skillLevel"
                    min="1"
                    max="5"
                    value={newSkill.level}
                    onChange={(e) => setNewSkill({...newSkill, level: parseInt(e.target.value)})}
                    className="w-full h-2 bg-purple-200 rounded-lg appearance-none cursor-pointer slider"
                  />
                  <div className="flex justify-between text-xs text-gray-600 mt-1">
                    <span>Beginner</span>
                    <span>Expert</span>
                  </div>
                </div>

                <div className="flex gap-3 pt-4">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => setShowAddSkillModal(false)}
                    className="flex-1"
                  >
                    Cancel
                  </Button>
                  <Button
                    type="submit"
                    className="flex-1 bg-purple-600 hover:bg-purple-700"
                  >
                    Add to Queue
                  </Button>
                </div>
              </form>
            </div>

            {/* Pending Skills Display */}
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="font-semibold text-purple-700 border-b border-purple-200 pb-2 flex-1">
                  Pending Skills ({pendingSkills.length})
                </h3>
                {pendingSkills.length > 0 && (
                  <Button
                    onClick={handleClearPendingSkills}
                    variant="outline"
                    size="sm"
                    className="ml-2 text-red-600 border-red-200 hover:bg-red-50"
                  >
                    Clear All
                  </Button>
                )}
              </div>

              {pendingSkills.length === 0 ? (
                <div className="text-center py-8 text-gray-500 bg-gray-50 rounded-lg border-2 border-dashed border-gray-200">
                  <p>No pending skills</p>
                  <p className="text-sm">Add skills using the form to see them here</p>
                </div>
              ) : (
                <div className="space-y-3 max-h-80 overflow-y-auto">
                  {pendingSkills.map((skill, index) => (
                    <div key={index} className="bg-purple-50 p-3 rounded-lg border border-purple-200">
                      <div className="flex justify-between items-start">
                        <div className="flex-1">
                          <h4 className="font-medium text-purple-800">{skill.name}</h4>
                          <p className="text-sm text-purple-600">{skill.category}</p>
                          <div className="flex items-center gap-2 mt-1">
                            <div className="flex gap-1">
                              {[1, 2, 3, 4, 5].map((star) => (
                                <div key={star} className={`w-3 h-3 rounded-full ${star <= skill.level ? 'bg-purple-500' : 'bg-gray-200'}`} />
                              ))}
                            </div>
                            <span className="text-xs text-purple-500">Level {skill.level}</span>
                          </div>
                        </div>
                        <Button
                          onClick={() => handleRemovePendingSkill(index)}
                          variant="ghost"
                          size="sm"
                          className="text-red-600 hover:bg-red-50"
                        >
                          <X className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {pendingSkills.length > 0 && (
                <Button
                  onClick={handleSaveAllSkills}
                  disabled={isSavingSkills}
                  className="w-full bg-purple-600 hover:bg-purple-700"
                >
                  {isSavingSkills ? "Saving..." : `Save All ${pendingSkills.length} Skill(s)`}
                </Button>
              )}
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Projects Modal */}
      <Dialog open={showAddProjectModal} onOpenChange={setShowAddProjectModal}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-xl font-bold text-indigo-800">
              Add Project
            </DialogTitle>
            {pendingProjects.length > 0 && (
              <p className="text-sm text-gray-600">
                {pendingProjects.length} project(s) ready to save
              </p>
            )}
          </DialogHeader>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="space-y-4">
              <h3 className="font-semibold text-indigo-700 border-b border-indigo-200 pb-2">Add New Project</h3>
              
              <form onSubmit={(e) => { e.preventDefault(); handleSaveProject(); }} className="space-y-4">
                <div>
                  <Label htmlFor="projectName">Project Name *</Label>
                  <Input
                    id="projectName"
                    value={newProject.name}
                    onChange={(e) => setNewProject({...newProject, name: e.target.value})}
                    placeholder="Enter project name"
                    required
                  />
                </div>

                <div>
                  <Label htmlFor="projectDescription">Description</Label>
                  <Textarea
                    id="projectDescription"
                    value={newProject.description}
                    onChange={(e) => setNewProject({...newProject, description: e.target.value})}
                    placeholder="Describe the project and your role"
                    rows={3}
                  />
                </div>

                <div>
                  <Label htmlFor="projectUrl">Project URL</Label>
                  <Input
                    id="projectUrl"
                    value={newProject.url}
                    onChange={(e) => setNewProject({...newProject, url: e.target.value})}
                    placeholder="https://example.com"
                  />
                </div>

                <div>
                  <Label htmlFor="projectGithub">GitHub URL</Label>
                  <Input
                    id="projectGithub"
                    value={newProject.githubUrl}
                    onChange={(e) => setNewProject({...newProject, githubUrl: e.target.value})}
                    placeholder="https://github.com/username/repository"
                  />
                </div>

                <div className="flex items-center space-x-2">
                  <input
                    type="checkbox"
                    id="projectFeatured"
                    checked={newProject.featured}
                    onChange={(e) => setNewProject({...newProject, featured: e.target.checked})}
                    className="rounded border-gray-300"
                  />
                  <Label htmlFor="projectFeatured">Feature this project</Label>
                </div>

                <div className="flex gap-3 pt-4">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => setShowAddProjectModal(false)}
                    className="flex-1"
                  >
                    Cancel
                  </Button>
                  <Button
                    type="submit"
                    className="flex-1 bg-indigo-600 hover:bg-indigo-700"
                  >
                    Add to Queue
                  </Button>
                </div>
              </form>
            </div>

            {/* Pending Projects Display */}
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="font-semibold text-indigo-700 border-b border-indigo-200 pb-2 flex-1">
                  Pending Projects ({pendingProjects.length})
                </h3>
                {pendingProjects.length > 0 && (
                  <Button
                    onClick={handleClearPendingProjects}
                    variant="outline"
                    size="sm"
                    className="ml-2 text-red-600 border-red-200 hover:bg-red-50"
                  >
                    Clear All
                  </Button>
                )}
              </div>

              {pendingProjects.length === 0 ? (
                <div className="text-center py-8 text-gray-500 bg-gray-50 rounded-lg border-2 border-dashed border-gray-200">
                  <p>No pending projects</p>
                  <p className="text-sm">Add projects using the form to see them here</p>
                </div>
              ) : (
                <div className="space-y-3 max-h-80 overflow-y-auto">
                  {pendingProjects.map((project, index) => (
                    <div key={index} className="bg-indigo-50 p-3 rounded-lg border border-indigo-200">
                      <div className="flex justify-between items-start">
                        <div className="flex-1">
                          <h4 className="font-medium text-indigo-800">{project.name}</h4>
                          <p className="text-sm text-indigo-600">{project.description}</p>
                          {project.featured && (
                            <Badge variant="secondary" className="mt-1">Featured</Badge>
                          )}
                        </div>
                        <Button
                          onClick={() => handleRemovePendingProject(index)}
                          variant="ghost"
                          size="sm"
                          className="text-red-600 hover:bg-red-50"
                        >
                          <X className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {pendingProjects.length > 0 && (
                <Button
                  onClick={handleSaveAllProjects}
                  disabled={isSavingProjects}
                  className="w-full bg-indigo-600 hover:bg-indigo-700"
                >
                  {isSavingProjects ? "Saving..." : `Save All ${pendingProjects.length} Project(s)`}
                </Button>
              )}
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </PlatformLayout>
  );
}