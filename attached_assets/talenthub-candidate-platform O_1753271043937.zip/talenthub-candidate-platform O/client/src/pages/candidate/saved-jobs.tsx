import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { 
  Star, 
  Search, 
  Filter, 
  Building, 
  MapPin, 
  DollarSign, 
  Clock,
  Briefcase,
  Eye,
  ExternalLink,
  Trash2,
  Calendar,
  Users,
  TrendingUp,
  BookmarkMinus
} from "lucide-react";
import PlatformLayout from "@/components/layout/platform-layout";
import { platformConfigs } from "@/config/complete-navigation";

function SavedJobsContent() {
  const { toast } = useToast();
  const [searchTerm, setSearchTerm] = useState("");
  const [sortBy, setSortBy] = useState("saved_date");
  const [filterBy, setFilterBy] = useState("all");
  
  // Modal states
  const [applyModalOpen, setApplyModalOpen] = useState(false);
  const [viewDetailsModalOpen, setViewDetailsModalOpen] = useState(false);
  const [unsaveModalOpen, setUnsaveModalOpen] = useState(false);
  const [selectedJob, setSelectedJob] = useState<any>(null);
  
  // Application form state
  const [applicationForm, setApplicationForm] = useState({
    coverLetter: "",
    resume: "",
    additionalNotes: "",
    expectedSalary: "",
    availableStartDate: ""
  });

  const savedJobs = [
    {
      id: "1",
      title: "Senior Frontend Developer",
      company: "TechCorp Inc.",
      location: "San Francisco, CA",
      salary: "$130,000 - $160,000",
      type: "Full-time",
      remote: true,
      savedAt: "2024-01-20",
      postedAt: "2024-01-18",
      applicants: 47,
      status: "active",
      skills: ["React", "TypeScript", "Node.js"],
      description: "We're looking for a passionate Senior Frontend Developer to join our growing team...",
      applied: false,
      matchScore: 95
    },
    {
      id: "2",
      title: "Full Stack Engineer",
      company: "StartupXYZ",
      location: "Remote",
      salary: "$120,000 - $150,000",
      type: "Full-time",
      remote: true,
      savedAt: "2024-01-19",
      postedAt: "2024-01-15",
      applicants: 32,
      status: "active",
      skills: ["React", "Python", "AWS"],
      description: "Join our innovative team building the next generation of...",
      applied: true,
      matchScore: 88
    },
    {
      id: "3",
      title: "UI/UX Developer",
      company: "Design Studio",
      location: "New York, NY",
      salary: "$95,000 - $125,000",
      type: "Full-time",
      remote: false,
      savedAt: "2024-01-17",
      postedAt: "2024-01-12",
      applicants: 89,
      status: "closing_soon",
      skills: ["Figma", "React", "CSS"],
      description: "Creative UI/UX Developer needed to craft beautiful user experiences...",
      applied: false,
      matchScore: 82
    },
    {
      id: "4",
      title: "Backend Developer",
      company: "Enterprise Corp",
      location: "Seattle, WA",
      salary: "$115,000 - $145,000",
      type: "Contract",
      remote: true,
      savedAt: "2024-01-15",
      postedAt: "2024-01-10",
      applicants: 64,
      status: "expired",
      skills: ["Node.js", "MongoDB", "Docker"],
      description: "Looking for an experienced Backend Developer to work on...",
      applied: false,
      matchScore: 76
    }
  ];

  // Handler functions
  const handleApplyNow = (job: any) => {
    setSelectedJob(job);
    setApplyModalOpen(true);
  };

  const handleViewDetails = (job: any) => {
    setSelectedJob(job);
    setViewDetailsModalOpen(true);
  };

  const handleOriginal = (job: any) => {
    // Open original job posting in new window/tab
    const originalUrl = `https://company-careers.com/jobs/${job.id}`;
    window.open(originalUrl, '_blank');
    toast({
      title: "Opening Original Posting",
      description: `Redirecting to ${job.company}'s career page`
    });
  };

  const handleUnsave = (job: any) => {
    setSelectedJob(job);
    setUnsaveModalOpen(true);
  };

  const handleSubmitApplication = async () => {
    if (!selectedJob || !applicationForm.coverLetter.trim()) {
      toast({
        title: "Validation Error",
        description: "Please provide a cover letter",
        variant: "destructive"
      });
      return;
    }

    try {
      // Simulate API call
      if (import.meta.env.DEV) {
        await new Promise(resolve => setTimeout(resolve, 1500));
        
        toast({
          title: "Application Submitted!",
          description: `Your application for ${selectedJob.title} has been submitted successfully.`
        });

        // Reset form and close modal
        setApplicationForm({
          coverLetter: "",
          resume: "",
          additionalNotes: "",
          expectedSalary: "",
          availableStartDate: ""
        });
        setApplyModalOpen(false);
      }
    } catch (error) {
      toast({
        title: "Application Failed",
        description: "There was an error submitting your application. Please try again.",
        variant: "destructive"
      });
    }
  };

  const handleConfirmUnsave = () => {
    if (selectedJob) {
      toast({
        title: "Job Unsaved",
        description: `${selectedJob.title} has been removed from your saved jobs.`
      });
      setUnsaveModalOpen(false);
    }
  };

  const getStatusBadge = (status: string, applied: boolean) => {
    if (applied) {
      return <Badge className="bg-blue-100 text-blue-700">Applied</Badge>;
    }
    
    switch (status) {
      case "active":
        return <Badge className="bg-green-100 text-green-700">Active</Badge>;
      case "closing_soon":
        return <Badge className="bg-orange-100 text-orange-700">Closing Soon</Badge>;
      case "expired":
        return <Badge className="bg-red-100 text-red-700">Expired</Badge>;
      default:
        return <Badge className="bg-gray-100 text-gray-700">Unknown</Badge>;
    }
  };

  const getMatchScoreColor = (score: number) => {
    if (score >= 90) return "text-green-600";
    if (score >= 80) return "text-yellow-600";
    return "text-red-600";
  };

  const filteredJobs = savedJobs.filter(job => {
    const matchesSearch = job.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         job.company.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         job.skills.some(skill => skill.toLowerCase().includes(searchTerm.toLowerCase()));
    
    if (filterBy === "all") return matchesSearch;
    if (filterBy === "applied") return matchesSearch && job.applied;
    if (filterBy === "not_applied") return matchesSearch && !job.applied;
    if (filterBy === "remote") return matchesSearch && job.remote;
    if (filterBy === "active") return matchesSearch && job.status === "active";
    
    return matchesSearch;
  });

  const stats = {
    total: savedJobs.length,
    applied: savedJobs.filter(job => job.applied).length,
    active: savedJobs.filter(job => job.status === "active").length,
    remote: savedJobs.filter(job => job.remote).length
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-sky-50 to-white p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Saved Jobs</h1>
          <p className="text-gray-600">Keep track of interesting job opportunities for future reference</p>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card className="border-sky-200">
            <CardContent className="p-6 text-center">
              <Star className="h-8 w-8 text-sky-600 mx-auto mb-2" />
              <div className="text-2xl font-bold text-sky-700">{stats.total}</div>
              <div className="text-sm text-gray-600">Total Saved</div>
            </CardContent>
          </Card>
          <Card className="border-blue-200">
            <CardContent className="p-6 text-center">
              <Briefcase className="h-8 w-8 text-blue-600 mx-auto mb-2" />
              <div className="text-2xl font-bold text-blue-700">{stats.applied}</div>
              <div className="text-sm text-gray-600">Applied</div>
            </CardContent>
          </Card>
          <Card className="border-green-200">
            <CardContent className="p-6 text-center">
              <TrendingUp className="h-8 w-8 text-green-600 mx-auto mb-2" />
              <div className="text-2xl font-bold text-green-700">{stats.active}</div>
              <div className="text-sm text-gray-600">Still Active</div>
            </CardContent>
          </Card>
          <Card className="border-purple-200">
            <CardContent className="p-6 text-center">
              <Users className="h-8 w-8 text-purple-600 mx-auto mb-2" />
              <div className="text-2xl font-bold text-purple-700">{stats.remote}</div>
              <div className="text-sm text-gray-600">Remote Jobs</div>
            </CardContent>
          </Card>
        </div>

        {/* Filters */}
        <Card className="mb-6">
          <CardContent className="p-6">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="flex-1">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                  <Input
                    placeholder="Search saved jobs by title, company, or skills..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                  />
                </div>
              </div>
              <div className="flex gap-4">
                <Select value={filterBy} onValueChange={setFilterBy}>
                  <SelectTrigger className="w-48">
                    <Filter className="h-4 w-4 mr-2" />
                    <SelectValue placeholder="Filter by" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Jobs</SelectItem>
                    <SelectItem value="applied">Applied</SelectItem>
                    <SelectItem value="not_applied">Not Applied</SelectItem>
                    <SelectItem value="remote">Remote Only</SelectItem>
                    <SelectItem value="active">Active Jobs</SelectItem>
                  </SelectContent>
                </Select>
                <Select value={sortBy} onValueChange={setSortBy}>
                  <SelectTrigger className="w-48">
                    <SelectValue placeholder="Sort by" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="saved_date">Date Saved</SelectItem>
                    <SelectItem value="posted_date">Date Posted</SelectItem>
                    <SelectItem value="match_score">Match Score</SelectItem>
                    <SelectItem value="salary">Salary</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Saved Jobs List */}
        <div className="space-y-4">
          {filteredJobs.length === 0 ? (
            <Card>
              <CardContent className="p-12 text-center">
                <Star className="h-16 w-16 text-gray-300 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-2">No saved jobs found</h3>
                <p className="text-gray-600">Try adjusting your search criteria or browse new jobs to save.</p>
              </CardContent>
            </Card>
          ) : (
            filteredJobs.map((job) => (
              <Card key={job.id} className="hover:shadow-lg transition-shadow">
                <CardContent className="p-6">
                  <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
                    {/* Main Job Info */}
                    <div className="flex-1">
                      <div className="flex items-start justify-between mb-3">
                        <div>
                          <h3 className="text-lg font-semibold text-gray-900 mb-1">
                            {job.title}
                          </h3>
                          <div className="flex items-center gap-4 text-sm text-gray-600">
                            <div className="flex items-center gap-1">
                              <Building className="h-4 w-4" />
                              {job.company}
                            </div>
                            <div className="flex items-center gap-1">
                              <MapPin className="h-4 w-4" />
                              {job.location}
                            </div>
                            <div className="flex items-center gap-1">
                              <Briefcase className="h-4 w-4" />
                              {job.type}
                            </div>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          {getStatusBadge(job.status, job.applied)}
                          <div className={`text-lg font-bold ${getMatchScoreColor(job.matchScore)}`}>
                            {job.matchScore}%
                          </div>
                        </div>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4 text-sm">
                        <div className="flex items-center gap-1">
                          <DollarSign className="h-4 w-4 text-gray-400" />
                          <span className="font-medium text-green-600">{job.salary}</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <Users className="h-4 w-4 text-gray-400" />
                          <span>{job.applicants} applicants</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <Clock className="h-4 w-4 text-gray-400" />
                          <span>Posted {job.postedAt}</span>
                        </div>
                      </div>

                      <div className="mb-4">
                        <p className="text-sm text-gray-600 mb-2">{job.description}</p>
                        <div className="flex flex-wrap gap-2">
                          {job.skills.map((skill) => (
                            <Badge key={skill} variant="outline" className="text-xs">
                              {skill}
                            </Badge>
                          ))}
                          {job.remote && (
                            <Badge className="text-xs bg-purple-100 text-purple-700">
                              Remote
                            </Badge>
                          )}
                        </div>
                      </div>

                      <div className="text-xs text-gray-500">
                        Saved on {job.savedAt}
                      </div>
                    </div>

                    {/* Actions */}
                    <div className="flex flex-col gap-2 lg:w-48">
                      <Button 
                        className="w-full bg-sky-600 hover:bg-sky-700" 
                        disabled={job.applied || job.status === "expired"}
                        onClick={() => handleApplyNow(job)}
                      >
                        {job.applied ? "Applied" : job.status === "expired" ? "Expired" : "Apply Now"}
                      </Button>
                      <Button variant="outline" className="w-full" onClick={() => handleViewDetails(job)}>
                        <Eye className="h-4 w-4 mr-2" />
                        View Details
                      </Button>
                      <div className="flex gap-2">
                        <Button variant="outline" size="sm" className="flex-1" onClick={() => handleOriginal(job)}>
                          <ExternalLink className="h-4 w-4 mr-2" />
                          Original
                        </Button>
                        <Button variant="outline" size="sm" className="flex-1" onClick={() => handleUnsave(job)}>
                          <BookmarkMinus className="h-4 w-4 mr-2" />
                          Unsave
                        </Button>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))
          )}
        </div>

        {/* Quick Actions */}
        {filteredJobs.length > 0 && (
          <Card className="mt-6">
            <CardContent className="p-6">
              <div className="flex justify-between items-center">
                <div>
                  <h3 className="font-medium text-gray-900">Bulk Actions</h3>
                  <p className="text-sm text-gray-600">Manage multiple saved jobs at once</p>
                </div>
                <div className="flex gap-3">
                  <Button variant="outline">
                    Remove Expired Jobs
                  </Button>
                  <Button variant="outline">
                    Export to CSV
                  </Button>
                  <Button className="bg-sky-600 hover:bg-sky-700">
                    Apply to Selected
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        )}
      </div>

      {/* Modal Dialogs */}
      
      {/* Apply Now Modal */}
      <Dialog open={applyModalOpen} onOpenChange={setApplyModalOpen}>
        <DialogContent className="max-w-3xl">
          <DialogHeader>
            <DialogTitle>Apply for Position</DialogTitle>
            <DialogDescription>
              Submit your application for this position
            </DialogDescription>
          </DialogHeader>
          {selectedJob && (
            <div className="space-y-6">
              <div className="bg-sky-50 p-4 rounded-lg">
                <h4 className="font-semibold text-sky-900">{selectedJob.title}</h4>
                <p className="text-sky-700">{selectedJob.company} • {selectedJob.location}</p>
                <p className="text-sm text-sky-600">{selectedJob.salary}</p>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="expected-salary">Expected Salary (Optional)</Label>
                  <Input
                    id="expected-salary"
                    placeholder="$120,000"
                    value={applicationForm.expectedSalary}
                    onChange={(e) => setApplicationForm(prev => ({ ...prev, expectedSalary: e.target.value }))}
                  />
                </div>
                <div>
                  <Label htmlFor="start-date">Available Start Date</Label>
                  <Input
                    id="start-date"
                    type="date"
                    value={applicationForm.availableStartDate}
                    onChange={(e) => setApplicationForm(prev => ({ ...prev, availableStartDate: e.target.value }))}
                  />
                </div>
              </div>
              
              <div>
                <Label htmlFor="resume-selection">Resume</Label>
                <Select value={applicationForm.resume} onValueChange={(value) => setApplicationForm(prev => ({ ...prev, resume: value }))}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select resume to use" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="default">Default Resume.pdf</SelectItem>
                    <SelectItem value="tech">Tech Resume - Updated.pdf</SelectItem>
                    <SelectItem value="frontend">Frontend Developer Resume.pdf</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div>
                <Label htmlFor="cover-letter">Cover Letter *</Label>
                <Textarea
                  id="cover-letter"
                  placeholder="Write your cover letter here..."
                  value={applicationForm.coverLetter}
                  onChange={(e) => setApplicationForm(prev => ({ ...prev, coverLetter: e.target.value }))}
                  rows={8}
                />
              </div>
              
              <div>
                <Label htmlFor="additional-notes">Additional Notes</Label>
                <Textarea
                  id="additional-notes"
                  placeholder="Any additional information you'd like to include..."
                  value={applicationForm.additionalNotes}
                  onChange={(e) => setApplicationForm(prev => ({ ...prev, additionalNotes: e.target.value }))}
                  rows={3}
                />
              </div>
              
              <div className="flex justify-end gap-2">
                <Button variant="outline" onClick={() => setApplyModalOpen(false)}>
                  Cancel
                </Button>
                <Button onClick={handleSubmitApplication} className="bg-sky-600 hover:bg-sky-700">
                  Submit Application
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* View Details Modal */}
      <Dialog open={viewDetailsModalOpen} onOpenChange={setViewDetailsModalOpen}>
        <DialogContent className="max-w-4xl">
          <DialogHeader>
            <DialogTitle>Job Details</DialogTitle>
            <DialogDescription>
              Complete information about this position
            </DialogDescription>
          </DialogHeader>
          {selectedJob && (
            <div className="space-y-6">
              <div className="grid grid-cols-2 gap-6">
                <div>
                  <h3 className="text-2xl font-bold text-gray-900">{selectedJob.title}</h3>
                  <div className="flex items-center gap-2 mt-2">
                    <Building className="h-4 w-4 text-gray-500" />
                    <span className="text-lg text-gray-700">{selectedJob.company}</span>
                  </div>
                  <div className="flex items-center gap-2 mt-1">
                    <MapPin className="h-4 w-4 text-gray-500" />
                    <span className="text-gray-600">{selectedJob.location}</span>
                    {selectedJob.remote && <Badge variant="outline">Remote</Badge>}
                  </div>
                </div>
                
                <div className="space-y-3">
                  <div className="flex items-center gap-2">
                    <DollarSign className="h-4 w-4 text-gray-500" />
                    <span className="font-semibold">{selectedJob.salary}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Briefcase className="h-4 w-4 text-gray-500" />
                    <span>{selectedJob.type}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Users className="h-4 w-4 text-gray-500" />
                    <span>{selectedJob.applicants} applicants</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <TrendingUp className="h-4 w-4 text-gray-500" />
                    <span>{selectedJob.matchScore}% match</span>
                  </div>
                </div>
              </div>
              
              <div>
                <h4 className="font-semibold text-gray-900 mb-2">Required Skills</h4>
                <div className="flex flex-wrap gap-2">
                  {selectedJob.skills.map((skill: string, index: number) => (
                    <Badge key={index} variant="outline" className="bg-sky-50 text-sky-700">
                      {skill}
                    </Badge>
                  ))}
                </div>
              </div>
              
              <div>
                <h4 className="font-semibold text-gray-900 mb-2">Job Description</h4>
                <p className="text-gray-700 leading-relaxed">{selectedJob.description}</p>
              </div>
              
              <div className="grid grid-cols-2 gap-4 pt-4 border-t">
                <div>
                  <span className="text-sm text-gray-500">Posted Date:</span>
                  <p className="font-medium">{new Date(selectedJob.postedAt).toLocaleDateString()}</p>
                </div>
                <div>
                  <span className="text-sm text-gray-500">Saved Date:</span>
                  <p className="font-medium">{new Date(selectedJob.savedAt).toLocaleDateString()}</p>
                </div>
              </div>
              
              <div className="flex justify-end gap-2">
                <Button variant="outline" onClick={() => setViewDetailsModalOpen(false)}>
                  Close
                </Button>
                <Button 
                  onClick={() => {
                    setViewDetailsModalOpen(false);
                    handleApplyNow(selectedJob);
                  }}
                  className="bg-sky-600 hover:bg-sky-700"
                  disabled={selectedJob.applied || selectedJob.status === "expired"}
                >
                  {selectedJob.applied ? "Already Applied" : selectedJob.status === "expired" ? "Expired" : "Apply Now"}
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Unsave Confirmation Modal */}
      <Dialog open={unsaveModalOpen} onOpenChange={setUnsaveModalOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Remove from Saved Jobs</DialogTitle>
            <DialogDescription>
              Are you sure you want to remove this job from your saved list?
            </DialogDescription>
          </DialogHeader>
          {selectedJob && (
            <div className="space-y-4">
              <div className="bg-gray-50 p-4 rounded-lg">
                <h4 className="font-semibold text-gray-900">{selectedJob.title}</h4>
                <p className="text-gray-600">{selectedJob.company}</p>
                <p className="text-sm text-gray-500">Saved on {new Date(selectedJob.savedAt).toLocaleDateString()}</p>
              </div>
              
              <div className="flex justify-end gap-2">
                <Button variant="outline" onClick={() => setUnsaveModalOpen(false)}>
                  Keep Saved
                </Button>
                <Button variant="destructive" onClick={handleConfirmUnsave}>
                  Remove from Saved
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}

export default function SavedJobs() {
  const config = platformConfigs.candidate;
  
  const usageData = [
    { label: "Saved Jobs", current: 12, max: 50 },
    { label: "Applied", current: 8, max: 25 },
    { label: "Shortlisted", current: 3, max: 10 },
  ];

  return (
    <PlatformLayout
      sidebarTitle={config.sidebarTitle}
      sidebarSubtitle={config.sidebarSubtitle}
      sidebarSections={config.sidebarSections}
      usageData={usageData}
    >
      <SavedJobsContent />
    </PlatformLayout>
  );
}

