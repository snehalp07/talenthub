import PlatformLayout from "@/components/layout/platform-layout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { FolderOpen, Star, GitBranch, Eye, Code, TrendingUp, ArrowUp, ArrowDown } from "lucide-react";
import { candidateNavigation } from "@/config/complete-navigation";

export default function PortfolioAnalytics() {
  const portfolioMetrics = [
    { label: "Total Projects", value: "12", change: 2, color: "bg-blue-500", icon: FolderOpen },
    { label: "Portfolio Views", value: "1,247", change: 23, color: "bg-green-500", icon: Eye },
    { label: "GitHub Stars", value: "156", change: 8, color: "bg-purple-500", icon: Star },
    { label: "Code Quality Score", value: "92%", change: 5, color: "bg-orange-500", icon: Code }
  ];

  const projectPerformance = [
    {
      id: 1,
      name: "E-commerce Platform",
      technology: "React + Node.js",
      views: 342,
      stars: 45,
      forks: 12,
      commits: 127,
      status: "Active",
      impact: "High"
    },
    {
      id: 2,
      name: "Task Management App",
      technology: "Vue.js + Python",
      views: 198,
      stars: 28,
      forks: 7,
      commits: 89,
      status: "Completed",
      impact: "Medium"
    },
    {
      id: 3,
      name: "Data Visualization Tool",
      technology: "D3.js + Express",
      views: 156,
      stars: 33,
      forks: 9,
      commits: 67,
      status: "Active",
      impact: "High"
    }
  ];

  const skillDistribution = [
    { skill: "Frontend Development", projects: 8, percentage: 67 },
    { skill: "Backend Development", projects: 6, percentage: 50 },
    { skill: "Full Stack", projects: 4, percentage: 33 },
    { skill: "Data Science", projects: 3, percentage: 25 },
    { skill: "Mobile Development", projects: 2, percentage: 17 }
  ];

  const techStackUsage = [
    { tech: "JavaScript", usage: 92, projects: 11 },
    { tech: "React", usage: 75, projects: 9 },
    { tech: "Node.js", usage: 67, projects: 8 },
    { tech: "Python", usage: 50, projects: 6 },
    { tech: "TypeScript", usage: 42, projects: 5 }
  ];

  return (
    <PlatformLayout 
      sidebarTitle="Candidate Platform"
      sidebarSubtitle="Professional Development Hub"
      sidebarSections={candidateNavigation}
    >
      <div className="max-w-7xl mx-auto p-6 space-y-8">
        <div className="text-center space-y-4">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-slate-100 to-gray-100 rounded-full">
            <FolderOpen className="h-5 w-5 text-slate-600" />
            <span className="text-sm font-medium text-slate-900">Portfolio Analytics</span>
          </div>
          <h1 className="text-4xl font-bold bg-gradient-to-r from-slate-600 to-gray-600 bg-clip-text text-transparent">
            Project Portfolio Insights
          </h1>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            Analyze your project portfolio performance, technology usage, and professional impact
          </p>
        </div>

        {/* Portfolio Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {portfolioMetrics.map((metric, index) => {
            const IconComponent = metric.icon;
            return (
              <Card key={index} className="hover:shadow-md transition-shadow">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between mb-4">
                    <div className={`p-3 rounded-lg ${metric.color} text-white`}>
                      <IconComponent className="h-6 w-6" />
                    </div>
                    <div className={`flex items-center gap-1 px-2 py-1 rounded-full text-sm ${
                      Number(metric.change) > 0 ? 'bg-emerald-100 text-emerald-700' : 'bg-red-100 text-red-700'
                    }`}>
                      {Number(metric.change) > 0 ? <ArrowUp className="h-3 w-3" /> : <ArrowDown className="h-3 w-3" />}
                      {Math.abs(Number(metric.change))}
                    </div>
                  </div>
                  <div className="text-2xl font-bold text-gray-900 mb-1">{metric.value}</div>
                  <div className="text-sm text-gray-600">{metric.label}</div>
                </CardContent>
              </Card>
            );
          })}
        </div>

        <Tabs defaultValue="overview" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="projects">Project Performance</TabsTrigger>
            <TabsTrigger value="skills">Skill Distribution</TabsTrigger>
            <TabsTrigger value="technology">Tech Stack</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Portfolio Growth</CardTitle>
                  <CardDescription>Project and engagement growth over time</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="h-64 flex items-center justify-center text-gray-500">
                    <div className="text-center">
                      <TrendingUp className="h-12 w-12 mx-auto mb-2" />
                      <p>Portfolio growth chart visualization</p>
                      <div className="mt-4 space-y-2 text-sm">
                        <div className="flex justify-between">
                          <span>Projects this year:</span>
                          <span className="font-medium text-slate-600">+5</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Avg. monthly views:</span>
                          <span className="font-medium text-green-600">412</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Impact Summary</CardTitle>
                  <CardDescription>Overall portfolio impact and reach</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between p-4 bg-blue-50 rounded-lg">
                      <div>
                        <div className="font-medium text-blue-900">High Impact Projects</div>
                        <div className="text-sm text-blue-600">7 projects driving significant engagement</div>
                      </div>
                      <div className="text-2xl font-bold text-blue-600">58%</div>
                    </div>
                    <div className="flex items-center justify-between p-4 bg-green-50 rounded-lg">
                      <div>
                        <div className="font-medium text-green-900">Community Engagement</div>
                        <div className="text-sm text-green-600">Stars, forks, and contributions</div>
                      </div>
                      <div className="text-2xl font-bold text-green-600">156</div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="projects" className="space-y-6">
            <div className="grid gap-6">
              {projectPerformance.map((project) => (
                <Card key={project.id} className="hover:shadow-md transition-shadow">
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div className="space-y-2">
                        <CardTitle className="text-lg">{project.name}</CardTitle>
                        <CardDescription>{project.technology}</CardDescription>
                      </div>
                      <div className="flex items-center gap-2">
                        <Badge variant={project.status === 'Active' ? 'default' : 'secondary'}>
                          {project.status}
                        </Badge>
                        <Badge variant={project.impact === 'High' ? 'destructive' : 'outline'}>
                          {project.impact} Impact
                        </Badge>
                      </div>
                    </div>
                  </CardHeader>

                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-4 gap-4 text-center">
                      <div>
                        <div className="text-lg font-bold text-slate-600">{project.views}</div>
                        <div className="text-sm text-gray-600">Views</div>
                      </div>
                      <div>
                        <div className="text-lg font-bold text-yellow-600">{project.stars}</div>
                        <div className="text-sm text-gray-600">Stars</div>
                      </div>
                      <div>
                        <div className="text-lg font-bold text-blue-600">{project.forks}</div>
                        <div className="text-sm text-gray-600">Forks</div>
                      </div>
                      <div>
                        <div className="text-lg font-bold text-green-600">{project.commits}</div>
                        <div className="text-sm text-gray-600">Commits</div>
                      </div>
                    </div>

                    <div className="flex items-center justify-between pt-4 border-t">
                      <div className="flex items-center gap-2">
                        <GitBranch className="h-4 w-4 text-gray-500" />
                        <span className="text-sm text-gray-600">
                          Last updated: 2 days ago
                        </span>
                      </div>
                      <Button size="sm" className="bg-gradient-to-r from-slate-600 to-gray-600 hover:from-slate-700 hover:to-gray-700">
                        View Project
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="skills" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Skill Distribution Across Projects</CardTitle>
                <CardDescription>How your skills are represented in your portfolio</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  {skillDistribution.map((skill, index) => (
                    <div key={index} className="space-y-3">
                      <div className="flex items-center justify-between">
                        <span className="font-medium text-gray-900">{skill.skill}</span>
                        <div className="flex items-center gap-2">
                          <span className="text-sm text-gray-600">{skill.projects} projects</span>
                          <Badge variant="outline">{skill.percentage}%</Badge>
                        </div>
                      </div>
                      <Progress value={skill.percentage} className="h-2" />
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="technology" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Technology Stack Usage</CardTitle>
                <CardDescription>Technologies used across your portfolio projects</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  {techStackUsage.map((tech, index) => (
                    <div key={index} className="space-y-3">
                      <div className="flex items-center justify-between">
                        <span className="font-medium text-gray-900">{tech.tech}</span>
                        <div className="flex items-center gap-2">
                          <span className="text-sm text-gray-600">{tech.projects} projects</span>
                          <Badge className="bg-slate-600 hover:bg-slate-700">{tech.usage}%</Badge>
                        </div>
                      </div>
                      <Progress value={tech.usage} className="h-2" />
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </PlatformLayout>
  );
}