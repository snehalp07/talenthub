import PlatformLayout from "@/components/layout/platform-layout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { BookOpen, TrendingUp, Award, Clock, Target, Brain, ArrowUp, ArrowDown } from "lucide-react";
import { candidateNavigation } from "@/config/complete-navigation";

export default function LearningAnalytics() {
  const learningMetrics = [
    { label: "Courses Completed", value: "18", change: 3, color: "bg-green-500", icon: BookOpen },
    { label: "Learning Hours", value: "124", change: 12, color: "bg-blue-500", icon: Clock },
    { label: "Certificates Earned", value: "7", change: 2, color: "bg-purple-500", icon: Award },
    { label: "Skill Improvement", value: "23%", change: 8, color: "bg-orange-500", icon: TrendingUp }
  ];

  const courseProgress = [
    {
      id: 1,
      title: "Advanced React Development",
      provider: "Tech Academy",
      progress: 85,
      hoursSpent: 24,
      totalHours: 30,
      difficulty: "Advanced",
      rating: 4.8,
      skills: ["React", "Redux", "TypeScript"]
    },
    {
      id: 2,
      title: "AWS Cloud Practitioner",
      provider: "Amazon Web Services",
      progress: 65,
      hoursSpent: 18,
      totalHours: 28,
      difficulty: "Intermediate",
      rating: 4.6,
      skills: ["AWS", "Cloud Computing", "Security"]
    },
    {
      id: 3,
      title: "Data Structures & Algorithms",
      provider: "Code University",
      progress: 45,
      hoursSpent: 15,
      totalHours: 35,
      difficulty: "Advanced",
      rating: 4.9,
      skills: ["Algorithms", "Data Structures", "Problem Solving"]
    }
  ];

  const skillDevelopment = [
    { skill: "Frontend Development", current: 88, target: 95, improvement: "+12%" },
    { skill: "Cloud Computing", current: 72, target: 85, improvement: "+18%" },
    { skill: "Data Science", current: 65, target: 80, improvement: "+15%" },
    { skill: "DevOps", current: 58, target: 75, improvement: "+22%" }
  ];

  const learningPath = [
    { phase: "Foundation", status: "Completed", courses: 5, progress: 100 },
    { phase: "Intermediate", status: "In Progress", courses: 8, progress: 75 },
    { phase: "Advanced", status: "Not Started", courses: 6, progress: 0 },
    { phase: "Specialization", status: "Planned", courses: 4, progress: 0 }
  ];

  return (
    <PlatformLayout 
      sidebarTitle="Candidate Platform"
      sidebarSubtitle="Professional Development Hub"
      sidebarSections={candidateNavigation}
    >
      <div className="max-w-7xl mx-auto p-6 space-y-8">
        <div className="text-center space-y-4">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-emerald-100 to-green-100 rounded-full">
            <Brain className="h-5 w-5 text-emerald-600" />
            <span className="text-sm font-medium text-emerald-900">Learning Path Analytics</span>
          </div>
          <h1 className="text-4xl font-bold bg-gradient-to-r from-emerald-600 to-green-600 bg-clip-text text-transparent">
            Learning Progress Dashboard
          </h1>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            Track your educational journey, monitor skill development, and optimize your learning strategy
          </p>
        </div>

        {/* Learning Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {learningMetrics.map((metric, index) => {
            const IconComponent = metric.icon;
            return (
              <Card key={index} className="hover:shadow-md transition-shadow">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between mb-4">
                    <div className={`p-3 rounded-lg ${metric.color} text-white`}>
                      <IconComponent className="h-6 w-6" />
                    </div>
                    <div className={`flex items-center gap-1 px-2 py-1 rounded-full text-sm ${
                      Number(metric.change) > 0 ? 'bg-emerald-100 text-emerald-700' : 'bg-red-100 text-red-700'
                    }`}>
                      {Number(metric.change) > 0 ? <ArrowUp className="h-3 w-3" /> : <ArrowDown className="h-3 w-3" />}
                      {Math.abs(Number(metric.change))}
                    </div>
                  </div>
                  <div className="text-2xl font-bold text-gray-900 mb-1">{metric.value}</div>
                  <div className="text-sm text-gray-600">{metric.label}</div>
                </CardContent>
              </Card>
            );
          })}
        </div>

        <Tabs defaultValue="overview" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="courses">Course Progress</TabsTrigger>
            <TabsTrigger value="skills">Skill Development</TabsTrigger>
            <TabsTrigger value="path">Learning Path</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Learning Velocity</CardTitle>
                  <CardDescription>Your learning progress over time</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="h-64 flex items-center justify-center text-gray-500">
                    <div className="text-center">
                      <TrendingUp className="h-12 w-12 mx-auto mb-2" />
                      <p>Learning velocity chart visualization</p>
                      <div className="mt-4 space-y-2 text-sm">
                        <div className="flex justify-between">
                          <span>This month:</span>
                          <span className="font-medium text-emerald-600">+12 hours</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Avg. daily:</span>
                          <span className="font-medium text-green-600">2.3 hours</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Learning Path Progress</CardTitle>
                  <CardDescription>Overall progress across your learning journey</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {learningPath.map((phase, index) => (
                      <div key={index} className="space-y-2">
                        <div className="flex items-center justify-between">
                          <span className="font-medium text-gray-900">{phase.phase}</span>
                          <Badge variant={phase.status === 'Completed' ? 'default' : phase.status === 'In Progress' ? 'secondary' : 'outline'}>
                            {phase.status}
                          </Badge>
                        </div>
                        <Progress value={phase.progress} className="h-2" />
                        <div className="text-xs text-gray-500">{phase.courses} courses • {phase.progress}% complete</div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="courses" className="space-y-6">
            <div className="grid gap-6">
              {courseProgress.map((course) => (
                <Card key={course.id} className="hover:shadow-md transition-shadow">
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div className="space-y-2">
                        <CardTitle className="text-lg">{course.title}</CardTitle>
                        <CardDescription>{course.provider}</CardDescription>
                      </div>
                      <div className="text-right space-y-2">
                        <Badge variant="outline">{course.difficulty}</Badge>
                        <div className="text-2xl font-bold text-emerald-600">{course.progress}%</div>
                      </div>
                    </div>
                  </CardHeader>

                  <CardContent className="space-y-4">
                    <Progress value={course.progress} className="h-3" />
                    
                    <div className="grid grid-cols-3 gap-4">
                      <div className="text-center">
                        <div className="text-lg font-bold text-blue-600">{course.hoursSpent}</div>
                        <div className="text-sm text-gray-600">Hours Spent</div>
                      </div>
                      <div className="text-center">
                        <div className="text-lg font-bold text-gray-600">{course.totalHours}</div>
                        <div className="text-sm text-gray-600">Total Hours</div>
                      </div>
                      <div className="text-center">
                        <div className="text-lg font-bold text-yellow-600">{course.rating}</div>
                        <div className="text-sm text-gray-600">Rating</div>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <div className="text-sm font-medium text-gray-900">Skills You'll Learn</div>
                      <div className="flex flex-wrap gap-2">
                        {course.skills.map((skill, index) => (
                          <Badge key={index} variant="secondary" className="text-xs">
                            {skill}
                          </Badge>
                        ))}
                      </div>
                    </div>

                    <div className="flex items-center justify-between pt-4 border-t">
                      <span className="text-sm text-gray-600">
                        {course.totalHours - course.hoursSpent} hours remaining
                      </span>
                      <Button size="sm" className="bg-gradient-to-r from-emerald-600 to-green-600 hover:from-emerald-700 hover:to-green-700">
                        Continue Learning
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="skills" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Skill Development Tracking</CardTitle>
                <CardDescription>Monitor your progress across different skill areas</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  {skillDevelopment.map((skill, index) => (
                    <div key={index} className="space-y-3">
                      <div className="flex items-center justify-between">
                        <span className="font-medium text-gray-900">{skill.skill}</span>
                        <div className="flex items-center gap-2">
                          <Badge className="bg-emerald-600 hover:bg-emerald-700">{skill.improvement}</Badge>
                          <span className="text-sm text-gray-600">{skill.current}% / {skill.target}%</span>
                        </div>
                      </div>
                      <div className="relative">
                        <Progress value={skill.current} className="h-3" />
                        <div 
                          className="absolute top-0 h-3 bg-emerald-200 rounded-full opacity-50" 
                          style={{ left: `${skill.current}%`, width: `${skill.target - skill.current}%` }}
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="path" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Personalized Learning Path</CardTitle>
                <CardDescription>Your customized journey towards professional excellence</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  {learningPath.map((phase, index) => (
                    <div key={index} className="border rounded-lg p-4">
                      <div className="flex items-center justify-between mb-3">
                        <div className="flex items-center gap-3">
                          <div className={`w-8 h-8 rounded-full flex items-center justify-center text-white text-sm ${
                            phase.status === 'Completed' ? 'bg-green-500' : 
                            phase.status === 'In Progress' ? 'bg-blue-500' : 'bg-gray-400'
                          }`}>
                            {index + 1}
                          </div>
                          <div>
                            <div className="font-medium text-gray-900">{phase.phase}</div>
                            <div className="text-sm text-gray-600">{phase.courses} courses in this phase</div>
                          </div>
                        </div>
                        <Badge variant={phase.status === 'Completed' ? 'default' : phase.status === 'In Progress' ? 'secondary' : 'outline'}>
                          {phase.status}
                        </Badge>
                      </div>
                      <Progress value={phase.progress} className="h-2" />
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </PlatformLayout>
  );
}