import { useState } from "react";
import { useAuth } from "@/hooks/use-auth";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Switch } from "@/components/ui/switch";
import { useToast } from "@/hooks/use-toast";
import { 
  Linkedin, 
  CheckCircle, 
  AlertCircle,
  Users,
  Briefcase,
  TrendingUp,
  Calendar,
  Globe,
  Share,
  Download,
  RefreshCw,
  Settings,
  Eye,
  MessageSquare,
  UserPlus,
  Award,
  Building
} from "lucide-react";
import PlatformLayout from "@/components/layout/platform-layout";
import { platformConfigs } from "@/config/complete-navigation";

function LinkedInIntegrationContent() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [isConnected, setIsConnected] = useState(false);
  const [autoSync, setAutoSync] = useState(true);
  const [privacyMode, setPrivacyMode] = useState(false);

  const { data: linkedinProfile } = useQuery({
    queryKey: ["/api/linkedin/profile"],
    enabled: isConnected,
    initialData: {
      id: "alex-johnson-dev",
      name: "Alex Johnson",
      headline: "Senior Full Stack Developer | React & Node.js Expert",
      location: "Bangalore, India",
      industry: "Information Technology",
      publicProfileUrl: "https://linkedin.com/in/alex-johnson-dev",
      profilePicture: "/avatars/alex-linkedin.jpg",
      connections: 847,
      followers: 1234,
      summary: "Passionate full-stack developer with 5+ years of experience building scalable web applications. Expert in React, Node.js, and cloud technologies.",
      experience: [
        {
          title: "Senior Full Stack Developer",
          company: "TechCorp Solutions",
          duration: "2022 - Present",
          location: "Bangalore, India",
          description: "Leading development of enterprise web applications using React and Node.js"
        },
        {
          title: "Full Stack Developer", 
          company: "StartupXYZ",
          duration: "2020 - 2022",
          location: "Mumbai, India",
          description: "Built MVP from scratch serving 10K+ users with React and Express.js"
        }
      ],
      skills: [
        { name: "React.js", endorsements: 45 },
        { name: "Node.js", endorsements: 38 },
        { name: "JavaScript", endorsements: 52 },
        { name: "TypeScript", endorsements: 31 },
        { name: "AWS", endorsements: 28 }
      ],
      lastSynced: "2024-06-09T12:30:00Z"
    }
  });

  const { data: networkInsights } = useQuery({
    queryKey: ["/api/linkedin/network-insights"],
    enabled: isConnected,
    initialData: {
      connectionGrowth: 12,
      profileViews: 156,
      searchAppearances: 89,
      postImpressions: 2341,
      engagementRate: 4.7,
      industryRanking: 15,
      skillsRecommendations: [
        { skill: "System Design", priority: "high", demand: "Very High" },
        { skill: "DevOps", priority: "medium", demand: "High" },
        { skill: "Machine Learning", priority: "low", demand: "Growing" }
      ],
      networkQuality: {
        score: 78,
        factors: [
          "Strong connections in tech industry",
          "Active engagement with posts",
          "Regular content sharing"
        ]
      }
    }
  });

  const { data: jobRecommendations = [] } = useQuery({
    queryKey: ["/api/linkedin/job-recommendations"],
    enabled: isConnected,
    initialData: [
      {
        id: "linkedin-job-1",
        title: "Senior React Developer",
        company: "Meta",
        location: "Remote, India",
        salary: "₹30-45 LPA",
        matchScore: 94,
        appliedViaLinkedIn: false,
        postedDate: "2024-06-07",
        requirements: ["React", "TypeScript", "Node.js", "GraphQL"]
      },
      {
        id: "linkedin-job-2", 
        title: "Full Stack Engineer",
        company: "Stripe",
        location: "Bangalore, India",
        salary: "₹35-50 LPA",
        matchScore: 89,
        appliedViaLinkedIn: true,
        postedDate: "2024-06-05",
        requirements: ["JavaScript", "React", "Python", "Kubernetes"]
      },
      {
        id: "linkedin-job-3",
        title: "Tech Lead - Frontend",
        company: "Razorpay", 
        location: "Bangalore, India",
        salary: "₹40-60 LPA",
        matchScore: 87,
        appliedViaLinkedIn: false,
        postedDate: "2024-06-04",
        requirements: ["React", "Leadership", "System Design", "Mentoring"]
      }
    ]
  });

  const connectLinkedInMutation = useMutation({
    mutationFn: async () => {
      return apiRequest("POST", "/api/linkedin/connect", {});
    },
    onSuccess: () => {
      setIsConnected(true);
      toast({
        title: "LinkedIn Connected",
        description: "Your LinkedIn account has been successfully connected.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/linkedin/profile"] });
    },
  });

  const syncProfileMutation = useMutation({
    mutationFn: async () => {
      return apiRequest("POST", "/api/linkedin/sync", {});
    },
    onSuccess: () => {
      toast({
        title: "Profile Synced",
        description: "Your LinkedIn profile data has been updated.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/linkedin/profile"] });
    },
  });

  const handleConnect = () => {
    // In real implementation, this would redirect to LinkedIn OAuth
    connectLinkedInMutation.mutate();
  };

  const handleSync = () => {
    syncProfileMutation.mutate();
  };

  const getMatchColor = (score: number) => {
    if (score >= 90) return "text-green-600";
    if (score >= 80) return "text-blue-600";
    if (score >= 70) return "text-yellow-600";
    return "text-gray-600";
  };

  return (
    <div className="max-w-7xl mx-auto p-6">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">LinkedIn Integration</h1>
        <p className="text-muted-foreground">Connect your LinkedIn profile for enhanced job matching and career insights</p>
      </div>

      {!isConnected ? (
        <Card className="max-w-2xl mx-auto">
          <CardHeader className="text-center">
            <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Linkedin className="w-8 h-8 text-blue-600" />
            </div>
            <CardTitle>Connect Your LinkedIn Account</CardTitle>
            <CardDescription>
              Sync your professional profile to unlock personalized job recommendations and career insights
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="flex items-start space-x-3 p-4 bg-green-50 rounded-lg">
                <CheckCircle className="w-5 h-5 text-green-600 mt-0.5" />
                <div>
                  <h4 className="font-medium text-green-900">Auto Job Matching</h4>
                  <p className="text-sm text-green-700">Get personalized job recommendations based on your profile</p>
                </div>
              </div>
              
              <div className="flex items-start space-x-3 p-4 bg-blue-50 rounded-lg">
                <TrendingUp className="w-5 h-5 text-blue-600 mt-0.5" />
                <div>
                  <h4 className="font-medium text-blue-900">Career Insights</h4>
                  <p className="text-sm text-blue-700">Analyze your profile performance and network growth</p>
                </div>
              </div>
              
              <div className="flex items-start space-x-3 p-4 bg-purple-50 rounded-lg">
                <Users className="w-5 h-5 text-purple-600 mt-0.5" />
                <div>
                  <h4 className="font-medium text-purple-900">Network Analysis</h4>
                  <p className="text-sm text-purple-700">Understand your professional network and connections</p>
                </div>
              </div>
              
              <div className="flex items-start space-x-3 p-4 bg-orange-50 rounded-lg">
                <Award className="w-5 h-5 text-orange-600 mt-0.5" />
                <div>
                  <h4 className="font-medium text-orange-900">Skill Recommendations</h4>
                  <p className="text-sm text-orange-700">Get suggestions for in-demand skills to learn</p>
                </div>
              </div>
            </div>

            <Button 
              onClick={handleConnect}
              className="w-full bg-blue-600 hover:bg-blue-700"
              disabled={connectLinkedInMutation.isPending}
            >
              <Linkedin className="w-4 h-4 mr-2" />
              {connectLinkedInMutation.isPending ? "Connecting..." : "Connect LinkedIn Account"}
            </Button>

            <p className="text-xs text-gray-500 text-center">
              We'll only access your basic profile information and never post on your behalf without permission.
            </p>
          </CardContent>
        </Card>
      ) : (
        <Tabs defaultValue="profile" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="profile">Profile</TabsTrigger>
            <TabsTrigger value="insights">Insights</TabsTrigger>
            <TabsTrigger value="jobs">Job Matches</TabsTrigger>
            <TabsTrigger value="settings">Settings</TabsTrigger>
          </TabsList>

          <TabsContent value="profile" className="space-y-6">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="flex items-center">
                    <Linkedin className="w-5 h-5 mr-2 text-blue-600" />
                    LinkedIn Profile
                  </CardTitle>
                  <div className="flex items-center space-x-2">
                    <Badge className="bg-green-100 text-green-800">
                      <CheckCircle className="w-3 h-3 mr-1" />
                      Connected
                    </Badge>
                    <Button size="sm" variant="outline" onClick={handleSync}>
                      <RefreshCw className="w-3 h-3 mr-1" />
                      Sync
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="flex items-start space-x-4">
                  <div className="w-20 h-20 bg-blue-100 rounded-full flex items-center justify-center">
                    <Users className="w-10 h-10 text-blue-600" />
                  </div>
                  <div className="flex-1">
                    <h3 className="text-xl font-semibold">{linkedinProfile.name}</h3>
                    <p className="text-blue-600 font-medium">{linkedinProfile.headline}</p>
                    <p className="text-gray-600 mb-4">{linkedinProfile.location} • {linkedinProfile.industry}</p>
                    
                    <div className="grid grid-cols-3 gap-4 mb-4">
                      <div className="text-center">
                        <div className="text-2xl font-bold text-blue-600">{linkedinProfile.connections}</div>
                        <div className="text-sm text-gray-600">Connections</div>
                      </div>
                      <div className="text-center">
                        <div className="text-2xl font-bold text-purple-600">{linkedinProfile.followers}</div>
                        <div className="text-sm text-gray-600">Followers</div>
                      </div>
                      <div className="text-center">
                        <div className="text-2xl font-bold text-green-600">{linkedinProfile.skills.length}</div>
                        <div className="text-sm text-gray-600">Skills</div>
                      </div>
                    </div>

                    <p className="text-gray-700 mb-4">{linkedinProfile.summary}</p>
                    
                    <Button variant="outline" className="mr-2">
                      <Globe className="w-3 h-3 mr-1" />
                      View LinkedIn Profile
                    </Button>
                    <Button variant="outline">
                      <Share className="w-3 h-3 mr-1" />
                      Share Profile
                    </Button>
                  </div>
                </div>

                <div className="mt-6 pt-6 border-t">
                  <h4 className="font-medium mb-4">Recent Experience</h4>
                  <div className="space-y-4">
                    {linkedinProfile.experience.slice(0, 2).map((exp: any, index: number) => (
                      <div key={index} className="flex items-start space-x-4">
                        <div className="w-12 h-12 bg-gray-100 rounded-lg flex items-center justify-center">
                          <Building className="w-6 h-6 text-gray-600" />
                        </div>
                        <div>
                          <h5 className="font-medium">{exp.title}</h5>
                          <p className="text-blue-600">{exp.company}</p>
                          <p className="text-sm text-gray-600">{exp.duration} • {exp.location}</p>
                          <p className="text-sm text-gray-700 mt-1">{exp.description}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="mt-6 pt-6 border-t">
                  <h4 className="font-medium mb-4">Top Skills</h4>
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                    {linkedinProfile.skills.map((skill: any, index: number) => (
                      <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                        <span className="font-medium">{skill.name}</span>
                        <Badge variant="outline" className="text-xs">
                          {skill.endorsements} endorsements
                        </Badge>
                      </div>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="insights" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-600">Profile Views</p>
                      <p className="text-2xl font-bold text-blue-600">{networkInsights.profileViews}</p>
                    </div>
                    <Eye className="w-8 h-8 text-blue-600" />
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-600">Search Appearances</p>
                      <p className="text-2xl font-bold text-green-600">{networkInsights.searchAppearances}</p>
                    </div>
                    <TrendingUp className="w-8 h-8 text-green-600" />
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-600">Post Impressions</p>
                      <p className="text-2xl font-bold text-purple-600">{networkInsights.postImpressions}</p>
                    </div>
                    <MessageSquare className="w-8 h-8 text-purple-600" />
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-gray-600">Engagement Rate</p>
                      <p className="text-2xl font-bold text-orange-600">{networkInsights.engagementRate}%</p>
                    </div>
                    <UserPlus className="w-8 h-8 text-orange-600" />
                  </div>
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardHeader>
                <CardTitle>Network Quality Score</CardTitle>
                <CardDescription>
                  Analysis of your professional network strength and quality
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex items-center space-x-4 mb-4">
                  <div className="text-4xl font-bold text-blue-600">{networkInsights.networkQuality.score}/100</div>
                  <div>
                    <Badge className="bg-blue-100 text-blue-800 mb-2">
                      {networkInsights.networkQuality.score >= 80 ? 'Excellent' : 
                       networkInsights.networkQuality.score >= 60 ? 'Good' : 'Needs Improvement'}
                    </Badge>
                    <p className="text-sm text-gray-600">Your network is performing well</p>
                  </div>
                </div>
                
                <div>
                  <h4 className="font-medium mb-2">Strength Factors:</h4>
                  <ul className="space-y-1">
                    {networkInsights.networkQuality.factors.map((factor: string, index: number) => (
                      <li key={index} className="text-sm text-gray-700 flex items-center">
                        <CheckCircle className="w-3 h-3 text-green-500 mr-2" />
                        {factor}
                      </li>
                    ))}
                  </ul>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Skill Recommendations</CardTitle>
                <CardDescription>
                  Trending skills that could boost your profile visibility
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {networkInsights.skillsRecommendations.map((rec: any, index: number) => (
                    <div key={index} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                      <div>
                        <h4 className="font-medium">{rec.skill}</h4>
                        <p className="text-sm text-gray-600">Market demand: {rec.demand}</p>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Badge className={rec.priority === 'high' ? 'bg-red-100 text-red-800' : 
                                        rec.priority === 'medium' ? 'bg-yellow-100 text-yellow-800' : 
                                        'bg-green-100 text-green-800'}>
                          {rec.priority} priority
                        </Badge>
                        <Button size="sm" variant="outline">
                          Learn
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="jobs" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Briefcase className="w-5 h-5 mr-2 text-green-600" />
                  Personalized Job Matches
                </CardTitle>
                <CardDescription>
                  Jobs curated based on your LinkedIn profile and preferences
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {jobRecommendations.map((job: any) => (
                    <div key={job.id} className="p-4 border rounded-lg hover:shadow-md transition-shadow">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <div className="flex items-center space-x-3 mb-2">
                            <h3 className="text-lg font-semibold">{job.title}</h3>
                            <div className={`text-lg font-bold ${getMatchColor(job.matchScore)}`}>
                              {job.matchScore}% match
                            </div>
                            {job.appliedViaLinkedIn && (
                              <Badge className="bg-blue-100 text-blue-800">
                                Applied via LinkedIn
                              </Badge>
                            )}
                          </div>
                          <p className="text-blue-600 font-medium">{job.company}</p>
                          <p className="text-gray-600 mb-3">{job.location} • {job.salary}</p>
                          
                          <div className="flex flex-wrap gap-2 mb-3">
                            {job.requirements.map((req: string) => (
                              <Badge key={req} variant="outline" className="text-xs">
                                {req}
                              </Badge>
                            ))}
                          </div>
                          
                          <p className="text-sm text-gray-500">
                            Posted {new Date(job.postedDate).toLocaleDateString()}
                          </p>
                        </div>
                        
                        <div className="flex flex-col space-y-2 ml-4">
                          {!job.appliedViaLinkedIn && (
                            <Button size="sm" className="bg-blue-600 hover:bg-blue-700">
                              <Linkedin className="w-3 h-3 mr-1" />
                              Apply via LinkedIn
                            </Button>
                          )}
                          <Button size="sm" variant="outline">
                            <Eye className="w-3 h-3 mr-1" />
                            View Details
                          </Button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="settings" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Settings className="w-5 h-5 mr-2 text-gray-600" />
                  Integration Settings
                </CardTitle>
                <CardDescription>
                  Configure how TestEngine syncs with your LinkedIn profile
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="font-medium">Automatic Profile Sync</h4>
                    <p className="text-sm text-gray-600">Sync profile data daily to keep information up-to-date</p>
                  </div>
                  <Switch checked={autoSync} onCheckedChange={setAutoSync} />
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="font-medium">Privacy Mode</h4>
                    <p className="text-sm text-gray-600">Hide LinkedIn integration from other users</p>
                  </div>
                  <Switch checked={privacyMode} onCheckedChange={setPrivacyMode} />
                </div>

                <div className="pt-4 border-t">
                  <h4 className="font-medium mb-3">Data Permissions</h4>
                  <div className="space-y-2">
                    <div className="flex items-center justify-between p-3 bg-green-50 rounded-lg">
                      <div className="flex items-center">
                        <CheckCircle className="w-4 h-4 text-green-600 mr-2" />
                        <span className="text-sm">Basic profile information</span>
                      </div>
                      <Badge className="bg-green-100 text-green-800">Granted</Badge>
                    </div>
                    <div className="flex items-center justify-between p-3 bg-green-50 rounded-lg">
                      <div className="flex items-center">
                        <CheckCircle className="w-4 h-4 text-green-600 mr-2" />
                        <span className="text-sm">Work experience & education</span>
                      </div>
                      <Badge className="bg-green-100 text-green-800">Granted</Badge>
                    </div>
                    <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                      <div className="flex items-center">
                        <AlertCircle className="w-4 h-4 text-gray-600 mr-2" />
                        <span className="text-sm">Contact information</span>
                      </div>
                      <Badge className="bg-gray-100 text-gray-800">Not requested</Badge>
                    </div>
                  </div>
                </div>

                <div className="pt-4 border-t">
                  <h4 className="font-medium mb-3">Last Sync</h4>
                  <p className="text-sm text-gray-600">
                    {new Date(linkedinProfile.lastSynced).toLocaleString()}
                  </p>
                </div>

                <div className="pt-4 border-t">
                  <Button variant="destructive" className="w-full">
                    Disconnect LinkedIn Account
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      )}
    </div>
  );
}

export default function LinkedInIntegration() {
  const config = platformConfigs.candidate;
  
  const usageData = [
    { label: "LinkedIn Connections", current: 450, max: 500 },
    { label: "Profile Views", current: 89, max: 100 },
    { label: "Network Messages", current: 23, max: 50 },
  ];

  return (
    <PlatformLayout
      sidebarTitle={config.sidebarTitle}
      sidebarSubtitle={config.sidebarSubtitle}
      sidebarSections={config.sidebarSections}
      usageData={usageData}
    >
      <LinkedInIntegrationContent />
    </PlatformLayout>
  );
}