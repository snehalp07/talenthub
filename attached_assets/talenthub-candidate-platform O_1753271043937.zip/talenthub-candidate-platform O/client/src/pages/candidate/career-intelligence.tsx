import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import PlatformLayout from "@/components/layout/platform-layout";
import { candidateNavigation } from "@/config/complete-navigation";
import { 
  Brain, TrendingUp, Target, Award, Activity, Calendar,
  Users, Briefcase, Star, Zap, BarChart3, PieChart,
  ArrowUp, ArrowDown, CheckCircle, Clock, Globe,
  Shield, Lightbulb, Rocket, Trophy, Heart
} from "lucide-react";

const CareerIntelligence: React.FC = () => {
  const [selectedTimeframe, setSelectedTimeframe] = useState('30d');
  
  // Comprehensive career intelligence data
  const careerHealthScore = 87;
  const careerGrowthRate = 23;
  const marketPositioning = 'Top 15%';
  
  const keyMetrics = [
    { label: 'Career Health Score', value: careerHealthScore, change: +5, color: 'bg-emerald-500', icon: Heart },
    { label: 'Skills Growth Rate', value: `${careerGrowthRate}%`, change: +8, color: 'bg-blue-500', icon: TrendingUp },
    { label: 'Market Position', value: marketPositioning, change: '+2 ranks', color: 'bg-purple-500', icon: Target },
    { label: 'Network Influence', value: '8.4/10', change: +0.7, color: 'bg-orange-500', icon: Users }
  ];

  const platformMetrics = [
    { platform: 'Profile & Branding', score: 92, growth: '+12%', color: 'from-blue-400 to-blue-600', activities: 15 },
    { platform: 'Skills & Certifications', score: 85, growth: '+18%', color: 'from-emerald-400 to-emerald-600', activities: 23 },
    { platform: 'Job Search', score: 78, growth: '+8%', color: 'from-purple-400 to-purple-600', activities: 12 },
    { platform: 'Interview Preparation', score: 89, growth: '+25%', color: 'from-orange-400 to-orange-600', activities: 18 },
    { platform: 'Project Portfolio', score: 91, growth: '+15%', color: 'from-cyan-400 to-cyan-600', activities: 8 },
    { platform: 'Networking', score: 84, growth: '+22%', color: 'from-pink-400 to-pink-600', activities: 31 }
  ];

  const milestones = [
    { title: 'React Expert Certification', date: '2 days ago', type: 'achievement', color: 'bg-emerald-100 text-emerald-800' },
    { title: 'Portfolio Views +150%', date: '1 week ago', type: 'growth', color: 'bg-blue-100 text-blue-800' },
    { title: 'Network Expanded to 500+', date: '2 weeks ago', type: 'milestone', color: 'bg-purple-100 text-purple-800' },
    { title: 'Interview Success Rate 85%', date: '3 weeks ago', type: 'performance', color: 'bg-orange-100 text-orange-800' }
  ];

  const careerGoals = [
    { goal: 'Senior Developer Role', progress: 78, target: 'Q2 2025', activities: ['Technical Interviews', 'System Design'] },
    { goal: 'Full-Stack Certification', progress: 92, target: 'Next Month', activities: ['Node.js Projects', 'Database Design'] },
    { goal: 'Team Leadership', progress: 45, target: 'Q3 2025', activities: ['Management Training', 'Mentoring'] },
    { goal: 'Open Source Contributor', progress: 63, target: 'Ongoing', activities: ['GitHub Contributions', 'Community Engagement'] }
  ];

  return (
    <PlatformLayout 
      sidebarTitle="Candidate Platform"
      sidebarSubtitle="Professional Development Hub"
      sidebarSections={candidateNavigation}
    >
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-blue-50 to-indigo-50 p-6">
        {/* Header Section */}
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-2">
            <div className="p-2 bg-gradient-to-br from-blue-500 to-purple-600 rounded-lg text-white">
              <Brain className="h-6 w-6" />
            </div>
            <h1 className="text-3xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
              Career Intelligence Dashboard
            </h1>
          </div>
          <p className="text-gray-600 text-lg">
            Comprehensive insights across your entire career development journey
          </p>
        </div>

        {/* Time Range Selector */}
        <div className="flex gap-2 mb-6">
          {['7d', '30d', '90d', '1y'].map((period) => (
            <Button
              key={period}
              variant={selectedTimeframe === period ? "default" : "outline"}
              size="sm"
              onClick={() => setSelectedTimeframe(period)}
              className={selectedTimeframe === period ? "bg-gradient-to-r from-blue-500 to-purple-600" : ""}
            >
              {period === '7d' ? '7 Days' : period === '30d' ? '30 Days' : period === '90d' ? '90 Days' : '1 Year'}
            </Button>
          ))}
        </div>

        {/* Key Metrics Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {keyMetrics.map((metric, index) => {
            const IconComponent = metric.icon;
            return (
              <Card key={index} className="relative overflow-hidden border-0 shadow-lg bg-white/80 backdrop-blur-sm">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between mb-4">
                    <div className={`p-3 rounded-lg ${metric.color} text-white`}>
                      <IconComponent className="h-6 w-6" />
                    </div>
                    <div className={`flex items-center gap-1 px-2 py-1 rounded-full text-sm ${
                      Number(metric.change) > 0 ? 'bg-emerald-100 text-emerald-700' : 'bg-red-100 text-red-700'
                    }`}>
                      {Number(metric.change) > 0 ? <ArrowUp className="h-3 w-3" /> : <ArrowDown className="h-3 w-3" />}
                      {Math.abs(Number(metric.change))}
                    </div>
                  </div>
                  <div className="text-2xl font-bold text-gray-900 mb-1">{metric.value}</div>
                  <div className="text-sm text-gray-600">{metric.label}</div>
                </CardContent>
              </Card>
            );
          })}
        </div>

        <Tabs defaultValue="overview" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4 bg-white/80 backdrop-blur-sm">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="platforms">Platform Analytics</TabsTrigger>
            <TabsTrigger value="goals">Career Goals</TabsTrigger>
            <TabsTrigger value="insights">AI Insights</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6">
            {/* Career Health Score */}
            <Card className="border-0 shadow-lg bg-white/80 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Activity className="h-5 w-5 text-emerald-500" />
                  Career Health Analysis
                </CardTitle>
                <CardDescription>
                  Comprehensive assessment of your career development across all platforms
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="mb-6">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-lg font-semibold">Overall Career Health</span>
                    <span className="text-2xl font-bold text-emerald-600">{careerHealthScore}/100</span>
                  </div>
                  <Progress value={careerHealthScore} className="h-3 bg-gray-200">
                    <div className="h-full bg-gradient-to-r from-emerald-400 to-emerald-600 rounded-full transition-all duration-500" 
                         style={{ width: `${careerHealthScore}%` }} />
                  </Progress>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="text-center p-4 bg-gradient-to-br from-blue-50 to-blue-100 rounded-lg">
                    <div className="text-2xl font-bold text-blue-600 mb-1">85%</div>
                    <div className="text-sm text-blue-700">Skills Mastery</div>
                  </div>
                  <div className="text-center p-4 bg-gradient-to-br from-purple-50 to-purple-100 rounded-lg">
                    <div className="text-2xl font-bold text-purple-600 mb-1">92%</div>
                    <div className="text-sm text-purple-700">Market Readiness</div>
                  </div>
                  <div className="text-center p-4 bg-gradient-to-br from-orange-50 to-orange-100 rounded-lg">
                    <div className="text-2xl font-bold text-orange-600 mb-1">78%</div>
                    <div className="text-sm text-orange-700">Career Momentum</div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Recent Milestones */}
            <Card className="border-0 shadow-lg bg-white/80 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Trophy className="h-5 w-5 text-yellow-500" />
                  Recent Milestones & Achievements
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {milestones.map((milestone, index) => (
                    <div key={index} className="flex items-center gap-4 p-4 bg-gradient-to-r from-gray-50 to-gray-100 rounded-lg">
                      <div className="flex-shrink-0">
                        <CheckCircle className="h-5 w-5 text-emerald-500" />
                      </div>
                      <div className="flex-1">
                        <div className="font-semibold text-gray-900">{milestone.title}</div>
                        <div className="text-sm text-gray-600">{milestone.date}</div>
                      </div>
                      <Badge className={milestone.color}>
                        {milestone.type}
                      </Badge>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="platforms" className="space-y-6">
            <Card className="border-0 shadow-lg bg-white/80 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <BarChart3 className="h-5 w-5 text-blue-500" />
                  Platform Performance Analytics
                </CardTitle>
                <CardDescription>
                  Detailed insights across all TalentHub platform features
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  {platformMetrics.map((platform, index) => (
                    <div key={index} className="space-y-3">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <div className={`w-4 h-4 rounded-full bg-gradient-to-r ${platform.color}`} />
                          <span className="font-semibold text-gray-900">{platform.platform}</span>
                        </div>
                        <div className="flex items-center gap-4">
                          <Badge variant="outline" className="text-emerald-600 border-emerald-200">
                            {platform.growth}
                          </Badge>
                          <span className="text-lg font-bold text-gray-900">{platform.score}%</span>
                        </div>
                      </div>
                      <div className="flex items-center gap-3">
                        <Progress value={platform.score} className="flex-1 h-2 bg-gray-200">
                          <div className={`h-full bg-gradient-to-r ${platform.color} rounded-full transition-all duration-500`} 
                               style={{ width: `${platform.score}%` }} />
                        </Progress>
                        <span className="text-sm text-gray-600">{platform.activities} activities</span>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="goals" className="space-y-6">
            <Card className="border-0 shadow-lg bg-white/80 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Target className="h-5 w-5 text-purple-500" />
                  Career Goals Tracking
                </CardTitle>
                <CardDescription>
                  Monitor progress towards your career objectives and milestones
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  {careerGoals.map((goal, index) => (
                    <div key={index} className="p-6 bg-gradient-to-br from-gray-50 to-gray-100 rounded-lg">
                      <div className="flex items-center justify-between mb-4">
                        <div>
                          <div className="font-semibold text-gray-900 text-lg">{goal.goal}</div>
                          <div className="text-sm text-gray-600">Target: {goal.target}</div>
                        </div>
                        <div className="text-right">
                          <div className="text-2xl font-bold text-blue-600">{goal.progress}%</div>
                          <div className="text-sm text-gray-600">Complete</div>
                        </div>
                      </div>
                      <Progress value={goal.progress} className="mb-4 h-3 bg-gray-200">
                        <div className="h-full bg-gradient-to-r from-blue-400 to-purple-600 rounded-full transition-all duration-500" 
                             style={{ width: `${goal.progress}%` }} />
                      </Progress>
                      <div className="flex gap-2">
                        {goal.activities.map((activity, actIndex) => (
                          <Badge key={actIndex} variant="outline" className="text-blue-600 border-blue-200">
                            {activity}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="insights" className="space-y-6">
            <Card className="border-0 shadow-lg bg-white/80 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Lightbulb className="h-5 w-5 text-yellow-500" />
                  AI-Powered Career Insights
                </CardTitle>
                <CardDescription>
                  Intelligent recommendations based on your career data and market trends
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  <div className="p-6 bg-gradient-to-br from-blue-50 to-indigo-100 rounded-lg border border-blue-200">
                    <div className="flex items-start gap-4">
                      <div className="p-2 bg-blue-500 rounded-lg">
                        <Rocket className="h-5 w-5 text-white" />
                      </div>
                      <div>
                        <div className="font-semibold text-blue-900 mb-2">Career Acceleration Opportunity</div>
                        <div className="text-blue-800 mb-3">
                          Your React skills and project portfolio position you for senior roles. Consider applying to 
                          3-5 senior positions in the next 30 days while your profile engagement is at peak.
                        </div>
                        <div className="flex gap-2">
                          <Badge className="bg-blue-600 text-white">High Impact</Badge>
                          <Badge variant="outline" className="text-blue-600 border-blue-300">30-day window</Badge>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="p-6 bg-gradient-to-br from-emerald-50 to-green-100 rounded-lg border border-emerald-200">
                    <div className="flex items-start gap-4">
                      <div className="p-2 bg-emerald-500 rounded-lg">
                        <Star className="h-5 w-5 text-white" />
                      </div>
                      <div>
                        <div className="font-semibold text-emerald-900 mb-2">Skill Gap Closure</div>
                        <div className="text-emerald-800 mb-3">
                          Adding System Design certification would complete your full-stack profile and increase 
                          salary negotiation power by an estimated 15-20%.
                        </div>
                        <div className="flex gap-2">
                          <Badge className="bg-emerald-600 text-white">Revenue Impact</Badge>
                          <Badge variant="outline" className="text-emerald-600 border-emerald-300">2-month effort</Badge>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="p-6 bg-gradient-to-br from-purple-50 to-violet-100 rounded-lg border border-purple-200">
                    <div className="flex items-start gap-4">
                      <div className="p-2 bg-purple-500 rounded-lg">
                        <Users className="h-5 w-5 text-white" />
                      </div>
                      <div>
                        <div className="font-semibold text-purple-900 mb-2">Network Leverage</div>
                        <div className="text-purple-800 mb-3">
                          Your network growth (+22%) is exceptional. Consider hosting a technical workshop or 
                          writing thought leadership content to maximize visibility.
                        </div>
                        <div className="flex gap-2">
                          <Badge className="bg-purple-600 text-white">Brand Building</Badge>
                          <Badge variant="outline" className="text-purple-600 border-purple-300">Ongoing</Badge>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </PlatformLayout>
  );
};

export default CareerIntelligence;