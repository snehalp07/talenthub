import PlatformLayout from "@/components/layout/platform-layout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { BookOpen, Search, Filter, Star, Clock, Download, Code, Globe, Smartphone, Database, Cpu, Zap, Play, GitBranch, Eye, Users } from "lucide-react";
import { platformConfigs } from "@/config/complete-navigation";

export default function SampleProjects() {
  const config = platformConfigs.candidate;

  const sampleProjects = [
    {
      id: 1,
      name: "React E-commerce Store",
      description: "Complete online store with cart, checkout, payment integration, and admin dashboard",
      category: "Frontend",
      difficulty: "Intermediate",
      duration: "2-3 weeks",
      tech: ["React", "TypeScript", "Tailwind CSS", "Stripe API", "Context API"],
      features: ["Product catalog", "Shopping cart", "User authentication", "Payment processing", "Order management"],
      learningGoals: ["State management", "API integration", "Payment flows", "Responsive design"],
      demoUrl: "https://react-ecommerce-demo.vercel.app",
      githubUrl: "https://github.com/samples/react-ecommerce",
      color: "from-blue-500 to-indigo-500",
      icon: Globe,
      popularity: 95,
      difficulty_score: 7
    },
    {
      id: 2,
      name: "Node.js REST API",
      description: "Scalable backend API with authentication, CRUD operations, and comprehensive testing",
      category: "Backend",
      difficulty: "Beginner",
      duration: "1-2 weeks",
      tech: ["Node.js", "Express.js", "MongoDB", "JWT", "Jest", "Swagger"],
      features: ["User authentication", "CRUD operations", "Input validation", "Error handling", "API documentation"],
      learningGoals: ["RESTful design", "Database modeling", "Authentication", "Testing"],
      demoUrl: "https://nodejs-api-demo.herokuapp.com/docs",
      githubUrl: "https://github.com/samples/nodejs-rest-api",
      color: "from-green-500 to-emerald-500",
      icon: Database,
      popularity: 88,
      difficulty_score: 4
    },
    {
      id: 3,
      name: "React Native Fitness App",
      description: "Cross-platform mobile app for fitness tracking with workout plans and progress monitoring",
      category: "Mobile",
      difficulty: "Intermediate",
      duration: "3-4 weeks",
      tech: ["React Native", "Expo", "AsyncStorage", "React Navigation", "Charts"],
      features: ["Workout tracking", "Progress analytics", "Custom plans", "Social sharing", "Offline support"],
      learningGoals: ["Mobile UI/UX", "Local storage", "Navigation", "Data visualization"],
      demoUrl: "https://expo.dev/@samples/fitness-tracker",
      githubUrl: "https://github.com/samples/rn-fitness-app",
      color: "from-orange-500 to-red-500",
      icon: Smartphone,
      popularity: 92,
      difficulty_score: 6
    },
    {
      id: 4,
      name: "Python ML Image Classifier",
      description: "Machine learning project for image classification with web interface and model deployment",
      category: "AI/ML",
      difficulty: "Advanced",
      duration: "4-5 weeks",
      tech: ["Python", "TensorFlow", "Flask", "OpenCV", "Docker", "AWS"],
      features: ["Model training", "Image preprocessing", "Web interface", "API deployment", "Performance metrics"],
      learningGoals: ["Deep learning", "Model deployment", "Computer vision", "Cloud deployment"],
      demoUrl: "https://ml-classifier-demo.herokuapp.com",
      githubUrl: "https://github.com/samples/ml-image-classifier",
      color: "from-purple-500 to-pink-500",
      icon: Cpu,
      popularity: 86,
      difficulty_score: 9
    },
    {
      id: 5,
      name: "Vue.js Dashboard",
      description: "Admin dashboard with data visualization, user management, and real-time updates",
      category: "Frontend",
      difficulty: "Intermediate",
      duration: "2-3 weeks",
      tech: ["Vue.js", "Vuex", "Chart.js", "Socket.io", "Vuetify"],
      features: ["Data visualization", "Real-time updates", "User management", "Responsive design", "Dark mode"],
      learningGoals: ["Vue ecosystem", "State management", "Real-time communication", "Data visualization"],
      demoUrl: "https://vue-dashboard-demo.netlify.app",
      githubUrl: "https://github.com/samples/vue-dashboard",
      color: "from-teal-500 to-green-500",
      icon: Globe,
      popularity: 84,
      difficulty_score: 6
    },
    {
      id: 6,
      name: "IoT Smart Home System",
      description: "Complete IoT solution with device management, automation, and mobile control",
      category: "IoT",
      difficulty: "Advanced",
      duration: "5-6 weeks",
      tech: ["Arduino", "Raspberry Pi", "MQTT", "React", "Node.js", "InfluxDB"],
      features: ["Device control", "Automation rules", "Data logging", "Mobile app", "Voice commands"],
      learningGoals: ["IoT protocols", "Embedded programming", "Real-time data", "Hardware integration"],
      demoUrl: "https://smart-home-demo.com",
      githubUrl: "https://github.com/samples/iot-smart-home",
      color: "from-yellow-500 to-orange-500",
      icon: Zap,
      popularity: 78,
      difficulty_score: 10
    }
  ];

  const projectCategories = [
    { name: "Frontend", count: 45, color: "bg-blue-500" },
    { name: "Backend", count: 38, color: "bg-green-500" },
    { name: "Full-Stack", count: 29, color: "bg-purple-500" },
    { name: "Mobile", count: 32, color: "bg-orange-500" },
    { name: "AI/ML", count: 24, color: "bg-pink-500" },
    { name: "IoT", count: 18, color: "bg-yellow-500" }
  ];

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case "Beginner": return "bg-green-100 text-green-800 border-green-200";
      case "Intermediate": return "bg-yellow-100 text-yellow-800 border-yellow-200";
      case "Advanced": return "bg-red-100 text-red-800 border-red-200";
      default: return "bg-gray-100 text-gray-800 border-gray-200";
    }
  };

  return (
    <PlatformLayout
      sidebarTitle={config.sidebarTitle}
      sidebarSubtitle={config.sidebarSubtitle}
      sidebarSections={config.sidebarSections}
      usageData={config.usageData}
    >
      <div className="p-6 max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="text-center space-y-4">
          <div className="flex items-center justify-center space-x-3">
            <div className="p-3 bg-gradient-to-r from-indigo-500 to-purple-500 rounded-full">
              <BookOpen className="h-8 w-8 text-white" />
            </div>
            <h1 className="text-4xl font-bold bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent">
              Sample Projects
            </h1>
          </div>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Learn from curated project examples with complete source code, tutorials, and step-by-step guides
          </p>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card className="bg-gradient-to-r from-indigo-50 to-purple-50 border-indigo-200">
            <CardContent className="p-4 text-center">
              <BookOpen className="h-8 w-8 text-indigo-500 mx-auto mb-2" />
              <p className="text-2xl font-bold text-indigo-600">186</p>
              <p className="text-sm text-muted-foreground">Sample Projects</p>
            </CardContent>
          </Card>
          <Card className="bg-gradient-to-r from-blue-50 to-indigo-50 border-blue-200">
            <CardContent className="p-4 text-center">
              <Download className="h-8 w-8 text-blue-500 mx-auto mb-2" />
              <p className="text-2xl font-bold text-blue-600">12.5K</p>
              <p className="text-sm text-muted-foreground">Downloads</p>
            </CardContent>
          </Card>
          <Card className="bg-gradient-to-r from-green-50 to-emerald-50 border-green-200">
            <CardContent className="p-4 text-center">
              <Star className="h-8 w-8 text-green-500 mx-auto mb-2" />
              <p className="text-2xl font-bold text-green-600">4.8</p>
              <p className="text-sm text-muted-foreground">Avg. Rating</p>
            </CardContent>
          </Card>
          <Card className="bg-gradient-to-r from-orange-50 to-red-50 border-orange-200">
            <CardContent className="p-4 text-center">
              <Users className="h-8 w-8 text-orange-500 mx-auto mb-2" />
              <p className="text-2xl font-bold text-orange-600">3.2K</p>
              <p className="text-sm text-muted-foreground">Active Learners</p>
            </CardContent>
          </Card>
        </div>

        {/* Search and Filters */}
        <div className="flex flex-col sm:flex-row gap-4 items-center justify-between">
          <div className="flex items-center space-x-2 flex-1">
            <div className="relative flex-1 max-w-md">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
              <Input
                placeholder="Search sample projects..."
                className="pl-10"
              />
            </div>
          </div>
          <div className="flex items-center space-x-2">
            <Select defaultValue="all">
              <SelectTrigger className="w-40">
                <SelectValue placeholder="Category" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Categories</SelectItem>
                <SelectItem value="frontend">Frontend</SelectItem>
                <SelectItem value="backend">Backend</SelectItem>
                <SelectItem value="fullstack">Full-Stack</SelectItem>
                <SelectItem value="mobile">Mobile</SelectItem>
                <SelectItem value="ai">AI/ML</SelectItem>
                <SelectItem value="iot">IoT</SelectItem>
              </SelectContent>
            </Select>
            <Select defaultValue="all">
              <SelectTrigger className="w-40">
                <SelectValue placeholder="Difficulty" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Levels</SelectItem>
                <SelectItem value="beginner">Beginner</SelectItem>
                <SelectItem value="intermediate">Intermediate</SelectItem>
                <SelectItem value="advanced">Advanced</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <Tabs defaultValue="projects" className="space-y-6">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="projects">Browse Projects</TabsTrigger>
            <TabsTrigger value="categories">By Category</TabsTrigger>
            <TabsTrigger value="learning">Learning Paths</TabsTrigger>
          </TabsList>

          <TabsContent value="projects" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {sampleProjects.map((project) => {
                const IconComponent = project.icon;
                return (
                  <Card key={project.id} className="group hover:shadow-lg transition-all duration-300 hover:-translate-y-1 border-l-4 border-l-indigo-500">
                    <CardHeader className="pb-3">
                      <div className="flex items-start justify-between">
                        <div className={`p-2 bg-gradient-to-r ${project.color} rounded-lg`}>
                          <IconComponent className="h-6 w-6 text-white" />
                        </div>
                        <div className="flex gap-2">
                          <Badge className={getDifficultyColor(project.difficulty)}>
                            {project.difficulty}
                          </Badge>
                          <Badge variant="secondary">{project.category}</Badge>
                        </div>
                      </div>
                      <CardTitle className="text-xl">{project.name}</CardTitle>
                      <CardDescription>{project.description}</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="flex items-center gap-4 text-sm text-muted-foreground">
                        <div className="flex items-center gap-1">
                          <Clock className="h-4 w-4" />
                          <span>{project.duration}</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <Star className="h-4 w-4 text-yellow-500" />
                          <span>{(project.popularity / 20).toFixed(1)}</span>
                        </div>
                        <div className="text-xs px-2 py-1 bg-gray-100 rounded">
                          Level {project.difficulty_score}/10
                        </div>
                      </div>

                      <div className="space-y-3">
                        <div>
                          <h4 className="text-sm font-medium mb-2">Technologies</h4>
                          <div className="flex flex-wrap gap-1">
                            {project.tech.map((tech, index) => (
                              <Badge key={index} variant="outline" className="text-xs">
                                {tech}
                              </Badge>
                            ))}
                          </div>
                        </div>

                        <div>
                          <h4 className="text-sm font-medium mb-2">Key Features</h4>
                          <ul className="text-xs text-muted-foreground space-y-1">
                            {project.features.slice(0, 3).map((feature, index) => (
                              <li key={index} className="flex items-center gap-1">
                                <div className="w-1 h-1 bg-indigo-500 rounded-full" />
                                {feature}
                              </li>
                            ))}
                            {project.features.length > 3 && (
                              <li className="text-indigo-600">+{project.features.length - 3} more features</li>
                            )}
                          </ul>
                        </div>

                        <div>
                          <h4 className="text-sm font-medium mb-2">Learning Goals</h4>
                          <div className="flex flex-wrap gap-1">
                            {project.learningGoals.slice(0, 2).map((goal, index) => (
                              <Badge key={index} variant="outline" className="text-xs bg-indigo-50 text-indigo-700 border-indigo-200">
                                {goal}
                              </Badge>
                            ))}
                            {project.learningGoals.length > 2 && (
                              <Badge variant="outline" className="text-xs">
                                +{project.learningGoals.length - 2}
                              </Badge>
                            )}
                          </div>
                        </div>
                      </div>

                      <div className="flex items-center gap-2 pt-2">
                        <Button className="flex-1 bg-gradient-to-r from-indigo-500 to-purple-500 hover:from-indigo-600 hover:to-purple-600">
                          <Download className="h-4 w-4 mr-2" />
                          Use Template
                        </Button>
                        <Button variant="outline" size="icon">
                          <Play className="h-4 w-4" />
                        </Button>
                        <Button variant="outline" size="icon">
                          <Eye className="h-4 w-4" />
                        </Button>
                        <Button variant="outline" size="icon">
                          <GitBranch className="h-4 w-4" />
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </TabsContent>

          <TabsContent value="categories" className="space-y-6">
            <h2 className="text-2xl font-bold text-indigo-700">Browse by Category</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {projectCategories.map((category) => (
                <Card key={category.name} className="group hover:shadow-lg transition-all duration-300 hover:-translate-y-1 cursor-pointer">
                  <CardContent className="p-6 text-center">
                    <div className={`w-16 h-16 ${category.color} rounded-full flex items-center justify-center mx-auto mb-4`}>
                      <Code className="h-8 w-8 text-white" />
                    </div>
                    <h3 className="text-xl font-semibold mb-2">{category.name}</h3>
                    <p className="text-3xl font-bold text-indigo-600 mb-1">{category.count}</p>
                    <p className="text-sm text-muted-foreground">Sample Projects</p>
                    <Button className="mt-4 w-full" variant="outline">
                      Explore {category.name}
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="learning" className="space-y-6">
            <h2 className="text-2xl font-bold text-indigo-700">Structured Learning Paths</h2>
            
            <div className="space-y-6">
              <Card className="border-l-4 border-l-blue-500">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Globe className="h-5 w-5 text-blue-500" />
                    Frontend Development Path
                  </CardTitle>
                  <CardDescription>Master modern frontend development with React and TypeScript</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-sm">1. HTML/CSS Basics → 2. JavaScript Fundamentals → 3. React Basics → 4. TypeScript Integration → 5. Advanced React Patterns</span>
                    </div>
                    <div className="flex items-center gap-4 text-sm text-muted-foreground">
                      <span>8 Projects</span>
                      <span>12-16 weeks</span>
                      <span>Beginner to Advanced</span>
                    </div>
                    <Button className="bg-blue-500 hover:bg-blue-600">Start Learning Path</Button>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-l-4 border-l-green-500">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Database className="h-5 w-5 text-green-500" />
                    Backend Development Path
                  </CardTitle>
                  <CardDescription>Build scalable backend systems with Node.js and databases</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-sm">1. Node.js Basics → 2. Express Framework → 3. Database Design → 4. Authentication → 5. API Design → 6. Deployment</span>
                    </div>
                    <div className="flex items-center gap-4 text-sm text-muted-foreground">
                      <span>10 Projects</span>
                      <span>14-18 weeks</span>
                      <span>Beginner to Advanced</span>
                    </div>
                    <Button className="bg-green-500 hover:bg-green-600">Start Learning Path</Button>
                  </div>
                </CardContent>
              </Card>

              <Card className="border-l-4 border-l-purple-500">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Cpu className="h-5 w-5 text-purple-500" />
                    AI/ML Development Path
                  </CardTitle>
                  <CardDescription>Learn machine learning and AI development with Python</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="text-sm">1. Python Basics → 2. Data Science → 3. ML Fundamentals → 4. Deep Learning → 5. Model Deployment</span>
                    </div>
                    <div className="flex items-center gap-4 text-sm text-muted-foreground">
                      <span>12 Projects</span>
                      <span>16-20 weeks</span>
                      <span>Intermediate to Advanced</span>
                    </div>
                    <Button className="bg-purple-500 hover:bg-purple-600">Start Learning Path</Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </PlatformLayout>
  );
}