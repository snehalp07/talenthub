import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import PlatformLayout from "@/components/layout/platform-layout";
import { platformConfigs } from "@/config/navigation";
import { 
  BarChart3, 
  TrendingUp, 
  Target, 
  Users,
  Trophy,
  Clock,
  CheckCircle,
  Star,
  Award,
  Brain,
  Eye,
  Calendar
} from "lucide-react";

export default function CandidateAnalytics() {
  const config = platformConfigs.candidate;

  const performanceMetrics = [
    { label: "Profile Views", value: 347, change: "+23%", trend: "up" },
    { label: "Application Success Rate", value: "68%", change: "+12%", trend: "up" },
    { label: "Skill Score Average", value: "87%", change: "+5%", trend: "up" },
    { label: "Interview Conversion", value: "34%", change: "+8%", trend: "up" }
  ];

  const skillProgress = [
    { skill: "JavaScript", score: 87, level: "Advanced", improvement: "+12%" },
    { skill: "React", score: 82, level: "Advanced", improvement: "+8%" },
    { skill: "Node.js", score: 75, level: "Intermediate", improvement: "+15%" },
    { skill: "System Design", score: 58, level: "Beginner", improvement: "+22%" },
    { skill: "TypeScript", score: 71, level: "Intermediate", improvement: "+10%" }
  ];

  const applicationStats = [
    { month: "Jan", applications: 12, interviews: 4, offers: 1 },
    { month: "Feb", applications: 18, interviews: 6, offers: 2 },
    { month: "Mar", applications: 15, interviews: 5, offers: 1 },
    { month: "Apr", applications: 22, interviews: 8, offers: 3 },
    { month: "May", applications: 19, interviews: 7, offers: 2 },
    { month: "Jun", applications: 24, interviews: 9, offers: 4 }
  ];

  const achievements = [
    {
      title: "JavaScript Expert",
      description: "Scored 90%+ in JavaScript assessment",
      earned: true,
      date: "2024-06-10"
    },
    {
      title: "Interview Ace",
      description: "Completed 5 successful interviews",
      earned: true,
      date: "2024-06-05"
    },
    {
      title: "Profile Star",
      description: "Achieved 500+ profile views",
      earned: false,
      progress: 69
    },
    {
      title: "Skill Master",
      description: "Reach expert level in 3 skills",
      earned: false,
      progress: 67
    }
  ];

  return (
    <PlatformLayout
      sidebarTitle={config.sidebarTitle}
      sidebarSubtitle={config.sidebarSubtitle}
      sidebarSections={config.sidebarSections}
      usageData={config.usageData}
    >
      <div className="max-w-6xl mx-auto px-6 py-8">
        {/* Header */}
        <div className="mb-8">
          <h2 className="text-3xl font-bold text-neutral-600 mb-2">Performance Analytics</h2>
          <p className="text-neutral-500">Track your career progress and identify areas for improvement.</p>
        </div>

        {/* Performance Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          {performanceMetrics.map((metric, index) => (
            <Card key={index} className="shadow-sm">
              <CardContent className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                    <BarChart3 className="w-6 h-6 text-blue-600" />
                  </div>
                  <Badge className="bg-green-100 text-green-600">
                    {metric.change}
                  </Badge>
                </div>
                <h3 className="text-2xl font-bold text-neutral-600 mb-1">{metric.value}</h3>
                <p className="text-sm text-neutral-500">{metric.label}</p>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Analytics */}
          <div className="lg:col-span-2 space-y-6">
            {/* Application Trends */}
            <Card className="shadow-sm">
              <CardHeader>
                <CardTitle className="text-xl">Application Activity</CardTitle>
                <CardDescription>
                  Your job application trends over the past 6 months
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {applicationStats.map((stat, index) => (
                    <div key={index} className="flex items-center justify-between p-4 border border-neutral-200 rounded-lg">
                      <div className="flex items-center space-x-4">
                        <div className="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center">
                          <Calendar className="w-4 h-4 text-blue-600" />
                        </div>
                        <span className="font-medium text-neutral-600">{stat.month}</span>
                      </div>
                      <div className="flex items-center space-x-6 text-sm">
                        <div className="text-center">
                          <p className="text-lg font-bold text-neutral-600">{stat.applications}</p>
                          <p className="text-xs text-neutral-500">Applications</p>
                        </div>
                        <div className="text-center">
                          <p className="text-lg font-bold text-blue-600">{stat.interviews}</p>
                          <p className="text-xs text-neutral-500">Interviews</p>
                        </div>
                        <div className="text-center">
                          <p className="text-lg font-bold text-green-600">{stat.offers}</p>
                          <p className="text-xs text-neutral-500">Offers</p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Skill Progress */}
            <Card className="shadow-sm">
              <CardHeader>
                <CardTitle className="text-xl">Skill Development</CardTitle>
                <CardDescription>
                  Your progress across different technical skills
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {skillProgress.map((skill, index) => (
                    <div key={index} className="space-y-2">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-3">
                          <Brain className="w-4 h-4 text-purple-600" />
                          <span className="font-medium text-neutral-600">{skill.skill}</span>
                          <Badge variant="outline" className="text-xs">{skill.level}</Badge>
                        </div>
                        <div className="flex items-center space-x-2">
                          <span className="text-sm font-bold text-neutral-600">{skill.score}%</span>
                          <Badge className="bg-green-100 text-green-600 text-xs">
                            {skill.improvement}
                          </Badge>
                        </div>
                      </div>
                      <Progress value={skill.score} className="h-2" />
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar Analytics */}
          <div className="space-y-6">
            {/* Quick Stats */}
            <Card className="shadow-sm">
              <CardHeader>
                <CardTitle className="text-lg">This Month</CardTitle>
                <CardDescription>
                  Your June performance summary
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <Eye className="w-4 h-4 text-blue-600" />
                      <span className="text-sm text-neutral-600">Profile Views</span>
                    </div>
                    <span className="font-bold text-neutral-600">89</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <Target className="w-4 h-4 text-green-600" />
                      <span className="text-sm text-neutral-600">Applications</span>
                    </div>
                    <span className="font-bold text-neutral-600">24</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <Users className="w-4 h-4 text-purple-600" />
                      <span className="text-sm text-neutral-600">Interviews</span>
                    </div>
                    <span className="font-bold text-neutral-600">9</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <Trophy className="w-4 h-4 text-orange-600" />
                      <span className="text-sm text-neutral-600">Offers</span>
                    </div>
                    <span className="font-bold text-neutral-600">4</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Achievements */}
            <Card className="shadow-sm">
              <CardHeader>
                <CardTitle className="text-lg">Achievements</CardTitle>
                <CardDescription>
                  Your career milestones and progress
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {achievements.map((achievement, index) => (
                    <div key={index} className="border border-neutral-200 rounded-lg p-3">
                      <div className="flex items-start space-x-3">
                        <div className={`w-8 h-8 ${achievement.earned ? 'bg-green-100' : 'bg-gray-100'} rounded-lg flex items-center justify-center flex-shrink-0`}>
                          {achievement.earned ? (
                            <Award className="w-4 h-4 text-green-600" />
                          ) : (
                            <Target className="w-4 h-4 text-gray-400" />
                          )}
                        </div>
                        <div className="flex-1">
                          <h4 className="font-medium text-neutral-600 mb-1">{achievement.title}</h4>
                          <p className="text-xs text-neutral-500 mb-2">{achievement.description}</p>
                          {achievement.earned ? (
                            <Badge className="bg-green-100 text-green-600 text-xs">
                              <CheckCircle className="w-3 h-3 mr-1" />
                              Earned {achievement.date}
                            </Badge>
                          ) : (
                            <div className="space-y-1">
                              <Progress value={achievement.progress} className="h-1" />
                              <p className="text-xs text-neutral-400">{achievement.progress}% complete</p>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Recommendations */}
            <Card className="shadow-sm">
              <CardHeader>
                <CardTitle className="text-lg">Recommendations</CardTitle>
                <CardDescription>
                  Personalized suggestions to improve your performance
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="border border-neutral-200 rounded-lg p-3">
                    <div className="flex items-center space-x-2 mb-2">
                      <TrendingUp className="w-4 h-4 text-blue-600" />
                      <span className="text-sm font-medium">Boost Profile Views</span>
                    </div>
                    <p className="text-xs text-neutral-600 mb-2">Add a professional headshot to increase profile views by 40%</p>
                    <Badge variant="outline" className="text-xs">High Impact</Badge>
                  </div>
                  <div className="border border-neutral-200 rounded-lg p-3">
                    <div className="flex items-center space-x-2 mb-2">
                      <Brain className="w-4 h-4 text-purple-600" />
                      <span className="text-sm font-medium">Skill Development</span>
                    </div>
                    <p className="text-xs text-neutral-600 mb-2">Focus on System Design to reach Advanced level</p>
                    <Badge variant="outline" className="text-xs">Recommended</Badge>
                  </div>
                  <div className="border border-neutral-200 rounded-lg p-3">
                    <div className="flex items-center space-x-2 mb-2">
                      <Clock className="w-4 h-4 text-green-600" />
                      <span className="text-sm font-medium">Application Timing</span>
                    </div>
                    <p className="text-xs text-neutral-600 mb-2">Apply within 2 days of job posting for better response rates</p>
                    <Badge variant="outline" className="text-xs">Strategy</Badge>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </PlatformLayout>
  );
}