import { useState, useRef, useEffect } from "react";
import { useAuth } from "@/hooks/use-auth";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { useToast } from "@/hooks/use-toast";
import { 
  Brain, 
  Mic, 
  MicOff, 
  Camera, 
  CameraOff,
  Play,
  Pause,
  Square,
  SkipForward,
  Clock,
  Star,
  MessageSquare,
  FileText,
  BarChart3,
  Eye,
  Download,
  Share,
  Settings,
  Volume2,
  VolumeX,
  Lightbulb,
  Target,
  Award,
  TrendingUp,
  AlertCircle,
  CheckCircle,
  RefreshCw,
  Zap
} from "lucide-react";
import PlatformLayout from "@/components/layout/platform-layout";
import { platformConfigs } from "@/config/complete-navigation";

function AIMockInterviewsContent() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [isRecording, setIsRecording] = useState(false);
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [interviewMode, setInterviewMode] = useState("practice");
  const [selectedRole, setSelectedRole] = useState("frontend-developer");
  const [difficulty, setDifficulty] = useState("intermediate");
  const [sessionActive, setSessionActive] = useState(false);
  const [responseTime, setResponseTime] = useState(0);
  const videoRef = useRef<HTMLVideoElement>(null);
  const [currentResponse, setCurrentResponse] = useState("");

  const { data: interviewTypes } = useQuery({
    queryKey: ["/api/ai-interviews/types"],
    initialData: [
      {
        id: "frontend-developer",
        title: "Frontend Developer",
        description: "React, JavaScript, CSS, and web development fundamentals",
        duration: "45 minutes",
        questionCount: 12,
        topics: ["JavaScript", "React", "CSS", "Performance", "Testing"]
      },
      {
        id: "full-stack-developer",
        title: "Full Stack Developer", 
        description: "Frontend, backend, databases, and system design",
        duration: "60 minutes",
        questionCount: 15,
        topics: ["JavaScript", "Node.js", "Databases", "APIs", "System Design"]
      },
      {
        id: "data-scientist",
        title: "Data Scientist",
        description: "Machine learning, statistics, and data analysis",
        duration: "50 minutes",
        questionCount: 10,
        topics: ["Python", "Machine Learning", "Statistics", "SQL", "Data Visualization"]
      },
      {
        id: "product-manager",
        title: "Product Manager",
        description: "Product strategy, analytics, and stakeholder management",
        duration: "55 minutes",
        questionCount: 8,
        topics: ["Product Strategy", "Analytics", "User Research", "Roadmapping", "Leadership"]
      }
    ]
  });

  const { data: currentSession } = useQuery({
    queryKey: ["/api/ai-interviews/current-session"],
    enabled: sessionActive,
    initialData: {
      sessionId: "sess-001",
      role: "Frontend Developer",
      difficulty: "Intermediate",
      currentQuestionIndex: 0,
      totalQuestions: 12,
      timeElapsed: 0,
      questions: [
        {
          id: "q1",
          type: "technical",
          category: "JavaScript",
          question: "Explain the difference between let, const, and var in JavaScript. When would you use each?",
          followUp: "Can you provide a code example demonstrating hoisting with these keywords?",
          expectedDuration: 180,
          keyPoints: ["Block scope", "Hoisting", "Reassignment", "Temporal dead zone"]
        },
        {
          id: "q2", 
          type: "behavioral",
          category: "Problem Solving",
          question: "Tell me about a time when you had to debug a complex issue in production. How did you approach it?",
          followUp: "What tools or techniques did you use to identify the root cause?",
          expectedDuration: 240,
          keyPoints: ["Problem-solving approach", "Tools used", "Communication", "Prevention measures"]
        },
        {
          id: "q3",
          type: "technical",
          category: "React",
          question: "How would you optimize the performance of a React application that's rendering slowly?",
          followUp: "Can you explain when you would use React.memo vs useMemo vs useCallback?",
          expectedDuration: 300,
          keyPoints: ["Performance optimization", "React hooks", "Memoization", "Profiling"]
        }
      ]
    }
  });

  const { data: previousSessions = [] } = useQuery({
    queryKey: ["/api/ai-interviews/history"],
    initialData: [
      {
        id: "session-1",
        role: "Frontend Developer",
        difficulty: "Intermediate",
        completedAt: "2024-06-05T14:30:00Z",
        duration: 42,
        score: 87,
        strengths: ["Technical Knowledge", "Communication", "Problem Solving"],
        improvements: ["Code Examples", "Follow-up Questions"],
        questionCount: 12,
        feedback: {
          overall: "Strong performance with good technical understanding. Work on providing more concrete examples.",
          technical: 85,
          communication: 90,
          problemSolving: 88,
          confidence: 82
        }
      },
      {
        id: "session-2",
        role: "Full Stack Developer",
        difficulty: "Advanced",
        completedAt: "2024-05-28T16:15:00Z",
        duration: 58,
        score: 79,
        strengths: ["System Design", "Architecture"],
        improvements: ["Database Optimization", "Scalability Concepts"],
        questionCount: 15,
        feedback: {
          overall: "Good technical depth. Focus on scalability and performance optimization.",
          technical: 82,
          communication: 75,
          problemSolving: 80,
          confidence: 78
        }
      }
    ]
  });

  const { data: aiInsights } = useQuery({
    queryKey: ["/api/ai-interviews/insights"],
    initialData: {
      overallProgress: {
        sessionsCompleted: 8,
        averageScore: 83,
        improvementRate: 12,
        strongestAreas: ["Technical Knowledge", "Problem Solving"],
        focusAreas: ["System Design", "Behavioral Questions"]
      },
      skillAnalysis: [
        { skill: "JavaScript", score: 92, trend: "improving", sessions: 5 },
        { skill: "React", score: 88, trend: "stable", sessions: 4 },
        { skill: "System Design", score: 65, trend: "improving", sessions: 3 },
        { skill: "Communication", score: 85, trend: "improving", sessions: 8 },
        { skill: "Problem Solving", score: 90, trend: "stable", sessions: 7 }
      ],
      recommendations: [
        {
          type: "skill_focus",
          title: "Strengthen System Design",
          description: "Practice designing scalable architectures and database schemas",
          priority: "high",
          estimatedTime: "3-4 weeks"
        },
        {
          type: "interview_practice",
          title: "Behavioral Questions",
          description: "Work on STAR method for behavioral interview responses",
          priority: "medium",
          estimatedTime: "1-2 weeks"
        }
      ]
    }
  });

  const startInterviewMutation = useMutation({
    mutationFn: async (interviewConfig: any) => {
      return apiRequest("POST", "/api/ai-interviews/start", interviewConfig);
    },
    onSuccess: () => {
      setSessionActive(true);
      toast({
        title: "Interview Started",
        description: "Your AI mock interview session has begun.",
      });
    },
  });

  const submitResponseMutation = useMutation({
    mutationFn: async (responseData: any) => {
      return apiRequest("POST", "/api/ai-interviews/submit-response", responseData);
    },
    onSuccess: () => {
      setCurrentQuestion(prev => prev + 1);
      setCurrentResponse("");
    },
  });

  const startInterview = () => {
    startInterviewMutation.mutate({
      role: selectedRole,
      difficulty,
      mode: interviewMode
    });
  };

  const submitResponse = () => {
    submitResponseMutation.mutate({
      sessionId: currentSession.sessionId,
      questionId: currentSession.questions[currentQuestion].id,
      response: currentResponse,
      responseTime: responseTime,
      isRecorded: isRecording
    });
  };

  const getScoreColor = (score: number) => {
    if (score >= 85) return "text-green-600";
    if (score >= 70) return "text-yellow-600";
    return "text-red-600";
  };

  const getTrendIcon = (trend: string) => {
    if (trend === "improving") return <TrendingUp className="w-3 h-3 text-green-500" />;
    if (trend === "declining") return <TrendingUp className="w-3 h-3 text-red-500 rotate-180" />;
    return <TrendingUp className="w-3 h-3 text-gray-400" />;
  };

  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (sessionActive && !isRecording) {
      interval = setInterval(() => {
        setResponseTime(prev => prev + 1);
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [sessionActive, isRecording]);

  return (
    <div className="max-w-7xl mx-auto p-6">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">AI Mock Interviews</h1>
        <p className="text-muted-foreground">Practice with AI-powered interviews and get real-time feedback</p>
      </div>

      <Tabs defaultValue="practice" className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="practice">Practice Interview</TabsTrigger>
          <TabsTrigger value="history">Interview History</TabsTrigger>
          <TabsTrigger value="insights">AI Insights</TabsTrigger>
          <TabsTrigger value="settings">Settings</TabsTrigger>
        </TabsList>

        <TabsContent value="practice" className="space-y-6">
          {!sessionActive ? (
            <>
              {/* Interview Setup */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Brain className="w-5 h-5 mr-2 text-purple-600" />
                    Start New Interview
                  </CardTitle>
                  <CardDescription>
                    Configure your AI mock interview session
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-4">
                      <div>
                        <label className="text-sm font-medium mb-2 block">Interview Type</label>
                        <select 
                          className="w-full p-2 border rounded-md"
                          value={selectedRole}
                          onChange={(e) => setSelectedRole(e.target.value)}
                        >
                          {interviewTypes.map((type: any) => (
                            <option key={type.id} value={type.id}>
                              {type.title}
                            </option>
                          ))}
                        </select>
                      </div>

                      <div>
                        <label className="text-sm font-medium mb-2 block">Difficulty Level</label>
                        <select 
                          className="w-full p-2 border rounded-md"
                          value={difficulty}
                          onChange={(e) => setDifficulty(e.target.value)}
                        >
                          <option value="beginner">Beginner</option>
                          <option value="intermediate">Intermediate</option>
                          <option value="advanced">Advanced</option>
                          <option value="expert">Expert</option>
                        </select>
                      </div>

                      <div>
                        <label className="text-sm font-medium mb-2 block">Interview Mode</label>
                        <select 
                          className="w-full p-2 border rounded-md"
                          value={interviewMode}
                          onChange={(e) => setInterviewMode(e.target.value)}
                        >
                          <option value="practice">Practice Mode</option>
                          <option value="assessment">Assessment Mode</option>
                          <option value="quick">Quick Interview (15 min)</option>
                        </select>
                      </div>
                    </div>

                    <div className="space-y-4">
                      {selectedRole && (
                        <div className="p-4 bg-purple-50 rounded-lg">
                          <h4 className="font-medium text-purple-900 mb-2">Interview Details</h4>
                          {(() => {
                            const selected = interviewTypes.find((t: any) => t.id === selectedRole);
                            return selected ? (
                              <>
                                <p className="text-sm text-purple-800 mb-3">{selected.description}</p>
                                <div className="grid grid-cols-2 gap-4 text-sm">
                                  <div>
                                    <span className="text-purple-600">Duration:</span>
                                    <span className="ml-1">{selected.duration}</span>
                                  </div>
                                  <div>
                                    <span className="text-purple-600">Questions:</span>
                                    <span className="ml-1">{selected.questionCount}</span>
                                  </div>
                                </div>
                                <div className="mt-3">
                                  <span className="text-purple-600 text-sm">Topics:</span>
                                  <div className="flex flex-wrap gap-1 mt-1">
                                    {selected.topics.map((topic: string) => (
                                      <Badge key={topic} variant="outline" className="text-xs">
                                        {topic}
                                      </Badge>
                                    ))}
                                  </div>
                                </div>
                              </>
                            ) : null;
                          })()}
                        </div>
                      )}

                      <Button 
                        onClick={startInterview}
                        className="w-full bg-purple-600 hover:bg-purple-700"
                        disabled={startInterviewMutation.isPending}
                      >
                        <Brain className="w-4 h-4 mr-2" />
                        {startInterviewMutation.isPending ? "Starting..." : "Start Interview"}
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Available Interview Types */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                {interviewTypes.map((type: any) => (
                  <Card 
                    key={type.id} 
                    className={`cursor-pointer transition-all ${selectedRole === type.id ? 'ring-2 ring-purple-500' : ''}`}
                    onClick={() => setSelectedRole(type.id)}
                  >
                    <CardHeader className="pb-2">
                      <CardTitle className="text-lg">{type.title}</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-sm text-gray-600 mb-3">{type.description}</p>
                      <div className="space-y-1 text-xs text-gray-500">
                        <div className="flex justify-between">
                          <span>Duration:</span>
                          <span>{type.duration}</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Questions:</span>
                          <span>{type.questionCount}</span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </>
          ) : (
            /* Active Interview Session */
            <div className="space-y-6">
              {/* Interview Progress */}
              <Card>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between mb-4">
                    <div>
                      <h3 className="text-lg font-semibold">{currentSession.role} Interview</h3>
                      <p className="text-sm text-gray-600">Question {currentQuestion + 1} of {currentSession.totalQuestions}</p>
                    </div>
                    <div className="text-right">
                      <div className="text-2xl font-bold text-purple-600">
                        {Math.floor(responseTime / 60)}:{String(responseTime % 60).padStart(2, '0')}
                      </div>
                      <p className="text-xs text-gray-500">Response Time</p>
                    </div>
                  </div>
                  <Progress value={(currentQuestion / currentSession.totalQuestions) * 100} className="mb-4" />
                </CardContent>
              </Card>

              {/* Current Question */}
              <Card>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="flex items-center">
                      <MessageSquare className="w-5 h-5 mr-2 text-blue-600" />
                      Interview Question
                    </CardTitle>
                    <Badge className="bg-blue-100 text-blue-800">
                      {currentSession.questions[currentQuestion]?.category}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="p-4 bg-blue-50 rounded-lg">
                      <p className="text-lg text-blue-900">
                        {currentSession.questions[currentQuestion]?.question}
                      </p>
                    </div>

                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                      {/* Video Recording Area */}
                      <div>
                        <div className="aspect-video bg-gray-900 rounded-lg flex items-center justify-center relative mb-4">
                          <video
                            ref={videoRef}
                            className="w-full h-full rounded-lg"
                            autoPlay
                            muted
                            style={{ display: isRecording ? 'block' : 'none' }}
                          />
                          {!isRecording && (
                            <div className="text-center text-white">
                              <Camera className="w-16 h-16 mx-auto mb-4 opacity-50" />
                              <p>Click record to start your response</p>
                            </div>
                          )}
                          
                          {isRecording && (
                            <div className="absolute top-4 left-4 flex items-center bg-red-600 text-white px-3 py-1 rounded-full">
                              <div className="w-2 h-2 bg-white rounded-full mr-2 animate-pulse"></div>
                              <span className="text-sm font-medium">Recording</span>
                            </div>
                          )}
                        </div>

                        <div className="flex justify-center space-x-4">
                          <Button
                            onClick={() => setIsRecording(!isRecording)}
                            variant={isRecording ? "destructive" : "default"}
                          >
                            {isRecording ? <Square className="w-4 h-4 mr-2" /> : <Play className="w-4 h-4 mr-2" />}
                            {isRecording ? "Stop Recording" : "Start Recording"}
                          </Button>
                        </div>
                      </div>

                      {/* Text Response Area */}
                      <div>
                        <label className="text-sm font-medium mb-2 block">Written Response (Optional)</label>
                        <Textarea
                          placeholder="Type your response here..."
                          value={currentResponse}
                          onChange={(e) => setCurrentResponse(e.target.value)}
                          rows={10}
                          className="mb-4"
                        />
                        
                        <div className="space-y-2">
                          <Button 
                            onClick={submitResponse}
                            className="w-full bg-green-600 hover:bg-green-700"
                            disabled={!currentResponse && !isRecording}
                          >
                            <CheckCircle className="w-4 h-4 mr-2" />
                            Submit Response
                          </Button>
                          
                          <Button 
                            variant="outline"
                            className="w-full"
                            onClick={() => setCurrentQuestion(prev => prev + 1)}
                          >
                            <SkipForward className="w-4 h-4 mr-2" />
                            Skip Question
                          </Button>
                        </div>
                      </div>
                    </div>

                    {/* AI Tips */}
                    <div className="p-4 bg-yellow-50 rounded-lg">
                      <div className="flex items-start space-x-3">
                        <Lightbulb className="w-5 h-5 text-yellow-600 mt-0.5" />
                        <div>
                          <h4 className="font-medium text-yellow-900 mb-1">AI Tip</h4>
                          <p className="text-sm text-yellow-800">
                            For this {currentSession.questions[currentQuestion]?.type} question, focus on: {" "}
                            {currentSession.questions[currentQuestion]?.keyPoints.join(", ")}
                          </p>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          )}
        </TabsContent>

        <TabsContent value="history" className="space-y-6">
          <div className="space-y-4">
            {previousSessions.map((session: any) => (
              <Card key={session.id}>
                <CardContent className="p-6">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center space-x-3 mb-2">
                        <h3 className="text-lg font-semibold">{session.role}</h3>
                        <Badge className="bg-purple-100 text-purple-800">
                          {session.difficulty}
                        </Badge>
                        <div className={`text-lg font-bold ${getScoreColor(session.score)}`}>
                          {session.score}/100
                        </div>
                      </div>
                      
                      <p className="text-sm text-gray-600 mb-4">
                        Completed {new Date(session.completedAt).toLocaleDateString()} • {session.duration} minutes • {session.questionCount} questions
                      </p>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                          <h4 className="font-medium text-sm mb-2 text-green-600">Strengths</h4>
                          <ul className="space-y-1">
                            {session.strengths.map((strength: string, index: number) => (
                              <li key={index} className="text-sm text-gray-700 flex items-center">
                                <CheckCircle className="w-3 h-3 text-green-500 mr-2" />
                                {strength}
                              </li>
                            ))}
                          </ul>
                        </div>
                        
                        <div>
                          <h4 className="font-medium text-sm mb-2 text-orange-600">Areas for Improvement</h4>
                          <ul className="space-y-1">
                            {session.improvements.map((improvement: string, index: number) => (
                              <li key={index} className="text-sm text-gray-700 flex items-center">
                                <AlertCircle className="w-3 h-3 text-orange-500 mr-2" />
                                {improvement}
                              </li>
                            ))}
                          </ul>
                        </div>
                      </div>

                      <div className="mt-4 p-3 bg-gray-50 rounded-lg">
                        <p className="text-sm text-gray-700">
                          <strong>AI Feedback:</strong> {session.feedback.overall}
                        </p>
                      </div>
                    </div>
                    
                    <div className="flex flex-col space-y-2 ml-4">
                      <Button size="sm" variant="outline">
                        <Eye className="w-3 h-3 mr-1" />
                        Review
                      </Button>
                      <Button size="sm" variant="outline">
                        <Download className="w-3 h-3 mr-1" />
                        Report
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="insights" className="space-y-6">
          {/* Overall Progress */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <BarChart3 className="w-5 h-5 mr-2 text-blue-600" />
                Performance Analytics
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-6">
                <div className="text-center">
                  <div className="text-3xl font-bold text-blue-600 mb-1">
                    {aiInsights.overallProgress.sessionsCompleted}
                  </div>
                  <div className="text-sm text-gray-600">Sessions Completed</div>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold text-green-600 mb-1">
                    {aiInsights.overallProgress.averageScore}
                  </div>
                  <div className="text-sm text-gray-600">Average Score</div>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold text-purple-600 mb-1">
                    +{aiInsights.overallProgress.improvementRate}%
                  </div>
                  <div className="text-sm text-gray-600">Improvement Rate</div>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold text-orange-600 mb-1">
                    {aiInsights.overallProgress.focusAreas.length}
                  </div>
                  <div className="text-sm text-gray-600">Focus Areas</div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Skill Analysis */}
          <Card>
            <CardHeader>
              <CardTitle>Skill Performance Analysis</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {aiInsights.skillAnalysis.map((skill: any, index: number) => (
                  <div key={index} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                    <div className="flex items-center space-x-4">
                      <div>
                        <h4 className="font-medium">{skill.skill}</h4>
                        <p className="text-sm text-gray-600">{skill.sessions} sessions practiced</p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-4">
                      <div className="flex items-center space-x-2">
                        {getTrendIcon(skill.trend)}
                        <span className="text-sm text-gray-600">{skill.trend}</span>
                      </div>
                      <div className="text-right">
                        <div className={`text-lg font-bold ${getScoreColor(skill.score)}`}>
                          {skill.score}%
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* AI Recommendations */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Target className="w-5 h-5 mr-2 text-green-600" />
                AI Recommendations
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {aiInsights.recommendations.map((rec: any, index: number) => (
                  <div key={index} className="p-4 bg-green-50 rounded-lg">
                    <div className="flex items-start justify-between">
                      <div>
                        <h4 className="font-medium text-green-900 mb-1">{rec.title}</h4>
                        <p className="text-sm text-green-800 mb-2">{rec.description}</p>
                        <div className="flex items-center space-x-2">
                          <Badge className={rec.priority === 'high' ? 'bg-red-100 text-red-800' : 'bg-yellow-100 text-yellow-800'}>
                            {rec.priority} priority
                          </Badge>
                          <span className="text-xs text-green-600">{rec.estimatedTime}</span>
                        </div>
                      </div>
                      <Button size="sm" className="bg-green-600 hover:bg-green-700">
                        Start Practice
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="settings" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Settings className="w-5 h-5 mr-2 text-gray-600" />
                Interview Settings
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <h4 className="font-medium mb-4">Recording Preferences</h4>
                  <div className="space-y-3">
                    <label className="flex items-center space-x-2">
                      <input type="checkbox" defaultChecked className="rounded" />
                      <span className="text-sm">Auto-record video responses</span>
                    </label>
                    <label className="flex items-center space-x-2">
                      <input type="checkbox" defaultChecked className="rounded" />
                      <span className="text-sm">Enable audio recording</span>
                    </label>
                    <label className="flex items-center space-x-2">
                      <input type="checkbox" className="rounded" />
                      <span className="text-sm">Save recordings locally</span>
                    </label>
                  </div>
                </div>

                <div>
                  <h4 className="font-medium mb-4">AI Feedback Settings</h4>
                  <div className="space-y-3">
                    <label className="flex items-center space-x-2">
                      <input type="checkbox" defaultChecked className="rounded" />
                      <span className="text-sm">Real-time feedback</span>
                    </label>
                    <label className="flex items-center space-x-2">
                      <input type="checkbox" defaultChecked className="rounded" />
                      <span className="text-sm">Detailed analysis reports</span>
                    </label>
                    <label className="flex items-center space-x-2">
                      <input type="checkbox" className="rounded" />
                      <span className="text-sm">Share analytics with mentors</span>
                    </label>
                  </div>
                </div>
              </div>

              <div className="pt-4 border-t">
                <Button className="bg-gray-600 hover:bg-gray-700">
                  <RefreshCw className="w-4 h-4 mr-2" />
                  Reset All Settings
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}

export default function AiMockInterviews() {
  const config = platformConfigs.candidate;
  
  const usageData = [
    { label: "Interviews Completed", current: 12, max: 30 },
    { label: "Average Score", current: 78, max: 100 },
    { label: "Skills Practiced", current: 8, max: 15 },
  ];

  return (
    <PlatformLayout
      sidebarTitle={config.sidebarTitle}
      sidebarSubtitle={config.sidebarSubtitle}
      sidebarSections={config.sidebarSections}
      usageData={usageData}
    >
      <AIMockInterviewsContent />
    </PlatformLayout>
  );
}