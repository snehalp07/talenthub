import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import PlatformLayout from "@/components/layout/platform-layout";
import { platformConfigs } from "@/config/navigation";
import { 
  Brain, 
  Zap, 
  Target, 
  Clock,
  CheckCircle,
  TrendingUp,
  Award,
  PlayCircle,
  BarChart3,
  Star,
  Code,
  Database,
  Globe,
  Smartphone
} from "lucide-react";

export default function AISkillAssessment() {
  const config = platformConfigs.candidate;

  const skillCategories = [
    {
      title: "Frontend Development",
      description: "React, Vue, Angular, CSS, HTML",
      assessments: 8,
      completion: 75,
      level: "Advanced",
      lastScore: 87,
      icon: Globe,
      color: "blue"
    },
    {
      title: "Backend Development", 
      description: "Node.js, Python, Java, APIs",
      assessments: 6,
      completion: 60,
      level: "Intermediate",
      lastScore: 78,
      icon: Database,
      color: "green"
    },
    {
      title: "Mobile Development",
      description: "React Native, Flutter, iOS, Android",
      assessments: 4,
      completion: 25,
      level: "Beginner",
      lastScore: 65,
      icon: Smartphone,
      color: "purple"
    },
    {
      title: "Data Science",
      description: "Python, ML, Analytics, Statistics",
      assessments: 5,
      completion: 40,
      level: "Intermediate",
      lastScore: 72,
      icon: BarChart3,
      color: "orange"
    }
  ];

  const aiAssessments = [
    {
      title: "React Advanced Patterns",
      difficulty: "Advanced",
      duration: "45 min",
      questions: 25,
      type: "Adaptive AI",
      description: "AI-powered assessment that adapts to your skill level in real-time",
      skills: ["React", "Hooks", "Context API", "Performance"],
      completionRate: 68,
      averageScore: 82
    },
    {
      title: "JavaScript ES6+ Mastery",
      difficulty: "Intermediate",
      duration: "30 min", 
      questions: 20,
      type: "Interactive AI",
      description: "Dynamic coding challenges with AI-powered feedback",
      skills: ["ES6", "Promises", "Async/Await", "Modules"],
      completionRate: 85,
      averageScore: 76
    },
    {
      title: "System Design Fundamentals",
      difficulty: "Advanced",
      duration: "60 min",
      questions: 15,
      type: "Scenario AI",
      description: "Real-world system design problems with AI evaluation",
      skills: ["Scalability", "Architecture", "Databases", "APIs"],
      completionRate: 45,
      averageScore: 71
    },
    {
      title: "Python Data Structures",
      difficulty: "Intermediate",
      duration: "40 min",
      questions: 18,
      type: "Code AI",
      description: "AI-graded coding exercises with instant feedback",
      skills: ["Python", "Algorithms", "Data Structures", "Optimization"],
      completionRate: 72,
      averageScore: 79
    }
  ];

  const recentResults = [
    {
      assessment: "React Advanced Patterns",
      score: 87,
      date: "2024-06-12",
      improvement: "+12%",
      rank: "Top 15%"
    },
    {
      assessment: "JavaScript ES6+ Mastery", 
      score: 82,
      date: "2024-06-10",
      improvement: "+8%",
      rank: "Top 25%"
    },
    {
      assessment: "CSS Grid & Flexbox",
      score: 91,
      date: "2024-06-08",
      improvement: "+15%",
      rank: "Top 10%"
    }
  ];

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case "Beginner":
        return "bg-green-100 text-green-600";
      case "Intermediate":
        return "bg-yellow-100 text-yellow-600";
      case "Advanced":
        return "bg-red-100 text-red-600";
      default:
        return "bg-gray-100 text-gray-600";
    }
  };

  return (
    <PlatformLayout
      sidebarTitle={config.sidebarTitle}
      sidebarSubtitle={config.sidebarSubtitle}
      sidebarSections={config.sidebarSections}
      usageData={config.usageData}
    >
      <div className="max-w-6xl mx-auto px-6 py-8">
        {/* Header */}
        <div className="mb-8">
          <h2 className="text-3xl font-bold text-neutral-600 mb-2">AI Skill Assessment</h2>
          <p className="text-neutral-500">Advanced AI-powered assessments that adapt to your skill level and provide personalized learning paths.</p>
        </div>

        {/* AI Features Banner */}
        <Card className="shadow-sm bg-gradient-to-r from-blue-50 to-purple-50 border-blue-200 mb-8">
          <CardContent className="p-6">
            <div className="flex items-center space-x-4">
              <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center">
                <Brain className="w-8 h-8 text-blue-600" />
              </div>
              <div className="flex-1">
                <h3 className="text-xl font-bold text-neutral-600 mb-2">Powered by Advanced AI</h3>
                <p className="text-neutral-600 mb-3">Our AI assessment engine adapts questions in real-time based on your responses, providing accurate skill evaluation and personalized improvement recommendations.</p>
                <div className="flex items-center space-x-4">
                  <Badge className="bg-blue-100 text-blue-600">
                    <Zap className="w-3 h-3 mr-1" />
                    Adaptive Learning
                  </Badge>
                  <Badge className="bg-purple-100 text-purple-600">
                    <Target className="w-3 h-3 mr-1" />
                    Personalized Path
                  </Badge>
                  <Badge className="bg-green-100 text-green-600">
                    <CheckCircle className="w-3 h-3 mr-1" />
                    Instant Feedback
                  </Badge>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Skill Categories Overview */}
        <div className="mb-8">
          <h3 className="text-xl font-bold text-neutral-600 mb-4">Skill Categories</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {skillCategories.map((category, index) => (
              <Card key={index} className="shadow-sm hover:shadow-md transition-shadow">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between mb-4">
                    <div className={`w-12 h-12 bg-${category.color}-100 rounded-lg flex items-center justify-center`}>
                      <category.icon className={`w-6 h-6 text-${category.color}-600`} />
                    </div>
                    <Badge className={getDifficultyColor(category.level)}>
                      {category.level}
                    </Badge>
                  </div>
                  <h4 className="font-semibold text-neutral-600 mb-2">{category.title}</h4>
                  <p className="text-sm text-neutral-500 mb-3">{category.description}</p>
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="text-neutral-500">Progress</span>
                      <span className="font-medium">{category.completion}%</span>
                    </div>
                    <Progress value={category.completion} className="h-2" />
                    <div className="flex justify-between text-xs text-neutral-400">
                      <span>{category.assessments} assessments</span>
                      <span>Last score: {category.lastScore}%</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Available AI Assessments */}
          <div className="lg:col-span-2">
            <Card className="shadow-sm">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="text-xl">AI-Powered Assessments</CardTitle>
                  <Button variant="ghost" size="sm">View All</Button>
                </div>
                <CardDescription>
                  Intelligent assessments that adapt to your skill level
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {aiAssessments.map((assessment, index) => (
                    <div key={index} className="border border-neutral-200 rounded-lg p-4 hover:bg-neutral-50 transition-colors">
                      <div className="flex items-start justify-between mb-3">
                        <div className="flex-1">
                          <div className="flex items-center space-x-2 mb-2">
                            <h4 className="font-semibold text-neutral-600">{assessment.title}</h4>
                            <Badge className={getDifficultyColor(assessment.difficulty)}>
                              {assessment.difficulty}
                            </Badge>
                            <Badge className="bg-blue-100 text-blue-600">
                              <Brain className="w-3 h-3 mr-1" />
                              {assessment.type}
                            </Badge>
                          </div>
                          <p className="text-sm text-neutral-500 mb-3">{assessment.description}</p>
                          <div className="flex items-center space-x-4 text-xs text-neutral-400 mb-3">
                            <div className="flex items-center">
                              <Clock className="w-3 h-3 mr-1" />
                              {assessment.duration}
                            </div>
                            <div className="flex items-center">
                              <CheckCircle className="w-3 h-3 mr-1" />
                              {assessment.questions} questions
                            </div>
                            <div className="flex items-center">
                              <TrendingUp className="w-3 h-3 mr-1" />
                              {assessment.completionRate}% completion rate
                            </div>
                          </div>
                          <div className="flex items-center space-x-2">
                            {assessment.skills.map((skill, skillIndex) => (
                              <Badge key={skillIndex} variant="outline" className="text-xs">
                                {skill}
                              </Badge>
                            ))}
                          </div>
                        </div>
                        <div className="text-right">
                          <p className="text-sm text-neutral-500 mb-1">Avg Score</p>
                          <p className="text-lg font-bold text-blue-600">{assessment.averageScore}%</p>
                        </div>
                      </div>
                      <div className="flex items-center justify-between pt-3 border-t border-neutral-200">
                        <div className="flex items-center space-x-2">
                          <Star className="w-4 h-4 text-yellow-500 fill-current" />
                          <span className="text-xs text-neutral-500">AI-powered adaptive questions</span>
                        </div>
                        <Button className="bg-blue-500 hover:bg-blue-600" size="sm">
                          <PlayCircle className="w-4 h-4 mr-1" />
                          Start Assessment
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar Content */}
          <div className="space-y-6">
            {/* Recent Results */}
            <Card className="shadow-sm">
              <CardHeader>
                <CardTitle className="text-lg">Recent Results</CardTitle>
                <CardDescription>
                  Your latest assessment scores and improvements
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {recentResults.map((result, index) => (
                    <div key={index} className="border border-neutral-200 rounded-lg p-3">
                      <h4 className="font-medium text-neutral-600 mb-2">{result.assessment}</h4>
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center space-x-2">
                          <Badge className="bg-green-100 text-green-600">
                            {result.score}%
                          </Badge>
                          <Badge variant="outline" className="text-xs">
                            {result.improvement}
                          </Badge>
                        </div>
                        <span className="text-xs text-neutral-400">{result.date}</span>
                      </div>
                      <p className="text-xs text-neutral-500">{result.rank} globally</p>
                    </div>
                  ))}
                </div>
                <Button variant="outline" className="w-full mt-4">
                  <BarChart3 className="w-4 h-4 mr-2" />
                  View All Results
                </Button>
              </CardContent>
            </Card>

            {/* AI Recommendations */}
            <Card className="shadow-sm">
              <CardHeader>
                <CardTitle className="text-lg">AI Recommendations</CardTitle>
                <CardDescription>
                  Personalized improvement suggestions
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="border border-neutral-200 rounded-lg p-3">
                    <div className="flex items-center space-x-2 mb-2">
                      <Brain className="w-4 h-4 text-blue-600" />
                      <span className="text-sm font-medium">Focus Area</span>
                    </div>
                    <p className="text-sm text-neutral-600 mb-1">Advanced React Patterns</p>
                    <p className="text-xs text-neutral-500">Based on your recent performance</p>
                  </div>
                  <div className="border border-neutral-200 rounded-lg p-3">
                    <div className="flex items-center space-x-2 mb-2">
                      <Target className="w-4 h-4 text-green-600" />
                      <span className="text-sm font-medium">Next Goal</span>
                    </div>
                    <p className="text-sm text-neutral-600 mb-1">System Design Certification</p>
                    <p className="text-xs text-neutral-500">Complete 3 more assessments</p>
                  </div>
                  <div className="border border-neutral-200 rounded-lg p-3">
                    <div className="flex items-center space-x-2 mb-2">
                      <Award className="w-4 h-4 text-purple-600" />
                      <span className="text-sm font-medium">Achievement</span>
                    </div>
                    <p className="text-sm text-neutral-600 mb-1">JavaScript Expert</p>
                    <p className="text-xs text-neutral-500">80% progress to unlock</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </PlatformLayout>
  );
}