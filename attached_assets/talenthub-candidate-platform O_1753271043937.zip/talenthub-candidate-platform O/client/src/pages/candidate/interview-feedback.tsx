import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  MessageSquare, 
  Star, 
  Plus,
  TrendingUp,
  TrendingDown,
  Target,
  Eye,
  Calendar,
  Clock,
  User,
  Briefcase,
  CheckCircle,
  AlertCircle,
  ThumbsUp,
  ThumbsDown,
  BarChart3,
  Lightbulb,
  Award
} from "lucide-react";
import PlatformLayout from "@/components/layout/platform-layout";
import { platformConfigs } from "@/config/complete-navigation";

function InterviewFeedbackContent() {
  const [selectedInterview, setSelectedInterview] = useState("1");

  const interviews = [
    {
      id: "1",
      jobTitle: "Senior Frontend Developer",
      company: "TechCorp Inc.",
      interviewer: "Sarah Johnson",
      date: "2024-01-15",
      duration: "60 minutes",
      status: "completed",
      overallRating: 4.2,
      feedback: {
        technical: {
          score: 8.5,
          strengths: ["Strong React knowledge", "Good problem-solving approach", "Clean code structure"],
          improvements: ["Could improve TypeScript usage", "Practice more system design"]
        },
        communication: {
          score: 7.8,
          strengths: ["Clear explanations", "Good listening skills", "Professional demeanor"],
          improvements: ["Speak with more confidence", "Ask clarifying questions earlier"]
        },
        cultural: {
          score: 9.0,
          strengths: ["Great team collaboration mindset", "Aligns with company values", "Enthusiasm for role"],
          improvements: ["Learn more about company products"]
        }
      },
      detailedFeedback: "Strong technical candidate with excellent React skills. Shows good problem-solving approach and writes clean code. Communication could be more confident, but overall a positive interview experience.",
      nextSteps: "Technical interview scheduled with team lead",
      interviewType: "Technical"
    },
    {
      id: "2",
      jobTitle: "Full Stack Engineer",
      company: "StartupXYZ",
      interviewer: "Mike Chen",
      date: "2024-01-10",
      duration: "45 minutes",
      status: "completed",
      overallRating: 3.6,
      feedback: {
        technical: {
          score: 7.0,
          strengths: ["Good frontend skills", "Understanding of databases"],
          improvements: ["Need more backend experience", "API design knowledge gaps"]
        },
        communication: {
          score: 6.5,
          strengths: ["Honest about experience level", "Willing to learn"],
          improvements: ["More structured responses", "Better examples preparation"]
        },
        cultural: {
          score: 8.2,
          strengths: ["Good cultural fit", "Startup mindset", "Adaptable"],
          improvements: ["Show more initiative examples"]
        }
      },
      detailedFeedback: "Candidate shows potential but needs more backend development experience. Good attitude and willingness to learn. Consider for junior full-stack role instead.",
      nextSteps: "Feedback provided, considering for different role",
      interviewType: "Behavioral"
    }
  ];

  const feedbackStats = {
    totalInterviews: 8,
    averageRating: 4.1,
    strongAreas: ["Technical Skills", "Problem Solving", "Cultural Fit"],
    improvementAreas: ["System Design", "Confidence", "Communication"],
    trendDirection: "up"
  };

  const commonQuestions = [
    {
      question: "Tell me about yourself",
      yourAnswer: "I'm a frontend developer with 4+ years of experience...",
      feedback: "Good structure, but could be more concise and include specific achievements",
      rating: 7,
      suggestions: ["Include quantifiable achievements", "Keep to 2-3 minutes", "Connect to the role"]
    },
    {
      question: "What's your biggest weakness?",
      yourAnswer: "I sometimes spend too much time perfecting code...",
      feedback: "Honest answer but shows how you're improving",
      rating: 8,
      suggestions: ["Mention specific steps you're taking", "Show growth mindset"]
    },
    {
      question: "Why do you want to work here?",
      yourAnswer: "The company has a great reputation...",
      feedback: "Too generic, research the company more",
      rating: 5,
      suggestions: ["Research company products", "Mention specific values", "Connect to career goals"]
    }
  ];

  const improvementPlan = [
    {
      area: "System Design",
      priority: "High",
      actions: [
        "Study common design patterns",
        "Practice whiteboard design sessions",
        "Learn about scalability concepts"
      ],
      timeline: "2-3 weeks"
    },
    {
      area: "Communication Confidence",
      priority: "Medium",
      actions: [
        "Practice mock interviews",
        "Record yourself answering questions",
        "Join public speaking groups"
      ],
      timeline: "1-2 weeks"
    },
    {
      area: "Company Research",
      priority: "Medium",
      actions: [
        "Research company products and services",
        "Understand company values and culture",
        "Follow company news and updates"
      ],
      timeline: "1 week"
    }
  ];

  const selectedInterviewData = interviews.find(i => i.id === selectedInterview);

  const getRatingColor = (rating: number) => {
    if (rating >= 8) return "text-green-600";
    if (rating >= 6) return "text-yellow-600";
    return "text-red-600";
  };

  const getPriorityColor = (priority: string) => {
    switch (priority.toLowerCase()) {
      case "high": return "bg-red-100 text-red-700";
      case "medium": return "bg-yellow-100 text-yellow-700";
      case "low": return "bg-green-100 text-green-700";
      default: return "bg-gray-100 text-gray-700";
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-sky-50 to-white p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Interview Feedback</h1>
          <p className="text-gray-600">Track your interview performance and get actionable improvement insights</p>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card className="border-blue-200">
            <CardContent className="p-6 text-center">
              <MessageSquare className="h-8 w-8 text-blue-600 mx-auto mb-2" />
              <div className="text-2xl font-bold text-blue-700">{feedbackStats.totalInterviews}</div>
              <div className="text-sm text-gray-600">Total Interviews</div>
            </CardContent>
          </Card>
          <Card className="border-green-200">
            <CardContent className="p-6 text-center">
              <Star className="h-8 w-8 text-green-600 mx-auto mb-2" />
              <div className="text-2xl font-bold text-green-700">{feedbackStats.averageRating}</div>
              <div className="text-sm text-gray-600">Average Rating</div>
            </CardContent>
          </Card>
          <Card className="border-purple-200">
            <CardContent className="p-6 text-center">
              {feedbackStats.trendDirection === "up" ? (
                <TrendingUp className="h-8 w-8 text-purple-600 mx-auto mb-2" />
              ) : (
                <TrendingDown className="h-8 w-8 text-purple-600 mx-auto mb-2" />
              )}
              <div className="text-2xl font-bold text-purple-700">
                {feedbackStats.trendDirection === "up" ? "↗" : "↘"} 12%
              </div>
              <div className="text-sm text-gray-600">Performance Trend</div>
            </CardContent>
          </Card>
          <Card className="border-orange-200">
            <CardContent className="p-6 text-center">
              <Target className="h-8 w-8 text-orange-600 mx-auto mb-2" />
              <div className="text-2xl font-bold text-orange-700">3</div>
              <div className="text-sm text-gray-600">Areas to Improve</div>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="recent-feedback" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="recent-feedback">Recent Feedback</TabsTrigger>
            <TabsTrigger value="detailed-analysis">Detailed Analysis</TabsTrigger>
            <TabsTrigger value="question-analysis">Question Analysis</TabsTrigger>
            <TabsTrigger value="improvement-plan">Improvement Plan</TabsTrigger>
          </TabsList>

          {/* Recent Feedback Tab */}
          <TabsContent value="recent-feedback">
            <div className="space-y-6">
              {/* Interview Selection */}
              <Card>
                <CardHeader>
                  <CardTitle>Recent Interview Feedback</CardTitle>
                  <CardDescription>Select an interview to view detailed feedback</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {interviews.map((interview) => (
                      <Card 
                        key={interview.id} 
                        className={`border-2 cursor-pointer hover:shadow-lg transition-shadow ${
                          selectedInterview === interview.id ? 'border-sky-500 bg-sky-50' : 'border-gray-200'
                        }`}
                        onClick={() => setSelectedInterview(interview.id)}
                      >
                        <CardContent className="p-4">
                          <div className="flex justify-between items-start mb-3">
                            <div>
                              <h3 className="font-semibold text-gray-900">{interview.jobTitle}</h3>
                              <p className="text-sm text-gray-600">{interview.company}</p>
                            </div>
                            <div className="flex items-center gap-1">
                              <Star className="h-4 w-4 text-yellow-500" />
                              <span className="font-medium">{interview.overallRating}</span>
                            </div>
                          </div>
                          <div className="text-sm text-gray-600 space-y-1">
                            <div>Date: {interview.date}</div>
                            <div>Duration: {interview.duration}</div>
                            <div>Type: {interview.interviewType}</div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* Selected Interview Feedback */}
              {selectedInterviewData && (
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center justify-between">
                      <span>{selectedInterviewData.jobTitle} - {selectedInterviewData.company}</span>
                      <Badge className="bg-blue-100 text-blue-700">{selectedInterviewData.interviewType}</Badge>
                    </CardTitle>
                    <CardDescription>
                      Interview with {selectedInterviewData.interviewer} on {selectedInterviewData.date}
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    {/* Overall Rating */}
                    <div className="text-center p-6 bg-gray-50 rounded-lg">
                      <div className="flex items-center justify-center gap-2 mb-2">
                        <Star className="h-6 w-6 text-yellow-500" />
                        <span className="text-3xl font-bold">{selectedInterviewData.overallRating}</span>
                        <span className="text-gray-600">/ 5.0</span>
                      </div>
                      <p className="text-gray-600">Overall Interview Rating</p>
                    </div>

                    {/* Detailed Feedback Breakdown */}
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                      {Object.entries(selectedInterviewData.feedback).map(([category, data]) => (
                        <Card key={category} className="border-2">
                          <CardContent className="p-4">
                            <div className="text-center mb-4">
                              <h4 className="font-medium text-gray-900 capitalize mb-2">{category} Skills</h4>
                              <div className={`text-2xl font-bold ${getRatingColor(data.score)}`}>
                                {data.score}/10
                              </div>
                            </div>

                            <div className="space-y-3">
                              <div>
                                <h5 className="font-medium text-green-600 mb-2 flex items-center gap-1">
                                  <ThumbsUp className="h-4 w-4" />
                                  Strengths
                                </h5>
                                <ul className="text-sm text-gray-600 space-y-1">
                                  {data.strengths.map((strength, index) => (
                                    <li key={index} className="flex items-start gap-2">
                                      <CheckCircle className="h-3 w-3 text-green-500 mt-1 flex-shrink-0" />
                                      {strength}
                                    </li>
                                  ))}
                                </ul>
                              </div>

                              <div>
                                <h5 className="font-medium text-orange-600 mb-2 flex items-center gap-1">
                                  <ThumbsDown className="h-4 w-4" />
                                  Areas for Improvement
                                </h5>
                                <ul className="text-sm text-gray-600 space-y-1">
                                  {data.improvements.map((improvement, index) => (
                                    <li key={index} className="flex items-start gap-2">
                                      <AlertCircle className="h-3 w-3 text-orange-500 mt-1 flex-shrink-0" />
                                      {improvement}
                                    </li>
                                  ))}
                                </ul>
                              </div>
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                    </div>

                    {/* Detailed Comments */}
                    <div className="space-y-4">
                      <div className="p-4 bg-blue-50 rounded-lg">
                        <h4 className="font-medium text-blue-900 mb-2">Interviewer Comments</h4>
                        <p className="text-blue-800">{selectedInterviewData.detailedFeedback}</p>
                      </div>

                      <div className="p-4 bg-green-50 rounded-lg">
                        <h4 className="font-medium text-green-900 mb-2">Next Steps</h4>
                        <p className="text-green-800">{selectedInterviewData.nextSteps}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              )}
            </div>
          </TabsContent>

          {/* Detailed Analysis Tab */}
          <TabsContent value="detailed-analysis">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <BarChart3 className="h-5 w-5 text-sky-600" />
                    Performance Overview
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div>
                    <h4 className="font-medium text-gray-900 mb-3">Strong Areas</h4>
                    <div className="space-y-2">
                      {feedbackStats.strongAreas.map((area, index) => (
                        <div key={index} className="flex items-center justify-between p-3 bg-green-50 rounded-lg">
                          <span className="font-medium text-green-800">{area}</span>
                          <CheckCircle className="h-5 w-5 text-green-600" />
                        </div>
                      ))}
                    </div>
                  </div>

                  <div>
                    <h4 className="font-medium text-gray-900 mb-3">Improvement Areas</h4>
                    <div className="space-y-2">
                      {feedbackStats.improvementAreas.map((area, index) => (
                        <div key={index} className="flex items-center justify-between p-3 bg-orange-50 rounded-lg">
                          <span className="font-medium text-orange-800">{area}</span>
                          <Target className="h-5 w-5 text-orange-600" />
                        </div>
                      ))}
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Progress Tracking</CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div>
                    <div className="flex justify-between mb-2">
                      <span className="text-sm font-medium">Technical Skills</span>
                      <span className="text-sm text-gray-600">8.2/10</span>
                    </div>
                    <Progress value={82} className="h-2" />
                  </div>

                  <div>
                    <div className="flex justify-between mb-2">
                      <span className="text-sm font-medium">Communication</span>
                      <span className="text-sm text-gray-600">7.1/10</span>
                    </div>
                    <Progress value={71} className="h-2" />
                  </div>

                  <div>
                    <div className="flex justify-between mb-2">
                      <span className="text-sm font-medium">Cultural Fit</span>
                      <span className="text-sm text-gray-600">8.6/10</span>
                    </div>
                    <Progress value={86} className="h-2" />
                  </div>

                  <div>
                    <div className="flex justify-between mb-2">
                      <span className="text-sm font-medium">Problem Solving</span>
                      <span className="text-sm text-gray-600">7.8/10</span>
                    </div>
                    <Progress value={78} className="h-2" />
                  </div>

                  <div className="pt-4 border-t">
                    <div className="text-center">
                      <div className="text-2xl font-bold text-sky-700 mb-1">78%</div>
                      <div className="text-sm text-gray-600">Overall Interview Success Rate</div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Question Analysis Tab */}
          <TabsContent value="question-analysis">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <MessageSquare className="h-5 w-5 text-sky-600" />
                  Common Interview Questions Analysis
                </CardTitle>
                <CardDescription>Review your responses to frequent interview questions</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  {commonQuestions.map((item, index) => (
                    <Card key={index} className="border-2">
                      <CardContent className="p-6">
                        <div className="flex justify-between items-start mb-4">
                          <h3 className="font-semibold text-gray-900 mb-2">{item.question}</h3>
                          <div className="flex items-center gap-1">
                            <Star className="h-4 w-4 text-yellow-500" />
                            <span className={`font-medium ${getRatingColor(item.rating)}`}>
                              {item.rating}/10
                            </span>
                          </div>
                        </div>

                        <div className="space-y-4">
                          <div className="p-3 bg-gray-50 rounded-lg">
                            <h4 className="font-medium text-gray-900 mb-2">Your Answer:</h4>
                            <p className="text-gray-700 italic">"{item.yourAnswer}"</p>
                          </div>

                          <div className="p-3 bg-blue-50 rounded-lg">
                            <h4 className="font-medium text-blue-900 mb-2">Interviewer Feedback:</h4>
                            <p className="text-blue-800">{item.feedback}</p>
                          </div>

                          <div>
                            <h4 className="font-medium text-gray-900 mb-2">Suggestions for Improvement:</h4>
                            <ul className="space-y-1">
                              {item.suggestions.map((suggestion, suggestionIndex) => (
                                <li key={suggestionIndex} className="flex items-start gap-2 text-sm text-gray-600">
                                  <Lightbulb className="h-4 w-4 text-yellow-500 mt-0.5 flex-shrink-0" />
                                  {suggestion}
                                </li>
                              ))}
                            </ul>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Improvement Plan Tab */}
          <TabsContent value="improvement-plan">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Target className="h-5 w-5 text-sky-600" />
                  Personalized Improvement Plan
                </CardTitle>
                <CardDescription>
                  Action plan based on your interview feedback to enhance future performance
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  {improvementPlan.map((plan, index) => (
                    <Card key={index} className="border-2">
                      <CardContent className="p-6">
                        <div className="flex justify-between items-start mb-4">
                          <div>
                            <h3 className="font-semibold text-gray-900 mb-1">{plan.area}</h3>
                            <div className="text-sm text-gray-600">Timeline: {plan.timeline}</div>
                          </div>
                          <Badge className={getPriorityColor(plan.priority)}>
                            {plan.priority} Priority
                          </Badge>
                        </div>

                        <div>
                          <h4 className="font-medium text-gray-900 mb-3">Action Steps:</h4>
                          <ul className="space-y-2">
                            {plan.actions.map((action, actionIndex) => (
                              <li key={actionIndex} className="flex items-start gap-3">
                                <div className="w-6 h-6 border-2 border-gray-300 rounded-full mt-0.5 flex-shrink-0" />
                                <span className="text-gray-700">{action}</span>
                              </li>
                            ))}
                          </ul>
                        </div>
                      </CardContent>
                    </Card>
                  ))}

                  <div className="flex gap-4">
                    <Button className="bg-sky-600 hover:bg-sky-700">
                      <Award className="h-4 w-4 mr-2" />
                      Start Improvement Plan
                    </Button>
                    <Button variant="outline">
                      <Calendar className="h-4 w-4 mr-2" />
                      Schedule Practice Session
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}

export default function InterviewFeedback() {
  const config = platformConfigs.candidate;
  
  const usageData = [
    { label: "Feedback Sessions", current: 8, max: 15 },
    { label: "Improvement Score", current: 82, max: 100 },
    { label: "Skills Practiced", current: 12, max: 20 },
  ];

  return (
    <PlatformLayout
      sidebarTitle={config.sidebarTitle}
      sidebarSubtitle={config.sidebarSubtitle}
      sidebarSections={config.sidebarSections}
      usageData={usageData}
    >
      <InterviewFeedbackContent />
    </PlatformLayout>
  );
}