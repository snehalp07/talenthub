import PlatformLayout from "@/components/layout/platform-layout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { Plus, Code, FileText, Settings, Rocket, Star, Clock, Users, Lightbulb, Target, CheckCircle, ArrowRight, Palette, Database, Globe } from "lucide-react";
import { platformConfigs } from "@/config/complete-navigation";

export default function ProjectCreator() {
  const config = platformConfigs.candidate;

  const projectTemplates = [
    {
      id: 1,
      name: "React E-commerce App",
      category: "Frontend",
      difficulty: "Intermediate",
      duration: "2-3 weeks",
      tech: ["React", "TypeScript", "Tailwind", "Stripe"],
      description: "Build a full-featured online store with payment integration",
      color: "from-blue-500 to-indigo-500",
      icon: Globe
    },
    {
      id: 2,
      name: "Node.js REST API",
      category: "Backend",
      difficulty: "Beginner",
      duration: "1-2 weeks",
      tech: ["Node.js", "Express", "MongoDB", "JWT"],
      description: "Create a scalable API with authentication and database",
      color: "from-green-500 to-emerald-500",
      icon: Database
    },
    {
      id: 3,
      name: "Full-Stack Social Platform",
      category: "Full-Stack",
      difficulty: "Advanced",
      duration: "4-6 weeks",
      tech: ["Next.js", "Prisma", "PostgreSQL", "WebSocket"],
      description: "Build a complete social media platform with real-time features",
      color: "from-purple-500 to-pink-500",
      icon: Users
    },
    {
      id: 4,
      name: "Mobile Todo App",
      category: "Mobile",
      difficulty: "Beginner",
      duration: "1 week",
      tech: ["React Native", "AsyncStorage", "Redux"],
      description: "Create a cross-platform mobile task management app",
      color: "from-orange-500 to-red-500",
      icon: CheckCircle
    },
    {
      id: 5,
      name: "AI Chat Interface",
      category: "AI/ML",
      difficulty: "Intermediate",
      duration: "2-3 weeks",
      tech: ["Python", "FastAPI", "OpenAI", "React"],
      description: "Build an intelligent chatbot with modern UI",
      color: "from-cyan-500 to-blue-500",
      icon: Lightbulb
    },
    {
      id: 6,
      name: "DevOps Portfolio",
      category: "DevOps",
      difficulty: "Advanced",
      duration: "3-4 weeks",
      tech: ["Docker", "Kubernetes", "AWS", "Terraform"],
      description: "Showcase infrastructure automation and deployment skills",
      color: "from-yellow-500 to-orange-500",
      icon: Settings
    }
  ];

  const projectSteps = [
    { step: 1, title: "Choose Template", description: "Select from pre-built templates or start from scratch", completed: false },
    { step: 2, title: "Project Setup", description: "Configure project details and requirements", completed: false },
    { step: 3, title: "Development", description: "Build your project with guided assistance", completed: false },
    { step: 4, title: "Testing & Review", description: "Test functionality and get peer feedback", completed: false },
    { step: 5, title: "Deployment", description: "Deploy and showcase your completed project", completed: false }
  ];

  return (
    <PlatformLayout
      sidebarTitle={config.sidebarTitle}
      sidebarSubtitle={config.sidebarSubtitle}
      sidebarSections={config.sidebarSections}
      usageData={config.usageData}
    >
      <div className="p-6 max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="text-center space-y-4">
          <div className="flex items-center justify-center space-x-3">
            <div className="p-3 bg-gradient-to-r from-blue-500 to-purple-500 rounded-full">
              <Plus className="h-8 w-8 text-white" />
            </div>
            <h1 className="text-4xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
              Project Creator
            </h1>
          </div>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Create impressive projects with guided templates, smart suggestions, and integrated development tools
          </p>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card className="bg-gradient-to-r from-blue-50 to-purple-50 border-blue-200">
            <CardContent className="p-4 text-center">
              <Plus className="h-8 w-8 text-blue-500 mx-auto mb-2" />
              <p className="text-2xl font-bold text-blue-600">24</p>
              <p className="text-sm text-muted-foreground">Templates Available</p>
            </CardContent>
          </Card>
          <Card className="bg-gradient-to-r from-green-50 to-emerald-50 border-green-200">
            <CardContent className="p-4 text-center">
              <Rocket className="h-8 w-8 text-green-500 mx-auto mb-2" />
              <p className="text-2xl font-bold text-green-600">3</p>
              <p className="text-sm text-muted-foreground">Projects Started</p>
            </CardContent>
          </Card>
          <Card className="bg-gradient-to-r from-purple-50 to-pink-50 border-purple-200">
            <CardContent className="p-4 text-center">
              <Star className="h-8 w-8 text-purple-500 mx-auto mb-2" />
              <p className="text-2xl font-bold text-purple-600">2</p>
              <p className="text-sm text-muted-foreground">Projects Completed</p>
            </CardContent>
          </Card>
          <Card className="bg-gradient-to-r from-orange-50 to-red-50 border-orange-200">
            <CardContent className="p-4 text-center">
              <Clock className="h-8 w-8 text-orange-500 mx-auto mb-2" />
              <p className="text-2xl font-bold text-orange-600">15</p>
              <p className="text-sm text-muted-foreground">Avg. Days to Complete</p>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="templates" className="space-y-6">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="templates">Project Templates</TabsTrigger>
            <TabsTrigger value="custom">Custom Project</TabsTrigger>
            <TabsTrigger value="guided">Guided Creation</TabsTrigger>
          </TabsList>

          <TabsContent value="templates" className="space-y-6">
            <div className="flex justify-between items-center">
              <h2 className="text-2xl font-bold text-blue-700">Choose a Template</h2>
              <div className="flex gap-2">
                <Select defaultValue="all">
                  <SelectTrigger className="w-40">
                    <SelectValue placeholder="Category" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Categories</SelectItem>
                    <SelectItem value="frontend">Frontend</SelectItem>
                    <SelectItem value="backend">Backend</SelectItem>
                    <SelectItem value="fullstack">Full-Stack</SelectItem>
                    <SelectItem value="mobile">Mobile</SelectItem>
                    <SelectItem value="ai">AI/ML</SelectItem>
                    <SelectItem value="devops">DevOps</SelectItem>
                  </SelectContent>
                </Select>
                <Select defaultValue="all">
                  <SelectTrigger className="w-40">
                    <SelectValue placeholder="Difficulty" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Levels</SelectItem>
                    <SelectItem value="beginner">Beginner</SelectItem>
                    <SelectItem value="intermediate">Intermediate</SelectItem>
                    <SelectItem value="advanced">Advanced</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {projectTemplates.map((template) => {
                const IconComponent = template.icon;
                return (
                  <Card key={template.id} className="group hover:shadow-lg transition-all duration-300 hover:-translate-y-1 border-l-4 border-l-blue-500">
                    <CardHeader className="pb-3">
                      <div className="flex items-start justify-between">
                        <div className={`p-2 bg-gradient-to-r ${template.color} rounded-lg`}>
                          <IconComponent className="h-6 w-6 text-white" />
                        </div>
                        <Badge variant="outline" className="text-xs">
                          {template.difficulty}
                        </Badge>
                      </div>
                      <CardTitle className="text-lg">{template.name}</CardTitle>
                      <CardDescription className="text-sm">{template.description}</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="flex items-center gap-2 text-sm text-muted-foreground">
                        <Clock className="h-4 w-4" />
                        <span>{template.duration}</span>
                        <Badge variant="secondary" className="text-xs ml-auto">
                          {template.category}
                        </Badge>
                      </div>
                      <div className="flex flex-wrap gap-1">
                        {template.tech.map((tech, index) => (
                          <Badge key={index} variant="outline" className="text-xs">
                            {tech}
                          </Badge>
                        ))}
                      </div>
                      <Button className="w-full bg-gradient-to-r from-blue-500 to-purple-500 hover:from-blue-600 hover:to-purple-600">
                        <Plus className="h-4 w-4 mr-2" />
                        Start Project
                      </Button>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </TabsContent>

          <TabsContent value="custom" className="space-y-6">
            <h2 className="text-2xl font-bold text-blue-700">Create Custom Project</h2>
            
            <Card>
              <CardHeader>
                <CardTitle>Project Details</CardTitle>
                <CardDescription>Define your project requirements and specifications</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Project Name</label>
                    <Input placeholder="My Awesome Project" />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Category</label>
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="Select category" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="frontend">Frontend</SelectItem>
                        <SelectItem value="backend">Backend</SelectItem>
                        <SelectItem value="fullstack">Full-Stack</SelectItem>
                        <SelectItem value="mobile">Mobile</SelectItem>
                        <SelectItem value="ai">AI/ML</SelectItem>
                        <SelectItem value="devops">DevOps</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">Description</label>
                  <Textarea placeholder="Describe your project goals and features..." />
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Expected Duration</label>
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="Timeline" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="1week">1 Week</SelectItem>
                        <SelectItem value="2weeks">2 Weeks</SelectItem>
                        <SelectItem value="1month">1 Month</SelectItem>
                        <SelectItem value="3months">3 Months</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Difficulty Level</label>
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="Difficulty" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="beginner">Beginner</SelectItem>
                        <SelectItem value="intermediate">Intermediate</SelectItem>
                        <SelectItem value="advanced">Advanced</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">Technology Stack</label>
                  <Input placeholder="React, Node.js, PostgreSQL, etc." />
                </div>
                <Button className="w-full bg-gradient-to-r from-green-500 to-emerald-500 hover:from-green-600 hover:to-emerald-600">
                  <Rocket className="h-4 w-4 mr-2" />
                  Create Project
                </Button>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="guided" className="space-y-6">
            <h2 className="text-2xl font-bold text-blue-700">Guided Project Creation</h2>
            
            <Card>
              <CardHeader>
                <CardTitle>Step-by-Step Project Builder</CardTitle>
                <CardDescription>Follow our guided process to create the perfect project for your goals</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-4">
                  {projectSteps.map((step, index) => (
                    <div key={step.step} className="flex items-center space-x-4">
                      <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                        step.completed ? 'bg-green-500 text-white' : 
                        index === 0 ? 'bg-blue-500 text-white' : 'bg-gray-200 text-gray-500'
                      }`}>
                        {step.completed ? <CheckCircle className="h-4 w-4" /> : step.step}
                      </div>
                      <div className="flex-1">
                        <h3 className={`font-medium ${index === 0 ? 'text-blue-600' : 'text-gray-700'}`}>
                          {step.title}
                        </h3>
                        <p className="text-sm text-muted-foreground">{step.description}</p>
                      </div>
                      {index === 0 && (
                        <ArrowRight className="h-5 w-5 text-blue-500" />
                      )}
                    </div>
                  ))}
                </div>
                
                <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
                  <h4 className="font-medium text-blue-800 mb-2">Current Step: Choose Template</h4>
                  <p className="text-sm text-blue-600 mb-3">
                    Let's start by understanding your interests and skill level to recommend the best project template.
                  </p>
                  <Button className="bg-blue-500 hover:bg-blue-600">
                    <Target className="h-4 w-4 mr-2" />
                    Start Guided Setup
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </PlatformLayout>
  );
}