import { useState } from "react";
import PlatformLayout from "@/components/layout/platform-layout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { FileText, Upload, Download, Eye, Shield, Clock, CheckCircle, AlertCircle } from "lucide-react";
import { candidateNavigation } from "@/config/complete-navigation";

export default function DocumentCenter() {
  const [selectedDoc, setSelectedDoc] = useState<string | null>(null);

  const documents = [
    {
      id: "resume-2024",
      name: "Professional Resume 2024.pdf",
      type: "Resume",
      status: "Verified",
      uploadDate: "2024-12-15",
      size: "2.4 MB",
      verificationStatus: "Approved",
      downloads: 24,
      views: 156
    },
    {
      id: "degree-cert",
      name: "Computer Science Degree Certificate.pdf",
      type: "Education",
      status: "Pending",
      uploadDate: "2024-12-20",
      size: "1.8 MB",
      verificationStatus: "Under Review",
      downloads: 0,
      views: 3
    },
    {
      id: "portfolio",
      name: "Development Portfolio 2024.pdf",
      type: "Portfolio",
      status: "Verified",
      uploadDate: "2024-12-10",
      size: "5.2 MB",
      verificationStatus: "Approved",
      downloads: 18,
      views: 89
    },
    {
      id: "certifications",
      name: "AWS & React Certifications.pdf",
      type: "Certifications",
      status: "Verified",
      uploadDate: "2024-12-08",
      size: "3.1 MB",
      verificationStatus: "Approved",
      downloads: 31,
      views: 127
    }
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case "Verified": return "bg-green-100 text-green-800";
      case "Pending": return "bg-yellow-100 text-yellow-800";
      case "Rejected": return "bg-red-100 text-red-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "Verified": return <CheckCircle className="h-4 w-4 text-green-600" />;
      case "Pending": return <Clock className="h-4 w-4 text-yellow-600" />;
      case "Rejected": return <AlertCircle className="h-4 w-4 text-red-600" />;
      default: return <Clock className="h-4 w-4 text-gray-600" />;
    }
  };

  return (
    <PlatformLayout
      sidebarTitle="Candidate Platform"
      sidebarSubtitle="Your Professional Journey"
      sidebarSections={candidateNavigation}
    >
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-indigo-50 p-6">
        <div className="max-w-6xl mx-auto">
          {/* Header */}
          <div className="mb-8">
            <div className="flex items-center gap-3 mb-4">
              <div className="bg-blue-600 p-2 rounded-lg">
                <FileText className="h-6 w-6 text-white" />
              </div>
              <div>
                <h1 className="text-3xl font-bold bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">
                  Document Center
                </h1>
                <p className="text-gray-600">Manage your professional documents and certifications</p>
              </div>
            </div>
          </div>

          {/* Stats Cards */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
            <Card className="bg-gradient-to-br from-blue-500 to-blue-600 text-white">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-blue-100">Total Documents</p>
                    <p className="text-2xl font-bold">12</p>
                  </div>
                  <FileText className="h-8 w-8 text-blue-200" />
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-br from-green-500 to-green-600 text-white">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-green-100">Verified</p>
                    <p className="text-2xl font-bold">9</p>
                  </div>
                  <CheckCircle className="h-8 w-8 text-green-200" />
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-br from-yellow-500 to-yellow-600 text-white">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-yellow-100">Pending Review</p>
                    <p className="text-2xl font-bold">2</p>
                  </div>
                  <Clock className="h-8 w-8 text-yellow-200" />
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-br from-purple-500 to-purple-600 text-white">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-purple-100">Storage Used</p>
                    <p className="text-2xl font-bold">15.2 GB</p>
                  </div>
                  <Shield className="h-8 w-8 text-purple-200" />
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Upload Section */}
          <Card className="mb-8 bg-gradient-to-r from-blue-50 to-indigo-50 border-blue-200">
            <CardHeader>
              <CardTitle className="text-blue-800 flex items-center gap-2">
                <Upload className="h-5 w-5" />
                Upload New Document
              </CardTitle>
              <CardDescription>
                Upload your professional documents for verification and sharing with recruiters
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="border-2 border-dashed border-blue-300 rounded-lg p-8 text-center">
                <Upload className="h-12 w-12 text-blue-400 mx-auto mb-4" />
                <p className="text-lg font-medium text-gray-700 mb-2">
                  Drag and drop your files here, or click to browse
                </p>
                <p className="text-sm text-gray-500 mb-4">
                  Supported formats: PDF, DOC, DOCX, JPG, PNG (Max 10MB per file)
                </p>
                <Button className="bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700">
                  <Upload className="h-4 w-4 mr-2" />
                  Choose Files
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Document List */}
          <div className="space-y-4">
            <h2 className="text-2xl font-bold text-gray-800 mb-6">Your Documents</h2>
            
            {documents.map((doc) => (
              <Card key={doc.id} className="hover:shadow-lg transition-all duration-300 border-l-4 border-l-blue-500">
                <CardHeader>
                  <div className="flex justify-between items-start">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <FileText className="h-5 w-5 text-blue-600" />
                        <CardTitle className="text-lg text-gray-800">{doc.name}</CardTitle>
                        <Badge className={getStatusColor(doc.status)}>
                          {getStatusIcon(doc.status)}
                          <span className="ml-1">{doc.status}</span>
                        </Badge>
                        <Badge variant="outline" className="bg-blue-50 text-blue-700">
                          {doc.type}
                        </Badge>
                      </div>
                      
                      <div className="flex items-center gap-6 text-sm text-gray-600 mb-3">
                        <span>Size: {doc.size}</span>
                        <span>Uploaded: {doc.uploadDate}</span>
                        <span>Views: {doc.views}</span>
                        <span>Downloads: {doc.downloads}</span>
                      </div>
                      
                      <div className="flex items-center gap-2 text-sm">
                        <span className="text-gray-600">Verification Status:</span>
                        <span className={`font-medium ${
                          doc.verificationStatus === 'Approved' ? 'text-green-600' : 
                          doc.verificationStatus === 'Under Review' ? 'text-yellow-600' : 
                          'text-red-600'
                        }`}>
                          {doc.verificationStatus}
                        </span>
                      </div>
                    </div>
                    
                    <div className="flex gap-2">
                      <Button 
                        variant="outline" 
                        size="sm"
                        className="border-blue-200 text-blue-700 hover:bg-blue-50"
                      >
                        <Eye className="h-4 w-4 mr-1" />
                        View
                      </Button>
                      <Button 
                        variant="outline" 
                        size="sm"
                        className="border-green-200 text-green-700 hover:bg-green-50"
                      >
                        <Download className="h-4 w-4 mr-1" />
                        Download
                      </Button>
                    </div>
                  </div>
                </CardHeader>
                
                {doc.status === "Pending" && (
                  <CardContent className="pt-0">
                    <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
                      <div className="flex items-center gap-2 mb-2">
                        <Clock className="h-4 w-4 text-yellow-600" />
                        <span className="font-medium text-yellow-800">Verification in Progress</span>
                      </div>
                      <p className="text-sm text-yellow-700 mb-3">
                        Your document is currently being reviewed by our verification team. 
                        This process typically takes 2-3 business days.
                      </p>
                      <Progress value={65} className="h-2" />
                      <p className="text-xs text-yellow-600 mt-1">Estimated completion: 1-2 days</p>
                    </div>
                  </CardContent>
                )}
              </Card>
            ))}
          </div>

          {/* Document Guidelines */}
          <Card className="mt-8 bg-gradient-to-r from-indigo-50 to-purple-50 border-indigo-200">
            <CardHeader>
              <CardTitle className="text-indigo-800">Document Guidelines</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <h4 className="font-semibold text-gray-800 mb-2">Accepted Document Types</h4>
                  <ul className="space-y-1 text-sm text-gray-600">
                    <li>• Professional Resume/CV</li>
                    <li>• Educational Certificates & Transcripts</li>
                    <li>• Professional Certifications</li>
                    <li>• Portfolio & Work Samples</li>
                    <li>• Letters of Recommendation</li>
                    <li>• Training Completion Certificates</li>
                  </ul>
                </div>
                
                <div>
                  <h4 className="font-semibold text-gray-800 mb-2">Best Practices</h4>
                  <ul className="space-y-1 text-sm text-gray-600">
                    <li>• Use clear, high-resolution scans</li>
                    <li>• Ensure all text is readable</li>
                    <li>• Include complete document pages</li>
                    <li>• Use professional file naming</li>
                    <li>• Keep file sizes under 10MB</li>
                    <li>• Verify document authenticity</li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </PlatformLayout>
  );
}