import PlatformLayout from "@/components/layout/platform-layout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { Zap, TrendingUp, BarChart3, Globe, Search, Filter, BookOpen, Users, Clock, Star, ChevronRight, ArrowUp, ArrowDown, Eye, MessageSquare, Share } from "lucide-react";
import { platformConfigs } from "@/config/complete-navigation";

export default function IndustryInsights() {
  const config = platformConfigs.candidate;
  const insights = [
    {
      id: 1,
      title: "AI & Machine Learning Trends in 2025",
      category: "Technology",
      readTime: "8 min",
      views: 12450,
      publishDate: "June 18, 2025",
      author: "Dr. Alex Chen",
      company: "Google AI",
      excerpt: "Exploring the latest developments in artificial intelligence and their impact on software development careers...",
      image: "https://images.unsplash.com/photo-1677442136019-21780ecad995?w=400&h=250&fit=crop",
      trending: true,
      tags: ["AI", "Machine Learning", "Career Growth"],
      engagement: { likes: 234, comments: 45, shares: 67 }
    },
    {
      id: 2,
      title: "Remote Work Evolution: What's Next",
      category: "Workplace",
      readTime: "6 min",
      views: 8920,
      publishDate: "June 17, 2025",
      author: "Sarah Mitchell",
      company: "Microsoft",
      excerpt: "How remote work continues to reshape the professional landscape and what skills matter most...",
      image: "https://images.unsplash.com/photo-1664575602276-acd073f104c1?w=400&h=250&fit=crop",
      trending: false,
      tags: ["Remote Work", "Future of Work", "Productivity"],
      engagement: { likes: 189, comments: 32, shares: 41 }
    },
    {
      id: 3,
      title: "Cybersecurity Skills Gap: Opportunities Ahead",
      category: "Security",
      readTime: "10 min",
      views: 15670,
      publishDate: "June 16, 2025",
      author: "Marcus Thompson",
      company: "CrowdStrike",
      excerpt: "The growing demand for cybersecurity professionals and how to break into this lucrative field...",
      image: "https://images.unsplash.com/photo-1555949963-aa79dcee981c?w=400&h=250&fit=crop",
      trending: true,
      tags: ["Cybersecurity", "Career Transition", "High Demand"],
      engagement: { likes: 312, comments: 58, shares: 89 }
    }
  ];

  const marketTrends = [
    {
      skill: "Artificial Intelligence",
      growth: 45,
      demand: "Very High",
      avgSalary: "$125,000",
      trend: "up",
      change: "+12%"
    },
    {
      skill: "Cloud Computing",
      growth: 38,
      demand: "High",
      avgSalary: "$110,000",
      trend: "up",
      change: "+8%"
    },
    {
      skill: "Data Science",
      growth: 35,
      demand: "High",
      avgSalary: "$118,000",
      trend: "up",
      change: "+15%"
    },
    {
      skill: "DevOps",
      growth: 32,
      demand: "High",
      avgSalary: "$105,000",
      trend: "up",
      change: "+6%"
    },
    {
      skill: "Cybersecurity",
      growth: 42,
      demand: "Very High",
      avgSalary: "$120,000",
      trend: "up",
      change: "+18%"
    }
  ];

  const categories = [
    { name: "Technology", count: 45, color: "bg-blue-500", growth: "+12%" },
    { name: "Healthcare", count: 28, color: "bg-green-500", growth: "+8%" },
    { name: "Finance", count: 32, color: "bg-purple-500", growth: "+15%" },
    { name: "Education", count: 18, color: "bg-orange-500", growth: "+6%" },
    { name: "Manufacturing", count: 22, color: "bg-red-500", growth: "+10%" },
    { name: "Retail", count: 16, color: "bg-pink-500", growth: "+4%" }
  ];

  const reportData = [
    {
      title: "Q2 2025 Tech Salary Report",
      type: "Salary Analysis",
      date: "June 2025",
      downloads: 2450,
      preview: "Comprehensive analysis of technology sector compensation trends...",
      size: "2.8 MB"
    },
    {
      title: "Future Skills Forecast 2025-2030",
      type: "Skills Analysis", 
      date: "May 2025",
      downloads: 3200,
      preview: "Predictive analysis of emerging skills and career opportunities...",
      size: "4.1 MB"
    },
    {
      title: "Remote Work Impact Study",
      type: "Workplace Research",
      date: "April 2025", 
      downloads: 1890,
      preview: "In-depth study on the long-term effects of remote work adoption...",
      size: "3.5 MB"
    }
  ];

  return (
    <PlatformLayout
      sidebarTitle={config.sidebarTitle}
      sidebarSubtitle={config.sidebarSubtitle}
      sidebarSections={config.sidebarSections}
      usageData={config.usageData}
    >
      <div className="p-6 max-w-7xl mx-auto space-y-6">
      {/* Header */}
      <div className="text-center space-y-4">
        <div className="flex items-center justify-center space-x-3">
          <div className="p-3 bg-gradient-to-r from-orange-500 to-red-500 rounded-full">
            <Zap className="h-8 w-8 text-white" />
          </div>
          <h1 className="text-4xl font-bold bg-gradient-to-r from-orange-600 to-red-600 bg-clip-text text-transparent">
            Industry Insights
          </h1>
        </div>
        <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
          Stay ahead with the latest industry trends, market analysis, and career insights
        </p>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="bg-gradient-to-r from-orange-50 to-red-50 border-orange-200">
          <CardContent className="p-4 text-center">
            <BookOpen className="h-8 w-8 text-orange-500 mx-auto mb-2" />
            <p className="text-2xl font-bold text-orange-600">1,250+</p>
            <p className="text-sm text-muted-foreground">Insights Published</p>
          </CardContent>
        </Card>
        <Card className="bg-gradient-to-r from-blue-50 to-cyan-50 border-blue-200">
          <CardContent className="p-4 text-center">
            <TrendingUp className="h-8 w-8 text-blue-500 mx-auto mb-2" />
            <p className="text-2xl font-bold text-blue-600">85%</p>
            <p className="text-sm text-muted-foreground">Accuracy Rate</p>
          </CardContent>
        </Card>
        <Card className="bg-gradient-to-r from-green-50 to-emerald-50 border-green-200">
          <CardContent className="p-4 text-center">
            <Users className="h-8 w-8 text-green-500 mx-auto mb-2" />
            <p className="text-2xl font-bold text-green-600">50K+</p>
            <p className="text-sm text-muted-foreground">Monthly Readers</p>
          </CardContent>
        </Card>
        <Card className="bg-gradient-to-r from-purple-50 to-pink-50 border-purple-200">
          <CardContent className="p-4 text-center">
            <Globe className="h-8 w-8 text-purple-500 mx-auto mb-2" />
            <p className="text-2xl font-bold text-purple-600">120+</p>
            <p className="text-sm text-muted-foreground">Industries Covered</p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="latest" className="space-y-6">
        <TabsList className="grid w-full grid-cols-4 bg-orange-100">
          <TabsTrigger value="latest" className="data-[state=active]:bg-orange-500 data-[state=active]:text-white">
            Latest Insights
          </TabsTrigger>
          <TabsTrigger value="market-trends" className="data-[state=active]:bg-orange-500 data-[state=active]:text-white">
            Market Trends
          </TabsTrigger>
          <TabsTrigger value="industry-data" className="data-[state=active]:bg-orange-500 data-[state=active]:text-white">
            Industry Data
          </TabsTrigger>
          <TabsTrigger value="reports" className="data-[state=active]:bg-orange-500 data-[state=active]:text-white">
            Research Reports
          </TabsTrigger>
        </TabsList>

        <TabsContent value="latest" className="space-y-6">
          {/* Search and Filter */}
          <Card className="bg-gradient-to-r from-orange-50 to-red-50 border-orange-200">
            <CardContent className="p-6">
              <div className="flex flex-col md:flex-row gap-4">
                <div className="flex-1 relative">
                  <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                  <Input placeholder="Search insights by topic, author, or keyword..." className="pl-10 bg-white" />
                </div>
                <div className="flex gap-2">
                  <Button variant="outline" className="border-orange-300 hover:bg-orange-50">
                    <Filter className="h-4 w-4 mr-2" />
                    Filter
                  </Button>
                  <Button variant="outline" className="border-orange-300 hover:bg-orange-50">
                    <TrendingUp className="h-4 w-4 mr-2" />
                    Trending
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Featured Insights */}
          <div className="space-y-4">
            <h2 className="text-2xl font-bold text-orange-700">Featured Insights</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {insights.map((insight) => (
                <Card key={insight.id} className="group hover:shadow-lg transition-all duration-300 border-l-4 border-l-orange-500">
                  <div className="relative">
                    <img 
                      src={insight.image} 
                      alt={insight.title}
                      className="w-full h-48 object-cover rounded-t-lg"
                    />
                    <div className="absolute top-3 right-3 flex gap-2">
                      {insight.trending && (
                        <Badge className="bg-gradient-to-r from-orange-400 to-red-500 text-white">
                          <TrendingUp className="h-3 w-3 mr-1" />
                          Trending
                        </Badge>
                      )}
                      <Badge variant="secondary" className="bg-orange-100 text-orange-700">
                        {insight.category}
                      </Badge>
                    </div>
                  </div>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-lg group-hover:text-orange-600 transition-colors line-clamp-2">
                      {insight.title}
                    </CardTitle>
                    <CardDescription className="space-y-2">
                      <p className="text-sm text-muted-foreground line-clamp-2">{insight.excerpt}</p>
                      <div className="flex items-center justify-between text-xs text-muted-foreground">
                        <span>By {insight.author}</span>
                        <span>{insight.publishDate}</span>
                      </div>
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="pt-0 space-y-4">
                    <div className="flex flex-wrap gap-1">
                      {insight.tags.map((tag) => (
                        <Badge key={tag} variant="secondary" className="text-xs bg-orange-100 text-orange-700">
                          {tag}
                        </Badge>
                      ))}
                    </div>
                    
                    <div className="flex justify-between items-center text-sm text-muted-foreground">
                      <div className="flex items-center gap-4">
                        <div className="flex items-center gap-1">
                          <Eye className="h-4 w-4" />
                          {insight.views.toLocaleString()}
                        </div>
                        <div className="flex items-center gap-1">
                          <Clock className="h-4 w-4" />
                          {insight.readTime}
                        </div>
                      </div>
                    </div>

                    <div className="flex justify-between items-center pt-2 border-t">
                      <div className="flex items-center gap-3 text-sm">
                        <div className="flex items-center gap-1">
                          <Star className="h-4 w-4 text-yellow-500" />
                          {insight.engagement.likes}
                        </div>
                        <div className="flex items-center gap-1">
                          <MessageSquare className="h-4 w-4 text-blue-500" />
                          {insight.engagement.comments}
                        </div>
                        <div className="flex items-center gap-1">
                          <Share className="h-4 w-4 text-green-500" />
                          {insight.engagement.shares}
                        </div>
                      </div>
                      <Button size="sm" className="bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600">
                        Read More
                        <ChevronRight className="h-4 w-4 ml-1" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </TabsContent>

        <TabsContent value="market-trends" className="space-y-6">
          <h2 className="text-2xl font-bold text-orange-700">Hot Skills & Market Trends</h2>
          
          <div className="space-y-4">
            {marketTrends.map((trend, index) => (
              <Card key={index} className="border-l-4 border-l-orange-500">
                <CardContent className="p-6">
                  <div className="grid grid-cols-1 md:grid-cols-5 gap-4 items-center">
                    <div className="md:col-span-2">
                      <h3 className="text-lg font-semibold">{trend.skill}</h3>
                      <Badge 
                        variant={trend.demand === 'Very High' ? 'default' : 'secondary'}
                        className={trend.demand === 'Very High' ? 'bg-red-500' : 'bg-orange-500'}
                      >
                        {trend.demand} Demand
                      </Badge>
                    </div>
                    
                    <div className="space-y-2">
                      <div className="flex justify-between items-center">
                        <span className="text-sm text-muted-foreground">Growth</span>
                        <span className="text-sm font-medium">{trend.growth}%</span>
                      </div>
                      <Progress value={trend.growth} className="h-2" />
                    </div>
                    
                    <div className="text-center">
                      <p className="text-lg font-bold text-green-600">{trend.avgSalary}</p>
                      <p className="text-xs text-muted-foreground">Avg. Salary</p>
                    </div>
                    
                    <div className="text-center">
                      <div className={`flex items-center justify-center gap-1 ${
                        trend.trend === 'up' ? 'text-green-600' : 'text-red-600'
                      }`}>
                        {trend.trend === 'up' ? 
                          <ArrowUp className="h-4 w-4" /> : 
                          <ArrowDown className="h-4 w-4" />
                        }
                        <span className="font-medium">{trend.change}</span>
                      </div>
                      <p className="text-xs text-muted-foreground">YoY Change</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="industry-data" className="space-y-6">
          <h2 className="text-2xl font-bold text-orange-700">Industry Growth Data</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {categories.map((category) => (
              <Card key={category.name} className="group hover:shadow-lg transition-all duration-300">
                <CardContent className="p-6 text-center space-y-4">
                  <div className={`w-16 h-16 ${category.color} rounded-full flex items-center justify-center mx-auto group-hover:scale-110 transition-transform`}>
                    <BarChart3 className="h-8 w-8 text-white" />
                  </div>
                  <h3 className="text-xl font-bold group-hover:text-orange-600 transition-colors">
                    {category.name}
                  </h3>
                  <div className="space-y-2">
                    <p className="text-3xl font-bold text-orange-600">{category.count}</p>
                    <p className="text-muted-foreground">active insights</p>
                    <Badge className="bg-green-100 text-green-700">
                      <TrendingUp className="h-3 w-3 mr-1" />
                      {category.growth}
                    </Badge>
                  </div>
                  <Button variant="outline" className="w-full border-orange-300 hover:bg-orange-50">
                    View Insights
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="reports" className="space-y-6">
          <h2 className="text-2xl font-bold text-orange-700">Research Reports & White Papers</h2>
          
          <div className="space-y-4">
            {reportData.map((report, index) => (
              <Card key={index} className="border-l-4 border-l-orange-500">
                <CardContent className="p-6">
                  <div className="flex justify-between items-start">
                    <div className="flex-1 space-y-2">
                      <div className="flex items-center gap-3">
                        <h3 className="text-lg font-semibold">{report.title}</h3>
                        <Badge variant="outline" className="text-xs">
                          {report.type}
                        </Badge>
                      </div>
                      <p className="text-muted-foreground">{report.preview}</p>
                      <div className="flex items-center gap-4 text-sm text-muted-foreground">
                        <span>Published: {report.date}</span>
                        <span>Size: {report.size}</span>
                        <span>Downloads: {report.downloads.toLocaleString()}</span>
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <Button variant="outline" size="sm">
                        Preview
                      </Button>
                      <Button size="sm" className="bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600">
                        Download
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>
      </Tabs>
      </div>
    </PlatformLayout>
  );
}