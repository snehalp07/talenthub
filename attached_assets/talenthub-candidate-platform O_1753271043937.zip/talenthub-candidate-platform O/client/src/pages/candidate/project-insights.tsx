import PlatformLayout from "@/components/layout/platform-layout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { TrendingUp, BarChart3, Target, Star, Clock, Users, Eye, GitBranch, Calendar, Award, Zap, Brain, Globe } from "lucide-react";
import { platformConfigs } from "@/config/complete-navigation";

export default function ProjectInsights() {
  const config = platformConfigs.candidate;

  const projectInsights = [
    {
      id: 1,
      projectName: "E-commerce React App",
      insights: {
        performanceScore: 92,
        marketRelevance: 88,
        skillDevelopment: 85,
        careerImpact: 90
      },
      recommendations: [
        "Add TypeScript for better maintainability",
        "Implement PWA features for mobile experience", 
        "Add comprehensive testing suite",
        "Consider micro-frontend architecture"
      ],
      marketTrends: {
        demand: "High",
        growth: "+25%",
        salaryImpact: "+$8K"
      },
      technicalMetrics: {
        complexity: 7,
        innovation: 8,
        scalability: 6,
        security: 9
      }
    },
    {
      id: 2,
      projectName: "Node.js API Server",
      insights: {
        performanceScore: 88,
        marketRelevance: 95,
        skillDevelopment: 82,
        careerImpact: 87
      },
      recommendations: [
        "Implement GraphQL endpoints",
        "Add comprehensive API documentation",
        "Integrate monitoring and logging",
        "Implement rate limiting and caching"
      ],
      marketTrends: {
        demand: "Very High",
        growth: "+35%", 
        salaryImpact: "+$12K"
      },
      technicalMetrics: {
        complexity: 6,
        innovation: 7,
        scalability: 9,
        security: 8
      }
    }
  ];

  const skillInsights = [
    {
      skill: "React",
      proficiencyLevel: 85,
      marketDemand: 92,
      projects: 8,
      hoursInvested: 450,
      recommendations: ["Learn Next.js", "Master React Testing Library", "Explore React Native"]
    },
    {
      skill: "Node.js",
      proficiencyLevel: 78,
      marketDemand: 88,
      projects: 5,
      hoursInvested: 320,
      recommendations: ["Learn Express.js advanced patterns", "Master database optimization", "Explore microservices"]
    },
    {
      skill: "TypeScript",
      proficiencyLevel: 70,
      marketDemand: 95,
      projects: 3,
      hoursInvested: 180,
      recommendations: ["Practice advanced types", "Learn decorators", "Explore type-driven development"]
    }
  ];

  const careerInsights = [
    {
      metric: "Portfolio Strength",
      current: 78,
      target: 90,
      recommendation: "Add 2 more full-stack projects"
    },
    {
      metric: "Market Readiness",
      current: 85,
      target: 95,
      recommendation: "Focus on cloud deployment skills"
    },
    {
      metric: "Technical Depth",
      current: 72,
      target: 85,
      recommendation: "Deepen system design knowledge"
    },
    {
      metric: "Industry Trends Alignment",
      current: 88,
      target: 95,
      recommendation: "Learn AI/ML integration basics"
    }
  ];

  const getScoreColor = (score: number) => {
    if (score >= 90) return "text-green-600";
    if (score >= 75) return "text-blue-600";
    if (score >= 60) return "text-orange-600";
    return "text-red-600";
  };

  const getDemandColor = (demand: string) => {
    switch (demand) {
      case "Very High": return "bg-green-100 text-green-800 border-green-200";
      case "High": return "bg-blue-100 text-blue-800 border-blue-200";
      case "Medium": return "bg-yellow-100 text-yellow-800 border-yellow-200";
      default: return "bg-gray-100 text-gray-800 border-gray-200";
    }
  };

  return (
    <PlatformLayout
      sidebarTitle={config.sidebarTitle}
      sidebarSubtitle={config.sidebarSubtitle}
      sidebarSections={config.sidebarSections}
      usageData={config.usageData}
    >
      <div className="p-6 max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="text-center space-y-4">
          <div className="flex items-center justify-center space-x-3">
            <div className="p-3 bg-gradient-to-r from-cyan-500 to-blue-500 rounded-full">
              <TrendingUp className="h-8 w-8 text-white" />
            </div>
            <h1 className="text-4xl font-bold bg-gradient-to-r from-cyan-600 to-blue-600 bg-clip-text text-transparent">
              Project Insights
            </h1>
          </div>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            AI-driven analysis of your projects with career impact assessment and strategic recommendations
          </p>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card className="bg-gradient-to-r from-cyan-50 to-blue-50 border-cyan-200">
            <CardContent className="p-4 text-center">
              <TrendingUp className="h-8 w-8 text-cyan-500 mx-auto mb-2" />
              <p className="text-2xl font-bold text-cyan-600">90%</p>
              <p className="text-sm text-muted-foreground">Avg. Career Impact</p>
            </CardContent>
          </Card>
          <Card className="bg-gradient-to-r from-green-50 to-emerald-50 border-green-200">
            <CardContent className="p-4 text-center">
              <BarChart3 className="h-8 w-8 text-green-500 mx-auto mb-2" />
              <p className="text-2xl font-bold text-green-600">92%</p>
              <p className="text-sm text-muted-foreground">Market Relevance</p>
            </CardContent>
          </Card>
          <Card className="bg-gradient-to-r from-purple-50 to-pink-50 border-purple-200">
            <CardContent className="p-4 text-center">
              <Brain className="h-8 w-8 text-purple-500 mx-auto mb-2" />
              <p className="text-2xl font-bold text-purple-600">84%</p>
              <p className="text-sm text-muted-foreground">Skill Development</p>
            </CardContent>
          </Card>
          <Card className="bg-gradient-to-r from-orange-50 to-red-50 border-orange-200">
            <CardContent className="p-4 text-center">
              <Award className="h-8 w-8 text-orange-500 mx-auto mb-2" />
              <p className="text-2xl font-bold text-orange-600">+$10K</p>
              <p className="text-sm text-muted-foreground">Potential Salary Impact</p>
            </CardContent>
          </Card>
        </div>

        {/* Time Range Selector */}
        <div className="flex justify-between items-center">
          <h2 className="text-2xl font-bold text-cyan-700">Intelligence Dashboard</h2>
          <Select defaultValue="30days">
            <SelectTrigger className="w-40">
              <SelectValue placeholder="Time Range" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="7days">Last 7 Days</SelectItem>
              <SelectItem value="30days">Last 30 Days</SelectItem>
              <SelectItem value="3months">Last 3 Months</SelectItem>
              <SelectItem value="1year">Last Year</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <Tabs defaultValue="projects" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="projects">Project Analysis</TabsTrigger>
            <TabsTrigger value="skills">Skill Insights</TabsTrigger>
            <TabsTrigger value="career">Career Impact</TabsTrigger>
            <TabsTrigger value="recommendations">AI Recommendations</TabsTrigger>
          </TabsList>

          <TabsContent value="projects" className="space-y-6">
            <div className="space-y-6">
              {projectInsights.map((project) => (
                <Card key={project.id} className="border-l-4 border-l-cyan-500">
                  <CardHeader>
                    <CardTitle className="text-xl">{project.projectName}</CardTitle>
                    <CardDescription>Comprehensive project analysis and market positioning</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                      <div className="text-center">
                        <div className={`text-lg font-semibold ${getScoreColor(project.insights.performanceScore)}`}>
                          {project.insights.performanceScore}%
                        </div>
                        <div className="text-sm text-muted-foreground">Performance Score</div>
                        <Progress value={project.insights.performanceScore} className="h-2 mt-1" />
                      </div>
                      <div className="text-center">
                        <div className={`text-lg font-semibold ${getScoreColor(project.insights.marketRelevance)}`}>
                          {project.insights.marketRelevance}%
                        </div>
                        <div className="text-sm text-muted-foreground">Market Relevance</div>
                        <Progress value={project.insights.marketRelevance} className="h-2 mt-1" />
                      </div>
                      <div className="text-center">
                        <div className={`text-lg font-semibold ${getScoreColor(project.insights.skillDevelopment)}`}>
                          {project.insights.skillDevelopment}%
                        </div>
                        <div className="text-sm text-muted-foreground">Skill Development</div>
                        <Progress value={project.insights.skillDevelopment} className="h-2 mt-1" />
                      </div>
                      <div className="text-center">
                        <div className={`text-lg font-semibold ${getScoreColor(project.insights.careerImpact)}`}>
                          {project.insights.careerImpact}%
                        </div>
                        <div className="text-sm text-muted-foreground">Career Impact</div>
                        <Progress value={project.insights.careerImpact} className="h-2 mt-1" />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div>
                        <h4 className="font-medium mb-3">Market Analysis</h4>
                        <div className="space-y-2">
                          <div className="flex justify-between">
                            <span className="text-sm">Market Demand:</span>
                            <Badge className={getDemandColor(project.marketTrends.demand)}>
                              {project.marketTrends.demand}
                            </Badge>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-sm">Growth Rate:</span>
                            <span className="text-sm font-medium text-green-600">{project.marketTrends.growth}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-sm">Salary Impact:</span>
                            <span className="text-sm font-medium text-blue-600">{project.marketTrends.salaryImpact}</span>
                          </div>
                        </div>
                      </div>

                      <div>
                        <h4 className="font-medium mb-3">Technical Metrics</h4>
                        <div className="grid grid-cols-2 gap-3">
                          <div className="text-center p-2 bg-blue-50 rounded">
                            <div className="text-lg font-bold text-blue-600">{project.technicalMetrics.complexity}/10</div>
                            <div className="text-xs text-muted-foreground">Complexity</div>
                          </div>
                          <div className="text-center p-2 bg-purple-50 rounded">
                            <div className="text-lg font-bold text-purple-600">{project.technicalMetrics.innovation}/10</div>
                            <div className="text-xs text-muted-foreground">Innovation</div>
                          </div>
                          <div className="text-center p-2 bg-green-50 rounded">
                            <div className="text-lg font-bold text-green-600">{project.technicalMetrics.scalability}/10</div>
                            <div className="text-xs text-muted-foreground">Scalability</div>
                          </div>
                          <div className="text-center p-2 bg-orange-50 rounded">
                            <div className="text-lg font-bold text-orange-600">{project.technicalMetrics.security}/10</div>
                            <div className="text-xs text-muted-foreground">Security</div>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div>
                      <h4 className="font-medium mb-3">AI Recommendations</h4>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                        {project.recommendations.map((rec, index) => (
                          <div key={index} className="flex items-start gap-2 p-3 bg-cyan-50 border border-cyan-200 rounded-lg">
                            <Zap className="h-4 w-4 text-cyan-500 mt-0.5" />
                            <span className="text-sm text-cyan-800">{rec}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="skills" className="space-y-6">
            <h3 className="text-xl font-bold text-cyan-700">Skill Development Insights</h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {skillInsights.map((skill, index) => (
                <Card key={index} className="border-l-4 border-l-cyan-500">
                  <CardHeader className="pb-3">
                    <CardTitle className="text-lg">{skill.skill}</CardTitle>
                    <CardDescription>{skill.projects} projects • {skill.hoursInvested} hours invested</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="space-y-3">
                      <div>
                        <div className="flex justify-between text-sm mb-1">
                          <span>Proficiency Level</span>
                          <span className="font-medium">{skill.proficiencyLevel}%</span>
                        </div>
                        <Progress value={skill.proficiencyLevel} className="h-2" />
                      </div>
                      <div>
                        <div className="flex justify-between text-sm mb-1">
                          <span>Market Demand</span>
                          <span className="font-medium">{skill.marketDemand}%</span>
                        </div>
                        <Progress value={skill.marketDemand} className="h-2" />
                      </div>
                    </div>

                    <div>
                      <h4 className="text-sm font-medium mb-2">Next Steps</h4>
                      <div className="space-y-1">
                        {skill.recommendations.slice(0, 2).map((rec, i) => (
                          <div key={i} className="flex items-start gap-2 text-xs text-muted-foreground">
                            <Target className="h-3 w-3 text-cyan-500 mt-0.5" />
                            {rec}
                          </div>
                        ))}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="career" className="space-y-6">
            <h3 className="text-xl font-bold text-cyan-700">Career Development Analysis</h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {careerInsights.map((insight, index) => (
                <Card key={index}>
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between mb-4">
                      <h4 className="font-semibold">{insight.metric}</h4>
                      <div className="text-right">
                        <div className={`text-lg font-bold ${getScoreColor(insight.current)}`}>
                          {insight.current}%
                        </div>
                        <div className="text-sm text-muted-foreground">Target: {insight.target}%</div>
                      </div>
                    </div>
                    <Progress value={insight.current} className="h-3 mb-3" />
                    <div className="bg-cyan-50 p-3 rounded-lg border border-cyan-200">
                      <h5 className="text-sm font-medium text-cyan-800 mb-1">Recommendation</h5>
                      <p className="text-xs text-cyan-700">{insight.recommendation}</p>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            <Card>
              <CardHeader>
                <CardTitle>Career Trajectory Forecast</CardTitle>
                <CardDescription>AI prediction based on current progress and market trends</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="text-center p-4 bg-green-50 border border-green-200 rounded-lg">
                      <div className="text-2xl font-bold text-green-600">6 months</div>
                      <div className="text-sm text-green-800">Senior Developer Ready</div>
                    </div>
                    <div className="text-center p-4 bg-blue-50 border border-blue-200 rounded-lg">
                      <div className="text-2xl font-bold text-blue-600">12 months</div>
                      <div className="text-sm text-blue-800">Tech Lead Potential</div>
                    </div>
                    <div className="text-center p-4 bg-purple-50 border border-purple-200 rounded-lg">
                      <div className="text-2xl font-bold text-purple-600">18 months</div>
                      <div className="text-sm text-purple-800">Architecture Role Ready</div>
                    </div>
                  </div>
                  <div className="text-center">
                    <p className="text-sm text-muted-foreground">
                      Based on your current learning velocity and project quality improvements
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="recommendations" className="space-y-6">
            <h3 className="text-xl font-bold text-cyan-700">Personalized AI Recommendations</h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Target className="h-5 w-5 text-blue-500" />
                    Short-term Goals (1-3 months)
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="p-3 bg-blue-50 border border-blue-200 rounded-lg">
                      <h4 className="font-medium text-blue-800">Complete TypeScript Migration</h4>
                      <p className="text-sm text-blue-600">Convert your React projects to TypeScript for better maintainability</p>
                    </div>
                    <div className="p-3 bg-green-50 border border-green-200 rounded-lg">
                      <h4 className="font-medium text-green-800">Add Comprehensive Testing</h4>
                      <p className="text-sm text-green-600">Implement unit and integration tests to reach 80% coverage</p>
                    </div>
                    <div className="p-3 bg-purple-50 border border-purple-200 rounded-lg">
                      <h4 className="font-medium text-purple-800">Deploy to Cloud</h4>
                      <p className="text-sm text-purple-600">Learn AWS/Vercel deployment for production readiness</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Star className="h-5 w-5 text-orange-500" />
                    Long-term Objectives (6-12 months)
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="p-3 bg-orange-50 border border-orange-200 rounded-lg">
                      <h4 className="font-medium text-orange-800">Master System Design</h4>
                      <p className="text-sm text-orange-600">Learn scalable architecture patterns for senior roles</p>
                    </div>
                    <div className="p-3 bg-yellow-50 border border-yellow-200 rounded-lg">
                      <h4 className="font-medium text-yellow-800">AI/ML Integration</h4>
                      <p className="text-sm text-yellow-600">Add AI features to projects for competitive advantage</p>
                    </div>
                    <div className="p-3 bg-indigo-50 border border-indigo-200 rounded-lg">
                      <h4 className="font-medium text-indigo-800">Open Source Contributions</h4>
                      <p className="text-sm text-indigo-600">Build reputation through meaningful OSS contributions</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardHeader>
                <CardTitle>Market-Driven Action Plan</CardTitle>
                <CardDescription>Steps prioritized by market demand and career growth potential</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {[
                    { step: 1, action: "Complete Full-Stack TypeScript Project", priority: "High", timeframe: "2-3 weeks" },
                    { step: 2, action: "Build AI-Enhanced Application", priority: "High", timeframe: "4-6 weeks" },
                    { step: 3, action: "Implement Microservices Architecture", priority: "Medium", timeframe: "6-8 weeks" },
                    { step: 4, action: "Contribute to Popular Open Source Project", priority: "Medium", timeframe: "Ongoing" }
                  ].map((item) => (
                    <div key={item.step} className="flex items-center gap-4 p-3 border rounded-lg">
                      <div className="w-8 h-8 bg-cyan-500 rounded-full flex items-center justify-center text-white font-bold text-sm">
                        {item.step}
                      </div>
                      <div className="flex-1">
                        <h4 className="font-medium">{item.action}</h4>
                        <div className="flex gap-2 mt-1">
                          <Badge variant={item.priority === "High" ? "default" : "secondary"}>
                            {item.priority} Priority
                          </Badge>
                          <span className="text-sm text-muted-foreground">{item.timeframe}</span>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </PlatformLayout>
  );
}