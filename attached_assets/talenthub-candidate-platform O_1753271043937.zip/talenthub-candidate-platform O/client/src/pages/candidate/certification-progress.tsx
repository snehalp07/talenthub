import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import PlatformLayout from "@/components/layout/platform-layout";
import { candidateNavigation } from "@/config/complete-navigation";
import { 
  CheckCircle, Clock, Trophy, Target, Star, TrendingUp,
  Play, BookOpen, Brain, Award, Activity, Calendar,
  BarChart3, Zap, ArrowRight, Users, Code
} from "lucide-react";

const CertificationProgress: React.FC = () => {
  const [selectedTrack, setSelectedTrack] = useState('frontend');

  const certificationTracks = {
    frontend: {
      name: 'Frontend Development',
      icon: Code,
      color: 'blue',
      overall: 75,
      completed: 3,
      total: 4,
      modules: [
        {
          name: 'React Fundamentals',
          status: 'completed',
          score: 95,
          timeSpent: '12 hours',
          completedDate: '2024-01-15',
          skills: ['JSX', 'Components', 'Props', 'State Management']
        },
        {
          name: 'JavaScript ES6+',
          status: 'completed',
          score: 88,
          timeSpent: '8 hours',
          completedDate: '2024-01-10',
          skills: ['Arrow Functions', 'Destructuring', 'Async/Await', 'Modules']
        },
        {
          name: 'CSS & Styling',
          status: 'completed',
          score: 92,
          timeSpent: '6 hours',
          completedDate: '2024-01-05',
          skills: ['Flexbox', 'Grid', 'Responsive Design', 'CSS-in-JS']
        },
        {
          name: 'Testing & Deployment',
          status: 'in-progress',
          score: null,
          timeSpent: '3 hours',
          completedDate: null,
          progress: 60,
          skills: ['Jest', 'React Testing Library', 'CI/CD', 'Deployment']
        }
      ]
    },
    backend: {
      name: 'Backend Development',
      icon: Code,
      color: 'green',
      overall: 45,
      completed: 1,
      total: 4,
      modules: [
        {
          name: 'Node.js Fundamentals',
          status: 'completed',
          score: 87,
          timeSpent: '10 hours',
          completedDate: '2024-01-20',
          skills: ['Express.js', 'Middleware', 'Routing', 'Error Handling']
        },
        {
          name: 'Database Design',
          status: 'in-progress',
          score: null,
          timeSpent: '4 hours',
          completedDate: null,
          progress: 40,
          skills: ['SQL', 'MongoDB', 'Database Modeling', 'ORM']
        },
        {
          name: 'API Development',
          status: 'not-started',
          score: null,
          timeSpent: '0 hours',
          completedDate: null,
          skills: ['REST API', 'GraphQL', 'Authentication', 'Documentation']
        },
        {
          name: 'DevOps Basics',
          status: 'not-started',
          score: null,
          timeSpent: '0 hours',
          completedDate: null,
          skills: ['Docker', 'AWS', 'CI/CD', 'Monitoring']
        }
      ]
    },
    fullstack: {
      name: 'Full-Stack Development',
      icon: Code,
      color: 'purple',
      overall: 30,
      completed: 0,
      total: 5,
      modules: [
        {
          name: 'Frontend Integration',
          status: 'in-progress',
          score: null,
          timeSpent: '2 hours',
          completedDate: null,
          progress: 25,
          skills: ['React + Backend', 'State Management', 'API Integration']
        },
        {
          name: 'Backend Architecture',
          status: 'not-started',
          score: null,
          timeSpent: '0 hours',
          completedDate: null,
          skills: ['Microservices', 'Architecture Patterns', 'Scalability']
        },
        {
          name: 'Database Management',
          status: 'not-started',
          score: null,
          timeSpent: '0 hours',
          completedDate: null,
          skills: ['Advanced SQL', 'NoSQL', 'Database Optimization']
        },
        {
          name: 'System Design',
          status: 'not-started',
          score: null,
          timeSpent: '0 hours',
          completedDate: null,
          skills: ['System Architecture', 'Load Balancing', 'Caching']
        },
        {
          name: 'Production Deployment',
          status: 'not-started',
          score: null,
          timeSpent: '0 hours',
          completedDate: null,
          skills: ['Cloud Deployment', 'Monitoring', 'Security']
        }
      ]
    }
  };

  const selectedTrackData = certificationTracks[selectedTrack as keyof typeof certificationTracks];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed': return 'text-green-600 bg-green-100';
      case 'in-progress': return 'text-orange-600 bg-orange-100';
      case 'not-started': return 'text-gray-600 bg-gray-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'completed': return 'Completed';
      case 'in-progress': return 'In Progress';
      case 'not-started': return 'Not Started';
      default: return 'Unknown';
    }
  };

  return (
    <PlatformLayout
      sidebarTitle="Candidate Platform"
      sidebarSubtitle="Interview Preparation"
      sidebarSections={candidateNavigation}
    >
      <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-white to-purple-50 p-6">
        <div className="max-w-7xl mx-auto space-y-8">
          {/* Header */}
          <div className="text-center space-y-4">
            <div className="inline-flex items-center space-x-2 bg-indigo-100 text-indigo-800 px-4 py-2 rounded-full text-sm font-medium">
              <CheckCircle className="h-4 w-4" />
              <span>Certification Progress Tracking</span>
            </div>
            <h1 className="text-4xl font-bold text-gray-900">Your Certification Journey</h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Track your progress across all certification tracks and monitor your skill development
            </p>
          </div>

          {/* Overall Progress Summary */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card className="bg-gradient-to-r from-blue-500 to-blue-600 text-white">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-blue-100">Total Certifications</p>
                    <p className="text-3xl font-bold">4 / 13</p>
                  </div>
                  <Trophy className="h-12 w-12 text-blue-200" />
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-r from-green-500 to-green-600 text-white">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-green-100">Study Hours</p>
                    <p className="text-3xl font-bold">47h</p>
                  </div>
                  <Clock className="h-12 w-12 text-green-200" />
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-r from-purple-500 to-purple-600 text-white">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-purple-100">Average Score</p>
                    <p className="text-3xl font-bold">91%</p>
                  </div>
                  <Star className="h-12 w-12 text-purple-200" />
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Track Selection */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Target className="h-5 w-5" />
                <span>Certification Tracks</span>
              </CardTitle>
              <CardDescription>Select a track to view detailed progress</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {Object.entries(certificationTracks).map(([key, track]) => (
                  <Button
                    key={key}
                    variant={selectedTrack === key ? "default" : "outline"}
                    className={`h-auto p-4 flex flex-col items-center space-y-2 ${
                      selectedTrack === key ? 'bg-indigo-600 hover:bg-indigo-700' : ''
                    }`}
                    onClick={() => setSelectedTrack(key)}
                  >
                    <track.icon className="h-6 w-6" />
                    <div className="text-center">
                      <div className="font-medium">{track.name}</div>
                      <div className="text-sm opacity-75">{track.completed}/{track.total} modules</div>
                      <Progress value={track.overall} className="mt-2 h-2" />
                    </div>
                  </Button>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Detailed Track Progress */}
          <Card>
            <CardHeader className="bg-gradient-to-r from-indigo-500 to-purple-500 text-white">
              <CardTitle className="text-xl">{selectedTrackData.name} Progress</CardTitle>
              <CardDescription className="text-white/80">
                {selectedTrackData.completed} of {selectedTrackData.total} modules completed ({selectedTrackData.overall}%)
              </CardDescription>
            </CardHeader>
            <CardContent className="p-6">
              <div className="mb-6">
                <div className="flex justify-between items-center mb-2">
                  <span className="text-sm font-medium">Overall Progress</span>
                  <span className="text-sm text-gray-600">{selectedTrackData.overall}%</span>
                </div>
                <Progress value={selectedTrackData.overall} className="h-3" />
              </div>

              <div className="space-y-6">
                {selectedTrackData.modules.map((module: any, index: number) => (
                  <div key={index} className="border rounded-lg p-6 bg-gray-50">
                    <div className="flex items-start justify-between mb-4">
                      <div className="flex-1">
                        <h3 className="text-lg font-semibold text-gray-900">{module.name}</h3>
                        <Badge className={`mt-2 ${getStatusColor(module.status)}`}>
                          {getStatusText(module.status)}
                        </Badge>
                      </div>
                      <div className="text-right">
                        {module.score && (
                          <div className="text-2xl font-bold text-green-600">{module.score}%</div>
                        )}
                        <div className="text-sm text-gray-600">{module.timeSpent}</div>
                        {module.completedDate && (
                          <div className="text-sm text-gray-500">Completed: {module.completedDate}</div>
                        )}
                      </div>
                    </div>

                    {module.status === 'in-progress' && module.progress && (
                      <div className="mb-4">
                        <div className="flex justify-between items-center mb-2">
                          <span className="text-sm font-medium">Module Progress</span>
                          <span className="text-sm text-gray-600">{module.progress}%</span>
                        </div>
                        <Progress value={module.progress} className="h-2" />
                      </div>
                    )}

                    <div>
                      <h4 className="font-medium text-gray-700 mb-2">Skills Covered</h4>
                      <div className="flex flex-wrap gap-2">
                        {module.skills.map((skill: any, i: number) => (
                          <Badge key={i} variant="outline" className="text-xs">
                            {skill}
                          </Badge>
                        ))}
                      </div>
                    </div>

                    {module.status === 'not-started' && (
                      <Button className="mt-4 w-full" variant="outline">
                        <Play className="h-4 w-4 mr-2" />
                        Start Module
                      </Button>
                    )}

                    {module.status === 'in-progress' && (
                      <Button className="mt-4 w-full" variant="default">
                        <ArrowRight className="h-4 w-4 mr-2" />
                        Continue Learning
                      </Button>
                    )}

                    {module.status === 'completed' && (
                      <Button className="mt-4 w-full" variant="outline">
                        <BookOpen className="h-4 w-4 mr-2" />
                        Review Content
                      </Button>
                    )}
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Quick Actions */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Brain className="h-5 w-5" />
                  <span>Recommended Next Steps</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-center space-x-3 p-3 bg-blue-50 rounded-lg">
                  <Target className="h-5 w-5 text-blue-600" />
                  <div>
                    <div className="font-medium">Complete Testing Module</div>
                    <div className="text-sm text-gray-600">60% progress remaining</div>
                  </div>
                </div>
                <div className="flex items-center space-x-3 p-3 bg-green-50 rounded-lg">
                  <Play className="h-5 w-5 text-green-600" />
                  <div>
                    <div className="font-medium">Start Database Design</div>
                    <div className="text-sm text-gray-600">Begin backend track</div>
                  </div>
                </div>
                <div className="flex items-center space-x-3 p-3 bg-purple-50 rounded-lg">
                  <Award className="h-5 w-5 text-purple-600" />
                  <div>
                    <div className="font-medium">Frontend Certification Ready</div>
                    <div className="text-sm text-gray-600">Take final assessment</div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <BarChart3 className="h-5 w-5" />
                  <span>Learning Analytics</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex justify-between items-center">
                  <span className="text-sm font-medium">Study Streak</span>
                  <span className="text-2xl font-bold text-orange-600">12 days</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm font-medium">Weekly Goal</span>
                  <span className="text-sm text-gray-600">8h / 10h completed</span>
                </div>
                <Progress value={80} className="h-2" />
                <div className="flex justify-between items-center">
                  <span className="text-sm font-medium">Best Category</span>
                  <span className="text-sm font-semibold text-blue-600">React Development</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm font-medium">Improvement Area</span>
                  <span className="text-sm font-semibold text-red-600">System Design</span>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </PlatformLayout>
  );
};

export default CertificationProgress;