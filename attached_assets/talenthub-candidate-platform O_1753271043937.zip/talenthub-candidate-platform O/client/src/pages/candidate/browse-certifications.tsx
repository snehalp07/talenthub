import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Progress } from "@/components/ui/progress";
import PlatformLayout from "@/components/layout/platform-layout";
import { platformConfigs } from "@/config/complete-navigation";
import { useThemeClasses } from "@/lib/theme-config";
import { 
  GraduationCap, 
  Search, 
  Filter, 
  Star, 
  Clock, 
  Users, 
  Award,
  CheckCircle,
  BookOpen,
  Target
} from "lucide-react";

function BrowseCertificationsContent() {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("all");

  const certifications = [
    {
      id: 1,
      title: "AWS Certified Developer Associate",
      provider: "Amazon Web Services",
      category: "Cloud Computing",
      level: "Intermediate",
      duration: "40 hours",
      rating: 4.8,
      enrolled: 12847,
      price: "Free",
      skills: ["AWS", "Lambda", "DynamoDB", "S3"],
      description: "Learn to develop and maintain applications on AWS platform with hands-on experience.",
      progress: 0,
      completed: false
    },
    {
      id: 2,
      title: "Google Cloud Professional Developer",
      provider: "Google Cloud",
      category: "Cloud Computing",
      level: "Advanced",
      duration: "60 hours",
      rating: 4.9,
      enrolled: 8934,
      price: "$149",
      skills: ["GCP", "Kubernetes", "Cloud Functions", "BigQuery"],
      description: "Master Google Cloud development tools and best practices.",
      progress: 25,
      completed: false
    },
    {
      id: 3,
      title: "Microsoft Azure Fundamentals",
      provider: "Microsoft",
      category: "Cloud Computing",
      level: "Beginner",
      duration: "20 hours",
      rating: 4.7,
      enrolled: 15672,
      price: "Free",
      skills: ["Azure", "VM", "Storage", "Networking"],
      description: "Introduction to Microsoft Azure cloud services and architecture.",
      progress: 100,
      completed: true
    },
    {
      id: 4,
      title: "Certified Kubernetes Administrator",
      provider: "CNCF",
      category: "DevOps",
      level: "Advanced",
      duration: "80 hours",
      rating: 4.9,
      enrolled: 6543,
      price: "$299",
      skills: ["Kubernetes", "Docker", "Container Orchestration"],
      description: "Comprehensive training for Kubernetes cluster administration.",
      progress: 0,
      completed: false
    },
    {
      id: 5,
      title: "React Advanced Patterns",
      provider: "Meta",
      category: "Web Development",
      level: "Advanced",
      duration: "35 hours",
      rating: 4.8,
      enrolled: 9876,
      price: "$99",
      skills: ["React", "Hooks", "Context", "Performance"],
      description: "Master advanced React patterns and performance optimization techniques.",
      progress: 60,
      completed: false
    },
    {
      id: 6,
      title: "Blockchain Development Fundamentals",
      provider: "Ethereum Foundation",
      category: "Blockchain",
      level: "Intermediate",
      duration: "50 hours",
      rating: 4.6,
      enrolled: 4321,
      price: "$199",
      skills: ["Solidity", "Smart Contracts", "Web3", "DeFi"],
      description: "Learn blockchain development with Ethereum and smart contracts.",
      progress: 0,
      completed: false
    }
  ];

  const categories = [
    { id: "all", name: "All Categories", count: certifications.length },
    { id: "cloud", name: "Cloud Computing", count: 3 },
    { id: "web", name: "Web Development", count: 1 },
    { id: "devops", name: "DevOps", count: 1 },
    { id: "blockchain", name: "Blockchain", count: 1 }
  ];

  const filteredCertifications = certifications.filter(cert => {
    const matchesSearch = cert.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         cert.provider.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === "all" || 
                           cert.category.toLowerCase().includes(selectedCategory);
    return matchesSearch && matchesCategory;
  });

  const getLevelColor = (level: string) => {
    switch (level) {
      case "Beginner": return "bg-green-100 text-green-800";
      case "Intermediate": return "bg-yellow-100 text-yellow-800";
      case "Advanced": return "bg-red-100 text-red-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  const getProgressColor = (progress: number) => {
    if (progress === 0) return "bg-gray-200";
    if (progress < 50) return "bg-yellow-400";
    if (progress < 100) return "bg-blue-400";
    return "bg-green-400";
  };

  return (
    <div className="max-w-7xl mx-auto px-6 py-8">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-sky-800 mb-2">Browse Certifications</h1>
        <p className="text-sky-600">Discover industry-recognized certifications to advance your career</p>
      </div>

      {/* Search and Filters */}
      <div className="mb-8 space-y-4">
        <div className="flex flex-col md:flex-row gap-4">
          <div className="flex-1 relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
            <Input
              placeholder="Search certifications, providers, or skills..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
          <Button variant="outline" className="flex items-center gap-2">
            <Filter className="h-4 w-4" />
            Filters
          </Button>
        </div>

        {/* Category Filters */}
        <div className="flex flex-wrap gap-2">
          {categories.map((category) => (
            <Button
              key={category.id}
              variant={selectedCategory === category.id ? "default" : "outline"}
              size="sm"
              onClick={() => setSelectedCategory(category.id)}
              className="flex items-center gap-2"
            >
              {category.name}
              <Badge variant="secondary" className="ml-1">
                {category.count}
              </Badge>
            </Button>
          ))}
        </div>
      </div>

      {/* Statistics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        <Card className="border-sky-200">
          <CardContent className="p-6 text-center">
            <div className="w-12 h-12 bg-sky-100 rounded-lg flex items-center justify-center mx-auto mb-3">
              <GraduationCap className="w-6 h-6 text-sky-600" />
            </div>
            <h3 className="text-2xl font-bold text-sky-800">45+</h3>
            <p className="text-sm text-sky-600">Available Certifications</p>
          </CardContent>
        </Card>

        <Card className="border-sky-200">
          <CardContent className="p-6 text-center">
            <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mx-auto mb-3">
              <CheckCircle className="w-6 h-6 text-green-600" />
            </div>
            <h3 className="text-2xl font-bold text-sky-800">3</h3>
            <p className="text-sm text-sky-600">Completed</p>
          </CardContent>
        </Card>

        <Card className="border-sky-200">
          <CardContent className="p-6 text-center">
            <div className="w-12 h-12 bg-yellow-100 rounded-lg flex items-center justify-center mx-auto mb-3">
              <BookOpen className="w-6 h-6 text-yellow-600" />
            </div>
            <h3 className="text-2xl font-bold text-sky-800">2</h3>
            <p className="text-sm text-sky-600">In Progress</p>
          </CardContent>
        </Card>

        <Card className="border-sky-200">
          <CardContent className="p-6 text-center">
            <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center mx-auto mb-3">
              <Target className="w-6 h-6 text-purple-600" />
            </div>
            <h3 className="text-2xl font-bold text-sky-800">85%</h3>
            <p className="text-sm text-sky-600">Avg. Completion Rate</p>
          </CardContent>
        </Card>
      </div>

      {/* Certifications Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {filteredCertifications.map((cert) => (
          <Card key={cert.id} className="shadow-sm border-sky-200 hover:shadow-md transition-shadow">
            <CardHeader>
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <CardTitle className="text-xl text-sky-800 mb-2">{cert.title}</CardTitle>
                  <CardDescription className="text-sky-600 mb-3">
                    by {cert.provider}
                  </CardDescription>
                  <div className="flex items-center gap-2 mb-3">
                    <Badge className={getLevelColor(cert.level)}>{cert.level}</Badge>
                    <Badge variant="outline">{cert.category}</Badge>
                    {cert.completed && (
                      <Badge className="bg-green-100 text-green-800">
                        <CheckCircle className="w-3 h-3 mr-1" />
                        Completed
                      </Badge>
                    )}
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-lg font-bold text-sky-800">{cert.price}</div>
                  <div className="flex items-center text-sm text-gray-600">
                    <Star className="w-4 h-4 text-yellow-400 mr-1" />
                    {cert.rating}
                  </div>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600 mb-4">{cert.description}</p>
              
              {/* Progress Bar */}
              {cert.progress > 0 && (
                <div className="mb-4">
                  <div className="flex justify-between text-sm mb-1">
                    <span>Progress</span>
                    <span>{cert.progress}%</span>
                  </div>
                  <Progress value={cert.progress} className="h-2" />
                </div>
              )}

              {/* Skills */}
              <div className="mb-4">
                <p className="text-sm font-medium text-gray-700 mb-2">Skills you'll learn:</p>
                <div className="flex flex-wrap gap-1">
                  {cert.skills.map((skill, index) => (
                    <Badge key={index} variant="secondary" className="text-xs">
                      {skill}
                    </Badge>
                  ))}
                </div>
              </div>

              {/* Meta Information */}
              <div className="flex items-center justify-between text-sm text-gray-500 mb-4">
                <div className="flex items-center">
                  <Clock className="w-4 h-4 mr-1" />
                  {cert.duration}
                </div>
                <div className="flex items-center">
                  <Users className="w-4 h-4 mr-1" />
                  {cert.enrolled.toLocaleString()} enrolled
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex gap-2">
                {cert.completed ? (
                  <Button className="flex-1 bg-green-600 hover:bg-green-700">
                    <Award className="w-4 h-4 mr-2" />
                    View Certificate
                  </Button>
                ) : cert.progress > 0 ? (
                  <Button className="flex-1 bg-sky-600 hover:bg-sky-700">
                    Continue Learning
                  </Button>
                ) : (
                  <Button className="flex-1 bg-sky-600 hover:bg-sky-700">
                    Start Certification
                  </Button>
                )}
                <Button variant="outline" size="icon">
                  <Star className="w-4 h-4" />
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* No results */}
      {filteredCertifications.length === 0 && (
        <div className="text-center py-12">
          <GraduationCap className="w-16 h-16 text-gray-400 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-600 mb-2">No certifications found</h3>
          <p className="text-gray-500">Try adjusting your search or filter criteria</p>
        </div>
      )}
    </div>
  );
}

export default function BrowseCertifications() {
  const config = platformConfigs.candidate;
  const theme = useThemeClasses('candidate');
  
  const usageData = [
    { label: "Certifications Progress", current: 3, max: 10 },
    { label: "Study Hours", current: 45, max: 100 },
    { label: "Completion Rate", current: 85, max: 100 },
  ];

  return (
    <PlatformLayout
      sidebarTitle={config.sidebarTitle}
      sidebarSubtitle={config.sidebarSubtitle}
      sidebarSections={config.sidebarSections}
      usageData={usageData}
    >
      <BrowseCertificationsContent />
    </PlatformLayout>
  );
}