import PlatformLayout from "@/components/layout/platform-layout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { MessageSquare, Plus, ThumbsUp, MessageCircle, Pin, Clock, TrendingUp, Search, Filter } from "lucide-react";
import { platformConfigs } from "@/config/complete-navigation";

export default function Forum() {
  const config = platformConfigs.candidate;

  const forumTopics = [
    {
      id: 1,
      title: "Best practices for React performance optimization",
      author: "Sarah Chen",
      authorAvatar: "/api/placeholder/40/40",
      category: "React",
      replies: 23,
      views: 456,
      lastActivity: "2 hours ago",
      lastReplyBy: "Mike Johnson",
      isPinned: true,
      isAnswered: true,
      tags: ["react", "performance", "optimization"]
    },
    {
      id: 2,
      title: "How to negotiate salary for remote positions?",
      author: "Alex Rodriguez",
      authorAvatar: "/api/placeholder/40/40",
      category: "Career",
      replies: 18,
      views: 892,
      lastActivity: "4 hours ago",
      lastReplyBy: "Emma Wilson",
      isPinned: false,
      isAnswered: true,
      tags: ["salary", "remote", "negotiation"]
    },
    {
      id: 3,
      title: "TypeScript vs JavaScript for new projects in 2024",
      author: "David Kim",
      authorAvatar: "/api/placeholder/40/40",
      category: "JavaScript",
      replies: 41,
      views: 1234,
      lastActivity: "6 hours ago",
      lastReplyBy: "Lisa Chen",
      isPinned: false,
      isAnswered: false,
      tags: ["typescript", "javascript", "2024"]
    },
    {
      id: 4,
      title: "Interview preparation checklist for senior developers",
      author: "Maria Garcia",
      authorAvatar: "/api/placeholder/40/40",
      category: "Interviews",
      replies: 15,
      views: 678,
      lastActivity: "8 hours ago",
      lastReplyBy: "John Smith",
      isPinned: true,
      isAnswered: true,
      tags: ["interviews", "senior", "preparation"]
    }
  ];

  const categories = [
    { name: "React", posts: 234, color: "bg-blue-100 text-blue-800" },
    { name: "Career", posts: 189, color: "bg-green-100 text-green-800" },
    { name: "JavaScript", posts: 156, color: "bg-yellow-100 text-yellow-800" },
    { name: "Interviews", posts: 98, color: "bg-purple-100 text-purple-800" },
    { name: "Remote Work", posts: 87, color: "bg-pink-100 text-pink-800" },
    { name: "Leadership", posts: 65, color: "bg-orange-100 text-orange-800" }
  ];

  const myActivity = [
    {
      type: "post",
      title: "How to handle state management in large React apps?",
      replies: 8,
      time: "2 days ago"
    },
    {
      type: "reply",
      title: "Best practices for code reviews",
      time: "3 days ago"
    },
    {
      type: "like",
      title: "Career transition from developer to manager",
      time: "5 days ago"
    }
  ];

  return (
    <PlatformLayout
      sidebarTitle={config.sidebarTitle}
      sidebarSubtitle={config.sidebarSubtitle}
      sidebarSections={config.sidebarSections}
      usageData={config.usageData}
    >
      <div className="space-y-6">
        {/* Forum Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card className="bg-gradient-to-br from-blue-50 to-blue-100 border-blue-200">
            <CardHeader className="pb-2">
              <CardTitle className="text-lg text-blue-700">Your Posts</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-blue-800">12</div>
              <p className="text-sm text-blue-600">3 this month</p>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-green-50 to-green-100 border-green-200">
            <CardHeader className="pb-2">
              <CardTitle className="text-lg text-green-700">Replies Received</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-green-800">89</div>
              <p className="text-sm text-green-600">+15 this week</p>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-purple-50 to-purple-100 border-purple-200">
            <CardHeader className="pb-2">
              <CardTitle className="text-lg text-purple-700">Reputation Score</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-purple-800">847</div>
              <p className="text-sm text-purple-600">Top 15% contributor</p>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-orange-50 to-orange-100 border-orange-200">
            <CardHeader className="pb-2">
              <CardTitle className="text-lg text-orange-700">Solutions Provided</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-orange-800">23</div>
              <p className="text-sm text-orange-600">8.2% acceptance rate</p>
            </CardContent>
          </Card>
        </div>

        {/* Search and Create */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <MessageSquare className="h-5 w-5 text-blue-600" />
              Forum Discussions
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex gap-4">
              <Input 
                placeholder="Search discussions, topics, or questions..." 
                className="flex-1"
              />
              <Button variant="outline" size="icon">
                <Filter className="h-4 w-4" />
              </Button>
              <Button className="bg-blue-600 hover:bg-blue-700">
                <Search className="h-4 w-4 mr-2" />
                Search
              </Button>
              <Button variant="outline">
                <Plus className="h-4 w-4 mr-2" />
                New Topic
              </Button>
            </div>
          </CardContent>
        </Card>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Main Content */}
          <div className="lg:col-span-2">
            <Tabs defaultValue="recent" className="w-full">
              <TabsList className="grid w-full grid-cols-4">
                <TabsTrigger value="recent">Recent</TabsTrigger>
                <TabsTrigger value="trending">Trending</TabsTrigger>
                <TabsTrigger value="unanswered">Unanswered</TabsTrigger>
                <TabsTrigger value="my-posts">My Posts</TabsTrigger>
              </TabsList>

              <TabsContent value="recent" className="space-y-4">
                <div className="space-y-4">
                  {forumTopics.map((topic) => (
                    <Card key={topic.id} className="hover:shadow-md transition-shadow">
                      <CardContent className="p-6">
                        <div className="space-y-3">
                          <div className="flex items-start justify-between">
                            <div className="flex-1">
                              <div className="flex items-center gap-2 mb-2">
                                {topic.isPinned && <Pin className="h-4 w-4 text-yellow-500" />}
                                <Badge variant="secondary" className="bg-blue-100 text-blue-800">
                                  {topic.category}
                                </Badge>
                                {topic.isAnswered && (
                                  <Badge variant="outline" className="border-green-300 text-green-600">
                                    Answered
                                  </Badge>
                                )}
                              </div>
                              <h3 className="text-lg font-semibold hover:text-blue-600 cursor-pointer mb-2">
                                {topic.title}
                              </h3>
                              <div className="flex items-center gap-2 mb-3">
                                <Avatar className="h-6 w-6">
                                  <AvatarImage src={topic.authorAvatar} />
                                  <AvatarFallback>{topic.author.split(' ').map(n => n[0]).join('')}</AvatarFallback>
                                </Avatar>
                                <span className="text-sm text-gray-600">by {topic.author}</span>
                              </div>
                              <div className="flex flex-wrap gap-1 mb-3">
                                {topic.tags.map((tag) => (
                                  <Badge key={tag} variant="outline" className="text-xs">
                                    #{tag}
                                  </Badge>
                                ))}
                              </div>
                            </div>
                          </div>
                          <div className="flex items-center justify-between">
                            <div className="flex items-center gap-4 text-sm text-gray-500">
                              <div className="flex items-center gap-1">
                                <MessageCircle className="h-4 w-4" />
                                {topic.replies} replies
                              </div>
                              <div className="flex items-center gap-1">
                                <TrendingUp className="h-4 w-4" />
                                {topic.views} views
                              </div>
                              <div className="flex items-center gap-1">
                                <Clock className="h-4 w-4" />
                                {topic.lastActivity}
                              </div>
                            </div>
                            <div className="text-sm text-gray-500">
                              Last reply by {topic.lastReplyBy}
                            </div>
                          </div>
                          <div className="flex gap-2 pt-2">
                            <Button variant="outline" size="sm">
                              <MessageCircle className="h-4 w-4 mr-1" />
                              Reply
                            </Button>
                            <Button variant="outline" size="sm">
                              <ThumbsUp className="h-4 w-4 mr-1" />
                              Like
                            </Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </TabsContent>

              <TabsContent value="trending" className="space-y-4">
                <Card>
                  <CardContent className="p-6">
                    <div className="text-center py-8">
                      <TrendingUp className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                      <h3 className="text-lg font-medium text-gray-600 mb-2">Trending Discussions</h3>
                      <p className="text-gray-500">Most popular topics in the community</p>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="unanswered" className="space-y-4">
                <Card>
                  <CardContent className="p-6">
                    <div className="text-center py-8">
                      <MessageSquare className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                      <h3 className="text-lg font-medium text-gray-600 mb-2">Unanswered Questions</h3>
                      <p className="text-gray-500">Help others by providing answers</p>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="my-posts" className="space-y-4">
                <div className="space-y-4">
                  {myActivity.map((activity, index) => (
                    <Card key={index} className="hover:shadow-md transition-shadow">
                      <CardContent className="p-4">
                        <div className="flex items-center justify-between">
                          <div>
                            <div className="flex items-center gap-2 mb-1">
                              <Badge variant={activity.type === 'post' ? 'default' : 'secondary'}>
                                {activity.type}
                              </Badge>
                            </div>
                            <h4 className="font-medium">{activity.title}</h4>
                            {activity.replies && (
                              <p className="text-sm text-gray-500">{activity.replies} replies</p>
                            )}
                          </div>
                          <span className="text-sm text-gray-500">{activity.time}</span>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </TabsContent>
            </Tabs>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Categories */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Categories</CardTitle>
                <CardDescription>Browse by topic</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {categories.map((category) => (
                    <div key={category.name} className="flex justify-between items-center p-2 hover:bg-gray-50 rounded cursor-pointer">
                      <span className="font-medium">{category.name}</span>
                      <Badge className={category.color}>
                        {category.posts}
                      </Badge>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Quick Actions */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Community Guidelines</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2 text-sm text-gray-600">
                  <p>• Be respectful and professional</p>
                  <p>• Search before posting duplicates</p>
                  <p>• Provide clear, detailed questions</p>
                  <p>• Mark helpful answers as solutions</p>
                  <p>• Share knowledge and help others</p>
                </div>
              </CardContent>
            </Card>

            {/* Active Contributors */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Top Contributors</CardTitle>
                <CardDescription>This week's most helpful members</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {[
                    { name: "Sarah Chen", points: 234, avatar: "/api/placeholder/30/30" },
                    { name: "Mike Johnson", points: 189, avatar: "/api/placeholder/30/30" },
                    { name: "Emma Wilson", points: 156, avatar: "/api/placeholder/30/30" }
                  ].map((contributor, index) => (
                    <div key={contributor.name} className="flex items-center gap-3">
                      <div className="text-sm font-bold text-gray-500">#{index + 1}</div>
                      <Avatar className="h-8 w-8">
                        <AvatarImage src={contributor.avatar} />
                        <AvatarFallback>{contributor.name.split(' ').map(n => n[0]).join('')}</AvatarFallback>
                      </Avatar>
                      <div className="flex-1">
                        <div className="font-medium text-sm">{contributor.name}</div>
                        <div className="text-xs text-gray-500">{contributor.points} points</div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </PlatformLayout>
  );
}