import { useEffect } from "react";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import PlatformLayout from "@/components/layout/platform-layout";
import { platformConfigs } from "@/config/complete-navigation";
import { Brain, BarChart3, Users, FileText, Settings, Award, TrendingUp, Clock, Target } from "lucide-react";

function HomeContent() {
  const { toast } = useToast();
  const { user, isLoading } = useAuth();

  // Temporarily removed authentication checks for testing
  const testUser = user || { role: "candidate", firstName: "Test", lastName: "User" };

  const getRoleBasedQuickActions = () => {
    switch (testUser.role) {
      case "candidate":
        return [
          { title: "Take Test", description: "Start a new assessment", icon: <FileText className="w-6 h-6" />, href: "/tests", color: "bg-sky-primary" },
          { title: "View Analytics", description: "See your performance", icon: <BarChart3 className="w-6 h-6" />, href: "/analytics", color: "bg-purple-600" },
          { title: "Certifications", description: "View your certificates", icon: <Award className="w-6 h-6" />, href: "/certifications", color: "bg-green-600" },
          { title: "Subscription", description: "Manage your plan", icon: <Settings className="w-6 h-6" />, href: "/subscription", color: "bg-yellow-600" }
        ];
      case "recruiter":
      case "recruiter_admin":
        return [
          { title: "Create Test", description: "Design new assessment", icon: <FileText className="w-6 h-6" />, href: "/tests", color: "bg-sky-primary" },
          { title: "Candidate Rankings", description: "View top performers", icon: <Users className="w-6 h-6" />, href: "/analytics", color: "bg-purple-600" },
          { title: "Test Analytics", description: "Performance insights", icon: <BarChart3 className="w-6 h-6" />, href: "/analytics", color: "bg-green-600" },
          { title: "Manage Team", description: "Add team members", icon: <Users className="w-6 h-6" />, href: "/team", color: "bg-yellow-600" }
        ];
      default:
        return [
          { title: "Dashboard", description: "Overview of activities", icon: <BarChart3 className="w-6 h-6" />, href: "/dashboard", color: "bg-sky-primary" },
          { title: "Analytics", description: "Detailed insights", icon: <TrendingUp className="w-6 h-6" />, href: "/analytics", color: "bg-purple-600" },
          { title: "Management", description: "System administration", icon: <Settings className="w-6 h-6" />, href: "/admin", color: "bg-green-600" }
        ];
    }
  };

  const getRoleDisplayName = (role: string) => {
    const roleMap: Record<string, string> = {
      "candidate": "Candidate",
      "recruiter": "Recruiter",
      "recruiter_admin": "Recruiter Admin",
      "recruiter_employee": "Recruiter Employee",
      "college_admin": "College Admin",
      "college_sub_admin": "College Sub-Admin",
      "super_admin": "Super Admin"
    };
    return roleMap[role] || role;
  };

  const quickActions = getRoleBasedQuickActions();

  return (
    <div className="min-h-screen bg-gray-50">
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Welcome Section */}
        <div className="mb-8">
          <div className="sky-gradient-light rounded-2xl p-8">
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-3xl font-bold text-gray-900 mb-2">
                  Welcome back, {testUser.firstName || "Candidate"}!
                </h1>
                <p className="text-lg text-gray-600">
                  Role: <span className="font-semibold text-sky-primary">{getRoleDisplayName(testUser.role)}</span>
                </p>
                <p className="text-gray-600 mt-2">
                  Ready to continue your journey with TestEngine? Let's make today productive.
                </p>
              </div>
              <div className="hidden md:block">
                <Brain className="w-24 h-24 text-sky-primary opacity-20" />
              </div>
            </div>
          </div>
        </div>

        {/* Quick Actions */}
        <div className="mb-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-6">Quick Actions</h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {quickActions.map((action, index) => (
              <Link key={index} href={action.href}>
                <Card className="cursor-pointer hover:shadow-lg transition-shadow duration-200 border-gray-200 hover:border-sky-300">
                  <CardContent className="p-6">
                    <div className="flex items-center space-x-4">
                      <div className={`${action.color} text-white w-12 h-12 rounded-xl flex items-center justify-center`}>
                        {action.icon}
                      </div>
                      <div>
                        <h3 className="font-semibold text-gray-900">{action.title}</h3>
                        <p className="text-sm text-gray-600">{action.description}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>
        </div>

        {/* Recent Activity & Stats */}
        <div className="grid lg:grid-cols-3 gap-8">
          {/* Recent Activity */}
          <div className="lg:col-span-2">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Clock className="w-5 h-5 mr-2 text-sky-primary" />
                  Recent Activity
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center space-x-4 p-4 bg-gray-50 rounded-lg">
                    <div className="bg-sky-primary text-white w-10 h-10 rounded-full flex items-center justify-center">
                      <FileText className="w-5 h-5" />
                    </div>
                    <div className="flex-1">
                      <p className="font-medium text-gray-900">
                        {testUser.role === "candidate" ? "Completed JavaScript Assessment" : "Created new test: JavaScript Fundamentals"}
                      </p>
                      <p className="text-sm text-gray-600">2 hours ago</p>
                    </div>
                  </div>
                  
                  <div className="flex items-center space-x-4 p-4 bg-gray-50 rounded-lg">
                    <div className="bg-green-500 text-white w-10 h-10 rounded-full flex items-center justify-center">
                      <Award className="w-5 h-5" />
                    </div>
                    <div className="flex-1">
                      <p className="font-medium text-gray-900">
                        {testUser.role === "candidate" ? "Earned React Developer Certificate" : "25 candidates completed your test"}
                      </p>
                      <p className="text-sm text-gray-600">1 day ago</p>
                    </div>
                  </div>
                  
                  <div className="flex items-center space-x-4 p-4 bg-gray-50 rounded-lg">
                    <div className="bg-purple-600 text-white w-10 h-10 rounded-full flex items-center justify-center">
                      <BarChart3 className="w-5 h-5" />
                    </div>
                    <div className="flex-1">
                      <p className="font-medium text-gray-900">
                        {testUser.role === "candidate" ? "Performance analytics updated" : "Monthly analytics report generated"}
                      </p>
                      <p className="text-sm text-gray-600">3 days ago</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Quick Stats */}
          <div className="space-y-6">
            <Card className="analytics-card-gradient">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">
                      {testUser.role === "candidate" ? "Tests Completed" : "Active Tests"}
                    </p>
                    <p className="text-3xl font-bold text-sky-primary">12</p>
                  </div>
                  <Target className="w-8 h-8 text-sky-primary" />
                </div>
                <p className="text-sm text-gray-600 mt-2">
                  <span className="text-green-600 font-medium">+2</span> this week
                </p>
              </CardContent>
            </Card>

            <Card className="success-gradient">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">
                      {testUser.role === "candidate" ? "Average Score" : "Completion Rate"}
                    </p>
                    <p className="text-3xl font-bold text-green-600">87%</p>
                  </div>
                  <TrendingUp className="w-8 h-8 text-green-600" />
                </div>
                <p className="text-sm text-gray-600 mt-2">
                  <span className="text-green-600 font-medium">+5%</span> improvement
                </p>
              </CardContent>
            </Card>

            <Card className="purple-gradient">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">
                      {testUser.role === "candidate" ? "Certificates" : "Candidates"}
                    </p>
                    <p className="text-3xl font-bold text-purple-600">
                      {testUser.role === "candidate" ? "5" : "247"}
                    </p>
                  </div>
                  <Award className="w-8 h-8 text-purple-600" />
                </div>
                <p className="text-sm text-gray-600 mt-2">
                  <span className="text-purple-600 font-medium">+1</span> this month
                </p>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Getting Started for New Users */}
        {testUser.role === "candidate" && (
          <div className="mt-8">
            <Card className="border-sky-200 bg-sky-50">
              <CardContent className="p-6">
                <div className="flex items-start space-x-4">
                  <div className="bg-sky-primary text-white w-12 h-12 rounded-xl flex items-center justify-center">
                    <Brain className="w-6 h-6" />
                  </div>
                  <div className="flex-1">
                    <h3 className="text-lg font-semibold text-gray-900 mb-2">New to TestEngine?</h3>
                    <p className="text-gray-600 mb-4">
                      Start with our free practice tests to get familiar with the platform and identify your strengths.
                    </p>
                    <div className="flex space-x-4">
                      <Link href="/tests">
                        <Button className="bg-sky-primary hover:bg-sky-600">
                          Take Practice Test
                        </Button>
                      </Link>
                      <Link href="/subscription">
                        <Button variant="outline">
                          View Plans
                        </Button>
                      </Link>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        )}
      </main>
    </div>
  );
}

export default function Home() {
  const config = platformConfigs.candidate;
  
  const usageData = [
    { label: "Profile Completion", current: 85, max: 100 },
    { label: "Active Applications", current: 8, max: 25 },
    { label: "Skill Tests Taken", current: 12, max: 20 },
  ];

  return (
    <PlatformLayout
      sidebarTitle={config.sidebarTitle}
      sidebarSubtitle={config.sidebarSubtitle}
      sidebarSections={config.sidebarSections}
      usageData={usageData}
    >
      <HomeContent />
    </PlatformLayout>
  );
}
