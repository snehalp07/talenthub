import PlatformLayout from "@/components/layout/platform-layout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Users, UserPlus, MessageCircle, Crown, Lock, Globe, Search, Filter, Plus } from "lucide-react";
import { platformConfigs } from "@/config/complete-navigation";

export default function Groups() {
  const config = platformConfigs.candidate;

  const myGroups = [
    {
      id: 1,
      name: "React Developers Community",
      description: "A place for React developers to share knowledge, best practices, and get help",
      members: 15847,
      posts: 342,
      type: "public",
      category: "Technology",
      avatar: "/api/placeholder/60/60",
      role: "member",
      lastActivity: "2 hours ago",
      isActive: true
    },
    {
      id: 2,
      name: "Remote Work Professionals",
      description: "Connecting remote workers worldwide for networking and career growth",
      members: 8923,
      posts: 156,
      type: "public",
      category: "Career",
      avatar: "/api/placeholder/60/60",
      role: "admin",
      lastActivity: "4 hours ago",
      isActive: true
    },
    {
      id: 3,
      name: "Tech Leadership Circle",
      description: "Exclusive group for engineering managers and tech leads",
      members: 542,
      posts: 89,
      type: "private",
      category: "Leadership",
      avatar: "/api/placeholder/60/60",
      role: "moderator",
      lastActivity: "1 day ago",
      isActive: true
    }
  ];

  const suggestedGroups = [
    {
      id: 4,
      name: "JavaScript Developers Hub",
      description: "Everything JavaScript - from basics to advanced frameworks",
      members: 23156,
      posts: 567,
      type: "public",
      category: "Technology",
      avatar: "/api/placeholder/60/60",
      commonMembers: 12
    },
    {
      id: 5,
      name: "Women in Tech",
      description: "Supporting and empowering women in technology careers",
      members: 11234,
      posts: 234,
      type: "public",
      category: "Community",
      avatar: "/api/placeholder/60/60",
      commonMembers: 8
    },
    {
      id: 6,
      name: "Startup Founders Network",
      description: "Connect with fellow entrepreneurs and startup founders",
      members: 3456,
      posts: 178,
      type: "private",
      category: "Entrepreneurship",
      avatar: "/api/placeholder/60/60",
      commonMembers: 5
    }
  ];

  const categories = [
    { name: "Technology", count: 45, color: "bg-blue-100 text-blue-800" },
    { name: "Career", count: 32, color: "bg-green-100 text-green-800" },
    { name: "Leadership", count: 18, color: "bg-purple-100 text-purple-800" },
    { name: "Industry", count: 25, color: "bg-orange-100 text-orange-800" },
    { name: "Community", count: 22, color: "bg-pink-100 text-pink-800" }
  ];

  return (
    <PlatformLayout
      sidebarTitle={config.sidebarTitle}
      sidebarSubtitle={config.sidebarSubtitle}
      sidebarSections={config.sidebarSections}
      usageData={config.usageData}
    >
      <div className="space-y-6">
        {/* Groups Overview */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card className="bg-gradient-to-br from-blue-50 to-blue-100 border-blue-200">
            <CardHeader className="pb-2">
              <CardTitle className="text-lg text-blue-700">Groups Joined</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-blue-800">12</div>
              <p className="text-sm text-blue-600">3 active today</p>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-green-50 to-green-100 border-green-200">
            <CardHeader className="pb-2">
              <CardTitle className="text-lg text-green-700">Posts This Week</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-green-800">8</div>
              <p className="text-sm text-green-600">+3 vs last week</p>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-purple-50 to-purple-100 border-purple-200">
            <CardHeader className="pb-2">
              <CardTitle className="text-lg text-purple-700">Admin/Moderator</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-purple-800">2</div>
              <p className="text-sm text-purple-600">leadership roles</p>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-br from-orange-50 to-orange-100 border-orange-200">
            <CardHeader className="pb-2">
              <CardTitle className="text-lg text-orange-700">Network Reach</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-orange-800">47K</div>
              <p className="text-sm text-orange-600">total members</p>
            </CardContent>
          </Card>
        </div>

        {/* Search and Create */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Search className="h-5 w-5 text-blue-600" />
              Discover Groups
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex gap-4">
              <Input 
                placeholder="Search groups by name, topic, or keyword..." 
                className="flex-1"
              />
              <Button variant="outline" size="icon">
                <Filter className="h-4 w-4" />
              </Button>
              <Button className="bg-blue-600 hover:bg-blue-700">
                Search
              </Button>
              <Button variant="outline">
                <Plus className="h-4 w-4 mr-2" />
                Create Group
              </Button>
            </div>
          </CardContent>
        </Card>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Main Content */}
          <div className="lg:col-span-2">
            <Tabs defaultValue="my-groups" className="w-full">
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="my-groups">My Groups</TabsTrigger>
                <TabsTrigger value="discover">Discover</TabsTrigger>
                <TabsTrigger value="activity">Activity</TabsTrigger>
              </TabsList>

              <TabsContent value="my-groups" className="space-y-4">
                <div className="space-y-4">
                  {myGroups.map((group) => (
                    <Card key={group.id} className="hover:shadow-md transition-shadow">
                      <CardContent className="p-6">
                        <div className="flex items-start gap-4">
                          <Avatar className="h-16 w-16">
                            <AvatarImage src={group.avatar} />
                            <AvatarFallback>{group.name.split(' ').map(n => n[0]).join('')}</AvatarFallback>
                          </Avatar>
                          <div className="flex-1 space-y-2">
                            <div className="flex items-start justify-between">
                              <div>
                                <h3 className="font-semibold text-lg flex items-center gap-2">
                                  {group.name}
                                  {group.type === 'private' ? (
                                    <Lock className="h-4 w-4 text-gray-500" />
                                  ) : (
                                    <Globe className="h-4 w-4 text-green-500" />
                                  )}
                                  {group.role === 'admin' && <Crown className="h-4 w-4 text-yellow-500" />}
                                </h3>
                                <p className="text-gray-600 text-sm">{group.description}</p>
                              </div>
                              <Badge variant="secondary" className="bg-blue-100 text-blue-800">
                                {group.category}
                              </Badge>
                            </div>
                            <div className="flex items-center gap-4 text-sm text-gray-500">
                              <div className="flex items-center gap-1">
                                <Users className="h-4 w-4" />
                                {group.members.toLocaleString()} members
                              </div>
                              <div className="flex items-center gap-1">
                                <MessageCircle className="h-4 w-4" />
                                {group.posts} posts
                              </div>
                              <div>Last activity: {group.lastActivity}</div>
                            </div>
                            <div className="flex items-center gap-2">
                              <Badge variant={group.role === 'admin' ? 'default' : 'secondary'}>
                                {group.role}
                              </Badge>
                              {group.isActive && (
                                <Badge variant="outline" className="border-green-300 text-green-600">
                                  Active
                                </Badge>
                              )}
                            </div>
                            <div className="flex gap-2 pt-2">
                              <Button variant="outline" size="sm">
                                <MessageCircle className="h-4 w-4 mr-1" />
                                View Posts
                              </Button>
                              <Button variant="outline" size="sm">
                                Members
                              </Button>
                              {group.role === 'admin' && (
                                <Button variant="outline" size="sm">
                                  Manage
                                </Button>
                              )}
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </TabsContent>

              <TabsContent value="discover" className="space-y-4">
                <div className="space-y-4">
                  {suggestedGroups.map((group) => (
                    <Card key={group.id} className="hover:shadow-md transition-shadow">
                      <CardContent className="p-6">
                        <div className="flex items-start gap-4">
                          <Avatar className="h-16 w-16">
                            <AvatarImage src={group.avatar} />
                            <AvatarFallback>{group.name.split(' ').map(n => n[0]).join('')}</AvatarFallback>
                          </Avatar>
                          <div className="flex-1 space-y-2">
                            <div className="flex items-start justify-between">
                              <div>
                                <h3 className="font-semibold text-lg flex items-center gap-2">
                                  {group.name}
                                  {group.type === 'private' ? (
                                    <Lock className="h-4 w-4 text-gray-500" />
                                  ) : (
                                    <Globe className="h-4 w-4 text-green-500" />
                                  )}
                                </h3>
                                <p className="text-gray-600 text-sm">{group.description}</p>
                              </div>
                              <Badge variant="secondary" className="bg-blue-100 text-blue-800">
                                {group.category}
                              </Badge>
                            </div>
                            <div className="flex items-center gap-4 text-sm text-gray-500">
                              <div className="flex items-center gap-1">
                                <Users className="h-4 w-4" />
                                {group.members.toLocaleString()} members
                              </div>
                              <div className="flex items-center gap-1">
                                <MessageCircle className="h-4 w-4" />
                                {group.posts} posts
                              </div>
                            </div>
                            <p className="text-sm text-blue-600">
                              {group.commonMembers} mutual connections
                            </p>
                            <div className="flex gap-2 pt-2">
                              <Button className="bg-blue-600 hover:bg-blue-700" size="sm">
                                <UserPlus className="h-4 w-4 mr-1" />
                                {group.type === 'private' ? 'Request to Join' : 'Join Group'}
                              </Button>
                              <Button variant="outline" size="sm">
                                Preview
                              </Button>
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </TabsContent>

              <TabsContent value="activity" className="space-y-4">
                <Card>
                  <CardContent className="p-6">
                    <div className="text-center py-8">
                      <MessageCircle className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                      <h3 className="text-lg font-medium text-gray-600 mb-2">Recent Group Activity</h3>
                      <p className="text-gray-500">Your latest interactions and updates from groups</p>
                      <Button className="mt-4 bg-blue-600 hover:bg-blue-700">
                        View All Activity
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Categories */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Browse Categories</CardTitle>
                <CardDescription>Find groups by topic</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {categories.map((category) => (
                    <div key={category.name} className="flex justify-between items-center p-2 hover:bg-gray-50 rounded cursor-pointer">
                      <span className="font-medium">{category.name}</span>
                      <Badge className={category.color}>
                        {category.count}
                      </Badge>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Quick Actions */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Quick Actions</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <Button variant="outline" className="w-full justify-start">
                    <Plus className="h-4 w-4 mr-2" />
                    Create New Group
                  </Button>
                  <Button variant="outline" className="w-full justify-start">
                    <Search className="h-4 w-4 mr-2" />
                    Browse All Groups
                  </Button>
                  <Button variant="outline" className="w-full justify-start">
                    <Users className="h-4 w-4 mr-2" />
                    Invite Friends
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </PlatformLayout>
  );
}