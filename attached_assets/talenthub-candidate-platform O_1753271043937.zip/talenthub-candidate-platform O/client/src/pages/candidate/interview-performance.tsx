import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import PlatformLayout from "@/components/layout/platform-layout";
import { candidateNavigation } from "@/config/complete-navigation";
import { 
  BarChart3, TrendingUp, Target, Clock, Award, CheckCircle,
  Star, Users, Zap, Brain, MessageSquare, Code, Calendar,
  ArrowUp, ArrowDown, Activity, Trophy, Eye, Play
} from "lucide-react";

const InterviewPerformance: React.FC = () => {
  const [timeRange, setTimeRange] = useState('30d');

  const performanceOverview = {
    totalInterviews: 24,
    averageScore: 78,
    improvementRate: 15,
    passRate: 82,
    certifications: 3,
    streak: 7
  };

  const monthlyProgress = [
    { month: 'Jan', interviews: 4, avgScore: 65, passRate: 60 },
    { month: 'Feb', interviews: 6, avgScore: 72, passRate: 70 },
    { month: 'Mar', interviews: 8, avgScore: 78, passRate: 80 },
    { month: 'Apr', interviews: 6, avgScore: 82, passRate: 85 }
  ];

  const techStackPerformance = [
    { 
      stack: 'React', 
      interviews: 8, 
      avgScore: 85, 
      trend: '+12%', 
      level: 'Advanced',
      lastInterview: '2 days ago',
      strengths: ['Component Design', 'Hooks', 'State Management'],
      weaknesses: ['Performance Optimization', 'Testing']
    },
    { 
      stack: 'Node.js', 
      interviews: 6, 
      avgScore: 79, 
      trend: '+8%', 
      level: 'Intermediate',
      lastInterview: '5 days ago',
      strengths: ['Express.js', 'API Design', 'Middleware'],
      weaknesses: ['Security', 'Scaling']
    },
    { 
      stack: 'Python', 
      interviews: 5, 
      avgScore: 73, 
      trend: '+15%', 
      level: 'Intermediate',
      lastInterview: '1 week ago',
      strengths: ['Data Structures', 'Libraries'],
      weaknesses: ['OOP Design', 'Performance']
    },
    { 
      stack: 'System Design', 
      interviews: 3, 
      avgScore: 68, 
      trend: '+20%', 
      level: 'Foundation',
      lastInterview: '3 days ago',
      strengths: ['Database Design'],
      weaknesses: ['Scalability', 'Load Balancing', 'Caching']
    }
  ];

  const interviewCategories = [
    { category: 'Technical Skills', score: 82, maxScore: 100, color: 'bg-blue-500' },
    { category: 'Problem Solving', score: 75, maxScore: 100, color: 'bg-green-500' },
    { category: 'Communication', score: 88, maxScore: 100, color: 'bg-purple-500' },
    { category: 'Code Quality', score: 79, maxScore: 100, color: 'bg-orange-500' },
    { category: 'System Design', score: 65, maxScore: 100, color: 'bg-red-500' },
    { category: 'Behavioral', score: 91, maxScore: 100, color: 'bg-teal-500' }
  ];

  const recentInterviews = [
    {
      company: 'TechCorp',
      role: 'Senior React Developer',
      date: '2 days ago',
      duration: '45 mins',
      score: 87,
      status: 'Passed',
      feedback: 'Strong technical skills, good problem-solving approach',
      techStack: ['React', 'TypeScript', 'Redux'],
      areas: ['Component optimization', 'Testing strategies']
    },
    {
      company: 'StartupX',
      role: 'Full-Stack Engineer',
      date: '5 days ago',
      duration: '60 mins',
      score: 73,
      status: 'Conditional',
      feedback: 'Good frontend skills, backend needs improvement',
      techStack: ['React', 'Node.js', 'MongoDB'],
      areas: ['API security', 'Database design']
    },
    {
      company: 'DataCorp',
      role: 'Python Developer',
      date: '1 week ago',
      duration: '50 mins',
      score: 81,
      status: 'Passed',
      feedback: 'Excellent algorithmic thinking, clean code structure',
      techStack: ['Python', 'Django', 'PostgreSQL'],
      areas: ['Advanced OOP concepts']
    }
  ];

  const achievementBadges = [
    { name: 'Interview Streak', count: 7, icon: Zap, color: 'bg-yellow-500' },
    { name: 'Tech Mastery', count: 3, icon: Code, color: 'bg-blue-500' },
    { name: 'Problem Solver', count: 15, icon: Brain, color: 'bg-purple-500' },
    { name: 'Communicator', count: 12, icon: MessageSquare, color: 'bg-green-500' }
  ];

  return (
    <PlatformLayout
      sidebarTitle="Candidate Platform"
      sidebarSubtitle="Interview Preparation"
      sidebarSections={candidateNavigation}
    >
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-indigo-50 p-6">
        <div className="max-w-7xl mx-auto space-y-8">
          {/* Header */}
          <div className="text-center space-y-4">
            <div className="inline-flex items-center space-x-2 bg-blue-100 text-blue-800 px-4 py-2 rounded-full text-sm font-medium">
              <BarChart3 className="h-4 w-4" />
              <span>Interview Performance Analytics</span>
            </div>
            <h1 className="text-4xl font-bold text-gray-900">
              Performance Dashboard
            </h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Track your interview performance, identify strengths and weaknesses, 
              and monitor your improvement across different tech stacks and companies.
            </p>
          </div>

          {/* Performance Overview */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-6 gap-6">
            <Card className="bg-gradient-to-r from-blue-500 to-cyan-500 text-white">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-blue-100 text-sm">Total Interviews</p>
                    <p className="text-3xl font-bold">{performanceOverview.totalInterviews}</p>
                  </div>
                  <MessageSquare className="h-8 w-8 text-blue-200" />
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-r from-green-500 to-emerald-500 text-white">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-green-100 text-sm">Average Score</p>
                    <p className="text-3xl font-bold">{performanceOverview.averageScore}%</p>
                  </div>
                  <Target className="h-8 w-8 text-green-200" />
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-r from-purple-500 to-pink-500 text-white">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-purple-100 text-sm">Improvement</p>
                    <p className="text-3xl font-bold">+{performanceOverview.improvementRate}%</p>
                  </div>
                  <TrendingUp className="h-8 w-8 text-purple-200" />
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-r from-orange-500 to-red-500 text-white">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-orange-100 text-sm">Pass Rate</p>
                    <p className="text-3xl font-bold">{performanceOverview.passRate}%</p>
                  </div>
                  <CheckCircle className="h-8 w-8 text-orange-200" />
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-r from-yellow-500 to-orange-500 text-white">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-yellow-100 text-sm">Certifications</p>
                    <p className="text-3xl font-bold">{performanceOverview.certifications}</p>
                  </div>
                  <Award className="h-8 w-8 text-yellow-200" />
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-r from-teal-500 to-blue-500 text-white">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-teal-100 text-sm">Current Streak</p>
                    <p className="text-3xl font-bold">{performanceOverview.streak}</p>
                  </div>
                  <Zap className="h-8 w-8 text-teal-200" />
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Main Performance Charts */}
            <div className="lg:col-span-2 space-y-6">
              {/* Tech Stack Performance */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Code className="h-5 w-5" />
                    <span>Tech Stack Performance</span>
                  </CardTitle>
                  <CardDescription>Your performance across different technologies</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-6">
                    {techStackPerformance.map((tech, index) => (
                      <div key={index} className="p-4 bg-gray-50 rounded-lg">
                        <div className="flex items-center justify-between mb-3">
                          <div className="flex items-center space-x-3">
                            <h3 className="font-semibold text-lg">{tech.stack}</h3>
                            <Badge variant="outline">{tech.level}</Badge>
                          </div>
                          <div className="flex items-center space-x-4">
                            <span className="text-sm text-gray-500">{tech.interviews} interviews</span>
                            <div className="text-right">
                              <div className="text-lg font-semibold">{tech.avgScore}%</div>
                              <div className="text-sm text-green-600">{tech.trend}</div>
                            </div>
                          </div>
                        </div>
                        
                        <Progress value={tech.avgScore} className="h-2 mb-3" />
                        
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                          <div>
                            <span className="font-medium text-green-700">Strengths:</span>
                            <div className="flex flex-wrap gap-1 mt-1">
                              {tech.strengths.map((strength, i) => (
                                <Badge key={i} variant="secondary" className="text-xs bg-green-100 text-green-800">
                                  {strength}
                                </Badge>
                              ))}
                            </div>
                          </div>
                          <div>
                            <span className="font-medium text-red-700">Areas to Improve:</span>
                            <div className="flex flex-wrap gap-1 mt-1">
                              {tech.weaknesses.map((weakness, i) => (
                                <Badge key={i} variant="secondary" className="text-xs bg-red-100 text-red-800">
                                  {weakness}
                                </Badge>
                              ))}
                            </div>
                          </div>
                        </div>
                        
                        <div className="flex items-center justify-between mt-3 pt-3 border-t">
                          <span className="text-xs text-gray-500">Last interview: {tech.lastInterview}</span>
                          <Button variant="outline" size="sm">
                            <Play className="h-3 w-3 mr-2" />
                            Practice More
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* Recent Interview History */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Calendar className="h-5 w-5" />
                    <span>Recent Interviews</span>
                  </CardTitle>
                  <CardDescription>Detailed breakdown of your latest interview sessions</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {recentInterviews.map((interview, index) => (
                      <div key={index} className="p-4 border rounded-lg">
                        <div className="flex items-center justify-between mb-3">
                          <div>
                            <h3 className="font-semibold">{interview.company}</h3>
                            <p className="text-sm text-gray-600">{interview.role}</p>
                          </div>
                          <div className="text-right">
                            <div className="text-lg font-semibold">{interview.score}%</div>
                            <Badge variant={
                              interview.status === 'Passed' ? 'default' :
                              interview.status === 'Conditional' ? 'secondary' : 'destructive'
                            }>
                              {interview.status}
                            </Badge>
                          </div>
                        </div>
                        
                        <div className="grid grid-cols-2 gap-4 text-sm mb-3">
                          <div>
                            <span className="text-gray-500">Date:</span> {interview.date}
                          </div>
                          <div>
                            <span className="text-gray-500">Duration:</span> {interview.duration}
                          </div>
                        </div>
                        
                        <div className="mb-3">
                          <div className="flex flex-wrap gap-1">
                            {interview.techStack.map((tech, i) => (
                              <Badge key={i} variant="outline" className="text-xs">
                                {tech}
                              </Badge>
                            ))}
                          </div>
                        </div>
                        
                        <p className="text-sm text-gray-700 mb-2">{interview.feedback}</p>
                        
                        <div className="text-sm">
                          <span className="font-medium">Focus Areas:</span>
                          <div className="flex flex-wrap gap-1 mt-1">
                            {interview.areas.map((area, i) => (
                              <Badge key={i} variant="secondary" className="text-xs bg-blue-100 text-blue-800">
                                {area}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Sidebar */}
            <div className="space-y-6">
              {/* Skill Categories */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Activity className="h-5 w-5" />
                    <span>Skill Categories</span>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {interviewCategories.map((category, index) => (
                    <div key={index} className="space-y-2">
                      <div className="flex justify-between items-center">
                        <span className="text-sm font-medium">{category.category}</span>
                        <span className="text-sm">{category.score}%</span>
                      </div>
                      <div className="relative">
                        <Progress value={category.score} className="h-2" />
                        <div className={`absolute top-0 left-0 h-2 rounded-full ${category.color}`} 
                             style={{ width: `${category.score}%` }} />
                      </div>
                    </div>
                  ))}
                </CardContent>
              </Card>

              {/* Achievement Badges */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Trophy className="h-5 w-5" />
                    <span>Achievements</span>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  {achievementBadges.map((badge, index) => (
                    <div key={index} className="flex items-center space-x-3">
                      <div className={`p-2 rounded-lg ${badge.color}`}>
                        <badge.icon className="h-4 w-4 text-white" />
                      </div>
                      <div className="flex-1">
                        <div className="font-medium text-sm">{badge.name}</div>
                        <div className="text-xs text-gray-500">{badge.count} earned</div>
                      </div>
                    </div>
                  ))}
                </CardContent>
              </Card>

              {/* Monthly Progress */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <TrendingUp className="h-5 w-5" />
                    <span>Monthly Trends</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {monthlyProgress.map((month, index) => (
                      <div key={index} className="flex items-center justify-between p-2 bg-gray-50 rounded">
                        <span className="text-sm font-medium">{month.month}</span>
                        <div className="text-right text-sm">
                          <div>{month.avgScore}% avg</div>
                          <div className="text-xs text-gray-500">{month.interviews} interviews</div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* Action Buttons */}
              <div className="space-y-3">
                <Button size="lg" className="w-full bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700">
                  <Play className="h-4 w-4 mr-2" />
                  Start New Interview
                </Button>
                <Button variant="outline" size="lg" className="w-full">
                  <Eye className="h-4 w-4 mr-2" />
                  View Detailed Report
                </Button>
                <Button variant="outline" size="lg" className="w-full">
                  <Target className="h-4 w-4 mr-2" />
                  Set Goals
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </PlatformLayout>
  );
};

export default InterviewPerformance;