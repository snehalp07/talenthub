import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Progress } from "@/components/ui/progress";
import { Separator } from "@/components/ui/separator";
import PlatformLayout from "@/components/layout/platform-layout";
import { candidateNavigation } from "@/config/complete-navigation";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { 
  Search, 
  Filter, 
  Calendar, 
  Building, 
  MapPin, 
  Clock, 
  CheckCircle, 
  XCircle, 
  AlertCircle,
  Eye,
  MessageSquare,
  Phone,
  Mail,
  FileText,
  Edit3,
  Save,
  Plus,
  Bell,
  TrendingUp,
  BarChart3,
  Target,
  Zap,
  Copy,
  Trash2,
  Star,
  Users,
  Briefcase
} from "lucide-react";

function ApplicationTrackerContent() {
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [activeTab, setActiveTab] = useState("applications");
  const [selectedTemplate, setSelectedTemplate] = useState("");
  const [draftDialogOpen, setDraftDialogOpen] = useState(false);
  const [reminderDialogOpen, setReminderDialogOpen] = useState(false);
  const [templateDialogOpen, setTemplateDialogOpen] = useState(false);
  const [newTemplateName, setNewTemplateName] = useState("");
  const [newTemplateCategory, setNewTemplateCategory] = useState("");
  const [newTemplateContent, setNewTemplateContent] = useState("");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // DEV MODE: Bypass authentication for development
  const isDev = import.meta.env.DEV || process.env.NODE_ENV === 'development';

  const { data: applications = [], isLoading } = useQuery({
    queryKey: ["/api/candidate/job-applications"],
  });

  // Phase 2: New API queries with auth bypass
  const { data: draftApplications = [] } = useQuery({
    queryKey: ["/api/candidate/draft-applications"],
    enabled: isDev || true
  });

  const { data: templates = [] } = useQuery({
    queryKey: ["/api/candidate/application-templates"],
    enabled: isDev || true
  });

  const { data: reminders = [] } = useQuery({
    queryKey: ["/api/candidate/follow-up-reminders"],
    enabled: isDev || true
  });

  const { data: analytics } = useQuery({
    queryKey: ["/api/candidate/success-analytics"],
    enabled: isDev || true
  });

  // Phase 2: Mutations for creating new items
  const createDraftMutation = useMutation({
    mutationFn: (data: any) => apiRequest("POST", "/api/candidate/draft-applications", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/candidate/draft-applications"] });
      toast({ title: "Success", description: "Draft application saved successfully" });
      setDraftDialogOpen(false);
    }
  });

  const createTemplateMutation = useMutation({
    mutationFn: (data: any) => apiRequest("POST", "/api/candidate/application-templates", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/candidate/application-templates"] });
      toast({ title: "Success", description: "Template created successfully" });
      setTemplateDialogOpen(false);
      setNewTemplateName("");
      setNewTemplateCategory("");
      setNewTemplateContent("");
    }
  });

  const createReminderMutation = useMutation({
    mutationFn: (data: any) => apiRequest("POST", "/api/candidate/follow-up-reminders", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/candidate/follow-up-reminders"] });
      toast({ title: "Success", description: "Reminder created successfully" });
      setReminderDialogOpen(false);
    }
  });

  const completeReminderMutation = useMutation({
    mutationFn: ({ id, isCompleted }: { id: string, isCompleted: boolean }) => 
      apiRequest("PATCH", `/api/candidate/follow-up-reminders/${id}`, { isCompleted }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/candidate/follow-up-reminders"] });
      toast({ title: "Success", description: "Reminder updated successfully" });
    }
  });

  // Hardcoded applications for demo (existing logic)
  const hardcodedApplications = [
    {
      id: "1",
      jobTitle: "Senior Frontend Developer",
      company: "TechCorp Inc.",
      location: "San Francisco, CA",
      appliedDate: "2024-01-15",
      status: "interview_scheduled",
      statusText: "Interview Scheduled",
      salary: "$120,000 - $150,000",
      interviewDate: "2024-01-22",
      notes: "Technical round with the frontend team",
      recruiterContact: "sarah.johnson@techcorp.com"
    },
    {
      id: "2",
      jobTitle: "Full Stack Engineer",
      company: "StartupXYZ",
      location: "Remote",
      appliedDate: "2024-01-10",
      status: "under_review",
      statusText: "Under Review",
      salary: "$100,000 - $130,000",
      notes: "Applied through company website",
      recruiterContact: "hr@startupxyz.com"
    },
    {
      id: "3",
      jobTitle: "React Developer",
      company: "Digital Solutions",
      location: "New York, NY",
      appliedDate: "2024-01-08",
      status: "rejected",
      statusText: "Not Selected",
      salary: "$110,000 - $140,000",
      feedback: "Strong technical skills but looking for more backend experience"
    },
    {
      id: "4",
      jobTitle: "UI/UX Developer",
      company: "Creative Agency",
      location: "Los Angeles, CA",
      appliedDate: "2024-01-20",
      status: "applied",
      statusText: "Application Sent",
      salary: "$95,000 - $125,000",
      notes: "Portfolio review pending"
    },
    {
      id: "5",
      jobTitle: "Lead Frontend Engineer",
      company: "Enterprise Corp",
      location: "Seattle, WA",
      appliedDate: "2024-01-18",
      status: "offer_received",
      statusText: "Offer Received",
      salary: "$140,000 - $170,000",
      offerDeadline: "2024-01-30",
      notes: "Negotiating start date and benefits package"
    }
  ];

  // Filter applications based on search and status
  const getFilteredApplications = () => {
    const apps = applications.length > 0 ? applications as any[] : hardcodedApplications;
    return apps.filter((app: any) => {
      const matchesSearch = app.jobTitle?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           app.company?.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesStatus = statusFilter === "all" || app.status === statusFilter;
      return matchesSearch && matchesStatus;
    });
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "applied": return "bg-blue-100 text-blue-700 border-blue-200";
      case "under_review": return "bg-yellow-100 text-yellow-700 border-yellow-200";
      case "interview_scheduled": return "bg-purple-100 text-purple-700 border-purple-200";
      case "offer_received": return "bg-green-100 text-green-700 border-green-200";
      case "rejected": return "bg-red-100 text-red-700 border-red-200";
      default: return "bg-gray-100 text-gray-700 border-gray-200";
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "applied": return <Clock className="h-4 w-4" />;
      case "under_review": return <AlertCircle className="h-4 w-4" />;
      case "interview_scheduled": return <Calendar className="h-4 w-4" />;
      case "offer_received": return <CheckCircle className="h-4 w-4" />;
      case "rejected": return <XCircle className="h-4 w-4" />;
      default: return <Clock className="h-4 w-4" />;
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "high": return "bg-red-100 text-red-700 border-red-200";
      case "medium": return "bg-yellow-100 text-yellow-700 border-yellow-200";
      case "low": return "bg-green-100 text-green-700 border-green-200";
      default: return "bg-gray-100 text-gray-700 border-gray-200";
    }
  };

  const displayApplications = getFilteredApplications();
  const allApplications = applications.length > 0 ? applications as any[] : hardcodedApplications;

  const statusCounts = {
    all: allApplications.length,
    applied: allApplications.filter((app: any) => app.status === "applied").length,
    under_review: allApplications.filter((app: any) => app.status === "under_review").length,
    interview_scheduled: allApplications.filter((app: any) => app.status === "interview_scheduled").length,
    offer_received: allApplications.filter((app: any) => app.status === "offer_received").length,
    rejected: allApplications.filter((app: any) => app.status === "rejected").length,
  };

  if (isLoading) {
    return (
      <div className="max-w-6xl mx-auto p-6">
        <div className="space-y-4">
          {[1, 2, 3].map((i) => (
            <Card key={i} className="animate-pulse">
              <CardContent className="p-6">
                <div className="h-4 bg-gray-200 rounded w-1/4 mb-2"></div>
                <div className="h-3 bg-gray-200 rounded w-1/2 mb-4"></div>
                <div className="h-3 bg-gray-200 rounded w-3/4"></div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto p-6">
      <div className="mb-8">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 mb-2">Application Tracker</h1>
            <p className="text-muted-foreground">
              Track applications, manage drafts, create templates, set reminders, and analyze your success
            </p>
          </div>
          <div className="flex gap-2">
            <Button onClick={() => setDraftDialogOpen(true)} className="bg-sky-500 hover:bg-sky-600">
              <Plus className="h-4 w-4 mr-2" />
              Create Draft
            </Button>
            <Button onClick={() => setTemplateDialogOpen(true)} variant="outline">
              <FileText className="h-4 w-4 mr-2" />
              New Template
            </Button>
          </div>
        </div>
      </div>

      {/* Phase 2: Enhanced Tabs Interface */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="applications" className="flex items-center gap-2">
            <FileText className="h-4 w-4" />
            Applications
          </TabsTrigger>
          <TabsTrigger value="drafts" className="flex items-center gap-2">
            <Edit3 className="h-4 w-4" />
            Drafts ({draftApplications.length})
          </TabsTrigger>
          <TabsTrigger value="templates" className="flex items-center gap-2">
            <Copy className="h-4 w-4" />
            Templates ({templates.length})
          </TabsTrigger>
          <TabsTrigger value="reminders" className="flex items-center gap-2">
            <Bell className="h-4 w-4" />
            Reminders ({reminders.filter((r: any) => !r.isCompleted).length})
          </TabsTrigger>
          <TabsTrigger value="analytics" className="flex items-center gap-2">
            <BarChart3 className="h-4 w-4" />
            Analytics
          </TabsTrigger>
        </TabsList>

        {/* Tab 1: Application History (Existing + Enhanced) */}
        <TabsContent value="applications" className="space-y-6">
          {/* Stats Cards */}
          <div className="grid grid-cols-2 md:grid-cols-6 gap-4">
            <Card className="border-blue-200">
              <CardContent className="p-4 text-center">
                <div className="text-2xl font-bold text-blue-700">{statusCounts.all}</div>
                <div className="text-xs text-gray-600">Total Applications</div>
              </CardContent>
            </Card>
            <Card className="border-yellow-200">
              <CardContent className="p-4 text-center">
                <div className="text-2xl font-bold text-yellow-700">{statusCounts.applied}</div>
                <div className="text-xs text-gray-600">Applied</div>
              </CardContent>
            </Card>
            <Card className="border-purple-200">
              <CardContent className="p-4 text-center">
                <div className="text-2xl font-bold text-purple-700">{statusCounts.under_review}</div>
                <div className="text-xs text-gray-600">Under Review</div>
              </CardContent>
            </Card>
            <Card className="border-orange-200">
              <CardContent className="p-4 text-center">
                <div className="text-2xl font-bold text-orange-700">{statusCounts.interview_scheduled}</div>
                <div className="text-xs text-gray-600">Interviews</div>
              </CardContent>
            </Card>
            <Card className="border-green-200">
              <CardContent className="p-4 text-center">
                <div className="text-2xl font-bold text-green-700">{statusCounts.offer_received}</div>
                <div className="text-xs text-gray-600">Offers</div>
              </CardContent>
            </Card>
            <Card className="border-red-200">
              <CardContent className="p-4 text-center">
                <div className="text-2xl font-bold text-red-700">{statusCounts.rejected}</div>
                <div className="text-xs text-gray-600">Rejected</div>
              </CardContent>
            </Card>
          </div>

          {/* Filters and Search */}
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
              <Input
                placeholder="Search by job title or company..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-full sm:w-48">
                <SelectValue placeholder="Filter by status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Applications</SelectItem>
                <SelectItem value="applied">Applied</SelectItem>
                <SelectItem value="under_review">Under Review</SelectItem>
                <SelectItem value="interview_scheduled">Interview Scheduled</SelectItem>
                <SelectItem value="offer_received">Offer Received</SelectItem>
                <SelectItem value="rejected">Rejected</SelectItem>
              </SelectContent>
            </Select>
            <Button onClick={() => setReminderDialogOpen(true)} variant="outline">
              <Bell className="h-4 w-4 mr-2" />
              Add Reminder
            </Button>
          </div>

          {/* Applications List */}
          <div className="space-y-4">
            {displayApplications.map((application: any) => (
              <Card key={application.id} className="hover:shadow-lg transition-shadow">
                <CardContent className="p-6">
                  <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
                    <div className="flex-1">
                      <div className="flex items-start justify-between mb-3">
                        <div>
                          <h3 className="text-lg font-semibold text-gray-900 mb-1">
                            {application.jobTitle}
                          </h3>
                          <div className="flex items-center gap-4 text-sm text-gray-600">
                            <div className="flex items-center gap-1">
                              <Building className="h-4 w-4" />
                              {application.company}
                            </div>
                            <div className="flex items-center gap-1">
                              <MapPin className="h-4 w-4" />
                              {application.location}
                            </div>
                            <div className="flex items-center gap-1">
                              <Calendar className="h-4 w-4" />
                              Applied: {application.appliedDate}
                            </div>
                          </div>
                        </div>
                        <Badge className={`${getStatusColor(application.status)} border`}>
                          {getStatusIcon(application.status)}
                          <span className="ml-1">{application.statusText}</span>
                        </Badge>
                      </div>
                      
                      {application.salary && (
                        <div className="text-sm text-gray-600 mb-2">
                          <strong>Salary:</strong> {application.salary}
                        </div>
                      )}
                      
                      {application.notes && (
                        <div className="text-sm text-gray-600 mb-2">
                          <strong>Notes:</strong> {application.notes}
                        </div>
                      )}
                      
                      {application.feedback && (
                        <div className="text-sm text-gray-600 mb-2">
                          <strong>Feedback:</strong> {application.feedback}
                        </div>
                      )}
                      
                      {application.interviewDate && (
                        <div className="text-sm text-green-600 mb-2">
                          <strong>Interview:</strong> {application.interviewDate}
                        </div>
                      )}
                      
                      {application.offerDeadline && (
                        <div className="text-sm text-orange-600 mb-2">
                          <strong>Offer Deadline:</strong> {application.offerDeadline}
                        </div>
                      )}
                    </div>
                    
                    <div className="flex gap-2">
                      <Button variant="outline" size="sm">
                        <Eye className="h-4 w-4 mr-1" />
                        View
                      </Button>
                      {application.recruiterContact && (
                        <Button variant="outline" size="sm">
                          <Mail className="h-4 w-4 mr-1" />
                          Contact
                        </Button>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* Tab 2: Draft Applications */}
        <TabsContent value="drafts" className="space-y-6">
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-semibold">Draft Applications</h2>
            <Button onClick={() => setDraftDialogOpen(true)} className="bg-sky-500 hover:bg-sky-600">
              <Plus className="h-4 w-4 mr-2" />
              Create New Draft
            </Button>
          </div>
          
          <div className="space-y-4">
            {draftApplications.map((draft: any) => (
              <Card key={draft.id} className="hover:shadow-lg transition-shadow">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div className="flex-1">
                      <h3 className="text-lg font-semibold text-gray-900 mb-2">{draft.jobTitle}</h3>
                      <div className="flex items-center gap-4 text-sm text-gray-600 mb-3">
                        <div className="flex items-center gap-1">
                          <Building className="h-4 w-4" />
                          {draft.company}
                        </div>
                        <div className="flex items-center gap-1">
                          <Clock className="h-4 w-4" />
                          Last edited: {new Date(draft.lastEdited).toLocaleDateString()}
                        </div>
                        <div className="flex items-center gap-1">
                          <FileText className="h-4 w-4" />
                          Template: {draft.templateUsed}
                        </div>
                      </div>
                      
                      <div className="mb-3">
                        <div className="flex items-center justify-between mb-1">
                          <span className="text-sm text-gray-600">Completion</span>
                          <span className="text-sm font-medium">{draft.completionStatus}%</span>
                        </div>
                        <Progress value={draft.completionStatus} className="h-2" />
                      </div>
                      
                      {draft.notes && (
                        <div className="text-sm text-gray-600">
                          <strong>Notes:</strong> {draft.notes}
                        </div>
                      )}
                    </div>
                    
                    <div className="flex gap-2 ml-4">
                      <Button variant="outline" size="sm">
                        <Edit3 className="h-4 w-4 mr-1" />
                        Edit
                      </Button>
                      <Button size="sm" className="bg-green-600 hover:bg-green-700">
                        <Save className="h-4 w-4 mr-1" />
                        Submit
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* Tab 3: Application Templates */}
        <TabsContent value="templates" className="space-y-6">
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-semibold">Application Templates</h2>
            <Button onClick={() => setTemplateDialogOpen(true)} variant="outline">
              <Plus className="h-4 w-4 mr-2" />
              Create Template
            </Button>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
            {templates.map((template: any) => (
              <Card key={template.id} className="hover:shadow-lg transition-shadow">
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-lg">{template.name}</CardTitle>
                    {template.isDefault && (
                      <Badge className="bg-sky-100 text-sky-700 border-sky-200">
                        <Star className="h-3 w-3 mr-1" />
                        Default
                      </Badge>
                    )}
                  </div>
                  <CardDescription>{template.description}</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-gray-600">Category:</span>
                      <Badge variant="outline">{template.category}</Badge>
                    </div>
                    
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-gray-600">Usage:</span>
                      <span className="font-medium">{template.usageCount} times</span>
                    </div>
                    
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-gray-600">Last used:</span>
                      <span>{new Date(template.lastUsed).toLocaleDateString()}</span>
                    </div>
                    
                    <Separator />
                    
                    <div className="flex gap-2">
                      <Button variant="outline" size="sm" className="flex-1">
                        <Eye className="h-4 w-4 mr-1" />
                        Preview
                      </Button>
                      <Button size="sm" className="flex-1 bg-sky-500 hover:bg-sky-600">
                        <Copy className="h-4 w-4 mr-1" />
                        Use Template
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* Tab 4: Follow-up Reminders */}
        <TabsContent value="reminders" className="space-y-6">
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-semibold">Follow-up Reminders</h2>
            <Button onClick={() => setReminderDialogOpen(true)} variant="outline">
              <Plus className="h-4 w-4 mr-2" />
              Add Reminder
            </Button>
          </div>
          
          <div className="space-y-4">
            {reminders.map((reminder: any) => (
              <Card key={reminder.id} className={`hover:shadow-lg transition-shadow ${reminder.isCompleted ? 'opacity-60' : ''}`}>
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <h3 className="text-lg font-semibold text-gray-900">{reminder.jobTitle}</h3>
                        <Badge className={getPriorityColor(reminder.priority)}>
                          {reminder.priority.charAt(0).toUpperCase() + reminder.priority.slice(1)}
                        </Badge>
                        {reminder.isCompleted && (
                          <Badge className="bg-green-100 text-green-700 border-green-200">
                            <CheckCircle className="h-3 w-3 mr-1" />
                            Completed
                          </Badge>
                        )}
                      </div>
                      
                      <div className="flex items-center gap-4 text-sm text-gray-600 mb-3">
                        <div className="flex items-center gap-1">
                          <Building className="h-4 w-4" />
                          {reminder.company}
                        </div>
                        <div className="flex items-center gap-1">
                          <Calendar className="h-4 w-4" />
                          {new Date(reminder.reminderDate).toLocaleDateString()}
                        </div>
                        <div className="flex items-center gap-1">
                          <Bell className="h-4 w-4" />
                          {reminder.reminderType.replace('_', ' ').charAt(0).toUpperCase() + reminder.reminderType.replace('_', ' ').slice(1)}
                        </div>
                      </div>
                      
                      <p className="text-sm text-gray-700">{reminder.message}</p>
                      
                      {reminder.isCompleted && reminder.completedAt && (
                        <div className="text-sm text-green-600 mt-2">
                          Completed on: {new Date(reminder.completedAt).toLocaleDateString()}
                        </div>
                      )}
                    </div>
                    
                    <div className="flex gap-2 ml-4">
                      {!reminder.isCompleted && (
                        <Button 
                          size="sm" 
                          onClick={() => completeReminderMutation.mutate({ id: reminder.id, isCompleted: true })}
                          className="bg-green-600 hover:bg-green-700"
                        >
                          <CheckCircle className="h-4 w-4 mr-1" />
                          Mark Complete
                        </Button>
                      )}
                      <Button variant="outline" size="sm">
                        <Edit3 className="h-4 w-4 mr-1" />
                        Edit
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* Tab 5: Success Analytics Dashboard */}
        <TabsContent value="analytics" className="space-y-6">
          <h2 className="text-xl font-semibold">Success Analytics Dashboard</h2>
          
          {analytics && (
            <>
              {/* Overview Stats */}
              <div className="grid grid-cols-2 md:grid-cols-6 gap-4">
                <Card className="border-blue-200">
                  <CardContent className="p-4 text-center">
                    <div className="text-2xl font-bold text-blue-700">{analytics.overview.totalApplications}</div>
                    <div className="text-xs text-gray-600">Total Applications</div>
                  </CardContent>
                </Card>
                <Card className="border-green-200">
                  <CardContent className="p-4 text-center">
                    <div className="text-2xl font-bold text-green-700">{analytics.overview.responseRate}%</div>
                    <div className="text-xs text-gray-600">Response Rate</div>
                  </CardContent>
                </Card>
                <Card className="border-purple-200">
                  <CardContent className="p-4 text-center">
                    <div className="text-2xl font-bold text-purple-700">{analytics.overview.interviewRate}%</div>
                    <div className="text-xs text-gray-600">Interview Rate</div>
                  </CardContent>
                </Card>
                <Card className="border-orange-200">
                  <CardContent className="p-4 text-center">
                    <div className="text-2xl font-bold text-orange-700">{analytics.overview.offerRate}%</div>
                    <div className="text-xs text-gray-600">Offer Rate</div>
                  </CardContent>
                </Card>
                <Card className="border-cyan-200">
                  <CardContent className="p-4 text-center">
                    <div className="text-2xl font-bold text-cyan-700">{analytics.overview.averageResponseTime}</div>
                    <div className="text-xs text-gray-600">Avg Response (days)</div>
                  </CardContent>
                </Card>
                <Card className="border-emerald-200">
                  <CardContent className="p-4 text-center">
                    <div className="text-2xl font-bold text-emerald-700">{analytics.overview.successScore}</div>
                    <div className="text-xs text-gray-600">Success Score</div>
                  </CardContent>
                </Card>
              </div>

              {/* Application Trends */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <TrendingUp className="h-5 w-5" />
                    Application Trends
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {analytics.applicationTrends.map((trend: any, index: number) => (
                      <div key={index} className="flex items-center justify-between">
                        <div className="font-medium">{trend.month}</div>
                        <div className="flex items-center gap-4 text-sm">
                          <span>Apps: {trend.applications}</span>
                          <span>Responses: {trend.responses}</span>
                          <span>Interviews: {trend.interviews}</span>
                          <span className="text-green-600 font-medium">Offers: {trend.offers}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* Top Performing Templates */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Target className="h-5 w-5" />
                    Top Performing Templates
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {analytics.topPerformingTemplates.map((template: any, index: number) => (
                      <div key={index} className="flex items-center justify-between">
                        <div className="font-medium">{template.template}</div>
                        <div className="flex items-center gap-4 text-sm">
                          <span>Apps: {template.applications}</span>
                          <span>Response: {template.responseRate}%</span>
                          <span className="text-green-600 font-medium">Offers: {template.offerRate}%</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* Skills Impact */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Zap className="h-5 w-5" />
                    Skills Impact Analysis
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {analytics.skillsImpact.map((skill: any, index: number) => (
                      <div key={index} className="flex items-center justify-between">
                        <div className="font-medium">{skill.skill}</div>
                        <div className="flex items-center gap-4 text-sm">
                          <span>Apps: {skill.applications}</span>
                          <span>Success: {skill.successRate}%</span>
                          <Badge className={skill.demandTrend === 'up' ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-700'}>
                            {skill.demandTrend === 'up' ? '↗️ Growing' : '→ Stable'}
                          </Badge>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </>
          )}
        </TabsContent>
      </Tabs>

      {/* Phase 2: Dialog Modals */}
      
      {/* Create Template Dialog */}
      <Dialog open={templateDialogOpen} onOpenChange={setTemplateDialogOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Create New Template</DialogTitle>
            <DialogDescription>
              Create a reusable cover letter template for future applications
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label htmlFor="template-name">Template Name</Label>
              <Input
                id="template-name"
                placeholder="e.g., Tech Role Template"
                value={newTemplateName}
                onChange={(e) => setNewTemplateName(e.target.value)}
              />
            </div>
            <div>
              <Label htmlFor="template-category">Category</Label>
              <Select value={newTemplateCategory} onValueChange={setNewTemplateCategory}>
                <SelectTrigger>
                  <SelectValue placeholder="Select a category" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Technology">Technology</SelectItem>
                  <SelectItem value="Startup">Startup</SelectItem>
                  <SelectItem value="Enterprise">Enterprise</SelectItem>
                  <SelectItem value="Finance">Finance</SelectItem>
                  <SelectItem value="Healthcare">Healthcare</SelectItem>
                  <SelectItem value="General">General</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="template-content">Cover Letter Template</Label>
              <Textarea
                id="template-content"
                placeholder="Dear {hiringManager},...&#10;&#10;Use placeholders like {jobTitle}, {company}, {skills} for dynamic content"
                value={newTemplateContent}
                onChange={(e) => setNewTemplateContent(e.target.value)}
                rows={8}
              />
              <div className="text-sm text-gray-500 mt-1">
                Use placeholders: {"{jobTitle}"}, {"{company}"}, {"{hiringManager}"}, {"{skills}"}
              </div>
            </div>
            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={() => setTemplateDialogOpen(false)}>
                Cancel
              </Button>
              <Button 
                onClick={() => createTemplateMutation.mutate({
                  name: newTemplateName,
                  description: `Template for ${newTemplateCategory} positions`,
                  coverLetterTemplate: newTemplateContent,
                  category: newTemplateCategory
                })}
                disabled={!newTemplateName || !newTemplateCategory || !newTemplateContent}
              >
                Create Template
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}

export default function ApplicationTracker() {
  return (
    <PlatformLayout
      sidebarTitle="Candidate Platform"
      sidebarSubtitle="Job Search & Applications"
      sidebarSections={candidateNavigation}
    >
      <ApplicationTrackerContent />
    </PlatformLayout>
  );
}