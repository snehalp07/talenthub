import PlatformLayout from "@/components/layout/platform-layout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { TrendingUp, DollarSign, Users, MapPin, Building, BarChart3, ArrowUp, ArrowDown } from "lucide-react";
import { candidateNavigation } from "@/config/complete-navigation";

export default function MarketIntelligence() {
  const marketMetrics = [
    { label: "Avg. Salary Range", value: "$85K-120K", change: 8, color: "bg-green-500", icon: DollarSign },
    { label: "Job Openings", value: "2,847", change: 15, color: "bg-blue-500", icon: Users },
    { label: "Market Growth", value: "12%", change: 3, color: "bg-purple-500", icon: TrendingUp },
    { label: "Remote Positions", value: "68%", change: 5, color: "bg-orange-500", icon: MapPin }
  ];

  const salaryTrends = [
    { role: "Senior Frontend Developer", min: 85000, max: 120000, median: 102000, growth: "+8%" },
    { role: "Full Stack Developer", min: 75000, max: 110000, median: 92000, growth: "+12%" },
    { role: "DevOps Engineer", min: 90000, max: 130000, median: 110000, growth: "+15%" },
    { role: "Cloud Architect", min: 110000, max: 160000, median: 135000, growth: "+18%" }
  ];

  const topSkills = [
    { skill: "React", demand: 92, growth: "+15%", jobs: 1247 },
    { skill: "Node.js", demand: 88, growth: "+18%", jobs: 1098 },
    { skill: "TypeScript", demand: 85, growth: "+22%", jobs: 967 },
    { skill: "AWS", demand: 82, growth: "+25%", jobs: 876 },
    { skill: "Python", demand: 79, growth: "+12%", jobs: 834 },
    { skill: "Docker", demand: 76, growth: "+20%", jobs: 723 }
  ];

  const topCompanies = [
    { name: "TechCorp", openings: 45, avgSalary: 115000, rating: 4.6, industry: "Technology" },
    { name: "InnovateX", openings: 32, avgSalary: 108000, rating: 4.4, industry: "Software" },
    { name: "CloudScale", openings: 28, avgSalary: 125000, rating: 4.8, industry: "Cloud Services" },
    { name: "DataFlow", openings: 23, avgSalary: 98000, rating: 4.2, industry: "Data Analytics" },
    { name: "StartupHub", openings: 19, avgSalary: 95000, rating: 4.3, industry: "Startup" }
  ];

  const locationData = [
    { city: "San Francisco", jobs: 456, avgSalary: 135000, costIndex: 180 },
    { city: "New York", jobs: 389, avgSalary: 125000, costIndex: 165 },
    { city: "Seattle", jobs: 312, avgSalary: 118000, costIndex: 145 },
    { city: "Austin", jobs: 287, avgSalary: 105000, costIndex: 120 },
    { city: "Denver", jobs: 234, avgSalary: 98000, costIndex: 115 }
  ];

  return (
    <PlatformLayout 
      sidebarTitle="Candidate Platform"
      sidebarSubtitle="Professional Development Hub"
      sidebarSections={candidateNavigation}
    >
      <div className="max-w-7xl mx-auto p-6 space-y-8">
        <div className="text-center space-y-4">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-indigo-100 to-blue-100 rounded-full">
            <BarChart3 className="h-5 w-5 text-indigo-600" />
            <span className="text-sm font-medium text-indigo-900">Market Intelligence</span>
          </div>
          <h1 className="text-4xl font-bold bg-gradient-to-r from-indigo-600 to-blue-600 bg-clip-text text-transparent">
            Industry Market Analysis
          </h1>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            Stay ahead with real-time market insights, salary trends, and demand patterns in your industry
          </p>
        </div>

        {/* Market Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {marketMetrics.map((metric, index) => {
            const IconComponent = metric.icon;
            return (
              <Card key={index} className="hover:shadow-md transition-shadow">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between mb-4">
                    <div className={`p-3 rounded-lg ${metric.color} text-white`}>
                      <IconComponent className="h-6 w-6" />
                    </div>
                    <div className={`flex items-center gap-1 px-2 py-1 rounded-full text-sm ${
                      Number(metric.change) > 0 ? 'bg-emerald-100 text-emerald-700' : 'bg-red-100 text-red-700'
                    }`}>
                      {Number(metric.change) > 0 ? <ArrowUp className="h-3 w-3" /> : <ArrowDown className="h-3 w-3" />}
                      {Math.abs(Number(metric.change))}%
                    </div>
                  </div>
                  <div className="text-2xl font-bold text-gray-900 mb-1">{metric.value}</div>
                  <div className="text-sm text-gray-600">{metric.label}</div>
                </CardContent>
              </Card>
            );
          })}
        </div>

        <Tabs defaultValue="overview" className="space-y-6">
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="salaries">Salary Trends</TabsTrigger>
            <TabsTrigger value="skills">In-Demand Skills</TabsTrigger>
            <TabsTrigger value="companies">Top Companies</TabsTrigger>
            <TabsTrigger value="locations">Locations</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Market Growth Trends</CardTitle>
                  <CardDescription>Tech industry growth over the past year</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="h-64 flex items-center justify-center text-gray-500">
                    <div className="text-center">
                      <TrendingUp className="h-12 w-12 mx-auto mb-2" />
                      <p>Market growth chart visualization</p>
                      <div className="mt-4 space-y-2 text-sm">
                        <div className="flex justify-between">
                          <span>Job market growth:</span>
                          <span className="font-medium text-indigo-600">+12%</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Salary increase:</span>
                          <span className="font-medium text-green-600">+8.5%</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Quick Market Insights</CardTitle>
                  <CardDescription>Key trends and opportunities</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="border-l-4 border-blue-500 pl-4">
                      <div className="font-medium text-gray-900">Remote Work Surge</div>
                      <div className="text-sm text-gray-600">68% of positions now offer remote work options</div>
                    </div>
                    <div className="border-l-4 border-green-500 pl-4">
                      <div className="font-medium text-gray-900">Cloud Skills Premium</div>
                      <div className="text-sm text-gray-600">AWS and Azure skills command 25% salary premium</div>
                    </div>
                    <div className="border-l-4 border-purple-500 pl-4">
                      <div className="font-medium text-gray-900">TypeScript Adoption</div>
                      <div className="text-sm text-gray-600">TypeScript demand increased 22% this year</div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="salaries" className="space-y-6">
            <div className="grid gap-6">
              {salaryTrends.map((role, index) => (
                <Card key={index} className="hover:shadow-md transition-shadow">
                  <CardContent className="p-6">
                    <div className="flex items-start justify-between mb-4">
                      <div>
                        <div className="font-semibold text-lg text-gray-900">{role.role}</div>
                        <div className="text-sm text-gray-600">Annual salary range</div>
                      </div>
                      <Badge className="bg-green-600 hover:bg-green-700">{role.growth}</Badge>
                    </div>
                    
                    <div className="grid grid-cols-3 gap-4 mb-4">
                      <div className="text-center">
                        <div className="text-lg font-bold text-gray-600">${(role.min / 1000).toFixed(0)}K</div>
                        <div className="text-sm text-gray-500">Minimum</div>
                      </div>
                      <div className="text-center">
                        <div className="text-lg font-bold text-indigo-600">${(role.median / 1000).toFixed(0)}K</div>
                        <div className="text-sm text-gray-500">Median</div>
                      </div>
                      <div className="text-center">
                        <div className="text-lg font-bold text-gray-600">${(role.max / 1000).toFixed(0)}K</div>
                        <div className="text-sm text-gray-500">Maximum</div>
                      </div>
                    </div>
                    
                    <div className="relative">
                      <Progress value={60} className="h-2" />
                      <div className="flex justify-between text-xs text-gray-500 mt-1">
                        <span>${(role.min / 1000).toFixed(0)}K</span>
                        <span>${(role.max / 1000).toFixed(0)}K</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="skills" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Most In-Demand Skills</CardTitle>
                <CardDescription>Skills with highest market demand and growth potential</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  {topSkills.map((skill, index) => (
                    <div key={index} className="space-y-3">
                      <div className="flex items-center justify-between">
                        <span className="font-medium text-gray-900">{skill.skill}</span>
                        <div className="flex items-center gap-4">
                          <Badge className="bg-indigo-600 hover:bg-indigo-700">{skill.growth}</Badge>
                          <span className="text-sm text-gray-600">{skill.jobs} jobs</span>
                        </div>
                      </div>
                      <div className="flex items-center gap-3">
                        <Progress value={skill.demand} className="flex-1 h-2" />
                        <span className="text-sm font-medium text-indigo-600 w-12">{skill.demand}%</span>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="companies" className="space-y-6">
            <div className="grid gap-6">
              {topCompanies.map((company, index) => (
                <Card key={index} className="hover:shadow-md transition-shadow">
                  <CardContent className="p-6">
                    <div className="flex items-start justify-between mb-4">
                      <div className="space-y-1">
                        <div className="font-semibold text-lg text-gray-900">{company.name}</div>
                        <div className="text-sm text-gray-600">{company.industry}</div>
                      </div>
                      <div className="text-right">
                        <div className="text-lg font-bold text-indigo-600">{company.openings}</div>
                        <div className="text-sm text-gray-600">open positions</div>
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <div className="text-sm text-gray-600">Average Salary</div>
                        <div className="text-lg font-semibold text-green-600">${(company.avgSalary / 1000).toFixed(0)}K</div>
                      </div>
                      <div>
                        <div className="text-sm text-gray-600">Company Rating</div>
                        <div className="text-lg font-semibold text-yellow-600">{company.rating}/5.0</div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="locations" className="space-y-6">
            <div className="grid gap-6">
              {locationData.map((location, index) => (
                <Card key={index} className="hover:shadow-md transition-shadow">
                  <CardContent className="p-6">
                    <div className="flex items-start justify-between mb-4">
                      <div className="space-y-1">
                        <div className="font-semibold text-lg text-gray-900">{location.city}</div>
                        <div className="text-sm text-gray-600">{location.jobs} job openings</div>
                      </div>
                      <Badge variant="outline">Top {index + 1}</Badge>
                    </div>
                    
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <div className="text-sm text-gray-600">Average Salary</div>
                        <div className="text-lg font-semibold text-green-600">${(location.avgSalary / 1000).toFixed(0)}K</div>
                      </div>
                      <div>
                        <div className="text-sm text-gray-600">Cost of Living Index</div>
                        <div className="text-lg font-semibold text-orange-600">{location.costIndex}</div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </PlatformLayout>
  );
}