import { useState, useRef, useEffect } from "react";
import { useAuth } from "@/hooks/use-auth";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import PlatformLayout from "@/components/layout/platform-layout";
import { platformConfigs } from "@/config/complete-navigation";
import { useThemeClasses } from "@/lib/theme-config";

import { 
  Video, 
  Play, 
  Pause, 
  Square, 
  Upload, 
  Download,
  Edit,
  Share,
  Eye,
  Clock,
  Camera,
  Mic,
  FileVideo,
  Award,
  Star,
  BarChart3,
  Users,
  PlayCircle,
  StopCircle
} from "lucide-react";

function VideoCVContent() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [isRecording, setIsRecording] = useState(false);
  const [recordingDuration, setRecordingDuration] = useState(0);
  const [selectedTemplate, setSelectedTemplate] = useState("professional");
  const [mediaRecorder, setMediaRecorder] = useState<MediaRecorder | null>(null);
  const [videoBlob, setVideoBlob] = useState<Blob | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const streamRef = useRef<MediaStream | null>(null);

  const { data: videoTemplates } = useQuery({
    queryKey: ["/api/video-cv/templates"],
    initialData: [
      {
        id: "professional",
        name: "Professional Introduction",
        duration: "60-90 seconds",
        sections: ["Personal intro", "Experience highlights", "Key skills", "Career goals"],
        difficulty: "Beginner"
      },
      {
        id: "technical",
        name: "Technical Showcase",
        duration: "2-3 minutes", 
        sections: ["Tech introduction", "Project demos", "Code walkthrough", "Problem solving"],
        difficulty: "Advanced"
      },
      {
        id: "creative",
        name: "Creative Portfolio",
        duration: "90-120 seconds",
        sections: ["Creative intro", "Portfolio showcase", "Design process", "Vision statement"],
        difficulty: "Intermediate"
      }
    ]
  });

  const { data: userVideos = [] } = useQuery({
    queryKey: ["/api/video-cv/my-videos"],
    initialData: [
      {
        id: "video-1",
        title: "Professional Introduction",
        template: "professional",
        duration: 85,
        status: "published",
        views: 127,
        createdAt: "2024-06-05T10:30:00Z",
        thumbnail: "/thumbnails/video1.jpg",
        analytics: {
          completionRate: 78,
          engagement: 85,
          feedback: "Excellent presentation skills"
        }
      },
      {
        id: "video-2",
        title: "Technical Skills Demo",
        template: "technical",
        duration: 165,
        status: "draft",
        views: 0,
        createdAt: "2024-06-08T14:20:00Z",
        thumbnail: "/thumbnails/video2.jpg",
        analytics: null
      }
    ]
  });

  // Recording functions
  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ 
        video: { width: 1280, height: 720 }, 
        audio: true 
      });
      
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }
      
      const recorder = new MediaRecorder(stream);
      const chunks: BlobPart[] = [];
      
      recorder.ondataavailable = (e) => chunks.push(e.data);
      recorder.onstop = () => {
        const blob = new Blob(chunks, { type: 'video/webm' });
        setVideoBlob(blob);
        setPreviewUrl(URL.createObjectURL(blob));
        stream.getTracks().forEach(track => track.stop());
      };
      
      setMediaRecorder(recorder);
      recorder.start();
      setIsRecording(true);
      
      toast({
        title: "Recording started",
        description: "Your video recording has begun.",
      });
    } catch (error) {
      toast({
        title: "Recording failed",
        description: "Unable to access camera and microphone.",
        variant: "destructive",
      });
    }
  };

  const stopRecording = () => {
    if (mediaRecorder && mediaRecorder.state !== 'inactive') {
      mediaRecorder.stop();
      setIsRecording(false);
      setRecordingDuration(0);
      
      toast({
        title: "Recording stopped",
        description: "Your video has been recorded successfully.",
      });
    }
  };

  // Timer effect for recording duration
  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isRecording) {
      interval = setInterval(() => {
        setRecordingDuration(prev => prev + 1);
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [isRecording]);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const { data: recordingTips } = useQuery({
    queryKey: ["/api/video-cv/tips"],
    initialData: {
      preparation: [
        "Choose a quiet, well-lit location",
        "Test your camera and microphone beforehand",
        "Prepare an outline but don't memorize word-for-word",
        "Practice maintaining eye contact with the camera"
      ],
      technical: [
        "Use landscape orientation (16:9 ratio)",
        "Ensure stable internet connection for uploads",
        "Record in HD quality (1080p minimum)",
        "Keep file size under 500MB for faster processing"
      ],
      presentation: [
        "Speak clearly and at moderate pace",
        "Use confident body language and gestures",
        "Smile naturally and be authentic",
        "Keep content concise and engaging"
      ]
    }
  });



  const uploadVideoMutation = useMutation({
    mutationFn: async (videoData: FormData) => {
      return apiRequest("POST", "/api/video-cv/upload", videoData);
    },
    onSuccess: () => {
      toast({
        title: "Video Uploaded",
        description: "Your video CV has been uploaded successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/video-cv/my-videos"] });
    },
  });

  const getStatusBadge = (status: string) => {
    const variants = {
      draft: "bg-yellow-100 text-yellow-800",
      published: "bg-green-100 text-green-800",
      processing: "bg-blue-100 text-blue-800",
      private: "bg-gray-100 text-gray-800"
    };
    return variants[status as keyof typeof variants] || variants.draft;
  };

  const formatDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className="max-w-7xl mx-auto p-6">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Video CV Studio</h1>
        <p className="text-muted-foreground">Create compelling video resumes that showcase your personality and skills</p>
      </div>

      <Tabs defaultValue="record" className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="record">Record</TabsTrigger>
          <TabsTrigger value="templates">Templates</TabsTrigger>
          <TabsTrigger value="my-videos">My Videos</TabsTrigger>
          <TabsTrigger value="tips">Tips & Guides</TabsTrigger>
        </TabsList>

        <TabsContent value="record" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Recording Interface */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Camera className="w-5 h-5 mr-2 text-red-500" />
                  Video Recording
                </CardTitle>
                <CardDescription>
                  Record your video CV directly in your browser
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="aspect-video bg-gray-900 rounded-lg flex items-center justify-center relative">
                  <video
                    ref={videoRef}
                    className="w-full h-full rounded-lg"
                    autoPlay
                    muted
                    style={{ display: isRecording ? 'block' : 'none' }}
                  />
                  {!isRecording && (
                    <div className="text-center text-white">
                      <Camera className="w-16 h-16 mx-auto mb-4 opacity-50" />
                      <p className="text-lg">Click Start Recording to begin</p>
                    </div>
                  )}
                  
                  {isRecording && (
                    <div className="absolute top-4 left-4 flex items-center bg-red-600 text-white px-3 py-1 rounded-full">
                      <div className="w-2 h-2 bg-white rounded-full mr-2 animate-pulse"></div>
                      <span className="text-sm font-medium">REC {formatTime(recordingDuration)}</span>
                    </div>
                  )}
                </div>

                <div className="flex justify-center space-x-4">
                  {!isRecording ? (
                    <Button onClick={startRecording} className="bg-red-600 hover:bg-red-700">
                      <Video className="w-4 h-4 mr-2" />
                      Start Recording
                    </Button>
                  ) : (
                    <Button onClick={stopRecording} variant="destructive">
                      <Square className="w-4 h-4 mr-2" />
                      Stop Recording
                    </Button>
                  )}
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium">Video Title</label>
                  <Input placeholder="Enter title for your video CV" />
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium">Description</label>
                  <Textarea 
                    placeholder="Brief description of your video content..."
                    rows={3}
                  />
                </div>
              </CardContent>
            </Card>

            {/* Upload & Settings */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Upload className="w-5 h-5 mr-2 text-sky-600" />
                  Upload Video
                </CardTitle>
                <CardDescription>
                  Upload a pre-recorded video from your device
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="border-2 border-dashed border-gray-300 rounded-lg p-8 text-center">
                  <FileVideo className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                  <p className="text-gray-600 mb-2">Drag and drop your video file here</p>
                  <p className="text-sm text-gray-500 mb-4">Supported formats: MP4, MOV, AVI (Max: 500MB)</p>
                  <Button variant="outline">
                    <Upload className="w-4 h-4 mr-2" />
                    Choose File
                  </Button>
                </div>

                <div className="space-y-4">
                  <div>
                    <label className="text-sm font-medium mb-2 block">Template Style</label>
                    <select className="w-full p-2 border rounded-md">
                      <option value="professional">Professional Introduction</option>
                      <option value="technical">Technical Showcase</option>
                      <option value="creative">Creative Portfolio</option>
                    </select>
                  </div>

                  <div>
                    <label className="text-sm font-medium mb-2 block">Privacy Settings</label>
                    <select className="w-full p-2 border rounded-md">
                      <option value="public">Public - Visible to all employers</option>
                      <option value="unlisted">Unlisted - Only with direct link</option>
                      <option value="private">Private - Only visible to you</option>
                    </select>
                  </div>

                  <Button className="w-full bg-sky-500 hover:bg-sky-600">
                    <Upload className="w-4 h-4 mr-2" />
                    Upload Video
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="templates" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {videoTemplates.map((template: any) => (
              <Card key={template.id} className={`cursor-pointer transition-all ${selectedTemplate === template.id ? 'ring-2 ring-sky-500' : ''}`}>
                <CardHeader>
                  <CardTitle className="text-lg">{template.name}</CardTitle>
                  <CardDescription>
                    Duration: {template.duration} • {template.difficulty}
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <div>
                      <h4 className="font-medium text-sm mb-2">Template Sections:</h4>
                      <ul className="space-y-1">
                        {template.sections.map((section: string, index: number) => (
                          <li key={index} className="text-sm text-gray-600 flex items-center">
                            <span className="w-1 h-1 bg-sky-500 rounded-full mr-2"></span>
                            {section}
                          </li>
                        ))}
                      </ul>
                    </div>
                    <Button 
                      variant="outline" 
                      className="w-full"
                      onClick={() => setSelectedTemplate(template.id)}
                    >
                      Use This Template
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="my-videos" className="space-y-6">
          <div className="grid gap-6">
            {userVideos.map((video: any) => (
              <Card key={video.id}>
                <CardContent className="p-6">
                  <div className="flex items-start space-x-4">
                    <div className="w-32 h-20 bg-gray-200 rounded-lg flex items-center justify-center flex-shrink-0">
                      <Play className="w-8 h-8 text-gray-400" />
                    </div>
                    <div className="flex-1">
                      <div className="flex items-start justify-between">
                        <div>
                          <h3 className="font-semibold text-lg">{video.title}</h3>
                          <p className="text-sm text-gray-600">
                            {formatDuration(video.duration)} • Created {new Date(video.createdAt).toLocaleDateString()}
                          </p>
                          <div className="flex items-center gap-2 mt-2">
                            <Badge className={getStatusBadge(video.status)}>
                              {video.status.toUpperCase()}
                            </Badge>
                            <Badge variant="outline">
                              <Eye className="w-3 h-3 mr-1" />
                              {video.views} views
                            </Badge>
                          </div>
                        </div>
                        <div className="flex space-x-2">
                          <Button size="sm" variant="outline">
                            <Edit className="w-3 h-3 mr-1" />
                            Edit
                          </Button>
                          <Button size="sm" variant="outline">
                            <Share className="w-3 h-3 mr-1" />
                            Share
                          </Button>
                        </div>
                      </div>
                      
                      {video.analytics && (
                        <div className="mt-4 grid grid-cols-3 gap-4">
                          <div className="text-center p-3 bg-gray-50 rounded-lg">
                            <div className="text-lg font-semibold text-green-600">{video.analytics.completionRate}%</div>
                            <div className="text-xs text-gray-600">Completion Rate</div>
                          </div>
                          <div className="text-center p-3 bg-gray-50 rounded-lg">
                            <div className="text-lg font-semibold text-blue-600">{video.analytics.engagement}%</div>
                            <div className="text-xs text-gray-600">Engagement</div>
                          </div>
                          <div className="text-center p-3 bg-gray-50 rounded-lg">
                            <div className="text-lg font-semibold text-purple-600">
                              <Star className="w-4 h-4 inline" />
                            </div>
                            <div className="text-xs text-gray-600">Positive Feedback</div>
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="tips" className="space-y-6">
          <div className="grid gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Award className="w-5 h-5 mr-2 text-yellow-500" />
                  Preparation Tips
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-3">
                  {recordingTips.preparation.map((tip: string, index: number) => (
                    <li key={index} className="flex items-start">
                      <span className="w-2 h-2 bg-yellow-500 rounded-full mt-2 mr-3 flex-shrink-0"></span>
                      <span className="text-gray-700">{tip}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Camera className="w-5 h-5 mr-2 text-blue-500" />
                  Technical Guidelines
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-3">
                  {recordingTips.technical.map((tip: string, index: number) => (
                    <li key={index} className="flex items-start">
                      <span className="w-2 h-2 bg-blue-500 rounded-full mt-2 mr-3 flex-shrink-0"></span>
                      <span className="text-gray-700">{tip}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Mic className="w-5 h-5 mr-2 text-green-500" />
                  Presentation Excellence
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-3">
                  {recordingTips.presentation.map((tip: string, index: number) => (
                    <li key={index} className="flex items-start">
                      <span className="w-2 h-2 bg-green-500 rounded-full mt-2 mr-3 flex-shrink-0"></span>
                      <span className="text-gray-700">{tip}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}

export default function VideoCV() {
  const config = platformConfigs.candidate;
  const theme = useThemeClasses('candidate');
  
  const usageData = [
    { label: "Video CVs Created", current: 3, max: 10 },
    { label: "Profile Views", current: 47, max: 100 },
    { label: "Video Quality", current: 85, max: 100 },
  ];

  return (
    <PlatformLayout
      sidebarTitle={config.sidebarTitle}
      sidebarSubtitle={config.sidebarSubtitle}
      sidebarSections={config.sidebarSections}
      usageData={usageData}
    >
      <VideoCVContent />
    </PlatformLayout>
  );
}