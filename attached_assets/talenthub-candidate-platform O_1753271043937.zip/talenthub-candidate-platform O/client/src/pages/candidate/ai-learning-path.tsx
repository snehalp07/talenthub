import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";
import PlatformLayout from "@/components/layout/platform-layout";
import { platformConfigs } from "@/config/complete-navigation";
import { useThemeClasses } from "@/lib/theme-config";
import { 
  Brain, 
  Target, 
  TrendingUp, 
  Clock, 
  Star, 
  CheckCircle, 
  AlertCircle,
  BookOpen,
  Award,
  Users,
  Calendar,
  Zap,
  BarChart3,
  MapPin,
  RefreshCw,
  Play,
  Pause,
  Settings
} from "lucide-react";

function AILearningPathContent() {
  const [analysisComplete, setAnalysisComplete] = useState(false);
  const [selectedCareerGoal, setSelectedCareerGoal] = useState("");
  const [experienceLevel, setExperienceLevel] = useState([3]);

  const skillGapAnalysis = {
    overallScore: 72,
    strengths: [
      { skill: "JavaScript", proficiency: 85, marketDemand: 92 },
      { skill: "React", proficiency: 82, marketDemand: 89 },
      { skill: "Node.js", proficiency: 78, marketDemand: 85 },
      { skill: "Git", proficiency: 90, marketDemand: 95 }
    ],
    gaps: [
      { skill: "TypeScript", proficiency: 45, marketDemand: 88, priority: "High" },
      { skill: "AWS", proficiency: 35, marketDemand: 91, priority: "High" },
      { skill: "Docker", proficiency: 25, marketDemand: 82, priority: "Medium" },
      { skill: "Kubernetes", proficiency: 15, marketDemand: 78, priority: "Medium" },
      { skill: "GraphQL", proficiency: 30, marketDemand: 75, priority: "Low" }
    ],
    recommendations: [
      "Focus on cloud technologies to align with market trends",
      "Strengthen TypeScript skills for enterprise development",
      "Consider DevOps certifications for career advancement"
    ]
  };

  const personalizedPath = {
    totalDuration: "24 weeks",
    estimatedCost: 1200,
    expectedSalaryIncrease: 25000,
    jobMarketMatch: 89,
    phases: [
      {
        id: 1,
        title: "Foundation Phase",
        duration: "6 weeks",
        description: "Build core competencies in modern development",
        certifications: [
          {
            name: "TypeScript Professional",
            provider: "Platform Native",
            duration: "3 weeks",
            difficulty: "Intermediate",
            prerequisites: ["JavaScript proficiency"],
            priority: "High"
          },
          {
            name: "Modern JavaScript (ES2024)",
            provider: "Platform Native",
            duration: "3 weeks",
            difficulty: "Intermediate",
            prerequisites: ["Basic JavaScript"],
            priority: "Medium"
          }
        ]
      },
      {
        id: 2,
        title: "Cloud Specialization",
        duration: "10 weeks",
        description: "Master cloud technologies and deployment",
        certifications: [
          {
            name: "AWS Solutions Architect Associate",
            provider: "Amazon Web Services",
            duration: "8 weeks",
            difficulty: "Advanced",
            prerequisites: ["Cloud basics", "Networking fundamentals"],
            priority: "High"
          },
          {
            name: "Docker & Containerization",
            provider: "Platform Native",
            duration: "2 weeks",
            difficulty: "Intermediate",
            prerequisites: ["Linux basics"],
            priority: "High"
          }
        ]
      },
      {
        id: 3,
        title: "Advanced Specialization",
        duration: "8 weeks",
        description: "Advanced cloud orchestration and DevOps",
        certifications: [
          {
            name: "Kubernetes Administrator (CKA)",
            provider: "Cloud Native Computing Foundation",
            duration: "6 weeks",
            difficulty: "Expert",
            prerequisites: ["Docker proficiency", "Linux administration"],
            priority: "Medium"
          },
          {
            name: "GraphQL API Development",
            provider: "Platform Native",
            duration: "2 weeks",
            difficulty: "Advanced",
            prerequisites: ["API development experience"],
            priority: "Low"
          }
        ]
      }
    ]
  };

  const adaptiveLearning = {
    currentWeek: 8,
    totalWeeks: 24,
    progressScore: 78,
    adaptations: [
      {
        type: "pace-adjustment",
        message: "Based on your learning speed, we've extended the TypeScript module by 1 week",
        impact: "Improved comprehension predicted",
        date: "2024-02-15"
      },
      {
        type: "content-recommendation",
        message: "Added bonus module on React Testing based on your interests",
        impact: "Enhanced skill depth",
        date: "2024-02-10"
      },
      {
        type: "difficulty-adjustment",
        message: "Simplified AWS networking concepts based on quiz results",
        impact: "Better learning progression",
        date: "2024-02-05"
      }
    ],
    nextOptimization: "2024-02-25"
  };

  const careerAlignment = {
    targetRole: "Senior Full-Stack Engineer",
    currentMatch: 72,
    targetMatch: 95,
    salaryRange: {
      current: "80K - 100K",
      target: "120K - 150K"
    },
    topCompanies: ["Google", "Amazon", "Microsoft", "Netflix", "Uber"],
    marketTrends: [
      { skill: "Cloud Architecture", growth: "+34%", demand: "Very High" },
      { skill: "TypeScript", growth: "+28%", demand: "High" },
      { skill: "DevOps", growth: "+31%", demand: "Very High" },
      { skill: "Microservices", growth: "+25%", demand: "High" }
    ]
  };

  const learningPreferences = {
    preferredTime: "evenings",
    learningStyle: "hands-on",
    difficulty: "challenging",
    pace: "moderate",
    focusAreas: ["practical-projects", "industry-relevant", "certification-focused"]
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'High':
        return 'bg-red-100 text-red-800';
      case 'Medium':
        return 'bg-yellow-100 text-yellow-800';
      case 'Low':
        return 'bg-green-100 text-green-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'Expert':
        return 'bg-purple-100 text-purple-800';
      case 'Advanced':
        return 'bg-red-100 text-red-800';
      case 'Intermediate':
        return 'bg-yellow-100 text-yellow-800';
      case 'Beginner':
        return 'bg-green-100 text-green-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="p-8 space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">AI-Powered Learning Paths</h1>
          <p className="text-gray-600 mt-1">Personalized certification roadmaps based on your skills, goals, and market trends</p>
        </div>
        <Button className="flex items-center gap-2">
          <RefreshCw className="w-4 h-4" />
          Refresh Analysis
        </Button>
      </div>

      <Tabs defaultValue="analysis" className="space-y-6">
        <TabsList className="grid grid-cols-5 w-full max-w-3xl">
          <TabsTrigger value="analysis">Skill Analysis</TabsTrigger>
          <TabsTrigger value="pathway">Learning Path</TabsTrigger>
          <TabsTrigger value="adaptive">Adaptive Learning</TabsTrigger>
          <TabsTrigger value="career">Career Alignment</TabsTrigger>
          <TabsTrigger value="preferences">Preferences</TabsTrigger>
        </TabsList>

        <TabsContent value="analysis" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Overall Score */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Brain className="w-5 h-5 text-blue-600" />
                  Overall Skill Score
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="text-center">
                  <div className="text-4xl font-bold text-blue-600 mb-2">
                    {skillGapAnalysis.overallScore}
                  </div>
                  <Progress value={skillGapAnalysis.overallScore} className="h-3" />
                  <p className="text-sm text-gray-600 mt-2">
                    Above average for your experience level
                  </p>
                </div>
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-600">Market Relevance</span>
                    <span className="font-medium">85%</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-600">Certification Readiness</span>
                    <span className="font-medium">78%</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-600">Career Progression</span>
                    <span className="font-medium">72%</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Strengths */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <CheckCircle className="w-5 h-5 text-green-600" />
                  Your Strengths
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {skillGapAnalysis.strengths.map((strength, index) => (
                  <div key={index} className="space-y-2">
                    <div className="flex justify-between items-center">
                      <span className="font-medium text-gray-900">{strength.skill}</span>
                      <Badge className="bg-green-100 text-green-800">
                        {strength.proficiency}%
                      </Badge>
                    </div>
                    <div className="flex items-center gap-2">
                      <Progress value={strength.proficiency} className="flex-1 h-2" />
                      <span className="text-xs text-gray-500">
                        Market: {strength.marketDemand}%
                      </span>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>

            {/* Skill Gaps */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <AlertCircle className="w-5 h-5 text-orange-600" />
                  Priority Skill Gaps
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {skillGapAnalysis.gaps.map((gap, index) => (
                  <div key={index} className="space-y-2">
                    <div className="flex justify-between items-center">
                      <span className="font-medium text-gray-900">{gap.skill}</span>
                      <Badge className={getPriorityColor(gap.priority)}>
                        {gap.priority}
                      </Badge>
                    </div>
                    <div className="flex items-center gap-2">
                      <Progress value={gap.proficiency} className="flex-1 h-2" />
                      <span className="text-xs text-gray-500">
                        Need: {gap.marketDemand}%
                      </span>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>
          </div>

          {/* AI Recommendations */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Zap className="w-5 h-5 text-purple-600" />
                AI Recommendations
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {skillGapAnalysis.recommendations.map((recommendation, index) => (
                  <div key={index} className="flex items-start gap-3 p-3 bg-purple-50 rounded-lg">
                    <Brain className="w-5 h-5 text-purple-600 mt-0.5" />
                    <p className="text-sm text-gray-700">{recommendation}</p>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="pathway" className="space-y-6">
          {/* Path Overview */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <MapPin className="w-5 h-5 text-green-600" />
                Your Personalized Learning Path
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                <div className="text-center">
                  <div className="text-2xl font-bold text-green-600 mb-1">
                    {personalizedPath.totalDuration}
                  </div>
                  <div className="text-sm text-gray-600">Total Duration</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-blue-600 mb-1">
                    ${personalizedPath.estimatedCost}
                  </div>
                  <div className="text-sm text-gray-600">Investment</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-purple-600 mb-1">
                    +${personalizedPath.expectedSalaryIncrease.toLocaleString()}
                  </div>
                  <div className="text-sm text-gray-600">Expected Salary Increase</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-orange-600 mb-1">
                    {personalizedPath.jobMarketMatch}%
                  </div>
                  <div className="text-sm text-gray-600">Job Market Match</div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Learning Phases */}
          <div className="space-y-6">
            {personalizedPath.phases.map((phase, phaseIndex) => (
              <Card key={phase.id}>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle className="flex items-center gap-3">
                        <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                          <span className="text-sm font-bold text-blue-600">{phase.id}</span>
                        </div>
                        {phase.title}
                      </CardTitle>
                      <p className="text-gray-600 mt-1">{phase.description}</p>
                    </div>
                    <Badge variant="outline" className="ml-4">
                      {phase.duration}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                    {phase.certifications.map((cert, certIndex) => (
                      <div key={certIndex} className="border border-gray-200 rounded-lg p-4">
                        <div className="flex items-start justify-between mb-3">
                          <div>
                            <h4 className="font-semibold text-gray-900">{cert.name}</h4>
                            <p className="text-sm text-gray-600">{cert.provider}</p>
                          </div>
                          <Badge className={getPriorityColor(cert.priority)}>
                            {cert.priority}
                          </Badge>
                        </div>

                        <div className="space-y-2 mb-3">
                          <div className="flex justify-between text-sm">
                            <span className="text-gray-600">Duration:</span>
                            <span className="font-medium">{cert.duration}</span>
                          </div>
                          <div className="flex justify-between text-sm">
                            <span className="text-gray-600">Difficulty:</span>
                            <Badge className={getDifficultyColor(cert.difficulty)} variant="outline">
                              {cert.difficulty}
                            </Badge>
                          </div>
                        </div>

                        <div className="mb-3">
                          <span className="text-xs font-medium text-gray-700">Prerequisites:</span>
                          <div className="flex flex-wrap gap-1 mt-1">
                            {cert.prerequisites.map((prereq, prereqIndex) => (
                              <Badge key={prereqIndex} variant="outline" className="text-xs">
                                {prereq}
                              </Badge>
                            ))}
                          </div>
                        </div>

                        <Button size="sm" className="w-full">
                          <Play className="w-4 h-4 mr-2" />
                          Start Learning
                        </Button>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="adaptive" className="space-y-6">
          {/* Progress Overview */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BarChart3 className="w-5 h-5 text-blue-600" />
                Adaptive Learning Progress
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <span className="text-gray-600">Overall Progress</span>
                  <span className="font-semibold">Week {adaptiveLearning.currentWeek} of {adaptiveLearning.totalWeeks}</span>
                </div>
                <Progress value={(adaptiveLearning.currentWeek / adaptiveLearning.totalWeeks) * 100} className="h-3" />
                
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-6">
                  <div className="text-center p-4 bg-blue-50 rounded-lg">
                    <div className="text-2xl font-bold text-blue-600 mb-1">
                      {adaptiveLearning.progressScore}%
                    </div>
                    <div className="text-sm text-gray-600">Learning Efficiency</div>
                  </div>
                  <div className="text-center p-4 bg-green-50 rounded-lg">
                    <div className="text-2xl font-bold text-green-600 mb-1">
                      {adaptiveLearning.adaptations.length}
                    </div>
                    <div className="text-sm text-gray-600">AI Optimizations</div>
                  </div>
                  <div className="text-center p-4 bg-purple-50 rounded-lg">
                    <div className="text-2xl font-bold text-purple-600 mb-1">
                      +15%
                    </div>
                    <div className="text-sm text-gray-600">Retention Improvement</div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* AI Adaptations */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Zap className="w-5 h-5 text-purple-600" />
                Recent AI Adaptations
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {adaptiveLearning.adaptations.map((adaptation, index) => (
                  <div key={index} className="border border-purple-200 rounded-lg p-4">
                    <div className="flex items-start gap-3">
                      <div className="w-8 h-8 bg-purple-100 rounded-full flex items-center justify-center">
                        <Brain className="w-4 h-4 text-purple-600" />
                      </div>
                      <div className="flex-1">
                        <div className="flex items-start justify-between mb-2">
                          <h4 className="font-medium text-gray-900 capitalize">
                            {adaptation.type.replace('-', ' ')}
                          </h4>
                          <span className="text-xs text-gray-500">{adaptation.date}</span>
                        </div>
                        <p className="text-sm text-gray-700 mb-2">{adaptation.message}</p>
                        <Badge className="bg-green-100 text-green-800 text-xs">
                          {adaptation.impact}
                        </Badge>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
              <div className="mt-4 p-3 bg-blue-50 rounded-lg">
                <div className="flex items-center gap-2">
                  <Calendar className="w-4 h-4 text-blue-600" />
                  <span className="text-sm font-medium text-blue-900">
                    Next optimization scheduled for {adaptiveLearning.nextOptimization}
                  </span>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="career" className="space-y-6">
          {/* Career Goal Alignment */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Target className="w-5 h-5 text-green-600" />
                Career Goal Alignment
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div className="text-center">
                  <h3 className="text-xl font-semibold text-gray-900 mb-2">
                    {careerAlignment.targetRole}
                  </h3>
                  <div className="flex justify-center items-center gap-4 mb-4">
                    <div className="text-center">
                      <div className="text-2xl font-bold text-orange-600">
                        {careerAlignment.currentMatch}%
                      </div>
                      <div className="text-sm text-gray-600">Current Match</div>
                    </div>
                    <div className="text-2xl text-gray-400">→</div>
                    <div className="text-center">
                      <div className="text-2xl font-bold text-green-600">
                        {careerAlignment.targetMatch}%
                      </div>
                      <div className="text-sm text-gray-600">Target Match</div>
                    </div>
                  </div>
                  <Progress 
                    value={careerAlignment.currentMatch} 
                    className="h-3 mb-2" 
                  />
                  <p className="text-sm text-gray-600">
                    {careerAlignment.targetMatch - careerAlignment.currentMatch}% improvement needed
                  </p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <h4 className="font-semibold text-gray-900 mb-3">Salary Progression</h4>
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span className="text-gray-600">Current Range:</span>
                        <span className="font-medium">{careerAlignment.salaryRange.current}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-600">Target Range:</span>
                        <span className="font-medium text-green-600">{careerAlignment.salaryRange.target}</span>
                      </div>
                    </div>
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-900 mb-3">Target Companies</h4>
                    <div className="flex flex-wrap gap-2">
                      {careerAlignment.topCompanies.map((company, index) => (
                        <Badge key={index} variant="outline" className="text-xs">
                          {company}
                        </Badge>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Market Trends */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <TrendingUp className="w-5 h-5 text-blue-600" />
                Market Trends & Demand
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {careerAlignment.marketTrends.map((trend, index) => (
                  <div key={index} className="flex items-center justify-between p-3 border border-gray-200 rounded-lg">
                    <div>
                      <h4 className="font-medium text-gray-900">{trend.skill}</h4>
                      <p className="text-sm text-gray-600">Market Growth: {trend.growth}</p>
                    </div>
                    <Badge className={
                      trend.demand === 'Very High' ? 'bg-red-100 text-red-800' : 
                      trend.demand === 'High' ? 'bg-orange-100 text-orange-800' : 
                      'bg-yellow-100 text-yellow-800'
                    }>
                      {trend.demand} Demand
                    </Badge>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="preferences" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Settings className="w-5 h-5 text-gray-600" />
                Learning Preferences
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <div>
                  <label className="text-sm font-medium text-gray-700 mb-2 block">
                    Career Goal
                  </label>
                  <Select value={selectedCareerGoal} onValueChange={setSelectedCareerGoal}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select your career goal" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="senior-fullstack">Senior Full-Stack Engineer</SelectItem>
                      <SelectItem value="cloud-architect">Cloud Solutions Architect</SelectItem>
                      <SelectItem value="devops-engineer">DevOps Engineer</SelectItem>
                      <SelectItem value="tech-lead">Technical Lead</SelectItem>
                      <SelectItem value="startup-cto">Startup CTO</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <label className="text-sm font-medium text-gray-700 mb-2 block">
                    Years of Experience: {experienceLevel[0]}
                  </label>
                  <Slider
                    value={experienceLevel}
                    onValueChange={setExperienceLevel}
                    max={15}
                    min={0}
                    step={1}
                    className="w-full"
                  />
                  <div className="flex justify-between text-xs text-gray-500 mt-1">
                    <span>0 years</span>
                    <span>15+ years</span>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="text-sm font-medium text-gray-700 mb-2 block">
                      Preferred Learning Time
                    </label>
                    <Select defaultValue={learningPreferences.preferredTime}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="mornings">Mornings</SelectItem>
                        <SelectItem value="afternoons">Afternoons</SelectItem>
                        <SelectItem value="evenings">Evenings</SelectItem>
                        <SelectItem value="weekends">Weekends</SelectItem>
                        <SelectItem value="flexible">Flexible</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <label className="text-sm font-medium text-gray-700 mb-2 block">
                      Learning Style
                    </label>
                    <Select defaultValue={learningPreferences.learningStyle}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="visual">Visual Learner</SelectItem>
                        <SelectItem value="hands-on">Hands-on Practice</SelectItem>
                        <SelectItem value="theoretical">Theoretical Concepts</SelectItem>
                        <SelectItem value="mixed">Mixed Approach</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="text-sm font-medium text-gray-700 mb-2 block">
                      Preferred Difficulty
                    </label>
                    <Select defaultValue={learningPreferences.difficulty}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="gentle">Gentle Learning Curve</SelectItem>
                        <SelectItem value="moderate">Moderate Challenge</SelectItem>
                        <SelectItem value="challenging">Challenging</SelectItem>
                        <SelectItem value="intensive">Intensive Bootcamp</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <label className="text-sm font-medium text-gray-700 mb-2 block">
                      Learning Pace
                    </label>
                    <Select defaultValue={learningPreferences.pace}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="relaxed">Relaxed (5-10 hrs/week)</SelectItem>
                        <SelectItem value="moderate">Moderate (10-15 hrs/week)</SelectItem>
                        <SelectItem value="intensive">Intensive (15-25 hrs/week)</SelectItem>
                        <SelectItem value="accelerated">Accelerated (25+ hrs/week)</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </div>

              <div className="flex gap-3 pt-4">
                <Button className="flex-1">Save Preferences</Button>
                <Button variant="outline">Generate New Path</Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}

export default function AILearningPath() {
  const config = platformConfigs.candidate;
  const theme = useThemeClasses('candidate');
  
  const usageData = [
    { label: "Learning Progress", current: 68, max: 100 },
    { label: "Skills Analyzed", current: 15, max: 25 },
    { label: "Path Completion", current: 3, max: 8 },
  ];

  return (
    <PlatformLayout
      sidebarTitle={config.sidebarTitle}
      sidebarSubtitle={config.sidebarSubtitle}
      sidebarSections={config.sidebarSections}
      usageData={usageData}
    >
      <AILearningPathContent />
    </PlatformLayout>
  );
}