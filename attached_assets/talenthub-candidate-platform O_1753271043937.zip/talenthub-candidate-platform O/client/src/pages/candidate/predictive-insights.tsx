import PlatformLayout from "@/components/layout/platform-layout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Sparkles, Target, TrendingUp, Zap, Brain, Star, ArrowUp, ArrowDown } from "lucide-react";
import { candidateNavigation } from "@/config/complete-navigation";

export default function PredictiveInsights() {
  const predictionMetrics = [
    { label: "Career Growth Probability", value: "87%", change: 5, color: "bg-blue-500", icon: TrendingUp },
    { label: "Next Promotion Timeline", value: "8 months", change: -2, color: "bg-green-500", icon: Target },
    { label: "Skill Relevance Score", value: "92%", change: 8, color: "bg-purple-500", icon: Brain },
    { label: "Market Fit Rating", value: "94%", change: 12, color: "bg-orange-500", icon: Star }
  ];

  const careerPredictions = [
    {
      title: "Senior Frontend Developer",
      probability: 89,
      timeline: "6-8 months",
      requirements: ["Advanced React", "Team Leadership", "System Architecture"],
      salaryIncrease: "25-35%",
      confidence: "High"
    },
    {
      title: "Full Stack Tech Lead",
      probability: 78,
      timeline: "12-15 months",
      requirements: ["Backend Expertise", "DevOps Skills", "Project Management"],
      salaryIncrease: "35-45%",
      confidence: "Medium"
    },
    {
      title: "Engineering Manager",
      probability: 65,
      timeline: "18-24 months",
      requirements: ["Leadership Experience", "Strategic Thinking", "People Management"],
      salaryIncrease: "40-55%",
      confidence: "Medium"
    }
  ];

  const skillPredictions = [
    { skill: "TypeScript", currentLevel: 78, predictedLevel: 95, importance: "Critical", trend: "Rising" },
    { skill: "AWS", currentLevel: 65, predictedLevel: 88, importance: "High", trend: "Stable" },
    { skill: "System Design", currentLevel: 45, predictedLevel: 75, importance: "Critical", trend: "Rising" },
    { skill: "GraphQL", currentLevel: 32, predictedLevel: 70, importance: "Medium", trend: "Emerging" }
  ];

  const marketPredictions = [
    {
      insight: "Remote Work Demand",
      prediction: "Remote positions will increase by 35% in your field over the next year",
      impact: "Positive",
      confidence: 92,
      timeframe: "Next 12 months"
    },
    {
      insight: "AI/ML Integration",
      prediction: "Frontend roles will increasingly require AI integration skills",
      impact: "High Impact",
      confidence: 85,
      timeframe: "Next 18 months"
    },
    {
      insight: "Salary Growth",
      prediction: "Your role's median salary expected to grow 15% annually",
      impact: "Positive",
      confidence: 88,
      timeframe: "Next 24 months"
    }
  ];

  const recommendations = [
    {
      type: "Skill Development",
      priority: "High",
      action: "Focus on System Design patterns and scalability",
      impact: "Unlocks senior-level opportunities",
      timeframe: "3-6 months"
    },
    {
      type: "Certification",
      priority: "Medium",
      action: "Complete AWS Solutions Architect Associate",
      impact: "25% salary increase potential",
      timeframe: "2-4 months"
    },
    {
      type: "Networking",
      priority: "High",
      action: "Connect with 3 engineering managers monthly",
      impact: "Higher promotion likelihood",
      timeframe: "Ongoing"
    }
  ];

  return (
    <PlatformLayout 
      sidebarTitle="Candidate Platform"
      sidebarSubtitle="Professional Development Hub"
      sidebarSections={candidateNavigation}
    >
      <div className="max-w-7xl mx-auto p-6 space-y-8">
        <div className="text-center space-y-4">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-violet-100 to-purple-100 rounded-full">
            <Sparkles className="h-5 w-5 text-violet-600" />
            <span className="text-sm font-medium text-violet-900">Predictive Career Insights</span>
          </div>
          <h1 className="text-4xl font-bold bg-gradient-to-r from-violet-600 to-purple-600 bg-clip-text text-transparent">
            AI-Powered Career Predictions
          </h1>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            Leverage advanced analytics to predict career trajectories, skill demands, and market opportunities
          </p>
        </div>

        {/* Prediction Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {predictionMetrics.map((metric, index) => {
            const IconComponent = metric.icon;
            return (
              <Card key={index} className="hover:shadow-md transition-shadow">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between mb-4">
                    <div className={`p-3 rounded-lg ${metric.color} text-white`}>
                      <IconComponent className="h-6 w-6" />
                    </div>
                    <div className={`flex items-center gap-1 px-2 py-1 rounded-full text-sm ${
                      Number(metric.change) > 0 ? 'bg-emerald-100 text-emerald-700' : 'bg-red-100 text-red-700'
                    }`}>
                      {Number(metric.change) > 0 ? <ArrowUp className="h-3 w-3" /> : <ArrowDown className="h-3 w-3" />}
                      {Math.abs(Number(metric.change))}%
                    </div>
                  </div>
                  <div className="text-2xl font-bold text-gray-900 mb-1">{metric.value}</div>
                  <div className="text-sm text-gray-600">{metric.label}</div>
                </CardContent>
              </Card>
            );
          })}
        </div>

        <Tabs defaultValue="career" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="career">Career Paths</TabsTrigger>
            <TabsTrigger value="skills">Skill Predictions</TabsTrigger>
            <TabsTrigger value="market">Market Trends</TabsTrigger>
            <TabsTrigger value="recommendations">Recommendations</TabsTrigger>
          </TabsList>

          <TabsContent value="career" className="space-y-6">
            <div className="grid gap-6">
              {careerPredictions.map((prediction, index) => (
                <Card key={index} className="hover:shadow-md transition-shadow">
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div className="space-y-2">
                        <CardTitle className="text-lg">{prediction.title}</CardTitle>
                        <CardDescription>Predicted career progression opportunity</CardDescription>
                      </div>
                      <div className="text-right space-y-2">
                        <Badge variant={prediction.confidence === 'High' ? 'default' : 'secondary'}>
                          {prediction.confidence} Confidence
                        </Badge>
                        <div className="text-2xl font-bold text-violet-600">{prediction.probability}%</div>
                      </div>
                    </div>
                  </CardHeader>

                  <CardContent className="space-y-4">
                    <Progress value={prediction.probability} className="h-3" />
                    
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <div className="text-sm font-medium text-gray-900">Timeline</div>
                        <div className="text-sm text-gray-600">{prediction.timeline}</div>
                      </div>
                      <div>
                        <div className="text-sm font-medium text-gray-900">Salary Increase</div>
                        <div className="text-sm text-green-600 font-medium">{prediction.salaryIncrease}</div>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <div className="text-sm font-medium text-gray-900">Key Requirements</div>
                      <div className="flex flex-wrap gap-2">
                        {prediction.requirements.map((req, index) => (
                          <Badge key={index} variant="secondary" className="text-xs">
                            {req}
                          </Badge>
                        ))}
                      </div>
                    </div>

                    <div className="flex justify-end pt-2">
                      <Button size="sm" className="bg-gradient-to-r from-violet-600 to-purple-600 hover:from-violet-700 hover:to-purple-700">
                        View Action Plan
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="skills" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Skill Development Predictions</CardTitle>
                <CardDescription>AI predictions for skill importance and your development trajectory</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  {skillPredictions.map((skill, index) => (
                    <div key={index} className="space-y-3">
                      <div className="flex items-center justify-between">
                        <span className="font-medium text-gray-900">{skill.skill}</span>
                        <div className="flex items-center gap-2">
                          <Badge variant={skill.importance === 'Critical' ? 'destructive' : skill.importance === 'High' ? 'default' : 'secondary'}>
                            {skill.importance}
                          </Badge>
                          <Badge variant="outline">{skill.trend}</Badge>
                        </div>
                      </div>
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <div className="text-sm text-gray-600 mb-1">Current Level</div>
                          <Progress value={skill.currentLevel} className="h-2" />
                          <div className="text-xs text-gray-500 mt-1">{skill.currentLevel}%</div>
                        </div>
                        <div>
                          <div className="text-sm text-gray-600 mb-1">Predicted Level (12 months)</div>
                          <Progress value={skill.predictedLevel} className="h-2" />
                          <div className="text-xs text-gray-500 mt-1">{skill.predictedLevel}%</div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="market" className="space-y-6">
            <div className="grid gap-6">
              {marketPredictions.map((prediction, index) => (
                <Card key={index} className="hover:shadow-md transition-shadow">
                  <CardContent className="p-6">
                    <div className="flex items-start justify-between mb-4">
                      <div className="space-y-2">
                        <div className="font-semibold text-lg text-gray-900">{prediction.insight}</div>
                        <p className="text-sm text-gray-600">{prediction.prediction}</p>
                      </div>
                      <div className="text-right space-y-1">
                        <Badge variant={prediction.impact === 'Positive' ? 'default' : prediction.impact === 'High Impact' ? 'destructive' : 'secondary'}>
                          {prediction.impact}
                        </Badge>
                        <div className="text-sm text-gray-500">{prediction.confidence}% confidence</div>
                      </div>
                    </div>
                    
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-gray-600">{prediction.timeframe}</span>
                      <Progress value={prediction.confidence} className="w-24 h-2" />
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="recommendations" className="space-y-6">
            <div className="grid gap-6">
              {recommendations.map((rec, index) => (
                <Card key={index} className="hover:shadow-md transition-shadow">
                  <CardContent className="p-6">
                    <div className="flex items-start justify-between mb-4">
                      <div className="space-y-2">
                        <div className="flex items-center gap-2">
                          <div className="font-semibold text-lg text-gray-900">{rec.type}</div>
                          <Badge variant={rec.priority === 'High' ? 'destructive' : 'secondary'}>
                            {rec.priority} Priority
                          </Badge>
                        </div>
                        <p className="text-sm text-gray-600">{rec.action}</p>
                      </div>
                      <div className="text-right space-y-1">
                        <div className="text-sm font-medium text-violet-600">{rec.timeframe}</div>
                      </div>
                    </div>
                    
                    <div className="space-y-2">
                      <div className="text-sm font-medium text-gray-900">Expected Impact</div>
                      <p className="text-sm text-green-600">{rec.impact}</p>
                    </div>

                    <div className="flex justify-end pt-4">
                      <Button size="sm" className="bg-gradient-to-r from-violet-600 to-purple-600 hover:from-violet-700 hover:to-purple-700">
                        Start Action
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </PlatformLayout>
  );
}