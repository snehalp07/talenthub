import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import PlatformLayout from "@/components/layout/platform-layout";
import { candidateNavigation } from "@/config/complete-navigation";
import { 
  Lightbulb, Target, Brain, Star, Clock, TrendingUp,
  CheckCircle, Play, BookOpen, Users, Calendar,
  Award, Zap, ArrowRight, Activity, Code, MessageSquare
} from "lucide-react";

const PersonalizedPrep: React.FC = () => {
  const [selectedPlan, setSelectedPlan] = useState('weekly');

  const aiRecommendations = {
    priority: [
      {
        skill: 'System Design',
        urgency: 'High',
        reason: 'Upcoming senior role interviews',
        currentLevel: 65,
        targetLevel: 80,
        timeframe: '3 weeks',
        tasks: ['Database scaling patterns', 'Load balancer design', 'Microservices architecture'],
        estimatedHours: 24
      },
      {
        skill: 'React Performance',
        urgency: 'Medium',
        reason: 'Weak area in recent interviews',
        currentLevel: 72,
        targetLevel: 85,
        timeframe: '2 weeks',
        tasks: ['Memo optimization', 'Bundle analysis', 'Code splitting'],
        estimatedHours: 16
      },
      {
        skill: 'Behavioral Responses',
        urgency: 'Medium',
        reason: 'STAR method improvement needed',
        currentLevel: 78,
        targetLevel: 88,
        timeframe: '1 week',
        tasks: ['Leadership examples', 'Conflict resolution', 'Team scenarios'],
        estimatedHours: 8
      }
    ]
  };

  const learningPlans = {
    weekly: {
      name: '1-Week Sprint',
      focus: 'Quick wins for immediate interviews',
      schedule: [
        { day: 'Monday', focus: 'System Design Basics', duration: '2 hours', tasks: ['Database design patterns', 'API architecture'] },
        { day: 'Tuesday', focus: 'React Performance', duration: '1.5 hours', tasks: ['Memo and callbacks', 'Profiling tools'] },
        { day: 'Wednesday', focus: 'Behavioral Practice', duration: '1 hour', tasks: ['STAR method drills', 'Leadership examples'] },
        { day: 'Thursday', focus: 'Mock Interview', duration: '2 hours', tasks: ['Full technical interview', 'Feedback analysis'] },
        { day: 'Friday', focus: 'Algorithm Review', duration: '1.5 hours', tasks: ['Dynamic programming', 'Tree algorithms'] },
        { day: 'Weekend', focus: 'Project Portfolio', duration: '3 hours', tasks: ['Update GitHub', 'Document projects'] }
      ]
    },
    biweekly: {
      name: '2-Week Deep Dive',
      focus: 'Comprehensive skill building',
      schedule: [
        { day: 'Week 1', focus: 'System Design Mastery', duration: '12 hours', tasks: ['Scalability patterns', 'Database sharding', 'Caching strategies'] },
        { day: 'Week 2', focus: 'Interview Excellence', duration: '10 hours', tasks: ['Mock interviews', 'Behavioral mastery', 'Technical communication'] }
      ]
    },
    monthly: {
      name: '4-Week Transformation',
      focus: 'Complete interview readiness',
      schedule: [
        { day: 'Week 1-2', focus: 'Technical Foundation', duration: '20 hours', tasks: ['System design', 'Algorithm mastery', 'Framework expertise'] },
        { day: 'Week 3-4', focus: 'Interview Mastery', duration: '16 hours', tasks: ['Mock interviews', 'Behavioral excellence', 'Presentation skills'] }
      ]
    }
  };

  const adaptiveLearning = [
    {
      trigger: 'Failed System Design Question',
      adaptation: 'Added 5 extra system design sessions',
      impact: '+15% system design score improvement',
      timeAdjustment: '+3 hours/week'
    },
    {
      trigger: 'Strong Algorithm Performance',
      adaptation: 'Reduced algorithm practice, increased behavioral focus',
      impact: '+12% overall interview performance',
      timeAdjustment: '-2 hours/week on algorithms'
    },
    {
      trigger: 'Communication Feedback',
      adaptation: 'Added technical explanation exercises',
      impact: '+20% communication score',
      timeAdjustment: '+1 hour/week presentation practice'
    }
  ];

  const personalizedResources = [
    {
      category: 'System Design',
      resources: [
        { name: 'Designing Data-Intensive Applications', type: 'Book', priority: 'High', progress: 35 },
        { name: 'System Design Interview Course', type: 'Video', priority: 'High', progress: 60 },
        { name: 'AWS Architecture Center', type: 'Documentation', priority: 'Medium', progress: 20 }
      ]
    },
    {
      category: 'React Performance',
      resources: [
        { name: 'React Performance Patterns', type: 'Tutorial', priority: 'High', progress: 80 },
        { name: 'Web Vitals Optimization', type: 'Guide', priority: 'Medium', progress: 45 },
        { name: 'React DevTools Profiler', type: 'Tool', priority: 'High', progress: 25 }
      ]
    },
    {
      category: 'Behavioral Skills',
      resources: [
        { name: 'STAR Method Masterclass', type: 'Course', priority: 'High', progress: 70 },
        { name: 'Leadership Stories Bank', type: 'Templates', priority: 'Medium', progress: 90 },
        { name: 'Conflict Resolution Examples', type: 'Case Studies', priority: 'Medium', progress: 55 }
      ]
    }
  ];

  const progressTracking = {
    weeklyGoals: [
      { goal: 'Complete 5 system design problems', progress: 3, target: 5, status: 'on-track' },
      { goal: 'Practice 3 behavioral scenarios', progress: 2, target: 3, status: 'on-track' },
      { goal: 'Optimize React app performance', progress: 1, target: 1, status: 'completed' },
      { goal: 'Mock interview sessions', progress: 1, target: 2, status: 'behind' }
    ],
    streakData: {
      current: 12,
      longest: 18,
      weeklyTarget: 5
    }
  };

  const selectedPlanData = learningPlans[selectedPlan as keyof typeof learningPlans];

  return (
    <PlatformLayout
      sidebarTitle="Candidate Platform"
      sidebarSubtitle="Interview Preparation"
      sidebarSections={candidateNavigation}
    >
      <div className="min-h-screen bg-gradient-to-br from-orange-50 via-white to-yellow-50 p-6">
        <div className="max-w-7xl mx-auto space-y-8">
          {/* Header */}
          <div className="text-center space-y-4">
            <div className="inline-flex items-center space-x-2 bg-orange-100 text-orange-800 px-4 py-2 rounded-full text-sm font-medium">
              <Lightbulb className="h-4 w-4" />
              <span>AI-Powered Personalized Interview Preparation</span>
            </div>
            <h1 className="text-4xl font-bold text-gray-900">
              Your Personalized Prep Plan
            </h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              AI-curated interview preparation tailored to your skill gaps, career goals, 
              and upcoming interviews with adaptive learning and real-time adjustments.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Main Content */}
            <div className="lg:col-span-2 space-y-6">
              {/* AI Priority Recommendations */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Brain className="h-5 w-5" />
                    <span>AI Priority Recommendations</span>
                  </CardTitle>
                  <CardDescription>Based on your performance history and upcoming interviews</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-6">
                    {aiRecommendations.priority.map((rec, index) => (
                      <div key={index} className="p-4 border rounded-lg">
                        <div className="flex items-center justify-between mb-3">
                          <h3 className="font-semibold text-lg">{rec.skill}</h3>
                          <Badge variant={
                            rec.urgency === 'High' ? 'destructive' :
                            rec.urgency === 'Medium' ? 'default' : 'secondary'
                          }>
                            {rec.urgency} Priority
                          </Badge>
                        </div>
                        
                        <div className="text-sm text-gray-600 mb-3">{rec.reason}</div>
                        
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
                          <div className="text-center">
                            <div className="text-lg font-bold text-blue-600">{rec.currentLevel}%</div>
                            <div className="text-xs text-gray-500">Current</div>
                          </div>
                          <div className="text-center">
                            <div className="text-lg font-bold text-green-600">{rec.targetLevel}%</div>
                            <div className="text-xs text-gray-500">Target</div>
                          </div>
                          <div className="text-center">
                            <div className="text-lg font-bold text-purple-600">{rec.timeframe}</div>
                            <div className="text-xs text-gray-500">Timeline</div>
                          </div>
                          <div className="text-center">
                            <div className="text-lg font-bold text-orange-600">{rec.estimatedHours}h</div>
                            <div className="text-xs text-gray-500">Est. Time</div>
                          </div>
                        </div>

                        <div className="mb-4">
                          <div className="flex justify-between text-sm mb-1">
                            <span>Progress to Target</span>
                            <span>{rec.currentLevel}% / {rec.targetLevel}%</span>
                          </div>
                          <Progress value={(rec.currentLevel / rec.targetLevel) * 100} className="h-2" />
                        </div>

                        <div className="mb-4">
                          <span className="font-medium text-blue-700">Focus Areas:</span>
                          <div className="flex flex-wrap gap-1 mt-1">
                            {rec.tasks.map((task, i) => (
                              <Badge key={i} variant="secondary" className="text-xs">
                                {task}
                              </Badge>
                            ))}
                          </div>
                        </div>

                        <Button variant="outline" className="w-full">
                          <Play className="h-4 w-4 mr-2" />
                          Start {rec.skill} Practice
                        </Button>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* Personalized Learning Plans */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Calendar className="h-5 w-5" />
                    <span>Adaptive Learning Schedule</span>
                  </CardTitle>
                  <CardDescription>Choose your preparation timeline</CardDescription>
                </CardHeader>
                <CardContent>
                  <Tabs value={selectedPlan} onValueChange={setSelectedPlan} className="space-y-4">
                    <div className="grid grid-cols-3 gap-4">
                      {Object.entries(learningPlans).map(([key, plan]) => (
                        <Card 
                          key={key}
                          className={`cursor-pointer transition-all duration-300 border-2 ${
                            selectedPlan === key 
                              ? 'border-orange-500 shadow-lg' 
                              : 'border-gray-200 hover:border-orange-300'
                          }`}
                          onClick={() => setSelectedPlan(key)}
                        >
                          <CardContent className="p-4 text-center">
                            <h3 className="font-semibold">{plan.name}</h3>
                            <p className="text-sm text-gray-600 mt-1">{plan.focus}</p>
                          </CardContent>
                        </Card>
                      ))}
                    </div>

                    <Card>
                      <CardHeader>
                        <CardTitle>{selectedPlanData.name}</CardTitle>
                        <CardDescription>{selectedPlanData.focus}</CardDescription>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-4">
                          {selectedPlanData.schedule.map((item: any, index: number) => (
                            <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                              <div className="flex-1">
                                <div className="font-medium">{item.day}</div>
                                <div className="text-sm text-gray-600">{item.focus}</div>
                                <div className="flex flex-wrap gap-1 mt-1">
                                  {item.tasks.map((task: any, i: number) => (
                                    <Badge key={i} variant="outline" className="text-xs">
                                      {task}
                                    </Badge>
                                  ))}
                                </div>
                              </div>
                              <div className="text-right">
                                <div className="font-medium text-blue-600">{item.duration}</div>
                                <Button variant="ghost" size="sm" className="mt-1">
                                  <ArrowRight className="h-3 w-3" />
                                </Button>
                              </div>
                            </div>
                          ))}
                        </div>
                      </CardContent>
                    </Card>
                  </Tabs>
                </CardContent>
              </Card>

              {/* Adaptive Learning Insights */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Activity className="h-5 w-5" />
                    <span>AI Learning Adaptations</span>
                  </CardTitle>
                  <CardDescription>How your plan adapts based on performance</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {adaptiveLearning.map((adaptation, index) => (
                      <div key={index} className="p-4 bg-blue-50 rounded-lg">
                        <div className="flex items-center justify-between mb-2">
                          <span className="font-medium">Trigger: {adaptation.trigger}</span>
                          <Badge variant="secondary">{adaptation.timeAdjustment}</Badge>
                        </div>
                        <div className="text-sm text-gray-700 mb-2">{adaptation.adaptation}</div>
                        <div className="text-sm text-green-600 font-medium">{adaptation.impact}</div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Sidebar */}
            <div className="space-y-6">
              {/* Progress Tracking */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Target className="h-5 w-5" />
                    <span>This Week's Goals</span>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {progressTracking.weeklyGoals.map((goal, index) => (
                    <div key={index} className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-medium">{goal.goal}</span>
                        <Badge variant={
                          goal.status === 'completed' ? 'default' :
                          goal.status === 'on-track' ? 'secondary' : 'destructive'
                        }>
                          {goal.status}
                        </Badge>
                      </div>
                      <div className="flex justify-between text-xs text-gray-500">
                        <span>{goal.progress} / {goal.target}</span>
                        <span>{Math.round((goal.progress / goal.target) * 100)}%</span>
                      </div>
                      <Progress value={(goal.progress / goal.target) * 100} className="h-1.5" />
                    </div>
                  ))}
                </CardContent>
              </Card>

              {/* Learning Streak */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Zap className="h-5 w-5" />
                    <span>Learning Streak</span>
                  </CardTitle>
                </CardHeader>
                <CardContent className="text-center">
                  <div className="text-3xl font-bold text-orange-600 mb-2">
                    {progressTracking.streakData.current}
                  </div>
                  <div className="text-sm text-gray-600 mb-4">Days Current Streak</div>
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <div className="font-medium">Longest</div>
                      <div>{progressTracking.streakData.longest} days</div>
                    </div>
                    <div>
                      <div className="font-medium">Weekly Target</div>
                      <div>{progressTracking.streakData.weeklyTarget} days</div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Personalized Resources */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <BookOpen className="h-5 w-5" />
                    <span>Your Resources</span>
                  </CardTitle>
                  <CardDescription>Curated for your goals</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  {personalizedResources.map((category, index) => (
                    <div key={index}>
                      <h3 className="font-medium text-sm mb-2">{category.category}</h3>
                      <div className="space-y-2">
                        {category.resources.slice(0, 2).map((resource, i) => (
                          <div key={i} className="p-2 bg-gray-50 rounded">
                            <div className="flex items-center justify-between mb-1">
                              <span className="text-xs font-medium">{resource.name}</span>
                              <Badge variant="outline" className="text-xs">{resource.type}</Badge>
                            </div>
                            <Progress value={resource.progress} className="h-1" />
                            <div className="text-xs text-gray-500 mt-1">{resource.progress}% complete</div>
                          </div>
                        ))}
                      </div>
                    </div>
                  ))}
                </CardContent>
              </Card>

              {/* Action Buttons */}
              <div className="space-y-3">
                <Button size="lg" className="w-full bg-gradient-to-r from-orange-600 to-yellow-600 hover:from-orange-700 hover:to-yellow-700">
                  <Play className="h-4 w-4 mr-2" />
                  Start Today's Plan
                </Button>
                <Button variant="outline" size="lg" className="w-full">
                  <Calendar className="h-4 w-4 mr-2" />
                  Schedule Sessions
                </Button>
                <Button variant="outline" size="lg" className="w-full">
                  <Target className="h-4 w-4 mr-2" />
                  Adjust Goals
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </PlatformLayout>
  );
};

export default PersonalizedPrep;