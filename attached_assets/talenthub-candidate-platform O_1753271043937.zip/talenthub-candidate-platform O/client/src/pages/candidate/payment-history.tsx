import { useState } from "react";
import PlatformLayout from "@/components/layout/platform-layout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { CreditCard, Download, Receipt, Calendar, TrendingUp, DollarSign, CheckCircle, AlertCircle, Clock } from "lucide-react";
import { candidateNavigation } from "@/config/complete-navigation";

export default function PaymentHistory() {
  const [selectedPeriod, setSelectedPeriod] = useState("all");

  const payments = [
    {
      id: "PAY-2024-001",
      date: "2024-12-20",
      type: "Test Booking",
      description: "JavaScript Certification Test",
      amount: 149.00,
      status: "Completed",
      method: "Credit Card ****1234",
      invoice: "INV-2024-1234"
    },
    {
      id: "PAY-2024-002",
      date: "2024-12-15",
      type: "Premium Features",
      description: "AI Resume Analysis & Optimization",
      amount: 29.99,
      status: "Completed",
      method: "PayPal",
      invoice: "INV-2024-1235"
    },
    {
      id: "PAY-2024-003",
      date: "2024-12-10",
      type: "Certification",
      description: "React Advanced Certification",
      amount: 199.00,
      status: "Completed",
      method: "Credit Card ****5678",
      invoice: "INV-2024-1236"
    },
    {
      id: "PAY-2024-004",
      date: "2024-12-08",
      type: "Test Booking",
      description: "Full-Stack Developer Assessment",
      amount: 299.00,
      status: "Pending",
      method: "Bank Transfer",
      invoice: "INV-2024-1237"
    },
    {
      id: "PAY-2024-005",
      date: "2024-11-28",
      type: "Subscription",
      description: "Professional Plan - Monthly",
      amount: 49.99,
      status: "Completed",
      method: "Credit Card ****1234",
      invoice: "INV-2024-1238"
    }
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case "Completed": return "bg-green-100 text-green-800";
      case "Pending": return "bg-yellow-100 text-yellow-800";
      case "Failed": return "bg-red-100 text-red-800";
      case "Refunded": return "bg-blue-100 text-blue-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "Completed": return <CheckCircle className="h-4 w-4 text-green-600" />;
      case "Pending": return <Clock className="h-4 w-4 text-yellow-600" />;
      case "Failed": return <AlertCircle className="h-4 w-4 text-red-600" />;
      case "Refunded": return <TrendingUp className="h-4 w-4 text-blue-600" />;
      default: return <Clock className="h-4 w-4 text-gray-600" />;
    }
  };

  const totalSpent = payments.filter(p => p.status === "Completed").reduce((sum, p) => sum + p.amount, 0);
  const pendingAmount = payments.filter(p => p.status === "Pending").reduce((sum, p) => sum + p.amount, 0);

  return (
    <PlatformLayout
      sidebarTitle="Candidate Platform"
      sidebarSubtitle="Your Professional Journey"
      sidebarSections={candidateNavigation}
    >
      <div className="min-h-screen bg-gradient-to-br from-green-50 via-white to-emerald-50 p-6">
        <div className="max-w-6xl mx-auto">
          {/* Header */}
          <div className="mb-8">
            <div className="flex items-center gap-3 mb-4">
              <div className="bg-green-600 p-2 rounded-lg">
                <CreditCard className="h-6 w-6 text-white" />
              </div>
              <div>
                <h1 className="text-3xl font-bold bg-gradient-to-r from-green-600 to-emerald-600 bg-clip-text text-transparent">
                  Payment History
                </h1>
                <p className="text-gray-600">Track your payments, invoices, and subscription charges</p>
              </div>
            </div>
          </div>

          {/* Stats Cards */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
            <Card className="bg-gradient-to-br from-green-500 to-green-600 text-white">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-green-100">Total Spent</p>
                    <p className="text-2xl font-bold">${totalSpent.toFixed(2)}</p>
                  </div>
                  <DollarSign className="h-8 w-8 text-green-200" />
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-br from-yellow-500 to-yellow-600 text-white">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-yellow-100">Pending</p>
                    <p className="text-2xl font-bold">${pendingAmount.toFixed(2)}</p>
                  </div>
                  <Clock className="h-8 w-8 text-yellow-200" />
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-br from-blue-500 to-blue-600 text-white">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-blue-100">Transactions</p>
                    <p className="text-2xl font-bold">{payments.length}</p>
                  </div>
                  <Receipt className="h-8 w-8 text-blue-200" />
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-br from-purple-500 to-purple-600 text-white">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-purple-100">This Month</p>
                    <p className="text-2xl font-bold">$477.99</p>
                  </div>
                  <TrendingUp className="h-8 w-8 text-purple-200" />
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Filters */}
          <Card className="mb-8 bg-gradient-to-r from-green-50 to-emerald-50 border-green-200">
            <CardHeader>
              <CardTitle className="text-green-800">Filter Payments</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex flex-wrap gap-4">
                <Button 
                  variant={selectedPeriod === "all" ? "default" : "outline"}
                  onClick={() => setSelectedPeriod("all")}
                  className={selectedPeriod === "all" ? "bg-green-600 hover:bg-green-700" : "border-green-200 text-green-700 hover:bg-green-50"}
                >
                  All Time
                </Button>
                <Button 
                  variant={selectedPeriod === "month" ? "default" : "outline"}
                  onClick={() => setSelectedPeriod("month")}
                  className={selectedPeriod === "month" ? "bg-green-600 hover:bg-green-700" : "border-green-200 text-green-700 hover:bg-green-50"}
                >
                  This Month
                </Button>
                <Button 
                  variant={selectedPeriod === "quarter" ? "default" : "outline"}
                  onClick={() => setSelectedPeriod("quarter")}
                  className={selectedPeriod === "quarter" ? "bg-green-600 hover:bg-green-700" : "border-green-200 text-green-700 hover:bg-green-50"}
                >
                  Last 3 Months
                </Button>
                <Button 
                  variant={selectedPeriod === "year" ? "default" : "outline"}
                  onClick={() => setSelectedPeriod("year")}
                  className={selectedPeriod === "year" ? "bg-green-600 hover:bg-green-700" : "border-green-200 text-green-700 hover:bg-green-50"}
                >
                  This Year
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Payment History Table */}
          <Card className="mb-8">
            <CardHeader>
              <div className="flex justify-between items-center">
                <div>
                  <CardTitle className="text-gray-800">Payment Transactions</CardTitle>
                  <CardDescription>Complete history of your payments and charges</CardDescription>
                </div>
                <Button 
                  variant="outline" 
                  className="border-green-200 text-green-700 hover:bg-green-50"
                >
                  <Download className="h-4 w-4 mr-2" />
                  Export CSV
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Payment ID</TableHead>
                    <TableHead>Date</TableHead>
                    <TableHead>Type</TableHead>
                    <TableHead>Description</TableHead>
                    <TableHead>Amount</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Method</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {payments.map((payment) => (
                    <TableRow key={payment.id} className="hover:bg-green-50/50">
                      <TableCell className="font-medium text-green-700">{payment.id}</TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <Calendar className="h-4 w-4 text-gray-500" />
                          {payment.date}
                        </div>
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline" className="bg-blue-50 text-blue-700">
                          {payment.type}
                        </Badge>
                      </TableCell>
                      <TableCell className="max-w-xs truncate">{payment.description}</TableCell>
                      <TableCell className="font-semibold text-green-600">
                        ${payment.amount.toFixed(2)}
                      </TableCell>
                      <TableCell>
                        <Badge className={getStatusColor(payment.status)}>
                          {getStatusIcon(payment.status)}
                          <span className="ml-1">{payment.status}</span>
                        </Badge>
                      </TableCell>
                      <TableCell className="text-sm text-gray-600">{payment.method}</TableCell>
                      <TableCell>
                        <div className="flex gap-2">
                          <Button 
                            size="sm" 
                            variant="outline"
                            className="border-green-200 text-green-700 hover:bg-green-50"
                          >
                            <Receipt className="h-3 w-3 mr-1" />
                            Invoice
                          </Button>
                          <Button 
                            size="sm" 
                            variant="outline"
                            className="border-blue-200 text-blue-700 hover:bg-blue-50"
                          >
                            <Download className="h-3 w-3 mr-1" />
                            Receipt
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>

          {/* Payment Methods & Billing Info */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <Card className="bg-gradient-to-r from-green-50 to-emerald-50 border-green-200">
              <CardHeader>
                <CardTitle className="text-green-800 flex items-center gap-2">
                  <CreditCard className="h-5 w-5" />
                  Payment Methods
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between p-4 bg-white rounded-lg border border-green-200">
                    <div className="flex items-center gap-3">
                      <div className="bg-green-100 p-2 rounded">
                        <CreditCard className="h-4 w-4 text-green-600" />
                      </div>
                      <div>
                        <p className="font-medium">Visa ****1234</p>
                        <p className="text-sm text-gray-600">Expires 12/26</p>
                      </div>
                    </div>
                    <Badge className="bg-green-100 text-green-800">Primary</Badge>
                  </div>
                  
                  <div className="flex items-center justify-between p-4 bg-white rounded-lg border border-gray-200">
                    <div className="flex items-center gap-3">
                      <div className="bg-blue-100 p-2 rounded">
                        <CreditCard className="h-4 w-4 text-blue-600" />
                      </div>
                      <div>
                        <p className="font-medium">PayPal Account</p>
                        <p className="text-sm text-gray-600">john.doe@email.com</p>
                      </div>
                    </div>
                    <Badge variant="outline">Backup</Badge>
                  </div>
                </div>
                
                <Button className="w-full mt-4 bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700">
                  Add Payment Method
                </Button>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-r from-blue-50 to-indigo-50 border-blue-200">
              <CardHeader>
                <CardTitle className="text-blue-800">Billing Information</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <h4 className="font-semibold text-gray-800 mb-2">Billing Address</h4>
                    <div className="text-sm text-gray-600 space-y-1">
                      <p>John Doe</p>
                      <p>123 Professional Street</p>
                      <p>Tech City, TC 12345</p>
                      <p>United States</p>
                    </div>
                  </div>
                  
                  <div>
                    <h4 className="font-semibold text-gray-800 mb-2">Tax Information</h4>
                    <div className="text-sm text-gray-600 space-y-1">
                      <p>Tax ID: Not provided</p>
                      <p>VAT Number: Not applicable</p>
                      <p>Tax Rate: 8.25% (Local sales tax)</p>
                    </div>
                  </div>
                </div>
                
                <Button 
                  variant="outline" 
                  className="w-full mt-4 border-blue-200 text-blue-700 hover:bg-blue-50"
                >
                  Update Billing Info
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </PlatformLayout>
  );
}