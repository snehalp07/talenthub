import PlatformLayout from "@/components/layout/platform-layout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Trophy, Search, Download, Share, Eye, Star, Calendar, CheckCircle, Award, Globe, Code, Database, Smartphone } from "lucide-react";
import { platformConfigs } from "@/config/complete-navigation";

export default function CertificateGallery() {
  const config = platformConfigs.candidate;

  const certificates = [
    {
      id: 1,
      title: "Frontend Developer Certification",
      issuer: "TalentHub Academy",
      issuedDate: "2024-02-15",
      expiryDate: "2026-02-15",
      credentialId: "TH-FE-2024-001234",
      skills: ["React", "TypeScript", "CSS", "JavaScript"],
      category: "Frontend",
      level: "Advanced",
      verificationUrl: "https://verify.talenthub.com/cert/TH-FE-2024-001234",
      status: "active",
      color: "from-blue-500 to-indigo-500",
      icon: Globe,
      description: "Comprehensive frontend development certification covering modern React, TypeScript, and advanced UI/UX patterns."
    },
    {
      id: 2,
      title: "React Mastery Certificate",
      issuer: "TalentHub Academy",
      issuedDate: "2024-01-20",
      expiryDate: "2026-01-20",
      credentialId: "TH-RC-2024-005678",
      skills: ["React", "Redux", "Context API", "Hooks"],
      category: "Frontend",
      level: "Expert",
      verificationUrl: "https://verify.talenthub.com/cert/TH-RC-2024-005678",
      status: "active",
      color: "from-cyan-500 to-blue-500",
      icon: Code,
      description: "Advanced React development certification demonstrating mastery of state management and component architecture."
    },
    {
      id: 3,
      title: "Full-Stack Developer Badge",
      issuer: "TalentHub Academy",
      issuedDate: "2024-02-01",
      expiryDate: "2026-02-01",
      credentialId: "TH-FS-2024-009012",
      skills: ["React", "Node.js", "MongoDB", "AWS"],
      category: "Full-Stack",
      level: "Advanced",
      verificationUrl: "https://verify.talenthub.com/cert/TH-FS-2024-009012",
      status: "active",
      color: "from-purple-500 to-pink-500",
      icon: Database,
      description: "Complete full-stack development certification covering frontend, backend, and cloud deployment."
    },
    {
      id: 4,
      title: "Mobile Development Certificate",
      issuer: "TalentHub Academy",
      issuedDate: "2023-12-15",
      expiryDate: "2025-12-15",
      credentialId: "TH-MD-2023-003456",
      skills: ["React Native", "Flutter", "Mobile UI/UX"],
      category: "Mobile",
      level: "Intermediate",
      verificationUrl: "https://verify.talenthub.com/cert/TH-MD-2023-003456",
      status: "expiring-soon",
      color: "from-orange-500 to-red-500",
      icon: Smartphone,
      description: "Cross-platform mobile development certification with focus on React Native and Flutter frameworks."
    }
  ];

  const achievements = [
    {
      id: 1,
      title: "Code Quality Champion",
      description: "Maintained 95%+ code quality score across 10 projects",
      earnedDate: "2024-02-10",
      rarity: "rare",
      category: "Quality"
    },
    {
      id: 2,
      title: "Community Contributor",
      description: "Made 50+ meaningful contributions to open source projects",
      earnedDate: "2024-01-25",
      rarity: "uncommon",
      category: "Community"
    },
    {
      id: 3,
      title: "Innovation Leader",
      description: "Created 3 innovative solutions that received industry recognition",
      earnedDate: "2024-02-05",
      rarity: "legendary",
      category: "Innovation"
    }
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case "active": return "bg-green-100 text-green-800 border-green-200";
      case "expiring-soon": return "bg-orange-100 text-orange-800 border-orange-200";
      case "expired": return "bg-red-100 text-red-800 border-red-200";
      default: return "bg-gray-100 text-gray-800 border-gray-200";
    }
  };

  const getRarityColor = (rarity: string) => {
    switch (rarity) {
      case "common": return "bg-gray-100 text-gray-800 border-gray-200";
      case "uncommon": return "bg-green-100 text-green-800 border-green-200";
      case "rare": return "bg-blue-100 text-blue-800 border-blue-200";
      case "epic": return "bg-purple-100 text-purple-800 border-purple-200";
      case "legendary": return "bg-yellow-100 text-yellow-800 border-yellow-200";
      default: return "bg-gray-100 text-gray-800 border-gray-200";
    }
  };

  return (
    <PlatformLayout
      sidebarTitle={config.sidebarTitle}
      sidebarSubtitle={config.sidebarSubtitle}
      sidebarSections={config.sidebarSections}
      usageData={config.usageData}
    >
      <div className="p-6 max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="text-center space-y-4">
          <div className="flex items-center justify-center space-x-3">
            <div className="p-3 bg-gradient-to-r from-yellow-500 to-orange-500 rounded-full">
              <Trophy className="h-8 w-8 text-white" />
            </div>
            <h1 className="text-4xl font-bold bg-gradient-to-r from-yellow-600 to-orange-600 bg-clip-text text-transparent">
              Certificate Gallery
            </h1>
          </div>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Showcase your professional certifications, achievements, and digital credentials with verification
          </p>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card className="bg-gradient-to-r from-yellow-50 to-orange-50 border-yellow-200">
            <CardContent className="p-4 text-center">
              <Trophy className="h-8 w-8 text-yellow-500 mx-auto mb-2" />
              <p className="text-2xl font-bold text-yellow-600">4</p>
              <p className="text-sm text-muted-foreground">Certificates Earned</p>
            </CardContent>
          </Card>
          <Card className="bg-gradient-to-r from-green-50 to-emerald-50 border-green-200">
            <CardContent className="p-4 text-center">
              <CheckCircle className="h-8 w-8 text-green-500 mx-auto mb-2" />
              <p className="text-2xl font-bold text-green-600">3</p>
              <p className="text-sm text-muted-foreground">Active Credentials</p>
            </CardContent>
          </Card>
          <Card className="bg-gradient-to-r from-purple-50 to-pink-50 border-purple-200">
            <CardContent className="p-4 text-center">
              <Award className="h-8 w-8 text-purple-500 mx-auto mb-2" />
              <p className="text-2xl font-bold text-purple-600">3</p>
              <p className="text-sm text-muted-foreground">Achievements</p>
            </CardContent>
          </Card>
          <Card className="bg-gradient-to-r from-blue-50 to-indigo-50 border-blue-200">
            <CardContent className="p-4 text-center">
              <Star className="h-8 w-8 text-blue-500 mx-auto mb-2" />
              <p className="text-2xl font-bold text-blue-600">1</p>
              <p className="text-sm text-muted-foreground">Legendary Badge</p>
            </CardContent>
          </Card>
        </div>

        {/* Search and Filters */}
        <div className="flex flex-col sm:flex-row gap-4 items-center justify-between">
          <div className="flex items-center space-x-2 flex-1">
            <div className="relative flex-1 max-w-md">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
              <Input
                placeholder="Search certificates..."
                className="pl-10"
              />
            </div>
          </div>
          <div className="flex items-center space-x-2">
            <Select defaultValue="all">
              <SelectTrigger className="w-40">
                <SelectValue placeholder="Category" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Categories</SelectItem>
                <SelectItem value="frontend">Frontend</SelectItem>
                <SelectItem value="backend">Backend</SelectItem>
                <SelectItem value="fullstack">Full-Stack</SelectItem>
                <SelectItem value="mobile">Mobile</SelectItem>
              </SelectContent>
            </Select>
            <Select defaultValue="active">
              <SelectTrigger className="w-40">
                <SelectValue placeholder="Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="active">Active</SelectItem>
                <SelectItem value="expiring">Expiring Soon</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <Tabs defaultValue="certificates" className="space-y-6">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="certificates">Certificates</TabsTrigger>
            <TabsTrigger value="achievements">Achievements</TabsTrigger>
            <TabsTrigger value="verification">Verification</TabsTrigger>
          </TabsList>

          <TabsContent value="certificates" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {certificates.map((cert) => {
                const IconComponent = cert.icon;
                return (
                  <Card key={cert.id} className="group hover:shadow-lg transition-all duration-300 hover:-translate-y-1 border-l-4 border-l-yellow-500">
                    <CardHeader className="pb-3">
                      <div className="flex items-start justify-between">
                        <div className={`p-2 bg-gradient-to-r ${cert.color} rounded-lg`}>
                          <IconComponent className="h-6 w-6 text-white" />
                        </div>
                        <div className="flex gap-2">
                          <Badge className={getStatusColor(cert.status)}>
                            {cert.status === "active" ? "Active" : 
                             cert.status === "expiring-soon" ? "Expiring Soon" : "Expired"}
                          </Badge>
                          <Badge variant="secondary">{cert.level}</Badge>
                        </div>
                      </div>
                      <CardTitle className="text-xl">{cert.title}</CardTitle>
                      <CardDescription>{cert.description}</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="grid grid-cols-2 gap-4 text-sm text-muted-foreground">
                        <div className="flex items-center gap-1">
                          <Calendar className="h-4 w-4" />
                          <span>Issued: {new Date(cert.issuedDate).toLocaleDateString()}</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <Calendar className="h-4 w-4" />
                          <span>Expires: {new Date(cert.expiryDate).toLocaleDateString()}</span>
                        </div>
                      </div>

                      <div className="space-y-2">
                        <h4 className="text-sm font-medium">Skills Covered</h4>
                        <div className="flex flex-wrap gap-1">
                          {cert.skills.map((skill, index) => (
                            <Badge key={index} variant="outline" className="text-xs">
                              {skill}
                            </Badge>
                          ))}
                        </div>
                      </div>

                      <div className="bg-gray-50 p-3 rounded-lg">
                        <h4 className="text-sm font-medium mb-1">Credential Details</h4>
                        <p className="text-xs text-muted-foreground">ID: {cert.credentialId}</p>
                        <p className="text-xs text-muted-foreground">Issuer: {cert.issuer}</p>
                      </div>

                      <div className="flex items-center gap-2 pt-2">
                        <Button size="sm" className="flex-1 bg-gradient-to-r from-yellow-500 to-orange-500 hover:from-yellow-600 hover:to-orange-600">
                          <Eye className="h-4 w-4 mr-2" />
                          View Certificate
                        </Button>
                        <Button size="sm" variant="outline">
                          <Download className="h-4 w-4" />
                        </Button>
                        <Button size="sm" variant="outline">
                          <Share className="h-4 w-4" />
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </TabsContent>

          <TabsContent value="achievements" className="space-y-6">
            <h3 className="text-xl font-bold text-yellow-700">Achievement Badges</h3>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {achievements.map((achievement) => (
                <Card key={achievement.id} className="text-center hover:shadow-lg transition-all duration-300 hover:-translate-y-1">
                  <CardContent className="p-6">
                    <div className="mb-4">
                      <div className="w-16 h-16 bg-gradient-to-r from-yellow-500 to-orange-500 rounded-full flex items-center justify-center mx-auto mb-3">
                        <Trophy className="h-8 w-8 text-white" />
                      </div>
                      <Badge className={getRarityColor(achievement.rarity)}>
                        {achievement.rarity.charAt(0).toUpperCase() + achievement.rarity.slice(1)}
                      </Badge>
                    </div>
                    <h4 className="font-semibold text-lg mb-2">{achievement.title}</h4>
                    <p className="text-sm text-muted-foreground mb-3">{achievement.description}</p>
                    <div className="text-xs text-muted-foreground">
                      Earned: {new Date(achievement.earnedDate).toLocaleDateString()}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="verification" className="space-y-6">
            <h3 className="text-xl font-bold text-yellow-700">Certificate Verification</h3>
            
            <Card>
              <CardHeader>
                <CardTitle>Verify Credentials</CardTitle>
                <CardDescription>Verify the authenticity of certificates and credentials</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium">Credential ID</label>
                  <Input placeholder="Enter credential ID (e.g., TH-FE-2024-001234)" />
                </div>
                <Button className="w-full bg-gradient-to-r from-yellow-500 to-orange-500 hover:from-yellow-600 hover:to-orange-600">
                  Verify Credential
                </Button>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Verification Links</CardTitle>
                <CardDescription>Direct verification links for all your certificates</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {certificates.map((cert) => (
                    <div key={cert.id} className="flex items-center justify-between p-3 border rounded-lg">
                      <div>
                        <h4 className="font-medium">{cert.title}</h4>
                        <p className="text-sm text-muted-foreground">ID: {cert.credentialId}</p>
                      </div>
                      <Button size="sm" variant="outline">
                        <Globe className="h-4 w-4 mr-2" />
                        Verify
                      </Button>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </PlatformLayout>
  );
}