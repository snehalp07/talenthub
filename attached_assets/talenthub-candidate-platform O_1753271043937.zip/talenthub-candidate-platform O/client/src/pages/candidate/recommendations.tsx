import PlatformLayout from "@/components/layout/platform-layout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Textarea } from "@/components/ui/textarea";
import { Award, Users, Star, Calendar, Search, Filter, Clock, Target, TrendingUp, ChevronRight, MessageSquare, Eye, ThumbsUp, Quote, Edit, Send } from "lucide-react";
import { platformConfigs } from "@/config/complete-navigation";

export default function Recommendations() {
  const config = platformConfigs.candidate;
  const receivedRecommendations = [
    {
      id: 1,
      recommender: "Jennifer Walsh",
      recommenderImage: "https://images.unsplash.com/photo-1494790108755-2616b612b786?w=150&h=150&fit=crop&crop=face",
      recommenderTitle: "Senior Product Manager",
      recommenderCompany: "Google",
      relationship: "Former Manager",
      date: "June 15, 2025",
      content: "Alex is an exceptional software engineer with strong technical skills and excellent problem-solving abilities. During our 2 years working together, he consistently delivered high-quality code and mentored junior developers. His expertise in React and system design made him invaluable to our team's success.",
      skills: ["React", "System Design", "Leadership", "Mentoring"],
      public: true,
      featured: true,
      engagement: { views: 245, likes: 32 }
    },
    {
      id: 2,
      recommender: "Michael Chen",
      recommenderImage: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&h=150&fit=crop&crop=face",
      recommenderTitle: "Tech Lead",
      recommenderCompany: "Microsoft",
      relationship: "Colleague",
      date: "June 10, 2025",
      content: "I had the pleasure of collaborating with Alex on several complex projects. His analytical thinking and attention to detail are remarkable. He has a unique ability to break down complex problems and communicate solutions clearly to both technical and non-technical stakeholders.",
      skills: ["Problem Solving", "Communication", "Analysis", "Collaboration"],
      public: true,
      featured: false,
      engagement: { views: 189, likes: 28 }
    },
    {
      id: 3,
      recommender: "Sarah Johnson",
      recommenderImage: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=150&h=150&fit=crop&crop=face",
      recommenderTitle: "UX Designer",
      recommenderCompany: "Adobe",
      relationship: "Project Partner",
      date: "June 8, 2025",
      content: "Alex's collaboration skills are outstanding. Working together on the user interface redesign project, he demonstrated deep understanding of user experience principles while maintaining technical excellence. His feedback was always constructive and helped improve our final product significantly.",
      skills: ["UI/UX", "Collaboration", "Feedback", "Technical Excellence"],
      public: false,
      featured: false,
      engagement: { views: 156, likes: 22 }
    }
  ];

  const givenRecommendations = [
    {
      id: 1,
      recipient: "David Park",
      recipientImage: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&h=150&fit=crop&crop=face",
      recipientTitle: "Data Scientist",
      date: "June 12, 2025",
      content: "David is an exceptional data scientist with deep expertise in machine learning...",
      status: "Published"
    },
    {
      id: 2,
      recipient: "Emily Chen",
      recipientImage: "https://images.unsplash.com/photo-1580489944761-15a19d654956?w=150&h=150&fit=crop&crop=face",
      recipientTitle: "Frontend Developer",
      date: "June 5, 2025",
      content: "Emily's frontend development skills are remarkable. Her attention to detail...",
      status: "Draft"
    }
  ];

  const recommendationRequests = [
    {
      id: 1,
      requester: "Lisa Wong",
      requesterImage: "https://images.unsplash.com/photo-1580489944761-15a19d654956?w=150&h=150&fit=crop&crop=face",
      requesterTitle: "Product Designer",
      requesterCompany: "Spotify",
      relationship: "Former Colleague",
      requestDate: "June 20, 2025",
      message: "Hi! We worked together on the mobile app redesign. Would you mind writing a recommendation highlighting our collaboration and my design process?",
      skills: ["Product Design", "User Research", "Prototyping"],
      urgency: "Normal"
    },
    {
      id: 2,
      requester: "James Miller",
      requesterImage: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&h=150&fit=crop&crop=face",
      requesterTitle: "Backend Developer",
      requesterCompany: "Amazon",
      relationship: "Mentee",
      requestDate: "June 18, 2025",
      message: "Thank you for mentoring me over the past 6 months. I'm applying for senior roles and would appreciate a recommendation focusing on my growth and technical skills.",
      skills: ["Node.js", "AWS", "Microservices", "Growth"],
      urgency: "High"
    }
  ];

  const skillsEndorsements = [
    { skill: "React", endorsements: 45, recentEndorsers: ["Jennifer W.", "Michael C.", "Sarah J."] },
    { skill: "System Design", endorsements: 32, recentEndorsers: ["David P.", "Emily C.", "Lisa W."] },
    { skill: "Leadership", endorsements: 28, recentEndorsers: ["Jennifer W.", "Michael C."] },
    { skill: "Problem Solving", endorsements: 38, recentEndorsers: ["Michael C.", "Sarah J.", "David P."] },
    { skill: "Mentoring", endorsements: 22, recentEndorsers: ["Jennifer W.", "James M."] },
    { skill: "Communication", endorsements: 35, recentEndorsers: ["Michael C.", "Sarah J.", "Lisa W."] }
  ];

  return (
    <PlatformLayout
      sidebarTitle={config.sidebarTitle}
      sidebarSubtitle={config.sidebarSubtitle}
      sidebarSections={config.sidebarSections}
      usageData={config.usageData}
    >
      <div className="p-6 max-w-7xl mx-auto space-y-6">
      {/* Header */}
      <div className="text-center space-y-4">
        <div className="flex items-center justify-center space-x-3">
          <div className="p-3 bg-gradient-to-r from-amber-500 to-orange-500 rounded-full">
            <Award className="h-8 w-8 text-white" />
          </div>
          <h1 className="text-4xl font-bold bg-gradient-to-r from-amber-600 to-orange-600 bg-clip-text text-transparent">
            Professional Recommendations
          </h1>
        </div>
        <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
          Build credibility with professional recommendations and skill endorsements from your network
        </p>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="bg-gradient-to-r from-amber-50 to-orange-50 border-amber-200">
          <CardContent className="p-4 text-center">
            <Award className="h-8 w-8 text-amber-500 mx-auto mb-2" />
            <p className="text-2xl font-bold text-amber-600">12</p>
            <p className="text-sm text-muted-foreground">Recommendations</p>
          </CardContent>
        </Card>
        <Card className="bg-gradient-to-r from-blue-50 to-cyan-50 border-blue-200">
          <CardContent className="p-4 text-center">
            <Star className="h-8 w-8 text-blue-500 mx-auto mb-2" />
            <p className="text-2xl font-bold text-blue-600">240</p>
            <p className="text-sm text-muted-foreground">Skill Endorsements</p>
          </CardContent>
        </Card>
        <Card className="bg-gradient-to-r from-green-50 to-emerald-50 border-green-200">
          <CardContent className="p-4 text-center">
            <Eye className="h-8 w-8 text-green-500 mx-auto mb-2" />
            <p className="text-2xl font-bold text-green-600">1,250</p>
            <p className="text-sm text-muted-foreground">Profile Views</p>
          </CardContent>
        </Card>
        <Card className="bg-gradient-to-r from-purple-50 to-pink-50 border-purple-200">
          <CardContent className="p-4 text-center">
            <TrendingUp className="h-8 w-8 text-purple-500 mx-auto mb-2" />
            <p className="text-2xl font-bold text-purple-600">95%</p>
            <p className="text-sm text-muted-foreground">Response Rate</p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="received" className="space-y-6">
        <TabsList className="grid w-full grid-cols-5 bg-amber-100">
          <TabsTrigger value="received" className="data-[state=active]:bg-amber-500 data-[state=active]:text-white">
            Received
          </TabsTrigger>
          <TabsTrigger value="given" className="data-[state=active]:bg-amber-500 data-[state=active]:text-white">
            Given
          </TabsTrigger>
          <TabsTrigger value="requests" className="data-[state=active]:bg-amber-500 data-[state=active]:text-white">
            Requests
          </TabsTrigger>
          <TabsTrigger value="endorsements" className="data-[state=active]:bg-amber-500 data-[state=active]:text-white">
            Endorsements
          </TabsTrigger>
          <TabsTrigger value="request-new" className="data-[state=active]:bg-amber-500 data-[state=active]:text-white">
            Request New
          </TabsTrigger>
        </TabsList>

        <TabsContent value="received" className="space-y-6">
          {/* Search and Filter */}
          <Card className="bg-gradient-to-r from-amber-50 to-orange-50 border-amber-200">
            <CardContent className="p-6">
              <div className="flex flex-col md:flex-row gap-4">
                <div className="flex-1 relative">
                  <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                  <Input placeholder="Search recommendations by recommender or skill..." className="pl-10 bg-white" />
                </div>
                <div className="flex gap-2">
                  <Button variant="outline" className="border-amber-300 hover:bg-amber-50">
                    <Filter className="h-4 w-4 mr-2" />
                    Filter
                  </Button>
                  <Button variant="outline" className="border-amber-300 hover:bg-amber-50">
                    <Star className="h-4 w-4 mr-2" />
                    Featured
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Recommendations */}
          <div className="space-y-4">
            <h2 className="text-2xl font-bold text-amber-700">Your Recommendations</h2>
            <div className="space-y-6">
              {receivedRecommendations.map((rec) => (
                <Card key={rec.id} className="border-l-4 border-l-amber-500">
                  <CardHeader className="pb-4">
                    <div className="flex items-start gap-4">
                      <Avatar className="h-12 w-12">
                        <AvatarImage src={rec.recommenderImage} alt={rec.recommender} />
                        <AvatarFallback>{rec.recommender.split(' ').map(n => n[0]).join('')}</AvatarFallback>
                      </Avatar>
                      <div className="flex-1">
                        <div className="flex justify-between items-start">
                          <div>
                            <CardTitle className="text-lg">{rec.recommender}</CardTitle>
                            <p className="text-sm text-muted-foreground">{rec.recommenderTitle}</p>
                            <p className="text-sm font-medium text-amber-600">{rec.recommenderCompany}</p>
                            <p className="text-xs text-muted-foreground mt-1">{rec.relationship} • {rec.date}</p>
                          </div>
                          <div className="flex gap-2">
                            {rec.featured && (
                              <Badge className="bg-gradient-to-r from-yellow-400 to-orange-500 text-white">
                                <Star className="h-3 w-3 mr-1" />
                                Featured
                              </Badge>
                            )}
                            <Badge variant={rec.public ? 'default' : 'secondary'}>
                              {rec.public ? 'Public' : 'Private'}
                            </Badge>
                          </div>
                        </div>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="bg-gray-50 p-4 rounded-lg border-l-4 border-l-amber-300">
                      <Quote className="h-5 w-5 text-amber-500 mb-2" />
                      <p className="text-sm italic">{rec.content}</p>
                    </div>

                    <div className="flex flex-wrap gap-1">
                      {rec.skills.map((skill) => (
                        <Badge key={skill} variant="secondary" className="text-xs bg-amber-100 text-amber-700">
                          {skill}
                        </Badge>
                      ))}
                    </div>

                    <div className="flex justify-between items-center pt-2 border-t">
                      <div className="flex items-center gap-4 text-sm text-muted-foreground">
                        <div className="flex items-center gap-1">
                          <Eye className="h-4 w-4" />
                          {rec.engagement.views} views
                        </div>
                        <div className="flex items-center gap-1">
                          <ThumbsUp className="h-4 w-4" />
                          {rec.engagement.likes} likes
                        </div>
                      </div>
                      <div className="flex gap-2">
                        <Button variant="outline" size="sm">
                          <MessageSquare className="h-4 w-4 mr-2" />
                          Thank
                        </Button>
                        <Button size="sm" className="bg-gradient-to-r from-amber-500 to-orange-500">
                          Share
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </TabsContent>

        <TabsContent value="given" className="space-y-6">
          <h2 className="text-2xl font-bold text-amber-700">Recommendations You've Written</h2>
          
          <div className="space-y-4">
            {givenRecommendations.map((rec) => (
              <Card key={rec.id} className="border-l-4 border-l-amber-500">
                <CardContent className="p-6">
                  <div className="flex justify-between items-start">
                    <div className="flex items-center gap-4">
                      <Avatar className="h-12 w-12">
                        <AvatarImage src={rec.recipientImage} alt={rec.recipient} />
                        <AvatarFallback>{rec.recipient.split(' ').map(n => n[0]).join('')}</AvatarFallback>
                      </Avatar>
                      <div>
                        <h3 className="text-lg font-semibold">{rec.recipient}</h3>
                        <p className="text-sm text-muted-foreground">{rec.recipientTitle}</p>
                        <p className="text-xs text-muted-foreground">{rec.date}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <Badge variant={rec.status === 'Published' ? 'default' : 'secondary'}>
                        {rec.status}
                      </Badge>
                      <Button variant="outline" size="sm">
                        <Edit className="h-4 w-4 mr-2" />
                        Edit
                      </Button>
                    </div>
                  </div>
                  <div className="mt-4 p-3 bg-gray-50 rounded-lg">
                    <p className="text-sm text-muted-foreground">{rec.content}</p>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="requests" className="space-y-6">
          <h2 className="text-2xl font-bold text-amber-700">Recommendation Requests</h2>
          
          <div className="space-y-4">
            {recommendationRequests.map((request) => (
              <Card key={request.id} className="border-l-4 border-l-amber-500">
                <CardContent className="p-6">
                  <div className="flex justify-between items-start mb-4">
                    <div className="flex items-center gap-4">
                      <Avatar className="h-12 w-12">
                        <AvatarImage src={request.requesterImage} alt={request.requester} />
                        <AvatarFallback>{request.requester.split(' ').map(n => n[0]).join('')}</AvatarFallback>
                      </Avatar>
                      <div>
                        <h3 className="text-lg font-semibold">{request.requester}</h3>
                        <p className="text-sm text-muted-foreground">{request.requesterTitle} at {request.requesterCompany}</p>
                        <p className="text-xs text-muted-foreground">{request.relationship} • {request.requestDate}</p>
                      </div>
                    </div>
                    <Badge variant={request.urgency === 'High' ? 'destructive' : 'secondary'}>
                      {request.urgency} Priority
                    </Badge>
                  </div>

                  <div className="bg-blue-50 p-4 rounded-lg mb-4">
                    <p className="text-sm">{request.message}</p>
                  </div>

                  <div className="flex flex-wrap gap-1 mb-4">
                    {request.skills.map((skill) => (
                      <Badge key={skill} variant="outline" className="text-xs">
                        {skill}
                      </Badge>
                    ))}
                  </div>

                  <div className="flex gap-2">
                    <Button variant="outline" className="flex-1">
                      Decline
                    </Button>
                    <Button className="flex-1 bg-gradient-to-r from-amber-500 to-orange-500">
                      Write Recommendation
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="endorsements" className="space-y-6">
          <h2 className="text-2xl font-bold text-amber-700">Skill Endorsements</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {skillsEndorsements.map((skill, index) => (
              <Card key={index} className="border-l-4 border-l-amber-500">
                <CardContent className="p-6">
                  <div className="flex justify-between items-start mb-4">
                    <div>
                      <h3 className="text-lg font-semibold">{skill.skill}</h3>
                      <p className="text-sm text-muted-foreground">{skill.endorsements} endorsements</p>
                    </div>
                    <Button size="sm" variant="outline">
                      <Star className="h-4 w-4 mr-2" />
                      Endorse Others
                    </Button>
                  </div>

                  <div className="space-y-2">
                    <p className="text-sm font-medium">Recent endorsements from:</p>
                    <div className="flex flex-wrap gap-2">
                      {skill.recentEndorsers.map((endorser, idx) => (
                        <Badge key={idx} variant="secondary" className="text-xs bg-amber-100 text-amber-700">
                          {endorser}
                        </Badge>
                      ))}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="request-new" className="space-y-6">
          <div className="max-w-2xl mx-auto">
            <Card className="border-amber-200">
              <CardHeader className="text-center">
                <CardTitle className="text-2xl text-amber-700">Request Recommendation</CardTitle>
                <CardDescription>Ask a colleague or manager to write you a professional recommendation</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium mb-2">Recommender's Email</label>
                    <Input placeholder="colleague@company.com" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2">Your Relationship</label>
                    <Input placeholder="Former Manager, Colleague, etc." />
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2">Skills to Highlight</label>
                  <Input placeholder="React, Leadership, Problem Solving..." />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2">Personal Message</label>
                  <Textarea placeholder="Hi [Name], I hope you're doing well. I'm updating my professional profile and would be honored if you could write a recommendation highlighting our work together on [project/role]. Thank you for considering!" />
                </div>
                <Button className="w-full bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600">
                  <Send className="h-4 w-4 mr-2" />
                  Send Request
                </Button>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
      </div>
    </PlatformLayout>
  );
}