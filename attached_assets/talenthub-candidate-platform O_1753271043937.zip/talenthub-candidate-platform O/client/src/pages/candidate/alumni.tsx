import PlatformLayout from "@/components/layout/platform-layout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { School, Users, MapPin, Calendar, Search, Filter, GraduationCap, Briefcase, Star, ChevronRight, MessageSquare, Video, Coffee, Trophy, TrendingUp } from "lucide-react";
import { platformConfigs } from "@/config/complete-navigation";

export default function Alumni() {
  const config = platformConfigs.candidate;
  const alumniConnections = [
    {
      id: 1,
      name: "Jennifer Walsh",
      graduation: "2020",
      degree: "Computer Science",
      school: "Stanford University",
      currentRole: "Senior Software Engineer",
      company: "Google",
      location: "San Francisco, CA",
      connections: 342,
      image: "https://images.unsplash.com/photo-1494790108755-2616b612b786?w=150&h=150&fit=crop&crop=face",
      expertise: ["React", "System Design", "Leadership"],
      featured: true,
      mutualConnections: 12
    },
    {
      id: 2,
      name: "Michael Chen",
      graduation: "2018",
      degree: "Business Administration",
      school: "Harvard Business School",
      currentRole: "Product Manager",
      company: "Microsoft",
      location: "Seattle, WA",
      connections: 567,
      image: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&h=150&fit=crop&crop=face",
      expertise: ["Product Strategy", "Analytics", "Growth"],
      featured: false,
      mutualConnections: 8
    },
    {
      id: 3,
      name: "Sarah Johnson",
      graduation: "2019",
      degree: "Data Science",
      school: "MIT",
      currentRole: "Data Science Lead",
      company: "Netflix",
      location: "Los Angeles, CA",
      connections: 445,
      image: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=150&h=150&fit=crop&crop=face",
      expertise: ["Machine Learning", "Analytics", "Python"],
      featured: true,
      mutualConnections: 15
    }
  ];

  const schools = [
    {
      name: "Stanford University",
      alumni: 1245,
      logo: "https://images.unsplash.com/photo-1607237138185-eedd9c632b0b?w=100&h=100&fit=crop",
      topRoles: ["Software Engineer", "Product Manager", "Data Scientist"],
      color: "bg-red-500"
    },
    {
      name: "MIT",
      alumni: 987,
      logo: "https://images.unsplash.com/photo-1564981797816-1043664bf78d?w=100&h=100&fit=crop",
      topRoles: ["Research Scientist", "Tech Lead", "CTO"],
      color: "bg-blue-500"
    },
    {
      name: "Harvard University",
      alumni: 856,
      logo: "https://images.unsplash.com/photo-1541339907198-e08756dedf3f?w=100&h=100&fit=crop",
      topRoles: ["CEO", "Consultant", "Investment Banker"],
      color: "bg-purple-500"
    },
    {
      name: "UC Berkeley",
      alumni: 743,
      logo: "https://images.unsplash.com/photo-1562774053-701939374585?w=100&h=100&fit=crop",
      topRoles: ["Software Engineer", "Researcher", "Startup Founder"],
      color: "bg-yellow-500"
    }
  ];

  const upcomingEvents = [
    {
      id: 1,
      title: "Stanford Tech Alumni Mixer",
      date: "July 15, 2025",
      time: "6:00 PM - 9:00 PM",
      location: "San Francisco",
      attendees: 85,
      type: "Networking",
      school: "Stanford University"
    },
    {
      id: 2,
      title: "MIT Innovation Symposium",
      date: "July 22, 2025", 
      time: "2:00 PM - 6:00 PM",
      location: "Boston",
      attendees: 150,
      type: "Conference",
      school: "MIT"
    },
    {
      id: 3,
      title: "Harvard Business Alumni Dinner",
      date: "August 5, 2025",
      time: "7:00 PM - 10:00 PM", 
      location: "New York",
      attendees: 120,
      type: "Social",
      school: "Harvard University"
    }
  ];

  const mentorshipPrograms = [
    {
      title: "Career Acceleration",
      school: "Stanford University",
      mentors: 45,
      description: "Connect with senior professionals for career guidance",
      duration: "3 months",
      participants: 120
    },
    {
      title: "Startup Advisory",
      school: "MIT",
      mentors: 32,
      description: "Get advice from successful entrepreneur alumni",
      duration: "6 months",
      participants: 85
    },
    {
      title: "Leadership Development",
      school: "Harvard University",
      mentors: 28,
      description: "Leadership coaching from C-level executives",
      duration: "4 months",
      participants: 95
    }
  ];

  return (
    <PlatformLayout
      sidebarTitle={config.sidebarTitle}
      sidebarSubtitle={config.sidebarSubtitle}
      sidebarSections={config.sidebarSections}
      usageData={config.usageData}
    >
      <div className="p-6 max-w-7xl mx-auto space-y-6">
      {/* Header */}
      <div className="text-center space-y-4">
        <div className="flex items-center justify-center space-x-3">
          <div className="p-3 bg-gradient-to-r from-indigo-500 to-purple-500 rounded-full">
            <School className="h-8 w-8 text-white" />
          </div>
          <h1 className="text-4xl font-bold bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent">
            Alumni Network
          </h1>
        </div>
        <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
          Connect with fellow alumni, access exclusive opportunities, and build lasting professional relationships
        </p>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="bg-gradient-to-r from-indigo-50 to-purple-50 border-indigo-200">
          <CardContent className="p-4 text-center">
            <School className="h-8 w-8 text-indigo-500 mx-auto mb-2" />
            <p className="text-2xl font-bold text-indigo-600">500+</p>
            <p className="text-sm text-muted-foreground">Universities</p>
          </CardContent>
        </Card>
        <Card className="bg-gradient-to-r from-blue-50 to-cyan-50 border-blue-200">
          <CardContent className="p-4 text-center">
            <Users className="h-8 w-8 text-blue-500 mx-auto mb-2" />
            <p className="text-2xl font-bold text-blue-600">125K+</p>
            <p className="text-sm text-muted-foreground">Alumni Connected</p>
          </CardContent>
        </Card>
        <Card className="bg-gradient-to-r from-green-50 to-emerald-50 border-green-200">
          <CardContent className="p-4 text-center">
            <Trophy className="h-8 w-8 text-green-500 mx-auto mb-2" />
            <p className="text-2xl font-bold text-green-600">2,450</p>
            <p className="text-sm text-muted-foreground">Success Stories</p>
          </CardContent>
        </Card>
        <Card className="bg-gradient-to-r from-orange-50 to-red-50 border-orange-200">
          <CardContent className="p-4 text-center">
            <Calendar className="h-8 w-8 text-orange-500 mx-auto mb-2" />
            <p className="text-2xl font-bold text-orange-600">320</p>
            <p className="text-sm text-muted-foreground">Monthly Events</p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="network" className="space-y-6">
        <TabsList className="grid w-full grid-cols-4 bg-indigo-100">
          <TabsTrigger value="network" className="data-[state=active]:bg-indigo-500 data-[state=active]:text-white">
            Alumni Network
          </TabsTrigger>
          <TabsTrigger value="schools" className="data-[state=active]:bg-indigo-500 data-[state=active]:text-white">
            Schools
          </TabsTrigger>
          <TabsTrigger value="events" className="data-[state=active]:bg-indigo-500 data-[state=active]:text-white">
            Events
          </TabsTrigger>
          <TabsTrigger value="mentorship" className="data-[state=active]:bg-indigo-500 data-[state=active]:text-white">
            Mentorship
          </TabsTrigger>
        </TabsList>

        <TabsContent value="network" className="space-y-6">
          {/* Search and Filter */}
          <Card className="bg-gradient-to-r from-indigo-50 to-purple-50 border-indigo-200">
            <CardContent className="p-6">
              <div className="flex flex-col md:flex-row gap-4">
                <div className="flex-1 relative">
                  <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                  <Input placeholder="Search alumni by name, school, company, or role..." className="pl-10 bg-white" />
                </div>
                <div className="flex gap-2">
                  <Button variant="outline" className="border-indigo-300 hover:bg-indigo-50">
                    <Filter className="h-4 w-4 mr-2" />
                    Filter
                  </Button>
                  <Button variant="outline" className="border-indigo-300 hover:bg-indigo-50">
                    <MapPin className="h-4 w-4 mr-2" />
                    Location
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Featured Alumni */}
          <div className="space-y-4">
            <h2 className="text-2xl font-bold text-indigo-700">Featured Alumni</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {alumniConnections.map((alumni) => (
                <Card key={alumni.id} className="group hover:shadow-lg transition-all duration-300 border-l-4 border-l-indigo-500">
                  <CardHeader className="pb-4">
                    <div className="flex items-start gap-4">
                      <Avatar className="h-16 w-16">
                        <AvatarImage src={alumni.image} alt={alumni.name} />
                        <AvatarFallback>{alumni.name.split(' ').map(n => n[0]).join('')}</AvatarFallback>
                      </Avatar>
                      <div className="flex-1">
                        <div className="flex justify-between items-start">
                          <div>
                            <CardTitle className="text-lg group-hover:text-indigo-600 transition-colors">
                              {alumni.name}
                            </CardTitle>
                            <p className="text-sm text-muted-foreground">{alumni.currentRole}</p>
                            <p className="text-sm font-medium text-indigo-600">{alumni.company}</p>
                          </div>
                          {alumni.featured && (
                            <Badge className="bg-gradient-to-r from-yellow-400 to-orange-500 text-white">
                              <Star className="h-3 w-3 mr-1" />
                              Featured
                            </Badge>
                          )}
                        </div>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-2 gap-4 text-sm">
                      <div>
                        <p className="text-muted-foreground">School</p>
                        <p className="font-medium">{alumni.school}</p>
                      </div>
                      <div>
                        <p className="text-muted-foreground">Graduated</p>
                        <p className="font-medium">{alumni.graduation}</p>
                      </div>
                      <div>
                        <p className="text-muted-foreground">Location</p>
                        <p className="font-medium">{alumni.location}</p>
                      </div>
                      <div>
                        <p className="text-muted-foreground">Connections</p>
                        <p className="font-medium">{alumni.connections}</p>
                      </div>
                    </div>

                    <div className="flex flex-wrap gap-1">
                      {alumni.expertise.map((skill) => (
                        <Badge key={skill} variant="secondary" className="text-xs bg-indigo-100 text-indigo-700">
                          {skill}
                        </Badge>
                      ))}
                    </div>

                    <div className="text-sm text-muted-foreground">
                      {alumni.mutualConnections} mutual connections
                    </div>

                    <div className="flex gap-2 pt-2 border-t">
                      <Button variant="outline" size="sm" className="flex-1">
                        <MessageSquare className="h-4 w-4 mr-2" />
                        Message
                      </Button>
                      <Button size="sm" className="flex-1 bg-gradient-to-r from-indigo-500 to-purple-500 hover:from-indigo-600 hover:to-purple-600">
                        Connect
                        <ChevronRight className="h-4 w-4 ml-1" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </TabsContent>

        <TabsContent value="schools" className="space-y-6">
          <h2 className="text-2xl font-bold text-indigo-700">Alumni by School</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {schools.map((school, index) => (
              <Card key={index} className="group hover:shadow-lg transition-all duration-300">
                <CardContent className="p-6">
                  <div className="flex items-start gap-4">
                    <img 
                      src={school.logo} 
                      alt={school.name}
                      className="w-16 h-16 rounded-lg object-cover"
                    />
                    <div className="flex-1 space-y-3">
                      <div>
                        <h3 className="text-lg font-semibold group-hover:text-indigo-600 transition-colors">
                          {school.name}
                        </h3>
                        <p className="text-sm text-muted-foreground">
                          {school.alumni.toLocaleString()} alumni connected
                        </p>
                      </div>
                      
                      <div>
                        <p className="text-sm font-medium mb-2">Top Roles:</p>
                        <div className="flex flex-wrap gap-1">
                          {school.topRoles.map((role) => (
                            <Badge key={role} variant="outline" className="text-xs">
                              {role}
                            </Badge>
                          ))}
                        </div>
                      </div>

                      <Button className="w-full bg-gradient-to-r from-indigo-500 to-purple-500 hover:from-indigo-600 hover:to-purple-600">
                        Explore Alumni
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="events" className="space-y-6">
          <h2 className="text-2xl font-bold text-indigo-700">Upcoming Alumni Events</h2>
          
          <div className="space-y-4">
            {upcomingEvents.map((event) => (
              <Card key={event.id} className="border-l-4 border-l-indigo-500">
                <CardContent className="p-6">
                  <div className="grid grid-cols-1 lg:grid-cols-4 gap-4 items-center">
                    <div className="lg:col-span-2">
                      <div className="flex items-center gap-3 mb-2">
                        <h3 className="text-lg font-semibold">{event.title}</h3>
                        <Badge variant="outline" className="text-xs">
                          {event.type}
                        </Badge>
                      </div>
                      <p className="text-sm text-muted-foreground">{event.school}</p>
                    </div>
                    
                    <div className="space-y-1 text-sm">
                      <div className="flex items-center gap-2">
                        <Calendar className="h-4 w-4 text-indigo-500" />
                        <span>{event.date}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <MapPin className="h-4 w-4 text-indigo-500" />
                        <span>{event.location}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Users className="h-4 w-4 text-indigo-500" />
                        <span>{event.attendees} attending</span>
                      </div>
                    </div>
                    
                    <div className="flex gap-2">
                      <Button variant="outline" size="sm">
                        Details
                      </Button>
                      <Button size="sm" className="bg-gradient-to-r from-indigo-500 to-purple-500">
                        RSVP
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="mentorship" className="space-y-6">
          <h2 className="text-2xl font-bold text-indigo-700">Alumni Mentorship Programs</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {mentorshipPrograms.map((program, index) => (
              <Card key={index} className="group hover:shadow-lg transition-all duration-300">
                <CardHeader>
                  <div className="flex items-center gap-3">
                    <GraduationCap className="h-8 w-8 text-indigo-500" />
                    <div>
                      <CardTitle className="text-lg group-hover:text-indigo-600 transition-colors">
                        {program.title}
                      </CardTitle>
                      <CardDescription>{program.school}</CardDescription>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-sm text-muted-foreground">{program.description}</p>
                  
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <p className="text-muted-foreground">Duration</p>
                      <p className="font-medium">{program.duration}</p>
                    </div>
                    <div>
                      <p className="text-muted-foreground">Mentors</p>
                      <p className="font-medium">{program.mentors}</p>
                    </div>
                  </div>

                  <div className="text-sm">
                    <p className="text-muted-foreground">Active Participants</p>
                    <p className="font-medium">{program.participants} professionals</p>
                  </div>

                  <Button className="w-full bg-gradient-to-r from-indigo-500 to-purple-500 hover:from-indigo-600 hover:to-purple-600">
                    Apply Now
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>
      </Tabs>
      </div>
    </PlatformLayout>
  );
}