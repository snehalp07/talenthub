import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { Input } from "@/components/ui/input";
import PlatformLayout from "@/components/layout/platform-layout";
import { candidateNavigation } from "@/config/complete-navigation";
import { 
  Package, Search, Filter, Star, Clock, Trophy, Target, 
  Brain, Code, Server, Database, Cloud, Monitor, Layers,
  CheckCircle, ArrowRight, Zap, Award, TrendingUp, Play
} from "lucide-react";

const TestPackageMarketplace: React.FC = () => {
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');

  const packageCategories = [
    { id: 'all', name: 'All Packages', icon: Package, count: 47 },
    { id: 'frontend', name: 'Frontend', icon: Monitor, count: 12 },
    { id: 'backend', name: 'Backend', icon: Server, count: 15 },
    { id: 'fullstack', name: 'Full-Stack', icon: Layers, count: 8 },
    { id: 'devops', name: 'DevOps', icon: Cloud, count: 7 },
    { id: 'data', name: 'Data Science', icon: Database, count: 5 }
  ];

  const testPackages = [
    {
      id: 1,
      title: 'React Developer Certification Package',
      category: 'frontend',
      level: 'Professional',
      duration: '4-6 weeks',
      tests: 8,
      price: 'Free',
      rating: 4.9,
      students: 2847,
      description: 'Master React fundamentals, hooks, state management, and advanced patterns',
      color: 'from-blue-500 to-blue-600',
      icon: Monitor,
      features: ['JSX & Components', 'Hooks & State', 'Redux Toolkit', 'Testing Library'],
      certification: 'React Professional Certificate',
      recommended: true
    },
    {
      id: 2,
      title: 'Node.js Backend Mastery',
      category: 'backend',
      level: 'Expert',
      duration: '6-8 weeks',
      tests: 12,
      price: 'Premium',
      rating: 4.8,
      students: 1923,
      description: 'Complete Node.js ecosystem with Express, databases, and microservices',
      color: 'from-green-500 to-green-600',
      icon: Server,
      features: ['Express.js', 'MongoDB/SQL', 'REST APIs', 'Microservices'],
      certification: 'Node.js Expert Certificate'
    },
    {
      id: 3,
      title: 'AWS Cloud Practitioner Prep',
      category: 'devops',
      level: 'Foundation',
      duration: '3-4 weeks',
      tests: 6,
      price: 'Free',
      rating: 4.7,
      students: 3456,
      description: 'Official AWS certification preparation with hands-on labs',
      color: 'from-orange-500 to-orange-600',
      icon: Cloud,
      features: ['EC2 & S3', 'IAM Security', 'Billing & Pricing', 'Practice Exams'],
      certification: 'AWS Certified Cloud Practitioner'
    },
    {
      id: 4,
      title: 'Full-Stack JavaScript Developer',
      category: 'fullstack',
      level: 'Professional',
      duration: '8-10 weeks',
      tests: 15,
      price: 'Premium',
      rating: 4.9,
      students: 1567,
      description: 'End-to-end JavaScript development with modern frameworks',
      color: 'from-purple-500 to-purple-600',
      icon: Layers,
      features: ['React/Vue', 'Node.js/Express', 'Database Design', 'Deployment'],
      certification: 'Full-Stack Developer Certificate'
    },
    {
      id: 5,
      title: 'Python Data Science Fundamentals',
      category: 'data',
      level: 'Foundation',
      duration: '5-6 weeks',
      tests: 10,
      price: 'Free',
      rating: 4.6,
      students: 2134,
      description: 'Data analysis, visualization, and machine learning basics',
      color: 'from-emerald-500 to-emerald-600',
      icon: Database,
      features: ['Pandas & NumPy', 'Matplotlib', 'Scikit-learn', 'Jupyter'],
      certification: 'Data Science Foundation Certificate'
    },
    {
      id: 6,
      title: 'AI-Recommended Package for John',
      category: 'ai-recommended',
      level: 'Custom',
      duration: '6-8 weeks',
      tests: 11,
      price: 'Premium',
      rating: 4.8,
      students: 'Personalized',
      description: 'Tailored certification path based on your skill gap analysis',
      color: 'from-pink-500 to-pink-600',
      icon: Brain,
      features: ['Skill Gap Focus', 'Adaptive Learning', 'Career Goals', 'Mentorship'],
      certification: 'Personalized Professional Certificate',
      aiRecommended: true
    }
  ];

  const filteredPackages = testPackages.filter(pkg => {
    const matchesCategory = selectedCategory === 'all' || pkg.category === selectedCategory;
    const matchesSearch = pkg.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         pkg.description.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  const LevelBadge = ({ level }: { level: string }) => {
    const colors = {
      'Foundation': 'bg-green-100 text-green-800',
      'Professional': 'bg-blue-100 text-blue-800',
      'Expert': 'bg-purple-100 text-purple-800',
      'Custom': 'bg-pink-100 text-pink-800'
    };
    return <Badge className={colors[level as keyof typeof colors] || colors.Foundation}>{level}</Badge>;
  };

  return (
    <PlatformLayout
      sidebarTitle="Skills Certification Hub"
      sidebarSubtitle="Test Package Marketplace"
      sidebarSections={candidateNavigation}
    >
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50">
        {/* Header Section */}
        <div className="bg-gradient-to-r from-blue-600 to-purple-600 text-white p-8">
          <div className="max-w-7xl mx-auto">
            <div className="flex items-center gap-3 mb-4">
              <Package className="h-8 w-8" />
              <h1 className="text-3xl font-bold">Test Package Marketplace</h1>
            </div>
            <p className="text-blue-100 text-lg mb-6">
              Discover curated test packages designed to accelerate your certification journey
            </p>
            
            {/* Search and Filter */}
            <div className="flex flex-col lg:flex-row gap-4">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                <Input
                  placeholder="Search packages, technologies, or certifications..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10 bg-white/10 border-white/20 text-white placeholder:text-white/70"
                />
              </div>
              <Button variant="outline" className="bg-white/10 border-white/20 text-white hover:bg-white/20">
                <Filter className="h-4 w-4 mr-2" />
                Advanced Filters
              </Button>
            </div>
          </div>
        </div>

        {/* Category Tabs */}
        <div className="bg-white shadow-sm border-b">
          <div className="max-w-7xl mx-auto px-8 py-4">
            <div className="flex flex-wrap gap-2">
              {packageCategories.map(category => {
                const Icon = category.icon;
                return (
                  <Button
                    key={category.id}
                    variant={selectedCategory === category.id ? "default" : "outline"}
                    size="sm"
                    onClick={() => setSelectedCategory(category.id)}
                    className={`flex items-center gap-2 ${
                      selectedCategory === category.id 
                        ? 'bg-blue-600 text-white' 
                        : 'text-gray-600 hover:text-blue-600'
                    }`}
                  >
                    <Icon className="h-4 w-4" />
                    {category.name}
                    <Badge variant="secondary" className="ml-1">{category.count}</Badge>
                  </Button>
                );
              })}
            </div>
          </div>
        </div>

        {/* Main Content */}
        <div className="max-w-7xl mx-auto p-8">
          {/* Stats Section */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
            <Card className="text-center">
              <CardContent className="p-4">
                <Package className="h-8 w-8 text-blue-600 mx-auto mb-2" />
                <div className="text-2xl font-bold text-gray-900">47</div>
                <div className="text-sm text-gray-600">Test Packages</div>
              </CardContent>
            </Card>
            <Card className="text-center">
              <CardContent className="p-4">
                <Trophy className="h-8 w-8 text-green-600 mx-auto mb-2" />
                <div className="text-2xl font-bold text-gray-900">23</div>
                <div className="text-sm text-gray-600">Certifications</div>
              </CardContent>
            </Card>
            <Card className="text-center">
              <CardContent className="p-4">
                <Star className="h-8 w-8 text-yellow-600 mx-auto mb-2" />
                <div className="text-2xl font-bold text-gray-900">4.8</div>
                <div className="text-sm text-gray-600">Avg Rating</div>
              </CardContent>
            </Card>
            <Card className="text-center">
              <CardContent className="p-4">
                <TrendingUp className="h-8 w-8 text-purple-600 mx-auto mb-2" />
                <div className="text-2xl font-bold text-gray-900">12K+</div>
                <div className="text-sm text-gray-600">Students</div>
              </CardContent>
            </Card>
          </div>

          {/* Package Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
            {filteredPackages.map(pkg => {
              const Icon = pkg.icon;
              return (
                <Card key={pkg.id} className="relative overflow-hidden group hover:shadow-lg transition-all duration-300">
                  {pkg.recommended && (
                    <div className="absolute top-4 right-4 z-10">
                      <Badge className="bg-yellow-100 text-yellow-800">
                        <Star className="h-3 w-3 mr-1" />
                        Recommended
                      </Badge>
                    </div>
                  )}
                  {pkg.aiRecommended && (
                    <div className="absolute top-4 right-4 z-10">
                      <Badge className="bg-pink-100 text-pink-800">
                        <Brain className="h-3 w-3 mr-1" />
                        AI Recommended
                      </Badge>
                    </div>
                  )}
                  
                  <div className={`h-32 bg-gradient-to-r ${pkg.color} flex items-center justify-center`}>
                    <Icon className="h-16 w-16 text-white" />
                  </div>
                  
                  <CardHeader className="pb-2">
                    <div className="flex items-start justify-between">
                      <CardTitle className="text-lg line-clamp-2">{pkg.title}</CardTitle>
                      <div className="flex items-center gap-1 text-sm text-gray-600">
                        <Star className="h-4 w-4 text-yellow-500 fill-current" />
                        {pkg.rating}
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <LevelBadge level={pkg.level} />
                      <Badge variant="outline">{pkg.tests} Tests</Badge>
                      {pkg.price === 'Free' ? (
                        <Badge className="bg-green-100 text-green-800">Free</Badge>
                      ) : (
                        <Badge className="bg-orange-100 text-orange-800">Premium</Badge>
                      )}
                    </div>
                  </CardHeader>
                  
                  <CardContent className="space-y-4">
                    <CardDescription className="line-clamp-2">
                      {pkg.description}
                    </CardDescription>
                    
                    <div className="flex items-center gap-4 text-sm text-gray-600">
                      <div className="flex items-center gap-1">
                        <Clock className="h-4 w-4" />
                        {pkg.duration}
                      </div>
                      <div className="flex items-center gap-1">
                        <Target className="h-4 w-4" />
                        {typeof pkg.students === 'string' ? pkg.students : `${pkg.students} students`}
                      </div>
                    </div>
                    
                    <div className="space-y-2">
                      <div className="text-sm font-medium text-gray-700">Key Features:</div>
                      <div className="flex flex-wrap gap-1">
                        {pkg.features.slice(0, 3).map((feature, index) => (
                          <Badge key={index} variant="secondary" className="text-xs">
                            {feature}
                          </Badge>
                        ))}
                        {pkg.features.length > 3 && (
                          <Badge variant="secondary" className="text-xs">
                            +{pkg.features.length - 3} more
                          </Badge>
                        )}
                      </div>
                    </div>
                    
                    <div className="pt-2 border-t">
                      <div className="text-sm font-medium text-gray-700 mb-2">
                        Certification: {pkg.certification}
                      </div>
                      <div className="flex gap-2">
                        <Button 
                          className="flex-1 bg-blue-600 hover:bg-blue-700"
                          onClick={() => window.location.href = '/candidate/browse-tests'}
                        >
                          <Play className="h-4 w-4 mr-2" />
                          Start Package
                        </Button>
                        <Button variant="outline" size="sm">
                          Preview
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>

          {filteredPackages.length === 0 && (
            <div className="text-center py-12">
              <Package className="h-16 w-16 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">No packages found</h3>
              <p className="text-gray-600">Try adjusting your search or category filters</p>
            </div>
          )}

          {/* Custom Package Builder CTA */}
          <Card className="mt-8 bg-gradient-to-r from-indigo-500 to-purple-600 text-white">
            <CardContent className="p-8 text-center">
              <Zap className="h-12 w-12 mx-auto mb-4" />
              <h3 className="text-2xl font-bold mb-2">Can't find the perfect package?</h3>
              <p className="text-indigo-100 mb-6">
                Create a custom certification package tailored to your specific learning goals and career path
              </p>
              <Button className="bg-white text-indigo-600 hover:bg-gray-100">
                <Award className="h-4 w-4 mr-2" />
                Build Custom Package
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </PlatformLayout>
  );
};

export default TestPackageMarketplace;