import PlatformLayout from "@/components/layout/platform-layout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { Target, Search, TrendingUp, Clock, Star, CheckCircle, AlertTriangle, Brain, BookOpen, Zap, Award } from "lucide-react";
import { platformConfigs } from "@/config/complete-navigation";

export default function SkillGapAnalysis() {
  const config = platformConfigs.candidate;

  const skillGaps = [
    {
      skill: "System Design",
      currentLevel: 35,
      targetLevel: 85,
      importance: "Critical",
      marketDemand: 95,
      salaryImpact: "+$25K",
      timeToTarget: "6-8 months",
      resources: ["High-Level System Design", "Designing Data-Intensive Applications", "System Design Interview courses"],
      projects: ["Design a chat application", "Build a URL shortener", "Create a social media feed"],
      gap: 50,
      priority: "high"
    },
    {
      skill: "TypeScript",
      currentLevel: 60,
      targetLevel: 90,
      importance: "High",
      marketDemand: 88,
      salaryImpact: "+$12K",
      timeToTarget: "3-4 months",
      resources: ["TypeScript Handbook", "Advanced TypeScript courses", "Real-world TypeScript projects"],
      projects: ["Migrate React app to TypeScript", "Build type-safe API client", "Create custom utility types"],
      gap: 30,
      priority: "high"
    },
    {
      skill: "DevOps & Cloud",
      currentLevel: 25,
      targetLevel: 75,
      importance: "High",
      marketDemand: 92,
      salaryImpact: "+$18K",
      timeToTarget: "4-6 months",
      resources: ["AWS Certified Developer", "Docker & Kubernetes courses", "CI/CD pipeline tutorials"],
      projects: ["Deploy app to AWS", "Set up CI/CD pipeline", "Container orchestration project"],
      gap: 50,
      priority: "high"
    },
    {
      skill: "Testing & QA",
      currentLevel: 45,
      targetLevel: 80,
      importance: "Medium",
      marketDemand: 75,
      salaryImpact: "+$8K",
      timeToTarget: "2-3 months",
      resources: ["Testing JavaScript Applications", "Jest documentation", "Cypress testing course"],
      projects: ["Achieve 90% test coverage", "E2E testing setup", "Test automation framework"],
      gap: 35,
      priority: "medium"
    },
    {
      skill: "AI/ML Integration",
      currentLevel: 15,
      targetLevel: 70,
      importance: "Emerging",
      marketDemand: 85,
      salaryImpact: "+$15K",
      timeToTarget: "6-9 months",
      resources: ["Machine Learning for Web Developers", "OpenAI API documentation", "TensorFlow.js tutorials"],
      projects: ["Build AI chatbot", "Image recognition app", "Recommendation system"],
      gap: 55,
      priority: "medium"
    },
    {
      skill: "Performance Optimization",
      currentLevel: 50,
      targetLevel: 85,
      importance: "Medium",
      marketDemand: 70,
      salaryImpact: "+$10K",
      timeToTarget: "3-4 months",
      resources: ["Web Performance optimization guides", "Lighthouse documentation", "Performance budgets"],
      projects: ["Optimize bundle size", "Implement lazy loading", "Database query optimization"],
      gap: 35,
      priority: "low"
    }
  ];

  const learningPaths = [
    {
      id: 1,
      title: "Senior Full-Stack Developer Path",
      description: "Complete roadmap to senior-level full-stack development",
      duration: "8-12 months",
      skills: ["System Design", "TypeScript", "DevOps", "Testing"],
      completionRate: 68,
      difficulty: "Advanced"
    },
    {
      id: 2,
      title: "Modern Frontend Specialist",
      description: "Master advanced frontend technologies and patterns",
      duration: "4-6 months",
      skills: ["TypeScript", "Performance", "Testing", "Modern Frameworks"],
      completionRate: 45,
      difficulty: "Intermediate"
    },
    {
      id: 3,
      title: "AI-Enhanced Developer",
      description: "Integrate AI capabilities into web applications",
      duration: "6-9 months",
      skills: ["AI/ML Integration", "Python", "API Design", "Data Processing"],
      completionRate: 20,
      difficulty: "Advanced"
    }
  ];

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "high": return "bg-red-100 text-red-800 border-red-200";
      case "medium": return "bg-orange-100 text-orange-800 border-orange-200";
      case "low": return "bg-yellow-100 text-yellow-800 border-yellow-200";
      default: return "bg-gray-100 text-gray-800 border-gray-200";
    }
  };

  const getImportanceColor = (importance: string) => {
    switch (importance) {
      case "Critical": return "bg-red-100 text-red-800 border-red-200";
      case "High": return "bg-orange-100 text-orange-800 border-orange-200";
      case "Medium": return "bg-yellow-100 text-yellow-800 border-yellow-200";
      case "Emerging": return "bg-purple-100 text-purple-800 border-purple-200";
      default: return "bg-gray-100 text-gray-800 border-gray-200";
    }
  };

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case "Beginner": return "bg-green-100 text-green-800 border-green-200";
      case "Intermediate": return "bg-yellow-100 text-yellow-800 border-yellow-200";
      case "Advanced": return "bg-red-100 text-red-800 border-red-200";
      default: return "bg-gray-100 text-gray-800 border-gray-200";
    }
  };

  return (
    <PlatformLayout
      sidebarTitle={config.sidebarTitle}
      sidebarSubtitle={config.sidebarSubtitle}
      sidebarSections={config.sidebarSections}
      usageData={config.usageData}
    >
      <div className="p-6 max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="text-center space-y-4">
          <div className="flex items-center justify-center space-x-3">
            <div className="p-3 bg-gradient-to-r from-red-500 to-orange-500 rounded-full">
              <Target className="h-8 w-8 text-white" />
            </div>
            <h1 className="text-4xl font-bold bg-gradient-to-r from-red-600 to-orange-600 bg-clip-text text-transparent">
              Skill Gap Analysis
            </h1>
          </div>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            AI-powered analysis of your skill gaps with personalized learning recommendations and career roadmaps
          </p>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card className="bg-gradient-to-r from-red-50 to-orange-50 border-red-200">
            <CardContent className="p-4 text-center">
              <Target className="h-8 w-8 text-red-500 mx-auto mb-2" />
              <p className="text-2xl font-bold text-red-600">6</p>
              <p className="text-sm text-muted-foreground">Skills Analyzed</p>
            </CardContent>
          </Card>
          <Card className="bg-gradient-to-r from-orange-50 to-yellow-50 border-orange-200">
            <CardContent className="p-4 text-center">
              <AlertTriangle className="h-8 w-8 text-orange-500 mx-auto mb-2" />
              <p className="text-2xl font-bold text-orange-600">3</p>
              <p className="text-sm text-muted-foreground">High Priority Gaps</p>
            </CardContent>
          </Card>
          <Card className="bg-gradient-to-r from-green-50 to-emerald-50 border-green-200">
            <CardContent className="p-4 text-center">
              <TrendingUp className="h-8 w-8 text-green-500 mx-auto mb-2" />
              <p className="text-2xl font-bold text-green-600">+$88K</p>
              <p className="text-sm text-muted-foreground">Potential Salary Impact</p>
            </CardContent>
          </Card>
          <Card className="bg-gradient-to-r from-blue-50 to-indigo-50 border-blue-200">
            <CardContent className="p-4 text-center">
              <Clock className="h-8 w-8 text-blue-500 mx-auto mb-2" />
              <p className="text-2xl font-bold text-blue-600">8</p>
              <p className="text-sm text-muted-foreground">Months to Target</p>
            </CardContent>
          </Card>
        </div>

        {/* Search and Filters */}
        <div className="flex flex-col sm:flex-row gap-4 items-center justify-between">
          <div className="flex items-center space-x-2 flex-1">
            <div className="relative flex-1 max-w-md">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
              <Input
                placeholder="Search skills..."
                className="pl-10"
              />
            </div>
          </div>
          <div className="flex items-center space-x-2">
            <Select defaultValue="all">
              <SelectTrigger className="w-40">
                <SelectValue placeholder="Priority" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Priorities</SelectItem>
                <SelectItem value="high">High Priority</SelectItem>
                <SelectItem value="medium">Medium Priority</SelectItem>
                <SelectItem value="low">Low Priority</SelectItem>
              </SelectContent>
            </Select>
            <Select defaultValue="gap">
              <SelectTrigger className="w-40">
                <SelectValue placeholder="Sort by" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="gap">Largest Gap</SelectItem>
                <SelectItem value="priority">Priority</SelectItem>
                <SelectItem value="impact">Salary Impact</SelectItem>
                <SelectItem value="demand">Market Demand</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <Tabs defaultValue="gaps" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="gaps">Skill Gaps</TabsTrigger>
            <TabsTrigger value="paths">Learning Paths</TabsTrigger>
            <TabsTrigger value="roadmap">Personal Roadmap</TabsTrigger>
            <TabsTrigger value="progress">Progress Tracking</TabsTrigger>
          </TabsList>

          <TabsContent value="gaps" className="space-y-6">
            <div className="space-y-6">
              {skillGaps.map((gap, index) => (
                <Card key={index} className="border-l-4 border-l-red-500">
                  <CardHeader>
                    <div className="flex items-start justify-between">
                      <div>
                        <CardTitle className="text-xl">{gap.skill}</CardTitle>
                        <CardDescription>
                          Market demand: {gap.marketDemand}% • Time to target: {gap.timeToTarget}
                        </CardDescription>
                      </div>
                      <div className="flex gap-2">
                        <Badge className={getPriorityColor(gap.priority)}>
                          {gap.priority.charAt(0).toUpperCase() + gap.priority.slice(1)} Priority
                        </Badge>
                        <Badge className={getImportanceColor(gap.importance)}>
                          {gap.importance}
                        </Badge>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                      <div className="space-y-3">
                        <h4 className="font-medium">Skill Level Progress</h4>
                        <div className="space-y-2">
                          <div className="flex justify-between text-sm">
                            <span>Current Level</span>
                            <span className="font-medium">{gap.currentLevel}%</span>
                          </div>
                          <Progress value={gap.currentLevel} className="h-2" />
                        </div>
                        <div className="space-y-2">
                          <div className="flex justify-between text-sm">
                            <span>Target Level</span>
                            <span className="font-medium">{gap.targetLevel}%</span>
                          </div>
                          <Progress value={gap.targetLevel} className="h-2" />
                        </div>
                        <div className="text-center p-3 bg-red-50 border border-red-200 rounded-lg">
                          <div className="text-lg font-bold text-red-600">{gap.gap}%</div>
                          <div className="text-sm text-red-800">Gap to Close</div>
                        </div>
                      </div>

                      <div className="space-y-3">
                        <h4 className="font-medium">Market Impact</h4>
                        <div className="space-y-2">
                          <div className="flex justify-between">
                            <span className="text-sm">Market Demand:</span>
                            <span className="text-sm font-medium">{gap.marketDemand}%</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-sm">Salary Impact:</span>
                            <span className="text-sm font-medium text-green-600">{gap.salaryImpact}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-sm">Time to Target:</span>
                            <span className="text-sm font-medium">{gap.timeToTarget}</span>
                          </div>
                        </div>
                      </div>

                      <div className="space-y-3">
                        <h4 className="font-medium">Recommended Resources</h4>
                        <div className="space-y-1">
                          {gap.resources.slice(0, 3).map((resource, i) => (
                            <div key={i} className="flex items-start gap-2 text-xs text-muted-foreground">
                              <BookOpen className="h-3 w-3 text-red-500 mt-0.5" />
                              {resource}
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>

                    <div className="space-y-3">
                      <h4 className="font-medium">Suggested Projects</h4>
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                        {gap.projects.map((project, i) => (
                          <div key={i} className="p-3 bg-orange-50 border border-orange-200 rounded-lg">
                            <div className="flex items-center gap-2">
                              <Zap className="h-4 w-4 text-orange-500" />
                              <span className="text-sm font-medium text-orange-800">{project}</span>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>

                    <div className="flex gap-2">
                      <Button className="bg-gradient-to-r from-red-500 to-orange-500 hover:from-red-600 hover:to-orange-600">
                        <Target className="h-4 w-4 mr-2" />
                        Start Learning Plan
                      </Button>
                      <Button variant="outline">
                        <BookOpen className="h-4 w-4 mr-2" />
                        View Resources
                      </Button>
                      <Button variant="outline">
                        <Star className="h-4 w-4 mr-2" />
                        Track Progress
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="paths" className="space-y-6">
            <h3 className="text-xl font-bold text-red-700">Structured Learning Paths</h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {learningPaths.map((path) => (
                <Card key={path.id} className="hover:shadow-lg transition-all duration-300 hover:-translate-y-1 border-l-4 border-l-red-500">
                  <CardHeader className="pb-3">
                    <CardTitle className="text-lg">{path.title}</CardTitle>
                    <CardDescription>{path.description}</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-muted-foreground">Duration:</span>
                      <span className="font-medium">{path.duration}</span>
                    </div>
                    
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span>Progress</span>
                        <span className="font-medium">{path.completionRate}%</span>
                      </div>
                      <Progress value={path.completionRate} className="h-2" />
                    </div>

                    <div className="space-y-2">
                      <h4 className="text-sm font-medium">Key Skills</h4>
                      <div className="flex flex-wrap gap-1">
                        {path.skills.map((skill, index) => (
                          <Badge key={index} variant="outline" className="text-xs">
                            {skill}
                          </Badge>
                        ))}
                      </div>
                    </div>

                    <div className="flex items-center justify-between">
                      <Badge className={getDifficultyColor(path.difficulty)}>
                        {path.difficulty}
                      </Badge>
                    </div>

                    <Button className="w-full bg-gradient-to-r from-red-500 to-orange-500 hover:from-red-600 hover:to-orange-600">
                      <Brain className="h-4 w-4 mr-2" />
                      Start Learning Path
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="roadmap" className="space-y-6">
            <h3 className="text-xl font-bold text-red-700">Personalized Learning Roadmap</h3>
            
            <Card>
              <CardHeader>
                <CardTitle>Your 12-Month Development Plan</CardTitle>
                <CardDescription>AI-generated roadmap based on your current skills and career goals</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  {[
                    { phase: "Phase 1", duration: "Months 1-3", focus: "Foundation Building", skills: ["TypeScript", "Testing"], priority: "High" },
                    { phase: "Phase 2", duration: "Months 4-6", focus: "System Design Mastery", skills: ["System Design", "DevOps"], priority: "High" },
                    { phase: "Phase 3", duration: "Months 7-9", focus: "Advanced Topics", skills: ["Performance", "AI/ML"], priority: "Medium" },
                    { phase: "Phase 4", duration: "Months 10-12", focus: "Specialization", skills: ["Advanced Patterns", "Leadership"], priority: "Medium" }
                  ].map((phase, index) => (
                    <div key={index} className="border rounded-lg p-4">
                      <div className="flex items-center justify-between mb-3">
                        <div>
                          <h4 className="font-semibold text-lg">{phase.phase}: {phase.focus}</h4>
                          <p className="text-sm text-muted-foreground">{phase.duration}</p>
                        </div>
                        <Badge className={getPriorityColor(phase.priority.toLowerCase())}>
                          {phase.priority} Priority
                        </Badge>
                      </div>
                      <div className="flex flex-wrap gap-2">
                        {phase.skills.map((skill, i) => (
                          <Badge key={i} variant="secondary" className="text-xs">
                            {skill}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Career Milestones</CardTitle>
                <CardDescription>Key achievements to unlock throughout your journey</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {[
                    { milestone: "Complete TypeScript Migration", target: "Month 2", reward: "TypeScript Specialist Badge" },
                    { milestone: "Deploy First Cloud Application", target: "Month 4", reward: "Cloud Developer Certificate" },
                    { milestone: "Design Scalable System", target: "Month 6", reward: "System Architect Recognition" },
                    { milestone: "Lead Technical Project", target: "Month 9", reward: "Technical Leadership Badge" },
                    { milestone: "Mentor Junior Developer", target: "Month 12", reward: "Mentor Certification" }
                  ].map((item, index) => (
                    <div key={index} className="flex items-center gap-4">
                      <div className="w-8 h-8 bg-red-500 rounded-full flex items-center justify-center text-white font-bold text-sm">
                        {index + 1}
                      </div>
                      <div className="flex-1">
                        <h4 className="font-medium">{item.milestone}</h4>
                        <div className="flex gap-2 mt-1">
                          <span className="text-sm text-muted-foreground">Target: {item.target}</span>
                          <Badge variant="outline" className="text-xs">
                            <Award className="h-3 w-3 mr-1" />
                            {item.reward}
                          </Badge>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="progress" className="space-y-6">
            <h3 className="text-xl font-bold text-red-700">Progress Tracking</h3>
            
            <Card>
              <CardHeader>
                <CardTitle>Overall Development Progress</CardTitle>
                <CardDescription>Track your skill development across all areas</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  <div className="text-center">
                    <div className="text-4xl font-bold text-red-600 mb-2">42%</div>
                    <div className="text-muted-foreground">Overall Progress to Target Skills</div>
                    <Progress value={42} className="h-3 mt-4" />
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <h4 className="font-medium mb-3">This Month's Achievements</h4>
                      <div className="space-y-2">
                        <div className="flex items-center gap-2 p-2 bg-green-50 border border-green-200 rounded">
                          <CheckCircle className="h-4 w-4 text-green-500" />
                          <span className="text-sm">Completed TypeScript basics course</span>
                        </div>
                        <div className="flex items-center gap-2 p-2 bg-green-50 border border-green-200 rounded">
                          <CheckCircle className="h-4 w-4 text-green-500" />
                          <span className="text-sm">Built first TypeScript project</span>
                        </div>
                        <div className="flex items-center gap-2 p-2 bg-blue-50 border border-blue-200 rounded">
                          <Clock className="h-4 w-4 text-blue-500" />
                          <span className="text-sm">In progress: System design fundamentals</span>
                        </div>
                      </div>
                    </div>

                    <div>
                      <h4 className="font-medium mb-3">Upcoming Targets</h4>
                      <div className="space-y-2">
                        <div className="flex items-center gap-2 p-2 border rounded">
                          <Target className="h-4 w-4 text-orange-500" />
                          <span className="text-sm">Complete advanced TypeScript patterns</span>
                        </div>
                        <div className="flex items-center gap-2 p-2 border rounded">
                          <Target className="h-4 w-4 text-orange-500" />
                          <span className="text-sm">Start system design case studies</span>
                        </div>
                        <div className="flex items-center gap-2 p-2 border rounded">
                          <Target className="h-4 w-4 text-orange-500" />
                          <span className="text-sm">Set up first CI/CD pipeline</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </PlatformLayout>
  );
}