import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import PlatformLayout from "@/components/layout/platform-layout";
import { candidateNavigation } from "@/config/complete-navigation";
import { 
  TrendingUp, Award, Target, Zap, Clock, Star,
  BarChart3, PieChart, Activity, Brain, Code,
  CheckCircle, AlertCircle, ArrowUp, ArrowDown,
  Trophy, Shield, Lightbulb, Rocket, Calendar
} from "lucide-react";

const SkillsAnalytics: React.FC = () => {
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [timeRange, setTimeRange] = useState('3m');
  
  // Skills mastery data with color coding
  const skillsData = [
    { skill: 'React.js', level: 92, growth: +15, category: 'Frontend', color: 'from-blue-400 to-blue-600', tests: 8, hours: 45 },
    { skill: 'TypeScript', level: 89, growth: +12, category: 'Frontend', color: 'from-indigo-400 to-indigo-600', tests: 6, hours: 38 },
    { skill: 'Node.js', level: 85, growth: +18, category: 'Backend', color: 'from-green-400 to-green-600', tests: 7, hours: 42 },
    { skill: 'Python', level: 78, growth: +22, category: 'Backend', color: 'from-yellow-400 to-yellow-600', tests: 5, hours: 35 },
    { skill: 'PostgreSQL', level: 82, growth: +8, category: 'Database', color: 'from-purple-400 to-purple-600', tests: 4, hours: 28 },
    { skill: 'Docker', level: 75, growth: +25, category: 'DevOps', color: 'from-cyan-400 to-cyan-600', tests: 3, hours: 22 },
    { skill: 'AWS', level: 71, growth: +20, category: 'Cloud', color: 'from-orange-400 to-orange-600', tests: 4, hours: 30 },
    { skill: 'GraphQL', level: 68, growth: +30, category: 'API', color: 'from-pink-400 to-pink-600', tests: 3, hours: 18 }
  ];

  const performanceMetrics = {
    overall: { score: 87, change: +5, rank: 'Top 12%' },
    testSuccess: { score: 84, change: +8, total: 45 },
    projectQuality: { score: 91, change: +3, projects: 12 },
    learningVelocity: { score: 89, change: +12, hours: 156 }
  };

  const certificationProgress = [
    { name: 'React Expert', progress: 92, timeLeft: '3 days', difficulty: 'Advanced', color: 'bg-blue-500' },
    { name: 'AWS Cloud Practitioner', progress: 67, timeLeft: '2 weeks', difficulty: 'Intermediate', color: 'bg-orange-500' },
    { name: 'Full-Stack Developer', progress: 78, timeLeft: '1 week', difficulty: 'Expert', color: 'bg-purple-500' },
    { name: 'DevOps Engineer', progress: 45, timeLeft: '1 month', difficulty: 'Advanced', color: 'bg-cyan-500' }
  ];

  const skillGaps = [
    { skill: 'System Design', importance: 'High', impact: '+25% salary potential', urgency: 'high' },
    { skill: 'Microservices', importance: 'Medium', impact: '+15% job opportunities', urgency: 'medium' },
    { skill: 'Kubernetes', importance: 'High', impact: '+30% DevOps roles', urgency: 'high' },
    { skill: 'Machine Learning', importance: 'Low', impact: '+20% future-proofing', urgency: 'low' }
  ];

  const categories = ['all', 'Frontend', 'Backend', 'Database', 'DevOps', 'Cloud', 'API'];

  const filteredSkills = selectedCategory === 'all' 
    ? skillsData 
    : skillsData.filter(skill => skill.category === selectedCategory);

  return (
    <PlatformLayout 
      sidebarTitle="Candidate Platform"
      sidebarSubtitle="Professional Development Hub"
      sidebarSections={candidateNavigation}
    >
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-emerald-50 to-teal-50 p-6">
        {/* Header Section */}
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-2">
            <div className="p-2 bg-gradient-to-br from-emerald-500 to-teal-600 rounded-lg text-white">
              <TrendingUp className="h-6 w-6" />
            </div>
            <h1 className="text-3xl font-bold bg-gradient-to-r from-emerald-600 to-teal-600 bg-clip-text text-transparent">
              Skills & Performance Analytics
            </h1>
          </div>
          <p className="text-gray-600 text-lg">
            Comprehensive analysis of your technical skills growth and performance metrics
          </p>
        </div>

        {/* Control Filters */}
        <div className="flex flex-wrap gap-4 mb-6">
          <div className="flex gap-2">
            <span className="text-sm font-medium text-gray-700 self-center">Category:</span>
            {categories.map((category) => (
              <Button
                key={category}
                variant={selectedCategory === category ? "default" : "outline"}
                size="sm"
                onClick={() => setSelectedCategory(category)}
                className={selectedCategory === category ? "bg-gradient-to-r from-emerald-500 to-teal-600" : ""}
              >
                {category === 'all' ? 'All Skills' : category}
              </Button>
            ))}
          </div>
          <div className="flex gap-2">
            <span className="text-sm font-medium text-gray-700 self-center">Period:</span>
            {['1m', '3m', '6m', '1y'].map((period) => (
              <Button
                key={period}
                variant={timeRange === period ? "default" : "outline"}
                size="sm"
                onClick={() => setTimeRange(period)}
                className={timeRange === period ? "bg-gradient-to-r from-emerald-500 to-teal-600" : ""}
              >
                {period === '1m' ? '1 Month' : period === '3m' ? '3 Months' : period === '6m' ? '6 Months' : '1 Year'}
              </Button>
            ))}
          </div>
        </div>

        {/* Performance Overview Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card className="border-0 shadow-lg bg-white/80 backdrop-blur-sm">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="p-3 bg-gradient-to-br from-emerald-500 to-emerald-600 rounded-lg text-white">
                  <Award className="h-6 w-6" />
                </div>
                <div className="flex items-center gap-1 px-2 py-1 rounded-full text-sm bg-emerald-100 text-emerald-700">
                  <ArrowUp className="h-3 w-3" />
                  {performanceMetrics.overall.change}
                </div>
              </div>
              <div className="text-2xl font-bold text-gray-900 mb-1">{performanceMetrics.overall.score}/100</div>
              <div className="text-sm text-gray-600">Overall Performance</div>
              <div className="text-xs text-emerald-600 font-medium mt-1">{performanceMetrics.overall.rank}</div>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-lg bg-white/80 backdrop-blur-sm">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="p-3 bg-gradient-to-br from-blue-500 to-blue-600 rounded-lg text-white">
                  <Target className="h-6 w-6" />
                </div>
                <div className="flex items-center gap-1 px-2 py-1 rounded-full text-sm bg-blue-100 text-blue-700">
                  <ArrowUp className="h-3 w-3" />
                  {performanceMetrics.testSuccess.change}
                </div>
              </div>
              <div className="text-2xl font-bold text-gray-900 mb-1">{performanceMetrics.testSuccess.score}%</div>
              <div className="text-sm text-gray-600">Test Success Rate</div>
              <div className="text-xs text-blue-600 font-medium mt-1">{performanceMetrics.testSuccess.total} tests taken</div>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-lg bg-white/80 backdrop-blur-sm">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="p-3 bg-gradient-to-br from-purple-500 to-purple-600 rounded-lg text-white">
                  <Star className="h-6 w-6" />
                </div>
                <div className="flex items-center gap-1 px-2 py-1 rounded-full text-sm bg-purple-100 text-purple-700">
                  <ArrowUp className="h-3 w-3" />
                  {performanceMetrics.projectQuality.change}
                </div>
              </div>
              <div className="text-2xl font-bold text-gray-900 mb-1">{performanceMetrics.projectQuality.score}/100</div>
              <div className="text-sm text-gray-600">Project Quality</div>
              <div className="text-xs text-purple-600 font-medium mt-1">{performanceMetrics.projectQuality.projects} projects</div>
            </CardContent>
          </Card>

          <Card className="border-0 shadow-lg bg-white/80 backdrop-blur-sm">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="p-3 bg-gradient-to-br from-orange-500 to-orange-600 rounded-lg text-white">
                  <Zap className="h-6 w-6" />
                </div>
                <div className="flex items-center gap-1 px-2 py-1 rounded-full text-sm bg-orange-100 text-orange-700">
                  <ArrowUp className="h-3 w-3" />
                  {performanceMetrics.learningVelocity.change}
                </div>
              </div>
              <div className="text-2xl font-bold text-gray-900 mb-1">{performanceMetrics.learningVelocity.score}/100</div>
              <div className="text-sm text-gray-600">Learning Velocity</div>
              <div className="text-xs text-orange-600 font-medium mt-1">{performanceMetrics.learningVelocity.hours} hours</div>
            </CardContent>
          </Card>
        </div>

        <Tabs defaultValue="skills" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4 bg-white/80 backdrop-blur-sm">
            <TabsTrigger value="skills">Skills Mastery</TabsTrigger>
            <TabsTrigger value="certifications">Certifications</TabsTrigger>
            <TabsTrigger value="gaps">Skill Gaps</TabsTrigger>
            <TabsTrigger value="trends">Growth Trends</TabsTrigger>
          </TabsList>

          <TabsContent value="skills" className="space-y-6">
            <Card className="border-0 shadow-lg bg-white/80 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Code className="h-5 w-5 text-emerald-500" />
                  Technical Skills Proficiency
                </CardTitle>
                <CardDescription>
                  Detailed breakdown of your technical skills with growth indicators
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  {filteredSkills.map((skill, index) => (
                    <div key={index} className="p-6 bg-gradient-to-br from-gray-50 to-gray-100 rounded-lg">
                      <div className="flex items-center justify-between mb-4">
                        <div className="flex items-center gap-3">
                          <div className={`w-4 h-4 rounded-full bg-gradient-to-r ${skill.color}`} />
                          <div>
                            <div className="font-semibold text-gray-900 text-lg">{skill.skill}</div>
                            <div className="text-sm text-gray-600">{skill.category}</div>
                          </div>
                        </div>
                        <div className="flex items-center gap-4">
                          <div className="text-right">
                            <div className="text-2xl font-bold text-gray-900">{skill.level}%</div>
                            <div className={`text-sm font-medium ${
                              skill.growth > 0 ? 'text-emerald-600' : 'text-red-600'
                            }`}>
                              {skill.growth > 0 ? '+' : ''}{skill.growth}% growth
                            </div>
                          </div>
                        </div>
                      </div>
                      
                      <Progress value={skill.level} className="mb-4 h-3 bg-gray-200">
                        <div className={`h-full bg-gradient-to-r ${skill.color} rounded-full transition-all duration-500`} 
                             style={{ width: `${skill.level}%` }} />
                      </Progress>
                      
                      <div className="grid grid-cols-3 gap-4 text-center">
                        <div className="p-3 bg-white rounded-lg">
                          <div className="text-lg font-bold text-blue-600">{skill.tests}</div>
                          <div className="text-xs text-gray-600">Tests Completed</div>
                        </div>
                        <div className="p-3 bg-white rounded-lg">
                          <div className="text-lg font-bold text-purple-600">{skill.hours}h</div>
                          <div className="text-xs text-gray-600">Practice Time</div>
                        </div>
                        <div className="p-3 bg-white rounded-lg">
                          <div className="text-lg font-bold text-emerald-600">
                            {skill.level >= 90 ? 'Expert' : skill.level >= 75 ? 'Advanced' : skill.level >= 60 ? 'Intermediate' : 'Beginner'}
                          </div>
                          <div className="text-xs text-gray-600">Skill Level</div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="certifications" className="space-y-6">
            <Card className="border-0 shadow-lg bg-white/80 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Trophy className="h-5 w-5 text-yellow-500" />
                  Certification Progress Tracking
                </CardTitle>
                <CardDescription>
                  Monitor your progress towards professional certifications
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  {certificationProgress.map((cert, index) => (
                    <div key={index} className="p-6 bg-gradient-to-br from-gray-50 to-gray-100 rounded-lg">
                      <div className="flex items-center justify-between mb-4">
                        <div>
                          <div className="font-semibold text-gray-900 text-lg">{cert.name}</div>
                          <div className="flex items-center gap-2 mt-1">
                            <Badge variant="outline" className="text-gray-600">
                              {cert.difficulty}
                            </Badge>
                            <span className="text-sm text-gray-600">Estimated: {cert.timeLeft}</span>
                          </div>
                        </div>
                        <div className="text-right">
                          <div className="text-2xl font-bold text-gray-900">{cert.progress}%</div>
                          <div className="text-sm text-gray-600">Complete</div>
                        </div>
                      </div>
                      
                      <Progress value={cert.progress} className="mb-4 h-4 bg-gray-200">
                        <div className={`h-full ${cert.color} rounded-full transition-all duration-500`} 
                             style={{ width: `${cert.progress}%` }} />
                      </Progress>
                      
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-gray-600">
                          {cert.progress >= 90 ? 'Almost there!' : cert.progress >= 70 ? 'Good progress' : cert.progress >= 50 ? 'Halfway point' : 'Getting started'}
                        </span>
                        <span className="font-medium text-gray-900">
                          {100 - cert.progress}% remaining
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="gaps" className="space-y-6">
            <Card className="border-0 shadow-lg bg-white/80 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <AlertCircle className="h-5 w-5 text-amber-500" />
                  Strategic Skill Gap Analysis
                </CardTitle>
                <CardDescription>
                  Identified skill gaps with career impact assessment and learning recommendations
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {skillGaps.map((gap, index) => (
                    <div key={index} className={`p-6 rounded-lg border-l-4 ${
                      gap.urgency === 'high' ? 'border-red-400 bg-gradient-to-r from-red-50 to-red-100' :
                      gap.urgency === 'medium' ? 'border-yellow-400 bg-gradient-to-r from-yellow-50 to-yellow-100' :
                      'border-green-400 bg-gradient-to-r from-green-50 to-green-100'
                    }`}>
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <div className="flex items-center gap-3 mb-2">
                            <div className="font-semibold text-gray-900 text-lg">{gap.skill}</div>
                            <Badge className={`${
                              gap.urgency === 'high' ? 'bg-red-600' :
                              gap.urgency === 'medium' ? 'bg-yellow-600' :
                              'bg-green-600'
                            } text-white`}>
                              {gap.importance} Priority
                            </Badge>
                          </div>
                          <div className="text-gray-700 mb-3">
                            <strong>Career Impact:</strong> {gap.impact}
                          </div>
                          <div className="flex gap-2">
                            <Button size="sm" className="bg-gradient-to-r from-blue-500 to-purple-600">
                              Start Learning Path
                            </Button>
                            <Button size="sm" variant="outline">
                              Find Courses
                            </Button>
                          </div>
                        </div>
                        <div className={`p-2 rounded-lg ${
                          gap.urgency === 'high' ? 'bg-red-200' :
                          gap.urgency === 'medium' ? 'bg-yellow-200' :
                          'bg-green-200'
                        }`}>
                          {gap.urgency === 'high' ? (
                            <AlertCircle className="h-5 w-5 text-red-600" />
                          ) : gap.urgency === 'medium' ? (
                            <Clock className="h-5 w-5 text-yellow-600" />
                          ) : (
                            <CheckCircle className="h-5 w-5 text-green-600" />
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="trends" className="space-y-6">
            <Card className="border-0 shadow-lg bg-white/80 backdrop-blur-sm">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <BarChart3 className="h-5 w-5 text-blue-500" />
                  Skills Growth Trends & Predictions
                </CardTitle>
                <CardDescription>
                  Historical growth patterns and AI-powered future skill recommendations
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  {/* Growth Trends Visualization */}
                  <div className="p-6 bg-gradient-to-br from-blue-50 to-indigo-100 rounded-lg">
                    <div className="flex items-center gap-3 mb-4">
                      <Rocket className="h-6 w-6 text-blue-600" />
                      <div className="font-semibold text-blue-900 text-lg">Fastest Growing Skills</div>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <div className="text-center p-4 bg-white rounded-lg">
                        <div className="text-2xl font-bold text-blue-600 mb-1">+30%</div>
                        <div className="text-sm text-blue-700">GraphQL</div>
                        <div className="text-xs text-gray-600">3 months</div>
                      </div>
                      <div className="text-center p-4 bg-white rounded-lg">
                        <div className="text-2xl font-bold text-cyan-600 mb-1">+25%</div>
                        <div className="text-sm text-cyan-700">Docker</div>
                        <div className="text-xs text-gray-600">3 months</div>
                      </div>
                      <div className="text-center p-4 bg-white rounded-lg">
                        <div className="text-2xl font-bold text-purple-600 mb-1">+22%</div>
                        <div className="text-sm text-purple-700">Python</div>
                        <div className="text-xs text-gray-600">3 months</div>
                      </div>
                    </div>
                  </div>

                  {/* AI Predictions */}
                  <div className="p-6 bg-gradient-to-br from-purple-50 to-violet-100 rounded-lg">
                    <div className="flex items-center gap-3 mb-4">
                      <Brain className="h-6 w-6 text-purple-600" />
                      <div className="font-semibold text-purple-900 text-lg">AI-Powered Growth Predictions</div>
                    </div>
                    <div className="space-y-4">
                      <div className="flex items-center justify-between p-4 bg-white rounded-lg">
                        <div>
                          <div className="font-medium text-gray-900">React.js → Expert Level</div>
                          <div className="text-sm text-gray-600">Based on current trajectory</div>
                        </div>
                        <div className="text-right">
                          <div className="font-bold text-purple-600">2 weeks</div>
                          <div className="text-xs text-gray-600">95% confidence</div>
                        </div>
                      </div>
                      <div className="flex items-center justify-between p-4 bg-white rounded-lg">
                        <div>
                          <div className="font-medium text-gray-900">System Design Mastery</div>
                          <div className="text-sm text-gray-600">Recommended next focus</div>
                        </div>
                        <div className="text-right">
                          <div className="font-bold text-blue-600">6 weeks</div>
                          <div className="text-xs text-gray-600">High impact</div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </PlatformLayout>
  );
};

export default SkillsAnalytics;