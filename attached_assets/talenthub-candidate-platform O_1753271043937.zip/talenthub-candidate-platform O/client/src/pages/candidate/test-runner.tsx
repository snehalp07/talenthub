import { useState, useEffect } from "react";
import { useRoute } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Clock, CheckCircle, AlertCircle, ArrowLeft, ArrowRight, Code } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import Editor from "@monaco-editor/react";
import PlatformLayout from "@/components/layout/platform-layout";
import { platformConfigs } from "@/config/complete-navigation";

interface Question {
  id: string;
  type: string;
  title: string;
  content: string;
  options?: string[];
  correctAnswer: string;
  explanation: string;
  points: number;
  order: number;
  tags: string[];
}

interface Test {
  id: string;
  title: string;
  description: string;
  duration: number;
  totalQuestions: number;
  passingScore: number;
  difficulty: string;
  category: string;
  questions: Question[];
}

function TestRunnerContent() {
  const [, params] = useRoute("/candidate/test-runner/:testId");
  const testId = params?.testId;
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [answers, setAnswers] = useState<Record<string, string>>({});
  const [timeRemaining, setTimeRemaining] = useState(0);
  const [testStarted, setTestStarted] = useState(false);
  const [testCompleted, setTestCompleted] = useState(false);
  const { toast } = useToast();

  // Fetch test with questions
  const { data: test, isLoading } = useQuery<Test>({
    queryKey: ["/api/candidate/tests", testId],
    queryFn: async () => {
      const response = await fetch(`/api/candidate/tests/${testId}`);
      if (!response.ok) throw new Error("Failed to fetch test");
      return response.json();
    },
    enabled: !!testId,
  });

  // Submit test attempt
  const submitTestMutation = useMutation({
    mutationFn: async (testData: { testId: string; answers: Record<string, string>; timeSpent: number }) => {
      const response = await fetch("/api/candidate/test-attempts", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(testData),
      });
      if (!response.ok) throw new Error("Failed to submit test");
      return response.json();
    },
    onSuccess: (data) => {
      toast({
        title: "Test Submitted Successfully",
        description: `Score: ${data.score}%. ${data.certificationEarned ? '🎉 Certificate earned!' : 'Badge earned!'}`,
      });
      setTestCompleted(true);
    },
    onError: () => {
      toast({
        title: "Submission Failed",
        description: "Failed to submit test. Please try again.",
        variant: "destructive",
      });
    },
  });

  // Timer effect
  useEffect(() => {
    if (!testStarted || !test || timeRemaining <= 0) return;

    const timer = setInterval(() => {
      setTimeRemaining((prev) => {
        if (prev <= 1) {
          handleSubmitTest();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [testStarted, test, timeRemaining]);

  const startTest = () => {
    if (test) {
      setTimeRemaining(test.duration * 60); // Convert minutes to seconds
      setTestStarted(true);
    }
  };

  const handleAnswerChange = (questionId: string, answer: string) => {
    setAnswers((prev) => ({
      ...prev,
      [questionId]: answer,
    }));
  };

  const handleSubmitTest = () => {
    if (!test) return;

    const timeSpent = (test.duration * 60) - timeRemaining;
    submitTestMutation.mutate({
      testId: test.id,
      answers,
      timeSpent,
    });
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const calculateScore = () => {
    if (!test) return 0;
    
    let correctAnswers = 0;
    let totalPoints = 0;
    let earnedPoints = 0;

    test.questions.forEach((question) => {
      totalPoints += question.points;
      if (answers[question.id] === question.correctAnswer) {
        correctAnswers++;
        earnedPoints += question.points;
      }
    });

    return Math.round((earnedPoints / totalPoints) * 100);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin w-8 h-8 border-4 border-sky-500 border-t-transparent rounded-full"></div>
      </div>
    );
  }

  if (!test) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Card className="w-96">
          <CardContent className="p-6 text-center">
            <AlertCircle className="w-12 h-12 text-red-500 mx-auto mb-4" />
            <h2 className="text-xl font-semibold mb-2">Test Not Found</h2>
            <p className="text-gray-600 mb-4">The requested test could not be found.</p>
            <Button onClick={() => window.location.href = '/candidate/skill-tests'}>
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Tests
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (testCompleted) {
    const score = calculateScore();
    const passed = score >= test.passingScore;

    return (
      <div className="min-h-screen bg-gray-50 py-8">
        <div className="max-w-4xl mx-auto px-6">
          <Card className="w-full">
            <CardHeader className="text-center">
              <div className={`w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4 ${
                passed ? 'bg-green-100' : 'bg-red-100'
              }`}>
                {passed ? (
                  <CheckCircle className="w-8 h-8 text-green-600" />
                ) : (
                  <AlertCircle className="w-8 h-8 text-red-600" />
                )}
              </div>
              <CardTitle className="text-2xl mb-2">
                {passed ? 'Congratulations!' : 'Test Complete'}
              </CardTitle>
              <p className="text-gray-600">
                {passed ? 'You have successfully passed the test!' : 'You can retake this test to improve your score.'}
              </p>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-center">
                <div className="bg-gray-50 p-4 rounded-lg">
                  <div className="text-2xl font-bold text-sky-600">{score}%</div>
                  <div className="text-sm text-gray-600">Your Score</div>
                </div>
                <div className="bg-gray-50 p-4 rounded-lg">
                  <div className="text-2xl font-bold text-gray-700">{test.passingScore}%</div>
                  <div className="text-sm text-gray-600">Passing Score</div>
                </div>
                <div className="bg-gray-50 p-4 rounded-lg">
                  <div className="text-2xl font-bold text-gray-700">
                    {Object.keys(answers).length}/{test.questions.length}
                  </div>
                  <div className="text-sm text-gray-600">Questions Answered</div>
                </div>
              </div>

              <div className="flex gap-4 justify-center">
                <Button 
                  onClick={() => window.location.href = '/candidate/test-results'}
                  className="bg-sky-600 hover:bg-sky-700"
                >
                  View Results & Analytics
                </Button>
                <Button 
                  variant="outline"
                  onClick={() => window.location.href = '/candidate/skill-tests'}
                >
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  Back to Tests
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  if (!testStarted) {
    return (
      <div className="min-h-screen bg-gray-50 py-8">
        <div className="max-w-4xl mx-auto px-6">
          <Card className="w-full">
            <CardHeader>
              <CardTitle className="text-2xl">{test.title}</CardTitle>
              <p className="text-gray-600">{test.description}</p>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="bg-gray-50 p-4 rounded-lg text-center">
                  <Clock className="w-6 h-6 text-sky-600 mx-auto mb-2" />
                  <div className="font-semibold">{test.duration} minutes</div>
                  <div className="text-sm text-gray-600">Duration</div>
                </div>
                <div className="bg-gray-50 p-4 rounded-lg text-center">
                  <div className="font-semibold">{test.totalQuestions} questions</div>
                  <div className="text-sm text-gray-600">Total Questions</div>
                </div>
                <div className="bg-gray-50 p-4 rounded-lg text-center">
                  <div className="font-semibold">{test.passingScore}%</div>
                  <div className="text-sm text-gray-600">Passing Score</div>
                </div>
              </div>

              <div className="space-y-2">
                <Badge variant="outline">{test.difficulty}</Badge>
                <Badge variant="secondary">{test.category}</Badge>
              </div>

              <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
                <h3 className="font-semibold text-yellow-800 mb-2">Instructions:</h3>
                <ul className="text-sm text-yellow-700 space-y-1">
                  <li>• You have {test.duration} minutes to complete this test</li>
                  <li>• Answer all questions to the best of your ability</li>
                  <li>• You cannot go back once you submit</li>
                  <li>• The test will auto-submit when time expires</li>
                </ul>
              </div>

              <div className="flex gap-4 justify-center">
                <Button 
                  variant="outline"
                  onClick={() => window.location.href = '/candidate/skill-tests'}
                >
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  Cancel
                </Button>
                <Button onClick={startTest} className="bg-sky-600 hover:bg-sky-700">
                  Start Test
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  const currentQuestion = test.questions[currentQuestionIndex];
  const progress = ((currentQuestionIndex + 1) / test.questions.length) * 100;

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-4xl mx-auto px-6">
        {/* Header */}
        <div className="bg-white rounded-lg shadow-sm p-4 mb-6">
          <div className="flex items-center justify-between mb-4">
            <h1 className="text-xl font-semibold">{test.title}</h1>
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2 text-orange-600">
                <Clock className="w-4 h-4" />
                <span className="font-mono font-semibold">{formatTime(timeRemaining)}</span>
              </div>
              <Badge variant="outline">
                Question {currentQuestionIndex + 1} of {test.questions.length}
              </Badge>
            </div>
          </div>
          <Progress value={progress} className="h-2" />
        </div>

        {/* Question */}
        <Card className="mb-6">
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="text-lg">
                {currentQuestion.title}
              </CardTitle>
              <Badge variant="secondary">{currentQuestion.points} pts</Badge>
            </div>
            <p className="text-gray-600">{currentQuestion.content}</p>
          </CardHeader>
          <CardContent>
            {currentQuestion.type === 'multiple_choice' && currentQuestion.options ? (
              <RadioGroup
                value={answers[currentQuestion.id] || ""}
                onValueChange={(value) => handleAnswerChange(currentQuestion.id, value)}
              >
                {currentQuestion.options.map((option, index) => (
                  <div key={index} className="flex items-center space-x-2">
                    <RadioGroupItem value={option} id={`option-${index}`} />
                    <Label htmlFor={`option-${index}`} className="flex-1 cursor-pointer">
                      {option}
                    </Label>
                  </div>
                ))}
              </RadioGroup>
            ) : currentQuestion.type === 'coding' ? (
              <div className="space-y-3">
                <div className="flex items-center gap-2">
                  <Code className="w-4 h-4 text-sky-600" />
                  <Label className="text-sm font-medium">Code Editor (JavaScript)</Label>
                </div>
                <div className="border rounded-lg overflow-hidden bg-gray-900">
                  <Editor
                    height="300px"
                    defaultLanguage="javascript"
                    theme="vs-dark"
                    value={answers[currentQuestion.id] || "// Write your solution here\nfunction solution() {\n  \n}"}
                    onChange={(value) => handleAnswerChange(currentQuestion.id, value || "")}
                    options={{
                      minimap: { enabled: false },
                      scrollBeyondLastLine: false,
                      fontSize: 14,
                      lineNumbers: "on",
                      wordWrap: "on",
                      automaticLayout: true,
                      theme: "vs-dark",
                    }}
                  />
                </div>
                <div className="text-xs text-gray-500">
                  Use JavaScript syntax. Test your solution before submitting.
                </div>
              </div>
            ) : (
              <div className="space-y-3">
                <Label htmlFor="answer">Your Answer:</Label>
                <Textarea
                  id="answer"
                  placeholder="Write your detailed answer here..."
                  value={answers[currentQuestion.id] || ""}
                  onChange={(e) => handleAnswerChange(currentQuestion.id, e.target.value)}
                  rows={8}
                  className="resize-none"
                />
              </div>
            )}
          </CardContent>
        </Card>

        {/* Navigation */}
        <div className="flex items-center justify-between">
          <Button
            variant="outline"
            onClick={() => setCurrentQuestionIndex(Math.max(0, currentQuestionIndex - 1))}
            disabled={currentQuestionIndex === 0}
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Previous
          </Button>

          <div className="flex gap-2">
            {currentQuestionIndex === test.questions.length - 1 ? (
              <Button
                onClick={handleSubmitTest}
                disabled={submitTestMutation.isPending}
                className="bg-green-600 hover:bg-green-700"
              >
                {submitTestMutation.isPending ? "Submitting..." : "Submit Test"}
              </Button>
            ) : (
              <Button
                onClick={() => setCurrentQuestionIndex(Math.min(test.questions.length - 1, currentQuestionIndex + 1))}
              >
                Next
                <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

export default function TestRunner() {
  const config = platformConfigs.candidate;
  
  const usageData = [
    { label: "Test Progress", current: 65, max: 100 },
    { label: "Time Remaining", current: 45, max: 60 },
    { label: "Questions Answered", current: 8, max: 15 },
  ];

  return (
    <PlatformLayout
      sidebarTitle={config.sidebarTitle}
      sidebarSubtitle={config.sidebarSubtitle}
      sidebarSections={config.sidebarSections}
      usageData={usageData}
    >
      <TestRunnerContent />
    </PlatformLayout>
  );
}