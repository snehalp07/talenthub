import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import PlatformLayout from "@/components/layout/platform-layout";
import { candidateNavigation } from "@/config/complete-navigation";
import { 
  Focus, Target, AlertTriangle, TrendingUp, CheckCircle,
  Star, Clock, Play, BookOpen, Brain, Zap, ArrowRight,
  Activity, Award, Users, MessageSquare, Code, BarChart3
} from "lucide-react";

const WeaknessTargeting: React.FC = () => {
  const [selectedWeakness, setSelectedWeakness] = useState('system-design');

  const identifiedWeaknesses = {
    'system-design': {
      name: 'System Design',
      severity: 'High',
      currentScore: 65,
      targetScore: 80,
      gapAnalysis: 'Struggles with scalability patterns and database design decisions',
      impactOnSuccess: 'Critical for senior positions - 85% of senior interviews include system design',
      timeToImprove: '3-4 weeks',
      specificIssues: [
        'Database sharding strategies',
        'Load balancer configuration',
        'Caching layer design',
        'Microservices communication'
      ],
      practiceItems: [
        { task: 'Design Twitter-like system', difficulty: 'Hard', estimated: '60 mins', completed: false },
        { task: 'Chat application architecture', difficulty: 'Medium', estimated: '45 mins', completed: true },
        { task: 'Rate limiting implementation', difficulty: 'Medium', estimated: '30 mins', completed: false },
        { task: 'CDN and caching strategy', difficulty: 'Hard', estimated: '45 mins', completed: false }
      ]
    },
    'communication': {
      name: 'Technical Communication',
      severity: 'Medium',
      currentScore: 72,
      targetScore: 85,
      gapAnalysis: 'Difficulty explaining complex technical concepts clearly to non-technical stakeholders',
      impactOnSuccess: 'Important for leadership roles - affects 70% of senior interview evaluations',
      timeToImprove: '2-3 weeks',
      specificIssues: [
        'Simplifying technical jargon',
        'Using analogies effectively',
        'Structured explanation flow',
        'Active listening skills'
      ],
      practiceItems: [
        { task: 'Explain API design to PM', difficulty: 'Medium', estimated: '20 mins', completed: true },
        { task: 'Database optimization explanation', difficulty: 'Hard', estimated: '25 mins', completed: false },
        { task: 'Architecture decision justification', difficulty: 'Hard', estimated: '30 mins', completed: false },
        { task: 'Technical risk communication', difficulty: 'Medium', estimated: '20 mins', completed: true }
      ]
    },
    'algorithms': {
      name: 'Advanced Algorithms',
      severity: 'Medium',
      currentScore: 78,
      targetScore: 88,
      gapAnalysis: 'Strong on basic algorithms but struggles with dynamic programming and graph algorithms',
      impactOnSuccess: 'Moderate impact - required for 60% of technical interviews',
      timeToImprove: '2 weeks',
      specificIssues: [
        'Dynamic programming optimization',
        'Graph traversal efficiency',
        'Tree algorithm complexity',
        'Backtracking patterns'
      ],
      practiceItems: [
        { task: 'Longest common subsequence', difficulty: 'Medium', estimated: '35 mins', completed: true },
        { task: 'Graph shortest path variations', difficulty: 'Hard', estimated: '45 mins', completed: false },
        { task: 'Dynamic programming optimization', difficulty: 'Hard', estimated: '40 mins', completed: false },
        { task: 'Tree reconstruction problems', difficulty: 'Medium', estimated: '30 mins', completed: true }
      ]
    },
    'behavioral': {
      name: 'Behavioral Responses',
      severity: 'Low',
      currentScore: 82,
      targetScore: 90,
      gapAnalysis: 'Good storytelling but needs more quantifiable impact metrics in examples',
      impactOnSuccess: 'High importance - influences 90% of hiring decisions',
      timeToImprove: '1-2 weeks',
      specificIssues: [
        'Quantifying impact with metrics',
        'Conflict resolution examples',
        'Leadership without authority',
        'Failure and learning stories'
      ],
      practiceItems: [
        { task: 'Leadership challenge with metrics', difficulty: 'Medium', estimated: '25 mins', completed: true },
        { task: 'Conflict resolution scenario', difficulty: 'Medium', estimated: '20 mins', completed: false },
        { task: 'Project failure and recovery', difficulty: 'Hard', estimated: '30 mins', completed: false },
        { task: 'Cross-team collaboration', difficulty: 'Medium', estimated: '25 mins', completed: true }
      ]
    }
  };

  const improvementStrategies = [
    {
      weakness: 'System Design',
      strategy: 'Structured Learning Path',
      approach: 'Bottom-up building blocks approach',
      phases: [
        'Database fundamentals and scaling patterns',
        'Load balancing and CDN concepts',
        'Microservices architecture patterns',
        'Complete system design practice'
      ],
      resources: ['System Design Interview book', 'AWS Architecture Center', 'High Scalability blog'],
      timeCommitment: '8-10 hours/week'
    },
    {
      weakness: 'Technical Communication',
      strategy: 'Progressive Complexity Training',
      approach: 'Start simple, build complexity gradually',
      phases: [
        'Record yourself explaining basic concepts',
        'Practice with technical and non-technical audiences',
        'Get feedback from peers and mentors',
        'Present complex architectures clearly'
      ],
      resources: ['Toastmasters practice', 'Peer feedback sessions', 'Technical presentation courses'],
      timeCommitment: '3-4 hours/week'
    }
  ];

  const practiceSchedule = [
    { day: 'Monday', focus: 'System Design Deep Dive', duration: '2 hours', activities: ['Database sharding patterns', 'Load balancer design'] },
    { day: 'Tuesday', focus: 'Algorithm Practice', duration: '1.5 hours', activities: ['Dynamic programming', 'Graph algorithms'] },
    { day: 'Wednesday', focus: 'Communication Skills', duration: '1 hour', activities: ['Technical explanation practice', 'Peer feedback'] },
    { day: 'Thursday', focus: 'Mock Interview', duration: '1.5 hours', activities: ['System design interview', 'Behavioral questions'] },
    { day: 'Friday', focus: 'Behavioral Scenarios', duration: '1 hour', activities: ['STAR method practice', 'Leadership examples'] },
    { day: 'Weekend', focus: 'Review and Planning', duration: '2 hours', activities: ['Progress assessment', 'Next week planning'] }
  ];

  const progressMetrics = {
    weeklyImprovement: [
      { week: 'Week 1', systemDesign: 65, communication: 72, algorithms: 78, behavioral: 82 },
      { week: 'Week 2', systemDesign: 68, communication: 75, algorithms: 80, behavioral: 84 },
      { week: 'Week 3', systemDesign: 72, communication: 78, algorithms: 82, behavioral: 86 },
      { week: 'Week 4', systemDesign: 75, communication: 81, algorithms: 84, behavioral: 88 }
    ],
    focusMetrics: {
      timeSpent: 28,
      targetTime: 32,
      completedTasks: 12,
      totalTasks: 16,
      averageScore: 74,
      improvementRate: '+8%'
    }
  };

  const selectedWeaknessData = identifiedWeaknesses[selectedWeakness as keyof typeof identifiedWeaknesses];

  return (
    <PlatformLayout
      sidebarTitle="Candidate Platform"
      sidebarSubtitle="Interview Preparation"
      sidebarSections={candidateNavigation}
    >
      <div className="min-h-screen bg-gradient-to-br from-red-50 via-white to-pink-50 p-6">
        <div className="max-w-7xl mx-auto space-y-8">
          {/* Header */}
          <div className="text-center space-y-4">
            <div className="inline-flex items-center space-x-2 bg-red-100 text-red-800 px-4 py-2 rounded-full text-sm font-medium">
              <Focus className="h-4 w-4" />
              <span>Weakness Targeting & Improvement</span>
            </div>
            <h1 className="text-4xl font-bold text-gray-900">
              Focus on Your Weak Areas
            </h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              AI-identified weakness analysis with targeted improvement strategies, 
              personalized practice plans, and progress tracking to eliminate interview blind spots.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Main Content */}
            <div className="lg:col-span-2 space-y-6">
              {/* Weakness Selection */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <AlertTriangle className="h-5 w-5" />
                    <span>Identified Weaknesses</span>
                  </CardTitle>
                  <CardDescription>Areas requiring focused improvement based on interview performance</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                    {Object.entries(identifiedWeaknesses).map(([key, weakness]) => (
                      <Card 
                        key={key}
                        className={`cursor-pointer transition-all duration-300 border-2 ${
                          selectedWeakness === key 
                            ? 'border-red-500 shadow-lg' 
                            : 'border-gray-200 hover:border-red-300'
                        }`}
                        onClick={() => setSelectedWeakness(key)}
                      >
                        <CardContent className="p-4">
                          <div className="flex items-center justify-between mb-2">
                            <h3 className="font-semibold">{weakness.name}</h3>
                            <Badge variant={
                              weakness.severity === 'High' ? 'destructive' :
                              weakness.severity === 'Medium' ? 'default' : 'secondary'
                            }>
                              {weakness.severity}
                            </Badge>
                          </div>
                          <div className="space-y-2">
                            <div className="flex justify-between text-sm">
                              <span>Current: {weakness.currentScore}%</span>
                              <span>Target: {weakness.targetScore}%</span>
                            </div>
                            <Progress value={(weakness.currentScore / weakness.targetScore) * 100} className="h-2" />
                            <div className="text-xs text-gray-600">{weakness.timeToImprove} to improve</div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* Selected Weakness Deep Dive */}
              <Card>
                <CardHeader className="bg-gradient-to-r from-red-500 to-pink-500 text-white">
                  <CardTitle className="text-xl">{selectedWeaknessData.name} - Targeted Improvement</CardTitle>
                  <CardDescription className="text-white/80">
                    Comprehensive analysis and improvement strategy
                  </CardDescription>
                </CardHeader>
                <CardContent className="p-6">
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
                    <div className="text-center">
                      <div className="text-3xl font-bold text-red-600">{selectedWeaknessData.currentScore}%</div>
                      <div className="text-sm text-gray-500">Current Level</div>
                    </div>
                    <div className="text-center">
                      <div className="text-3xl font-bold text-green-600">{selectedWeaknessData.targetScore}%</div>
                      <div className="text-sm text-gray-500">Target Level</div>
                    </div>
                    <div className="text-center">
                      <div className="text-3xl font-bold text-blue-600">{selectedWeaknessData.timeToImprove}</div>
                      <div className="text-sm text-gray-500">Time to Improve</div>
                    </div>
                  </div>

                  <div className="mb-6">
                    <div className="flex justify-between text-sm mb-2">
                      <span>Progress to Target</span>
                      <span>{selectedWeaknessData.currentScore}% / {selectedWeaknessData.targetScore}%</span>
                    </div>
                    <Progress value={(selectedWeaknessData.currentScore / selectedWeaknessData.targetScore) * 100} className="h-3" />
                  </div>

                  <div className="space-y-4 mb-6">
                    <div>
                      <h3 className="font-semibold text-red-700 mb-2">Gap Analysis</h3>
                      <p className="text-gray-700">{selectedWeaknessData.gapAnalysis}</p>
                    </div>
                    <div>
                      <h3 className="font-semibold text-blue-700 mb-2">Impact on Interview Success</h3>
                      <p className="text-gray-700">{selectedWeaknessData.impactOnSuccess}</p>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                    <div>
                      <h3 className="font-semibold text-orange-700 mb-3">Specific Issues to Address</h3>
                      <div className="space-y-2">
                        {selectedWeaknessData.specificIssues.map((issue: any, index: number) => (
                          <div key={index} className="flex items-center space-x-2">
                            <AlertTriangle className="h-4 w-4 text-orange-500" />
                            <span className="text-sm">{issue}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                    <div>
                      <h3 className="font-semibold text-green-700 mb-3">Targeted Practice Tasks</h3>
                      <div className="space-y-2">
                        {selectedWeaknessData.practiceItems.map((item: any, index: number) => (
                          <div key={index} className="flex items-center justify-between p-2 bg-gray-50 rounded">
                            <div className="flex items-center space-x-2">
                              {item.completed ? (
                                <CheckCircle className="h-4 w-4 text-green-500" />
                              ) : (
                                <Clock className="h-4 w-4 text-gray-400" />
                              )}
                              <span className="text-sm font-medium">{item.task}</span>
                            </div>
                            <div className="flex items-center space-x-2">
                              <Badge variant="outline" className="text-xs">{item.difficulty}</Badge>
                              <span className="text-xs text-gray-500">{item.estimated}</span>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>

                  <Button className="w-full bg-gradient-to-r from-red-600 to-pink-600 hover:from-red-700 hover:to-pink-700">
                    <Play className="h-4 w-4 mr-2" />
                    Start Targeted Practice for {selectedWeaknessData.name}
                  </Button>
                </CardContent>
              </Card>

              {/* Improvement Strategies */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Brain className="h-5 w-5" />
                    <span>Improvement Strategies</span>
                  </CardTitle>
                  <CardDescription>Proven methods for addressing specific weaknesses</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-6">
                    {improvementStrategies.map((strategy, index) => (
                      <div key={index} className="p-4 border rounded-lg">
                        <div className="flex items-center justify-between mb-3">
                          <h3 className="font-semibold text-lg">{strategy.weakness}</h3>
                          <Badge variant="outline">{strategy.timeCommitment}</Badge>
                        </div>
                        
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                          <div>
                            <span className="font-medium text-blue-700">Strategy:</span>
                            <div className="text-sm text-gray-700">{strategy.strategy}</div>
                          </div>
                          <div>
                            <span className="font-medium text-green-700">Approach:</span>
                            <div className="text-sm text-gray-700">{strategy.approach}</div>
                          </div>
                        </div>

                        <div className="mb-4">
                          <span className="font-medium text-purple-700">Learning Phases:</span>
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-2 mt-2">
                            {strategy.phases.map((phase, i) => (
                              <div key={i} className="flex items-center space-x-2">
                                <div className="w-6 h-6 rounded-full bg-purple-100 text-purple-600 text-xs flex items-center justify-center font-medium">
                                  {i + 1}
                                </div>
                                <span className="text-sm">{phase}</span>
                              </div>
                            ))}
                          </div>
                        </div>

                        <div>
                          <span className="font-medium text-orange-700">Resources:</span>
                          <div className="flex flex-wrap gap-1 mt-1">
                            {strategy.resources.map((resource, i) => (
                              <Badge key={i} variant="secondary" className="text-xs">
                                {resource}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Sidebar */}
            <div className="space-y-6">
              {/* Weekly Schedule */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Target className="h-5 w-5" />
                    <span>Weekly Focus Plan</span>
                  </CardTitle>
                  <CardDescription>Structured improvement schedule</CardDescription>
                </CardHeader>
                <CardContent className="space-y-3">
                  {practiceSchedule.map((day, index) => (
                    <div key={index} className="p-3 bg-gray-50 rounded-lg">
                      <div className="flex items-center justify-between mb-2">
                        <span className="font-medium text-sm">{day.day}</span>
                        <span className="text-xs text-blue-600">{day.duration}</span>
                      </div>
                      <div className="text-sm text-gray-700 mb-2">{day.focus}</div>
                      <div className="space-y-1">
                        {day.activities.map((activity, i) => (
                          <div key={i} className="text-xs text-gray-600">• {activity}</div>
                        ))}
                      </div>
                    </div>
                  ))}
                </CardContent>
              </Card>

              {/* Progress Metrics */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Activity className="h-5 w-5" />
                    <span>Focus Metrics</span>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4 text-center">
                    <div>
                      <div className="text-2xl font-bold text-blue-600">{progressMetrics.focusMetrics.timeSpent}h</div>
                      <div className="text-xs text-gray-500">This Week</div>
                    </div>
                    <div>
                      <div className="text-2xl font-bold text-green-600">{progressMetrics.focusMetrics.completedTasks}</div>
                      <div className="text-xs text-gray-500">Completed</div>
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>Weekly Progress</span>
                      <span>{progressMetrics.focusMetrics.timeSpent}h / {progressMetrics.focusMetrics.targetTime}h</span>
                    </div>
                    <Progress value={(progressMetrics.focusMetrics.timeSpent / progressMetrics.focusMetrics.targetTime) * 100} className="h-2" />
                  </div>

                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>Task Completion</span>
                      <span>{progressMetrics.focusMetrics.completedTasks} / {progressMetrics.focusMetrics.totalTasks}</span>
                    </div>
                    <Progress value={(progressMetrics.focusMetrics.completedTasks / progressMetrics.focusMetrics.totalTasks) * 100} className="h-2" />
                  </div>

                  <div className="text-center">
                    <div className="text-lg font-semibold text-purple-600">{progressMetrics.focusMetrics.improvementRate}</div>
                    <div className="text-xs text-gray-500">Improvement Rate</div>
                  </div>
                </CardContent>
              </Card>

              {/* Quick Actions */}
              <div className="space-y-3">
                <Button size="lg" className="w-full bg-gradient-to-r from-red-600 to-pink-600 hover:from-red-700 hover:to-pink-700">
                  <Play className="h-4 w-4 mr-2" />
                  Start Weakness Practice
                </Button>
                <Button variant="outline" size="lg" className="w-full">
                  <BookOpen className="h-4 w-4 mr-2" />
                  Study Resources
                </Button>
                <Button variant="outline" size="lg" className="w-full">
                  <BarChart3 className="h-4 w-4 mr-2" />
                  Progress Report
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </PlatformLayout>
  );
};

export default WeaknessTargeting;