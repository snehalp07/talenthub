import PlatformLayout from "@/components/layout/platform-layout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Network, Users, MessageCircle, Calendar, TrendingUp, UserPlus, ArrowUp, ArrowDown } from "lucide-react";
import { candidateNavigation } from "@/config/complete-navigation";

export default function NetworkingInsights() {
  const networkingMetrics = [
    { label: "Professional Connections", value: "847", change: 12, color: "bg-blue-500", icon: Users },
    { label: "Active Conversations", value: "23", change: 7, color: "bg-green-500", icon: MessageCircle },
    { label: "Events Attended", value: "15", change: 3, color: "bg-purple-500", icon: Calendar },
    { label: "Network Growth Rate", value: "8.5%", change: 2, color: "bg-orange-500", icon: TrendingUp }
  ];

  const connectionsByIndustry = [
    { industry: "Technology", connections: 287, percentage: 34 },
    { industry: "Finance", connections: 156, percentage: 18 },
    { industry: "Healthcare", connections: 134, percentage: 16 },
    { industry: "Education", connections: 127, percentage: 15 },
    { industry: "Consulting", connections: 89, percentage: 11 },
    { industry: "Other", connections: 54, percentage: 6 }
  ];

  const engagementActivities = [
    {
      type: "Industry Conference",
      name: "Tech Summit 2024",
      date: "Dec 15, 2024",
      connections: 12,
      engagement: "High",
      impact: "New opportunities"
    },
    {
      type: "Professional Meetup",
      name: "Full Stack Developers",
      date: "Dec 10, 2024",
      connections: 8,
      engagement: "Medium",
      impact: "Knowledge sharing"
    },
    {
      type: "Online Workshop",
      name: "AI in Development",
      date: "Dec 5, 2024",
      connections: 15,
      engagement: "High",
      impact: "Skill development"
    }
  ];

  const networkQuality = [
    { metric: "Industry Leaders", count: 23, percentage: 2.7, impact: "High" },
    { metric: "Senior Professionals", count: 127, percentage: 15, impact: "High" },
    { metric: "Peers/Colleagues", count: 324, percentage: 38, impact: "Medium" },
    { metric: "Junior Professionals", count: 198, percentage: 23, impact: "Medium" },
    { metric: "Students/Interns", count: 175, percentage: 21, impact: "Low" }
  ];

  const communicationPatterns = [
    { platform: "LinkedIn", interactions: 156, responseRate: 78 },
    { platform: "Professional Events", interactions: 89, responseRate: 92 },
    { platform: "Email", interactions: 67, responseRate: 65 },
    { platform: "Slack Communities", interactions: 45, responseRate: 84 },
    { platform: "Industry Forums", interactions: 32, responseRate: 71 }
  ];

  return (
    <PlatformLayout 
      sidebarTitle="Candidate Platform"
      sidebarSubtitle="Professional Development Hub"
      sidebarSections={candidateNavigation}
    >
      <div className="max-w-7xl mx-auto p-6 space-y-8">
        <div className="text-center space-y-4">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-rose-100 to-pink-100 rounded-full">
            <Network className="h-5 w-5 text-rose-600" />
            <span className="text-sm font-medium text-rose-900">Networking & Community Insights</span>
          </div>
          <h1 className="text-4xl font-bold bg-gradient-to-r from-rose-600 to-pink-600 bg-clip-text text-transparent">
            Professional Network Analytics
          </h1>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            Track networking activities, analyze connection quality, and optimize professional relationship building
          </p>
        </div>

        {/* Networking Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {networkingMetrics.map((metric, index) => {
            const IconComponent = metric.icon;
            return (
              <Card key={index} className="hover:shadow-md transition-shadow">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between mb-4">
                    <div className={`p-3 rounded-lg ${metric.color} text-white`}>
                      <IconComponent className="h-6 w-6" />
                    </div>
                    <div className={`flex items-center gap-1 px-2 py-1 rounded-full text-sm ${
                      Number(metric.change) > 0 ? 'bg-emerald-100 text-emerald-700' : 'bg-red-100 text-red-700'
                    }`}>
                      {Number(metric.change) > 0 ? <ArrowUp className="h-3 w-3" /> : <ArrowDown className="h-3 w-3" />}
                      {Math.abs(Number(metric.change))}
                    </div>
                  </div>
                  <div className="text-2xl font-bold text-gray-900 mb-1">{metric.value}</div>
                  <div className="text-sm text-gray-600">{metric.label}</div>
                </CardContent>
              </Card>
            );
          })}
        </div>

        <Tabs defaultValue="overview" className="space-y-6">
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="connections">Connections</TabsTrigger>
            <TabsTrigger value="activities">Activities</TabsTrigger>
            <TabsTrigger value="quality">Network Quality</TabsTrigger>
            <TabsTrigger value="communication">Communication</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Network Growth Timeline</CardTitle>
                  <CardDescription>Your networking activity over the past year</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="h-64 flex items-center justify-center text-gray-500">
                    <div className="text-center">
                      <TrendingUp className="h-12 w-12 mx-auto mb-2" />
                      <p>Network growth chart visualization</p>
                      <div className="mt-4 space-y-2 text-sm">
                        <div className="flex justify-between">
                          <span>New connections this month:</span>
                          <span className="font-medium text-rose-600">+42</span>
                        </div>
                        <div className="flex justify-between">
                          <span>Events attended:</span>
                          <span className="font-medium text-pink-600">6</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Networking Effectiveness</CardTitle>
                  <CardDescription>Quality metrics of your professional network</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between p-4 bg-rose-50 rounded-lg">
                      <div>
                        <div className="font-medium text-rose-900">Response Rate</div>
                        <div className="text-sm text-rose-600">Average response to your outreach</div>
                      </div>
                      <div className="text-2xl font-bold text-rose-600">76%</div>
                    </div>
                    <div className="flex items-center justify-between p-4 bg-pink-50 rounded-lg">
                      <div>
                        <div className="font-medium text-pink-900">Engagement Quality</div>
                        <div className="text-sm text-pink-600">Meaningful professional interactions</div>
                      </div>
                      <div className="text-2xl font-bold text-pink-600">8.4/10</div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="connections" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Connections by Industry</CardTitle>
                <CardDescription>Distribution of your professional network across industries</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  {connectionsByIndustry.map((industry, index) => (
                    <div key={index} className="space-y-3">
                      <div className="flex items-center justify-between">
                        <span className="font-medium text-gray-900">{industry.industry}</span>
                        <div className="flex items-center gap-2">
                          <span className="text-sm text-gray-600">{industry.connections} connections</span>
                          <Badge className="bg-rose-600 hover:bg-rose-700">{industry.percentage}%</Badge>
                        </div>
                      </div>
                      <Progress value={industry.percentage} className="h-2" />
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="activities" className="space-y-6">
            <div className="grid gap-6">
              {engagementActivities.map((activity, index) => (
                <Card key={index} className="hover:shadow-md transition-shadow">
                  <CardContent className="p-6">
                    <div className="flex items-start justify-between mb-4">
                      <div className="space-y-1">
                        <div className="font-semibold text-lg text-gray-900">{activity.name}</div>
                        <div className="text-sm text-gray-600">{activity.type} • {activity.date}</div>
                      </div>
                      <Badge variant={activity.engagement === 'High' ? 'default' : 'secondary'}>
                        {activity.engagement} Engagement
                      </Badge>
                    </div>
                    
                    <div className="grid grid-cols-2 gap-4 mb-4">
                      <div>
                        <div className="text-sm text-gray-600">New Connections</div>
                        <div className="text-lg font-semibold text-rose-600">{activity.connections}</div>
                      </div>
                      <div>
                        <div className="text-sm text-gray-600">Impact</div>
                        <div className="text-sm font-medium text-gray-900">{activity.impact}</div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="quality" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Network Quality Analysis</CardTitle>
                <CardDescription>Breakdown of your connections by professional level and influence</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  {networkQuality.map((quality, index) => (
                    <div key={index} className="space-y-3">
                      <div className="flex items-center justify-between">
                        <span className="font-medium text-gray-900">{quality.metric}</span>
                        <div className="flex items-center gap-2">
                          <Badge variant={quality.impact === 'High' ? 'destructive' : quality.impact === 'Medium' ? 'default' : 'secondary'}>
                            {quality.impact} Impact
                          </Badge>
                          <span className="text-sm text-gray-600">{quality.count} people</span>
                        </div>
                      </div>
                      <Progress value={quality.percentage} className="h-2" />
                      <div className="text-xs text-gray-500">{quality.percentage}% of network</div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="communication" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Communication Platform Analytics</CardTitle>
                <CardDescription>Effectiveness of different networking platforms and channels</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  {communicationPatterns.map((platform, index) => (
                    <div key={index} className="space-y-3">
                      <div className="flex items-center justify-between">
                        <span className="font-medium text-gray-900">{platform.platform}</span>
                        <div className="flex items-center gap-2">
                          <Badge className="bg-pink-600 hover:bg-pink-700">{platform.responseRate}% response</Badge>
                          <span className="text-sm text-gray-600">{platform.interactions} interactions</span>
                        </div>
                      </div>
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <div className="text-sm text-gray-600 mb-1">Interactions</div>
                          <Progress value={(platform.interactions / 200) * 100} className="h-2" />
                        </div>
                        <div>
                          <div className="text-sm text-gray-600 mb-1">Response Rate</div>
                          <Progress value={platform.responseRate} className="h-2" />
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </PlatformLayout>
  );
}