import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  TrendingUp, 
  TrendingDown, 
  Target, 
  Award, 
  Clock, 
  BarChart3,
  Eye,
  ThumbsUp,
  MessageSquare,
  CheckCircle,
  AlertCircle,
  Star
} from "lucide-react";
import PlatformLayout from "@/components/layout/platform-layout";
import { platformConfigs } from "@/config/complete-navigation";

interface PerformanceMetrics {
  skillRating: number;
  testsCompleted: number;
  averageScore: number;
  timeSpent: number;
  certifications: number;
  profileViews: number;
  applications: number;
  interviews: number;
}

interface SkillPerformance {
  skill: string;
  currentLevel: number;
  targetLevel: number;
  progress: number;
  trend: 'up' | 'down' | 'stable';
  lastAssessment: string;
}

interface Achievement {
  id: string;
  title: string;
  description: string;
  date: string;
  type: 'certification' | 'test' | 'skill' | 'milestone';
  badge: string;
}

function PerformanceContent() {
  const { data: metrics, isLoading } = useQuery<PerformanceMetrics>({
    queryKey: ["/api/candidate/performance/metrics"]
  });

  const { data: skillPerformance } = useQuery<SkillPerformance[]>({
    queryKey: ["/api/candidate/performance/skills"]
  });

  const { data: achievements } = useQuery<Achievement[]>({
    queryKey: ["/api/candidate/performance/achievements"]
  });

  const { data: recentActivity } = useQuery({
    queryKey: ["/api/candidate/performance/activity"]
  });

  if (isLoading) {
    return <div className="flex items-center justify-center h-64">Loading performance data...</div>;
  }

  const mockMetrics: PerformanceMetrics = {
    skillRating: 4.7,
    testsCompleted: 23,
    averageScore: 87,
    timeSpent: 45,
    certifications: 5,
    profileViews: 142,
    applications: 12,
    interviews: 7
  };

  const mockSkills: SkillPerformance[] = [
    { skill: "JavaScript", currentLevel: 85, targetLevel: 90, progress: 94, trend: 'up', lastAssessment: '2 days ago' },
    { skill: "React", currentLevel: 78, targetLevel: 85, progress: 92, trend: 'up', lastAssessment: '1 week ago' },
    { skill: "Python", currentLevel: 65, targetLevel: 80, progress: 81, trend: 'stable', lastAssessment: '3 days ago' },
    { skill: "System Design", currentLevel: 55, targetLevel: 75, progress: 73, trend: 'up', lastAssessment: '5 days ago' },
  ];

  const mockAchievements: Achievement[] = [
    { id: '1', title: 'React Expert', description: 'Completed advanced React certification', date: '2024-06-10', type: 'certification', badge: '🚀' },
    { id: '2', title: 'Top Performer', description: 'Scored in top 10% on JavaScript assessment', date: '2024-06-08', type: 'test', badge: '🏆' },
    { id: '3', title: 'Skill Master', description: 'Achieved 90%+ in 5 different skills', date: '2024-06-05', type: 'skill', badge: '⭐' },
    { id: '4', title: 'Interview Champion', description: 'Completed 5 successful interviews', date: '2024-06-01', type: 'milestone', badge: '💼' },
  ];

  const currentMetrics = metrics || mockMetrics;
  const currentSkills = skillPerformance || mockSkills;
  const currentAchievements = achievements || mockAchievements;

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">My Performance</h1>
          <p className="text-gray-600">Track your progress and achievements</p>
        </div>
        <Button variant="outline">
          <BarChart3 className="w-4 h-4 mr-2" />
          Export Report
        </Button>
      </div>

      {/* Performance Overview Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Overall Rating</CardTitle>
            <Star className="h-4 w-4 text-yellow-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{currentMetrics.skillRating}/5.0</div>
            <p className="text-xs text-muted-foreground">
              <TrendingUp className="w-3 h-3 inline mr-1" />
              +0.3 from last month
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Tests Completed</CardTitle>
            <Target className="h-4 w-4 text-blue-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{currentMetrics.testsCompleted}</div>
            <p className="text-xs text-muted-foreground">
              Average score: {currentMetrics.averageScore}%
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Learning Hours</CardTitle>
            <Clock className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{currentMetrics.timeSpent}h</div>
            <p className="text-xs text-muted-foreground">
              This month
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Certifications</CardTitle>
            <Award className="h-4 w-4 text-purple-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{currentMetrics.certifications}</div>
            <p className="text-xs text-muted-foreground">
              Active certificates
            </p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="skills" className="space-y-4">
        <TabsList>
          <TabsTrigger value="skills">Skill Progress</TabsTrigger>
          <TabsTrigger value="achievements">Achievements</TabsTrigger>
          <TabsTrigger value="activity">Recent Activity</TabsTrigger>
        </TabsList>

        <TabsContent value="skills" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Skill Development Progress</CardTitle>
              <CardDescription>Track your improvement across different skills</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {currentSkills.map((skill) => (
                <div key={skill.skill} className="space-y-2">
                  <div className="flex justify-between items-center">
                    <div className="flex items-center space-x-2">
                      <span className="font-medium">{skill.skill}</span>
                      {skill.trend === 'up' && <TrendingUp className="w-4 h-4 text-green-600" />}
                      {skill.trend === 'down' && <TrendingDown className="w-4 h-4 text-red-600" />}
                      {skill.trend === 'stable' && <span className="w-4 h-4 text-gray-400">—</span>}
                    </div>
                    <div className="flex items-center space-x-2">
                      <span className="text-sm text-gray-600">{skill.currentLevel}% / {skill.targetLevel}%</span>
                      <Badge variant="outline" className="text-xs">
                        Last: {skill.lastAssessment}
                      </Badge>
                    </div>
                  </div>
                  <Progress value={skill.progress} className="w-full" />
                </div>
              ))}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="achievements" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {currentAchievements.map((achievement) => (
              <Card key={achievement.id}>
                <CardHeader>
                  <div className="flex items-center space-x-3">
                    <span className="text-2xl">{achievement.badge}</span>
                    <div>
                      <CardTitle className="text-base">{achievement.title}</CardTitle>
                      <CardDescription>{achievement.description}</CardDescription>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="flex justify-between items-center">
                    <Badge variant={
                      achievement.type === 'certification' ? 'default' :
                      achievement.type === 'test' ? 'secondary' :
                      achievement.type === 'skill' ? 'outline' : 'destructive'
                    }>
                      {achievement.type}
                    </Badge>
                    <span className="text-sm text-gray-600">{achievement.date}</span>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="activity" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Recent Activity</CardTitle>
              <CardDescription>Your latest learning and testing activities</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {[
                  { icon: CheckCircle, action: "Completed React Advanced Assessment", time: "2 hours ago", score: "92%" },
                  { icon: Eye, action: "Viewed JavaScript Tutorial Series", time: "1 day ago", score: null },
                  { icon: Target, action: "Started Python Data Structures Course", time: "2 days ago", score: null },
                  { icon: MessageSquare, action: "Participated in Mock Interview", time: "3 days ago", score: "85%" },
                  { icon: Award, action: "Earned Frontend Developer Certificate", time: "1 week ago", score: null },
                ].map((activity, index) => (
                  <div key={index} className="flex items-center space-x-3 p-3 rounded-lg bg-gray-50">
                    <activity.icon className="w-5 h-5 text-blue-600" />
                    <div className="flex-1">
                      <p className="font-medium">{activity.action}</p>
                      <p className="text-sm text-gray-600">{activity.time}</p>
                    </div>
                    {activity.score && (
                      <Badge variant="outline">{activity.score}</Badge>
                    )}
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}

export default function Performance() {
  const config = platformConfigs.candidate;

  return (
    <PlatformLayout
      sidebarTitle={config.sidebarTitle}
      sidebarSubtitle={config.sidebarSubtitle}
      sidebarSections={config.sidebarSections}
    >
      <PerformanceContent />
    </PlatformLayout>
  );
}