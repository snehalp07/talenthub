import PlatformLayout from "@/components/layout/platform-layout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { BarChart3, TrendingUp, Eye, Star, GitBranch, Clock, Calendar, Users, Code, Download, Share, Award, Target, Zap, Activity } from "lucide-react";
import { platformConfigs } from "@/config/complete-navigation";

export default function ProjectAnalytics() {
  const config = platformConfigs.candidate;

  const projectMetrics = [
    {
      id: 1,
      name: "E-commerce Dashboard",
      views: 1245,
      stars: 42,
      forks: 18,
      downloads: 89,
      commits: 127,
      contributors: 3,
      issues: 5,
      lastActive: "2 days ago",
      trend: "+15%",
      category: "Frontend",
      status: "Active"
    },
    {
      id: 2,
      name: "Task Management API",
      views: 856,
      stars: 28,
      forks: 12,
      downloads: 67,
      commits: 89,
      contributors: 2,
      issues: 2,
      lastActive: "1 day ago",
      trend: "+8%",
      category: "Backend",
      status: "Active"
    },
    {
      id: 3,
      name: "Mobile Weather App",
      views: 634,
      stars: 19,
      forks: 8,
      downloads: 45,
      commits: 56,
      contributors: 1,
      issues: 3,
      lastActive: "5 days ago",
      trend: "-2%",
      category: "Mobile",
      status: "Paused"
    },
    {
      id: 4,
      name: "Portfolio Website",
      views: 2103,
      stars: 78,
      forks: 34,
      downloads: 156,
      commits: 94,
      contributors: 1,
      issues: 1,
      lastActive: "1 week ago",
      trend: "+23%",
      category: "Frontend",
      status: "Completed"
    }
  ];

  const skillsData = [
    { skill: "React", projects: 8, growth: "+12%", level: 85 },
    { skill: "TypeScript", projects: 6, growth: "+18%", level: 78 },
    { skill: "Node.js", projects: 5, growth: "+8%", level: 72 },
    { skill: "Python", projects: 4, growth: "+25%", level: 68 },
    { skill: "MongoDB", projects: 3, growth: "+15%", level: 65 },
    { skill: "Docker", projects: 2, growth: "+10%", level: 45 }
  ];

  const timelineData = [
    { date: "Jan 2024", projects: 2, commits: 45, views: 234 },
    { date: "Feb 2024", projects: 3, commits: 78, views: 456 },
    { date: "Mar 2024", projects: 4, commits: 92, views: 678 },
    { date: "Apr 2024", projects: 5, commits: 134, views: 892 },
    { date: "May 2024", projects: 5, commits: 156, views: 1245 }
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case "Active": return "bg-green-100 text-green-800 border-green-200";
      case "Paused": return "bg-orange-100 text-orange-800 border-orange-200";
      case "Completed": return "bg-blue-100 text-blue-800 border-blue-200";
      default: return "bg-gray-100 text-gray-800 border-gray-200";
    }
  };

  const getTrendColor = (trend: string) => {
    if (trend.startsWith('+')) return "text-green-600";
    if (trend.startsWith('-')) return "text-red-600";
    return "text-gray-600";
  };

  return (
    <PlatformLayout
      sidebarTitle={config.sidebarTitle}
      sidebarSubtitle={config.sidebarSubtitle}
      sidebarSections={config.sidebarSections}
      usageData={config.usageData}
    >
      <div className="p-6 max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="text-center space-y-4">
          <div className="flex items-center justify-center space-x-3">
            <div className="p-3 bg-gradient-to-r from-cyan-500 to-blue-500 rounded-full">
              <BarChart3 className="h-8 w-8 text-white" />
            </div>
            <h1 className="text-4xl font-bold bg-gradient-to-r from-cyan-600 to-blue-600 bg-clip-text text-transparent">
              Project Analytics
            </h1>
          </div>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Track project performance, analyze engagement metrics, and gain insights into your development progress
          </p>
        </div>

        {/* Overview Stats */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <Card className="bg-gradient-to-r from-cyan-50 to-blue-50 border-cyan-200">
            <CardContent className="p-4 text-center">
              <Eye className="h-8 w-8 text-cyan-500 mx-auto mb-2" />
              <p className="text-2xl font-bold text-cyan-600">4.8K</p>
              <p className="text-sm text-muted-foreground">Total Views</p>
              <div className="text-xs text-green-600 mt-1">+15% this month</div>
            </CardContent>
          </Card>
          <Card className="bg-gradient-to-r from-yellow-50 to-orange-50 border-yellow-200">
            <CardContent className="p-4 text-center">
              <Star className="h-8 w-8 text-yellow-500 mx-auto mb-2" />
              <p className="text-2xl font-bold text-yellow-600">167</p>
              <p className="text-sm text-muted-foreground">Total Stars</p>
              <div className="text-xs text-green-600 mt-1">+8% this month</div>
            </CardContent>
          </Card>
          <Card className="bg-gradient-to-r from-green-50 to-emerald-50 border-green-200">
            <CardContent className="p-4 text-center">
              <GitBranch className="h-8 w-8 text-green-500 mx-auto mb-2" />
              <p className="text-2xl font-bold text-green-600">72</p>
              <p className="text-sm text-muted-foreground">Total Forks</p>
              <div className="text-xs text-green-600 mt-1">+12% this month</div>
            </CardContent>
          </Card>
          <Card className="bg-gradient-to-r from-purple-50 to-pink-50 border-purple-200">
            <CardContent className="p-4 text-center">
              <Download className="h-8 w-8 text-purple-500 mx-auto mb-2" />
              <p className="text-2xl font-bold text-purple-600">357</p>
              <p className="text-sm text-muted-foreground">Total Downloads</p>
              <div className="text-xs text-green-600 mt-1">+18% this month</div>
            </CardContent>
          </Card>
        </div>

        {/* Time Range Selector */}
        <div className="flex justify-between items-center">
          <h2 className="text-2xl font-bold text-cyan-700">Performance Dashboard</h2>
          <Select defaultValue="30days">
            <SelectTrigger className="w-40">
              <SelectValue placeholder="Time Range" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="7days">Last 7 Days</SelectItem>
              <SelectItem value="30days">Last 30 Days</SelectItem>
              <SelectItem value="3months">Last 3 Months</SelectItem>
              <SelectItem value="1year">Last Year</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <Tabs defaultValue="overview" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="projects">Project Details</TabsTrigger>
            <TabsTrigger value="skills">Skills Growth</TabsTrigger>
            <TabsTrigger value="timeline">Timeline</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <TrendingUp className="h-5 w-5 text-cyan-500" />
                    Performance Trends
                  </CardTitle>
                  <CardDescription>Key metrics over the last 30 days</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-3">
                    <div className="flex justify-between items-center">
                      <span className="text-sm font-medium">Views Growth</span>
                      <span className="text-sm text-green-600 font-medium">+24%</span>
                    </div>
                    <Progress value={75} className="h-2" />
                  </div>
                  <div className="space-y-3">
                    <div className="flex justify-between items-center">
                      <span className="text-sm font-medium">Stars Growth</span>
                      <span className="text-sm text-green-600 font-medium">+18%</span>
                    </div>
                    <Progress value={65} className="h-2" />
                  </div>
                  <div className="space-y-3">
                    <div className="flex justify-between items-center">
                      <span className="text-sm font-medium">Engagement Rate</span>
                      <span className="text-sm text-blue-600 font-medium">8.4%</span>
                    </div>
                    <Progress value={84} className="h-2" />
                  </div>
                  <div className="space-y-3">
                    <div className="flex justify-between items-center">
                      <span className="text-sm font-medium">Code Quality Score</span>
                      <span className="text-sm text-purple-600 font-medium">92/100</span>
                    </div>
                    <Progress value={92} className="h-2" />
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Target className="h-5 w-5 text-blue-500" />
                    Monthly Goals
                  </CardTitle>
                  <CardDescription>Track your development objectives</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-3">
                    <div className="flex justify-between items-center">
                      <span className="text-sm font-medium">Complete 2 Projects</span>
                      <Badge className="bg-green-100 text-green-800">Completed</Badge>
                    </div>
                    <Progress value={100} className="h-2" />
                  </div>
                  <div className="space-y-3">
                    <div className="flex justify-between items-center">
                      <span className="text-sm font-medium">Learn New Technology</span>
                      <Badge className="bg-blue-100 text-blue-800">In Progress</Badge>
                    </div>
                    <Progress value={70} className="h-2" />
                  </div>
                  <div className="space-y-3">
                    <div className="flex justify-between items-center">
                      <span className="text-sm font-medium">Get 100+ Stars</span>
                      <Badge className="bg-yellow-100 text-yellow-800">67% Done</Badge>
                    </div>
                    <Progress value={67} className="h-2" />
                  </div>
                  <div className="space-y-3">
                    <div className="flex justify-between items-center">
                      <span className="text-sm font-medium">Contribute to Open Source</span>
                      <Badge className="bg-gray-100 text-gray-800">Planned</Badge>
                    </div>
                    <Progress value={25} className="h-2" />
                  </div>
                </CardContent>
              </Card>
            </div>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Activity className="h-5 w-5 text-green-500" />
                  Activity Heatmap
                </CardTitle>
                <CardDescription>Your coding activity over the past months</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-7 gap-1">
                  {Array.from({ length: 35 }, (_, i) => (
                    <div
                      key={i}
                      className={`w-4 h-4 rounded-sm ${
                        Math.random() > 0.7 ? 'bg-cyan-500' :
                        Math.random() > 0.5 ? 'bg-cyan-300' :
                        Math.random() > 0.3 ? 'bg-cyan-100' : 'bg-gray-100'
                      }`}
                      title={`${Math.floor(Math.random() * 10)} commits`}
                    />
                  ))}
                </div>
                <div className="flex items-center justify-between mt-4 text-xs text-muted-foreground">
                  <span>Less active</span>
                  <div className="flex items-center gap-1">
                    <div className="w-3 h-3 bg-gray-100 rounded-sm" />
                    <div className="w-3 h-3 bg-cyan-100 rounded-sm" />
                    <div className="w-3 h-3 bg-cyan-300 rounded-sm" />
                    <div className="w-3 h-3 bg-cyan-500 rounded-sm" />
                  </div>
                  <span>More active</span>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="projects" className="space-y-6">
            <h3 className="text-xl font-bold text-cyan-700">Project Performance Details</h3>
            
            <div className="space-y-4">
              {projectMetrics.map((project) => (
                <Card key={project.id} className="hover:shadow-md transition-shadow">
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-4 flex-1">
                        <div className="p-2 bg-gradient-to-r from-cyan-500 to-blue-500 rounded-lg">
                          <Code className="h-5 w-5 text-white" />
                        </div>
                        <div className="flex-1">
                          <div className="flex items-center gap-2 mb-1">
                            <h4 className="font-semibold text-lg">{project.name}</h4>
                            <Badge className={getStatusColor(project.status)}>
                              {project.status}
                            </Badge>
                            <Badge variant="secondary">{project.category}</Badge>
                          </div>
                          <div className="flex items-center gap-6 text-sm text-muted-foreground">
                            <div className="flex items-center gap-1">
                              <Eye className="h-4 w-4" />
                              <span>{project.views}</span>
                            </div>
                            <div className="flex items-center gap-1">
                              <Star className="h-4 w-4 text-yellow-500" />
                              <span>{project.stars}</span>
                            </div>
                            <div className="flex items-center gap-1">
                              <GitBranch className="h-4 w-4" />
                              <span>{project.forks}</span>
                            </div>
                            <div className="flex items-center gap-1">
                              <Download className="h-4 w-4" />
                              <span>{project.downloads}</span>
                            </div>
                            <div className="flex items-center gap-1">
                              <Users className="h-4 w-4" />
                              <span>{project.contributors}</span>
                            </div>
                            <span>Last active: {project.lastActive}</span>
                          </div>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className={`text-lg font-semibold ${getTrendColor(project.trend)}`}>
                          {project.trend}
                        </div>
                        <div className="text-sm text-muted-foreground">This month</div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="skills" className="space-y-6">
            <h3 className="text-xl font-bold text-cyan-700">Skills Development Progress</h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {skillsData.map((skill) => (
                <Card key={skill.skill} className="border-l-4 border-l-cyan-500">
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between mb-4">
                      <div>
                        <h4 className="font-semibold text-lg">{skill.skill}</h4>
                        <p className="text-sm text-muted-foreground">{skill.projects} projects</p>
                      </div>
                      <div className="text-right">
                        <div className="text-lg font-bold text-cyan-600">{skill.level}%</div>
                        <div className={`text-sm ${getTrendColor(skill.growth)}`}>{skill.growth}</div>
                      </div>
                    </div>
                    <Progress value={skill.level} className="h-3" />
                    <div className="flex justify-between text-xs text-muted-foreground mt-2">
                      <span>Beginner</span>
                      <span>Expert</span>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="timeline" className="space-y-6">
            <h3 className="text-xl font-bold text-cyan-700">Development Timeline</h3>
            
            <Card>
              <CardHeader>
                <CardTitle>Monthly Progress</CardTitle>
                <CardDescription>Track your development journey over time</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  {timelineData.map((month, index) => (
                    <div key={month.date} className="flex items-center space-x-4">
                      <div className="w-12 h-12 bg-gradient-to-r from-cyan-500 to-blue-500 rounded-full flex items-center justify-center text-white font-bold text-sm">
                        {month.date.split(' ')[0]}
                      </div>
                      <div className="flex-1 grid grid-cols-3 gap-4">
                        <div className="text-center">
                          <div className="text-lg font-bold text-cyan-600">{month.projects}</div>
                          <div className="text-xs text-muted-foreground">Projects</div>
                        </div>
                        <div className="text-center">
                          <div className="text-lg font-bold text-green-600">{month.commits}</div>
                          <div className="text-xs text-muted-foreground">Commits</div>
                        </div>
                        <div className="text-center">
                          <div className="text-lg font-bold text-purple-600">{month.views}</div>
                          <div className="text-xs text-muted-foreground">Views</div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </PlatformLayout>
  );
}