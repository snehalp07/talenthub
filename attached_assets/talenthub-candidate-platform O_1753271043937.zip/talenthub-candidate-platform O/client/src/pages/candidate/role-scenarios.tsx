import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import PlatformLayout from "@/components/layout/platform-layout";
import { candidateNavigation } from "@/config/complete-navigation";
import { 
  Users, Target, Star, TrendingUp, Clock, CheckCircle,
  Play, BookOpen, Brain, Award, Activity, Code,
  MessageSquare, Lightbulb, ArrowRight, Zap
} from "lucide-react";

const RoleScenarios: React.FC = () => {
  const [selectedLevel, setSelectedLevel] = useState('senior');

  const roleLevels = {
    junior: {
      name: 'Junior Developer (0-2 years)',
      focus: 'Technical fundamentals and learning agility',
      scenarios: [
        {
          title: 'First Technical Challenge',
          description: 'Solving a coding problem you\'ve never seen before',
          skills: ['Problem decomposition', 'Asking for help', 'Learning approach'],
          questions: [
            'Walk me through your debugging process',
            'How do you learn new technologies?',
            'Describe a time you got stuck and how you overcame it'
          ],
          preparation: [
            'Practice basic algorithms and data structures',
            'Prepare examples of learning new concepts quickly',
            'Show enthusiasm for growth and learning'
          ]
        },
        {
          title: 'Code Review Feedback',
          description: 'Receiving and implementing feedback from senior developers',
          skills: ['Receptiveness to feedback', 'Code improvement', 'Communication'],
          questions: [
            'How do you handle constructive criticism?',
            'Tell me about a time your code was heavily criticized',
            'How do you ensure code quality?'
          ],
          preparation: [
            'Prepare examples of implementing feedback',
            'Show willingness to learn and improve',
            'Demonstrate understanding of code quality principles'
          ]
        }
      ]
    },
    mid: {
      name: 'Mid-Level Developer (2-5 years)',
      focus: 'Project ownership and technical leadership',
      scenarios: [
        {
          title: 'Feature Development Lead',
          description: 'Leading development of a complex feature from start to finish',
          skills: ['Project planning', 'Technical design', 'Stakeholder communication'],
          questions: [
            'How do you break down a large feature into manageable tasks?',
            'Describe your approach to technical design',
            'How do you handle changing requirements?'
          ],
          preparation: [
            'Prepare examples of end-to-end feature development',
            'Show ability to balance technical and business concerns',
            'Demonstrate project management skills'
          ]
        },
        {
          title: 'Mentoring Junior Developers',
          description: 'Guiding and supporting less experienced team members',
          skills: ['Knowledge transfer', 'Patience', 'Teaching ability'],
          questions: [
            'How do you explain complex technical concepts?',
            'Tell me about a time you helped a junior developer grow',
            'How do you balance your own work with mentoring?'
          ],
          preparation: [
            'Prepare mentoring success stories',
            'Show ability to teach and guide others',
            'Demonstrate patience and communication skills'
          ]
        }
      ]
    },
    senior: {
      name: 'Senior Developer (5+ years)',
      focus: 'System architecture and team leadership',
      scenarios: [
        {
          title: 'System Architecture Decisions',
          description: 'Making critical technical decisions that affect the entire system',
          skills: ['Strategic thinking', 'Trade-off analysis', 'Long-term planning'],
          questions: [
            'How do you evaluate different architectural approaches?',
            'Describe a time you made a difficult technical decision',
            'How do you balance technical debt with new features?'
          ],
          preparation: [
            'Prepare examples of major architectural decisions',
            'Show ability to think strategically about technology',
            'Demonstrate understanding of business impact'
          ]
        },
        {
          title: 'Cross-Team Collaboration',
          description: 'Working with multiple teams to deliver complex projects',
          skills: ['Stakeholder management', 'Communication', 'Influence without authority'],
          questions: [
            'How do you align multiple teams toward a common goal?',
            'Tell me about a time you had to influence without authority',
            'How do you handle conflicting priorities across teams?'
          ],
          preparation: [
            'Prepare examples of successful cross-team projects',
            'Show ability to influence and collaborate',
            'Demonstrate strategic thinking'
          ]
        }
      ]
    },
    lead: {
      name: 'Tech Lead / Principal (7+ years)',
      focus: 'Organizational impact and technical vision',
      scenarios: [
        {
          title: 'Technical Vision & Strategy',
          description: 'Setting technical direction for multiple teams or the entire organization',
          skills: ['Visionary thinking', 'Strategic planning', 'Executive communication'],
          questions: [
            'How do you develop and communicate technical strategy?',
            'Describe a time you influenced organization-wide technical decisions',
            'How do you balance innovation with stability?'
          ],
          preparation: [
            'Prepare examples of strategic technical leadership',
            'Show ability to think at organizational scale',
            'Demonstrate executive-level communication'
          ]
        },
        {
          title: 'Crisis Management',
          description: 'Leading the team through critical production issues or major incidents',
          skills: ['Crisis leadership', 'Decision making under pressure', 'Communication'],
          questions: [
            'Walk me through how you handle a major production outage',
            'How do you make decisions when you don\'t have complete information?',
            'Describe a time you led a team through a crisis'
          ],
          preparation: [
            'Prepare detailed incident response examples',
            'Show calm leadership under pressure',
            'Demonstrate systematic problem-solving'
          ]
        }
      ]
    }
  };

  const interviewFormats = [
    {
      format: 'Behavioral Deep Dive',
      duration: '45-60 mins',
      structure: 'STAR method scenarios with follow-up questions',
      tips: ['Prepare 3-4 detailed examples per scenario', 'Focus on your specific contributions', 'Quantify impact where possible']
    },
    {
      format: 'Technical Discussion',
      duration: '30-45 mins',
      structure: 'Discussion of past projects and technical decisions',
      tips: ['Be ready to dive deep into technical details', 'Explain trade-offs and alternatives considered', 'Show learning from mistakes']
    },
    {
      format: 'Case Study Analysis',
      duration: '60-90 mins',
      structure: 'Hypothetical scenario requiring role-appropriate response',
      tips: ['Ask clarifying questions', 'Structure your approach clearly', 'Consider multiple stakeholders']
    }
  ];

  const preparationTips = {
    junior: [
      'Focus on learning examples and growth mindset',
      'Show enthusiasm for technology and problem-solving',
      'Prepare examples of overcoming challenges',
      'Demonstrate ability to receive and implement feedback'
    ],
    mid: [
      'Highlight project ownership and end-to-end delivery',
      'Show examples of technical leadership and mentoring',
      'Demonstrate ability to balance technical and business needs',
      'Prepare stories about handling increased responsibility'
    ],
    senior: [
      'Focus on system-level thinking and architectural decisions',
      'Show examples of leading technical initiatives',
      'Demonstrate ability to influence and collaborate across teams',
      'Highlight strategic thinking and long-term planning'
    ],
    lead: [
      'Emphasize organizational impact and technical vision',
      'Show examples of setting technical strategy and direction',
      'Demonstrate executive-level communication and influence',
      'Highlight experience managing complex, multi-team initiatives'
    ]
  };

  const practiceExercises = [
    {
      exercise: 'Scenario Role Play',
      description: 'Practice responding to role-specific scenarios with a peer or mentor',
      timeCommitment: '30-45 mins',
      frequency: 'Weekly'
    },
    {
      exercise: 'STAR Story Bank',
      description: 'Develop and refine 10-15 detailed examples using STAR method',
      timeCommitment: '2-3 hours',
      frequency: 'One-time setup, regular updates'
    },
    {
      exercise: 'Mock Behavioral Interview',
      description: 'Full behavioral interview simulation with feedback',
      timeCommitment: '60-90 mins',
      frequency: 'Bi-weekly'
    },
    {
      exercise: 'Industry Research',
      description: 'Stay current with role-appropriate industry trends and challenges',
      timeCommitment: '30 mins',
      frequency: 'Daily'
    }
  ];

  const selectedLevelData = roleLevels[selectedLevel as keyof typeof roleLevels];

  return (
    <PlatformLayout
      sidebarTitle="Candidate Platform"
      sidebarSubtitle="Interview Preparation"
      sidebarSections={candidateNavigation}
    >
      <div className="min-h-screen bg-gradient-to-br from-emerald-50 via-white to-teal-50 p-6">
        <div className="max-w-7xl mx-auto space-y-8">
          {/* Header */}
          <div className="text-center space-y-4">
            <div className="inline-flex items-center space-x-2 bg-emerald-100 text-emerald-800 px-4 py-2 rounded-full text-sm font-medium">
              <Users className="h-4 w-4" />
              <span>Role-Based Interview Scenarios</span>
            </div>
            <h1 className="text-4xl font-bold text-gray-900">
              Level-Specific Interview Preparation
            </h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Tailored interview scenarios and preparation strategies based on your experience level, 
              from junior developer to technical leadership roles.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Main Content */}
            <div className="lg:col-span-2 space-y-6">
              {/* Role Level Selection */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Target className="h-5 w-5" />
                    <span>Select Your Experience Level</span>
                  </CardTitle>
                  <CardDescription>Choose your career level for tailored interview scenarios</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                    {Object.entries(roleLevels).map(([key, level]) => (
                      <Card 
                        key={key}
                        className={`cursor-pointer transition-all duration-300 border-2 ${
                          selectedLevel === key 
                            ? 'border-emerald-500 shadow-lg' 
                            : 'border-gray-200 hover:border-emerald-300'
                        }`}
                        onClick={() => setSelectedLevel(key)}
                      >
                        <CardContent className="p-4">
                          <h3 className="font-semibold text-lg mb-2">{level.name}</h3>
                          <p className="text-sm text-gray-600">{level.focus}</p>
                          <div className="mt-3">
                            <Badge variant={selectedLevel === key ? 'default' : 'outline'}>
                              {level.scenarios.length} scenarios
                            </Badge>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* Selected Level Scenarios */}
              <Card>
                <CardHeader className="bg-gradient-to-r from-emerald-500 to-teal-500 text-white">
                  <CardTitle className="text-xl">{selectedLevelData.name}</CardTitle>
                  <CardDescription className="text-white/80">
                    {selectedLevelData.focus}
                  </CardDescription>
                </CardHeader>
                <CardContent className="p-6">
                  <div className="space-y-8">
                    {selectedLevelData.scenarios.map((scenario: any, index: number) => (
                      <div key={index} className="p-6 border rounded-lg bg-gray-50">
                        <h3 className="text-xl font-semibold mb-3 text-emerald-700">{scenario.title}</h3>
                        <p className="text-gray-700 mb-4">{scenario.description}</p>
                        
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
                          <div>
                            <h4 className="font-semibold text-blue-700 mb-2">Key Skills Assessed</h4>
                            <div className="space-y-1">
                              {scenario.skills.map((skill: any, i: number) => (
                                <div key={i} className="flex items-center space-x-2">
                                  <CheckCircle className="h-4 w-4 text-blue-500" />
                                  <span className="text-sm">{skill}</span>
                                </div>
                              ))}
                            </div>
                          </div>
                          
                          <div>
                            <h4 className="font-semibold text-purple-700 mb-2">Common Questions</h4>
                            <div className="space-y-2">
                              {scenario.questions.map((question: any, i: number) => (
                                <div key={i} className="text-sm text-gray-600 p-2 bg-white rounded border-l-2 border-purple-300">
                                  "{question}"
                                </div>
                              ))}
                            </div>
                          </div>
                          
                          <div>
                            <h4 className="font-semibold text-green-700 mb-2">Preparation Tips</h4>
                            <div className="space-y-1">
                              {scenario.preparation.map((tip: any, i: number) => (
                                <div key={i} className="flex items-start space-x-2">
                                  <Lightbulb className="h-4 w-4 text-green-500 mt-0.5" />
                                  <span className="text-sm text-gray-700">{tip}</span>
                                </div>
                              ))}
                            </div>
                          </div>
                        </div>
                        
                        <div className="flex gap-3">
                          <Button className="flex-1 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700">
                            <Play className="h-4 w-4 mr-2" />
                            Practice This Scenario
                          </Button>
                          <Button variant="outline" className="flex-1">
                            <BookOpen className="h-4 w-4 mr-2" />
                            Study Guide
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* Interview Formats */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <MessageSquare className="h-5 w-5" />
                    <span>Interview Formats</span>
                  </CardTitle>
                  <CardDescription>Common behavioral interview formats you might encounter</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {interviewFormats.map((format, index) => (
                      <div key={index} className="p-4 border rounded-lg">
                        <div className="flex items-center justify-between mb-2">
                          <h3 className="font-semibold text-lg">{format.format}</h3>
                          <Badge variant="outline">{format.duration}</Badge>
                        </div>
                        <p className="text-gray-700 mb-3">{format.structure}</p>
                        <div>
                          <span className="font-medium text-emerald-700">Success Tips:</span>
                          <ul className="list-disc list-inside mt-1 space-y-1">
                            {format.tips.map((tip, i) => (
                              <li key={i} className="text-sm text-gray-600">{tip}</li>
                            ))}
                          </ul>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Sidebar */}
            <div className="space-y-6">
              {/* Preparation Checklist */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Target className="h-5 w-5" />
                    <span>Level-Specific Tips</span>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  {preparationTips[selectedLevel as keyof typeof preparationTips]?.map((tip: any, index: number) => (
                    <div key={index} className="flex items-start space-x-2 p-3 bg-emerald-50 rounded-lg">
                      <CheckCircle className="h-4 w-4 text-emerald-500 mt-0.5" />
                      <span className="text-sm text-gray-700">{tip}</span>
                    </div>
                  ))}
                </CardContent>
              </Card>

              {/* Practice Exercises */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Activity className="h-5 w-5" />
                    <span>Practice Exercises</span>
                  </CardTitle>
                  <CardDescription>Regular practice for behavioral interviews</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  {practiceExercises.map((exercise, index) => (
                    <div key={index} className="p-3 border rounded-lg">
                      <div className="flex items-center justify-between mb-2">
                        <span className="font-medium text-sm">{exercise.exercise}</span>
                        <Badge variant="outline" className="text-xs">{exercise.frequency}</Badge>
                      </div>
                      <p className="text-xs text-gray-600 mb-2">{exercise.description}</p>
                      <div className="flex items-center justify-between">
                        <span className="text-xs text-blue-600">{exercise.timeCommitment}</span>
                        <Button variant="ghost" size="sm" className="text-xs">
                          <ArrowRight className="h-3 w-3" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </CardContent>
              </Card>

              {/* Progress Metrics */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <TrendingUp className="h-5 w-5" />
                    <span>Practice Progress</span>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="text-center">
                    <div className="text-2xl font-bold text-emerald-600">8</div>
                    <div className="text-sm text-gray-500">Scenarios Practiced</div>
                  </div>
                  
                  <div className="space-y-3">
                    <div>
                      <div className="flex justify-between text-sm mb-1">
                        <span>Story Bank Completion</span>
                        <span>75%</span>
                      </div>
                      <Progress value={75} className="h-2" />
                    </div>
                    <div>
                      <div className="flex justify-between text-sm mb-1">
                        <span>Mock Interview Sessions</span>
                        <span>4/6</span>
                      </div>
                      <Progress value={67} className="h-2" />
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Quick Actions */}
              <div className="space-y-3">
                <Button size="lg" className="w-full bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700">
                  <Play className="h-4 w-4 mr-2" />
                  Start Role Practice
                </Button>
                <Button variant="outline" size="lg" className="w-full">
                  <Brain className="h-4 w-4 mr-2" />
                  STAR Story Builder
                </Button>
                <Button variant="outline" size="lg" className="w-full">
                  <Award className="h-4 w-4 mr-2" />
                  Mock Interview
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </PlatformLayout>
  );
};

export default RoleScenarios;