import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import PlatformLayout from "@/components/layout/platform-layout";
import { platformConfigs } from "@/config/complete-navigation";
import { useThemeClasses } from "@/lib/theme-config";
import { 
  Smartphone, 
  Download, 
  Star, 
  Bell, 
  MapPin, 
  Clock, 
  Users, 
  Zap,
  Shield,
  Wifi,
  Camera,
  Mic,
  FileText,
  BarChart3,
  Settings,
  RefreshCw,
  Globe,
  QrCode
} from "lucide-react";

function MobileAppContent() {
  const [selectedFeature, setSelectedFeature] = useState("overview");

  const appFeatures = [
    {
      id: "job-search",
      title: "Mobile Job Search",
      description: "Search and apply for jobs on-the-go with smart notifications",
      icon: MapPin,
      benefits: [
        "Location-based job discovery",
        "One-tap applications",
        "Push notifications for new matches",
        "Offline job saving"
      ]
    },
    {
      id: "skill-testing",
      title: "Mobile Skill Tests",
      description: "Take skill assessments anywhere with adaptive mobile interface",
      icon: FileText,
      benefits: [
        "Touch-optimized test interface",
        "Offline test capability",
        "Real-time progress sync",
        "Mobile-friendly code editor"
      ]
    },
    {
      id: "video-interviews",
      title: "Video Interviews",
      description: "Conduct video interviews with built-in recording and analysis",
      icon: Camera,
      benefits: [
        "HD video recording",
        "AI-powered feedback",
        "Interview scheduling",
        "Practice mode available"
      ]
    },
    {
      id: "networking",
      title: "Professional Networking",
      description: "Connect with professionals and attend virtual events",
      icon: Users,
      benefits: [
        "QR code business cards",
        "Event check-ins",
        "Contact management",
        "Messaging integration"
      ]
    },
    {
      id: "analytics",
      title: "Performance Analytics",
      description: "Track your career progress with mobile-optimized dashboards",
      icon: BarChart3,
      benefits: [
        "Real-time performance metrics",
        "Goal tracking",
        "Achievement notifications",
        "Weekly progress reports"
      ]
    }
  ];

  const deviceCompatibility = [
    {
      platform: "iOS",
      minVersion: "iOS 14.0+",
      downloadUrl: "https://apps.apple.com/talenthub",
      icon: "🍎",
      features: ["Face ID", "Siri Shortcuts", "Apple Watch", "CarPlay"]
    },
    {
      platform: "Android",
      minVersion: "Android 8.0+",
      downloadUrl: "https://play.google.com/store/talenthub",
      icon: "🤖",
      features: ["Fingerprint", "Google Assistant", "Wear OS", "Android Auto"]
    }
  ];

  const appStats = {
    downloads: "2.1M+",
    rating: 4.8,
    reviews: 45672,
    updateFrequency: "Bi-weekly",
    offlineCapability: "85%"
  };

  const mobileOnlyFeatures = [
    {
      title: "Smart Camera Resume Scanner",
      description: "Scan physical resumes and business cards instantly",
      icon: Camera,
      availability: "iOS & Android"
    },
    {
      title: "Voice-to-Text Applications",
      description: "Apply to jobs using voice commands and AI transcription",
      icon: Mic,
      availability: "iOS & Android"
    },
    {
      title: "Geo-fenced Job Alerts",
      description: "Get notified when passing by companies with open positions",
      icon: MapPin,
      availability: "iOS & Android"
    },
    {
      title: "Offline Skill Assessment",
      description: "Take tests without internet and sync when connected",
      icon: Wifi,
      availability: "iOS & Android"
    },
    {
      title: "Apple Watch Integration",
      description: "Get interview reminders and quick job stats on your wrist",
      icon: Clock,
      availability: "iOS only"
    },
    {
      title: "Android Widgets",
      description: "Home screen widgets for job search and quick actions",
      icon: Settings,
      availability: "Android only"
    }
  ];

  const securityFeatures = [
    "End-to-end encryption for all communications",
    "Biometric authentication (Face ID, Fingerprint)",
    "Secure document storage with auto-deletion",
    "Privacy-first data handling",
    "GDPR compliant data management"
  ];

  return (
    <div className="max-w-7xl mx-auto px-6 py-8">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-sky-800 mb-2 flex items-center gap-3">
          <Smartphone className="w-8 h-8" />
          TalentHub Mobile App
        </h1>
        <p className="text-sky-600">Your complete career toolkit in your pocket - available on iOS and Android</p>
      </div>

      {/* App Overview Cards */}
      <div className="grid grid-cols-1 md:grid-cols-5 gap-6 mb-8">
        <Card className="border-sky-200">
          <CardContent className="p-6 text-center">
            <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mx-auto mb-3">
              <Download className="w-6 h-6 text-blue-600" />
            </div>
            <h3 className="text-2xl font-bold text-sky-800">{appStats.downloads}</h3>
            <p className="text-sm text-sky-600">Downloads</p>
          </CardContent>
        </Card>

        <Card className="border-sky-200">
          <CardContent className="p-6 text-center">
            <div className="w-12 h-12 bg-yellow-100 rounded-lg flex items-center justify-center mx-auto mb-3">
              <Star className="w-6 h-6 text-yellow-600" />
            </div>
            <h3 className="text-2xl font-bold text-sky-800">{appStats.rating}</h3>
            <p className="text-sm text-sky-600">App Store Rating</p>
          </CardContent>
        </Card>

        <Card className="border-sky-200">
          <CardContent className="p-6 text-center">
            <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mx-auto mb-3">
              <Users className="w-6 h-6 text-green-600" />
            </div>
            <h3 className="text-2xl font-bold text-sky-800">{appStats.reviews.toLocaleString()}</h3>
            <p className="text-sm text-sky-600">User Reviews</p>
          </CardContent>
        </Card>

        <Card className="border-sky-200">
          <CardContent className="p-6 text-center">
            <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center mx-auto mb-3">
              <RefreshCw className="w-6 h-6 text-purple-600" />
            </div>
            <h3 className="text-2xl font-bold text-sky-800">{appStats.updateFrequency}</h3>
            <p className="text-sm text-sky-600">Updates</p>
          </CardContent>
        </Card>

        <Card className="border-sky-200">
          <CardContent className="p-6 text-center">
            <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center mx-auto mb-3">
              <Wifi className="w-6 h-6 text-orange-600" />
            </div>
            <h3 className="text-2xl font-bold text-sky-800">{appStats.offlineCapability}</h3>
            <p className="text-sm text-sky-600">Offline Features</p>
          </CardContent>
        </Card>
      </div>

      {/* Download Section */}
      <Card className="mb-8 border-sky-200 bg-gradient-to-r from-sky-50 to-blue-50">
        <CardHeader>
          <CardTitle className="text-center text-2xl text-sky-800">Download TalentHub Mobile</CardTitle>
          <CardDescription className="text-center">
            Get started with your mobile career toolkit today
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="flex flex-col md:flex-row gap-6 justify-center items-center">
            {deviceCompatibility.map((device, index) => (
              <div key={index} className="text-center">
                <div className="text-6xl mb-4">{device.icon}</div>
                <h3 className="text-lg font-semibold text-sky-800 mb-2">{device.platform}</h3>
                <p className="text-sm text-gray-600 mb-4">{device.minVersion}</p>
                <Button className="bg-sky-600 hover:bg-sky-700 mb-3">
                  <Download className="w-4 h-4 mr-2" />
                  Download for {device.platform}
                </Button>
                <div className="text-xs text-gray-500">
                  {device.features.join(" • ")}
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <Tabs defaultValue="features" className="space-y-6">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="features">Core Features</TabsTrigger>
          <TabsTrigger value="previews">App Previews</TabsTrigger>
          <TabsTrigger value="mobile-only">Mobile-Only</TabsTrigger>
          <TabsTrigger value="security">Security</TabsTrigger>
          <TabsTrigger value="support">Support</TabsTrigger>
        </TabsList>

        {/* Core Features Tab */}
        <TabsContent value="features" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {appFeatures.map((feature) => (
              <Card key={feature.id} className="shadow-sm border-sky-200">
                <CardHeader>
                  <div className="flex items-center gap-3">
                    <div className="w-12 h-12 bg-sky-100 rounded-lg flex items-center justify-center">
                      <feature.icon className="w-6 h-6 text-sky-600" />
                    </div>
                    <div>
                      <CardTitle className="text-lg text-sky-800">{feature.title}</CardTitle>
                      <CardDescription>{feature.description}</CardDescription>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    {feature.benefits.map((benefit, index) => (
                      <div key={index} className="flex items-center text-sm">
                        <Zap className="w-4 h-4 text-green-600 mr-2 flex-shrink-0" />
                        <span>{benefit}</span>
                      </div>
                    ))}
                  </div>
                  <Button className="w-full mt-4 bg-sky-600 hover:bg-sky-700">
                    Try This Feature
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* Mobile Screen Previews Tab */}
        <TabsContent value="previews" className="space-y-6">
          <div className="text-center mb-8">
            <h3 className="text-2xl font-bold text-sky-800 mb-2">Mobile App Previews</h3>
            <p className="text-gray-600">Experience the TalentHub mobile interface across different features</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {/* Job Search Screen */}
            <div className="bg-white rounded-2xl shadow-lg p-4 border-2 border-gray-200">
              <div className="bg-gray-900 rounded-xl overflow-hidden">
                {/* Phone Frame */}
                <div className="bg-black px-6 py-2 flex justify-center">
                  <div className="w-16 h-1 bg-gray-600 rounded-full"></div>
                </div>
                
                {/* Screen Content */}
                <div className="bg-gradient-to-b from-sky-50 to-white px-4 py-6 h-96">
                  {/* Header */}
                  <div className="flex items-center justify-between mb-6">
                    <h4 className="text-lg font-bold text-sky-800">Job Search</h4>
                    <div className="w-8 h-8 bg-sky-100 rounded-full flex items-center justify-center">
                      <Bell className="w-4 h-4 text-sky-600" />
                    </div>
                  </div>
                  
                  {/* Search Bar */}
                  <div className="bg-white rounded-lg p-3 shadow-sm mb-4">
                    <div className="flex items-center text-gray-400 text-sm">
                      <MapPin className="w-4 h-4 mr-2" />
                      Search jobs near you...
                    </div>
                  </div>
                  
                  {/* Job Cards */}
                  <div className="space-y-3">
                    <div className="bg-white rounded-lg p-3 shadow-sm border-l-4 border-sky-500">
                      <h5 className="font-semibold text-sm text-gray-900">Senior Developer</h5>
                      <p className="text-xs text-gray-600">TechCorp • Remote</p>
                      <div className="flex justify-between items-center mt-2">
                        <span className="text-xs text-green-600 font-medium">$120k - $150k</span>
                        <button className="bg-sky-500 text-white px-3 py-1 rounded text-xs">Apply</button>
                      </div>
                    </div>
                    
                    <div className="bg-white rounded-lg p-3 shadow-sm border-l-4 border-purple-500">
                      <h5 className="font-semibold text-sm text-gray-900">Frontend Engineer</h5>
                      <p className="text-xs text-gray-600">StartupXYZ • San Francisco</p>
                      <div className="flex justify-between items-center mt-2">
                        <span className="text-xs text-green-600 font-medium">$100k - $130k</span>
                        <button className="bg-purple-500 text-white px-3 py-1 rounded text-xs">Apply</button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <h4 className="text-center font-semibold text-gray-800 mt-4">Job Discovery</h4>
              <p className="text-center text-sm text-gray-600">Location-based search with instant apply</p>
            </div>

            {/* Skill Test Screen */}
            <div className="bg-white rounded-2xl shadow-lg p-4 border-2 border-gray-200">
              <div className="bg-gray-900 rounded-xl overflow-hidden">
                <div className="bg-black px-6 py-2 flex justify-center">
                  <div className="w-16 h-1 bg-gray-600 rounded-full"></div>
                </div>
                
                <div className="bg-gradient-to-b from-blue-50 to-white px-4 py-6 h-96">
                  <div className="flex items-center justify-between mb-6">
                    <h4 className="text-lg font-bold text-blue-800">JavaScript Test</h4>
                    <div className="text-sm text-blue-600 font-medium">15:30</div>
                  </div>
                  
                  {/* Progress Bar */}
                  <div className="bg-gray-200 rounded-full h-2 mb-6">
                    <div className="bg-blue-500 h-2 rounded-full w-3/5"></div>
                  </div>
                  
                  {/* Question */}
                  <div className="bg-white rounded-lg p-4 shadow-sm mb-4">
                    <h5 className="font-semibold text-sm mb-2">Question 3 of 5</h5>
                    <p className="text-xs text-gray-700 mb-3">What is the output of this code?</p>
                    
                    {/* Code Block */}
                    <div className="bg-gray-900 rounded p-2 mb-3">
                      <code className="text-xs text-green-400">
                        console.log(typeof null);
                      </code>
                    </div>
                    
                    {/* Options */}
                    <div className="space-y-2">
                      <div className="flex items-center">
                        <div className="w-3 h-3 border border-gray-300 rounded-full mr-2"></div>
                        <span className="text-xs">string</span>
                      </div>
                      <div className="flex items-center">
                        <div className="w-3 h-3 bg-blue-500 rounded-full mr-2"></div>
                        <span className="text-xs">object</span>
                      </div>
                    </div>
                  </div>
                  
                  <button className="w-full bg-blue-500 text-white py-2 rounded-lg text-sm font-medium">
                    Next Question
                  </button>
                </div>
              </div>
              <h4 className="text-center font-semibold text-gray-800 mt-4">Mobile Testing</h4>
              <p className="text-center text-sm text-gray-600">Touch-optimized coding interface</p>
            </div>

            {/* Profile Screen */}
            <div className="bg-white rounded-2xl shadow-lg p-4 border-2 border-gray-200">
              <div className="bg-gray-900 rounded-xl overflow-hidden">
                <div className="bg-black px-6 py-2 flex justify-center">
                  <div className="w-16 h-1 bg-gray-600 rounded-full"></div>
                </div>
                
                <div className="bg-gradient-to-b from-green-50 to-white px-4 py-6 h-96">
                  <div className="text-center mb-6">
                    <div className="w-16 h-16 bg-green-500 rounded-full mx-auto mb-3 flex items-center justify-center">
                      <span className="text-white font-bold text-lg">AJ</span>
                    </div>
                    <h4 className="font-bold text-gray-900">Alex Johnson</h4>
                    <p className="text-sm text-gray-600">Senior Developer</p>
                  </div>
                  
                  {/* Stats */}
                  <div className="grid grid-cols-3 gap-2 mb-6">
                    <div className="text-center">
                      <div className="text-lg font-bold text-green-600">85%</div>
                      <div className="text-xs text-gray-600">Test Score</div>
                    </div>
                    <div className="text-center">
                      <div className="text-lg font-bold text-blue-600">12</div>
                      <div className="text-xs text-gray-600">Applications</div>
                    </div>
                    <div className="text-center">
                      <div className="text-lg font-bold text-purple-600">3</div>
                      <div className="text-xs text-gray-600">Interviews</div>
                    </div>
                  </div>
                  
                  {/* Quick Actions */}
                  <div className="space-y-2">
                    <div className="flex items-center bg-white rounded-lg p-3 shadow-sm">
                      <FileText className="w-4 h-4 text-green-600 mr-3" />
                      <span className="text-sm">Update Resume</span>
                    </div>
                    <div className="flex items-center bg-white rounded-lg p-3 shadow-sm">
                      <BarChart3 className="w-4 h-4 text-blue-600 mr-3" />
                      <span className="text-sm">View Analytics</span>
                    </div>
                  </div>
                </div>
              </div>
              <h4 className="text-center font-semibold text-gray-800 mt-4">Profile Hub</h4>
              <p className="text-center text-sm text-gray-600">Manage career progress on-the-go</p>
            </div>

            {/* Video Interview Screen */}
            <div className="bg-white rounded-2xl shadow-lg p-4 border-2 border-gray-200">
              <div className="bg-gray-900 rounded-xl overflow-hidden">
                <div className="bg-black px-6 py-2 flex justify-center">
                  <div className="w-16 h-1 bg-gray-600 rounded-full"></div>
                </div>
                
                <div className="bg-gradient-to-b from-red-50 to-white px-4 py-6 h-96">
                  <div className="flex items-center justify-between mb-4">
                    <h4 className="text-lg font-bold text-red-800">Live Interview</h4>
                    <div className="flex items-center text-red-600">
                      <div className="w-2 h-2 bg-red-500 rounded-full mr-1 animate-pulse"></div>
                      <span className="text-sm">REC</span>
                    </div>
                  </div>
                  
                  {/* Video Area */}
                  <div className="bg-gray-900 rounded-lg mb-4 h-32 flex items-center justify-center">
                    <Camera className="w-8 h-8 text-gray-500" />
                  </div>
                  
                  {/* Question */}
                  <div className="bg-white rounded-lg p-3 shadow-sm mb-4">
                    <p className="text-sm text-gray-800">
                      "Tell me about your experience with React and state management."
                    </p>
                  </div>
                  
                  {/* Controls */}
                  <div className="flex justify-center space-x-4">
                    <button className="w-12 h-12 bg-red-500 rounded-full flex items-center justify-center">
                      <Mic className="w-5 h-5 text-white" />
                    </button>
                    <button className="w-12 h-12 bg-gray-300 rounded-full flex items-center justify-center">
                      <Camera className="w-5 h-5 text-gray-600" />
                    </button>
                  </div>
                </div>
              </div>
              <h4 className="text-center font-semibold text-gray-800 mt-4">Video Interviews</h4>
              <p className="text-center text-sm text-gray-600">HD recording with AI feedback</p>
            </div>

            {/* Analytics Screen */}
            <div className="bg-white rounded-2xl shadow-lg p-4 border-2 border-gray-200">
              <div className="bg-gray-900 rounded-xl overflow-hidden">
                <div className="bg-black px-6 py-2 flex justify-center">
                  <div className="w-16 h-1 bg-gray-600 rounded-full"></div>
                </div>
                
                <div className="bg-gradient-to-b from-purple-50 to-white px-4 py-6 h-96">
                  <div className="flex items-center justify-between mb-6">
                    <h4 className="text-lg font-bold text-purple-800">Analytics</h4>
                    <div className="text-sm text-purple-600">This Week</div>
                  </div>
                  
                  {/* Chart Area */}
                  <div className="bg-white rounded-lg p-3 shadow-sm mb-4 h-24">
                    <div className="flex items-end justify-between h-full">
                      <div className="w-4 bg-purple-200 rounded-t" style={{height: '40%'}}></div>
                      <div className="w-4 bg-purple-400 rounded-t" style={{height: '70%'}}></div>
                      <div className="w-4 bg-purple-600 rounded-t" style={{height: '100%'}}></div>
                      <div className="w-4 bg-purple-400 rounded-t" style={{height: '60%'}}></div>
                      <div className="w-4 bg-purple-500 rounded-t" style={{height: '80%'}}></div>
                    </div>
                  </div>
                  
                  {/* Metrics */}
                  <div className="grid grid-cols-2 gap-3">
                    <div className="bg-white rounded-lg p-3 shadow-sm text-center">
                      <div className="text-lg font-bold text-purple-600">95%</div>
                      <div className="text-xs text-gray-600">Response Rate</div>
                    </div>
                    <div className="bg-white rounded-lg p-3 shadow-sm text-center">
                      <div className="text-lg font-bold text-green-600">8</div>
                      <div className="text-xs text-gray-600">New Matches</div>
                    </div>
                  </div>
                </div>
              </div>
              <h4 className="text-center font-semibold text-gray-800 mt-4">Performance Insights</h4>
              <p className="text-center text-sm text-gray-600">Real-time career analytics</p>
            </div>

            {/* Networking Screen */}
            <div className="bg-white rounded-2xl shadow-lg p-4 border-2 border-gray-200">
              <div className="bg-gray-900 rounded-xl overflow-hidden">
                <div className="bg-black px-6 py-2 flex justify-center">
                  <div className="w-16 h-1 bg-gray-600 rounded-full"></div>
                </div>
                
                <div className="bg-gradient-to-b from-orange-50 to-white px-4 py-6 h-96">
                  <div className="flex items-center justify-between mb-6">
                    <h4 className="text-lg font-bold text-orange-800">Network</h4>
                    <QrCode className="w-6 h-6 text-orange-600" />
                  </div>
                  
                  {/* Contacts */}
                  <div className="space-y-3 mb-4">
                    <div className="flex items-center bg-white rounded-lg p-3 shadow-sm">
                      <div className="w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center mr-3">
                        <span className="text-white text-xs font-bold">JS</span>
                      </div>
                      <div className="flex-1">
                        <div className="text-sm font-semibold">John Smith</div>
                        <div className="text-xs text-gray-600">Senior HR Manager</div>
                      </div>
                      <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                    </div>
                    
                    <div className="flex items-center bg-white rounded-lg p-3 shadow-sm">
                      <div className="w-8 h-8 bg-purple-500 rounded-full flex items-center justify-center mr-3">
                        <span className="text-white text-xs font-bold">MJ</span>
                      </div>
                      <div className="flex-1">
                        <div className="text-sm font-semibold">Maria Johnson</div>
                        <div className="text-xs text-gray-600">Tech Recruiter</div>
                      </div>
                      <div className="w-2 h-2 bg-orange-500 rounded-full"></div>
                    </div>
                  </div>
                  
                  {/* Quick Connect */}
                  <div className="bg-orange-100 rounded-lg p-3">
                    <div className="text-center">
                      <QrCode className="w-8 h-8 text-orange-600 mx-auto mb-2" />
                      <div className="text-sm font-medium text-orange-800">Share QR Code</div>
                      <div className="text-xs text-orange-600">Quick networking at events</div>
                    </div>
                  </div>
                </div>
              </div>
              <h4 className="text-center font-semibold text-gray-800 mt-4">Professional Network</h4>
              <p className="text-center text-sm text-gray-600">Connect with QR codes and messaging</p>
            </div>
          </div>
        </TabsContent>

        {/* Mobile-Only Features Tab */}
        <TabsContent value="mobile-only" className="space-y-6">
          <div className="space-y-6">
            {mobileOnlyFeatures.map((feature, index) => (
              <Card key={index} className="shadow-sm border-sky-200">
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-3">
                      <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
                        <feature.icon className="w-6 h-6 text-purple-600" />
                      </div>
                      <div>
                        <CardTitle className="text-lg text-sky-800">{feature.title}</CardTitle>
                        <CardDescription>{feature.description}</CardDescription>
                      </div>
                    </div>
                    <Badge variant="outline">{feature.availability}</Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="flex gap-2">
                    <Button size="sm" className="bg-sky-600 hover:bg-sky-700">
                      Learn More
                    </Button>
                    <Button variant="outline" size="sm">
                      <QrCode className="w-4 h-4 mr-2" />
                      QR Demo
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* Security Tab */}
        <TabsContent value="security" className="space-y-6">
          <Card className="border-sky-200">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Shield className="w-5 h-5" />
                Security & Privacy
              </CardTitle>
              <CardDescription>
                Your data security and privacy are our top priorities
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {securityFeatures.map((feature, index) => (
                  <div key={index} className="flex items-center">
                    <Shield className="w-5 h-5 text-green-600 mr-3 flex-shrink-0" />
                    <span className="text-sm">{feature}</span>
                  </div>
                ))}
              </div>
              
              <div className="mt-6 p-4 bg-green-50 rounded-lg">
                <h4 className="font-medium text-green-800 mb-2">Security Certifications</h4>
                <div className="flex flex-wrap gap-2">
                  <Badge className="bg-green-100 text-green-800">SOC 2 Type II</Badge>
                  <Badge className="bg-green-100 text-green-800">ISO 27001</Badge>
                  <Badge className="bg-green-100 text-green-800">GDPR Compliant</Badge>
                  <Badge className="bg-green-100 text-green-800">CCPA Compliant</Badge>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Support Tab */}
        <TabsContent value="support" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card className="border-sky-200">
              <CardHeader>
                <CardTitle>Getting Started</CardTitle>
                <CardDescription>Quick setup guides and tutorials</CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                <Button variant="outline" className="w-full justify-start">
                  <FileText className="w-4 h-4 mr-2" />
                  Setup Guide
                </Button>
                <Button variant="outline" className="w-full justify-start">
                  <Camera className="w-4 h-4 mr-2" />
                  Video Tutorials
                </Button>
                <Button variant="outline" className="w-full justify-start">
                  <Users className="w-4 h-4 mr-2" />
                  Community Forum
                </Button>
              </CardContent>
            </Card>

            <Card className="border-sky-200">
              <CardHeader>
                <CardTitle>Support Channels</CardTitle>
                <CardDescription>Get help when you need it</CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                <Button variant="outline" className="w-full justify-start">
                  <Bell className="w-4 h-4 mr-2" />
                  In-App Support
                </Button>
                <Button variant="outline" className="w-full justify-start">
                  <Globe className="w-4 h-4 mr-2" />
                  Knowledge Base
                </Button>
                <Button variant="outline" className="w-full justify-start">
                  <Users className="w-4 h-4 mr-2" />
                  Live Chat (24/7)
                </Button>
              </CardContent>
            </Card>
          </div>

          <Card className="border-sky-200 bg-blue-50">
            <CardHeader>
              <CardTitle>Mobile App Feedback</CardTitle>
              <CardDescription>Help us improve your mobile experience</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex gap-4">
                <Button className="bg-sky-600 hover:bg-sky-700">
                  <Star className="w-4 h-4 mr-2" />
                  Rate App
                </Button>
                <Button variant="outline">
                  <FileText className="w-4 h-4 mr-2" />
                  Send Feedback
                </Button>
                <Button variant="outline">
                  <Settings className="w-4 h-4 mr-2" />
                  Report Bug
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}

export default function MobileApp() {
  const config = platformConfigs.candidate;
  const theme = useThemeClasses('candidate');
  
  const usageData = [
    { label: "App Downloads", current: 2, max: 5 },
    { label: "Mobile Features", current: 85, max: 100 },
    { label: "Sync Status", current: 100, max: 100 },
  ];

  return (
    <PlatformLayout
      sidebarTitle={config.sidebarTitle}
      sidebarSubtitle={config.sidebarSubtitle}
      sidebarSections={config.sidebarSections}
      usageData={usageData}
    >
      <MobileAppContent />
    </PlatformLayout>
  );
}