import PlatformLayout from "@/components/layout/platform-layout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { BarChart3, Users, Target, Trophy } from "lucide-react";
import { candidateNavigation } from "@/config/complete-navigation";

export default function Benchmarking() {
  return (
    <PlatformLayout 
      sidebarTitle="Candidate Platform"
      sidebarSubtitle="Professional Development Hub"
      sidebarSections={candidateNavigation}
    >
      <div className="max-w-7xl mx-auto p-6 space-y-8">
        <div className="text-center space-y-4">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-red-100 to-pink-100 rounded-full">
            <BarChart3 className="h-5 w-5 text-red-600" />
            <span className="text-sm font-medium text-red-900">Performance Benchmarking</span>
          </div>
          <h1 className="text-4xl font-bold bg-gradient-to-r from-red-600 to-pink-600 bg-clip-text text-transparent">
            Industry Benchmarking Analytics
          </h1>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            Compare your performance against industry standards and peer benchmarks
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <Card className="hover:shadow-md transition-shadow">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="p-3 rounded-lg bg-red-500 text-white">
                  <BarChart3 className="h-6 w-6" />
                </div>
                <div className="text-2xl font-bold text-red-600">87th</div>
              </div>
              <div className="text-sm text-gray-600">Industry Percentile</div>
            </CardContent>
          </Card>

          <Card className="hover:shadow-md transition-shadow">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="p-3 rounded-lg bg-blue-500 text-white">
                  <Users className="h-6 w-6" />
                </div>
                <div className="text-2xl font-bold text-blue-600">4,293</div>
              </div>
              <div className="text-sm text-gray-600">Peer Comparisons</div>
            </CardContent>
          </Card>

          <Card className="hover:shadow-md transition-shadow">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="p-3 rounded-lg bg-green-500 text-white">
                  <Target className="h-6 w-6" />
                </div>
                <div className="text-2xl font-bold text-green-600">+12%</div>
              </div>
              <div className="text-sm text-gray-600">Above Average</div>
            </CardContent>
          </Card>

          <Card className="hover:shadow-md transition-shadow">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="p-3 rounded-lg bg-purple-500 text-white">
                  <Trophy className="h-6 w-6" />
                </div>
                <div className="text-2xl font-bold text-purple-600">5</div>
              </div>
              <div className="text-sm text-gray-600">Top Skill Areas</div>
            </CardContent>
          </Card>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Performance Benchmarking Dashboard</CardTitle>
            <CardDescription>Compare your skills and achievements against industry standards</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-center py-12">
              <BarChart3 className="h-16 w-16 mx-auto text-red-500 mb-4" />
              <h3 className="text-xl font-semibold text-gray-900 mb-2">Industry Benchmarking</h3>
              <p className="text-gray-600 mb-6">Understand where you stand in the market and identify growth opportunities</p>
              <Button className="bg-gradient-to-r from-red-600 to-pink-600 hover:from-red-700 hover:to-pink-700">
                View Benchmark Report
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </PlatformLayout>
  );
}