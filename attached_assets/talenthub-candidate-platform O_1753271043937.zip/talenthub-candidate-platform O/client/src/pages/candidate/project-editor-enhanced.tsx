import { useState, useCallback, useRef, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";
import { Progress } from "@/components/ui/progress";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import Editor from "@monaco-editor/react";
import PlatformLayout from "@/components/layout/platform-layout";
import { platformConfigs } from "@/config/navigation";
import { 
  Code, 
  Play, 
  Save, 
  Download, 
  Upload, 
  FileText, 
  Folder, 
  FolderOpen,
  Plus,
  Trash2,
  Terminal,
  GitBranch,
  Settings,
  Eye,
  EyeOff,
  Search,
  Zap,
  Bug,
  CheckCircle,
  AlertCircle,
  Clock,
  RotateCcw,
  X,
  Maximize2,
  Minimize2
} from "lucide-react";

interface Project {
  id: string;
  name: string;
  description: string;
  language: string;
  framework?: string;
  created: string;
  lastModified: string;
  files: ProjectFile[];
  status: 'draft' | 'in_progress' | 'completed' | 'submitted';
  settings: {
    theme: 'light' | 'vs-dark';
    fontSize: number;
    tabSize: number;
    wordWrap: boolean;
    minimap: boolean;
  };
}

interface ProjectFile {
  id: string;
  name: string;
  path: string;
  type: 'file' | 'folder';
  content?: string;
  language?: string;
  size?: number;
  modified?: string;
  children?: ProjectFile[];
}

interface TestResult {
  id: string;
  fileName: string;
  status: 'passed' | 'failed' | 'error';
  message: string;
  duration: number;
  output?: string;
}

export default function ProjectEditorEnhanced() {
  const config = platformConfigs.candidate;
  const { toast } = useToast();
  
  const [selectedProject, setSelectedProject] = useState<string>("1");
  const [selectedFile, setSelectedFile] = useState<string>("app.js");
  const [fileContent, setFileContent] = useState("");
  const [isRunning, setIsRunning] = useState(false);
  const [output, setOutput] = useState("");
  const [showPreview, setShowPreview] = useState(true);
  const [testResults, setTestResults] = useState<TestResult[]>([]);
  const [isTestRunning, setIsTestRunning] = useState(false);
  const [openTabs, setOpenTabs] = useState<string[]>(["app.js"]);
  const [activeTab, setActiveTab] = useState<string>("app.js");
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [editorSettings, setEditorSettings] = useState({
    theme: 'vs-dark' as 'light' | 'vs-dark',
    fontSize: 14,
    tabSize: 2,
    wordWrap: true,
    minimap: true
  });
  
  const editorRef = useRef<any>(null);

  // Mock project data with realistic content
  const mockProject: Project = {
    id: "1",
    name: "React Task Manager",
    description: "A professional task management application built with React",
    language: "javascript",
    framework: "react",
    created: "2025-06-15T10:00:00Z",
    lastModified: "2025-06-17T09:00:00Z",
    status: "in_progress",
    settings: editorSettings,
    files: [
      {
        id: "app.js",
        name: "app.js",
        path: "/app.js",
        type: "file",
        language: "javascript",
        content: `import React, { useState, useEffect } from 'react';
import './styles.css';

function TaskManager() {
  const [tasks, setTasks] = useState([]);
  const [newTask, setNewTask] = useState('');
  const [filter, setFilter] = useState('all');

  useEffect(() => {
    const savedTasks = localStorage.getItem('tasks');
    if (savedTasks) {
      setTasks(JSON.parse(savedTasks));
    }
  }, []);

  useEffect(() => {
    localStorage.setItem('tasks', JSON.stringify(tasks));
  }, [tasks]);

  const addTask = () => {
    if (newTask.trim()) {
      const task = {
        id: Date.now(),
        text: newTask,
        completed: false,
        priority: 'medium',
        created: new Date().toISOString()
      };
      setTasks([...tasks, task]);
      setNewTask('');
    }
  };

  const toggleTask = (id) => {
    setTasks(tasks.map(task =>
      task.id === id ? { ...task, completed: !task.completed } : task
    ));
  };

  const deleteTask = (id) => {
    setTasks(tasks.filter(task => task.id !== id));
  };

  const filteredTasks = tasks.filter(task => {
    if (filter === 'completed') return task.completed;
    if (filter === 'pending') return !task.completed;
    return true;
  });

  return (
    <div className="task-manager">
      <header className="header">
        <h1>Task Manager Pro</h1>
        <p>Stay organized and productive</p>
      </header>

      <div className="add-task-section">
        <div className="input-group">
          <input
            type="text"
            value={newTask}
            onChange={(e) => setNewTask(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && addTask()}
            placeholder="Add a new task..."
            className="task-input"
          />
          <button onClick={addTask} className="add-btn">
            Add Task
          </button>
        </div>

        <div className="filter-section">
          <button 
            onClick={() => setFilter('all')}
            className={\`filter-btn \${filter === 'all' ? 'active' : ''}\`}
          >
            All ({tasks.length})
          </button>
          <button 
            onClick={() => setFilter('pending')}
            className={\`filter-btn \${filter === 'pending' ? 'active' : ''}\`}
          >
            Pending ({tasks.filter(t => !t.completed).length})
          </button>
          <button 
            onClick={() => setFilter('completed')}
            className={\`filter-btn \${filter === 'completed' ? 'active' : ''}\`}
          >
            Completed ({tasks.filter(t => t.completed).length})
          </button>
        </div>
      </div>

      <div className="tasks-container">
        {filteredTasks.length === 0 ? (
          <div className="empty-state">
            <h3>No tasks found</h3>
            <p>Add a task to get started!</p>
          </div>
        ) : (
          <div className="tasks-list">
            {filteredTasks.map(task => (
              <div key={task.id} className={\`task-item \${task.completed ? 'completed' : ''}\`}>
                <div className="task-content">
                  <input
                    type="checkbox"
                    checked={task.completed}
                    onChange={() => toggleTask(task.id)}
                    className="task-checkbox"
                  />
                  <span className="task-text">{task.text}</span>
                  <span className="task-priority priority-{task.priority}">
                    {task.priority}
                  </span>
                </div>
                <button 
                  onClick={() => deleteTask(task.id)}
                  className="delete-btn"
                >
                  Delete
                </button>
              </div>
            ))}
          </div>
        )}
      </div>

      <footer className="footer">
        <p>Built with React • Task Manager Pro v1.0</p>
      </footer>
    </div>
  );
}

export default TaskManager;`,
        size: 2843,
        modified: "2025-06-17T09:00:00Z"
      },
      {
        id: "styles.css",
        name: "styles.css", 
        path: "/styles.css",
        type: "file",
        language: "css",
        content: `/* Task Manager Pro - Professional Styling */

* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}

body {
  font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  min-height: 100vh;
  color: #333;
}

.task-manager {
  max-width: 800px;
  margin: 0 auto;
  padding: 20px;
  min-height: 100vh;
}

.header {
  text-align: center;
  margin-bottom: 40px;
  color: white;
}

.header h1 {
  font-size: 2.5rem;
  margin-bottom: 10px;
  text-shadow: 2px 2px 4px rgba(0,0,0,0.3);
}

.header p {
  font-size: 1.2rem;
  opacity: 0.9;
}

.add-task-section {
  background: white;
  padding: 30px;
  border-radius: 15px;
  box-shadow: 0 10px 30px rgba(0,0,0,0.1);
  margin-bottom: 30px;
}

.input-group {
  display: flex;
  gap: 15px;
  margin-bottom: 20px;
}

.task-input {
  flex: 1;
  padding: 15px;
  border: 2px solid #e1e5e9;
  border-radius: 10px;
  font-size: 16px;
  transition: border-color 0.3s ease;
}

.task-input:focus {
  outline: none;
  border-color: #667eea;
  box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
}

.add-btn {
  padding: 15px 30px;
  background: linear-gradient(135deg, #667eea, #764ba2);
  color: white;
  border: none;
  border-radius: 10px;
  font-weight: 600;
  cursor: pointer;
  transition: transform 0.2s ease;
}

.add-btn:hover {
  transform: translateY(-2px);
  box-shadow: 0 5px 15px rgba(102, 126, 234, 0.4);
}

.filter-section {
  display: flex;
  gap: 10px;
  justify-content: center;
}

.filter-btn {
  padding: 10px 20px;
  border: 2px solid #e1e5e9;
  background: white;
  border-radius: 25px;
  cursor: pointer;
  transition: all 0.3s ease;
  font-weight: 500;
}

.filter-btn.active {
  background: #667eea;
  color: white;
  border-color: #667eea;
}

.filter-btn:hover:not(.active) {
  border-color: #667eea;
  color: #667eea;
}

.tasks-container {
  background: white;
  border-radius: 15px;
  padding: 30px;
  box-shadow: 0 10px 30px rgba(0,0,0,0.1);
  margin-bottom: 30px;
}

.empty-state {
  text-align: center;
  padding: 60px 20px;
  color: #6c757d;
}

.empty-state h3 {
  font-size: 1.5rem;
  margin-bottom: 10px;
}

.tasks-list {
  display: flex;
  flex-direction: column;
  gap: 15px;
}

.task-item {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 20px;
  background: #f8f9fa;
  border-radius: 12px;
  border-left: 4px solid #667eea;
  transition: all 0.3s ease;
}

.task-item:hover {
  transform: translateX(5px);
  box-shadow: 0 5px 15px rgba(0,0,0,0.1);
}

.task-item.completed {
  background: #e8f5e8;
  border-left-color: #28a745;
  opacity: 0.8;
}

.task-content {
  display: flex;
  align-items: center;
  gap: 15px;
  flex: 1;
}

.task-checkbox {
  width: 20px;
  height: 20px;
  cursor: pointer;
}

.task-text {
  flex: 1;
  font-size: 1.1rem;
  transition: all 0.3s ease;
}

.task-item.completed .task-text {
  text-decoration: line-through;
  color: #6c757d;
}

.task-priority {
  padding: 5px 12px;
  border-radius: 15px;
  font-size: 0.8rem;
  font-weight: 600;
  text-transform: uppercase;
}

.priority-high {
  background: #fee;
  color: #dc3545;
}

.priority-medium {
  background: #fff3cd;
  color: #856404;
}

.priority-low {
  background: #d4edda;
  color: #155724;
}

.delete-btn {
  padding: 8px 16px;
  background: #dc3545;
  color: white;
  border: none;
  border-radius: 8px;
  cursor: pointer;
  font-size: 0.9rem;
  transition: background 0.3s ease;
}

.delete-btn:hover {
  background: #c82333;
}

.footer {
  text-align: center;
  color: white;
  opacity: 0.8;
  padding: 20px;
}

/* Responsive Design */
@media (max-width: 768px) {
  .task-manager {
    padding: 15px;
  }
  
  .header h1 {
    font-size: 2rem;
  }
  
  .input-group {
    flex-direction: column;
  }
  
  .filter-section {
    flex-wrap: wrap;
  }
  
  .task-item {
    flex-direction: column;
    align-items: flex-start;
    gap: 15px;
  }
}`,
        size: 3824,
        modified: "2025-06-17T09:00:00Z"
      },
      {
        id: "index.html",
        name: "index.html",
        path: "/index.html", 
        type: "file",
        language: "html",
        content: `<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Task Manager Pro</title>
    <link rel="stylesheet" href="styles.css">
    <script src="https://unpkg.com/react@18/umd/react.development.js"></script>
    <script src="https://unpkg.com/react-dom@18/umd/react-dom.development.js"></script>
    <script src="https://unpkg.com/@babel/standalone/babel.min.js"></script>
</head>
<body>
    <div id="root"></div>
    <script type="text/babel" src="app.js"></script>
    <script type="text/babel">
        ReactDOM.render(<TaskManager />, document.getElementById('root'));
    </script>
</body>
</html>`,
        size: 672,
        modified: "2025-06-17T09:00:00Z"
      }
    ]
  };

  const { data: projects, isLoading } = useQuery({
    queryKey: ["/api/candidate/projects"],
    initialData: [mockProject]
  });

  const currentProject = projects?.find(p => p.id === selectedProject) || mockProject;
  
  // Flatten file structure for easier lookup
  const flattenFiles = (files: ProjectFile[]): ProjectFile[] => {
    const flattened: ProjectFile[] = [];
    files.forEach(file => {
      flattened.push(file);
      if (file.children) {
        flattened.push(...flattenFiles(file.children));
      }
    });
    return flattened;
  };
  
  const allFiles = flattenFiles(currentProject?.files || []);
  const currentFile = allFiles.find(f => f.id === activeTab);

  // Update file content when switching files
  useEffect(() => {
    if (currentFile?.content) {
      setFileContent(currentFile.content);
    }
  }, [currentFile]);

  const saveFileMutation = useMutation({
    mutationFn: async (data: { projectId: string; fileId: string; content: string }) => {
      const res = await apiRequest("PUT", `/api/projects/${data.projectId}/files/${data.fileId}`, { content: data.content });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/candidate/projects"] });
      toast({
        title: "File saved",
        description: "Your changes have been saved successfully.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Save failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const runTestsMutation = useMutation({
    mutationFn: async (projectId: string) => {
      const res = await apiRequest("POST", `/api/projects/${projectId}/test`);
      return res.json();
    },
    onSuccess: (data) => {
      setTestResults(data.results || []);
      toast({
        title: "Tests completed",
        description: `${data.results?.filter((r: TestResult) => r.status === 'passed').length || 0} tests passed`,
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Test execution failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleEditorChange = useCallback((value: string | undefined) => {
    setFileContent(value || "");
  }, []);

  const handleEditorDidMount = useCallback((editor: any, monaco: any) => {
    editorRef.current = editor;
    
    // Configure Monaco Editor themes
    monaco.editor.defineTheme('customLight', {
      base: 'vs',
      inherit: true,
      rules: [],
      colors: {
        'editor.background': '#ffffff',
        'editor.foreground': '#333333',
        'editorLineNumber.foreground': '#888888',
        'editor.selectionBackground': '#b3d9ff',
        'editor.inactiveSelectionBackground': '#e5e5e5'
      }
    });

    monaco.editor.defineTheme('customDark', {
      base: 'vs-dark',
      inherit: true,
      rules: [],
      colors: {
        'editor.background': '#1e1e1e',
        'editor.foreground': '#d4d4d4',
        'editorLineNumber.foreground': '#858585',
        'editor.selectionBackground': '#264f78',
        'editor.inactiveSelectionBackground': '#3a3d41'
      }
    });

    // Set initial theme
    monaco.editor.setTheme(editorSettings.theme === 'vs-dark' ? 'customDark' : 'customLight');
    
    // Add keyboard shortcuts
    editor.addCommand(monaco.KeyMod.CtrlCmd | monaco.KeyCode.KeyS, () => {
      handleSaveFile();
    });
  }, [editorSettings.theme]);

  const handleSaveFile = useCallback(() => {
    if (currentFile && selectedProject) {
      saveFileMutation.mutate({
        projectId: selectedProject,
        fileId: currentFile.id,
        content: fileContent
      });
    }
  }, [currentFile, selectedProject, fileContent, saveFileMutation]);

  const handleRunProject = useCallback(async () => {
    setIsRunning(true);
    setOutput("Building project...\n");
    
    // Simulate project execution
    setTimeout(() => {
      setOutput(prev => prev + "✓ Project built successfully\n");
      setTimeout(() => {
        setOutput(prev => prev + "✓ Starting development server on http://localhost:3000\n");
        setTimeout(() => {
          setOutput(prev => prev + "✓ Server running successfully\n");
          setIsRunning(false);
          toast({
            title: "Project started",
            description: "Your project is now running successfully.",
          });
        }, 1000);
      }, 1000);
    }, 1000);
  }, [toast]);

  const handleRunTests = useCallback(() => {
    setIsTestRunning(true);
    runTestsMutation.mutate(selectedProject);
    setTimeout(() => setIsTestRunning(false), 2000);
  }, [selectedProject, runTestsMutation]);

  const openFile = (file: ProjectFile) => {
    if (file.type === 'file') {
      if (!openTabs.includes(file.id)) {
        setOpenTabs([...openTabs, file.id]);
      }
      setActiveTab(file.id);
      setSelectedFile(file.id);
    }
  };

  const closeTab = (fileId: string) => {
    const newTabs = openTabs.filter(id => id !== fileId);
    setOpenTabs(newTabs);
    
    if (activeTab === fileId && newTabs.length > 0) {
      setActiveTab(newTabs[newTabs.length - 1]);
    } else if (newTabs.length === 0) {
      setActiveTab("");
    }
  };

  const renderFileTree = (files: ProjectFile[], level = 0) => {
    return files.map(file => (
      <div key={file.id} className={`ml-${level * 2}`}>
        <div
          className={`flex items-center space-x-2 px-2 py-1 rounded cursor-pointer hover:bg-gray-100 ${
            activeTab === file.id ? 'bg-blue-100' : ''
          }`}
          onClick={() => openFile(file)}
        >
          {file.type === 'folder' ? (
            <Folder className="w-4 h-4 text-gray-500" />
          ) : (
            <FileText className="w-4 h-4 text-gray-600" />
          )}
          <span className="text-sm">{file.name}</span>
        </div>
        {file.children && (
          <div className="ml-4">
            {renderFileTree(file.children, level + 1)}
          </div>
        )}
      </div>
    ));
  };

  return (
    <PlatformLayout
      sidebarTitle={config.sidebarTitle}
      sidebarSubtitle={config.sidebarSubtitle}
      sidebarSections={config.sidebarSections}
      usageData={config.usageData}
    >
      <div className="h-screen flex flex-col">
        {/* Header */}
        <div className="border-b bg-white px-6 py-4 flex-shrink-0">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-gray-900">Professional Code Editor</h1>
              <p className="text-gray-600">Monaco Editor with IntelliSense and advanced features</p>
            </div>
            
            <div className="flex items-center space-x-3">
              <Button onClick={handleSaveFile} variant="outline" disabled={saveFileMutation.isPending}>
                <Save className="w-4 h-4 mr-2" />
                {saveFileMutation.isPending ? "Saving..." : "Save"}
              </Button>
              
              <Button onClick={handleRunProject} disabled={isRunning}>
                <Play className="w-4 h-4 mr-2" />
                {isRunning ? "Running..." : "Run"}
              </Button>
              
              <Button onClick={handleRunTests} variant="outline" disabled={isTestRunning}>
                <Bug className="w-4 h-4 mr-2" />
                {isTestRunning ? "Testing..." : "Test"}
              </Button>
              
              <Button 
                onClick={() => setIsFullscreen(!isFullscreen)} 
                variant="ghost" 
                size="sm"
              >
                {isFullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
              </Button>
            </div>
          </div>
        </div>

        {/* Main Content */}
        <div className={`flex-1 flex ${isFullscreen ? 'fixed inset-0 z-50 bg-white' : ''}`}>
          {/* File Explorer */}
          {!isFullscreen && (
            <div className="w-80 border-r bg-gray-50 flex flex-col">
              <div className="p-4 border-b">
                <div className="flex items-center justify-between mb-3">
                  <h3 className="font-semibold">Project Explorer</h3>
                  <Button variant="ghost" size="sm">
                    <Plus className="w-4 h-4" />
                  </Button>
                </div>
                
                <Select value={selectedProject} onValueChange={setSelectedProject}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="1">React Task Manager</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <ScrollArea className="flex-1">
                <div className="p-2">
                  {renderFileTree(currentProject.files)}
                </div>
              </ScrollArea>
            </div>
          )}

          {/* Editor Area */}
          <div className="flex-1 flex flex-col">
            {/* Tab Bar */}
            <div className="border-b bg-gray-100 px-2 py-1 flex items-center space-x-1 overflow-x-auto">
              {openTabs.map(tabId => {
                const file = allFiles.find(f => f.id === tabId);
                if (!file) return null;
                
                return (
                  <div
                    key={tabId}
                    className={`flex items-center space-x-2 px-3 py-2 rounded-t-lg cursor-pointer ${
                      activeTab === tabId 
                        ? 'bg-white border-t border-l border-r' 
                        : 'bg-gray-200 hover:bg-gray-300'
                    }`}
                    onClick={() => setActiveTab(tabId)}
                  >
                    <FileText className="w-4 h-4" />
                    <span className="text-sm">{file.name}</span>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="h-4 w-4 p-0 hover:bg-gray-300"
                      onClick={(e) => {
                        e.stopPropagation();
                        closeTab(tabId);
                      }}
                    >
                      <X className="w-3 h-3" />
                    </Button>
                  </div>
                );
              })}
            </div>

            {/* Monaco Editor */}
            <div className="flex-1">
              {currentFile ? (
                <Editor
                  height="100%"
                  language={currentFile.language || 'javascript'}
                  value={fileContent}
                  onChange={handleEditorChange}
                  onMount={handleEditorDidMount}
                  options={{
                    fontSize: editorSettings.fontSize,
                    tabSize: editorSettings.tabSize,
                    wordWrap: editorSettings.wordWrap ? 'on' : 'off',
                    minimap: { enabled: editorSettings.minimap },
                    automaticLayout: true,
                    scrollBeyondLastLine: false,
                    lineNumbers: 'on',
                    renderWhitespace: 'selection',
                    selectOnLineNumbers: true,
                    roundedSelection: false,
                    readOnly: false,
                    cursorStyle: 'line',
                    formatOnPaste: true,
                    formatOnType: true,
                    quickSuggestions: true,
                    suggestOnTriggerCharacters: true,
                    acceptSuggestionOnCommitCharacter: true,
                    acceptSuggestionOnEnter: 'on',
                    wordBasedSuggestions: true
                  }}
                />
              ) : (
                <div className="flex items-center justify-center h-full text-gray-500">
                  <div className="text-center">
                    <Code className="w-16 h-16 mx-auto mb-4 text-gray-300" />
                    <p>Select a file to start editing</p>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Right Panel - Output & Tests */}
          {!isFullscreen && (
            <div className="w-96 border-l bg-white flex flex-col">
              <Tabs defaultValue="output" className="flex-1 flex flex-col">
                <TabsList className="grid w-full grid-cols-3">
                  <TabsTrigger value="output">Output</TabsTrigger>
                  <TabsTrigger value="tests">Tests</TabsTrigger>
                  <TabsTrigger value="settings">Settings</TabsTrigger>
                </TabsList>
                
                <TabsContent value="output" className="flex-1 p-4">
                  <div className="h-full">
                    <h4 className="font-medium mb-3 flex items-center">
                      <Terminal className="w-4 h-4 mr-2" />
                      Console Output
                    </h4>
                    <div className="bg-gray-900 text-green-400 p-4 rounded font-mono text-sm h-64 overflow-auto">
                      {output || "No output yet. Run your project to see results."}
                    </div>
                  </div>
                </TabsContent>
                
                <TabsContent value="tests" className="flex-1 p-4">
                  <div className="h-full">
                    <div className="flex items-center justify-between mb-3">
                      <h4 className="font-medium flex items-center">
                        <Bug className="w-4 h-4 mr-2" />
                        Test Results
                      </h4>
                      <Badge variant={testResults.length > 0 ? "default" : "secondary"}>
                        {testResults.filter(r => r.status === 'passed').length}/{testResults.length} passed
                      </Badge>
                    </div>
                    
                    <ScrollArea className="h-64">
                      {testResults.length > 0 ? (
                        <div className="space-y-2">
                          {testResults.map(result => (
                            <div
                              key={result.id}
                              className={`p-3 rounded border ${
                                result.status === 'passed' 
                                  ? 'bg-green-50 border-green-200' 
                                  : 'bg-red-50 border-red-200'
                              }`}
                            >
                              <div className="flex items-center justify-between">
                                <span className="font-medium text-sm">{result.fileName}</span>
                                {result.status === 'passed' ? (
                                  <CheckCircle className="w-4 h-4 text-green-600" />
                                ) : (
                                  <AlertCircle className="w-4 h-4 text-red-600" />
                                )}
                              </div>
                              <p className="text-xs text-gray-600 mt-1">{result.message}</p>
                              <p className="text-xs text-gray-500">{result.duration}ms</p>
                            </div>
                          ))}
                        </div>
                      ) : (
                        <div className="text-center text-gray-500 py-8">
                          <Bug className="w-8 h-8 mx-auto mb-2 text-gray-300" />
                          <p>No tests run yet</p>
                        </div>
                      )}
                    </ScrollArea>
                  </div>
                </TabsContent>
                
                <TabsContent value="settings" className="flex-1 p-4">
                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="theme">Editor Theme</Label>
                      <Select 
                        value={editorSettings.theme} 
                        onValueChange={(value: 'light' | 'vs-dark') => 
                          setEditorSettings(prev => ({ ...prev, theme: value }))
                        }
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="light">Light</SelectItem>
                          <SelectItem value="vs-dark">Dark</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    
                    <div>
                      <Label htmlFor="fontSize">Font Size</Label>
                      <Input
                        id="fontSize"
                        type="number"
                        value={editorSettings.fontSize}
                        onChange={(e) => 
                          setEditorSettings(prev => ({ ...prev, fontSize: parseInt(e.target.value) }))
                        }
                        min="10"
                        max="24"
                      />
                    </div>
                    
                    <div>
                      <Label htmlFor="tabSize">Tab Size</Label>
                      <Input
                        id="tabSize"
                        type="number"
                        value={editorSettings.tabSize}
                        onChange={(e) => 
                          setEditorSettings(prev => ({ ...prev, tabSize: parseInt(e.target.value) }))
                        }
                        min="2"
                        max="8"
                      />
                    </div>
                  </div>
                </TabsContent>
              </Tabs>
            </div>
          )}
        </div>
      </div>
    </PlatformLayout>
  );
}