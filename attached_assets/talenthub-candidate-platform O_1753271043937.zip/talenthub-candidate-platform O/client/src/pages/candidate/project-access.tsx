import { useState } from "react";
import { useAuth } from "@/hooks/use-auth";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { 
  FolderOpen, 
  Plus, 
  Lock, 
  Unlock,
  Star,
  Code,
  Globe,
  Github,
  ExternalLink,
  Award,
  Users,
  Calendar,
  Eye,
  Heart,
  MessageSquare,
  Share,
  Download,
  Edit,
  Trash2,
  Filter,
  Search,
  BookOpen,
  Zap,
  Crown,
  Shield
} from "lucide-react";
import PlatformLayout from "@/components/layout/platform-layout";
import { platformConfigs } from "@/config/complete-navigation";

function ProjectAccessContent() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [certificationLevel, setCertificationLevel] = useState("beginner");
  const [searchQuery, setSearchQuery] = useState("");
  const [showCreateModal, setShowCreateModal] = useState(false);

  const { data: userCertifications = [] } = useQuery({
    queryKey: ["/api/certifications/my-certifications", user?.id],
    initialData: [
      {
        id: "cert-1",
        name: "React Developer",
        level: "Advanced",
        levelNumber: 3,
        earnedAt: "2024-05-15T10:30:00Z",
        score: 92
      },
      {
        id: "cert-2",
        name: "JavaScript Expert",
        level: "Expert",
        levelNumber: 4,
        earnedAt: "2024-04-20T14:20:00Z",
        score: 88
      },
      {
        id: "cert-3",
        name: "Node.js Professional",
        level: "Professional",
        levelNumber: 3,
        earnedAt: "2024-03-10T09:15:00Z",
        score: 85
      }
    ]
  });

  const { data: availableProjects = [] } = useQuery({
    queryKey: ["/api/projects/available", selectedCategory, certificationLevel],
    initialData: [
      {
        id: "proj-1",
        title: "E-commerce Frontend Challenge",
        description: "Build a responsive e-commerce frontend with React, including product catalog, cart functionality, and checkout process.",
        category: "Frontend",
        difficulty: "Intermediate",
        requiredCertificationLevel: 2,
        estimatedHours: 15,
        technologies: ["React", "CSS", "JavaScript", "API Integration"],
        participants: 247,
        completionRate: 78,
        rating: 4.6,
        isUnlocked: true,
        preview: "/projects/ecommerce-preview.jpg",
        creator: "TechCorp Academy",
        createdAt: "2024-05-01T00:00:00Z"
      },
      {
        id: "proj-2",
        title: "Real-time Chat Application",
        description: "Develop a full-stack chat application with Socket.io, user authentication, and real-time messaging features.",
        category: "Full Stack",
        difficulty: "Advanced",
        requiredCertificationLevel: 3,
        estimatedHours: 25,
        technologies: ["React", "Node.js", "Socket.io", "MongoDB", "JWT"],
        participants: 156,
        completionRate: 65,
        rating: 4.8,
        isUnlocked: true,
        preview: "/projects/chat-preview.jpg",
        creator: "StartupXYZ",
        createdAt: "2024-04-15T00:00:00Z"
      },
      {
        id: "proj-3",
        title: "Machine Learning Prediction Model",
        description: "Create a machine learning model to predict stock prices using Python, pandas, and scikit-learn.",
        category: "Data Science",
        difficulty: "Expert",
        requiredCertificationLevel: 4,
        estimatedHours: 35,
        technologies: ["Python", "Pandas", "Scikit-learn", "TensorFlow", "Jupyter"],
        participants: 89,
        completionRate: 45,
        rating: 4.9,
        isUnlocked: false,
        preview: "/projects/ml-preview.jpg",
        creator: "AI Research Lab",
        createdAt: "2024-03-20T00:00:00Z"
      },
      {
        id: "proj-4",
        title: "Mobile App with React Native",
        description: "Build a cross-platform mobile application for task management with offline capabilities.",
        category: "Mobile",
        difficulty: "Professional",
        requiredCertificationLevel: 3,
        estimatedHours: 30,
        technologies: ["React Native", "Redux", "SQLite", "Push Notifications"],
        participants: 198,
        completionRate: 72,
        rating: 4.5,
        isUnlocked: true,
        preview: "/projects/mobile-preview.jpg",
        creator: "Mobile Dev Academy",
        createdAt: "2024-04-01T00:00:00Z"
      }
    ]
  });

  const { data: myProjects = [] } = useQuery({
    queryKey: ["/api/projects/my-projects"],
    initialData: [
      {
        id: "my-proj-1",
        title: "Personal Portfolio Website",
        description: "A responsive portfolio website showcasing my projects and skills",
        category: "Frontend",
        status: "completed",
        progress: 100,
        startedAt: "2024-05-20T10:00:00Z",
        completedAt: "2024-05-25T16:30:00Z",
        technologies: ["React", "Tailwind CSS", "Framer Motion"],
        githubUrl: "https://github.com/alexjohnson/portfolio",
        liveUrl: "https://alexjohnson.dev",
        feedback: "Excellent implementation with great attention to detail",
        score: 94
      },
      {
        id: "my-proj-2",
        title: "Task Management API",
        description: "RESTful API for task management with user authentication",
        category: "Backend",
        status: "in_progress",
        progress: 65,
        startedAt: "2024-06-01T09:00:00Z",
        technologies: ["Node.js", "Express", "MongoDB", "JWT"],
        githubUrl: "https://github.com/alexjohnson/task-api",
        feedback: null,
        score: null
      }
    ]
  });

  const createProjectMutation = useMutation({
    mutationFn: async (projectData: any) => {
      return apiRequest("POST", "/api/projects/create", projectData);
    },
    onSuccess: () => {
      toast({
        title: "Project Created",
        description: "Your project has been created successfully.",
      });
      setShowCreateModal(false);
      queryClient.invalidateQueries({ queryKey: ["/api/projects/my-projects"] });
    },
  });

  const getUserMaxCertificationLevel = () => {
    if (userCertifications.length === 0) return 1;
    return Math.max(...userCertifications.map((cert: any) => cert.levelNumber));
  };

  const canAccessProject = (project: any) => {
    return getUserMaxCertificationLevel() >= project.requiredCertificationLevel;
  };

  const getDifficultyBadge = (difficulty: string) => {
    const variants = {
      Beginner: "bg-green-100 text-green-800",
      Intermediate: "bg-yellow-100 text-yellow-800",
      Advanced: "bg-orange-100 text-orange-800",
      Expert: "bg-red-100 text-red-800",
      Professional: "bg-purple-100 text-purple-800"
    };
    return variants[difficulty as keyof typeof variants] || variants.Beginner;
  };

  const getStatusBadge = (status: string) => {
    const variants = {
      completed: "bg-green-100 text-green-800",
      in_progress: "bg-blue-100 text-blue-800",
      not_started: "bg-gray-100 text-gray-800",
      paused: "bg-yellow-100 text-yellow-800"
    };
    return variants[status as keyof typeof variants] || variants.not_started;
  };

  const filteredProjects = availableProjects.filter((project: any) => {
    const matchesCategory = selectedCategory === "all" || project.category.toLowerCase() === selectedCategory.toLowerCase();
    const matchesSearch = project.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         project.description.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  return (
    <div className="max-w-7xl mx-auto p-6">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">Project Access Hub</h1>
        <p className="text-muted-foreground">Access exclusive projects based on your certification level</p>
      </div>

      {/* Certification Level Display */}
      <Card className="mb-6 bg-gradient-to-r from-sky-50 to-blue-50 border-sky-200">
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">Your Certification Level</h3>
              <div className="flex items-center space-x-4">
                <Badge className="bg-sky-600 text-white px-4 py-2">
                  <Crown className="w-4 h-4 mr-2" />
                  Level {getUserMaxCertificationLevel()}
                </Badge>
                <span className="text-sm text-gray-600">
                  {userCertifications.length} certifications earned
                </span>
              </div>
            </div>
            <div className="text-right">
              <p className="text-sm text-gray-600 mb-1">Projects Unlocked</p>
              <p className="text-2xl font-bold text-sky-600">
                {filteredProjects.filter((p: any) => canAccessProject(p)).length}
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      <Tabs defaultValue="available" className="space-y-6">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="available">Available Projects</TabsTrigger>
          <TabsTrigger value="my-projects">My Projects</TabsTrigger>
          <TabsTrigger value="create">Create Project</TabsTrigger>
        </TabsList>

        <TabsContent value="available" className="space-y-6">
          {/* Filters */}
          <Card>
            <CardContent className="p-6">
              <div className="flex flex-wrap gap-4 items-center">
                <div className="flex-1 min-w-64">
                  <div className="relative">
                    <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                    <Input
                      placeholder="Search projects..."
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="pl-10"
                    />
                  </div>
                </div>
                <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                  <SelectTrigger className="w-48">
                    <SelectValue placeholder="Category" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Categories</SelectItem>
                    <SelectItem value="frontend">Frontend</SelectItem>
                    <SelectItem value="backend">Backend</SelectItem>
                    <SelectItem value="full stack">Full Stack</SelectItem>
                    <SelectItem value="mobile">Mobile</SelectItem>
                    <SelectItem value="data science">Data Science</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>

          {/* Project Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredProjects.map((project: any) => (
              <Card key={project.id} className={`relative ${!canAccessProject(project) ? 'opacity-75' : ''}`}>
                {!canAccessProject(project) && (
                  <div className="absolute inset-0 bg-gray-900/20 rounded-lg flex items-center justify-center z-10">
                    <div className="bg-white rounded-lg p-4 text-center shadow-lg">
                      <Lock className="w-8 h-8 text-gray-400 mx-auto mb-2" />
                      <p className="text-sm font-medium text-gray-700">
                        Requires Level {project.requiredCertificationLevel}
                      </p>
                      <p className="text-xs text-gray-500">
                        Complete more certifications to unlock
                      </p>
                    </div>
                  </div>
                )}
                
                <CardHeader>
                  <div className="flex items-start justify-between">
                    <Badge className={getDifficultyBadge(project.difficulty)}>
                      {project.difficulty}
                    </Badge>
                    <div className="flex items-center space-x-1">
                      <Star className="w-4 h-4 text-yellow-500" />
                      <span className="text-sm font-medium">{project.rating}</span>
                    </div>
                  </div>
                  <CardTitle className="text-lg">{project.title}</CardTitle>
                  <CardDescription className="line-clamp-2">
                    {project.description}
                  </CardDescription>
                </CardHeader>
                
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between text-sm text-gray-600">
                      <span className="flex items-center">
                        <Users className="w-4 h-4 mr-1" />
                        {project.participants} participants
                      </span>
                      <span className="flex items-center">
                        <Calendar className="w-4 h-4 mr-1" />
                        {project.estimatedHours}h
                      </span>
                    </div>
                    
                    <div className="flex flex-wrap gap-1">
                      {project.technologies.slice(0, 3).map((tech: string) => (
                        <Badge key={tech} variant="outline" className="text-xs">
                          {tech}
                        </Badge>
                      ))}
                      {project.technologies.length > 3 && (
                        <Badge variant="outline" className="text-xs">
                          +{project.technologies.length - 3} more
                        </Badge>
                      )}
                    </div>

                    <div className="pt-2">
                      <div className="flex items-center justify-between text-xs text-gray-500 mb-1">
                        <span>Completion Rate</span>
                        <span>{project.completionRate}%</span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2">
                        <div 
                          className="bg-green-500 h-2 rounded-full"
                          style={{ width: `${project.completionRate}%` }}
                        ></div>
                      </div>
                    </div>

                    <div className="flex space-x-2 pt-2">
                      <Button 
                        size="sm" 
                        className="flex-1"
                        disabled={!canAccessProject(project)}
                      >
                        <BookOpen className="w-3 h-3 mr-1" />
                        Start Project
                      </Button>
                      <Button size="sm" variant="outline">
                        <Eye className="w-3 h-3" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="my-projects" className="space-y-6">
          <div className="space-y-4">
            {myProjects.map((project: any) => (
              <Card key={project.id}>
                <CardContent className="p-6">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center space-x-3 mb-2">
                        <h3 className="text-lg font-semibold">{project.title}</h3>
                        <Badge className={getStatusBadge(project.status)}>
                          {project.status.replace('_', ' ').toUpperCase()}
                        </Badge>
                      </div>
                      <p className="text-gray-600 mb-4">{project.description}</p>
                      
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                        <div>
                          <p className="text-sm text-gray-500 mb-1">Progress</p>
                          <div className="flex items-center space-x-2">
                            <div className="flex-1 bg-gray-200 rounded-full h-2">
                              <div 
                                className="bg-blue-500 h-2 rounded-full"
                                style={{ width: `${project.progress}%` }}
                              ></div>
                            </div>
                            <span className="text-sm font-medium">{project.progress}%</span>
                          </div>
                        </div>
                        
                        <div>
                          <p className="text-sm text-gray-500 mb-1">Started</p>
                          <p className="text-sm">{new Date(project.startedAt).toLocaleDateString()}</p>
                        </div>
                        
                        {project.score && (
                          <div>
                            <p className="text-sm text-gray-500 mb-1">Score</p>
                            <div className="flex items-center space-x-1">
                              <Star className="w-4 h-4 text-yellow-500" />
                              <span className="text-sm font-medium">{project.score}/100</span>
                            </div>
                          </div>
                        )}
                      </div>

                      <div className="flex flex-wrap gap-2 mb-4">
                        {project.technologies.map((tech: string) => (
                          <Badge key={tech} variant="outline" className="text-xs">
                            {tech}
                          </Badge>
                        ))}
                      </div>

                      {project.feedback && (
                        <div className="bg-green-50 p-3 rounded-lg mb-4">
                          <p className="text-sm text-green-800">
                            <strong>Feedback:</strong> {project.feedback}
                          </p>
                        </div>
                      )}
                    </div>
                    
                    <div className="flex flex-col space-y-2 ml-4">
                      <Button size="sm" variant="outline">
                        <Edit className="w-3 h-3 mr-1" />
                        Edit
                      </Button>
                      {project.githubUrl && (
                        <Button size="sm" variant="outline">
                          <Github className="w-3 h-3 mr-1" />
                          Code
                        </Button>
                      )}
                      {project.liveUrl && (
                        <Button size="sm" variant="outline">
                          <ExternalLink className="w-3 h-3 mr-1" />
                          Live
                        </Button>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="create" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Plus className="w-5 h-5 mr-2 text-green-600" />
                Create New Project
              </CardTitle>
              <CardDescription>
                Create and share your own projects with the community
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <div>
                    <label className="text-sm font-medium mb-2 block">Project Title</label>
                    <Input placeholder="Enter project title" />
                  </div>
                  
                  <div>
                    <label className="text-sm font-medium mb-2 block">Category</label>
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="Select category" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="frontend">Frontend</SelectItem>
                        <SelectItem value="backend">Backend</SelectItem>
                        <SelectItem value="fullstack">Full Stack</SelectItem>
                        <SelectItem value="mobile">Mobile</SelectItem>
                        <SelectItem value="datascience">Data Science</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <label className="text-sm font-medium mb-2 block">
                      Required Certification Level
                      <Shield className="w-4 h-4 inline ml-1 text-amber-500" />
                    </label>
                    <Select value={certificationLevel} onValueChange={setCertificationLevel}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="1">Level 1 - Beginner</SelectItem>
                        <SelectItem value="2">Level 2 - Intermediate</SelectItem>
                        <SelectItem value="3">Level 3 - Advanced</SelectItem>
                        <SelectItem value="4">Level 4 - Expert</SelectItem>
                        <SelectItem value="5">Level 5 - Professional</SelectItem>
                      </SelectContent>
                    </Select>
                    <p className="text-xs text-gray-500 mt-1">
                      Users must have this certification level to access the project
                    </p>
                  </div>

                  <div>
                    <label className="text-sm font-medium mb-2 block">Estimated Hours</label>
                    <Input type="number" placeholder="20" />
                  </div>
                </div>

                <div className="space-y-4">
                  <div>
                    <label className="text-sm font-medium mb-2 block">Description</label>
                    <Textarea 
                      placeholder="Detailed project description..."
                      rows={4}
                    />
                  </div>

                  <div>
                    <label className="text-sm font-medium mb-2 block">Technologies</label>
                    <Input placeholder="React, Node.js, MongoDB (comma separated)" />
                  </div>

                  <div>
                    <label className="text-sm font-medium mb-2 block">Project Resources</label>
                    <div className="space-y-2">
                      <Input placeholder="GitHub repository URL (optional)" />
                      <Input placeholder="Live demo URL (optional)" />
                      <Input placeholder="Design mockup URL (optional)" />
                    </div>
                  </div>
                </div>
              </div>

              <div className="flex justify-end space-x-4">
                <Button variant="outline">Save as Draft</Button>
                <Button className="bg-green-600 hover:bg-green-700">
                  <Zap className="w-4 h-4 mr-2" />
                  Publish Project
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}

export default function ProjectAccess() {
  const config = platformConfigs.candidate;
  
  const usageData = [
    { label: "Project Credits", current: 18, max: 30 },
    { label: "Premium Access", current: 7, max: 12 },
    { label: "Code Reviews", current: 5, max: 10 },
  ];

  return (
    <PlatformLayout
      sidebarTitle={config.sidebarTitle}
      sidebarSubtitle={config.sidebarSubtitle}
      sidebarSections={config.sidebarSections}
      usageData={usageData}
    >
      <ProjectAccessContent />
    </PlatformLayout>
  );
}