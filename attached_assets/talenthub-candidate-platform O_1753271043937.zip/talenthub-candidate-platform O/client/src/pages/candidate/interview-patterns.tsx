import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import PlatformLayout from "@/components/layout/platform-layout";
import { candidateNavigation } from "@/config/complete-navigation";
import { 
  TrendingUp, MessageSquare, Code, Clock, Brain, Target,
  Star, CheckCircle, AlertTriangle, ArrowUp, Activity,
  BarChart3, Zap, Play, BookOpen, Users
} from "lucide-react";

const InterviewPatterns: React.FC = () => {
  const [timeRange, setTimeRange] = useState('3m');

  const questionPatterns = [
    {
      category: 'Algorithm & Data Structures',
      frequency: 85,
      difficulty: 'Medium-High',
      commonTopics: ['Arrays', 'Linked Lists', 'Trees', 'Dynamic Programming'],
      successRate: 72,
      avgTime: '25 mins',
      trend: '+8%',
      examples: [
        'Two Sum Problem variations',
        'Binary Tree Traversal',
        'Merge Intervals',
        'Longest Common Subsequence'
      ]
    },
    {
      category: 'System Design',
      frequency: 78,
      difficulty: 'High',
      commonTopics: ['Scalability', 'Databases', 'Caching', 'Load Balancing'],
      successRate: 68,
      avgTime: '35 mins',
      trend: '+12%',
      examples: [
        'Design URL Shortener',
        'Chat Application Architecture',
        'Rate Limiting System',
        'Social Media Feed'
      ]
    },
    {
      category: 'Frontend Framework',
      frequency: 92,
      difficulty: 'Medium',
      commonTopics: ['React Hooks', 'State Management', 'Performance', 'Testing'],
      successRate: 81,
      avgTime: '20 mins',
      trend: '+5%',
      examples: [
        'Custom Hook Implementation',
        'State Management Pattern',
        'Component Optimization',
        'Error Boundary Design'
      ]
    },
    {
      category: 'Backend Architecture',
      frequency: 74,
      difficulty: 'Medium-High',
      commonTopics: ['APIs', 'Authentication', 'Database Design', 'Microservices'],
      successRate: 75,
      avgTime: '30 mins',
      trend: '+10%',
      examples: [
        'REST API Design',
        'JWT Authentication',
        'Database Schema Design',
        'Service Communication'
      ]
    }
  ];

  const responsePatterns = [
    {
      pattern: 'Clarifying Questions',
      frequency: 65,
      impact: 'High',
      description: 'Asking relevant questions before solving',
      improvement: '+15% success rate',
      examples: ['Input constraints?', 'Edge cases?', 'Performance requirements?']
    },
    {
      pattern: 'Thinking Out Loud',
      frequency: 78,
      impact: 'Medium',
      description: 'Verbalizing thought process',
      improvement: '+12% communication score',
      examples: ['Let me think about this...', 'One approach could be...', 'This reminds me of...']
    },
    {
      pattern: 'Code Comments',
      frequency: 45,
      impact: 'Medium',
      description: 'Adding explanatory comments while coding',
      improvement: '+8% code quality score',
      examples: ['// Helper function to...', '// Edge case handling', '// Time complexity: O(n)']
    },
    {
      pattern: 'Testing Discussion',
      frequency: 38,
      impact: 'High',
      description: 'Discussing test cases and validation',
      improvement: '+18% overall score',
      examples: ['How would we test this?', 'Edge cases to consider...', 'Unit test scenarios...']
    }
  ];

  const interviewerBehaviors = [
    {
      behavior: 'Gives Hints',
      frequency: 72,
      response: 'Follow the hint direction',
      successImpact: '+20%',
      tips: ['Listen carefully', 'Ask for clarification', 'Build on the hint']
    },
    {
      behavior: 'Asks Follow-ups',
      frequency: 89,
      response: 'Engage thoughtfully',
      successImpact: '+15%',
      tips: ['Think before responding', 'Be specific', 'Show deeper understanding']
    },
    {
      behavior: 'Challenges Solution',
      frequency: 45,
      response: 'Defend with reasoning',
      successImpact: '+25%',
      tips: ['Stay calm', 'Explain trade-offs', 'Consider alternatives']
    },
    {
      behavior: 'Time Pressure',
      frequency: 67,
      response: 'Prioritize and communicate',
      successImpact: '+10%',
      tips: ['State priorities', 'Skip non-essentials', 'Show time awareness']
    }
  ];

  const timeManagementPatterns = [
    { phase: 'Problem Understanding', optimalTime: 15, yourAverage: 18, status: 'needs improvement' },
    { phase: 'Solution Planning', optimalTime: 20, yourAverage: 16, status: 'good' },
    { phase: 'Implementation', optimalTime: 45, yourAverage: 52, status: 'needs improvement' },
    { phase: 'Testing & Review', optimalTime: 20, yourAverage: 14, status: 'needs improvement' }
  ];

  const communicationMetrics = [
    { metric: 'Clarity of Explanation', score: 78, benchmark: 85, trend: '+6%' },
    { metric: 'Technical Accuracy', score: 85, benchmark: 80, trend: '+3%' },
    { metric: 'Question Asking', score: 65, benchmark: 75, trend: '+12%' },
    { metric: 'Code Narration', score: 72, benchmark: 80, trend: '+8%' }
  ];

  return (
    <PlatformLayout
      sidebarTitle="Candidate Platform"
      sidebarSubtitle="Interview Preparation"
      sidebarSections={candidateNavigation}
    >
      <div className="min-h-screen bg-gradient-to-br from-green-50 via-white to-emerald-50 p-6">
        <div className="max-w-7xl mx-auto space-y-8">
          {/* Header */}
          <div className="text-center space-y-4">
            <div className="inline-flex items-center space-x-2 bg-green-100 text-green-800 px-4 py-2 rounded-full text-sm font-medium">
              <TrendingUp className="h-4 w-4" />
              <span>Interview Pattern Analysis</span>
            </div>
            <h1 className="text-4xl font-bold text-gray-900">
              Interview Patterns & Insights
            </h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              AI-powered analysis of interview patterns, question types, and behavioral insights 
              to optimize your interview performance and preparation strategy.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Main Content */}
            <div className="lg:col-span-2 space-y-6">
              {/* Question Pattern Analysis */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Brain className="h-5 w-5" />
                    <span>Question Pattern Analysis</span>
                  </CardTitle>
                  <CardDescription>Most common question types and your performance</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-6">
                    {questionPatterns.map((pattern, index) => (
                      <div key={index} className="p-4 border rounded-lg">
                        <div className="flex items-center justify-between mb-3">
                          <h3 className="font-semibold text-lg">{pattern.category}</h3>
                          <div className="flex items-center space-x-2">
                            <Badge variant="outline">{pattern.difficulty}</Badge>
                            <Badge variant="secondary" className="bg-green-100 text-green-700">
                              {pattern.trend}
                            </Badge>
                          </div>
                        </div>

                        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
                          <div className="text-center">
                            <div className="text-2xl font-bold text-blue-600">{pattern.frequency}%</div>
                            <div className="text-xs text-gray-500">Frequency</div>
                          </div>
                          <div className="text-center">
                            <div className="text-2xl font-bold text-green-600">{pattern.successRate}%</div>
                            <div className="text-xs text-gray-500">Success Rate</div>
                          </div>
                          <div className="text-center">
                            <div className="text-2xl font-bold text-purple-600">{pattern.avgTime}</div>
                            <div className="text-xs text-gray-500">Avg Time</div>
                          </div>
                          <div className="text-center">
                            <div className="text-2xl font-bold text-orange-600">{pattern.commonTopics.length}</div>
                            <div className="text-xs text-gray-500">Key Topics</div>
                          </div>
                        </div>

                        <div className="mb-4">
                          <div className="flex justify-between text-sm mb-1">
                            <span>Your Performance</span>
                            <span>{pattern.successRate}%</span>
                          </div>
                          <Progress value={pattern.successRate} className="h-2" />
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div>
                            <span className="font-medium text-blue-700">Common Topics:</span>
                            <div className="flex flex-wrap gap-1 mt-1">
                              {pattern.commonTopics.map((topic, i) => (
                                <Badge key={i} variant="secondary" className="text-xs">
                                  {topic}
                                </Badge>
                              ))}
                            </div>
                          </div>
                          <div>
                            <span className="font-medium text-green-700">Example Questions:</span>
                            <div className="text-sm text-gray-600 mt-1">
                              {pattern.examples.slice(0, 2).map((example, i) => (
                                <div key={i} className="truncate">• {example}</div>
                              ))}
                            </div>
                          </div>
                        </div>

                        <div className="mt-4 pt-3 border-t">
                          <Button variant="outline" size="sm" className="w-full">
                            <Play className="h-3 w-3 mr-2" />
                            Practice {pattern.category}
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* Response Pattern Analysis */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <MessageSquare className="h-5 w-5" />
                    <span>Response Pattern Analysis</span>
                  </CardTitle>
                  <CardDescription>How you typically respond during interviews</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {responsePatterns.map((response, index) => (
                      <div key={index} className="p-4 bg-gray-50 rounded-lg">
                        <div className="flex items-center justify-between mb-2">
                          <h3 className="font-medium">{response.pattern}</h3>
                          <Badge variant={response.impact === 'High' ? 'default' : 'secondary'}>
                            {response.impact} Impact
                          </Badge>
                        </div>
                        <div className="text-sm text-gray-600 mb-3">{response.description}</div>
                        <div className="flex justify-between items-center mb-2">
                          <span className="text-sm">Usage Frequency</span>
                          <span className="text-sm font-medium">{response.frequency}%</span>
                        </div>
                        <Progress value={response.frequency} className="h-1.5 mb-2" />
                        <div className="text-xs text-green-600 font-medium">{response.improvement}</div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* Time Management Analysis */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Clock className="h-5 w-5" />
                    <span>Time Management Patterns</span>
                  </CardTitle>
                  <CardDescription>How you allocate time across interview phases</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {timeManagementPatterns.map((phase, index) => (
                      <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                        <div className="flex-1">
                          <div className="font-medium">{phase.phase}</div>
                          <div className="text-sm text-gray-600">
                            Optimal: {phase.optimalTime}% • Your avg: {phase.yourAverage}%
                          </div>
                        </div>
                        <div className="flex items-center space-x-2">
                          {phase.status === 'good' ? (
                            <CheckCircle className="h-4 w-4 text-green-500" />
                          ) : (
                            <AlertTriangle className="h-4 w-4 text-orange-500" />
                          )}
                          <Badge variant={phase.status === 'good' ? 'default' : 'secondary'}>
                            {phase.status}
                          </Badge>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Sidebar */}
            <div className="space-y-6">
              {/* Communication Metrics */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Users className="h-5 w-5" />
                    <span>Communication Metrics</span>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {communicationMetrics.map((metric, index) => (
                    <div key={index} className="space-y-2">
                      <div className="flex justify-between items-center">
                        <span className="text-sm font-medium">{metric.metric}</span>
                        <div className="flex items-center space-x-2">
                          <span className="text-sm">{metric.score}%</span>
                          <Badge variant="secondary" className="text-xs bg-green-100 text-green-700">
                            {metric.trend}
                          </Badge>
                        </div>
                      </div>
                      <div className="relative">
                        <Progress value={metric.score} className="h-2" />
                        <div 
                          className="absolute top-0 h-2 w-1 bg-blue-500 rounded-full"
                          style={{ left: `${metric.benchmark}%` }}
                        />
                      </div>
                      <div className="flex justify-between text-xs text-gray-500">
                        <span>Your Score</span>
                        <span>Benchmark: {metric.benchmark}%</span>
                      </div>
                    </div>
                  ))}
                </CardContent>
              </Card>

              {/* Interviewer Behavior Patterns */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Target className="h-5 w-5" />
                    <span>Interviewer Behaviors</span>
                  </CardTitle>
                  <CardDescription>Common patterns and responses</CardDescription>
                </CardHeader>
                <CardContent className="space-y-3">
                  {interviewerBehaviors.map((behavior, index) => (
                    <div key={index} className="p-3 border rounded-lg">
                      <div className="flex items-center justify-between mb-2">
                        <span className="font-medium text-sm">{behavior.behavior}</span>
                        <Badge variant="outline" className="text-xs">
                          {behavior.frequency}%
                        </Badge>
                      </div>
                      <div className="text-xs text-gray-600 mb-2">{behavior.response}</div>
                      <div className="text-xs text-green-600 font-medium mb-1">
                        Impact: {behavior.successImpact}
                      </div>
                      <div className="text-xs text-blue-600">
                        Tips: {behavior.tips.slice(0, 2).join(', ')}
                      </div>
                    </div>
                  ))}
                </CardContent>
              </Card>

              {/* Quick Actions */}
              <div className="space-y-3">
                <Button size="lg" className="w-full bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700">
                  <Play className="h-4 w-4 mr-2" />
                  Practice Weak Areas
                </Button>
                <Button variant="outline" size="lg" className="w-full">
                  <BookOpen className="h-4 w-4 mr-2" />
                  Pattern Study Guide
                </Button>
                <Button variant="outline" size="lg" className="w-full">
                  <BarChart3 className="h-4 w-4 mr-2" />
                  Detailed Analytics
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </PlatformLayout>
  );
};

export default InterviewPatterns;