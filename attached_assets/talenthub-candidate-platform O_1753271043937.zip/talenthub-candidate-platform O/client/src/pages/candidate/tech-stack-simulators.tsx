import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import PlatformLayout from "@/components/layout/platform-layout";
import { candidateNavigation } from "@/config/complete-navigation";
import { 
  Code, Play, Clock, Target, TrendingUp, Star, 
  CheckCircle, ArrowRight, Zap, Award, Users,
  Monitor, Server, Database, Cloud, Layers
} from "lucide-react";

const TechStackSimulators: React.FC = () => {
  const [selectedStack, setSelectedStack] = useState('react');

  const techStacks = [
    {
      id: 'react',
      name: 'React',
      icon: Monitor,
      color: 'from-blue-500 to-cyan-500',
      description: 'Frontend framework for building user interfaces',
      difficulty: 'Intermediate',
      duration: '45 mins',
      questions: 25,
      passRate: 78,
      topics: ['Components', 'Hooks', 'State Management', 'Performance', 'Testing']
    },
    {
      id: 'nodejs',
      name: 'Node.js',
      icon: Server,
      color: 'from-green-500 to-emerald-500',
      description: 'JavaScript runtime for server-side development',
      difficulty: 'Advanced',
      duration: '60 mins',
      questions: 30,
      passRate: 72,
      topics: ['Express.js', 'Async/Await', 'Database Integration', 'APIs', 'Security']
    },
    {
      id: 'python',
      name: 'Python',
      icon: Code,
      color: 'from-yellow-500 to-orange-500',
      description: 'Versatile programming language for multiple domains',
      difficulty: 'Intermediate',
      duration: '50 mins',
      questions: 28,
      passRate: 81,
      topics: ['Data Structures', 'OOP', 'Libraries', 'Django/Flask', 'Testing']
    },
    {
      id: 'aws',
      name: 'AWS',
      icon: Cloud,
      color: 'from-orange-500 to-red-500',
      description: 'Amazon Web Services cloud platform',
      difficulty: 'Expert',
      duration: '75 mins',
      questions: 35,
      passRate: 65,
      topics: ['EC2', 'S3', 'Lambda', 'RDS', 'Security']
    },
    {
      id: 'fullstack',
      name: 'Full-Stack',
      icon: Layers,
      color: 'from-purple-500 to-pink-500',
      description: 'Complete web development stack',
      difficulty: 'Expert',
      duration: '90 mins',
      questions: 40,
      passRate: 58,
      topics: ['Frontend', 'Backend', 'Database', 'DevOps', 'Architecture']
    },
    {
      id: 'sql',
      name: 'SQL/Database',
      icon: Database,
      color: 'from-indigo-500 to-blue-500',
      description: 'Database design and query optimization',
      difficulty: 'Intermediate',
      duration: '40 mins',
      questions: 22,
      passRate: 76,
      topics: ['Queries', 'Joins', 'Indexing', 'Normalization', 'Performance']
    }
  ];

  const recentSessions = [
    { stack: 'React', score: 85, date: '2 hours ago', status: 'Passed', improvement: '+12%' },
    { stack: 'Node.js', score: 72, date: '1 day ago', status: 'Passed', improvement: '+8%' },
    { stack: 'Python', score: 91, date: '3 days ago', status: 'Passed', improvement: '+15%' },
    { stack: 'AWS', score: 68, date: '1 week ago', status: 'Review', improvement: '+5%' }
  ];

  const selectedStackData = techStacks.find(stack => stack.id === selectedStack);

  return (
    <PlatformLayout
      sidebarTitle="Candidate Platform"
      sidebarSubtitle="Interview Preparation"
      sidebarSections={candidateNavigation}
    >
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-indigo-50 p-6">
        <div className="max-w-7xl mx-auto space-y-8">
          {/* Header */}
          <div className="text-center space-y-4">
            <div className="inline-flex items-center space-x-2 bg-blue-100 text-blue-800 px-4 py-2 rounded-full text-sm font-medium">
              <Code className="h-4 w-4" />
              <span>Tech Stack Interview Simulators</span>
            </div>
            <h1 className="text-4xl font-bold text-gray-900">
              Master Tech Stack Interviews
            </h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Practice with AI-powered interview simulations for your technology stack. 
              Get real-time feedback and improve your technical interview performance.
            </p>
          </div>

          <Tabs value={selectedStack} onValueChange={setSelectedStack} className="space-y-6">
            {/* Tech Stack Selection */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {techStacks.map((stack) => {
                const IconComponent = stack.icon;
                return (
                  <Card 
                    key={stack.id} 
                    className={`cursor-pointer transition-all duration-300 hover:shadow-lg border-2 ${
                      selectedStack === stack.id 
                        ? 'border-blue-500 shadow-lg' 
                        : 'border-gray-200 hover:border-blue-300'
                    }`}
                    onClick={() => setSelectedStack(stack.id)}
                  >
                    <CardHeader className="pb-3">
                      <div className="flex items-center justify-between">
                        <div className={`p-3 rounded-lg bg-gradient-to-r ${stack.color}`}>
                          <IconComponent className="h-6 w-6 text-white" />
                        </div>
                        <Badge variant={stack.difficulty === 'Expert' ? 'destructive' : stack.difficulty === 'Advanced' ? 'default' : 'secondary'}>
                          {stack.difficulty}
                        </Badge>
                      </div>
                      <CardTitle className="text-lg">{stack.name}</CardTitle>
                      <CardDescription className="text-sm">{stack.description}</CardDescription>
                    </CardHeader>
                    <CardContent className="pt-0">
                      <div className="grid grid-cols-2 gap-4 text-sm">
                        <div className="flex items-center space-x-2">
                          <Clock className="h-4 w-4 text-gray-500" />
                          <span>{stack.duration}</span>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Target className="h-4 w-4 text-gray-500" />
                          <span>{stack.questions} questions</span>
                        </div>
                        <div className="flex items-center space-x-2">
                          <TrendingUp className="h-4 w-4 text-gray-500" />
                          <span>{stack.passRate}% pass rate</span>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Users className="h-4 w-4 text-gray-500" />
                          <span>Live sessions</span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>

            {/* Selected Stack Details */}
            {selectedStackData && (
              <Card className="overflow-hidden">
                <CardHeader className={`bg-gradient-to-r ${selectedStackData.color} text-white`}>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-4">
                      <div className="p-3 bg-white/20 rounded-lg">
                        <selectedStackData.icon className="h-8 w-8" />
                      </div>
                      <div>
                        <CardTitle className="text-2xl">{selectedStackData.name} Interview Simulator</CardTitle>
                        <CardDescription className="text-white/80">
                          {selectedStackData.description}
                        </CardDescription>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-3xl font-bold">{selectedStackData.passRate}%</div>
                      <div className="text-sm text-white/80">Success Rate</div>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="p-6">
                  <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                    {/* Topics Covered */}
                    <div className="lg:col-span-2 space-y-4">
                      <h3 className="text-lg font-semibold flex items-center space-x-2">
                        <Target className="h-5 w-5" />
                        <span>Topics Covered</span>
                      </h3>
                      <div className="grid grid-cols-2 gap-3">
                        {selectedStackData.topics.map((topic, index) => (
                          <div key={index} className="flex items-center space-x-2 p-3 bg-gray-50 rounded-lg">
                            <CheckCircle className="h-4 w-4 text-green-500" />
                            <span className="font-medium">{topic}</span>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Session Info */}
                    <div className="space-y-4">
                      <h3 className="text-lg font-semibold flex items-center space-x-2">
                        <Clock className="h-5 w-5" />
                        <span>Session Details</span>
                      </h3>
                      <div className="space-y-3">
                        <div className="flex justify-between items-center p-3 bg-blue-50 rounded-lg">
                          <span className="font-medium">Duration</span>
                          <span className="text-blue-600 font-semibold">{selectedStackData.duration}</span>
                        </div>
                        <div className="flex justify-between items-center p-3 bg-green-50 rounded-lg">
                          <span className="font-medium">Questions</span>
                          <span className="text-green-600 font-semibold">{selectedStackData.questions}</span>
                        </div>
                        <div className="flex justify-between items-center p-3 bg-purple-50 rounded-lg">
                          <span className="font-medium">Difficulty</span>
                          <Badge variant={selectedStackData.difficulty === 'Expert' ? 'destructive' : 'default'}>
                            {selectedStackData.difficulty}
                          </Badge>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* Action Buttons */}
                  <div className="mt-6 flex flex-col sm:flex-row gap-3">
                    <Button size="lg" className="flex-1 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700">
                      <Play className="h-5 w-5 mr-2" />
                      Start Interview Simulation
                    </Button>
                    <Button variant="outline" size="lg" className="flex-1">
                      <Zap className="h-5 w-5 mr-2" />
                      Quick Practice (10 mins)
                    </Button>
                    <Button variant="outline" size="lg" className="flex-1">
                      <Award className="h-5 w-5 mr-2" />
                      View Certification Path
                    </Button>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Recent Sessions */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Clock className="h-5 w-5" />
                  <span>Recent Practice Sessions</span>
                </CardTitle>
                <CardDescription>Track your progress across different tech stacks</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {recentSessions.map((session, index) => (
                    <div key={index} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
                      <div className="flex items-center space-x-4">
                        <div className={`w-3 h-3 rounded-full ${session.status === 'Passed' ? 'bg-green-500' : 'bg-yellow-500'}`} />
                        <div>
                          <div className="font-medium">{session.stack} Interview Simulation</div>
                          <div className="text-sm text-gray-500">{session.date}</div>
                        </div>
                      </div>
                      <div className="flex items-center space-x-4">
                        <div className="text-right">
                          <div className="font-semibold text-lg">{session.score}%</div>
                          <div className="text-sm text-green-600">{session.improvement}</div>
                        </div>
                        <Badge variant={session.status === 'Passed' ? 'default' : 'secondary'}>
                          {session.status}
                        </Badge>
                        <Button variant="ghost" size="sm">
                          <ArrowRight className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </Tabs>
        </div>
      </div>
    </PlatformLayout>
  );
};

export default TechStackSimulators;