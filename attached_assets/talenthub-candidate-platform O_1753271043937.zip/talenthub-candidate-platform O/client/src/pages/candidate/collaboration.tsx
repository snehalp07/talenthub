import PlatformLayout from "@/components/layout/platform-layout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Progress } from "@/components/ui/progress";
import { HandHeart, Users, Zap, Calendar, Search, Filter, Clock, Target, Award, TrendingUp, ChevronRight, MessageSquare, GitBranch, Code, Globe, Video, Star } from "lucide-react";
import { platformConfigs } from "@/config/complete-navigation";

export default function Collaboration() {
  const config = platformConfigs.candidate;
  const activeProjects = [
    {
      id: 1,
      title: "Open Source AI Library",
      type: "Open Source",
      description: "Building a machine learning library for computer vision applications",
      skills: ["Python", "TensorFlow", "Computer Vision"],
      members: 8,
      progress: 75,
      deadline: "July 15, 2025",
      lead: "Alex Chen",
      status: "Active",
      image: "https://images.unsplash.com/photo-1555949963-aa79dcee981c?w=300&h=200&fit=crop",
      tags: ["AI", "Machine Learning", "Open Source"],
      featured: true
    },
    {
      id: 2,
      title: "FinTech Mobile App",
      type: "Startup Project",
      description: "Developing a personal finance management mobile application",
      skills: ["React Native", "Node.js", "MongoDB"],
      members: 5,
      progress: 45,
      deadline: "August 20, 2025",
      lead: "Sarah Kim",
      status: "Recruiting",
      image: "https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=300&h=200&fit=crop",
      tags: ["Mobile", "FinTech", "Startup"],
      featured: false
    },
    {
      id: 3,
      title: "Sustainability Tracker",
      type: "Social Impact",
      description: "Web platform to help organizations track and reduce carbon footprint",
      skills: ["React", "Express", "PostgreSQL"],
      members: 12,
      progress: 60,
      deadline: "September 10, 2025",
      lead: "Maria Rodriguez",
      status: "Active",
      image: "https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?w=300&h=200&fit=crop",
      tags: ["Sustainability", "Web Dev", "Social Impact"],
      featured: true
    }
  ];

  const myProjects = [
    {
      id: 1,
      title: "E-commerce Platform",
      role: "Frontend Developer",
      progress: 80,
      nextMilestone: "UI Testing Phase",
      team: ["Alice Wang", "Bob Smith", "Carol Lee"],
      lastActivity: "2 hours ago"
    },
    {
      id: 2,
      title: "Data Visualization Tool",
      role: "Full Stack Developer",
      progress: 35,
      nextMilestone: "Backend API Development",
      team: ["David Park", "Emma Wilson"],
      lastActivity: "1 day ago"
    }
  ];

  const skillCategories = [
    { name: "Frontend Development", projects: 24, color: "bg-blue-500", icon: Code },
    { name: "Backend Development", projects: 18, color: "bg-green-500", icon: GitBranch },
    { name: "Mobile Development", projects: 15, color: "bg-purple-500", icon: Globe },
    { name: "Data Science", projects: 12, color: "bg-orange-500", icon: TrendingUp },
    { name: "AI/ML", projects: 9, color: "bg-red-500", icon: Zap },
    { name: "DevOps", projects: 8, color: "bg-indigo-500", icon: Target }
  ];

  const teamMembers = [
    {
      name: "Alex Chen",
      role: "Tech Lead",
      skills: ["Python", "AI/ML", "System Design"],
      projects: 3,
      rating: 4.9,
      image: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&h=150&fit=crop&crop=face"
    },
    {
      name: "Sarah Kim",
      role: "Product Manager",
      skills: ["Strategy", "User Research", "Analytics"],
      projects: 2,
      rating: 4.8,
      image: "https://images.unsplash.com/photo-1494790108755-2616b612b786?w=150&h=150&fit=crop&crop=face"
    },
    {
      name: "Maria Rodriguez",
      role: "UX Designer",
      skills: ["Design", "Prototyping", "Research"],
      projects: 4,
      rating: 4.9,
      image: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=150&h=150&fit=crop&crop=face"
    }
  ];

  return (
    <PlatformLayout
      sidebarTitle={config.sidebarTitle}
      sidebarSubtitle={config.sidebarSubtitle}
      sidebarSections={config.sidebarSections}
      usageData={config.usageData}
    >
      <div className="p-6 max-w-7xl mx-auto space-y-6">
      {/* Header */}
      <div className="text-center space-y-4">
        <div className="flex items-center justify-center space-x-3">
          <div className="p-3 bg-gradient-to-r from-emerald-500 to-teal-500 rounded-full">
            <HandHeart className="h-8 w-8 text-white" />
          </div>
          <h1 className="text-4xl font-bold bg-gradient-to-r from-emerald-600 to-teal-600 bg-clip-text text-transparent">
            Collaboration Hub
          </h1>
        </div>
        <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
          Join collaborative projects, build teams, and create amazing solutions together
        </p>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="bg-gradient-to-r from-emerald-50 to-teal-50 border-emerald-200">
          <CardContent className="p-4 text-center">
            <HandHeart className="h-8 w-8 text-emerald-500 mx-auto mb-2" />
            <p className="text-2xl font-bold text-emerald-600">150+</p>
            <p className="text-sm text-muted-foreground">Active Projects</p>
          </CardContent>
        </Card>
        <Card className="bg-gradient-to-r from-blue-50 to-cyan-50 border-blue-200">
          <CardContent className="p-4 text-center">
            <Users className="h-8 w-8 text-blue-500 mx-auto mb-2" />
            <p className="text-2xl font-bold text-blue-600">2,500+</p>
            <p className="text-sm text-muted-foreground">Collaborators</p>
          </CardContent>
        </Card>
        <Card className="bg-gradient-to-r from-purple-50 to-pink-50 border-purple-200">
          <CardContent className="p-4 text-center">
            <Award className="h-8 w-8 text-purple-500 mx-auto mb-2" />
            <p className="text-2xl font-bold text-purple-600">85%</p>
            <p className="text-sm text-muted-foreground">Success Rate</p>
          </CardContent>
        </Card>
        <Card className="bg-gradient-to-r from-orange-50 to-red-50 border-orange-200">
          <CardContent className="p-4 text-center">
            <TrendingUp className="h-8 w-8 text-orange-500 mx-auto mb-2" />
            <p className="text-2xl font-bold text-orange-600">320</p>
            <p className="text-sm text-muted-foreground">Completed Projects</p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="discover" className="space-y-6">
        <TabsList className="grid w-full grid-cols-4 bg-emerald-100">
          <TabsTrigger value="discover" className="data-[state=active]:bg-emerald-500 data-[state=active]:text-white">
            Discover Projects
          </TabsTrigger>
          <TabsTrigger value="my-projects" className="data-[state=active]:bg-emerald-500 data-[state=active]:text-white">
            My Projects
          </TabsTrigger>
          <TabsTrigger value="create" className="data-[state=active]:bg-emerald-500 data-[state=active]:text-white">
            Create Project
          </TabsTrigger>
          <TabsTrigger value="team" className="data-[state=active]:bg-emerald-500 data-[state=active]:text-white">
            Find Team
          </TabsTrigger>
        </TabsList>

        <TabsContent value="discover" className="space-y-6">
          {/* Search and Filter */}
          <Card className="bg-gradient-to-r from-emerald-50 to-teal-50 border-emerald-200">
            <CardContent className="p-6">
              <div className="flex flex-col md:flex-row gap-4">
                <div className="flex-1 relative">
                  <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                  <Input placeholder="Search projects by technology, industry, or goal..." className="pl-10 bg-white" />
                </div>
                <div className="flex gap-2">
                  <Button variant="outline" className="border-emerald-300 hover:bg-emerald-50">
                    <Filter className="h-4 w-4 mr-2" />
                    Filter
                  </Button>
                  <Button variant="outline" className="border-emerald-300 hover:bg-emerald-50">
                    <Star className="h-4 w-4 mr-2" />
                    Featured
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Skill Categories */}
          <div className="space-y-4">
            <h2 className="text-2xl font-bold text-emerald-700">Browse by Skills</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {skillCategories.map((category) => {
                const IconComponent = category.icon;
                return (
                  <Card key={category.name} className="group hover:shadow-lg transition-all duration-300 cursor-pointer">
                    <CardContent className="p-4 flex items-center space-x-4">
                      <div className={`w-12 h-12 ${category.color} rounded-full flex items-center justify-center group-hover:scale-110 transition-transform`}>
                        <IconComponent className="h-6 w-6 text-white" />
                      </div>
                      <div>
                        <h3 className="font-semibold group-hover:text-emerald-600 transition-colors">
                          {category.name}
                        </h3>
                        <p className="text-sm text-muted-foreground">{category.projects} projects</p>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </div>

          {/* Featured Projects */}
          <div className="space-y-4">
            <h2 className="text-2xl font-bold text-emerald-700">Featured Projects</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {activeProjects.map((project) => (
                <Card key={project.id} className="group hover:shadow-lg transition-all duration-300 border-l-4 border-l-emerald-500">
                  <div className="relative">
                    <img 
                      src={project.image} 
                      alt={project.title}
                      className="w-full h-48 object-cover rounded-t-lg"
                    />
                    <div className="absolute top-3 right-3 flex gap-2">
                      {project.featured && (
                        <Badge className="bg-gradient-to-r from-yellow-400 to-orange-500 text-white">
                          <Star className="h-3 w-3 mr-1" />
                          Featured
                        </Badge>
                      )}
                      <Badge 
                        variant={project.status === 'Active' ? 'default' : 'secondary'}
                        className={project.status === 'Active' ? 'bg-green-500' : 'bg-blue-500'}
                      >
                        {project.status}
                      </Badge>
                    </div>
                  </div>
                  <CardHeader className="pb-3">
                    <div className="flex justify-between items-start">
                      <CardTitle className="text-lg group-hover:text-emerald-600 transition-colors">
                        {project.title}
                      </CardTitle>
                      <Badge variant="outline" className="text-xs">
                        {project.type}
                      </Badge>
                    </div>
                    <CardDescription className="space-y-2">
                      <p className="text-sm text-muted-foreground">{project.description}</p>
                      <div className="flex items-center justify-between text-xs text-muted-foreground">
                        <div className="flex items-center gap-1">
                          <Users className="h-3 w-3" />
                          {project.members} members
                        </div>
                        <div className="flex items-center gap-1">
                          <Calendar className="h-3 w-3" />
                          Due {project.deadline}
                        </div>
                      </div>
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="pt-0 space-y-4">
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span>Progress</span>
                        <span>{project.progress}%</span>
                      </div>
                      <Progress value={project.progress} className="h-2" />
                    </div>

                    <div className="flex flex-wrap gap-1">
                      {project.skills.map((skill) => (
                        <Badge key={skill} variant="secondary" className="text-xs bg-emerald-100 text-emerald-700">
                          {skill}
                        </Badge>
                      ))}
                    </div>

                    <div className="flex justify-between items-center pt-2 border-t">
                      <div className="text-sm">
                        <p className="text-muted-foreground">Led by</p>
                        <p className="font-medium">{project.lead}</p>
                      </div>
                      <Button className="bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-600 hover:to-teal-600">
                        Join Project
                        <ChevronRight className="h-4 w-4 ml-1" />
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </TabsContent>

        <TabsContent value="my-projects" className="space-y-6">
          <h2 className="text-2xl font-bold text-emerald-700">My Active Projects</h2>
          
          <div className="space-y-4">
            {myProjects.map((project) => (
              <Card key={project.id} className="border-l-4 border-l-emerald-500">
                <CardContent className="p-6">
                  <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                    <div className="lg:col-span-2 space-y-4">
                      <div>
                        <div className="flex justify-between items-start mb-2">
                          <h3 className="text-lg font-semibold">{project.title}</h3>
                          <Badge variant="outline">{project.role}</Badge>
                        </div>
                        <p className="text-sm text-muted-foreground">Next: {project.nextMilestone}</p>
                      </div>
                      
                      <div className="space-y-2">
                        <div className="flex justify-between text-sm">
                          <span>Overall Progress</span>
                          <span>{project.progress}%</span>
                        </div>
                        <Progress value={project.progress} className="h-2" />
                      </div>

                      <div className="flex items-center gap-2">
                        <p className="text-sm text-muted-foreground">Team:</p>
                        <div className="flex -space-x-2">
                          {project.team.map((member, index) => (
                            <Avatar key={index} className="h-8 w-8 border-2 border-white">
                              <AvatarFallback className="text-xs bg-emerald-100 text-emerald-700">
                                {member.split(' ').map(n => n[0]).join('')}
                              </AvatarFallback>
                            </Avatar>
                          ))}
                        </div>
                      </div>
                    </div>

                    <div className="space-y-4">
                      <div className="text-sm">
                        <p className="text-muted-foreground">Last Activity</p>
                        <p className="font-medium">{project.lastActivity}</p>
                      </div>
                      
                      <div className="flex gap-2">
                        <Button variant="outline" size="sm" className="flex-1">
                          <MessageSquare className="h-4 w-4 mr-2" />
                          Chat
                        </Button>
                        <Button size="sm" className="flex-1 bg-gradient-to-r from-emerald-500 to-teal-500">
                          View Project
                        </Button>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="create" className="space-y-6">
          <div className="max-w-2xl mx-auto">
            <Card className="border-emerald-200">
              <CardHeader className="text-center">
                <CardTitle className="text-2xl text-emerald-700">Create New Project</CardTitle>
                <CardDescription>Start a collaborative project and find your team</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium mb-2">Project Title</label>
                    <Input placeholder="Enter project name" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2">Project Type</label>
                    <Input placeholder="Open Source, Startup, etc." />
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2">Description</label>
                  <Input placeholder="Describe your project goals and vision..." />
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium mb-2">Required Skills</label>
                    <Input placeholder="React, Node.js, Design..." />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2">Team Size</label>
                    <Input type="number" placeholder="5" />
                  </div>
                </div>
                <Button className="w-full bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-600 hover:to-teal-600">
                  Create Project
                </Button>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="team" className="space-y-6">
          <h2 className="text-2xl font-bold text-emerald-700">Find Team Members</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {teamMembers.map((member, index) => (
              <Card key={index} className="group hover:shadow-lg transition-all duration-300">
                <CardContent className="p-6 text-center space-y-4">
                  <Avatar className="h-20 w-20 mx-auto">
                    <AvatarImage src={member.image} alt={member.name} />
                    <AvatarFallback>{member.name.split(' ').map(n => n[0]).join('')}</AvatarFallback>
                  </Avatar>
                  
                  <div>
                    <h3 className="text-lg font-semibold group-hover:text-emerald-600 transition-colors">
                      {member.name}
                    </h3>
                    <p className="text-sm text-muted-foreground">{member.role}</p>
                    <div className="flex items-center justify-center gap-1 mt-1">
                      <Star className="h-4 w-4 text-yellow-400 fill-current" />
                      <span className="text-sm font-medium">{member.rating}</span>
                    </div>
                  </div>

                  <div className="flex flex-wrap gap-1 justify-center">
                    {member.skills.slice(0, 3).map((skill) => (
                      <Badge key={skill} variant="secondary" className="text-xs bg-emerald-100 text-emerald-700">
                        {skill}
                      </Badge>
                    ))}
                  </div>

                  <p className="text-sm text-muted-foreground">
                    {member.projects} active projects
                  </p>

                  <Button className="w-full bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-600 hover:to-teal-600">
                    Connect
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>
      </Tabs>
      </div>
    </PlatformLayout>
  );
}