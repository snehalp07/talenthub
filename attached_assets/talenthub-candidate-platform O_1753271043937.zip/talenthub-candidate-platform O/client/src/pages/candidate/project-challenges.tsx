import PlatformLayout from "@/components/layout/platform-layout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Progress } from "@/components/ui/progress";
import { Target, Search, Trophy, Clock, Users, Flame, Zap, Calendar, Star, Play, CheckCircle, Code, Globe, Database } from "lucide-react";
import { platformConfigs } from "@/config/complete-navigation";

export default function ProjectChallenges() {
  const config = platformConfigs.candidate;

  const challenges = [
    {
      id: 1,
      title: "30-Day React Challenge",
      description: "Build 30 React components in 30 days to master modern frontend development",
      difficulty: "Intermediate",
      duration: "30 days",
      participants: 1247,
      completions: 823,
      reward: "React Master Certificate",
      category: "Frontend",
      startDate: "2024-03-01",
      endDate: "2024-03-31",
      status: "active",
      color: "from-blue-500 to-indigo-500",
      icon: Globe,
      requirements: ["React basics", "JavaScript ES6+", "Git knowledge"],
      dailyCommitment: "1-2 hours"
    },
    {
      id: 2,
      title: "API Building Marathon",
      description: "Create 15 REST APIs with different frameworks and databases in 2 weeks",
      difficulty: "Advanced",
      duration: "14 days",
      participants: 892,
      completions: 456,
      reward: "Backend Specialist Badge",
      category: "Backend",
      startDate: "2024-03-15",
      endDate: "2024-03-29",
      status: "active",
      color: "from-green-500 to-emerald-500",
      icon: Database,
      requirements: ["Node.js/Python", "Database knowledge", "API design"],
      dailyCommitment: "2-3 hours"
    },
    {
      id: 3,
      title: "Full-Stack Sprint",
      description: "Build complete applications from database to deployment in 7 days",
      difficulty: "Expert",
      duration: "7 days",
      participants: 634,
      completions: 287,
      reward: "Full-Stack Warrior Certificate",
      category: "Full-Stack",
      startDate: "2024-04-01",
      endDate: "2024-04-07",
      status: "upcoming",
      color: "from-purple-500 to-pink-500",
      icon: Code,
      requirements: ["Frontend & Backend skills", "DevOps basics", "System design"],
      dailyCommitment: "4-5 hours"
    },
    {
      id: 4,
      title: "Mobile UI/UX Challenge",
      description: "Design and implement 20 mobile app screens with perfect user experience",
      difficulty: "Intermediate",
      duration: "21 days",
      participants: 756,
      completions: 542,
      reward: "Mobile Design Expert Badge",
      category: "Mobile",
      startDate: "2024-03-10",
      endDate: "2024-03-31",
      status: "active",
      color: "from-orange-500 to-red-500",
      icon: Target,
      requirements: ["React Native/Flutter", "Design principles", "Mobile development"],
      dailyCommitment: "2 hours"
    },
    {
      id: 5,
      title: "Algorithm Mastery Quest",
      description: "Solve 100 coding problems across data structures and algorithms",
      difficulty: "Advanced",
      duration: "50 days",
      participants: 1456,
      completions: 789,
      reward: "Algorithm Master Certificate",
      category: "Programming",
      startDate: "2024-02-15",
      endDate: "2024-04-05",
      status: "active",
      color: "from-cyan-500 to-blue-500",
      icon: Zap,
      requirements: ["Programming fundamentals", "Problem-solving skills", "Math basics"],
      dailyCommitment: "1 hour"
    },
    {
      id: 6,
      title: "Open Source Contribution Drive",
      description: "Make meaningful contributions to 10 open source projects",
      difficulty: "Intermediate",
      duration: "60 days",
      participants: 923,
      completions: 234,
      reward: "Open Source Contributor Badge",
      category: "Community",
      startDate: "2024-04-15",
      endDate: "2024-06-14",
      status: "upcoming",
      color: "from-yellow-500 to-orange-500",
      icon: Trophy,
      requirements: ["Git proficiency", "Code review skills", "Communication skills"],
      dailyCommitment: "1-2 hours"
    }
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case "active": return "bg-green-100 text-green-800 border-green-200";
      case "upcoming": return "bg-blue-100 text-blue-800 border-blue-200";
      case "completed": return "bg-purple-100 text-purple-800 border-purple-200";
      case "ended": return "bg-gray-100 text-gray-800 border-gray-200";
      default: return "bg-gray-100 text-gray-800 border-gray-200";
    }
  };

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case "Beginner": return "bg-green-100 text-green-800 border-green-200";
      case "Intermediate": return "bg-yellow-100 text-yellow-800 border-yellow-200";
      case "Advanced": return "bg-orange-100 text-orange-800 border-orange-200";
      case "Expert": return "bg-red-100 text-red-800 border-red-200";
      default: return "bg-gray-100 text-gray-800 border-gray-200";
    }
  };

  return (
    <PlatformLayout
      sidebarTitle={config.sidebarTitle}
      sidebarSubtitle={config.sidebarSubtitle}
      sidebarSections={config.sidebarSections}
      usageData={config.usageData}
    >
      <div className="p-6 max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="text-center space-y-4">
          <div className="flex items-center justify-center space-x-3">
            <div className="p-3 bg-gradient-to-r from-orange-500 to-red-500 rounded-full">
              <Target className="h-8 w-8 text-white" />
            </div>
            <h1 className="text-4xl font-bold bg-gradient-to-r from-orange-600 to-red-600 bg-clip-text text-transparent">
              Project Challenges
            </h1>
          </div>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Join time-limited coding challenges to push your skills, compete with peers, and earn exclusive certificates
          </p>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <Card className="bg-gradient-to-r from-orange-50 to-red-50 border-orange-200">
            <CardContent className="p-4 text-center">
              <Target className="h-8 w-8 text-orange-500 mx-auto mb-2" />
              <p className="text-2xl font-bold text-orange-600">6</p>
              <p className="text-sm text-muted-foreground">Active Challenges</p>
            </CardContent>
          </Card>
          <Card className="bg-gradient-to-r from-green-50 to-emerald-50 border-green-200">
            <CardContent className="p-4 text-center">
              <Users className="h-8 w-8 text-green-500 mx-auto mb-2" />
              <p className="text-2xl font-bold text-green-600">5.9K</p>
              <p className="text-sm text-muted-foreground">Total Participants</p>
            </CardContent>
          </Card>
          <Card className="bg-gradient-to-r from-purple-50 to-pink-50 border-purple-200">
            <CardContent className="p-4 text-center">
              <Trophy className="h-8 w-8 text-purple-500 mx-auto mb-2" />
              <p className="text-2xl font-bold text-purple-600">3.1K</p>
              <p className="text-sm text-muted-foreground">Certificates Earned</p>
            </CardContent>
          </Card>
          <Card className="bg-gradient-to-r from-blue-50 to-indigo-50 border-blue-200">
            <CardContent className="p-4 text-center">
              <Flame className="h-8 w-8 text-blue-500 mx-auto mb-2" />
              <p className="text-2xl font-bold text-blue-600">52%</p>
              <p className="text-sm text-muted-foreground">Avg. Completion Rate</p>
            </CardContent>
          </Card>
        </div>

        {/* Search and Filters */}
        <div className="flex flex-col sm:flex-row gap-4 items-center justify-between">
          <div className="flex items-center space-x-2 flex-1">
            <div className="relative flex-1 max-w-md">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
              <Input
                placeholder="Search challenges..."
                className="pl-10"
              />
            </div>
          </div>
          <div className="flex items-center space-x-2">
            <Select defaultValue="all">
              <SelectTrigger className="w-40">
                <SelectValue placeholder="Category" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Categories</SelectItem>
                <SelectItem value="frontend">Frontend</SelectItem>
                <SelectItem value="backend">Backend</SelectItem>
                <SelectItem value="fullstack">Full-Stack</SelectItem>
                <SelectItem value="mobile">Mobile</SelectItem>
                <SelectItem value="programming">Programming</SelectItem>
              </SelectContent>
            </Select>
            <Select defaultValue="active">
              <SelectTrigger className="w-40">
                <SelectValue placeholder="Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="active">Active</SelectItem>
                <SelectItem value="upcoming">Upcoming</SelectItem>
                <SelectItem value="completed">Completed</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <Tabs defaultValue="challenges" className="space-y-6">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="challenges">All Challenges</TabsTrigger>
            <TabsTrigger value="active">My Active</TabsTrigger>
            <TabsTrigger value="completed">Completed</TabsTrigger>
          </TabsList>

          <TabsContent value="challenges" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {challenges.map((challenge) => {
                const IconComponent = challenge.icon;
                const completionRate = (challenge.completions / challenge.participants) * 100;
                
                return (
                  <Card key={challenge.id} className="group hover:shadow-lg transition-all duration-300 hover:-translate-y-1 border-l-4 border-l-orange-500">
                    <CardHeader className="pb-3">
                      <div className="flex items-start justify-between">
                        <div className={`p-2 bg-gradient-to-r ${challenge.color} rounded-lg`}>
                          <IconComponent className="h-6 w-6 text-white" />
                        </div>
                        <div className="flex gap-2">
                          <Badge className={getStatusColor(challenge.status)}>
                            {challenge.status === "active" ? "Active" : 
                             challenge.status === "upcoming" ? "Upcoming" : "Completed"}
                          </Badge>
                          <Badge className={getDifficultyColor(challenge.difficulty)}>
                            {challenge.difficulty}
                          </Badge>
                        </div>
                      </div>
                      <CardTitle className="text-xl">{challenge.title}</CardTitle>
                      <CardDescription>{challenge.description}</CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div className="grid grid-cols-2 gap-4 text-sm text-muted-foreground">
                        <div className="flex items-center gap-1">
                          <Clock className="h-4 w-4" />
                          <span>{challenge.duration}</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <Users className="h-4 w-4" />
                          <span>{challenge.participants.toLocaleString()} joined</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <Trophy className="h-4 w-4" />
                          <span>{challenge.completions} completed</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <Calendar className="h-4 w-4" />
                          <span>{challenge.dailyCommitment}/day</span>
                        </div>
                      </div>

                      <div className="space-y-2">
                        <div className="flex justify-between text-sm">
                          <span className="text-muted-foreground">Completion Rate</span>
                          <span className="font-medium">{completionRate.toFixed(0)}%</span>
                        </div>
                        <Progress value={completionRate} className="h-2" />
                      </div>

                      <div className="space-y-3">
                        <div>
                          <h4 className="text-sm font-medium mb-2">Requirements</h4>
                          <div className="space-y-1">
                            {challenge.requirements.map((req, index) => (
                              <div key={index} className="flex items-center gap-2 text-xs text-muted-foreground">
                                <CheckCircle className="h-3 w-3 text-green-500" />
                                {req}
                              </div>
                            ))}
                          </div>
                        </div>

                        <div className="bg-gradient-to-r from-orange-50 to-red-50 p-3 rounded-lg border border-orange-200">
                          <div className="flex items-center gap-2 mb-1">
                            <Trophy className="h-4 w-4 text-orange-500" />
                            <span className="text-sm font-medium text-orange-800">Reward</span>
                          </div>
                          <p className="text-xs text-orange-700">{challenge.reward}</p>
                        </div>
                      </div>

                      <div className="flex items-center gap-2 pt-2">
                        {challenge.status === "active" ? (
                          <Button className="flex-1 bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600">
                            <Play className="h-4 w-4 mr-2" />
                            Join Challenge
                          </Button>
                        ) : challenge.status === "upcoming" ? (
                          <Button className="flex-1" variant="outline">
                            <Calendar className="h-4 w-4 mr-2" />
                            Notify Me
                          </Button>
                        ) : (
                          <Button className="flex-1" variant="outline" disabled>
                            <CheckCircle className="h-4 w-4 mr-2" />
                            Completed
                          </Button>
                        )}
                        <Button variant="outline">
                          <Star className="h-4 w-4" />
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </TabsContent>

          <TabsContent value="active" className="space-y-6">
            <h3 className="text-xl font-bold text-orange-700">My Active Challenges</h3>
            
            <Card>
              <CardHeader>
                <CardTitle>Currently Participating</CardTitle>
                <CardDescription>Track your active challenge progress</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="border rounded-lg p-4">
                    <div className="flex items-center justify-between mb-3">
                      <div>
                        <h4 className="font-semibold">30-Day React Challenge</h4>
                        <p className="text-sm text-muted-foreground">Day 18 of 30</p>
                      </div>
                      <Badge className="bg-green-100 text-green-800">Active</Badge>
                    </div>
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span>Progress</span>
                        <span>18/30 Components Built</span>
                      </div>
                      <Progress value={60} className="h-2" />
                    </div>
                    <div className="mt-3 flex gap-2">
                      <Button size="sm" className="bg-orange-500 hover:bg-orange-600">
                        Continue Challenge
                      </Button>
                      <Button size="sm" variant="outline">
                        View Leaderboard
                      </Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="completed" className="space-y-6">
            <h3 className="text-xl font-bold text-orange-700">Completed Challenges</h3>
            
            <div className="text-center py-12">
              <Trophy className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-lg font-semibold mb-2">No Completed Challenges</h3>
              <p className="text-muted-foreground mb-4">
                Complete your first challenge to earn certificates and badges
              </p>
              <Button className="bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600">
                Join a Challenge
              </Button>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </PlatformLayout>
  );
}