import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import PlatformLayout from "@/components/layout/platform-layout";
import { candidateNavigation } from "@/config/complete-navigation";
import { 
  Building, Star, Users, Code, TrendingUp, Clock,
  Target, CheckCircle, Play, BookOpen, Globe,
  Award, MessageSquare, Brain, Activity, Zap
} from "lucide-react";

const CompanyPrep: React.FC = () => {
  const [selectedCompany, setSelectedCompany] = useState('google');

  const companies = {
    google: {
      name: 'Google',
      logo: '🔍',
      size: 'Large Tech',
      culture: 'Innovation-focused, data-driven, collaborative',
      interviewStyle: 'Algorithm-heavy, system design, Googleyness',
      difficulty: 'Very High',
      averageRounds: 5,
      timelineWeeks: '6-8',
      focusAreas: ['Algorithms & Data Structures', 'System Design', 'Behavioral (Googleyness)', 'Coding Best Practices'],
      commonQuestions: [
        'Design YouTube video streaming',
        'Implement LRU Cache',
        'Tell me about a time you disagreed with your manager',
        'How would you improve Google Maps?'
      ],
      techStack: ['Java', 'Python', 'C++', 'Go', 'JavaScript'],
      preparation: {
        algorithms: 85,
        systemDesign: 90,
        behavioral: 80,
        coding: 88
      },
      interviewTips: [
        'Focus heavily on algorithmic thinking and optimization',
        'Practice system design for scale (billions of users)',
        'Demonstrate leadership and innovation in behavioral answers',
        'Code should be clean, well-commented, and efficient'
      ]
    },
    meta: {
      name: 'Meta (Facebook)',
      logo: '📘',
      size: 'Large Tech',
      culture: 'Move fast, build connections, be bold',
      interviewStyle: 'Product sense, coding, system design, behavioral',
      difficulty: 'Very High',
      averageRounds: 5,
      timelineWeeks: '4-6',
      focusAreas: ['Product Design', 'Coding Efficiency', 'System Design', 'Cultural Fit'],
      commonQuestions: [
        'Design Facebook News Feed',
        'How would you design a chat application?',
        'Tell me about a time you had to work with ambiguous requirements',
        'How would you improve Instagram Stories?'
      ],
      techStack: ['React', 'PHP', 'Hack', 'Python', 'C++'],
      preparation: {
        algorithms: 80,
        systemDesign: 88,
        behavioral: 85,
        coding: 82
      },
      interviewTips: [
        'Emphasize user impact and product thinking',
        'Show ability to work in fast-paced environment',
        'Demonstrate collaboration and communication skills',
        'Focus on building products that connect people'
      ]
    },
    amazon: {
      name: 'Amazon',
      logo: '📦',
      size: 'Large Tech',
      culture: 'Customer obsession, ownership, deliver results',
      interviewStyle: 'Leadership principles, system design, coding',
      difficulty: 'High',
      averageRounds: 4,
      timelineWeeks: '3-5',
      focusAreas: ['Leadership Principles', 'System Design', 'Coding', 'Customer Focus'],
      commonQuestions: [
        'Design Amazon\'s recommendation system',
        'Tell me about a time you failed',
        'How would you handle a disagreement with a team member?',
        'Design a distributed cache system'
      ],
      techStack: ['Java', 'Python', 'C++', 'JavaScript', 'AWS'],
      preparation: {
        algorithms: 75,
        systemDesign: 85,
        behavioral: 90,
        coding: 78
      },
      interviewTips: [
        'Study all 16 leadership principles thoroughly',
        'Use STAR method for behavioral questions',
        'Show customer obsession in all answers',
        'Demonstrate ownership and bias for action'
      ]
    },
    netflix: {
      name: 'Netflix',
      logo: '🎬',
      size: 'Large Tech',
      culture: 'Freedom & responsibility, high performance',
      interviewStyle: 'Technical depth, cultural values, system design',
      difficulty: 'High',
      averageRounds: 4,
      timelineWeeks: '4-6',
      focusAreas: ['Technical Excellence', 'Cultural Values', 'System Design', 'Innovation'],
      commonQuestions: [
        'Design Netflix video streaming architecture',
        'How do you handle technical debt?',
        'Tell me about a time you took a calculated risk',
        'Design a content recommendation engine'
      ],
      techStack: ['Java', 'Python', 'JavaScript', 'Scala', 'React'],
      preparation: {
        algorithms: 70,
        systemDesign: 92,
        behavioral: 75,
        coding: 80
      },
      interviewTips: [
        'Emphasize technical excellence and innovation',
        'Show ability to work independently',
        'Demonstrate high-performance mindset',
        'Focus on scalability and reliability'
      ]
    }
  };

  const prepProgress = {
    researchCompleted: 75,
    questionsStudied: 12,
    mockInterviews: 3,
    cultureAlignment: 85
  };

  const companyResearch = [
    {
      category: 'Company Culture',
      items: [
        { task: 'Mission & Values Analysis', completed: true, importance: 'High' },
        { task: 'Recent News & Updates', completed: true, importance: 'Medium' },
        { task: 'Leadership Team Research', completed: false, importance: 'Medium' },
        { task: 'Company Blog Reading', completed: true, importance: 'Medium' }
      ]
    },
    {
      category: 'Technical Preparation',
      items: [
        { task: 'Tech Stack Deep Dive', completed: true, importance: 'High' },
        { task: 'Architecture Patterns Study', completed: false, importance: 'High' },
        { task: 'Common Interview Questions', completed: true, importance: 'High' },
        { task: 'System Design Specific to Company', completed: false, importance: 'High' }
      ]
    },
    {
      category: 'Role-Specific Research',
      items: [
        { task: 'Job Description Analysis', completed: true, importance: 'High' },
        { task: 'Team Structure Research', completed: false, importance: 'Medium' },
        { task: 'Current Projects Understanding', completed: false, importance: 'Medium' },
        { task: 'Growth Opportunities Analysis', completed: true, importance: 'Medium' }
      ]
    }
  ];

  const interviewRounds = [
    {
      round: 'Phone Screen',
      duration: '45 mins',
      focus: 'Coding & Basic System Design',
      preparation: 'Algorithm practice, basic system design concepts',
      tips: 'Clear communication, ask clarifying questions'
    },
    {
      round: 'Technical Round 1',
      duration: '60 mins',
      focus: 'Advanced Coding',
      preparation: 'Complex algorithms, data structures, optimization',
      tips: 'Think out loud, consider edge cases, optimize time complexity'
    },
    {
      round: 'System Design',
      duration: '60 mins',
      focus: 'Large Scale Architecture',
      preparation: 'Scalability patterns, database design, microservices',
      tips: 'Start high-level, drill down, consider trade-offs'
    },
    {
      round: 'Behavioral',
      duration: '45 mins',
      focus: 'Cultural Fit & Leadership',
      preparation: 'STAR method, leadership principles, culture alignment',
      tips: 'Specific examples, quantify impact, show growth mindset'
    },
    {
      round: 'Final Round',
      duration: '30 mins',
      focus: 'Questions & Culture',
      preparation: 'Thoughtful questions, salary negotiation',
      tips: 'Show genuine interest, ask about growth opportunities'
    }
  ];

  const selectedCompanyData = companies[selectedCompany as keyof typeof companies];

  return (
    <PlatformLayout
      sidebarTitle="Candidate Platform"
      sidebarSubtitle="Interview Preparation"
      sidebarSections={candidateNavigation}
    >
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-indigo-50 p-6">
        <div className="max-w-7xl mx-auto space-y-8">
          {/* Header */}
          <div className="text-center space-y-4">
            <div className="inline-flex items-center space-x-2 bg-blue-100 text-blue-800 px-4 py-2 rounded-full text-sm font-medium">
              <Building className="h-4 w-4" />
              <span>Company-Specific Interview Preparation</span>
            </div>
            <h1 className="text-4xl font-bold text-gray-900">
              Tailored Company Preparation
            </h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Deep-dive preparation for specific companies with culture insights, 
              interview patterns, and customized practice based on company requirements.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Main Content */}
            <div className="lg:col-span-2 space-y-6">
              {/* Company Selection */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Globe className="h-5 w-5" />
                    <span>Select Target Company</span>
                  </CardTitle>
                  <CardDescription>Choose a company to get tailored preparation insights</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                    {Object.entries(companies).map(([key, company]) => (
                      <Card 
                        key={key}
                        className={`cursor-pointer transition-all duration-300 border-2 ${
                          selectedCompany === key 
                            ? 'border-blue-500 shadow-lg' 
                            : 'border-gray-200 hover:border-blue-300'
                        }`}
                        onClick={() => setSelectedCompany(key)}
                      >
                        <CardContent className="p-4">
                          <div className="flex items-center space-x-3 mb-2">
                            <div className="text-2xl">{company.logo}</div>
                            <div>
                              <h3 className="font-semibold">{company.name}</h3>
                              <p className="text-sm text-gray-600">{company.size}</p>
                            </div>
                          </div>
                          <div className="space-y-2">
                            <Badge variant={
                              company.difficulty === 'Very High' ? 'destructive' :
                              company.difficulty === 'High' ? 'default' : 'secondary'
                            }>
                              {company.difficulty}
                            </Badge>
                            <div className="text-xs text-gray-600">
                              {company.averageRounds} rounds • {company.timelineWeeks} weeks
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* Company Deep Dive */}
              <Card>
                <CardHeader className="bg-gradient-to-r from-blue-500 to-indigo-500 text-white">
                  <CardTitle className="text-xl flex items-center space-x-3">
                    <div className="text-2xl">{selectedCompanyData.logo}</div>
                    <span>{selectedCompanyData.name} Interview Preparation</span>
                  </CardTitle>
                  <CardDescription className="text-white/80">
                    Comprehensive preparation strategy tailored to {selectedCompanyData.name}
                  </CardDescription>
                </CardHeader>
                <CardContent className="p-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                    <div>
                      <h3 className="font-semibold text-blue-700 mb-3">Company Culture</h3>
                      <p className="text-gray-700 mb-4">{selectedCompanyData.culture}</p>
                      
                      <h3 className="font-semibold text-green-700 mb-3">Interview Style</h3>
                      <p className="text-gray-700 mb-4">{selectedCompanyData.interviewStyle}</p>
                      
                      <h3 className="font-semibold text-purple-700 mb-3">Tech Stack</h3>
                      <div className="flex flex-wrap gap-1">
                        {selectedCompanyData.techStack.map((tech: any, index: number) => (
                          <Badge key={index} variant="outline" className="text-xs">
                            {tech}
                          </Badge>
                        ))}
                      </div>
                    </div>
                    
                    <div>
                      <h3 className="font-semibold text-orange-700 mb-3">Preparation Focus</h3>
                      <div className="space-y-3">
                        {Object.entries(selectedCompanyData.preparation).map(([area, score]) => (
                          <div key={area} className="space-y-1">
                            <div className="flex justify-between text-sm">
                              <span className="capitalize">{area.replace(/([A-Z])/g, ' $1')}</span>
                              <span>{score}%</span>
                            </div>
                            <Progress value={score} className="h-2" />
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                    <div>
                      <h3 className="font-semibold text-red-700 mb-3">Focus Areas</h3>
                      <div className="space-y-2">
                        {selectedCompanyData.focusAreas.map((area, index) => (
                          <div key={index} className="flex items-center space-x-2">
                            <Target className="h-4 w-4 text-red-500" />
                            <span className="text-sm">{area}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                    
                    <div>
                      <h3 className="font-semibold text-indigo-700 mb-3">Common Questions</h3>
                      <div className="space-y-2">
                        {selectedCompanyData.commonQuestions.map((question, index) => (
                          <div key={index} className="text-sm text-gray-700 p-2 bg-gray-50 rounded">
                            "{question}"
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>

                  <div>
                    <h3 className="font-semibold text-green-700 mb-3">Interview Success Tips</h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                      {selectedCompanyData.interviewTips.map((tip, index) => (
                        <div key={index} className="flex items-start space-x-2 p-3 bg-green-50 rounded-lg">
                          <CheckCircle className="h-4 w-4 text-green-500 mt-0.5" />
                          <span className="text-sm text-gray-700">{tip}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Interview Process */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Clock className="h-5 w-5" />
                    <span>Interview Process Overview</span>
                  </CardTitle>
                  <CardDescription>Typical interview rounds and what to expect</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {interviewRounds.map((round, index) => (
                      <div key={index} className="p-4 border-l-4 border-blue-500 bg-blue-50 rounded-r-lg">
                        <div className="flex items-center justify-between mb-2">
                          <h3 className="font-semibold text-lg">{round.round}</h3>
                          <Badge variant="outline">{round.duration}</Badge>
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-sm">
                          <div>
                            <span className="font-medium text-blue-700">Focus:</span>
                            <div className="text-gray-700">{round.focus}</div>
                          </div>
                          <div>
                            <span className="font-medium text-green-700">Preparation:</span>
                            <div className="text-gray-700">{round.preparation}</div>
                          </div>
                          <div>
                            <span className="font-medium text-purple-700">Tips:</span>
                            <div className="text-gray-700">{round.tips}</div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Sidebar */}
            <div className="space-y-6">
              {/* Preparation Progress */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Activity className="h-5 w-5" />
                    <span>Prep Progress</span>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-3">
                    <div>
                      <div className="flex justify-between text-sm mb-1">
                        <span>Research Completed</span>
                        <span>{prepProgress.researchCompleted}%</span>
                      </div>
                      <Progress value={prepProgress.researchCompleted} className="h-2" />
                    </div>
                    <div>
                      <div className="flex justify-between text-sm mb-1">
                        <span>Culture Alignment</span>
                        <span>{prepProgress.cultureAlignment}%</span>
                      </div>
                      <Progress value={prepProgress.cultureAlignment} className="h-2" />
                    </div>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4 text-center">
                    <div>
                      <div className="text-2xl font-bold text-blue-600">{prepProgress.questionsStudied}</div>
                      <div className="text-xs text-gray-500">Questions Studied</div>
                    </div>
                    <div>
                      <div className="text-2xl font-bold text-green-600">{prepProgress.mockInterviews}</div>
                      <div className="text-xs text-gray-500">Mock Interviews</div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Research Checklist */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <BookOpen className="h-5 w-5" />
                    <span>Research Checklist</span>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {companyResearch.map((category, index) => (
                    <div key={index}>
                      <h3 className="font-medium text-sm mb-2">{category.category}</h3>
                      <div className="space-y-2">
                        {category.items.map((item, i) => (
                          <div key={i} className="flex items-center justify-between p-2 bg-gray-50 rounded">
                            <div className="flex items-center space-x-2">
                              {item.completed ? (
                                <CheckCircle className="h-4 w-4 text-green-500" />
                              ) : (
                                <div className="h-4 w-4 border-2 border-gray-300 rounded" />
                              )}
                              <span className="text-xs">{item.task}</span>
                            </div>
                            <Badge variant="outline" className="text-xs">
                              {item.importance}
                            </Badge>
                          </div>
                        ))}
                      </div>
                    </div>
                  ))}
                </CardContent>
              </Card>

              {/* Action Buttons */}
              <div className="space-y-3">
                <Button size="lg" className="w-full bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700">
                  <Play className="h-4 w-4 mr-2" />
                  Start {selectedCompanyData.name} Prep
                </Button>
                <Button variant="outline" size="lg" className="w-full">
                  <MessageSquare className="h-4 w-4 mr-2" />
                  Company Mock Interview
                </Button>
                <Button variant="outline" size="lg" className="w-full">
                  <Brain className="h-4 w-4 mr-2" />
                  Culture Assessment
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </PlatformLayout>
  );
};

export default CompanyPrep;