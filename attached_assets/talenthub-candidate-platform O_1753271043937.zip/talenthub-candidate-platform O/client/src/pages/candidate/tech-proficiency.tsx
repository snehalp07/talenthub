import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import PlatformLayout from "@/components/layout/platform-layout";
import { candidateNavigation } from "@/config/complete-navigation";
import { 
  Target, TrendingUp, Star, Code, Database, Server, 
  Monitor, Cloud, Brain, Zap, CheckCircle, ArrowUp,
  Activity, Award, Calendar, Play, BookOpen
} from "lucide-react";

const TechProficiency: React.FC = () => {
  const [selectedCategory, setSelectedCategory] = useState('frontend');

  const techCategories = {
    frontend: {
      name: 'Frontend Development',
      icon: Monitor,
      color: 'from-blue-500 to-cyan-500',
      technologies: [
        { name: 'React', level: 85, trend: '+12%', interviews: 8, lastScore: 87, targetLevel: 90 },
        { name: 'Vue.js', level: 70, trend: '+8%', interviews: 3, lastScore: 73, targetLevel: 80 },
        { name: 'Angular', level: 60, trend: '+15%', interviews: 2, lastScore: 65, targetLevel: 75 },
        { name: 'TypeScript', level: 78, trend: '+10%', interviews: 6, lastScore: 82, targetLevel: 85 },
        { name: 'JavaScript ES6+', level: 88, trend: '+5%', interviews: 12, lastScore: 90, targetLevel: 92 },
        { name: 'CSS/SCSS', level: 82, trend: '+7%', interviews: 10, lastScore: 85, targetLevel: 88 }
      ]
    },
    backend: {
      name: 'Backend Development',
      icon: Server,
      color: 'from-green-500 to-emerald-500',
      technologies: [
        { name: 'Node.js', level: 79, trend: '+8%', interviews: 6, lastScore: 82, targetLevel: 85 },
        { name: 'Python', level: 73, trend: '+15%', interviews: 5, lastScore: 76, targetLevel: 80 },
        { name: 'Java', level: 65, trend: '+12%', interviews: 3, lastScore: 68, targetLevel: 75 },
        { name: 'Express.js', level: 81, trend: '+6%', interviews: 7, lastScore: 84, targetLevel: 88 },
        { name: 'Django', level: 68, trend: '+18%', interviews: 2, lastScore: 71, targetLevel: 78 },
        { name: 'REST APIs', level: 85, trend: '+4%', interviews: 9, lastScore: 88, targetLevel: 90 }
      ]
    },
    database: {
      name: 'Database Technologies',
      icon: Database,
      color: 'from-purple-500 to-pink-500',
      technologies: [
        { name: 'PostgreSQL', level: 76, trend: '+9%', interviews: 4, lastScore: 79, targetLevel: 82 },
        { name: 'MongoDB', level: 71, trend: '+13%', interviews: 5, lastScore: 74, targetLevel: 80 },
        { name: 'Redis', level: 58, trend: '+22%', interviews: 2, lastScore: 62, targetLevel: 70 },
        { name: 'SQL Optimization', level: 65, trend: '+16%', interviews: 3, lastScore: 68, targetLevel: 75 },
        { name: 'Database Design', level: 73, trend: '+11%', interviews: 4, lastScore: 76, targetLevel: 82 },
        { name: 'NoSQL Concepts', level: 69, trend: '+14%', interviews: 3, lastScore: 72, targetLevel: 78 }
      ]
    },
    devops: {
      name: 'DevOps & Cloud',
      icon: Cloud,
      color: 'from-orange-500 to-red-500',
      technologies: [
        { name: 'AWS', level: 68, trend: '+20%', interviews: 3, lastScore: 71, targetLevel: 78 },
        { name: 'Docker', level: 65, trend: '+18%', interviews: 4, lastScore: 68, targetLevel: 75 },
        { name: 'Kubernetes', level: 45, trend: '+25%', interviews: 1, lastScore: 48, targetLevel: 65 },
        { name: 'CI/CD', level: 62, trend: '+15%', interviews: 2, lastScore: 65, targetLevel: 72 },
        { name: 'Linux', level: 74, trend: '+8%', interviews: 5, lastScore: 77, targetLevel: 82 },
        { name: 'Git', level: 86, trend: '+3%', interviews: 8, lastScore: 88, targetLevel: 90 }
      ]
    }
  };

  const overallMetrics = {
    totalTechnologies: 24,
    averageProficiency: 72,
    improvementRate: 12,
    expertLevel: 6,
    advancedLevel: 10,
    intermediateLevel: 8
  };

  const skillProgression = [
    { month: 'Jan', frontend: 68, backend: 62, database: 58, devops: 45 },
    { month: 'Feb', frontend: 72, backend: 67, database: 63, devops: 52 },
    { month: 'Mar', frontend: 76, backend: 71, database: 68, devops: 58 },
    { month: 'Apr', frontend: 79, backend: 74, database: 71, devops: 62 }
  ];

  const recommendedLearning = [
    {
      technology: 'Kubernetes',
      currentLevel: 45,
      targetLevel: 65,
      priority: 'High',
      reason: 'High demand in DevOps roles',
      estimatedTime: '4-6 weeks',
      resources: ['Official Docs', 'Hands-on Labs', 'Practice Projects']
    },
    {
      technology: 'Redis',
      currentLevel: 58,
      targetLevel: 70,
      priority: 'Medium',
      reason: 'Important for caching strategies',
      estimatedTime: '2-3 weeks',
      resources: ['Redis University', 'Practical Examples']
    },
    {
      technology: 'Angular',
      currentLevel: 60,
      targetLevel: 75,
      priority: 'Medium',
      reason: 'Enterprise frontend opportunities',
      estimatedTime: '3-4 weeks',
      resources: ['Angular.io Guide', 'Real Projects']
    }
  ];

  const selectedCategoryData = techCategories[selectedCategory as keyof typeof techCategories];

  return (
    <PlatformLayout
      sidebarTitle="Candidate Platform"
      sidebarSubtitle="Interview Preparation"
      sidebarSections={candidateNavigation}
    >
      <div className="min-h-screen bg-gradient-to-br from-purple-50 via-white to-indigo-50 p-6">
        <div className="max-w-7xl mx-auto space-y-8">
          {/* Header */}
          <div className="text-center space-y-4">
            <div className="inline-flex items-center space-x-2 bg-purple-100 text-purple-800 px-4 py-2 rounded-full text-sm font-medium">
              <Target className="h-4 w-4" />
              <span>Tech Stack Proficiency Analysis</span>
            </div>
            <h1 className="text-4xl font-bold text-gray-900">
              Technology Skill Assessment
            </h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Comprehensive analysis of your technical skills across different technology stacks 
              with AI-powered recommendations for improvement and career advancement.
            </p>
          </div>

          {/* Overall Metrics */}
          <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-6 gap-4">
            <Card className="bg-gradient-to-r from-blue-500 to-cyan-500 text-white">
              <CardContent className="p-4">
                <div className="text-center">
                  <Code className="h-6 w-6 mx-auto mb-2 text-blue-200" />
                  <p className="text-sm text-blue-100">Technologies</p>
                  <p className="text-2xl font-bold">{overallMetrics.totalTechnologies}</p>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-r from-green-500 to-emerald-500 text-white">
              <CardContent className="p-4">
                <div className="text-center">
                  <Target className="h-6 w-6 mx-auto mb-2 text-green-200" />
                  <p className="text-sm text-green-100">Avg Proficiency</p>
                  <p className="text-2xl font-bold">{overallMetrics.averageProficiency}%</p>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-r from-purple-500 to-pink-500 text-white">
              <CardContent className="p-4">
                <div className="text-center">
                  <TrendingUp className="h-6 w-6 mx-auto mb-2 text-purple-200" />
                  <p className="text-sm text-purple-100">Growth Rate</p>
                  <p className="text-2xl font-bold">+{overallMetrics.improvementRate}%</p>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-r from-yellow-500 to-orange-500 text-white">
              <CardContent className="p-4">
                <div className="text-center">
                  <Star className="h-6 w-6 mx-auto mb-2 text-yellow-200" />
                  <p className="text-sm text-yellow-100">Expert Level</p>
                  <p className="text-2xl font-bold">{overallMetrics.expertLevel}</p>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-r from-indigo-500 to-purple-500 text-white">
              <CardContent className="p-4">
                <div className="text-center">
                  <Award className="h-6 w-6 mx-auto mb-2 text-indigo-200" />
                  <p className="text-sm text-indigo-100">Advanced</p>
                  <p className="text-2xl font-bold">{overallMetrics.advancedLevel}</p>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-r from-teal-500 to-blue-500 text-white">
              <CardContent className="p-4">
                <div className="text-center">
                  <Activity className="h-6 w-6 mx-auto mb-2 text-teal-200" />
                  <p className="text-sm text-teal-100">Intermediate</p>
                  <p className="text-2xl font-bold">{overallMetrics.intermediateLevel}</p>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Technology Categories */}
            <div className="lg:col-span-2">
              <Tabs value={selectedCategory} onValueChange={setSelectedCategory} className="space-y-6">
                {/* Category Selection */}
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  {Object.entries(techCategories).map(([key, category]) => {
                    const IconComponent = category.icon;
                    return (
                      <Card 
                        key={key}
                        className={`cursor-pointer transition-all duration-300 hover:shadow-lg border-2 ${
                          selectedCategory === key 
                            ? 'border-purple-500 shadow-lg' 
                            : 'border-gray-200 hover:border-purple-300'
                        }`}
                        onClick={() => setSelectedCategory(key)}
                      >
                        <CardContent className="p-4 text-center">
                          <div className={`p-3 rounded-lg bg-gradient-to-r ${category.color} mb-2 mx-auto w-fit`}>
                            <IconComponent className="h-6 w-6 text-white" />
                          </div>
                          <h3 className="font-medium text-sm">{category.name}</h3>
                        </CardContent>
                      </Card>
                    );
                  })}
                </div>

                {/* Selected Category Details */}
                <Card>
                  <CardHeader className={`bg-gradient-to-r ${selectedCategoryData.color} text-white`}>
                    <CardTitle className="flex items-center space-x-3">
                      <selectedCategoryData.icon className="h-6 w-6" />
                      <span>{selectedCategoryData.name}</span>
                    </CardTitle>
                    <CardDescription className="text-white/80">
                      Detailed skill assessment and improvement tracking
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="p-6">
                    <div className="space-y-6">
                      {selectedCategoryData.technologies.map((tech: any, index: number) => (
                        <div key={index} className="p-4 bg-gray-50 rounded-lg">
                          <div className="flex items-center justify-between mb-3">
                            <h3 className="font-semibold text-lg">{tech.name}</h3>
                            <div className="flex items-center space-x-3">
                              <Badge variant="secondary" className="bg-green-100 text-green-700">
                                {tech.trend}
                              </Badge>
                              <span className="text-xl font-bold">{tech.level}%</span>
                            </div>
                          </div>
                          
                          <div className="relative mb-3">
                            <Progress value={tech.level} className="h-3" />
                            <div 
                              className="absolute top-0 h-3 w-1 bg-red-500 rounded-full"
                              style={{ left: `${tech.targetLevel}%` }}
                            />
                          </div>
                          
                          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                            <div>
                              <span className="text-gray-500">Interviews:</span>
                              <div className="font-medium">{tech.interviews}</div>
                            </div>
                            <div>
                              <span className="text-gray-500">Last Score:</span>
                              <div className="font-medium">{tech.lastScore}%</div>
                            </div>
                            <div>
                              <span className="text-gray-500">Target:</span>
                              <div className="font-medium">{tech.targetLevel}%</div>
                            </div>
                            <div>
                              <span className="text-gray-500">Gap:</span>
                              <div className={`font-medium ${tech.targetLevel > tech.level ? 'text-red-600' : 'text-green-600'}`}>
                                {tech.targetLevel - tech.level > 0 ? '+' : ''}{tech.targetLevel - tech.level}%
                              </div>
                            </div>
                          </div>
                          
                          <div className="flex items-center justify-between mt-4 pt-3 border-t">
                            <div className="flex items-center space-x-2">
                              {tech.level >= 85 ? (
                                <Badge className="bg-green-500">Expert</Badge>
                              ) : tech.level >= 70 ? (
                                <Badge className="bg-blue-500">Advanced</Badge>
                              ) : tech.level >= 50 ? (
                                <Badge variant="secondary">Intermediate</Badge>
                              ) : (
                                <Badge variant="outline">Foundation</Badge>
                              )}
                            </div>
                            <Button variant="outline" size="sm">
                              <Play className="h-3 w-3 mr-2" />
                              Practice
                            </Button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </Tabs>
            </div>

            {/* Sidebar */}
            <div className="space-y-6">
              {/* Learning Recommendations */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Brain className="h-5 w-5" />
                    <span>AI Recommendations</span>
                  </CardTitle>
                  <CardDescription>Personalized learning priorities</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  {recommendedLearning.map((rec, index) => (
                    <div key={index} className="p-3 border rounded-lg">
                      <div className="flex items-center justify-between mb-2">
                        <span className="font-medium text-sm">{rec.technology}</span>
                        <Badge variant={
                          rec.priority === 'High' ? 'destructive' :
                          rec.priority === 'Medium' ? 'default' : 'secondary'
                        }>
                          {rec.priority}
                        </Badge>
                      </div>
                      <div className="text-xs text-gray-600 mb-2">{rec.reason}</div>
                      <div className="flex justify-between text-xs mb-2">
                        <span>Current: {rec.currentLevel}%</span>
                        <span>Target: {rec.targetLevel}%</span>
                      </div>
                      <Progress value={(rec.currentLevel / rec.targetLevel) * 100} className="h-1 mb-2" />
                      <div className="text-xs text-blue-600">{rec.estimatedTime}</div>
                    </div>
                  ))}
                </CardContent>
              </Card>

              {/* Skill Progression Chart */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center space-x-2">
                    <Calendar className="h-5 w-5" />
                    <span>Monthly Progress</span>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {skillProgression.map((month, index) => (
                      <div key={index} className="space-y-2">
                        <div className="flex justify-between items-center">
                          <span className="font-medium text-sm">{month.month}</span>
                          <span className="text-xs text-gray-500">
                            Avg: {Math.round((month.frontend + month.backend + month.database + month.devops) / 4)}%
                          </span>
                        </div>
                        <div className="grid grid-cols-4 gap-1">
                          <div className="text-center">
                            <div className="text-xs text-blue-600">{month.frontend}%</div>
                            <div className="h-1 bg-blue-500 rounded" style={{ width: `${month.frontend}%` }} />
                          </div>
                          <div className="text-center">
                            <div className="text-xs text-green-600">{month.backend}%</div>
                            <div className="h-1 bg-green-500 rounded" style={{ width: `${month.backend}%` }} />
                          </div>
                          <div className="text-center">
                            <div className="text-xs text-purple-600">{month.database}%</div>
                            <div className="h-1 bg-purple-500 rounded" style={{ width: `${month.database}%` }} />
                          </div>
                          <div className="text-center">
                            <div className="text-xs text-orange-600">{month.devops}%</div>
                            <div className="h-1 bg-orange-500 rounded" style={{ width: `${month.devops}%` }} />
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* Action Buttons */}
              <div className="space-y-3">
                <Button size="lg" className="w-full bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700">
                  <Play className="h-4 w-4 mr-2" />
                  Start Practice Session
                </Button>
                <Button variant="outline" size="lg" className="w-full">
                  <BookOpen className="h-4 w-4 mr-2" />
                  Learning Resources
                </Button>
                <Button variant="outline" size="lg" className="w-full">
                  <Target className="h-4 w-4 mr-2" />
                  Set New Goals
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </PlatformLayout>
  );
};

export default TechProficiency;