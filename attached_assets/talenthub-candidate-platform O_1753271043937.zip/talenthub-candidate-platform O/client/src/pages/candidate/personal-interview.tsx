import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useMutation, useQuery } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { CreditCard, CheckCircle, User, Briefcase, MapPin, DollarSign, Star } from "lucide-react";
import PlatformLayout from "@/components/layout/platform-layout";
import { platformConfigs } from "@/config/complete-navigation";

const personalInterviewSchema = z.object({
  jobIntent: z.string().min(10, "Please provide at least 10 characters describing your job intent"),
  topStrengths: z.array(z.string()).min(3, "Please select at least 3 strengths").max(5, "Maximum 5 strengths allowed"),
  preferredDomain: z.string().min(1, "Please select your preferred domain"),
  expectedCtc: z.number().min(1, "Please enter expected CTC"),
  currentLocation: z.string().min(1, "Please enter your current location"),
  willingnessToRelocate: z.boolean(),
});

type PersonalInterviewFormData = z.infer<typeof personalInterviewSchema>;

const strengthOptions = [
  "Problem Solving", "Leadership", "Communication", "Technical Skills", "Teamwork",
  "Adaptability", "Creativity", "Analytical Thinking", "Time Management", "Project Management",
  "Customer Service", "Attention to Detail", "Innovation", "Strategic Planning", "Mentoring"
];

const domainOptions = [
  "Software Development", "Data Science", "Product Management", "UX/UI Design", "DevOps",
  "Quality Assurance", "Business Analysis", "Cybersecurity", "Machine Learning", "Cloud Computing",
  "Mobile Development", "Frontend Development", "Backend Development", "Full Stack Development"
];

function PersonalInterviewContent() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [selectedStrengths, setSelectedStrengths] = useState<string[]>([]);
  const [paymentCompleted, setPaymentCompleted] = useState(false);
  const [showCompletionDialog, setShowCompletionDialog] = useState(false);

  const { data: existingInterview, isLoading: isLoadingInterview } = useQuery({
    queryKey: ["/api/personal-interview"],
    enabled: !!user,
  });

  const form = useForm<PersonalInterviewFormData>({
    resolver: zodResolver(personalInterviewSchema),
    defaultValues: {
      jobIntent: (existingInterview as any)?.jobIntent || "",
      topStrengths: (existingInterview as any)?.topStrengths || [],
      preferredDomain: (existingInterview as any)?.preferredDomain || "",
      expectedCtc: (existingInterview as any)?.expectedCtc || 0,
      currentLocation: (existingInterview as any)?.currentLocation || "",
      willingnessToRelocate: (existingInterview as any)?.willingnessToRelocate || false,
    },
  });

  const createInterviewMutation = useMutation({
    mutationFn: async (data: PersonalInterviewFormData) => {
      return await apiRequest("POST", "/api/personal-interview", data);
    },
    onSuccess: () => {
      setShowCompletionDialog(true);
      queryClient.invalidateQueries({ queryKey: ["/api/personal-interview"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const processPaymentMutation = useMutation({
    mutationFn: async () => {
      return await apiRequest("POST", "/api/personal-interview/payment", { amount: 500 });
    },
    onSuccess: () => {
      setPaymentCompleted(true);
      toast({
        title: "Payment Successful",
        description: "Registration fee of ₹500 has been processed. You can now complete your PI.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Payment Failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleStrengthToggle = (strength: string) => {
    const newStrengths = selectedStrengths.includes(strength)
      ? selectedStrengths.filter(s => s !== strength)
      : [...selectedStrengths, strength];
    
    if (newStrengths.length <= 5) {
      setSelectedStrengths(newStrengths);
      form.setValue("topStrengths", newStrengths);
    }
  };

  const onSubmit = (data: PersonalInterviewFormData) => {
    createInterviewMutation.mutate(data);
  };

  if (isLoadingInterview) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }

  if (existingInterview?.completedAt) {
    return (
      <div className="max-w-4xl mx-auto p-6">
        <Card>
          <CardHeader className="text-center">
            <div className="mx-auto w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mb-4">
              <CheckCircle className="w-8 h-8 text-green-600" />
            </div>
            <CardTitle className="text-2xl text-green-600">Personal Interview Completed!</CardTitle>
            <CardDescription>
              Your profile is now visible to recruiters and you have access to job opportunities.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <h3 className="font-semibold flex items-center">
                  <Briefcase className="w-4 h-4 mr-2" />
                  Job Intent
                </h3>
                <p className="text-sm text-muted-foreground">{existingInterview.jobIntent}</p>
              </div>
              <div className="space-y-2">
                <h3 className="font-semibold flex items-center">
                  <Star className="w-4 h-4 mr-2" />
                  Top Strengths
                </h3>
                <div className="flex flex-wrap gap-1">
                  {existingInterview.topStrengths?.map((strength: string) => (
                    <Badge key={strength} variant="secondary">{strength}</Badge>
                  ))}
                </div>
              </div>
              <div className="space-y-2">
                <h3 className="font-semibold flex items-center">
                  <User className="w-4 h-4 mr-2" />
                  Preferred Domain
                </h3>
                <p className="text-sm text-muted-foreground">{existingInterview.preferredDomain}</p>
              </div>
              <div className="space-y-2">
                <h3 className="font-semibold flex items-center">
                  <DollarSign className="w-4 h-4 mr-2" />
                  Expected CTC
                </h3>
                <p className="text-sm text-muted-foreground">₹{existingInterview.expectedCtc?.toLocaleString()}</p>
              </div>
              <div className="space-y-2">
                <h3 className="font-semibold flex items-center">
                  <MapPin className="w-4 h-4 mr-2" />
                  Current Location
                </h3>
                <p className="text-sm text-muted-foreground">{existingInterview.currentLocation}</p>
              </div>
              <div className="space-y-2">
                <h3 className="font-semibold">Willingness to Relocate</h3>
                <p className="text-sm text-muted-foreground">
                  {existingInterview.willingnessToRelocate ? "Yes" : "No"}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (!paymentCompleted && !existingInterview?.paymentStatus === "paid") {
    return (
      <div className="max-w-2xl mx-auto p-6">
        <Card>
          <CardHeader className="text-center">
            <div className="mx-auto w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mb-4">
              <CreditCard className="w-8 h-8 text-blue-600" />
            </div>
            <CardTitle className="text-2xl">Personal Interview Registration</CardTitle>
            <CardDescription>
              Complete your PI registration to make your profile visible to recruiters
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="bg-blue-50 p-4 rounded-lg">
              <h3 className="font-semibold text-blue-900 mb-2">What's Included:</h3>
              <ul className="space-y-1 text-sm text-blue-800">
                <li>• Profile visibility to verified recruiters</li>
                <li>• Access to exclusive job opportunities</li>
                <li>• Direct contact from hiring managers</li>
                <li>• Personalized job recommendations</li>
                <li>• Analytics on profile views and interests</li>
              </ul>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-gray-900 mb-2">₹500</div>
              <div className="text-sm text-muted-foreground mb-4">One-time registration fee</div>
              <Button 
                onClick={() => processPaymentMutation.mutate()}
                disabled={processPaymentMutation.isPending}
                className="w-full"
                size="lg"
              >
                {processPaymentMutation.isPending ? "Processing..." : "Pay & Continue"}
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto p-6">
      <Card>
        <CardHeader>
          <CardTitle className="text-2xl">Personal Interview Questions</CardTitle>
          <CardDescription>
            Please answer these questions to help recruiters understand your profile better
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              <FormField
                control={form.control}
                name="jobIntent"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>What are your career goals and job intent?</FormLabel>
                    <FormControl>
                      <Textarea 
                        {...field}
                        placeholder="Describe your career aspirations, what type of role you're looking for, and your professional objectives..."
                        rows={4}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="topStrengths"
                render={() => (
                  <FormItem>
                    <FormLabel>What are your top 3-5 strengths?</FormLabel>
                    <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                      {strengthOptions.map((strength) => (
                        <div key={strength} className="flex items-center space-x-2">
                          <Checkbox
                            id={strength}
                            checked={selectedStrengths.includes(strength)}
                            onCheckedChange={() => handleStrengthToggle(strength)}
                            disabled={!selectedStrengths.includes(strength) && selectedStrengths.length >= 5}
                          />
                          <label htmlFor={strength} className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70">
                            {strength}
                          </label>
                        </div>
                      ))}
                    </div>
                    <div className="text-sm text-muted-foreground">
                      Selected: {selectedStrengths.length}/5
                    </div>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="preferredDomain"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Preferred domain/industry?</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select your preferred domain" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {domainOptions.map((domain) => (
                          <SelectItem key={domain} value={domain}>
                            {domain}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="expectedCtc"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Expected CTC (Annual in ₹)</FormLabel>
                    <FormControl>
                      <Input 
                        type="number"
                        {...field}
                        onChange={(e) => field.onChange(Number(e.target.value))}
                        placeholder="e.g., 800000"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="currentLocation"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Current location</FormLabel>
                    <FormControl>
                      <Input {...field} placeholder="e.g., Bangalore, Mumbai, Delhi" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="willingnessToRelocate"
                render={({ field }) => (
                  <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                    <FormControl>
                      <Checkbox
                        checked={field.value}
                        onCheckedChange={field.onChange}
                      />
                    </FormControl>
                    <div className="space-y-1 leading-none">
                      <FormLabel>
                        I am willing to relocate for the right opportunity
                      </FormLabel>
                    </div>
                  </FormItem>
                )}
              />

              <Button 
                type="submit" 
                disabled={createInterviewMutation.isPending}
                className="w-full"
                size="lg"
              >
                {createInterviewMutation.isPending ? "Submitting..." : "Complete Personal Interview"}
              </Button>
            </form>
          </Form>
        </CardContent>
      </Card>

      {/* Completion Dialog */}
      <Dialog open={showCompletionDialog} onOpenChange={setShowCompletionDialog}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-green-600">
              <CheckCircle className="w-6 h-6" />
              Thank You for Completing Your Personal Interview!
            </DialogTitle>
            <DialogDescription className="space-y-4 pt-4">
              <p className="text-gray-700">
                Thank you for completing your personal interview! You are now registered with us. 
              </p>
              <p className="text-gray-700">
                We will make jobs available for you based on the subscription package you chose.
              </p>
              <div className="bg-sky-50 p-4 rounded-lg border border-sky-200">
                <p className="text-sky-800 font-medium">
                  Next Steps:
                </p>
                <ul className="text-sky-700 text-sm mt-2 space-y-1">
                  <li>• Browse available jobs in the Job Board</li>
                  <li>• Complete skills assessments to improve your ranking</li>
                  <li>• Check your notifications for job matches</li>
                </ul>
              </div>
            </DialogDescription>
          </DialogHeader>
          <div className="flex justify-end">
            <Button 
              onClick={() => setShowCompletionDialog(false)}
              className="bg-sky-600 hover:bg-sky-700"
            >
              Got it, thanks!
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}

export default function PersonalInterview() {
  const config = platformConfigs.candidate;
  
  const usageData = [
    { label: "Interview Sessions", current: 3, max: 10 },
    { label: "Premium Features", current: 5, max: 15 },
    { label: "Expert Reviews", current: 2, max: 8 },
  ];

  return (
    <PlatformLayout
      sidebarTitle={config.sidebarTitle}
      sidebarSubtitle={config.sidebarSubtitle}
      sidebarSections={config.sidebarSections}
      usageData={usageData}
    >
      <PersonalInterviewContent />
    </PlatformLayout>
  );
}