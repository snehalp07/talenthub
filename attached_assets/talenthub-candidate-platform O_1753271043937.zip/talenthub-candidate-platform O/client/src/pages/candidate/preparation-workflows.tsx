import PlatformLayout from "@/components/layout/platform-layout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Workflow, CheckCircle, Clock, Target } from "lucide-react";
import { candidateNavigation } from "@/config/complete-navigation";

export default function PreparationWorkflows() {
  return (
    <PlatformLayout 
      sidebarTitle="Candidate Platform"
      sidebarSubtitle="Professional Development Hub"
      sidebarSections={candidateNavigation}
    >
      <div className="max-w-7xl mx-auto p-6 space-y-8">
        <div className="text-center space-y-4">
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-green-100 to-emerald-100 rounded-full">
            <Workflow className="h-5 w-5 text-green-600" />
            <span className="text-sm font-medium text-green-900">Preparation Workflows</span>
          </div>
          <h1 className="text-4xl font-bold bg-gradient-to-r from-green-600 to-emerald-600 bg-clip-text text-transparent">
            Certification Preparation Analytics
          </h1>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            Track your preparation workflows, study patterns, and readiness metrics for certifications
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <Card className="hover:shadow-md transition-shadow">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="p-3 rounded-lg bg-green-500 text-white">
                  <CheckCircle className="h-6 w-6" />
                </div>
                <div className="text-2xl font-bold text-green-600">12</div>
              </div>
              <div className="text-sm text-gray-600">Active Workflows</div>
            </CardContent>
          </Card>

          <Card className="hover:shadow-md transition-shadow">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="p-3 rounded-lg bg-blue-500 text-white">
                  <Clock className="h-6 w-6" />
                </div>
                <div className="text-2xl font-bold text-blue-600">47h</div>
              </div>
              <div className="text-sm text-gray-600">Study Hours This Month</div>
            </CardContent>
          </Card>

          <Card className="hover:shadow-md transition-shadow">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="p-3 rounded-lg bg-purple-500 text-white">
                  <Target className="h-6 w-6" />
                </div>
                <div className="text-2xl font-bold text-purple-600">85%</div>
              </div>
              <div className="text-sm text-gray-600">Average Readiness Score</div>
            </CardContent>
          </Card>

          <Card className="hover:shadow-md transition-shadow">
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="p-3 rounded-lg bg-orange-500 text-white">
                  <CheckCircle className="h-6 w-6" />
                </div>
                <div className="text-2xl font-bold text-orange-600">7</div>
              </div>
              <div className="text-sm text-gray-600">Completed This Year</div>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle>Active Preparation Workflows</CardTitle>
              <CardDescription>Your current certification preparation workflows</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="p-4 bg-green-50 rounded-lg">
                <div className="flex justify-between items-start mb-3">
                  <div>
                    <h3 className="font-semibold text-green-900">AWS Solutions Architect Professional</h3>
                    <p className="text-sm text-green-700">Phase 3: Hands-on Labs & Practice Exams</p>
                  </div>
                  <Badge className="bg-green-100 text-green-700">78% Complete</Badge>
                </div>
                <Progress value={78} className="h-2 mb-2" />
                <div className="text-sm text-green-600">Next: Advanced Networking Scenarios</div>
              </div>

              <div className="p-4 bg-blue-50 rounded-lg">
                <div className="flex justify-between items-start mb-3">
                  <div>
                    <h3 className="font-semibold text-blue-900">Kubernetes Administrator (CKA)</h3>
                    <p className="text-sm text-blue-700">Phase 2: Cluster Management & Troubleshooting</p>
                  </div>
                  <Badge className="bg-blue-100 text-blue-700">56% Complete</Badge>
                </div>
                <Progress value={56} className="h-2 mb-2" />
                <div className="text-sm text-blue-600">Next: Storage & Volume Management</div>
              </div>

              <div className="p-4 bg-purple-50 rounded-lg">
                <div className="flex justify-between items-start mb-3">
                  <div>
                    <h3 className="font-semibold text-purple-900">CISSP Security Professional</h3>
                    <p className="text-sm text-purple-700">Phase 1: Domain Knowledge Foundation</p>
                  </div>
                  <Badge className="bg-purple-100 text-purple-700">23% Complete</Badge>
                </div>
                <Progress value={23} className="h-2 mb-2" />
                <div className="text-sm text-purple-600">Next: Asset Security & Data Classification</div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Workflow Performance Metrics</CardTitle>
              <CardDescription>Your preparation efficiency and progress analytics</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="text-center p-3 bg-green-50 rounded-lg">
                  <div className="text-2xl font-bold text-green-600">87%</div>
                  <div className="text-sm text-green-700">On-Track Rate</div>
                </div>
                <div className="text-center p-3 bg-blue-50 rounded-lg">
                  <div className="text-2xl font-bold text-blue-600">6.8h</div>
                  <div className="text-sm text-blue-700">Weekly Study Time</div>
                </div>
                <div className="text-center p-3 bg-purple-50 rounded-lg">
                  <div className="text-2xl font-bold text-purple-600">92%</div>
                  <div className="text-sm text-purple-700">Milestone Hit Rate</div>
                </div>
                <div className="text-center p-3 bg-orange-50 rounded-lg">
                  <div className="text-2xl font-bold text-orange-600">4.6</div>
                  <div className="text-sm text-orange-700">Months Avg Duration</div>
                </div>
              </div>

              <div className="space-y-3">
                <div>
                  <div className="flex justify-between items-center mb-1">
                    <span className="text-sm font-medium">Study Consistency</span>
                    <span className="text-sm text-green-600">89%</span>
                  </div>
                  <Progress value={89} className="h-2" />
                </div>

                <div>
                  <div className="flex justify-between items-center mb-1">
                    <span className="text-sm font-medium">Workflow Adherence</span>
                    <span className="text-sm text-blue-600">94%</span>
                  </div>
                  <Progress value={94} className="h-2" />
                </div>

                <div>
                  <div className="flex justify-between items-center mb-1">
                    <span className="text-sm font-medium">Practice Test Performance</span>
                    <span className="text-sm text-purple-600">82%</span>
                  </div>
                  <Progress value={82} className="h-2" />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Recommended Preparation Workflows</CardTitle>
            <CardDescription>Structured certification preparation paths optimized for success</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              <div className="p-4 border border-green-200 rounded-lg hover:shadow-md transition-shadow">
                <div className="flex items-center gap-3 mb-3">
                  <div className="w-10 h-10 bg-green-500 rounded-lg flex items-center justify-center">
                    <CheckCircle className="h-5 w-5 text-white" />
                  </div>
                  <div>
                    <h3 className="font-semibold">Cloud Security Specialist</h3>
                    <p className="text-sm text-gray-600">Azure Security + AWS Security</p>
                  </div>
                </div>
                <div className="space-y-2 mb-4">
                  <div className="flex justify-between text-sm">
                    <span>Duration</span>
                    <span className="font-medium">6-8 months</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span>Study Hours/Week</span>
                    <span className="font-medium">8-12 hours</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span>Success Rate</span>
                    <span className="font-medium text-green-600">89%</span>
                  </div>
                </div>
                <Button className="w-full bg-green-600 hover:bg-green-700">Start Workflow</Button>
              </div>

              <div className="p-4 border border-blue-200 rounded-lg hover:shadow-md transition-shadow">
                <div className="flex items-center gap-3 mb-3">
                  <div className="w-10 h-10 bg-blue-500 rounded-lg flex items-center justify-center">
                    <Target className="h-5 w-5 text-white" />
                  </div>
                  <div>
                    <h3 className="font-semibold">DevOps Engineering Path</h3>
                    <p className="text-sm text-gray-600">Docker + Kubernetes + Jenkins</p>
                  </div>
                </div>
                <div className="space-y-2 mb-4">
                  <div className="flex justify-between text-sm">
                    <span>Duration</span>
                    <span className="font-medium">4-6 months</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span>Study Hours/Week</span>
                    <span className="font-medium">10-15 hours</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span>Success Rate</span>
                    <span className="font-medium text-green-600">92%</span>
                  </div>
                </div>
                <Button className="w-full bg-blue-600 hover:bg-blue-700">Start Workflow</Button>
              </div>

              <div className="p-4 border border-purple-200 rounded-lg hover:shadow-md transition-shadow">
                <div className="flex items-center gap-3 mb-3">
                  <div className="w-10 h-10 bg-purple-500 rounded-lg flex items-center justify-center">
                    <Workflow className="h-5 w-5 text-white" />
                  </div>
                  <div>
                    <h3 className="font-semibold">Data Science Mastery</h3>
                    <p className="text-sm text-gray-600">Python + ML + Deep Learning</p>
                  </div>
                </div>
                <div className="space-y-2 mb-4">
                  <div className="flex justify-between text-sm">
                    <span>Duration</span>
                    <span className="font-medium">8-12 months</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span>Study Hours/Week</span>
                    <span className="font-medium">12-18 hours</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span>Success Rate</span>
                    <span className="font-medium text-green-600">85%</span>
                  </div>
                </div>
                <Button className="w-full bg-purple-600 hover:bg-purple-700">Start Workflow</Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </PlatformLayout>
  );
}