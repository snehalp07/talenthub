import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import PlatformLayout from "@/components/layout/platform-layout";
import { candidateNavigation } from "@/config/complete-navigation";
import { 
  Trophy, Star, Award, Medal, Crown, Target, Zap,
  Calendar, Clock, TrendingUp, CheckCircle, Users,
  Code, Brain, Rocket, Shield, Flame, Gift
} from "lucide-react";

const InterviewAchievements: React.FC = () => {
  const [selectedCategory, setSelectedCategory] = useState('all');

  const achievements = [
    {
      id: 1,
      title: "First Interview Success",
      description: "Complete your first mock interview with a passing score",
      category: "milestone",
      icon: Trophy,
      earned: true,
      earnedDate: "2024-01-15",
      rarity: "common",
      points: 100,
      progress: 100
    },
    {
      id: 2,
      title: "React Master",
      description: "Score 90+ on 3 consecutive React interviews",
      category: "technical",
      icon: Code,
      earned: true,
      earnedDate: "2024-01-20",
      rarity: "rare",
      points: 500,
      progress: 100
    },
    {
      id: 3,
      title: "Communication Expert",
      description: "Receive perfect behavioral assessment scores 5 times",
      category: "behavioral",
      icon: Users,
      earned: true,
      earnedDate: "2024-01-25",
      rarity: "epic",
      points: 750,
      progress: 100
    },
    {
      id: 4,
      title: "Speed Runner",
      description: "Complete a coding challenge in under 15 minutes",
      category: "performance",
      icon: Zap,
      earned: true,
      earnedDate: "2024-01-10",
      rarity: "rare",
      points: 300,
      progress: 100
    },
    {
      id: 5,
      title: "System Design Guru",
      description: "Excel in 5 system design interviews",
      category: "technical",
      icon: Brain,
      earned: false,
      earnedDate: null,
      rarity: "legendary",
      points: 1000,
      progress: 60
    },
    {
      id: 6,
      title: "Consistency Champion",
      description: "Practice interviews for 30 consecutive days",
      category: "consistency",
      icon: Flame,
      earned: false,
      earnedDate: null,
      rarity: "epic",
      points: 800,
      progress: 73
    },
    {
      id: 7,
      title: "Full-Stack Hero",
      description: "Pass frontend, backend, and database interviews",
      category: "milestone",
      icon: Crown,
      earned: false,
      earnedDate: null,
      rarity: "legendary",
      points: 1200,
      progress: 67
    },
    {
      id: 8,
      title: "Perfect Week",
      description: "Score 100% on all interviews in a single week",
      category: "performance",
      icon: Star,
      earned: false,
      earnedDate: null,
      rarity: "epic",
      points: 600,
      progress: 43
    }
  ];

  const categories = [
    { id: 'all', name: 'All Achievements', count: achievements.length },
    { id: 'milestone', name: 'Milestones', count: achievements.filter(a => a.category === 'milestone').length },
    { id: 'technical', name: 'Technical', count: achievements.filter(a => a.category === 'technical').length },
    { id: 'behavioral', name: 'Behavioral', count: achievements.filter(a => a.category === 'behavioral').length },
    { id: 'performance', name: 'Performance', count: achievements.filter(a => a.category === 'performance').length },
    { id: 'consistency', name: 'Consistency', count: achievements.filter(a => a.category === 'consistency').length }
  ];

  const stats = {
    totalPoints: achievements.filter(a => a.earned).reduce((sum, a) => sum + a.points, 0),
    totalEarned: achievements.filter(a => a.earned).length,
    totalAvailable: achievements.length,
    currentLevel: 12,
    nextLevelPoints: 3500,
    currentLevelPoints: 2650
  };

  const getRarityColor = (rarity: string) => {
    switch (rarity) {
      case 'common': return 'text-gray-600 bg-gray-100 border-gray-300';
      case 'rare': return 'text-blue-600 bg-blue-100 border-blue-300';
      case 'epic': return 'text-purple-600 bg-purple-100 border-purple-300';
      case 'legendary': return 'text-yellow-600 bg-yellow-100 border-yellow-300';
      default: return 'text-gray-600 bg-gray-100 border-gray-300';
    }
  };

  const getRarityIcon = (rarity: string) => {
    switch (rarity) {
      case 'common': return Medal;
      case 'rare': return Award;
      case 'epic': return Crown;
      case 'legendary': return Trophy;
      default: return Medal;
    }
  };

  const filteredAchievements = selectedCategory === 'all' 
    ? achievements 
    : achievements.filter(a => a.category === selectedCategory);

  return (
    <PlatformLayout
      sidebarTitle="Candidate Platform"
      sidebarSubtitle="Interview Preparation"
      sidebarSections={candidateNavigation}
    >
      <div className="min-h-screen bg-gradient-to-br from-yellow-50 via-white to-orange-50 p-6">
        <div className="max-w-7xl mx-auto space-y-8">
          {/* Header */}
          <div className="text-center space-y-4">
            <div className="inline-flex items-center space-x-2 bg-yellow-100 text-yellow-800 px-4 py-2 rounded-full text-sm font-medium">
              <Trophy className="h-4 w-4" />
              <span>Interview Achievement System</span>
            </div>
            <h1 className="text-4xl font-bold text-gray-900">Your Interview Achievements</h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Unlock achievements as you progress through your interview preparation journey
            </p>
          </div>

          {/* Stats Overview */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <Card className="bg-gradient-to-r from-yellow-400 to-yellow-500 text-white">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-yellow-100">Total Points</p>
                    <p className="text-3xl font-bold">{stats.totalPoints.toLocaleString()}</p>
                  </div>
                  <Star className="h-12 w-12 text-yellow-200" />
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-r from-green-400 to-green-500 text-white">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-green-100">Achievements</p>
                    <p className="text-3xl font-bold">{stats.totalEarned}/{stats.totalAvailable}</p>
                  </div>
                  <Trophy className="h-12 w-12 text-green-200" />
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-r from-purple-400 to-purple-500 text-white">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-purple-100">Current Level</p>
                    <p className="text-3xl font-bold">{stats.currentLevel}</p>
                  </div>
                  <Crown className="h-12 w-12 text-purple-200" />
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-r from-blue-400 to-blue-500 text-white">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-blue-100">Progress to Next</p>
                    <p className="text-lg font-bold">{stats.nextLevelPoints - stats.currentLevelPoints} pts</p>
                  </div>
                  <TrendingUp className="h-12 w-12 text-blue-200" />
                </div>
                <Progress 
                  value={(stats.currentLevelPoints / stats.nextLevelPoints) * 100} 
                  className="mt-2 h-2"
                />
              </CardContent>
            </Card>
          </div>

          {/* Category Filter */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Target className="h-5 w-5" />
                <span>Achievement Categories</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-6 gap-4">
                {categories.map((category) => (
                  <Button
                    key={category.id}
                    variant={selectedCategory === category.id ? "default" : "outline"}
                    className={`flex flex-col items-center space-y-1 h-auto p-4 ${
                      selectedCategory === category.id ? 'bg-yellow-600 hover:bg-yellow-700' : ''
                    }`}
                    onClick={() => setSelectedCategory(category.id)}
                  >
                    <span className="font-medium">{category.name}</span>
                    <Badge variant="secondary" className="text-xs">
                      {category.count}
                    </Badge>
                  </Button>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Achievements Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredAchievements.map((achievement) => {
              const IconComponent = achievement.icon;
              const RarityIcon = getRarityIcon(achievement.rarity);
              
              return (
                <Card 
                  key={achievement.id} 
                  className={`relative overflow-hidden transition-all duration-300 hover:shadow-lg ${
                    achievement.earned ? 'bg-gradient-to-br from-yellow-50 to-orange-50' : 'bg-gray-50'
                  }`}
                >
                  {achievement.earned && (
                    <div className="absolute top-4 right-4">
                      <CheckCircle className="h-6 w-6 text-green-500" />
                    </div>
                  )}
                  
                  <CardHeader className="pb-4">
                    <div className="flex items-start space-x-4">
                      <div className={`p-3 rounded-full ${
                        achievement.earned ? 'bg-yellow-100' : 'bg-gray-200'
                      }`}>
                        <IconComponent className={`h-8 w-8 ${
                          achievement.earned ? 'text-yellow-600' : 'text-gray-400'
                        }`} />
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center space-x-2 mb-2">
                          <RarityIcon className="h-4 w-4" />
                          <Badge className={`text-xs ${getRarityColor(achievement.rarity)}`}>
                            {achievement.rarity.charAt(0).toUpperCase() + achievement.rarity.slice(1)}
                          </Badge>
                        </div>
                        <CardTitle className={`text-lg ${
                          achievement.earned ? 'text-gray-900' : 'text-gray-500'
                        }`}>
                          {achievement.title}
                        </CardTitle>
                      </div>
                    </div>
                  </CardHeader>
                  
                  <CardContent className="pt-0">
                    <p className={`text-sm mb-4 ${
                      achievement.earned ? 'text-gray-700' : 'text-gray-500'
                    }`}>
                      {achievement.description}
                    </p>
                    
                    <div className="space-y-3">
                      <div className="flex justify-between items-center">
                        <span className="text-sm font-medium">Points</span>
                        <span className={`font-bold ${
                          achievement.earned ? 'text-yellow-600' : 'text-gray-400'
                        }`}>
                          {achievement.points.toLocaleString()}
                        </span>
                      </div>
                      
                      {achievement.earned ? (
                        <div className="flex items-center space-x-2 text-sm text-green-600">
                          <Calendar className="h-4 w-4" />
                          <span>Earned on {achievement.earnedDate}</span>
                        </div>
                      ) : (
                        <div className="space-y-2">
                          <div className="flex justify-between items-center">
                            <span className="text-sm font-medium">Progress</span>
                            <span className="text-sm text-gray-600">{achievement.progress}%</span>
                          </div>
                          <Progress value={achievement.progress} className="h-2" />
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>

          {/* Recent Activity */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Clock className="h-5 w-5" />
                <span>Recent Achievement Activity</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {achievements
                  .filter(a => a.earned)
                  .sort((a, b) => new Date(b.earnedDate!).getTime() - new Date(a.earnedDate!).getTime())
                  .slice(0, 3)
                  .map((achievement) => {
                    const IconComponent = achievement.icon;
                    return (
                      <div key={achievement.id} className="flex items-center space-x-4 p-4 bg-yellow-50 rounded-lg">
                        <div className="p-2 bg-yellow-100 rounded-full">
                          <IconComponent className="h-5 w-5 text-yellow-600" />
                        </div>
                        <div className="flex-1">
                          <h4 className="font-medium text-gray-900">{achievement.title}</h4>
                          <p className="text-sm text-gray-600">Earned {achievement.points} points</p>
                        </div>
                        <div className="text-right">
                          <Badge className={getRarityColor(achievement.rarity)}>
                            {achievement.rarity}
                          </Badge>
                          <p className="text-xs text-gray-500 mt-1">{achievement.earnedDate}</p>
                        </div>
                      </div>
                    );
                  })}
              </div>
            </CardContent>
          </Card>

          {/* Achievement Tips */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Rocket className="h-5 w-5" />
                  <span>Next Achievements</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {achievements
                  .filter(a => !a.earned && a.progress > 50)
                  .slice(0, 3)
                  .map((achievement) => (
                    <div key={achievement.id} className="flex items-center space-x-3 p-3 bg-blue-50 rounded-lg">
                      <Target className="h-5 w-5 text-blue-600" />
                      <div className="flex-1">
                        <div className="font-medium text-sm">{achievement.title}</div>
                        <div className="text-xs text-gray-600">{achievement.progress}% complete</div>
                      </div>
                    </div>
                  ))}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Gift className="h-5 w-5" />
                  <span>Achievement Benefits</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-center space-x-3 p-3 bg-green-50 rounded-lg">
                  <Shield className="h-5 w-5 text-green-600" />
                  <div>
                    <div className="font-medium text-sm">Profile Badges</div>
                    <div className="text-xs text-gray-600">Display achievements on your profile</div>
                  </div>
                </div>
                <div className="flex items-center space-x-3 p-3 bg-purple-50 rounded-lg">
                  <Star className="h-5 w-5 text-purple-600" />
                  <div>
                    <div className="font-medium text-sm">Skill Recognition</div>
                    <div className="text-xs text-gray-600">Employers can see your achievements</div>
                  </div>
                </div>
                <div className="flex items-center space-x-3 p-3 bg-orange-50 rounded-lg">
                  <Trophy className="h-5 w-5 text-orange-600" />
                  <div>
                    <div className="font-medium text-sm">Leaderboard Rankings</div>
                    <div className="text-xs text-gray-600">Compete with other candidates</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </PlatformLayout>
  );
};

export default InterviewAchievements;