import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { 
  Users, 
  UserCheck, 
  Shield, 
  GraduationCap, 
  ArrowRight, 
  CheckCircle,
  Star,
  Globe,
  Zap,
  Heart,
  Target,
  TrendingUp,
  Building,
  BarChart3,
  Briefcase,
  Handshake
} from "lucide-react";

export default function LandingPage() {
  const platforms = [
    {
      title: "Candidate Platform",
      subtitle: "Your Career Journey",
      description: "Find jobs, take assessments, build skills, and advance your career with AI-powered matching.",
      icon: Users,
      headerColor: "bg-gradient-to-r from-sky-500 to-sky-600",
      borderColor: "border-sky-200",
      textColor: "text-sky-700",
      bgColor: "bg-sky-50",
      href: "/candidate",
      features: ["Job Matching", "Skill Assessments", "Resume Builder", "Interview Prep"]
    },
    {
      title: "Recruiter Platform", 
      subtitle: "Talent Acquisition Hub",
      description: "Source, screen, and hire top talent with comprehensive recruitment management tools.",
      icon: UserCheck,
      headerColor: "bg-gradient-to-r from-teal-500 to-teal-600",
      borderColor: "border-teal-200",
      textColor: "text-teal-700",
      bgColor: "bg-teal-50",
      href: "/recruiter",
      features: ["Candidate Pipeline", "Interview Scheduling", "Bulk Operations", "Analytics"]
    },
    {
      title: "Admin Platform",
      subtitle: "System Administration",
      description: "Manage users, monitor system health, and configure platform settings with full administrative control.",
      icon: Shield,
      headerColor: "bg-gradient-to-r from-indigo-500 to-indigo-600",
      borderColor: "border-indigo-200",
      textColor: "text-indigo-700",
      bgColor: "bg-indigo-50",
      href: "/admin",
      features: ["User Management", "System Health", "Configuration", "Reports"]
    },
    {
      title: "Assessment Platform",
      subtitle: "Testing & Evaluation Hub",
      description: "Comprehensive testing environment with advanced question banks, real-time analytics, and certification management.",
      icon: Target,
      headerColor: "bg-gradient-to-r from-purple-500 to-purple-600",
      borderColor: "border-purple-200",
      textColor: "text-purple-700",
      bgColor: "bg-purple-50",
      href: "/assessment",
      features: ["Test Creation", "Question Banks", "Real-time Analytics", "Certification Management"]
    },
    {
      title: "LMS Platform",
      subtitle: "Learning Management System",
      description: "Create, deliver, and track learning experiences with comprehensive course management.",
      icon: GraduationCap,
      headerColor: "bg-gradient-to-r from-emerald-500 to-emerald-600",
      borderColor: "border-emerald-200",
      textColor: "text-emerald-700",
      bgColor: "bg-emerald-50",
      href: "/lms",
      features: ["Course Creation", "Progress Tracking", "Certifications", "Analytics"]
    },
    {
      title: "Organization Management",
      subtitle: "Multi-Tenant Administration",
      description: "Comprehensive organizational control for enterprises, universities, and certification bodies.",
      icon: Building,
      headerColor: "bg-gradient-to-r from-orange-500 to-orange-600",
      borderColor: "border-orange-200",
      textColor: "text-orange-700",
      bgColor: "bg-orange-50",
      href: "/organization",
      features: ["Multi-Tenant Control", "Role Management", "Department Structure", "Specialized Workflows"]
    }
  ];

  const stats = [
    { label: "Active Users", value: "12,847", icon: Users },
    { label: "Companies", value: "247", icon: Globe },
    { label: "Job Placements", value: "3,456", icon: Target },
    { label: "Success Rate", value: "94%", icon: TrendingUp }
  ];

  const testimonials = [
    {
      quote: "TalentHub transformed our hiring process. We found quality candidates 60% faster.",
      author: "Sarah Chen",
      role: "Head of Talent, TechCorp",
      rating: 5
    },
    {
      quote: "The learning platform helped me transition to a tech career in just 6 months.",
      author: "Michael Rodriguez", 
      role: "Software Developer",
      rating: 5
    },
    {
      quote: "Best recruitment platform we've used. The analytics are incredibly detailed.",
      author: "Priya Patel",
      role: "HR Director, Global Systems",
      rating: 5
    }
  ];

  return (
    <div className="min-h-screen bg-neutral-50">
      {/* Header */}
      <header className="bg-white border-b border-neutral-200">
        <div className="max-w-7xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-gradient-to-r from-blue-500 to-purple-600 rounded-lg flex items-center justify-center">
                <Heart className="h-6 w-6 text-white" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-neutral-600">TalentHub</h1>
                <p className="text-sm text-neutral-500">Integrated SaaS Platform</p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <Badge className="bg-green-100 text-green-600">All Platforms Active</Badge>
              <div className="text-sm text-neutral-500">Development Mode</div>
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="py-20 bg-gradient-to-br from-sky-50 via-white to-blue-50 relative overflow-hidden">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            {/* Hero Content */}
            <div className="text-left">
              <div className="mb-8">
                <Badge className="bg-sky-100 text-sky-700 border-sky-200 mb-6 px-4 py-2">
                  🚀 Trusted by 247+ Companies
                </Badge>
                <h2 className="text-5xl lg:text-6xl font-bold text-gray-900 mb-6 leading-tight">
                  Complete Talent Management
                  <span className="block text-transparent bg-clip-text bg-gradient-to-r from-sky-600 via-blue-600 to-indigo-600">
                    Ecosystem
                  </span>
                </h2>
                <p className="text-xl text-gray-600 mb-8 max-w-2xl leading-relaxed">
                  Unite recruitment, learning, and talent management in one comprehensive SaaS platform. 
                  Intelligently designed for candidates, recruiters, administrators, and educators with AI-powered insights.
                </p>
                
                {/* CTA Buttons */}
                <div className="flex flex-col sm:flex-row gap-4 mb-8">
                  <Link href="/candidate">
                    <Button className="bg-sky-600 hover:bg-sky-700 text-white font-semibold py-4 px-8 rounded-xl shadow-lg hover:shadow-xl transform hover:scale-105 transition-all duration-300 text-lg tracking-wide">
                      Start Your Journey
                      <ArrowRight className="w-5 h-5 ml-2" />
                    </Button>
                  </Link>
                  <Link href="/recruiter">
                    <Button variant="outline" className="border-2 border-sky-600 text-sky-600 hover:bg-sky-600 hover:text-white font-semibold py-4 px-8 rounded-xl shadow-md hover:shadow-lg transform hover:scale-105 transition-all duration-300 text-lg">
                      For Recruiters
                    </Button>
                  </Link>
                </div>
                
                {/* Trust Indicators */}
                <div className="flex items-center space-x-6 text-sm text-gray-500">
                  <div className="flex items-center space-x-2">
                    <CheckCircle className="w-5 h-5 text-green-500" />
                    <span>94% Success Rate</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <CheckCircle className="w-5 h-5 text-green-500" />
                    <span>12,847+ Active Users</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <CheckCircle className="w-5 h-5 text-green-500" />
                    <span>3,456+ Placements</span>
                  </div>
                </div>
              </div>
            </div>
            
            {/* Hero Image */}
            <div className="relative">
              <div className="relative bg-white rounded-2xl shadow-2xl p-8 border border-gray-100">
                {/* Enhanced Professional Team Leadership Photo */}
                <div className="relative group overflow-hidden rounded-2xl">
                  {/* Main Image with Hover Zoom Effect */}
                  <img 
                    src="https://images.unsplash.com/photo-1600880292203-757bb62b4baf?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=800&h=600" 
                    alt="Professional woman leading diverse team meeting - talent management platform" 
                    className="w-full h-96 object-cover transition-transform duration-700 group-hover:scale-105 shadow-2xl"
                  />
                  
                  {/* Dynamic Gradient Overlay */}
                  <div className="absolute inset-0 bg-gradient-to-r from-sky-600/20 via-purple-600/10 to-blue-600/20 opacity-60"></div>
                  
                  {/* Floating Professional Icons */}
                  <div className="absolute top-8 left-8 w-12 h-12 bg-white/90 rounded-full flex items-center justify-center shadow-lg animate-bounce delay-100">
                    <Briefcase className="w-6 h-6 text-sky-600" />
                  </div>
                  <div className="absolute top-16 right-12 w-10 h-10 bg-white/90 rounded-full flex items-center justify-center shadow-lg animate-bounce delay-300">
                    <BarChart3 className="w-5 h-5 text-purple-600" />
                  </div>
                  <div className="absolute bottom-20 left-12 w-11 h-11 bg-white/90 rounded-full flex items-center justify-center shadow-lg animate-bounce delay-500">
                    <Handshake className="w-5 h-5 text-green-600" />
                  </div>
                  
                  {/* Interactive Statistics Cards */}
                  <div className="absolute top-4 right-4 bg-white/95 px-4 py-3 rounded-xl shadow-lg backdrop-blur-sm transform hover:scale-105 transition-all duration-300">
                    <div className="text-center">
                      <div className="text-2xl font-bold text-sky-600">50K+</div>
                      <div className="text-xs text-gray-700 font-medium">Professionals Hired</div>
                    </div>
                  </div>
                  
                  <div className="absolute bottom-4 left-4 bg-gradient-to-r from-green-500 to-emerald-600 text-white px-4 py-3 rounded-xl shadow-lg backdrop-blur-sm transform hover:scale-105 transition-all duration-300">
                    <div className="flex items-center space-x-2">
                      <TrendingUp className="w-5 h-5 animate-pulse" />
                      <div>
                        <div className="text-lg font-bold">94%</div>
                        <div className="text-xs opacity-90">Success Rate</div>
                      </div>
                    </div>
                  </div>
                  
                  <div className="absolute bottom-4 right-4 bg-gradient-to-r from-purple-500 to-indigo-600 text-white px-4 py-3 rounded-xl shadow-lg backdrop-blur-sm transform hover:scale-105 transition-all duration-300">
                    <div className="flex items-center space-x-2">
                      <Building className="w-5 h-5" />
                      <div>
                        <div className="text-lg font-bold">500+</div>
                        <div className="text-xs opacity-90">Companies</div>
                      </div>
                    </div>
                  </div>
                  
                  {/* Leadership Badge */}
                  <div className="absolute top-4 left-4 bg-gradient-to-r from-sky-500 to-blue-600 text-white px-4 py-2 rounded-full shadow-lg backdrop-blur-sm">
                    <div className="flex items-center space-x-2">
                      <Star className="w-4 h-4 animate-pulse" />
                      <span className="text-sm font-bold">Leadership Excellence</span>
                    </div>
                  </div>
                  
                  {/* Interactive Team Member Highlights */}
                  <div className="absolute inset-0 opacity-0 hover:opacity-100 transition-opacity duration-500">
                    <div className="absolute top-1/3 left-1/4 w-3 h-3 bg-sky-400 rounded-full animate-ping"></div>
                    <div className="absolute top-1/2 right-1/3 w-3 h-3 bg-purple-400 rounded-full animate-ping delay-200"></div>
                    <div className="absolute bottom-1/3 left-1/3 w-3 h-3 bg-green-400 rounded-full animate-ping delay-400"></div>
                  </div>
                  
                  {/* Social Proof Company Logos */}
                  <div className="absolute bottom-16 left-1/2 transform -translate-x-1/2 bg-white/95 px-6 py-2 rounded-full shadow-lg backdrop-blur-sm">
                    <div className="flex items-center space-x-4">
                      <div className="text-xs text-gray-600 font-medium">Trusted by:</div>
                      <div className="flex space-x-3">
                        <div className="w-6 h-6 bg-gray-300 rounded-sm opacity-70"></div>
                        <div className="w-6 h-6 bg-gray-300 rounded-sm opacity-70"></div>
                        <div className="w-6 h-6 bg-gray-300 rounded-sm opacity-70"></div>
                      </div>
                    </div>
                  </div>
                </div>
                
                {/* Platform Integration Visualization */}
                <div className="grid grid-cols-2 gap-4">
                  <div className="bg-gradient-to-r from-sky-50 to-blue-50 p-4 rounded-lg border border-sky-100">
                    <div className="flex items-center space-x-3">
                      <div className="w-10 h-10 bg-sky-600 rounded-lg flex items-center justify-center">
                        <Users className="w-5 h-5 text-white" />
                      </div>
                      <div>
                        <div className="font-semibold text-gray-800 text-sm">Candidates</div>
                        <div className="text-xs text-gray-600">Career Growth</div>
                      </div>
                    </div>
                  </div>
                  <div className="bg-gradient-to-r from-purple-50 to-indigo-50 p-4 rounded-lg border border-purple-100">
                    <div className="flex items-center space-x-3">
                      <div className="w-10 h-10 bg-purple-600 rounded-lg flex items-center justify-center">
                        <UserCheck className="w-5 h-5 text-white" />
                      </div>
                      <div>
                        <div className="font-semibold text-gray-800 text-sm">Recruiters</div>
                        <div className="text-xs text-gray-600">Talent Acquisition</div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              
              {/* Floating Stats */}
              <div className="absolute -top-6 -right-6 bg-white rounded-xl shadow-xl p-4 border border-gray-100">
                <div className="text-center">
                  <div className="text-2xl font-bold text-sky-600">94%</div>
                  <div className="text-xs text-gray-600">Success Rate</div>
                </div>
              </div>
              
              <div className="absolute -bottom-6 -left-6 bg-white rounded-xl shadow-xl p-4 border border-gray-100">
                <div className="text-center">
                  <div className="text-2xl font-bold text-green-600">3.4k+</div>
                  <div className="text-xs text-gray-600">Placements</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Platform Cards */}
      <section className="py-20 bg-gradient-to-b from-sky-50 via-blue-50 to-sky-100 relative overflow-hidden">
        {/* Decorative background elements */}
        <div className="absolute inset-0 opacity-30">
          <div className="absolute top-10 left-10 w-72 h-72 bg-sky-200 rounded-full blur-3xl"></div>
          <div className="absolute bottom-10 right-10 w-96 h-96 bg-blue-200 rounded-full blur-3xl"></div>
        </div>
        
        <div className="max-w-7xl mx-auto px-6 relative z-10">
          <div className="text-center mb-16">
            <h3 className="text-4xl font-bold text-sky-800 mb-4">Choose Your Platform</h3>
            <p className="text-lg text-sky-700 max-w-2xl mx-auto">
              Access specialized tools designed for your role. Each platform is optimized for specific workflows and user needs.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {platforms.map((platform, index) => (
              <Card key={index} className={`card-hover shadow-xl border-2 ${platform.borderColor} group rounded-2xl overflow-hidden bg-white hover:shadow-2xl transition-all duration-500 transform hover:-translate-y-2`}>
                <CardHeader className={`${platform.headerColor} relative overflow-hidden p-6`}>
                  <div className="flex items-center space-x-4 relative z-10">
                    <div className="w-12 h-12 bg-white/20 backdrop-blur-sm rounded-xl flex items-center justify-center shadow-lg">
                      <platform.icon className="w-6 h-6 text-white" />
                    </div>
                    <div className="flex-1">
                      <CardTitle className="text-xl text-white font-bold">{platform.title}</CardTitle>
                      <CardDescription className="text-white/90 font-medium">
                        {platform.subtitle}
                      </CardDescription>
                    </div>
                  </div>
                  {/* Subtle pattern overlay */}
                  <div className="absolute inset-0 opacity-10">
                    <div className="w-full h-full bg-gradient-to-br from-white/20 to-transparent"></div>
                  </div>
                </CardHeader>
                <CardContent className="p-6 bg-white">
                  <p className="text-gray-600 mb-6 leading-relaxed">{platform.description}</p>
                  
                  <div className="space-y-3 mb-6">
                    {platform.features.map((feature, featureIndex) => (
                      <div key={featureIndex} className="flex items-center space-x-3">
                        <div className={`w-5 h-5 ${platform.headerColor} rounded-full flex items-center justify-center`}>
                          <CheckCircle className="w-3 h-3 text-white" />
                        </div>
                        <span className="text-sm text-gray-600 font-medium">{feature}</span>
                      </div>
                    ))}
                  </div>

                  <Link href={platform.href}>
                    <Button className={`w-full ${platform.headerColor} hover:shadow-xl text-white font-semibold py-3 px-6 rounded-xl shadow-lg transform hover:scale-105 transition-all duration-300 border-0 text-base tracking-wide`}>
                      <platform.icon className="w-4 h-4 mr-2" />
                      Access Platform
                      <ArrowRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform" />
                    </Button>
                  </Link>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center mb-16">
            <h3 className="text-3xl font-bold text-neutral-600 mb-4">Why Choose TalentHub?</h3>
            <p className="text-lg text-neutral-500 max-w-2xl mx-auto">
              Built with modern SaaS principles, our platform delivers enterprise-grade performance with user-friendly design.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center p-6 bg-white rounded-xl shadow-sm card-hover border border-sky-100">
              <div className="w-16 h-16 bg-sky-100 rounded-xl flex items-center justify-center mx-auto mb-4">
                <Zap className="w-8 h-8 text-sky-600" />
              </div>
              <h4 className="text-xl font-semibold text-neutral-600 mb-3">AI-Powered Matching</h4>
              <p className="text-neutral-500">
                Advanced algorithms ensure perfect matches between candidates and opportunities with 95% accuracy.
              </p>
            </div>

            <div className="text-center p-6 bg-white rounded-xl shadow-sm card-hover border border-accent-mint">
              <div className="w-16 h-16 bg-accent-mint rounded-xl flex items-center justify-center mx-auto mb-4">
                <Globe className="w-8 h-8 text-green-600" />
              </div>
              <h4 className="text-xl font-semibold text-neutral-600 mb-3">Multi-Tenant Architecture</h4>
              <p className="text-neutral-500">
                Secure, scalable infrastructure supports thousands of organizations with isolated data and custom branding.
              </p>
            </div>

            <div className="text-center p-6 bg-white rounded-xl shadow-sm card-hover border border-accent-lavender">
              <div className="w-16 h-16 bg-accent-lavender rounded-xl flex items-center justify-center mx-auto mb-4">
                <TrendingUp className="w-8 h-8 text-purple-600" />
              </div>
              <h4 className="text-xl font-semibold text-neutral-600 mb-3">Advanced Analytics</h4>
              <p className="text-neutral-500">
                Comprehensive insights and reporting help optimize recruitment processes and candidate success rates.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-20 bg-gradient-to-r from-sky-50 to-blue-50">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center mb-16">
            <h3 className="text-3xl font-bold text-neutral-600 mb-4">What Our Users Say</h3>
            <p className="text-lg text-neutral-500 max-w-2xl mx-auto">
              Real feedback from professionals who've transformed their careers and organizations with TalentHub.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <Card key={index} className="bg-white shadow-lg border-0 rounded-xl card-hover">
                <CardContent className="p-6">
                  <div className="flex items-center mb-4">
                    {[...Array(testimonial.rating)].map((_, i) => (
                      <Star key={i} className="w-5 h-5 text-yellow-400 fill-current" />
                    ))}
                  </div>
                  <p className="text-neutral-600 mb-6 italic">"{testimonial.quote}"</p>
                  <div className="border-t pt-4">
                    <p className="font-semibold text-neutral-700">{testimonial.author}</p>
                    <p className="text-sm text-neutral-500">{testimonial.role}</p>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-sky-600 to-blue-700">
        <div className="max-w-4xl mx-auto px-6 text-center">
          <h3 className="text-4xl font-bold text-white mb-6">
            Ready to Transform Your Talent Management?
          </h3>
          <p className="text-xl text-sky-100 mb-8 max-w-2xl mx-auto">
            Join thousands of professionals and organizations already using TalentHub to accelerate their success.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/candidate">
              <Button className="bg-white text-sky-600 hover:bg-gray-100 font-semibold py-4 px-8 rounded-xl shadow-lg hover:shadow-xl transform hover:scale-105 transition-all duration-300 text-lg">
                Get Started Free
                <ArrowRight className="w-5 h-5 ml-2" />
              </Button>
            </Link>
            <Link href="/auth">
              <Button className="bg-transparent border-2 border-white text-white hover:bg-white hover:text-sky-600 font-semibold py-4 px-8 rounded-xl shadow-md hover:shadow-lg transform hover:scale-105 transition-all duration-300 text-lg">
                Sign In
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-neutral-800 text-neutral-300 py-12">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
            <div>
              <div className="flex items-center space-x-3 mb-4">
                <div className="w-8 h-8 bg-gradient-to-r from-blue-500 to-purple-600 rounded-lg flex items-center justify-center">
                  <Heart className="h-5 w-5 text-white" />
                </div>
                <h4 className="text-xl font-bold text-white">TalentHub</h4>
              </div>
              <p className="text-sm">
                The comprehensive SaaS platform for modern talent management and professional development.
              </p>
            </div>
            
            <div>
              <h5 className="font-semibold text-white mb-4">Platforms</h5>
              <ul className="space-y-2 text-sm">
                <li><Link href="/candidate" className="hover:text-sky-400 transition-colors">Candidate Platform</Link></li>
                <li><Link href="/recruiter" className="hover:text-sky-400 transition-colors">Recruiter Platform</Link></li>
                <li><Link href="/lms" className="hover:text-sky-400 transition-colors">LMS Platform</Link></li>
                <li><Link href="/admin" className="hover:text-sky-400 transition-colors">Admin Platform</Link></li>
              </ul>
            </div>
            
            <div>
              <h5 className="font-semibold text-white mb-4">Features</h5>
              <ul className="space-y-2 text-sm">
                <li>AI-Powered Matching</li>
                <li>Advanced Analytics</li>
                <li>Multi-Tenant Architecture</li>
                <li>Comprehensive Learning</li>
              </ul>
            </div>
            
            <div>
              <h5 className="font-semibold text-white mb-4">Support</h5>
              <ul className="space-y-2 text-sm">
                <li>Documentation</li>
                <li>API Reference</li>
                <li>Community</li>
                <li>Help Center</li>
              </ul>
            </div>
          </div>
          
          <div className="border-t border-neutral-700 pt-8 flex flex-col md:flex-row justify-between items-center">
            <p className="text-sm">© 2025 TalentHub. All rights reserved.</p>
            <div className="flex items-center space-x-6 text-sm mt-4 md:mt-0">
              <span>Privacy Policy</span>
              <span>Terms of Service</span>
              <span>Contact</span>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}