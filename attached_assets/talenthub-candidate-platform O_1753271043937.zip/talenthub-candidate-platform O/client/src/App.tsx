import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AuthProvider } from "./hooks/use-auth";
import { NavigationProvider } from "./contexts/navigation-context";
import { ProtectedRoute } from "./lib/protected-route";
import LandingPage from "@/pages/landing-page";
import Dashboard from "@/pages/dashboard";
import CandidatePlatform from "@/pages/candidate-platform";
import RecruiterPlatform from "@/pages/recruiter-platform";
import AdminPlatform from "@/pages/admin-platform";
import LMSPlatform from "@/pages/lms-platform";
import AssessmentPlatform from "@/pages/assessment-platform";
import BackupAccess from "@/pages/backup-access";
import AuthPage from "@/pages/auth-page";
import NotFound from "@/pages/not-found";
import ImagePreview from "@/pages/image-preview";

// Candidate Pages
import CandidateHome from "@/pages/candidate/home";
import CandidateDashboard from "@/pages/candidate/dashboard";

import JobBoard from "@/pages/candidate/job-board";
import ApplicationTracker from "@/pages/candidate/application-tracker";
import JobAlerts from "@/pages/candidate/job-alerts";
import SavedJobs from "@/pages/candidate/saved-jobs";
import BrowseTests from "@/pages/candidate/browse-tests";
import SkillTests from "@/pages/candidate/skill-tests";
import TestRunner from "@/pages/candidate/test-runner";
import InfographicCV from "@/pages/candidate/infographic-cv";
import VideoCV from "@/pages/candidate/video-cv";
import ResumeTips from "@/pages/candidate/resume-tips";
import AIMockInterviews from "@/pages/candidate/ai-mock-interviews";
import PersonalInterview from "@/pages/candidate/personal-interview";
import CandidateInterviewScheduler from "@/pages/candidate/interview-scheduler";
import InterviewFeedback from "@/pages/candidate/interview-feedback";
import InterviewCommunication from "@/pages/candidate/interview-communication";
import CareerGuidance from "@/pages/candidate/career-guidance";
import MarketTrends from "@/pages/candidate/market-trends";
import PerformanceInsights from "@/pages/candidate/performance-insights";
import Networking from "@/pages/candidate/networking";
import ProfessionalNetwork from "@/pages/candidate/professional-network";
import Blog from "@/pages/candidate/blog";
import ProfessionalVlogs from "@/pages/candidate/professional-vlogs";
import Groups from "@/pages/candidate/groups";
import Forum from "@/pages/candidate/forum";
import EventsMeetups from "@/pages/candidate/events-meetups";
import Mentorship from "@/pages/candidate/mentorship";
import IndustryInsights from "@/pages/candidate/industry-insights";
import Collaboration from "@/pages/candidate/collaboration";
import Alumni from "@/pages/candidate/alumni";
import SkillExchanges from "@/pages/candidate/skill-exchanges";
import Recommendations from "@/pages/candidate/recommendations";
import LinkedInIntegration from "@/pages/candidate/linkedin-integration";
import ProjectAccess from "@/pages/candidate/project-access";
import ProjectEditor from "@/pages/candidate/project-editor";
import ProjectEditorEnhanced from "@/pages/candidate/project-editor-enhanced";
import TestReports from "@/pages/candidate/test-reports";
import OneOnOneSupport from "@/pages/candidate/one-on-one-support";
import PrioritySupport from "@/pages/candidate/priority-support";
import CandidateNotifications from "@/pages/candidate/notifications";
import CandidateSubscription from "@/pages/candidate/subscription";
import AISkillAssessment from "@/pages/candidate/ai-skill-assessment";
import Certifications from "@/pages/candidate/certifications";
import LearningPath from "@/pages/candidate/learning-path";
import CandidateAnalytics from "@/pages/candidate/analytics";
import ProfileBuilder from "@/pages/candidate/profile-builder";
import ProfilePreview from "@/pages/candidate/profile-preview";
import BrowseCertifications from "@/pages/candidate/browse-certifications";
import CertificationTracker from "@/pages/candidate/certification-tracker";
import AILearningPath from "@/pages/candidate/ai-learning-path";
import BlockchainCertificates from "@/pages/candidate/blockchain-certificates";
import MobileApp from "@/pages/candidate/mobile-app";
import Performance from "@/pages/candidate/performance";
import Settings from "@/pages/candidate/settings";
import TestCertificationView from "@/pages/candidate/test-certification-view";
import ProjectCertificationView from "@/pages/candidate/project-certification-view";
import MockInterviewCertificationView from "@/pages/candidate/mock-interview-certification-view";
import TestResults from "@/pages/candidate/test-results";

// Project Portfolio Pages
import ProjectCreator from "@/pages/candidate/project-creator";
import MyProjects from "@/pages/candidate/my-projects";
import ProjectGallery from "@/pages/candidate/project-gallery";
import SampleProjects from "@/pages/candidate/sample-projects";
import ProjectAnalytics from "@/pages/candidate/project-analytics";

// Project Certification Pages
import CertificationTracks from "@/pages/candidate/certification-tracks";
import ProjectChallenges from "@/pages/candidate/project-challenges";
import SubmissionPortal from "@/pages/candidate/submission-portal";
import CertificateGallery from "@/pages/candidate/certificate-gallery";

// AI Project Assistant Pages
import ProjectRecommendations from "@/pages/candidate/project-recommendations";
import CodeAnalysis from "@/pages/candidate/code-analysis";
import ProjectInsights from "@/pages/candidate/project-insights";
import SkillGapAnalysis from "@/pages/candidate/skill-gap-analysis";

// Interview Preparation Enhancement Pages
import TechStackSimulators from "@/pages/candidate/tech-stack-simulators";
import FrontendCertification from "@/pages/candidate/frontend-certification";
import BackendCertification from "@/pages/candidate/backend-certification";
import FullStackCertification from "@/pages/candidate/fullstack-certification";
import DevOpsCertification from "@/pages/candidate/devops-certification";
import DataScienceCertification from "@/pages/candidate/datascience-certification";
import InterviewPerformance from "@/pages/candidate/interview-performance";
import TechProficiency from "@/pages/candidate/tech-proficiency";
import InterviewPatterns from "@/pages/candidate/interview-patterns";
import BehavioralAssessment from "@/pages/candidate/behavioral-assessment";
import PersonalizedPrep from "@/pages/candidate/personalized-prep";
import WeaknessTargeting from "@/pages/candidate/weakness-targeting";
import CompanyPrep from "@/pages/candidate/company-prep";
import RoleScenarios from "@/pages/candidate/role-scenarios";

// Interview Certification Management Pages
import InterviewCertificationDashboard from "@/pages/candidate/interview-certification-dashboard";
import CertificationProgress from "@/pages/candidate/certification-progress";
import InterviewAchievements from "@/pages/candidate/interview-achievements";
import CertificationShowcase from "@/pages/candidate/certification-showcase";
import PracticeHistory from "@/pages/candidate/practice-history";

// Skills Certification Hub Pages
import TestPackageMarketplace from "@/pages/candidate/test-package-marketplace";
import AssessmentTesting from "@/pages/candidate/assessment-testing";
import CertificationWallet from "@/pages/candidate/certification-wallet";

// Global Certification Academy Pages
import GlobalTechCerts from "@/pages/candidate/global-tech-certs";
import PreparationWorkflows from "@/pages/candidate/preparation-workflows";
import PackageLearning from "@/pages/candidate/package-learning";
import AICertRecommendations from "@/pages/candidate/ai-cert-recommendations";
import BlockchainCertManagement from "@/pages/candidate/blockchain-cert-management";

// Billing and Analytics Pages
import BillingAnalytics from "@/pages/candidate/billing-analytics";

// Enhanced Analytics & Insights Pages
import CareerIntelligence from "@/pages/candidate/career-intelligence";
import SkillsAnalytics from "@/pages/candidate/skills-analytics";
import ProfileAnalytics from "@/pages/candidate/profile-analytics";
import JobIntelligence from "@/pages/candidate/job-intelligence";
import InterviewInsights from "@/pages/candidate/interview-insights";
import PortfolioAnalytics from "@/pages/candidate/portfolio-analytics";
import NetworkingInsights from "@/pages/candidate/networking-insights";
import LearningAnalytics from "@/pages/candidate/learning-analytics";
import MarketIntelligence from "@/pages/candidate/market-intelligence";
import PredictiveInsights from "@/pages/candidate/predictive-insights";
import Benchmarking from "@/pages/candidate/benchmarking";

// Recruiter Pages
import RecruiterCandidates from "@/pages/recruiter/candidates";
import RecruiterJobs from "@/pages/recruiter/jobs";
import RecruiterDashboard from "@/pages/recruiter/dashboard";
import TalentIntelligence from "@/pages/recruiter/talent-intelligence";
import AIDiscovery from "@/pages/recruiter/ai-discovery";
import AIcandidateDiscoveryVisual from "@/pages/recruiter/ai-candidate-discovery-visual";
import RecruiterResumeParser from "@/pages/recruiter/resume-parser";
import TalentPool from "@/pages/recruiter/talent-pool";
import CandidateRanking from "@/pages/recruiter/candidate-ranking";
import CampaignManagement from "@/pages/recruiter/campaign-management";
import BulkCVProcessing from "@/pages/recruiter/bulk-cv-processing";
import JobTemplates from "@/pages/recruiter/job-templates";
import JobPublishing from "@/pages/recruiter/job-publishing";
import MultiBoardDistribution from "@/pages/recruiter/multi-board-distribution";
import InterviewPipeline from "@/pages/recruiter/interview-pipeline";
import VideoInterviews from "@/pages/recruiter/video-interviews";
import InterviewScorecards from "@/pages/recruiter/scorecards";
import AIMatching from "@/pages/recruiter/ai-matching";
import AIScreening from "@/pages/recruiter/ai-screening";
import AIInterviewAnalysis from "@/pages/recruiter/ai-interview";
import AIScoring from "@/pages/recruiter/ai-scoring";
import AICommandCenter from "@/pages/recruiter/ai-command";
import RecruiterAnalytics from "@/pages/recruiter/analytics";
import PredictiveHiring from "@/pages/recruiter/predictive";
import RecruiterWorkflowAutomation from "@/pages/recruiter/automation";
import RealtimeAnalytics from "@/pages/recruiter/realtime";
import RecruiterMarketIntelligence from "@/pages/recruiter/market-intelligence";
import MarketIntelligencePage from "@/pages/recruiter/market";
import RecruiterBilling from "@/pages/recruiter/recruiter-billing";
import DiversityMetrics from "@/pages/recruiter/diversity";
import EmailTemplates from "@/pages/recruiter/email-templates";
import BulkOperations from "@/pages/recruiter/bulk-operations";
import CompanyProfile from "@/pages/recruiter/company-profile";
import CandidateExperience from "@/pages/recruiter/candidate-experience";
import BrandAnalytics from "@/pages/recruiter/brand-analytics";
import TeamCollaboration from "@/pages/recruiter/team-collaboration";
import CostAnalytics from "@/pages/recruiter/cost-analytics";
import SuccessPrediction from "@/pages/recruiter/success-prediction";
import RecruiterSubscriptionManagement from "@/pages/recruiter/subscription-management";
import RecruiterSettings from "@/pages/recruiter/settings";

// Job Requirements Labeling System Pages
import JobLabels from "@/pages/recruiter/job-labels";
import CreateLabel from "@/pages/recruiter/create-label";
import LabelManagement from "@/pages/recruiter/label-management";
import CandidateReview from "@/pages/recruiter/candidate-review";

// Recruitment System Pages
import CandidateDatabase from "@/pages/recruiter/candidate-database";
import EmailCampaigns from "@/pages/recruiter/email-campaigns";
import RegistrationForms from "@/pages/recruiter/registration-forms";
import RecruiterInterviewScheduler from "@/pages/recruiter/interview-scheduler";
import OfferManagement from "@/pages/recruiter/offer-management";
import RecruitmentAnalytics from "@/pages/recruiter/recruitment-analytics";
import RegistrationPortal from "@/pages/candidate/registration-portal";
import TestBooking from "@/pages/candidate/test-booking";
import DocumentCenter from "@/pages/candidate/document-center";
import PaymentHistory from "@/pages/candidate/payment-history";
import PaidTestSystem from "@/pages/assessment/paid-test-system";
import RecruitmentConfiguration from "@/pages/admin/recruitment-configuration";
import RecruitmentOversight from "@/pages/admin/recruitment-oversight";
import RecruitmentTesting from "@/pages/assessment/recruitment-testing";
import OrganizationRecruitment from "@/pages/organization-recruitment";

// Organization Management Platform - All Phases
import SkillCompetencyMatrix from "@/pages/organization/skill-matrix";
import CareerProgressionPaths from "@/pages/organization/career-paths";
import PerformanceBenchmarks from "@/pages/organization/benchmarks";
import BudgetResourceTracking from "@/pages/organization/budget-tracking";
import AssessmentTriggerEvents from "@/pages/organization/trigger-events";
import SkillsGapAnalysis from "@/pages/organization/skills-gap";
import ResourceOptimization from "@/pages/organization/resource-optimization";
import WorkflowAutomation from "@/pages/organization/workflow-automation";
import PredictiveAnalytics from "@/pages/organization/predictive-analytics";
import IndustryBenchmarking from "@/pages/organization/industry-benchmarking";
import AdvancedPermissions from "@/pages/organization/advanced-permissions";
import CrossPlatformSync from "@/pages/organization/cross-platform-sync";
import UnifiedUserContext from "@/pages/organization/user-context";
import LearningIntelligence from "@/pages/organization/learning-intelligence";
import MultiTenantIntelligence from "@/pages/organization/multi-tenant-intelligence";
import APIIntegrationHub from "@/pages/organization/api-integration";

// Core Management Pages
import DepartmentStructure from "@/pages/organization/departments";
import OrganizationUserManagement from "@/pages/organization/users";
import OrganizationPlatformSettings from "@/pages/organization/settings";

// New Comprehensive Assessment Platform Pages
import TestCreationStudio from "@/pages/assessment/test-creation";
import TechnicalAssessments from "@/pages/assessment/technical";
import BehavioralAssessments from "@/pages/assessment/behavioral";
import CognitiveAssessments from "@/pages/assessment/cognitive";
import RoleBasedAssessments from "@/pages/assessment/role-based";
import AITestGenerator from "@/pages/assessment/ai-generator";
import SmartProctoring from "@/pages/assessment/smart-proctoring";
import AutoScoring from "@/pages/assessment/auto-scoring";
import AdaptiveTesting from "@/pages/assessment/adaptive-testing";
import TestLibrary from "@/pages/assessment/test-library";
import ActiveTests from "@/pages/assessment/active-tests";
import LearningPaths from "@/pages/assessment/learning-paths";
import StudyMaterials from "@/pages/assessment/study-materials";
import AssessmentSettings from "@/pages/assessment/settings";

// Admin Pages
import AdminTenants from "@/pages/admin/tenants";
import AdminDashboard from "@/pages/admin/dashboard";
import AdminUsers from "@/pages/admin/users";
import BillingOverview from "@/pages/admin/billing-overview";
import APIAnalytics from "@/pages/admin/api-analytics";
import Partners from "@/pages/admin/partners";
import Revenue from "@/pages/admin/revenue";
import APIKeys from "@/pages/admin/api-keys";
import Integrations from "@/pages/admin/integrations";
import AdminOrganizations from "@/pages/admin/organizations";
import PaymentSetup from "@/pages/admin/payment-setup";
import EmailConfig from "@/pages/admin/email-config";
import SecurityCompliance from "@/pages/admin/security-compliance";
import TestCreation from "@/pages/admin/test-creation";
import QuestionBank from "@/pages/admin/question-bank";
import QuestionUpload from "@/pages/admin/question-upload";
import BulkUpload from "@/pages/admin/bulk-upload";
import AdminAssessmentAnalytics from "@/pages/admin/assessment-analytics";
import AIMonitoring from "@/pages/admin/ai-monitoring";
import ContentModeration from "@/pages/admin/content-moderation";
import MediaLibrary from "@/pages/admin/media-library";
import AdminResumeParser from "@/pages/admin/resume-parser";
import SystemMonitoring from "@/pages/admin/system-monitoring";
import DatabaseManagement from "@/pages/admin/database-management";
import AuditLogs from "@/pages/admin/audit-logs";
import FeatureControl from "@/pages/admin/feature-control";
import AdminSubscriptionManagement from "@/pages/admin/subscription-management";
import VerificationQueue from "@/pages/admin/verification-queue";
import BulkScheduling from "@/pages/admin/bulk-scheduling";
import AdminSettings from "@/pages/admin/settings";

// New Admin Pages - Revised Navigation Structure
import AdminLiveDashboard from "@/pages/admin/live-dashboard";
import AdminCandidateControl from "@/pages/admin/candidate-control";
import AdminRecruiterControl from "@/pages/admin/recruiter-control";
import ActiveSessions from "@/pages/admin/active-sessions";
import SystemHealth from "@/pages/admin/system-health";
import EmergencyControls from "@/pages/admin/emergency-controls";
import CrossPlatformAnalytics from "@/pages/admin/cross-platform-analytics";
import FeatureFlags from "@/pages/admin/feature-flags";
import RevenueOptimization from "@/pages/admin/revenue-optimization";
import CreditAnalytics from "@/pages/admin/credit-analytics";
import SubscriptionIntelligence from "@/pages/admin/subscription-intelligence";

// Billing Pages
import BillingDashboard from "@/pages/billing-dashboard";

// LMS Pages
import LMSCourses from "@/pages/lms/courses";
import LMSDashboard from "@/pages/lms/dashboard";
import LMSLibrary from "@/pages/lms/library";
import MyLearning from "@/pages/lms/my-learning";
import LMSVideos from "@/pages/lms/videos";
import LMSPracticeTests from "@/pages/lms/practice-tests";
import LMSAssignments from "@/pages/lms/assignments";
import LMSSettings from "@/pages/lms/settings";
import LMSAnalytics from "@/pages/lms/analytics";

// Assessment Pages
import AssessmentDashboard from "@/pages/assessment/dashboard";
import AssessmentWrapperDashboard from "@/pages/assessment/wrapper-dashboard";
import AssessmentBrowseTests from "@/pages/assessment/browse-tests";
import EnhancedAssessmentTestRunner from "@/pages/assessment/test-runner";
import AssessmentTestResults from "@/pages/assessment/test-results";
import AssessmentQuestionBank from "@/pages/assessment/question-bank";
import AssessmentBulkUpload from "@/pages/assessment/bulk-upload";
import AssessmentCertifications from "@/pages/assessment/certifications";
import AssessmentPlatformAnalytics from "@/pages/assessment/analytics";
import AssessmentOverview from "@/pages/assessment/overview";
import AssessmentUsers from "@/pages/assessment/users";
import AssessmentBlockchainCertificates from "@/pages/assessment/blockchain-certificates";
import AssessmentCourses from "@/pages/assessment/courses";
import AssessmentPracticeTests from "@/pages/assessment/practice-tests";

// Organization Management
import OrganizationManagement from "@/pages/organization-management";

function Router() {
  return (
    <Switch>
      <Route path="/" component={LandingPage} />
      <Route path="/image-preview" component={ImagePreview} />
      
      {/* Candidate Platform Routes */}
      <ProtectedRoute path="/candidate" component={CandidateDashboard} />
      <ProtectedRoute path="/candidate/home" component={CandidateHome} />
      <ProtectedRoute path="/candidate/dashboard" component={CandidateDashboard} />
      <ProtectedRoute path="/candidate/platform" component={CandidatePlatform} />
      
      {/* Job Search & Applications */}
      <ProtectedRoute path="/candidate/job-board" component={JobBoard} />
      <ProtectedRoute path="/candidate/application-tracker" component={ApplicationTracker} />
      <ProtectedRoute path="/candidate/job-alerts" component={JobAlerts} />
      <ProtectedRoute path="/candidate/saved-jobs" component={SavedJobs} />
      <ProtectedRoute path="/candidate/interview-communication" component={InterviewCommunication} />
      
      {/* Skills & Assessment */}
      <Route path="/candidate/skill-tests" component={SkillTests} />
      <Route path="/candidate/browse-tests" component={BrowseTests} />
      <Route path="/candidate/test-runner/:testId" component={TestRunner} />
      <Route path="/candidate/test-results" component={TestResults} />
      <Route path="/candidate/ai-skill-assessment" component={AISkillAssessment} />
      <Route path="/candidate/certifications" component={Certifications} />
      <Route path="/candidate/learning-path" component={LearningPath} />
      
      {/* Advanced Certifications */}
      <Route path="/candidate/browse-certifications" component={BrowseCertifications} />
      <Route path="/candidate/certification-tracker" component={CertificationTracker} />
      <Route path="/candidate/ai-learning-path" component={AILearningPath} />
      <Route path="/candidate/blockchain-certificates" component={BlockchainCertificates} />
      
      {/* Profile & Branding */}
      <Route path="/candidate/profile-builder" component={ProfileBuilder} />
      <Route path="/candidate/profile-preview" component={ProfilePreview} />
      <Route path="/candidate/video-cv" component={VideoCV} />
      <Route path="/candidate/infographic-cv" component={InfographicCV} />
      <Route path="/candidate/resume-tips" component={ResumeTips} />
      
      {/* Interview Preparation */}
      <ProtectedRoute path="/candidate/ai-mock-interviews" component={AIMockInterviews} />
      <ProtectedRoute path="/candidate/personal-interview" component={PersonalInterview} />
      <ProtectedRoute path="/candidate/interview-scheduler" component={CandidateInterviewScheduler} />
      <ProtectedRoute path="/candidate/interview-feedback" component={InterviewFeedback} />
      
      {/* Career Development */}
      <ProtectedRoute path="/candidate/career-guidance" component={CareerGuidance} />
      <ProtectedRoute path="/candidate/market-trends" component={MarketTrends} />
      <ProtectedRoute path="/candidate/performance-insights" component={PerformanceInsights} />
      
      {/* Networking & Community */}
      <ProtectedRoute path="/candidate/professional-network" component={ProfessionalNetwork} />
      <ProtectedRoute path="/candidate/blog" component={Blog} />
      <ProtectedRoute path="/candidate/professional-vlogs" component={ProfessionalVlogs} />
      <ProtectedRoute path="/candidate/groups" component={Groups} />
      <ProtectedRoute path="/candidate/forum" component={Forum} />
      <ProtectedRoute path="/candidate/events-meetups" component={EventsMeetups} />
      <ProtectedRoute path="/candidate/mentorship" component={Mentorship} />
      <ProtectedRoute path="/candidate/industry-insights" component={IndustryInsights} />
      <ProtectedRoute path="/candidate/collaboration" component={Collaboration} />
      <ProtectedRoute path="/candidate/alumni" component={Alumni} />
      <ProtectedRoute path="/candidate/skill-exchanges" component={SkillExchanges} />
      <ProtectedRoute path="/candidate/recommendations" component={Recommendations} />
      <ProtectedRoute path="/candidate/networking" component={Networking} />
      
      {/* Additional Features */}
      <Route path="/candidate/mobile-app" component={MobileApp} />
      <Route path="/candidate/analytics" component={CandidateAnalytics} />
      <Route path="/candidate/settings" component={Settings} />
      
      {/* Certification Views */}
      <Route path="/candidate/test-certification-view" component={TestCertificationView} />
      <Route path="/candidate/project-certification-view" component={ProjectCertificationView} />
      <Route path="/candidate/mock-interview-certification-view" component={MockInterviewCertificationView} />
      
      {/* Project Portfolio Routes */}
      <Route path="/candidate/project-creator" component={ProjectCreator} />
      <Route path="/candidate/my-projects" component={MyProjects} />
      <Route path="/candidate/project-gallery" component={ProjectGallery} />
      <Route path="/candidate/sample-projects" component={SampleProjects} />
      <Route path="/candidate/project-analytics" component={ProjectAnalytics} />

      {/* Project Certification Routes */}
      <Route path="/candidate/certification-tracks" component={CertificationTracks} />
      <Route path="/candidate/project-challenges" component={ProjectChallenges} />
      <Route path="/candidate/submission-portal" component={SubmissionPortal} />
      <Route path="/candidate/certificate-gallery" component={CertificateGallery} />

      {/* AI Project Assistant Routes */}
      <Route path="/candidate/project-recommendations" component={ProjectRecommendations} />
      <Route path="/candidate/code-analysis" component={CodeAnalysis} />
      <Route path="/candidate/project-insights" component={ProjectInsights} />
      <Route path="/candidate/skill-gap-analysis" component={SkillGapAnalysis} />

      {/* Interview Preparation Enhancement Routes */}
      <Route path="/candidate/tech-stack-simulators" component={TechStackSimulators} />
      <Route path="/candidate/interview-certification-dashboard" component={InterviewCertificationDashboard} />
      <Route path="/candidate/frontend-certification" component={FrontendCertification} />
      <Route path="/candidate/backend-certification" component={BackendCertification} />
      <Route path="/candidate/fullstack-certification" component={FullStackCertification} />
      <Route path="/candidate/devops-certification" component={DevOpsCertification} />
      <Route path="/candidate/datascience-certification" component={DataScienceCertification} />
      <Route path="/candidate/interview-performance" component={InterviewPerformance} />
      <Route path="/candidate/tech-proficiency" component={TechProficiency} />
      <Route path="/candidate/interview-patterns" component={InterviewPatterns} />
      <Route path="/candidate/behavioral-assessment" component={BehavioralAssessment} />
      <Route path="/candidate/personalized-prep" component={PersonalizedPrep} />
      <Route path="/candidate/weakness-targeting" component={WeaknessTargeting} />
      <Route path="/candidate/company-prep" component={CompanyPrep} />
      <Route path="/candidate/role-scenarios" component={RoleScenarios} />

      {/* Interview Certification Management Routes */}
      <Route path="/candidate/certification-progress" component={CertificationProgress} />
      <Route path="/candidate/interview-achievements" component={InterviewAchievements} />
      <Route path="/candidate/certification-showcase" component={CertificationShowcase} />
      <Route path="/candidate/practice-history" component={PracticeHistory} />

      {/* Skills Certification Hub Routes */}
      <Route path="/candidate/test-package-marketplace" component={TestPackageMarketplace} />
      <Route path="/candidate/assessment-testing" component={AssessmentTesting} />
      <Route path="/candidate/certification-wallet" component={CertificationWallet} />

      {/* Global Certification Academy Routes */}
      <Route path="/candidate/global-tech-certs" component={GlobalTechCerts} />
      <Route path="/candidate/preparation-workflows" component={PreparationWorkflows} />
      <Route path="/candidate/package-learning" component={PackageLearning} />
      <Route path="/candidate/ai-cert-recommendations" component={AICertRecommendations} />
      <Route path="/candidate/blockchain-cert-management" component={BlockchainCertManagement} />

      {/* Legacy/Additional Routes */}
      <Route path="/candidate/linkedin-integration" component={LinkedInIntegration} />
      <Route path="/candidate/project-access" component={ProjectAccess} />
      <Route path="/candidate/project-editor" component={ProjectEditor} />
      <Route path="/candidate/project-editor-enhanced" component={ProjectEditorEnhanced} />
      <Route path="/candidate/test-reports" component={TestReports} />
      <Route path="/candidate/one-on-one-support" component={OneOnOneSupport} />
      <Route path="/candidate/priority-support" component={PrioritySupport} />
      <Route path="/candidate/notifications" component={CandidateNotifications} />
      <Route path="/candidate/billing-analytics" component={BillingAnalytics} />
      <Route path="/candidate/subscription" component={CandidateSubscription} />
      <Route path="/candidate/performance" component={Performance} />
      
      {/* Enhanced Analytics & Insights Routes */}
      <Route path="/candidate/career-intelligence" component={CareerIntelligence} />
      <Route path="/candidate/skills-analytics" component={SkillsAnalytics} />
      <Route path="/candidate/profile-analytics" component={ProfileAnalytics} />
      <Route path="/candidate/job-intelligence" component={JobIntelligence} />
      <Route path="/candidate/interview-insights" component={InterviewInsights} />
      <Route path="/candidate/portfolio-analytics" component={PortfolioAnalytics} />
      <Route path="/candidate/networking-insights" component={NetworkingInsights} />
      <Route path="/candidate/learning-analytics" component={LearningAnalytics} />
      <Route path="/candidate/market-intelligence" component={MarketIntelligence} />
      <Route path="/candidate/predictive-insights" component={PredictiveInsights} />
      <Route path="/candidate/benchmarking" component={Benchmarking} />
      
      {/* Recruitment Portal Routes */}
      <Route path="/candidate/registration-portal" component={RegistrationPortal} />
      <Route path="/candidate/test-booking" component={TestBooking} />
      <Route path="/candidate/document-center" component={DocumentCenter} />
      <Route path="/candidate/payment-history" component={PaymentHistory} />

      {/* Recruiter Platform Routes */}
      <Route path="/recruiter" component={RecruiterDashboard} />
      <Route path="/recruiter/dashboard" component={RecruiterDashboard} />
      <Route path="/recruiter/platform" component={RecruiterPlatform} />
      <Route path="/recruiter/candidates" component={RecruiterCandidates} />
      <Route path="/recruiter/jobs" component={RecruiterJobs} />
      <Route path="/recruiter/job-templates" component={JobTemplates} />
      <Route path="/recruiter/job-publishing" component={JobPublishing} />
      <Route path="/recruiter/multi-board" component={MultiBoardDistribution} />
      <Route path="/recruiter/talent-intelligence" component={TalentIntelligence} />
      <Route path="/recruiter/ai-discovery" component={AIDiscovery} />
      <Route path="/recruiter/ai-candidate-discovery" component={AIcandidateDiscoveryVisual} />
      <Route path="/recruiter/resume-parser" component={RecruiterResumeParser} />
      <Route path="/recruiter/talent-pool" component={TalentPool} />
      <Route path="/recruiter/candidate-ranking" component={CandidateRanking} />
      
      {/* Recruitment Management Routes */}
      <Route path="/recruiter/campaign-management" component={CampaignManagement} />
      <Route path="/recruiter/bulk-cv-processing" component={BulkCVProcessing} />
      <Route path="/recruiter/candidate-database" component={CandidateDatabase} />
      <Route path="/recruiter/email-campaigns" component={EmailCampaigns} />
      <Route path="/recruiter/registration-forms" component={RegistrationForms} />
      <Route path="/recruiter/interview-scheduler" component={RecruiterInterviewScheduler} />
      <Route path="/recruiter/offer-management" component={OfferManagement} />
      <Route path="/recruiter/recruitment-analytics" component={RecruitmentAnalytics} />
      
      {/* Interview & Assessment Routes */}
      <Route path="/recruiter/interview-pipeline" component={InterviewPipeline} />
      <Route path="/recruiter/video-interviews" component={VideoInterviews} />
      <Route path="/recruiter/scorecards" component={InterviewScorecards} />
      
      {/* AI-Powered Tools Routes */}
      <Route path="/recruiter/ai-matching" component={AIMatching} />
      <Route path="/recruiter/ai-screening" component={AIScreening} />
      <Route path="/recruiter/ai-interview" component={AIInterviewAnalysis} />
      <Route path="/recruiter/ai-scoring" component={AIScoring} />
      <Route path="/recruiter/ai-command" component={AICommandCenter} />
      
      {/* Analytics & Intelligence Routes */}
      <Route path="/recruiter/analytics" component={RecruiterAnalytics} />
      <Route path="/recruiter/predictive" component={PredictiveHiring} />
      <Route path="/recruiter/realtime" component={RealtimeAnalytics} />
      <Route path="/recruiter/market-intelligence" component={RecruiterMarketIntelligence} />
      <Route path="/recruiter/market" component={MarketIntelligencePage} />
      <Route path="/recruiter/diversity" component={DiversityMetrics} />
      
      {/* Automation & Workflow Routes */}
      <Route path="/recruiter/automation" component={WorkflowAutomation} />
      
      {/* Email Communication Routes */}
      <Route path="/recruiter/email-templates" component={EmailTemplates} />
      
      {/* Bulk Operations Routes */}
      <Route path="/recruiter/bulk-operations" component={BulkOperations} />
      
      {/* Company Management Routes */}
      <Route path="/recruiter/company-profile" component={CompanyProfile} />
      <Route path="/recruiter/candidate-experience" component={CandidateExperience} />
      <Route path="/recruiter/brand-analytics" component={BrandAnalytics} />
      <Route path="/recruiter/team-collaboration" component={TeamCollaboration} />
      <Route path="/recruiter/recruiter-billing" component={RecruiterBilling} />
      <Route path="/recruiter/cost-analytics" component={CostAnalytics} />
      <Route path="/recruiter/success-prediction" component={SuccessPrediction} />
      <Route path="/recruiter/subscription-management" component={RecruiterSubscriptionManagement} />
      <Route path="/recruiter/settings" component={RecruiterSettings} />
      
      {/* Job Requirements Labeling System Routes */}
      <Route path="/recruiter/job-labels" component={JobLabels} />
      <Route path="/recruiter/create-label" component={CreateLabel} />
      <Route path="/recruiter/label-management" component={LabelManagement} />
      <Route path="/recruiter/candidate-review" component={CandidateReview} />

      {/* Admin Platform Routes */}
      <Route path="/admin" component={AdminDashboard} />
      <Route path="/admin/dashboard" component={AdminDashboard} />
      <Route path="/admin/platform" component={AdminPlatform} />
      
      {/* Real-Time Command Center */}
      <Route path="/admin/live-dashboard" component={AdminLiveDashboard} />
      <Route path="/admin/active-sessions" component={ActiveSessions} />
      <Route path="/admin/system-health" component={SystemHealth} />
      <Route path="/admin/emergency-controls" component={EmergencyControls} />
      
      {/* Platform Control Hub */}
      <Route path="/admin/candidate-control" component={AdminCandidateControl} />
      <Route path="/admin/recruiter-control" component={AdminRecruiterControl} />
      <Route path="/admin/cross-platform-analytics" component={CrossPlatformAnalytics} />
      <Route path="/admin/feature-flags" component={FeatureFlags} />
      
      {/* Revenue Intelligence */}
      <Route path="/admin/revenue-optimization" component={RevenueOptimization} />
      <Route path="/admin/credit-analytics" component={CreditAnalytics} />
      <Route path="/admin/subscription-intelligence" component={SubscriptionIntelligence} />
      
      {/* Core Management */}
      <Route path="/admin/users" component={AdminUsers} />
      <Route path="/admin/organizations" component={AdminOrganizations} />
      <Route path="/admin/tenants" component={AdminTenants} />
      
      {/* Recruitment Administration */}
      <Route path="/admin/recruitment-oversight" component={RecruitmentOversight} />
      <Route path="/admin/recruitment-configuration" component={RecruitmentConfiguration} />
      <Route path="/admin/tenant-management" component={AdminTenants} />
      <Route path="/admin/payment-setup" component={PaymentSetup} />
      <Route path="/admin/email-config" component={EmailConfig} />
      <Route path="/admin/security-compliance" component={SecurityCompliance} />
      
      {/* Assessment Control */}
      <Route path="/admin/test-creation" component={TestCreation} />
      <Route path="/admin/question-bank" component={QuestionBank} />
      <Route path="/admin/question-upload" component={QuestionUpload} />
      <Route path="/admin/bulk-upload" component={BulkUpload} />
      <Route path="/admin/assessment-analytics" component={AdminAssessmentAnalytics} />
      
      {/* AI & Content */}
      <Route path="/admin/ai-monitoring" component={AIMonitoring} />
      <Route path="/admin/content-moderation" component={ContentModeration} />
      <Route path="/admin/media-library" component={MediaLibrary} />
      <Route path="/admin/resume-parser" component={AdminResumeParser} />
      
      {/* System Operations */}
      <Route path="/admin/system-monitoring" component={SystemMonitoring} />
      <Route path="/admin/database-management" component={DatabaseManagement} />
      <Route path="/admin/audit-logs" component={AuditLogs} />
      <Route path="/admin/feature-control" component={FeatureControl} />
      <Route path="/admin/api-keys" component={APIKeys} />
      <Route path="/admin/integrations" component={Integrations} />
      
      {/* Business Management */}
      <Route path="/admin/billing-overview" component={BillingOverview} />
      <Route path="/admin/revenue" component={Revenue} />
      <Route path="/admin/api-analytics" component={APIAnalytics} />
      <Route path="/admin/partners" component={Partners} />
      <Route path="/admin/subscription-management" component={AdminSubscriptionManagement} />
      <Route path="/admin/verification-queue" component={VerificationQueue} />
      <Route path="/admin/bulk-scheduling" component={BulkScheduling} />
      
      {/* Admin Settings Route */}
      <Route path="/admin/settings" component={AdminSettings} />

      {/* LMS Platform Routes */}
      <Route path="/lms" component={LMSDashboard} />
      <Route path="/lms/dashboard" component={LMSDashboard} />
      <Route path="/lms/platform" component={LMSPlatform} />
      <Route path="/lms/courses" component={LMSCourses} />
      <Route path="/lms/library" component={LMSLibrary} />
      <Route path="/lms/my-learning" component={MyLearning} />
      <Route path="/lms/videos" component={LMSVideos} />
      <Route path="/lms/practice-tests" component={LMSPracticeTests} />
      <Route path="/lms/assignments" component={LMSAssignments} />
      <Route path="/lms/analytics" component={LMSAnalytics} />
      <Route path="/lms/settings" component={LMSSettings} />

      {/* Assessment Platform Routes - Streamlined Logical Flow */}
      <Route path="/assessment" component={AssessmentDashboard} />
      <Route path="/assessment/dashboard" component={AssessmentDashboard} />
      
      {/* Assessment Hub */}
      <Route path="/assessment/test-creation" component={TestCreationStudio} />
      <Route path="/assessment/question-bank" component={AssessmentQuestionBank} />
      <Route path="/assessment/active-tests" component={ActiveTests} />
      <Route path="/assessment/test-runner" component={EnhancedAssessmentTestRunner} />
      <Route path="/assessment/test-runner/:testId" component={EnhancedAssessmentTestRunner} />
      
      {/* Assessment Types */}
      <Route path="/assessment/technical" component={TechnicalAssessments} />
      <Route path="/assessment/behavioral" component={BehavioralAssessments} />
      <Route path="/assessment/cognitive" component={CognitiveAssessments} />
      <Route path="/assessment/role-based" component={RoleBasedAssessments} />
      
      {/* AI Automation */}
      <Route path="/assessment/ai-generator" component={AITestGenerator} />
      <Route path="/assessment/smart-proctoring" component={SmartProctoring} />
      <Route path="/assessment/auto-scoring" component={AutoScoring} />
      <Route path="/assessment/adaptive-testing" component={AdaptiveTesting} />
      
      {/* Results & Analytics */}
      <Route path="/assessment/test-results" component={AssessmentTestResults} />
      <Route path="/assessment/analytics" component={AssessmentPlatformAnalytics} />
      <Route path="/assessment/certifications" component={AssessmentCertifications} />
      
      {/* Learning Support */}
      <Route path="/assessment/learning-paths" component={LearningPaths} />
      <Route path="/assessment/study-materials" component={StudyMaterials} />
      <Route path="/assessment/practice-tests" component={AssessmentPracticeTests} />
      
      {/* Assessment Settings */}
      <Route path="/assessment/settings" component={AssessmentSettings} />
      
      {/* Legacy/Wrapper Routes */}

      {/* Organization Management Routes - All Phases */}
      <Route path="/organization" component={OrganizationManagement} />
      
      {/* Core Management Routes */}
      <Route path="/organization/departments" component={DepartmentStructure} />
      <Route path="/organization/users" component={OrganizationUserManagement} />
      <Route path="/organization/settings" component={OrganizationPlatformSettings} />
      
      {/* Phase 1: Core Data Model Routes */}
      <Route path="/organization/skill-matrix" component={SkillCompetencyMatrix} />
      <Route path="/organization/career-paths" component={CareerProgressionPaths} />
      <Route path="/organization/benchmarks" component={PerformanceBenchmarks} />
      <Route path="/organization/budget-tracking" component={BudgetResourceTracking} />
      
      {/* Phase 2: Cross-Platform Intelligence Routes */}
      <Route path="/organization/trigger-events" component={AssessmentTriggerEvents} />
      <Route path="/organization/skills-gap" component={SkillsGapAnalysis} />
      <Route path="/organization/resource-optimization" component={ResourceOptimization} />
      <Route path="/organization/workflow-automation" component={WorkflowAutomation} />
      
      {/* Phase 3: Advanced Analytics Routes */}
      <Route path="/organization/predictive-analytics" component={PredictiveAnalytics} />
      <Route path="/organization/industry-benchmarking" component={IndustryBenchmarking} />
      <Route path="/organization/advanced-permissions" component={AdvancedPermissions} />
      <Route path="/organization/cross-platform-sync" component={CrossPlatformSync} />
      
      {/* Integration & Intelligence Routes */}
      <Route path="/organization/user-context" component={UnifiedUserContext} />
      <Route path="/organization/learning-intelligence" component={LearningIntelligence} />
      <Route path="/organization/multi-tenant-intelligence" component={MultiTenantIntelligence} />
      <Route path="/organization/api-integration" component={APIIntegrationHub} />
      
      <Route path="/organization/:section" component={OrganizationManagement} />
      <Route path="/organization/recruitment" component={OrganizationRecruitment} />

      {/* Platform Routes */}
      <ProtectedRoute path="/recruiter" component={RecruiterPlatform} />
      <ProtectedRoute path="/admin" component={AdminPlatform} />
      <ProtectedRoute path="/lms" component={LMSPlatform} />
      <ProtectedRoute path="/assessment" component={AssessmentPlatform} />
      
      {/* Other Routes */}
      <ProtectedRoute path="/dashboard" component={Dashboard} />
      <ProtectedRoute path="/billing" component={BillingDashboard} />
      <ProtectedRoute path="/billing-dashboard" component={BillingDashboard} />
      <ProtectedRoute path="/backup-access" component={BackupAccess} />
      <Route path="/auth" component={AuthPage} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <AuthProvider>
          <NavigationProvider>
            <Router />
            <Toaster />
          </NavigationProvider>
        </AuthProvider>
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;