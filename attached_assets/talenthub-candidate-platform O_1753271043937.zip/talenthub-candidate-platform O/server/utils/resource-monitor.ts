// Resource monitoring to track usage and optimize costs
export class ResourceMonitor {
  private static memoryUsage: number[] = [];
  private static requestCount = 0;
  private static lastCleanup = Date.now();

  static trackRequest() {
    this.requestCount++;
    
    // Track memory usage
    const memUsage = process.memoryUsage();
    this.memoryUsage.push(memUsage.heapUsed / 1024 / 1024); // MB
    
    // Keep only last 100 measurements
    if (this.memoryUsage.length > 100) {
      this.memoryUsage = this.memoryUsage.slice(-50);
    }
    
    // Cleanup every 10 minutes
    if (Date.now() - this.lastCleanup > 600000) {
      this.cleanup();
      this.lastCleanup = Date.now();
    }
  }

  static cleanup() {
    // Force garbage collection if available
    if (global.gc) {
      global.gc();
    }
    
    // Clear old logs
    console.log(`[ResourceMonitor] Cleanup - Requests: ${this.requestCount}, Avg Memory: ${this.getAverageMemory()}MB`);
  }

  static getAverageMemory(): number {
    if (this.memoryUsage.length === 0) return 0;
    return Math.round(this.memoryUsage.reduce((a, b) => a + b, 0) / this.memoryUsage.length);
  }

  static getStats() {
    return {
      requestCount: this.requestCount,
      averageMemory: this.getAverageMemory(),
      currentMemory: Math.round(process.memoryUsage().heapUsed / 1024 / 1024)
    };
  }
}

// Middleware to track resource usage
export function resourceTracker(req: any, res: any, next: any) {
  ResourceMonitor.trackRequest();
  next();
}