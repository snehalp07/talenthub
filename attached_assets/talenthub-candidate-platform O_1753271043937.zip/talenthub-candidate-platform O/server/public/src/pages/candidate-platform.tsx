import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Button } from "@/components/ui/button";
import PlatformLayout from "@/components/layout/platform-layout";
import { platformConfigs } from "@/config/complete-navigation";
import { useThemeClasses } from "@/lib/theme-config";
import { 
  Search, 
  FileText, 
  Target, 
  TrendingUp, 
  Star,
  MapPin,
  Clock,
  Briefcase
} from "lucide-react";

export default function CandidatePlatform() {
  const config = platformConfigs.candidate;
  const theme = useThemeClasses('candidate');

  const jobRecommendations = [
    {
      title: "Senior Full Stack Developer",
      company: "TechCorp Solutions",
      location: "Bangalore, India",
      salary: "₹15-25 LPA",
      match: 95,
      posted: "2 days ago",
      type: "Full-time"
    },
    {
      title: "React Developer",
      company: "StartupXYZ",
      location: "Mumbai, India", 
      salary: "₹12-18 LPA",
      match: 87,
      posted: "1 week ago",
      type: "Full-time"
    },
    {
      title: "Frontend Engineer",
      company: "Digital Innovations",
      location: "Hyderabad, India",
      salary: "₹10-16 LPA", 
      match: 82,
      posted: "3 days ago",
      type: "Remote"
    }
  ];

  const assessmentProgress = [
    { skill: "JavaScript", progress: 85, level: "Advanced" },
    { skill: "React", progress: 78, level: "Intermediate" },
    { skill: "Node.js", progress: 72, level: "Intermediate" },
    { skill: "System Design", progress: 45, level: "Beginner" }
  ];

  const recentActivity = [
    { action: "Applied to Senior Developer role", company: "TechCorp", time: "2 hours ago" },
    { action: "Completed JavaScript Assessment", score: "85%", time: "1 day ago" },
    { action: "Updated profile summary", time: "3 days ago" },
  ];

  return (
    <PlatformLayout
      sidebarTitle={config.sidebarTitle}
      sidebarSubtitle={config.sidebarSubtitle}
      sidebarSections={config.sidebarSections}
      usageData={config.usageData}
    >
      <div className="max-w-6xl mx-auto px-6 py-8">
        {/* Welcome Section */}
        <div className="mb-8">
          <h2 className={theme.title}>Welcome back, John!</h2>
          <p className={theme.accent}>Continue building your career with personalized recommendations and skill assessments.</p>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card className={`${theme.card} shadow-sm`}>
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="w-12 h-12 bg-accent-mint rounded-lg flex items-center justify-center">
                  <Search className="w-6 h-6 text-green-600" />
                </div>
                <Badge variant="outline" className="border-accent-mint text-green-700">+3 new</Badge>
              </div>
              <h3 className="text-2xl font-bold text-sky-800 mb-1">12</h3>
              <p className="text-sm text-green-600">Job Matches</p>
            </CardContent>
          </Card>

          <Card className={`${theme.card} shadow-sm`}>
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="w-12 h-12 bg-accent-mint rounded-lg flex items-center justify-center">
                  <FileText className="w-6 h-6 text-green-600" />
                </div>
                <Badge variant="outline" className="border-accent-mint text-green-700">Active</Badge>
              </div>
              <h3 className="text-2xl font-bold text-sky-800 mb-1">8</h3>
              <p className="text-sm text-green-600">Applications</p>
            </CardContent>
          </Card>

          <Card className={`${theme.card} shadow-sm`}>
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="w-12 h-12 bg-accent-mint rounded-lg flex items-center justify-center">
                  <Target className="w-6 h-6 text-green-600" />
                </div>
                <Badge variant="outline" className="border-accent-mint text-green-700">85% avg</Badge>
              </div>
              <h3 className="text-2xl font-bold text-sky-800 mb-1">4</h3>
              <p className="text-sm text-green-600">Tests Taken</p>
            </CardContent>
          </Card>

          <Card className={`${theme.card} shadow-sm`}>
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="w-12 h-12 bg-accent-mint rounded-lg flex items-center justify-center">
                  <TrendingUp className="w-6 h-6 text-green-600" />
                </div>
                <Badge variant="outline" className="border-accent-mint text-green-700">+15%</Badge>
              </div>
              <h3 className="text-2xl font-bold text-sky-800 mb-1">92</h3>
              <p className="text-sm text-green-600">Profile Score</p>
            </CardContent>
          </Card>
        </div>

        {/* Main Content Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Job Recommendations */}
          <div className="lg:col-span-2">
            <Card className={`${theme.card} shadow-sm`}>
              <CardHeader className="bg-accent-mint/10">
                <div className="flex items-center justify-between">
                  <CardTitle className={theme.accent}>Recommended Jobs</CardTitle>
                  <Button variant="ghost" size="sm" className={theme.secondaryButton}>View All</Button>
                </div>
                <CardDescription className="text-green-700">
                  Personalized job matches based on your profile and preferences
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {jobRecommendations.map((job, index) => (
                    <div key={index} className={`${theme.border} border rounded-lg p-4 hover:bg-accent-mint/20 transition-colors`}>
                      <div className="flex items-start justify-between mb-3">
                        <div className="flex-1">
                          <h3 className="font-semibold text-neutral-600 mb-1">{job.title}</h3>
                          <p className="text-sm text-neutral-500 mb-2">{job.company}</p>
                          <div className="flex items-center space-x-4 text-xs text-neutral-400">
                            <div className="flex items-center">
                              <MapPin className="w-3 h-3 mr-1" />
                              {job.location}
                            </div>
                            <div className="flex items-center">
                              <Clock className="w-3 h-3 mr-1" />
                              {job.posted}
                            </div>
                            <div className="flex items-center">
                              <Briefcase className="w-3 h-3 mr-1" />
                              {job.type}
                            </div>
                          </div>
                        </div>
                        <div className="text-right">
                          <Badge className="bg-green-100 text-green-600 mb-2">
                            {job.match}% match
                          </Badge>
                          <p className="text-sm font-medium text-neutral-600">{job.salary}</p>
                        </div>
                      </div>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-2">
                          <Star className="w-4 h-4 text-yellow-500 fill-current" />
                          <span className="text-xs text-neutral-500">High match score</span>
                        </div>
                        <Button size="sm" className="bg-blue-500 hover:bg-blue-600">
                          Apply Now
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar Content */}
          <div className="space-y-6">
            {/* Skill Assessment Progress */}
            <Card className="shadow-sm">
              <CardHeader>
                <CardTitle className="text-lg">Skill Assessment</CardTitle>
                <CardDescription>
                  Track your progress across key skills
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {assessmentProgress.map((skill, index) => (
                    <div key={index}>
                      <div className="flex justify-between items-center mb-2">
                        <span className="text-sm font-medium text-neutral-600">{skill.skill}</span>
                        <Badge variant="outline" className="text-xs">{skill.level}</Badge>
                      </div>
                      <Progress value={skill.progress} className="h-2" />
                      <div className="text-xs text-neutral-500 mt-1">{skill.progress}% completed</div>
                    </div>
                  ))}
                </div>
                <Button variant="outline" className="w-full mt-4">
                  <Target className="w-4 h-4 mr-2" />
                  Take New Assessment
                </Button>
              </CardContent>
            </Card>

            {/* Recent Activity */}
            <Card className="shadow-sm">
              <CardHeader>
                <CardTitle className="text-lg">Recent Activity</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {recentActivity.map((activity, index) => (
                    <div key={index} className="flex items-start space-x-3">
                      <div className="w-2 h-2 bg-blue-500 rounded-full mt-2 flex-shrink-0"></div>
                      <div className="flex-1">
                        <p className="text-sm text-neutral-600">{activity.action}</p>
                        {activity.company && (
                          <p className="text-xs text-neutral-500">{activity.company}</p>
                        )}
                        {activity.score && (
                          <Badge variant="outline" className="text-xs mt-1">{activity.score}</Badge>
                        )}
                        <p className="text-xs text-neutral-400 mt-1">{activity.time}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </PlatformLayout>
  );
}