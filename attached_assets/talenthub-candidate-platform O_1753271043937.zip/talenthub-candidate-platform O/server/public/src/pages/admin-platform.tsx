import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Button } from "@/components/ui/button";
import PlatformLayout from "@/components/layout/platform-layout";
import { adminNavigation } from "@/config/complete-navigation";
import { useThemeClasses } from "@/lib/theme-config";
import { 
  Shield, 
  Users, 
  Settings, 
  Database, 
  Activity, 
  AlertTriangle,
  BarChart3,
  Server,
  Lock,
  UserPlus,
  FileText,
  Globe,
  Zap,
  CheckCircle,
  Home,
  Monitor,
  CreditCard,
  Mail,
  Key
} from "lucide-react";

export default function AdminPlatform() {
  const theme = useThemeClasses('admin');

  const usageData = [
    { label: "System Load", current: 78, max: 100 },
    { label: "Storage Used", current: 847, max: 1000 },
    { label: "Active Sessions", current: 1234, max: 2000 },
  ];

  const systemMetrics = [
    { label: "Total Users", value: "12,847", change: "+8.2%", icon: Users },
    { label: "Active Sessions", value: "1,234", change: "+15%", icon: Activity },
    { label: "System Uptime", value: "99.9%", change: "Stable", icon: Server },
    { label: "Data Storage", value: "847 GB", change: "+12 GB", icon: Database }
  ];

  const systemAlerts = [
    { message: "High CPU usage on server-02", severity: "warning", time: "10 minutes ago" },
    { message: "Storage capacity at 85%", severity: "warning", time: "2 hours ago" },
    { message: "Security scan completed", severity: "success", time: "6 hours ago" },
    { message: "New tenant registration", severity: "info", time: "1 hour ago" }
  ];

  const tenantStats = [
    { name: "TechCorp Solutions", users: 245, plan: "Enterprise", status: "Active", usage: 78 },
    { name: "StartupXYZ", users: 45, plan: "Professional", status: "Active", usage: 45 },
    { name: "Digital Innovations", users: 123, plan: "Growth", status: "Active", usage: 62 },
    { name: "Global Systems", users: 67, plan: "Professional", status: "Suspended", usage: 0 }
  ];

  const userActivity = [
    { action: "New user registration", user: "john.doe@company.com", time: "2 minutes ago", type: "success" },
    { action: "Failed login attempt", user: "suspicious@email.com", time: "5 minutes ago", type: "warning" },
    { action: "Bulk user import", user: "admin@company.com", time: "15 minutes ago", type: "info" },
    { action: "Password reset", user: "sarah.wilson@company.com", time: "1 hour ago", type: "info" }
  ];

  return (
    <PlatformLayout
      sidebarTitle="Admin Control"
      sidebarSubtitle="System management"
      sidebarSections={adminNavigation}
      usageData={usageData}
    >
      <div className="max-w-6xl mx-auto px-6 py-8">
        {/* Welcome Section */}
        <div className="mb-8">
          <h2 className={theme.title}>System Dashboard</h2>
          <p className={theme.accent}>Monitor system health, manage users, and oversee platform operations.</p>
        </div>

        {/* System Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          {systemMetrics.map((metric, index) => (
            <Card key={index} className={`${theme.card} shadow-sm`}>
              <CardContent className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <div className="w-12 h-12 bg-gray-100 rounded-lg flex items-center justify-center">
                    <metric.icon className="w-6 h-6 text-gray-600" />
                  </div>
                  <Badge variant="outline" className="text-xs border-gray-300 text-gray-700">
                    {metric.change}
                  </Badge>
                </div>
                <h3 className="text-2xl font-bold text-sky-800 mb-1">{metric.value}</h3>
                <p className="text-sm text-gray-600">{metric.label}</p>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Main Content Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Tenant Management */}
          <div className="lg:col-span-2">
            <Card className="shadow-sm">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="text-xl">Tenant Management</CardTitle>
                  <Button variant="ghost" size="sm">View All</Button>
                </div>
                <CardDescription>
                  Monitor and manage all tenant organizations on the platform
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {tenantStats.map((tenant, index) => (
                    <div key={index} className="border border-neutral-200 rounded-lg p-4">
                      <div className="flex items-center justify-between mb-3">
                        <div className="flex-1">
                          <h3 className="font-semibold text-neutral-600 mb-1">{tenant.name}</h3>
                          <div className="flex items-center space-x-4 text-sm text-neutral-500">
                            <span>{tenant.users} users</span>
                            <Badge variant="outline" className="text-xs">{tenant.plan}</Badge>
                            <Badge 
                              variant={tenant.status === 'Active' ? 'default' : 'secondary'}
                              className="text-xs"
                            >
                              {tenant.status}
                            </Badge>
                          </div>
                        </div>
                        <div className="text-right">
                          <div className="text-sm font-medium text-neutral-600">{tenant.usage}%</div>
                          <div className="text-xs text-neutral-500">Usage</div>
                        </div>
                      </div>
                      <Progress value={tenant.usage} className="h-2" />
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar Content */}
          <div className="space-y-6">
            {/* System Alerts */}
            <Card className="shadow-sm">
              <CardHeader>
                <CardTitle className="text-lg flex items-center">
                  <AlertTriangle className="w-5 h-5 mr-2 text-orange-500" />
                  System Alerts
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {systemAlerts.map((alert, index) => (
                    <div key={index} className="flex items-start space-x-3">
                      <div className={`w-2 h-2 rounded-full mt-2 flex-shrink-0 ${
                        alert.severity === 'warning' ? 'bg-orange-500' : 
                        alert.severity === 'success' ? 'bg-green-500' : 'bg-blue-500'
                      }`}></div>
                      <div className="flex-1">
                        <p className="text-sm text-neutral-600">{alert.message}</p>
                        <p className="text-xs text-neutral-400 mt-1">{alert.time}</p>
                      </div>
                    </div>
                  ))}
                </div>
                <Button variant="outline" className="w-full mt-4">
                  View All Alerts
                </Button>
              </CardContent>
            </Card>

            {/* Recent Activity */}
            <Card className="shadow-sm">
              <CardHeader>
                <CardTitle className="text-lg">Recent Activity</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {userActivity.map((activity, index) => (
                    <div key={index} className="flex items-start space-x-3">
                      <div className={`w-2 h-2 rounded-full mt-2 flex-shrink-0 ${
                        activity.type === 'success' ? 'bg-green-500' :
                        activity.type === 'warning' ? 'bg-orange-500' : 'bg-blue-500'
                      }`}></div>
                      <div className="flex-1">
                        <p className="text-sm text-neutral-600">{activity.action}</p>
                        <p className="text-xs text-neutral-500">{activity.user}</p>
                        <p className="text-xs text-neutral-400 mt-1">{activity.time}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* System Operations */}
        <div className="mt-8">
          <Card className="shadow-sm">
            <CardHeader>
              <CardTitle className="text-xl">System Operations</CardTitle>
              <CardDescription>
                Core administrative functions and system management tools
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="space-y-4">
                  <h3 className="font-semibold text-neutral-600 flex items-center">
                    <Users className="w-5 h-5 mr-2" />
                    User Management
                  </h3>
                  <div className="space-y-2">
                    <Button variant="outline" className="w-full justify-start text-sm">
                      <UserPlus className="w-4 h-4 mr-2" />
                      Bulk User Import
                    </Button>
                    <Button variant="outline" className="w-full justify-start text-sm">
                      <Settings className="w-4 h-4 mr-2" />
                      Role Management
                    </Button>
                    <Button variant="outline" className="w-full justify-start text-sm">
                      <Lock className="w-4 h-4 mr-2" />
                      Access Control
                    </Button>
                  </div>
                </div>

                <div className="space-y-4">
                  <h3 className="font-semibold text-neutral-600 flex items-center">
                    <Database className="w-5 h-5 mr-2" />
                    Data Management
                  </h3>
                  <div className="space-y-2">
                    <Button variant="outline" className="w-full justify-start text-sm">
                      <Database className="w-4 h-4 mr-2" />
                      Database Backup
                    </Button>
                    <Button variant="outline" className="w-full justify-start text-sm">
                      <FileText className="w-4 h-4 mr-2" />
                      Export Data
                    </Button>
                    <Button variant="outline" className="w-full justify-start text-sm">
                      <Activity className="w-4 h-4 mr-2" />
                      System Logs
                    </Button>
                  </div>
                </div>

                <div className="space-y-4">
                  <h3 className="font-semibold text-neutral-600 flex items-center">
                    <BarChart3 className="w-5 h-5 mr-2" />
                    Analytics & Reports
                  </h3>
                  <div className="space-y-2">
                    <Button variant="outline" className="w-full justify-start text-sm">
                      <BarChart3 className="w-4 h-4 mr-2" />
                      Usage Analytics
                    </Button>
                    <Button variant="outline" className="w-full justify-start text-sm">
                      <Globe className="w-4 h-4 mr-2" />
                      Performance Reports
                    </Button>
                    <Button variant="outline" className="w-full justify-start text-sm">
                      <Zap className="w-4 h-4 mr-2" />
                      Billing Reports
                    </Button>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </PlatformLayout>
  );
}