import { useLocation } from "wouter";
import PlatformLayout from "@/components/layout/platform-layout";
import { NavigationSection } from "@/components/layout/expandable-sidebar";
import { 
  Target,
  BarChart3,
  FileText,
  Database,
  Award,
  Play,
  Settings,
  Users,
  TrendingUp,
  Shield,
  BookOpen,
  Clipboard,
  Search
} from "lucide-react";

const assessmentNavigation: NavigationSection[] = [
  {
    title: "Assessment Hub",
    items: [
      {
        name: "Dashboard",
        href: "/assessment/dashboard",
        icon: Target
      }
    ]
  },
  {
    title: "Take Assessments",
    items: [
      {
        name: "Browse Tests",
        href: "/assessment/browse-tests",
        icon: Target
      },
      {
        name: "Test Runner",
        href: "/assessment/test-runner",
        icon: Play
      },
      {
        name: "Test Results",
        href: "/assessment/test-results",
        icon: BarChart3
      }
    ]
  },
  {
    title: "Create & Manage",
    items: [
      {
        name: "Question Banks",
        href: "/assessment/question-bank",
        icon: Database
      },
      {
        name: "Bulk Upload",
        href: "/assessment/bulk-upload",
        icon: FileText
      },
      {
        name: "User Management",
        href: "/admin/users",
        icon: Users
      }
    ]
  },
  {
    title: "Analytics & Reports",
    items: [
      {
        name: "Assessment Analytics",
        href: "/admin/assessment-analytics",
        icon: TrendingUp
      },
      {
        name: "Platform Overview",
        href: "/admin/dashboard",
        icon: BarChart3
      }
    ]
  },
  {
    title: "Certification",
    items: [
      {
        name: "Earned Certificates",
        href: "/assessment/certifications",
        icon: Award
      },
      {
        name: "Blockchain Certs",
        href: "/candidate/blockchain-certificates",
        icon: Shield
      }
    ]
  },
  {
    title: "Learning Integration",
    items: [
      {
        name: "LMS Courses",
        href: "/lms/courses",
        icon: BookOpen
      },
      {
        name: "Practice Tests",
        href: "/lms/practice-tests",
        icon: Target
      }
    ]
  }
];

export default function AssessmentPlatform() {
  const [location] = useLocation();
  
  const usageData = [
    { label: "Monthly Tests", current: 245, max: 500 },
    { label: "Active Users", current: 1247, max: 2000 },
    { label: "Storage Used", current: 12, max: 50 }
  ];


  
  return (
    <PlatformLayout
      sidebarTitle="Assessment Platform"
      sidebarSubtitle="Testing & Evaluation Hub"
      sidebarSections={assessmentNavigation}
      usageData={usageData}
    >
      {/* Content will be rendered based on route */}
      <div className="p-6">
        <h1 className="text-2xl font-bold text-gray-900">Assessment Platform</h1>
        <p className="text-gray-600 mt-2">Comprehensive testing and evaluation management system</p>
      </div>
    </PlatformLayout>
  );
}