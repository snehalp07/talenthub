import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import PlatformLayout from "@/components/layout/platform-layout";
import { adminNavigation } from "@/config/complete-navigation";
import { 
  Settings, 
  Eye, 
  EyeOff,
  Copy,
  Trash2,
  Plus,
  Calendar,
  Shield,
  Activity,
  AlertTriangle
} from "lucide-react";
import { useState } from "react";

export default function APIKeys() {
  const [visibleKeys, setVisibleKeys] = useState<Record<number, boolean>>({});

  const apiKeys = [
    {
      id: 1,
      name: "TechCorp Production",
      key: "tk_live_abcd1234efgh5678ijkl9012mnop3456",
      partner: "TechCorp Solutions",
      permissions: ["read:candidates", "write:jobs", "read:analytics"],
      status: "active",
      lastUsed: "2 hours ago",
      created: "2024-01-15",
      usage: 450000,
      rateLimit: "1000/hour"
    },
    {
      id: 2,
      name: "StartupHub Development",
      key: "tk_test_wxyz9876stuv5432nopq1098rstu7654",
      partner: "StartupHub Inc",
      permissions: ["read:candidates", "read:jobs"],
      status: "active",
      lastUsed: "1 day ago",
      created: "2024-03-10",
      usage: 180000,
      rateLimit: "500/hour"
    },
    {
      id: 3,
      name: "EduTech Trial",
      key: "tk_test_demo4321demo8765demo2109demo6543",
      partner: "EduTech Platform",
      permissions: ["read:candidates"],
      status: "restricted",
      lastUsed: "3 hours ago",
      created: "2025-06-01",
      usage: 25000,
      rateLimit: "100/hour"
    },
    {
      id: 4,
      name: "Legacy Integration",
      key: "tk_live_old1234old5678old9012old3456old789",
      partner: "DataFlow Systems",
      permissions: ["read:candidates", "write:jobs", "read:analytics", "write:assessments"],
      status: "inactive",
      lastUsed: "30 days ago",
      created: "2023-08-20",
      usage: 0,
      rateLimit: "2000/hour"
    }
  ];

  const keyMetrics = [
    { name: "Total API Keys", value: "47", description: "Active across all partners" },
    { name: "Active Keys", value: "42", description: "Currently in use" },
    { name: "Rate Limit Violations", value: "12", description: "In the last 24 hours" },
    { name: "Security Alerts", value: "2", description: "Require attention" }
  ];

  const toggleKeyVisibility = (keyId: number) => {
    setVisibleKeys(prev => ({ ...prev, [keyId]: !prev[keyId] }));
  };

  const maskKey = (key: string) => {
    const prefix = key.substring(0, 8);
    const suffix = key.substring(key.length - 4);
    return `${prefix}${'*'.repeat(24)}${suffix}`;
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'bg-green-100 text-green-800 border-green-200';
      case 'restricted': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'inactive': return 'bg-gray-100 text-gray-800 border-gray-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const usageData = [
    { label: "System Load", current: 78, max: 100 },
    { label: "Storage Used", current: 847, max: 1000 },
    { label: "Active Users", current: 1247, max: 2000 }
  ];

  return (
    <PlatformLayout
      sidebarTitle="Admin Control"
      sidebarSubtitle="System management"
      sidebarSections={adminNavigation}
      usageData={usageData}
    >
      <div className="max-w-7xl mx-auto px-6 py-8">
      {/* Header */}
      <div className="mb-8 flex justify-between items-start">
        <div>
          <h2 className="text-3xl font-bold text-sky-800 mb-2">API Key Management</h2>
          <p className="text-sky-600">Manage API keys, permissions, and security settings</p>
        </div>
        <div className="flex gap-3">
          <Button variant="outline" className="border-sky-200 text-sky-700 hover:bg-sky-50">
            <Shield className="h-4 w-4 mr-2" />
            Security Settings
          </Button>
          <Button className="bg-sky-600 hover:bg-sky-700 text-white">
            <Plus className="h-4 w-4 mr-2" />
            Generate New Key
          </Button>
        </div>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        {keyMetrics.map((metric, index) => (
          <Card key={index} className="shadow-sm border-sky-200">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-sky-600 mb-1">{metric.name}</p>
                  <p className="text-2xl font-bold text-sky-800">{metric.value}</p>
                  <p className="text-xs text-sky-500 mt-1">{metric.description}</p>
                </div>
                <div className="h-12 w-12 bg-sky-100 rounded-lg flex items-center justify-center">
                  <Settings className="h-6 w-6 text-sky-600" />
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* API Keys List */}
      <Card className="shadow-sm border-sky-200">
        <CardHeader>
          <CardTitle className="text-sky-800">API Keys</CardTitle>
          <CardDescription>Manage all API keys and their permissions</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-6">
            {apiKeys.map((apiKey) => (
              <div key={apiKey.id} className="p-6 bg-sky-50 rounded-lg border border-sky-100">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex-1">
                    <div className="flex items-center space-x-3 mb-2">
                      <h3 className="text-lg font-semibold text-sky-800">{apiKey.name}</h3>
                      <Badge className={getStatusColor(apiKey.status)}>
                        {apiKey.status.charAt(0).toUpperCase() + apiKey.status.slice(1)}
                      </Badge>
                      {apiKey.status === 'restricted' && (
                        <AlertTriangle className="h-4 w-4 text-yellow-500" />
                      )}
                    </div>
                    <p className="text-sm text-sky-600 mb-3">Partner: {apiKey.partner}</p>
                    
                    <div className="bg-white p-3 rounded border border-sky-200 mb-4">
                      <div className="flex items-center justify-between">
                        <code className="text-sm font-mono text-sky-800">
                          {visibleKeys[apiKey.id] ? apiKey.key : maskKey(apiKey.key)}
                        </code>
                        <div className="flex space-x-2">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => toggleKeyVisibility(apiKey.id)}
                            className="text-sky-600 hover:text-sky-800"
                          >
                            {visibleKeys[apiKey.id] ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            className="text-sky-600 hover:text-sky-800"
                          >
                            <Copy className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
                      <div>
                        <p className="text-xs text-sky-500 mb-1">Created</p>
                        <p className="text-sm font-medium text-sky-800">{apiKey.created}</p>
                      </div>
                      <div>
                        <p className="text-xs text-sky-500 mb-1">Last Used</p>
                        <p className="text-sm font-medium text-sky-800">{apiKey.lastUsed}</p>
                      </div>
                      <div>
                        <p className="text-xs text-sky-500 mb-1">Usage (30 days)</p>
                        <p className="text-sm font-medium text-sky-800">{apiKey.usage.toLocaleString()} calls</p>
                      </div>
                      <div>
                        <p className="text-xs text-sky-500 mb-1">Rate Limit</p>
                        <p className="text-sm font-medium text-sky-800">{apiKey.rateLimit}</p>
                      </div>
                    </div>

                    <div className="mb-4">
                      <p className="text-xs text-sky-500 mb-2">Permissions</p>
                      <div className="flex flex-wrap gap-2">
                        {apiKey.permissions.map((permission, index) => (
                          <Badge key={index} variant="outline" className="text-xs border-sky-300 text-sky-700">
                            {permission}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  </div>

                  <div className="flex space-x-2 ml-4">
                    <Button variant="outline" size="sm" className="border-sky-200 text-sky-700 hover:bg-sky-50">
                      <Settings className="h-4 w-4 mr-1" />
                      Configure
                    </Button>
                    <Button variant="outline" size="sm" className="border-red-200 text-red-700 hover:bg-red-50">
                      <Trash2 className="h-4 w-4 mr-1" />
                      Revoke
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Security Recommendations */}
      <Card className="shadow-sm border-sky-200 mt-8">
        <CardHeader>
          <CardTitle className="text-sky-800">Security Recommendations</CardTitle>
          <CardDescription>Best practices for API key security</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div className="flex items-start space-x-3">
                <Shield className="h-5 w-5 text-green-500 mt-0.5" />
                <div>
                  <p className="font-medium text-sky-800">Rotate keys regularly</p>
                  <p className="text-sm text-sky-600">Update API keys every 90 days for enhanced security</p>
                </div>
              </div>
              <div className="flex items-start space-x-3">
                <Activity className="h-5 w-5 text-green-500 mt-0.5" />
                <div>
                  <p className="font-medium text-sky-800">Monitor usage patterns</p>
                  <p className="text-sm text-sky-600">Set up alerts for unusual API usage patterns</p>
                </div>
              </div>
            </div>
            <div className="space-y-4">
              <div className="flex items-start space-x-3">
                <AlertTriangle className="h-5 w-5 text-yellow-500 mt-0.5" />
                <div>
                  <p className="font-medium text-sky-800">Implement rate limiting</p>
                  <p className="text-sm text-sky-600">Protect against abuse with appropriate rate limits</p>
                </div>
              </div>
              <div className="flex items-start space-x-3">
                <Settings className="h-5 w-5 text-blue-500 mt-0.5" />
                <div>
                  <p className="font-medium text-sky-800">Principle of least privilege</p>
                  <p className="text-sm text-sky-600">Grant only necessary permissions for each key</p>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
      </div>
    </PlatformLayout>
  );
}