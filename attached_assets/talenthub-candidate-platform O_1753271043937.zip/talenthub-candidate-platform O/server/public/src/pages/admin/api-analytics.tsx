import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Button } from "@/components/ui/button";
import { useQuery } from "@tanstack/react-query";
import PlatformLayout from "@/components/layout/platform-layout";
import { adminNavigation } from "@/config/complete-navigation";
import { 
  BarChart3, 
  TrendingUp, 
  Activity, 
  DollarSign,
  Users,
  Calendar,
  Filter,
  Download,
  Loader2,
  Shield
} from "lucide-react";

export default function APIAnalytics() {
  const { data: analyticsData, isLoading } = useQuery({
    queryKey: ["/api/admin/api-analytics"],
    queryFn: async () => {
      const response = await fetch("/api/admin/api-analytics");
      if (!response.ok) throw new Error("Failed to fetch analytics data");
      return response.json();
    }
  });

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin text-sky-600" />
      </div>
    );
  }

  if (!analyticsData) {
    return (
      <div className="max-w-7xl mx-auto px-6 py-8">
        <div className="text-center">
          <h2 className="text-xl font-semibold text-sky-800 mb-2">Unable to load analytics data</h2>
          <p className="text-sky-600">Please try again later</p>
        </div>
      </div>
    );
  }

  const apiMetrics = [
    { name: "Total API Calls", value: `${(analyticsData.metrics.totalCalls / 1000000).toFixed(1)}M`, change: "+12%", trend: "up" },
    { name: "Active Partners", value: analyticsData.metrics.activePartners.toString(), change: "+5", trend: "up" },
    { name: "Revenue Generated", value: `$${analyticsData.metrics.revenueGenerated.toLocaleString()}`, change: "+18%", trend: "up" },
    { name: "Error Rate", value: `${analyticsData.metrics.errorRate}%`, change: "-0.1%", trend: "down" }
  ];

  const usageByEndpoint = analyticsData.usageByEndpoint;
  const topPartners = analyticsData.topPartners;

  const usageData = [
    { label: "System Load", current: 78, max: 100 },
    { label: "Storage Used", current: 847, max: 1000 },
    { label: "Active Users", current: 1247, max: 2000 }
  ];

  return (
    <PlatformLayout
      sidebarTitle="Admin Control"
      sidebarSubtitle="System management"
      sidebarSections={adminNavigation}
      usageData={usageData}
    >
      <div className="max-w-7xl mx-auto px-6 py-8">
      {/* Header */}
      <div className="mb-8 flex justify-between items-start">
        <div>
          <h2 className="text-3xl font-bold text-sky-800 mb-2">API Usage Analytics</h2>
          <p className="text-sky-600">Monitor API performance, usage patterns, and revenue generation</p>
        </div>
        <div className="flex gap-3">
          <Button variant="outline" className="border-sky-200 text-sky-700 hover:bg-sky-50">
            <Filter className="h-4 w-4 mr-2" />
            Filter
          </Button>
          <Button className="bg-sky-600 hover:bg-sky-700 text-white">
            <Download className="h-4 w-4 mr-2" />
            Export Report
          </Button>
        </div>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        {apiMetrics.map((metric, index) => (
          <Card key={index} className="shadow-sm border-sky-200">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-sky-600 mb-1">{metric.name}</p>
                  <p className="text-2xl font-bold text-sky-800">{metric.value}</p>
                  <div className="flex items-center mt-2">
                    <TrendingUp className={`h-4 w-4 mr-1 ${
                      metric.trend === 'up' ? 'text-green-500' : 'text-red-500'
                    }`} />
                    <span className={`text-sm ${
                      metric.trend === 'up' ? 'text-green-600' : 'text-red-600'
                    }`}>
                      {metric.change}
                    </span>
                  </div>
                </div>
                <div className="h-12 w-12 bg-sky-100 rounded-lg flex items-center justify-center">
                  <BarChart3 className="h-6 w-6 text-sky-600" />
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
        {/* Usage by Endpoint */}
        <Card className="shadow-sm border-sky-200">
          <CardHeader>
            <CardTitle className="text-sky-800">Usage by Endpoint</CardTitle>
            <CardDescription>API call distribution across different endpoints</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {usageByEndpoint.map((endpoint, index) => (
                <div key={index} className="space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="text-sm font-medium text-sky-700">{endpoint.endpoint}</span>
                    <div className="text-right">
                      <p className="text-sm font-semibold text-sky-800">{endpoint.calls.toLocaleString()} calls</p>
                      <p className="text-xs text-sky-600">${endpoint.revenue.toLocaleString()}</p>
                    </div>
                  </div>
                  <Progress value={endpoint.percentage} className="h-2 bg-sky-100" />
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Top Partners */}
        <Card className="shadow-sm border-sky-200">
          <CardHeader>
            <CardTitle className="text-sky-800">Top API Partners</CardTitle>
            <CardDescription>Partners generating the most API revenue</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {topPartners.map((partner, index) => (
                <div key={index} className="flex items-center justify-between p-4 bg-sky-50 rounded-lg">
                  <div className="flex items-center space-x-4">
                    <div className="h-10 w-10 bg-sky-600 rounded-full flex items-center justify-center">
                      <Users className="h-5 w-5 text-white" />
                    </div>
                    <div>
                      <p className="font-medium text-sky-800">{partner.name}</p>
                      <div className="flex items-center space-x-2">
                        <Badge variant="outline" className="text-xs border-sky-300 text-sky-700">
                          {partner.plan}
                        </Badge>
                        <span className="text-xs text-sky-600">{partner.calls.toLocaleString()} calls</span>
                      </div>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-semibold text-sky-800">${partner.revenue.toLocaleString()}</p>
                    <p className="text-xs text-sky-600">This month</p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Usage Timeline */}
      <Card className="shadow-sm border-sky-200">
        <CardHeader>
          <CardTitle className="text-sky-800">API Usage Timeline</CardTitle>
          <CardDescription>Daily API calls and revenue over the past 30 days</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="h-64 bg-sky-50 rounded-lg flex items-center justify-center">
            <div className="text-center">
              <Activity className="h-12 w-12 text-sky-400 mx-auto mb-4" />
              <p className="text-sky-600">Interactive usage timeline chart</p>
              <p className="text-sm text-sky-500">Chart component would be integrated here</p>
            </div>
          </div>
        </CardContent>
      </Card>
      </div>
    </PlatformLayout>
  );
}