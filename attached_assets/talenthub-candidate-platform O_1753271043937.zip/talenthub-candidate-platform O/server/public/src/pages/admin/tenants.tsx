import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import PlatformLayout from "@/components/layout/platform-layout";
import { platformConfigs } from "@/config/navigation";
import { 
  Building, 
  Search, 
  Filter, 
  MoreHorizontal, 
  Eye, 
  Edit, 
  Trash2,
  Plus,
  Users,
  Calendar,
  DollarSign,
  TrendingUp,
  BarChart3,
  Settings,
  Crown,
  Shield,
  Globe,
  MapPin,
  Mail,
  Phone,
  Clock,
  CheckCircle,
  XCircle,
  AlertTriangle,
  Pause,
  Play
} from "lucide-react";

interface Tenant {
  id: string;
  name: string;
  domain: string;
  email: string;
  phone: string;
  address: string;
  industry: string;
  size: string;
  plan: string;
  status: string;
  createdAt: string;
  lastActivity: string;
  users: number;
  jobs: number;
  monthlyRevenue: number;
  storageUsed: number;
  storageLimit: number;
  features: string[];
  customizations: {
    branding: boolean;
    customDomain: boolean;
    sso: boolean;
  };
  contactPerson: {
    name: string;
    role: string;
    email: string;
  };
}

export default function AdminTenants() {
  const config = platformConfigs.admin;
  const { toast } = useToast();
  
  const [searchTerm, setSearchTerm] = useState("");
  const [filterStatus, setFilterStatus] = useState("all");
  const [filterPlan, setFilterPlan] = useState("all");
  const [sortBy, setSortBy] = useState("newest");
  const [selectedTenants, setSelectedTenants] = useState<string[]>([]);

  const { data: tenants = [], isLoading } = useQuery<Tenant[]>({
    queryKey: ["/api/admin/tenants"],
    initialData: [
      {
        id: "1",
        name: "TechCorp Solutions",
        domain: "techcorp.talenthub.com",
        email: "admin@techcorp.com",
        phone: "+1 (555) 123-4567",
        address: "123 Tech Street, San Francisco, CA 94105",
        industry: "Technology",
        size: "500-1000",
        plan: "Enterprise",
        status: "active",
        createdAt: "2024-01-15",
        lastActivity: "2 hours ago",
        users: 847,
        jobs: 45,
        monthlyRevenue: 4999,
        storageUsed: 15.6,
        storageLimit: 50,
        features: ["Advanced Analytics", "Custom Branding", "SSO", "API Access"],
        customizations: {
          branding: true,
          customDomain: true,
          sso: true
        },
        contactPerson: {
          name: "Sarah Johnson",
          role: "HR Director",
          email: "sarah.johnson@techcorp.com"
        }
      },
      {
        id: "2",
        name: "StartupXYZ",
        domain: "startupxyz.talenthub.com",
        email: "team@startupxyz.com",
        phone: "+1 (555) 987-6543",
        address: "456 Innovation Ave, Austin, TX 78701",
        industry: "Fintech",
        size: "50-100",
        plan: "Professional",
        status: "active",
        createdAt: "2024-03-22",
        lastActivity: "1 day ago",
        users: 67,
        jobs: 12,
        monthlyRevenue: 999,
        storageUsed: 3.2,
        storageLimit: 10,
        features: ["Analytics", "Team Management", "Bulk Operations"],
        customizations: {
          branding: false,
          customDomain: false,
          sso: false
        },
        contactPerson: {
          name: "Michael Chen",
          role: "CEO",
          email: "michael@startupxyz.com"
        }
      },
      {
        id: "3",
        name: "Global Enterprises",
        domain: "global.talenthub.com",
        email: "hr@globalent.com",
        phone: "+1 (555) 456-7890",
        address: "789 Corporate Blvd, New York, NY 10001",
        industry: "Consulting",
        size: "1000+",
        plan: "Enterprise Plus",
        status: "suspended",
        createdAt: "2023-11-08",
        lastActivity: "1 week ago",
        users: 1234,
        jobs: 78,
        monthlyRevenue: 9999,
        storageUsed: 45.8,
        storageLimit: 100,
        features: ["All Features", "White Label", "Dedicated Support", "Custom Integrations"],
        customizations: {
          branding: true,
          customDomain: true,
          sso: true
        },
        contactPerson: {
          name: "Emily Rodriguez",
          role: "VP of Human Resources",
          email: "emily.rodriguez@globalent.com"
        }
      }
    ]
  });

  const updateTenantStatus = useMutation({
    mutationFn: async ({ tenantId, status }: { tenantId: string; status: string }) => {
      return await apiRequest("PATCH", `/api/admin/tenants/${tenantId}`, { status });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/tenants"] });
      toast({
        title: "Tenant Updated",
        description: "Tenant status has been updated successfully",
      });
    }
  });

  const deleteTenant = useMutation({
    mutationFn: async (tenantId: string) => {
      return await apiRequest("DELETE", `/api/admin/tenants/${tenantId}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/tenants"] });
      toast({
        title: "Tenant Deleted",
        description: "Tenant has been deleted successfully",
      });
    }
  });

  const filteredTenants = tenants.filter(tenant => {
    const matchesSearch = tenant.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         tenant.domain.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         tenant.industry.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = filterStatus === "all" || tenant.status === filterStatus;
    const matchesPlan = filterPlan === "all" || tenant.plan === filterPlan;
    
    return matchesSearch && matchesStatus && matchesPlan;
  });

  const sortedTenants = [...filteredTenants].sort((a, b) => {
    switch (sortBy) {
      case "revenue":
        return b.monthlyRevenue - a.monthlyRevenue;
      case "users":
        return b.users - a.users;
      case "name":
        return a.name.localeCompare(b.name);
      default:
        return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
    }
  });

  const getStatusColor = (status: string) => {
    const colors = {
      active: "bg-green-100 text-green-800",
      suspended: "bg-red-100 text-red-800",
      pending: "bg-yellow-100 text-yellow-800",
      trial: "bg-blue-100 text-blue-800"
    };
    return colors[status as keyof typeof colors] || colors.active;
  };

  const getPlanColor = (plan: string) => {
    const colors = {
      "Basic": "bg-gray-100 text-gray-800",
      "Professional": "bg-blue-100 text-blue-800",
      "Enterprise": "bg-purple-100 text-purple-800",
      "Enterprise Plus": "bg-orange-100 text-orange-800"
    };
    return colors[plan as keyof typeof colors] || colors["Basic"];
  };

  const formatRevenue = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    }).format(amount);
  };

  const formatStorage = (used: number, limit: number) => {
    return `${used.toFixed(1)} GB / ${limit} GB`;
  };

  const getStoragePercentage = (used: number, limit: number) => {
    return Math.min((used / limit) * 100, 100);
  };

  const handleStatusChange = (tenantId: string, newStatus: string) => {
    updateTenantStatus.mutate({ tenantId, status: newStatus });
  };

  const handleDelete = (tenantId: string, tenantName: string) => {
    if (confirm(`Are you sure you want to delete ${tenantName}? This action cannot be undone.`)) {
      deleteTenant.mutate(tenantId);
    }
  };

  const handleBulkAction = (action: string) => {
    toast({
      title: `Bulk ${action}`,
      description: `${action} applied to ${selectedTenants.length} tenants`,
    });
    setSelectedTenants([]);
  };

  return (
    <PlatformLayout
      sidebarTitle={config.sidebarTitle}
      sidebarSubtitle={config.sidebarSubtitle}
      sidebarSections={config.sidebarSections}
      usageData={config.usageData}
    >
      <div className="max-w-7xl mx-auto px-6 py-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h2 className="text-3xl font-bold text-neutral-600 mb-2">Tenant Management</h2>
            <p className="text-neutral-500">Manage organizations, monitor usage, and oversee billing across all tenants.</p>
          </div>
          <div className="flex items-center space-x-3">
            <Button variant="outline">
              <BarChart3 className="w-4 h-4 mr-2" />
              Analytics
            </Button>
            <Button>
              <Plus className="w-4 h-4 mr-2" />
              Add Tenant
            </Button>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-neutral-500">Total Tenants</p>
                  <p className="text-3xl font-bold text-neutral-600">{tenants.length}</p>
                </div>
                <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                  <Building className="w-6 h-6 text-blue-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-neutral-500">Active Tenants</p>
                  <p className="text-3xl font-bold text-neutral-600">
                    {tenants.filter(t => t.status === "active").length}
                  </p>
                </div>
                <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                  <CheckCircle className="w-6 h-6 text-green-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-neutral-500">Total Users</p>
                  <p className="text-3xl font-bold text-neutral-600">
                    {tenants.reduce((sum, t) => sum + t.users, 0).toLocaleString()}
                  </p>
                </div>
                <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
                  <Users className="w-6 h-6 text-purple-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-neutral-500">Monthly Revenue</p>
                  <p className="text-3xl font-bold text-neutral-600">
                    {formatRevenue(tenants.reduce((sum, t) => sum + t.monthlyRevenue, 0))}
                  </p>
                </div>
                <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                  <DollarSign className="w-6 h-6 text-green-600" />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Search and Filters */}
        <Card className="mb-6">
          <CardContent className="p-6">
            <div className="flex flex-col lg:flex-row gap-4">
              <div className="flex-1">
                <div className="relative">
                  <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Search tenants by name, domain, or industry..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                  />
                </div>
              </div>
              <div className="flex gap-3">
                <Select value={filterStatus} onValueChange={setFilterStatus}>
                  <SelectTrigger className="w-40">
                    <SelectValue placeholder="Status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Status</SelectItem>
                    <SelectItem value="active">Active</SelectItem>
                    <SelectItem value="suspended">Suspended</SelectItem>
                    <SelectItem value="pending">Pending</SelectItem>
                    <SelectItem value="trial">Trial</SelectItem>
                  </SelectContent>
                </Select>
                
                <Select value={filterPlan} onValueChange={setFilterPlan}>
                  <SelectTrigger className="w-40">
                    <SelectValue placeholder="Plan" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Plans</SelectItem>
                    <SelectItem value="Basic">Basic</SelectItem>
                    <SelectItem value="Professional">Professional</SelectItem>
                    <SelectItem value="Enterprise">Enterprise</SelectItem>
                    <SelectItem value="Enterprise Plus">Enterprise Plus</SelectItem>
                  </SelectContent>
                </Select>

                <Select value={sortBy} onValueChange={setSortBy}>
                  <SelectTrigger className="w-40">
                    <SelectValue placeholder="Sort by" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="newest">Newest</SelectItem>
                    <SelectItem value="revenue">Revenue</SelectItem>
                    <SelectItem value="users">User Count</SelectItem>
                    <SelectItem value="name">Name A-Z</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Bulk Actions */}
        {selectedTenants.length > 0 && (
          <Card className="mb-6 border-blue-200 bg-blue-50">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">
                  {selectedTenants.length} tenants selected
                </span>
                <div className="flex items-center space-x-2">
                  <Button size="sm" variant="outline" onClick={() => handleBulkAction("suspend")}>
                    <Pause className="w-3 h-3 mr-1" />
                    Suspend
                  </Button>
                  <Button size="sm" variant="outline" onClick={() => handleBulkAction("activate")}>
                    <Play className="w-3 h-3 mr-1" />
                    Activate
                  </Button>
                  <Button size="sm" variant="outline" onClick={() => handleBulkAction("export")}>
                    <BarChart3 className="w-3 h-3 mr-1" />
                    Export
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Tenants List */}
        <div className="space-y-4">
          {isLoading ? (
            <div className="text-center py-12">
              <Building className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
              <p className="text-muted-foreground">Loading tenants...</p>
            </div>
          ) : sortedTenants.length === 0 ? (
            <Card>
              <CardContent className="p-12 text-center">
                <Building className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
                <h3 className="text-lg font-semibold mb-2">No Tenants Found</h3>
                <p className="text-muted-foreground mb-4">
                  Try adjusting your search criteria or add your first tenant.
                </p>
                <Button>
                  <Plus className="w-4 h-4 mr-2" />
                  Add First Tenant
                </Button>
              </CardContent>
            </Card>
          ) : (
            sortedTenants.map((tenant) => (
              <Card key={tenant.id} className="hover:shadow-md transition-shadow">
                <CardContent className="p-6">
                  <div className="flex items-start justify-between">
                    <div className="flex items-start space-x-4 flex-1">
                      <input
                        type="checkbox"
                        className="mt-1"
                        checked={selectedTenants.includes(tenant.id)}
                        onChange={(e) => {
                          if (e.target.checked) {
                            setSelectedTenants([...selectedTenants, tenant.id]);
                          } else {
                            setSelectedTenants(selectedTenants.filter(id => id !== tenant.id));
                          }
                        }}
                      />
                      
                      <Avatar className="h-12 w-12">
                        <AvatarFallback className="bg-blue-100 text-blue-600">
                          {tenant.name.split(' ').map(n => n[0]).join('').slice(0, 2)}
                        </AvatarFallback>
                      </Avatar>
                      
                      <div className="flex-1">
                        <div className="flex items-center space-x-3 mb-2">
                          <h3 className="text-lg font-semibold text-neutral-600">{tenant.name}</h3>
                          <Badge className={getStatusColor(tenant.status)}>
                            {tenant.status}
                          </Badge>
                          <Badge className={getPlanColor(tenant.plan)}>
                            {tenant.plan}
                          </Badge>
                          {tenant.customizations.sso && (
                            <Badge variant="outline" className="bg-purple-100 text-purple-600">
                              <Shield className="w-3 h-3 mr-1" />
                              SSO
                            </Badge>
                          )}
                        </div>
                        
                        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 mb-4">
                          <div>
                            <div className="flex items-center text-sm text-neutral-500 mb-1">
                              <Globe className="w-3 h-3 mr-1" />
                              {tenant.domain}
                            </div>
                            <div className="flex items-center text-sm text-neutral-500 mb-1">
                              <Mail className="w-3 h-3 mr-1" />
                              {tenant.email}
                            </div>
                            <div className="flex items-center text-sm text-neutral-500">
                              <MapPin className="w-3 h-3 mr-1" />
                              {tenant.industry} • {tenant.size} employees
                            </div>
                          </div>
                          
                          <div>
                            <div className="grid grid-cols-2 gap-4 text-sm mb-2">
                              <div>
                                <p className="text-neutral-500">Users</p>
                                <p className="font-medium">{tenant.users.toLocaleString()}</p>
                              </div>
                              <div>
                                <p className="text-neutral-500">Jobs</p>
                                <p className="font-medium">{tenant.jobs}</p>
                              </div>
                            </div>
                            <div className="text-sm">
                              <p className="text-neutral-500">Monthly Revenue</p>
                              <p className="font-medium text-green-600">{formatRevenue(tenant.monthlyRevenue)}</p>
                            </div>
                          </div>
                          
                          <div>
                            <div className="text-sm mb-2">
                              <p className="text-neutral-500">Storage Usage</p>
                              <div className="flex items-center space-x-2">
                                <div className="flex-1 bg-gray-200 rounded-full h-2">
                                  <div 
                                    className="bg-blue-600 h-2 rounded-full" 
                                    style={{ width: `${getStoragePercentage(tenant.storageUsed, tenant.storageLimit)}%` }}
                                  ></div>
                                </div>
                                <span className="font-medium">{Math.round(getStoragePercentage(tenant.storageUsed, tenant.storageLimit))}%</span>
                              </div>
                              <p className="text-xs text-neutral-500 mt-1">
                                {formatStorage(tenant.storageUsed, tenant.storageLimit)}
                              </p>
                            </div>
                            <div className="text-sm">
                              <p className="text-neutral-500">Last Activity</p>
                              <p className="font-medium">{tenant.lastActivity}</p>
                            </div>
                          </div>
                        </div>
                        
                        <div className="mb-3">
                          <p className="text-sm font-medium text-neutral-600 mb-2">Contact Person</p>
                          <div className="flex items-center text-sm text-neutral-500">
                            <span>{tenant.contactPerson.name} • {tenant.contactPerson.role}</span>
                          </div>
                        </div>
                        
                        <div className="flex flex-wrap gap-2">
                          {tenant.features.slice(0, 3).map((feature, index) => (
                            <Badge key={index} variant="outline" className="text-xs">
                              {feature}
                            </Badge>
                          ))}
                          {tenant.features.length > 3 && (
                            <Badge variant="outline" className="text-xs">
                              +{tenant.features.length - 3} more
                            </Badge>
                          )}
                        </div>
                      </div>
                    </div>
                    
                    <div className="flex items-center space-x-2 ml-4">
                      <Select 
                        value={tenant.status} 
                        onValueChange={(value) => handleStatusChange(tenant.id, value)}
                      >
                        <SelectTrigger className="w-32">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="active">Active</SelectItem>
                          <SelectItem value="suspended">Suspended</SelectItem>
                          <SelectItem value="pending">Pending</SelectItem>
                        </SelectContent>
                      </Select>
                      
                      <Button size="sm" variant="outline">
                        <Eye className="w-4 h-4" />
                      </Button>
                      
                      <Button size="sm" variant="outline">
                        <Edit className="w-4 h-4" />
                      </Button>
                      
                      <Button size="sm" variant="outline">
                        <Settings className="w-4 h-4" />
                      </Button>
                      
                      <Button 
                        size="sm" 
                        variant="outline"
                        onClick={() => handleDelete(tenant.id, tenant.name)}
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))
          )}
        </div>

        {/* Pagination */}
        <div className="flex items-center justify-between mt-8">
          <p className="text-sm text-neutral-500">
            Showing {sortedTenants.length} of {tenants.length} tenants
          </p>
          <div className="flex items-center space-x-2">
            <Button variant="outline" size="sm" disabled>
              Previous
            </Button>
            <Button variant="outline" size="sm" className="bg-blue-50">
              1
            </Button>
            <Button variant="outline" size="sm">
              2
            </Button>
            <Button variant="outline" size="sm">
              Next
            </Button>
          </div>
        </div>
      </div>
    </PlatformLayout>
  );
}