import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import PlatformLayout from "@/components/layout/platform-layout";
import { adminNavigation } from "@/config/complete-navigation";
import { 
  DollarSign, 
  TrendingUp, 
  TrendingDown,
  Calendar, 
  Target,
  Users,
  BarChart3,
  Download,
  Filter
} from "lucide-react";

export default function Revenue() {
  const revenueMetrics = [
    { name: "Total API Revenue", value: "$124,750", change: "+18.2%", trend: "up" },
    { name: "Monthly Recurring", value: "$89,200", change: "+12.5%", trend: "up" },
    { name: "Usage-Based Revenue", value: "$35,550", change: "+28.7%", trend: "up" },
    { name: "Average Revenue Per Partner", value: "$2,653", change: "-2.1%", trend: "down" }
  ];

  const revenueByModel = [
    { model: "White-Label Licensing", revenue: 48500, percentage: 38.9, growth: "+15%" },
    { model: "API Usage Pricing", revenue: 35550, percentage: 28.5, growth: "+28%" },
    { model: "Revenue Sharing", revenue: 25200, percentage: 20.2, growth: "+8%" },
    { model: "Tiered Access", revenue: 15500, percentage: 12.4, growth: "+35%" }
  ];

  const monthlyRevenue = [
    { month: "Jan", revenue: 67200, target: 65000, partners: 35 },
    { month: "Feb", revenue: 72100, target: 68000, partners: 38 },
    { month: "Mar", revenue: 78900, target: 72000, partners: 41 },
    { month: "Apr", revenue: 85600, target: 78000, partners: 44 },
    { month: "May", revenue: 92300, target: 85000, partners: 46 },
    { month: "Jun", revenue: 124750, target: 95000, partners: 47 }
  ];

  const topRevenuePartners = [
    { name: "TechCorp Solutions", revenue: 28500, plan: "Enterprise", growth: "+12%" },
    { name: "StartupHub Inc", revenue: 18200, plan: "Professional", growth: "+8%" },
    { name: "EduTech Platform", revenue: 15600, plan: "White-Label", growth: "+25%" },
    { name: "HR Innovations", revenue: 12800, plan: "Professional", growth: "+15%" },
    { name: "DataFlow Systems", revenue: 9900, plan: "Starter", growth: "+32%" }
  ];

  const usageData = [
    { label: "System Load", current: 78, max: 100 },
    { label: "Storage Used", current: 847, max: 1000 },
    { label: "Active Users", current: 1247, max: 2000 }
  ];

  return (
    <PlatformLayout
      sidebarTitle="Admin Control"
      sidebarSubtitle="System management"
      sidebarSections={adminNavigation}
      usageData={usageData}
    >
      <div className="max-w-7xl mx-auto px-6 py-8">
      {/* Header */}
      <div className="mb-8 flex justify-between items-start">
        <div>
          <h2 className="text-3xl font-bold text-sky-800 mb-2">Revenue Tracking</h2>
          <p className="text-sky-600">Monitor API revenue streams, track performance against targets</p>
        </div>
        <div className="flex gap-3">
          <Button variant="outline" className="border-sky-200 text-sky-700 hover:bg-sky-50">
            <Filter className="h-4 w-4 mr-2" />
            Filter Period
          </Button>
          <Button className="bg-sky-600 hover:bg-sky-700 text-white">
            <Download className="h-4 w-4 mr-2" />
            Export Report
          </Button>
        </div>
      </div>

      {/* Revenue Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        {revenueMetrics.map((metric, index) => (
          <Card key={index} className="shadow-sm border-sky-200">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-sky-600 mb-1">{metric.name}</p>
                  <p className="text-2xl font-bold text-sky-800">{metric.value}</p>
                  <div className="flex items-center mt-2">
                    {metric.trend === 'up' ? (
                      <TrendingUp className="h-4 w-4 mr-1 text-green-500" />
                    ) : (
                      <TrendingDown className="h-4 w-4 mr-1 text-red-500" />
                    )}
                    <span className={`text-sm ${
                      metric.trend === 'up' ? 'text-green-600' : 'text-red-600'
                    }`}>
                      {metric.change}
                    </span>
                  </div>
                </div>
                <div className="h-12 w-12 bg-sky-100 rounded-lg flex items-center justify-center">
                  <DollarSign className="h-6 w-6 text-sky-600" />
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
        {/* Revenue by Model */}
        <Card className="shadow-sm border-sky-200">
          <CardHeader>
            <CardTitle className="text-sky-800">Revenue by Pricing Model</CardTitle>
            <CardDescription>Breakdown of revenue streams across different pricing strategies</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {revenueByModel.map((model, index) => (
                <div key={index} className="space-y-2">
                  <div className="flex justify-between items-center">
                    <span className="text-sm font-medium text-sky-700">{model.model}</span>
                    <div className="text-right">
                      <p className="text-sm font-semibold text-sky-800">${model.revenue.toLocaleString()}</p>
                      <p className="text-xs text-green-600">{model.growth}</p>
                    </div>
                  </div>
                  <Progress value={model.percentage} className="h-2 bg-sky-100" />
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Top Revenue Partners */}
        <Card className="shadow-sm border-sky-200">
          <CardHeader>
            <CardTitle className="text-sky-800">Top Revenue Partners</CardTitle>
            <CardDescription>Partners generating the highest revenue this quarter</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {topRevenuePartners.map((partner, index) => (
                <div key={index} className="flex items-center justify-between p-4 bg-sky-50 rounded-lg">
                  <div className="flex items-center space-x-4">
                    <div className="h-10 w-10 bg-sky-600 rounded-full flex items-center justify-center text-white font-semibold">
                      {index + 1}
                    </div>
                    <div>
                      <p className="font-medium text-sky-800">{partner.name}</p>
                      <div className="flex items-center space-x-2">
                        <Badge variant="outline" className="text-xs border-sky-300 text-sky-700">
                          {partner.plan}
                        </Badge>
                        <span className="text-xs text-green-600">{partner.growth}</span>
                      </div>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-semibold text-sky-800">${partner.revenue.toLocaleString()}</p>
                    <p className="text-xs text-sky-600">This quarter</p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Monthly Revenue Performance */}
      <Card className="shadow-sm border-sky-200 mb-8">
        <CardHeader>
          <CardTitle className="text-sky-800">Monthly Revenue Performance</CardTitle>
          <CardDescription>Revenue vs targets with partner growth tracking</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-6">
            {monthlyRevenue.map((month, index) => (
              <div key={index} className="p-4 bg-sky-50 rounded-lg">
                <div className="flex justify-between items-center mb-3">
                  <div className="flex items-center space-x-4">
                    <h3 className="font-semibold text-sky-800">{month.month} 2025</h3>
                    <Badge variant="outline" className="border-sky-300 text-sky-700">
                      {month.partners} Partners
                    </Badge>
                  </div>
                  <div className="text-right">
                    <p className="text-lg font-bold text-sky-800">${month.revenue.toLocaleString()}</p>
                    <p className="text-sm text-sky-600">Target: ${month.target.toLocaleString()}</p>
                  </div>
                </div>
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="text-sky-600">Target Achievement</span>
                    <span className="text-sky-800 font-medium">
                      {Math.round((month.revenue / month.target) * 100)}%
                    </span>
                  </div>
                  <Progress 
                    value={Math.min((month.revenue / month.target) * 100, 100)} 
                    className="h-2 bg-sky-100" 
                  />
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Revenue Forecast */}
      <Card className="shadow-sm border-sky-200">
        <CardHeader>
          <CardTitle className="text-sky-800">Revenue Forecast</CardTitle>
          <CardDescription>Projected revenue based on current trends and pipeline</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="text-center p-6 bg-sky-50 rounded-lg">
              <Target className="h-8 w-8 text-sky-600 mx-auto mb-3" />
              <p className="text-2xl font-bold text-sky-800">$145K</p>
              <p className="text-sm text-sky-600">Q3 Forecast</p>
            </div>
            <div className="text-center p-6 bg-sky-50 rounded-lg">
              <BarChart3 className="h-8 w-8 text-sky-600 mx-auto mb-3" />
              <p className="text-2xl font-bold text-sky-800">$520K</p>
              <p className="text-sm text-sky-600">Annual Projection</p>
            </div>
            <div className="text-center p-6 bg-sky-50 rounded-lg">
              <Users className="h-8 w-8 text-sky-600 mx-auto mb-3" />
              <p className="text-2xl font-bold text-sky-800">65</p>
              <p className="text-sm text-sky-600">Expected Partners</p>
            </div>
          </div>
        </CardContent>
      </Card>
      </div>
    </PlatformLayout>
  );
}