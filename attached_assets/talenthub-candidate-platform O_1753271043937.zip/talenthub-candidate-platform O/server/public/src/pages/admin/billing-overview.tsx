import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { DollarSign, Users, AlertTriangle, TrendingUp, ArrowLeft, Shield, Home, CreditCard, BarChart3, Database, Settings, Lock, Globe, Monitor, Server, UserPlus, Key, Mail } from "lucide-react";
import { Link } from "wouter";
import PlatformLayout from "@/components/layout/platform-layout";

export default function BillingOverview() {
  // Fetch billing overview data
  const { data: billingData, isLoading: billingLoading } = useQuery({
    queryKey: ["/api/admin/billing/overview"],
  });

  const { data: alertsData, isLoading: alertsLoading } = useQuery({
    queryKey: ["/api/admin/billing/alerts"],
  });

  const sidebarSections = [
    {
      items: [
        { name: "Dashboard", icon: Home, href: "/admin", current: false },
        { name: "User Management", icon: Users, href: "/admin/users", current: false, badge: "12,847" },
        { name: "Tenant Management", icon: Globe, href: "/admin/tenants", current: false, badge: "247" },
        { name: "System Monitor", icon: Monitor, href: "/admin/monitor", current: false },
        { name: "Security Center", icon: Lock, href: "/admin/security", current: false, badge: "3" },
        { name: "Analytics", icon: BarChart3, href: "/admin/analytics", current: false },
      ]
    },
    {
      title: "Operations",
      items: [
        { name: "Database Management", icon: Database, href: "/admin/database" },
        { name: "Bulk Operations", icon: UserPlus, href: "/admin/bulk" },
        { name: "Backup & Recovery", icon: Server, href: "/admin/backup" },
        { name: "API Management", icon: Key, href: "/admin/api" },
        { name: "Notifications", icon: Mail, href: "/admin/notifications" },
        { name: "Billing Overview", icon: CreditCard, href: "/admin/billing-overview", current: true },
        { name: "System Settings", icon: Settings, href: "/admin/settings" },
      ]
    }
  ];

  const usageData = [
    { label: "System Load", current: 78, max: 100 },
    { label: "Storage Used", current: 847, max: 1000 },
    { label: "Active Sessions", current: 1234, max: 2000 },
  ];

  if (billingLoading || alertsLoading) {
    return (
      <PlatformLayout
        sidebarTitle="Admin Control"
        sidebarSubtitle="System management"
        sidebarSections={sidebarSections}
        usageData={usageData}
      >
        <div className="flex items-center justify-center min-h-[400px]">
          <div className="animate-spin w-8 h-8 border-4 border-gray-300 border-t-gray-600 rounded-full" />
        </div>
      </PlatformLayout>
    );
  }

  const billingArray = Array.isArray(billingData) ? billingData : [];
  const alertsArray = Array.isArray(alertsData) ? alertsData : [];
  
  const totalRevenue = billingArray.reduce((sum: number, tenant: any) => sum + tenant.monthlyRevenue, 0);
  const activeTenants = billingArray.filter((tenant: any) => tenant.subscriptionStatus === 'active').length;
  const overdueAmount = billingArray.reduce((sum: number, tenant: any) => sum + tenant.outstandingAmount, 0);
  const criticalAlerts = alertsArray.filter((alert: any) => alert.severity === 'critical').length;

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'active':
        return <Badge className="bg-green-100 text-green-800">Active</Badge>;
      case 'past_due':
        return <Badge className="bg-red-100 text-red-800">Past Due</Badge>;
      case 'canceled':
        return <Badge className="bg-gray-100 text-gray-800">Canceled</Badge>;
      default:
        return <Badge className="bg-yellow-100 text-yellow-800">Unknown</Badge>;
    }
  };

  return (
    <PlatformLayout
      sidebarTitle="Admin Control"
      sidebarSubtitle="System management"
      sidebarSections={sidebarSections}
      usageData={usageData}
    >
      <div className="p-6 space-y-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Link href="/admin">
              <Button variant="ghost" size="sm" className="text-gray-600 hover:text-gray-900">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Back to Admin Dashboard
              </Button>
            </Link>
            <h1 className="text-3xl font-bold text-gray-900">Billing Overview</h1>
          </div>
          <div className="text-sm text-gray-500">
            Last updated: {new Date().toLocaleString()}
          </div>
        </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Monthly Revenue</CardTitle>
            <DollarSign className="h-4 w-4 text-gray-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">${totalRevenue.toFixed(2)}</div>
            <p className="text-xs text-gray-600">Current billing cycle</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active Tenants</CardTitle>
            <Users className="h-4 w-4 text-gray-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{activeTenants}</div>
            <p className="text-xs text-gray-600">Paying customers</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Outstanding Amount</CardTitle>
            <AlertTriangle className="h-4 w-4 text-red-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">${overdueAmount.toFixed(2)}</div>
            <p className="text-xs text-gray-600">Overdue payments</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Critical Alerts</CardTitle>
            <TrendingUp className="h-4 w-4 text-red-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">{criticalAlerts}</div>
            <p className="text-xs text-gray-600">Require attention</p>
          </CardContent>
        </Card>
      </div>

      {/* Critical Alerts */}
      {alertsArray && alertsArray.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Critical Alerts</CardTitle>
            <CardDescription>Issues requiring immediate attention</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {alertsArray.slice(0, 5).map((alert: any) => (
                <Alert key={alert.id} className="border-red-200 bg-red-50">
                  <AlertTriangle className="h-4 w-4 text-red-600" />
                  <AlertDescription>
                    <div className="flex items-center justify-between">
                      <div>
                        <span className="font-medium">{alert.title}</span>
                        <p className="text-sm text-gray-600">{alert.message}</p>
                      </div>
                      <Badge className={`${
                        alert.severity === 'critical' ? 'bg-red-100 text-red-800' :
                        alert.severity === 'warning' ? 'bg-yellow-100 text-yellow-800' :
                        'bg-blue-100 text-blue-800'
                      }`}>
                        {alert.severity}
                      </Badge>
                    </div>
                  </AlertDescription>
                </Alert>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Tenant Billing Table */}
      <Card>
        <CardHeader>
          <CardTitle>Tenant Billing Details</CardTitle>
          <CardDescription>Comprehensive billing status for all tenants</CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Tenant</TableHead>
                <TableHead>Plan</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Monthly Revenue</TableHead>
                <TableHead>Last Payment</TableHead>
                <TableHead>Next Payment</TableHead>
                <TableHead>Outstanding</TableHead>
                <TableHead>Alerts</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {billingData?.map((tenant: any) => (
                <TableRow key={tenant.tenantId}>
                  <TableCell className="font-medium">{tenant.tenantName}</TableCell>
                  <TableCell>{tenant.currentPlan}</TableCell>
                  <TableCell>{getStatusBadge(tenant.subscriptionStatus)}</TableCell>
                  <TableCell>${tenant.monthlyRevenue.toFixed(2)}</TableCell>
                  <TableCell>
                    {tenant.lastPayment ? 
                      new Date(tenant.lastPayment).toLocaleDateString() : 
                      'No payments'
                    }
                  </TableCell>
                  <TableCell>
                    {tenant.nextPayment ? 
                      new Date(tenant.nextPayment).toLocaleDateString() : 
                      'Not scheduled'
                    }
                  </TableCell>
                  <TableCell className={`${tenant.outstandingAmount > 0 ? 'text-red-600 font-semibold' : ''}`}>
                    ${tenant.outstandingAmount.toFixed(2)}
                  </TableCell>
                  <TableCell>
                    {tenant.alerts > 0 && (
                      <Badge className="bg-red-100 text-red-800">
                        {tenant.alerts}
                      </Badge>
                    )}
                  </TableCell>
                  <TableCell>
                    <div className="flex space-x-2">
                      <Button variant="outline" size="sm">
                        View Details
                      </Button>
                      {tenant.outstandingAmount > 0 && (
                        <Button variant="outline" size="sm" className="text-red-600">
                          Send Notice
                        </Button>
                      )}
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
      </div>
    </PlatformLayout>
  );
}