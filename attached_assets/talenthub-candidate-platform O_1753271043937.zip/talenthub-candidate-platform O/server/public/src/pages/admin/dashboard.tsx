import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import PlatformLayout from "@/components/layout/platform-layout";
import { platformConfigs } from "@/config/navigation";
import { 
  BarChart3, 
  Users, 
  FileText, 
  TrendingUp, 
  Brain, 
  Award, 
  Briefcase, 
  Clock, 
  CheckCircle, 
  Target, 
  Star, 
  MapPin,
  Calendar,
  DollarSign,
  Send,
  Eye,
  ArrowRight,
  Play,
  BookOpen,
  Trophy,
  Zap,
  Filter,
  Heart,
  Building2,
  TrendingDown,
  UserCheck,
  MessageSquare,
  PhoneCall,
  Mail,
  Search,
  Plus,
  Shield,
  Database,
  Settings,
  AlertTriangle,
  CheckCircle2,
  XCircle,
  Activity,
  Server,
  HardDrive
} from "lucide-react";

export default function AdminDashboard() {
  const config = platformConfigs.admin;

  // System Health Metrics
  const systemHealth = [
    { metric: "Server Uptime", value: "99.9%", status: "excellent", color: "bg-green-500" },
    { metric: "Database Performance", value: "45ms", status: "good", color: "bg-blue-500" },
    { metric: "API Response Time", value: "120ms", status: "fair", color: "bg-yellow-500" },
    { metric: "Storage Usage", value: "68%", status: "warning", color: "bg-orange-500" }
  ];

  // Multi-Tenant Overview
  const tenantMetrics = [
    { 
      name: "TechCorp Solutions", 
      plan: "Enterprise", 
      users: 1247, 
      revenue: "$12,450",
      growth: "+15%",
      status: "Active",
      color: "bg-green-100 text-green-800"
    },
    { 
      name: "Innovation Labs", 
      plan: "Professional", 
      users: 543, 
      revenue: "$5,430",
      growth: "+8%",
      status: "Active",
      color: "bg-blue-100 text-blue-800"
    },
    { 
      name: "StartupXYZ", 
      plan: "Starter", 
      users: 89, 
      revenue: "$890",
      growth: "+25%",
      status: "Trial",
      color: "bg-yellow-100 text-yellow-800"
    },
    { 
      name: "MegaCorp Inc", 
      plan: "Enterprise", 
      users: 2156, 
      revenue: "$21,560",
      growth: "+12%",
      status: "Active",
      color: "bg-purple-100 text-purple-800"
    }
  ];

  // Platform Usage Analytics
  const platformUsage = [
    { platform: "Candidate", users: 12847, sessions: 45623, engagement: 87 },
    { platform: "Recruiter", users: 3421, sessions: 15234, engagement: 92 },
    { platform: "LMS", users: 8765, sessions: 32156, engagement: 78 },
    { platform: "Assessment", users: 5632, sessions: 18765, engagement: 85 }
  ];

  // System Alerts
  const systemAlerts = [
    {
      id: 1,
      type: "warning",
      title: "High API Usage on Tenant #47",
      description: "TechCorp Solutions approaching rate limits",
      time: "15 minutes ago",
      icon: AlertTriangle,
      color: "bg-yellow-500",
      priority: "Medium"
    },
    {
      id: 2,
      type: "success",
      title: "Database Backup Completed",
      description: "All tenant data successfully backed up",
      time: "2 hours ago",
      icon: CheckCircle2,
      color: "bg-green-500",
      priority: "Low"
    },
    {
      id: 3,
      type: "error",
      title: "Payment Gateway Issue",
      description: "Stripe webhook failing for 3 transactions",
      time: "4 hours ago",
      icon: XCircle,
      color: "bg-red-500",
      priority: "High"
    },
    {
      id: 4,
      type: "info",
      title: "New Feature Deployment",
      description: "Assessment Platform v2.1 rolled out successfully",
      time: "1 day ago",
      icon: Zap,
      color: "bg-blue-500",
      priority: "Low"
    }
  ];

  // Revenue Analytics
  const revenueData = [
    { month: "Jan", amount: 45000, growth: "+12%" },
    { month: "Feb", amount: 52000, growth: "+15%" },
    { month: "Mar", amount: 48000, growth: "-8%" },
    { month: "Apr", amount: 67000, growth: "+39%" },
    { month: "May", amount: 71000, growth: "+6%" },
    { month: "Jun", amount: 78000, growth: "+10%" }
  ];

  // Recent Admin Activities
  const recentActivities = [
    {
      id: 1,
      type: "tenant",
      title: "New Enterprise tenant onboarded",
      tenant: "Global Tech Innovations",
      time: "30 minutes ago",
      icon: Building2,
      color: "bg-green-500",
      status: "success"
    },
    {
      id: 2,
      type: "user",
      title: "Bulk user import completed",
      count: "247 users",
      time: "2 hours ago",
      icon: Users,
      color: "bg-blue-500",
      status: "success"
    },
    {
      id: 3,
      type: "billing",
      title: "Monthly billing cycle processed",
      amount: "$156,780",
      time: "4 hours ago",
      icon: DollarSign,
      color: "bg-purple-500",
      status: "success"
    },
    {
      id: 4,
      type: "security",
      title: "Security audit completed",
      result: "No issues found",
      time: "6 hours ago",
      icon: Shield,
      color: "bg-indigo-500",
      status: "success"
    },
    {
      id: 5,
      type: "maintenance",
      title: "Database optimization performed",
      improvement: "15% faster queries",
      time: "1 day ago",
      icon: Database,
      color: "bg-orange-500",
      status: "success"
    }
  ];

  return (
    <PlatformLayout
      sidebarTitle={config.sidebarTitle}
      sidebarSubtitle={config.sidebarSubtitle}
      sidebarSections={config.sidebarSections}
      usageData={[
        { label: "Total Tenants", current: 247, max: 500 },
        { label: "Active Users", current: 25689, max: 50000 },
        { label: "API Calls/Day", current: 1250000, max: 2000000 }
      ]}
    >
      <div className="min-h-screen bg-gray-50 p-6">
        {/* Hero Section */}
        <Card className="bg-white mb-6">
          <CardContent className="p-8">
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-3xl font-bold text-gray-900 mb-2">Admin Dashboard</h1>
                <p className="text-gray-600 mb-4">Multi-tenant platform oversight and system administration</p>
                <div className="flex items-center space-x-6">
                  <div className="text-center">
                    <div className="text-2xl font-bold text-sky-600">247</div>
                    <div className="text-sm text-gray-500">Active Tenants</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-green-600">$78K</div>
                    <div className="text-sm text-gray-500">Monthly Revenue</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-purple-600">99.9%</div>
                    <div className="text-sm text-gray-500">System Uptime</div>
                  </div>
                </div>
              </div>
              <div className="flex space-x-3">
                <Button className="bg-sky-500 hover:bg-sky-600 text-white">
                  <Plus className="w-4 h-4 mr-2" />
                  Add Tenant
                </Button>
                <Button variant="outline" className="border-gray-300 text-gray-600">
                  <Settings className="w-4 h-4 mr-2" />
                  System Settings
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* System Health & Tenant Overview */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
          {/* System Health */}
          <Card className="bg-white">
            <CardHeader>
              <CardTitle className="text-xl text-gray-800">System Health</CardTitle>
              <CardDescription>Real-time platform performance metrics</CardDescription>
            </CardHeader>
            <CardContent className="p-6 bg-white">
              {/* Visual Health Dashboard */}
              <div className="grid grid-cols-2 gap-4 mb-6">
                {systemHealth.map((metric, index) => (
                  <div key={index} className="text-center p-4 bg-gradient-to-br from-gray-50 to-green-50 rounded-lg border hover:shadow-md transition-all">
                    <div className={`w-16 h-16 ${metric.color} rounded-full flex items-center justify-center mx-auto mb-3 shadow-lg`}>
                      {metric.status === 'excellent' ? (
                        <CheckCircle className="w-8 h-8 text-white" />
                      ) : metric.status === 'good' ? (
                        <Activity className="w-8 h-8 text-white" />
                      ) : metric.status === 'fair' ? (
                        <Clock className="w-8 h-8 text-white" />
                      ) : (
                        <AlertTriangle className="w-8 h-8 text-white" />
                      )}
                    </div>
                    <div className="mb-2">
                      <div className="text-xl font-bold text-gray-900">{metric.value}</div>
                      <div className="text-xs text-gray-600 mb-2">{metric.metric}</div>
                    </div>
                    <div className={`text-xs font-medium px-2 py-1 rounded-full ${
                      metric.status === 'excellent' ? 'bg-green-100 text-green-800' :
                      metric.status === 'good' ? 'bg-blue-100 text-blue-800' :
                      metric.status === 'fair' ? 'bg-yellow-100 text-yellow-800' :
                      'bg-orange-100 text-orange-800'
                    }`}>
                      {metric.status === 'excellent' ? '🟢 Excellent' :
                       metric.status === 'good' ? '🔵 Good' :
                       metric.status === 'fair' ? '🟡 Fair' :
                       '🟠 Warning'}
                    </div>
                  </div>
                ))}
              </div>
              <Button variant="outline" className="w-full mt-4 text-gray-600 border-gray-300">
                <Activity className="w-4 h-4 mr-2" />
                View System Logs
              </Button>
            </CardContent>
          </Card>

          {/* Top Tenants */}
          <Card className="bg-white">
            <CardHeader>
              <CardTitle className="text-xl text-gray-800">Top Performing Tenants</CardTitle>
              <CardDescription>Revenue leaders and growth metrics</CardDescription>
            </CardHeader>
            <CardContent className="p-6 bg-white">
              <div className="space-y-4">
                {tenantMetrics.map((tenant, index) => (
                  <div key={index} className="border border-gray-200 rounded-lg p-4 hover:bg-gray-50 transition-colors">
                    <div className="flex items-start justify-between mb-2">
                      <h4 className="font-semibold text-gray-900">{tenant.name}</h4>
                      <Badge className={tenant.color}>{tenant.status}</Badge>
                    </div>
                    <div className="flex items-center justify-between text-sm text-gray-600">
                      <div className="flex items-center space-x-4">
                        <span className="flex items-center">
                          <Users className="w-4 h-4 mr-1" />
                          {tenant.users} users
                        </span>
                        <span className="font-medium text-gray-900">{tenant.plan}</span>
                      </div>
                      <div className="text-right">
                        <div className="font-medium text-green-600">{tenant.revenue}</div>
                        <div className="text-xs text-green-500">{tenant.growth}</div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
              <Button variant="outline" className="w-full mt-4 text-gray-600 border-gray-300">
                <Building2 className="w-4 h-4 mr-2" />
                Manage All Tenants
              </Button>
            </CardContent>
          </Card>
        </div>

        {/* Platform Usage & Revenue Analytics */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
          {/* Platform Usage */}
          <Card className="bg-white">
            <CardHeader>
              <CardTitle className="text-xl text-gray-800">Platform Usage Analytics</CardTitle>
              <CardDescription>Cross-platform user engagement metrics</CardDescription>
            </CardHeader>
            <CardContent className="p-6 bg-white">
              <div className="space-y-4">
                {platformUsage.map((platform, index) => (
                  <div key={index} className="p-4 border border-gray-200 rounded-lg">
                    <div className="flex items-center justify-between mb-2">
                      <h4 className="font-semibold text-gray-900">{platform.platform} Platform</h4>
                      <div className="text-right">
                        <div className="text-sm font-medium text-gray-900">{platform.engagement}%</div>
                        <div className="text-xs text-gray-500">engagement</div>
                      </div>
                    </div>
                    <div className="flex items-center justify-between text-sm text-gray-600 mb-2">
                      <span>{platform.users.toLocaleString()} users</span>
                      <span>{platform.sessions.toLocaleString()} sessions</span>
                    </div>
                    <Progress value={platform.engagement} className="h-2" />
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Revenue Trends */}
          <Card className="bg-white">
            <CardHeader>
              <CardTitle className="text-xl text-gray-800">Revenue Trends</CardTitle>
              <CardDescription>Monthly recurring revenue and growth</CardDescription>
            </CardHeader>
            <CardContent className="p-6 bg-white">
              <div className="space-y-3">
                {revenueData.map((month, index) => (
                  <div key={index} className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <div className="w-2 h-2 bg-sky-500 rounded-full"></div>
                      <span className="font-medium text-gray-900">{month.month} 2024</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <span className="font-semibold text-gray-900">${month.amount.toLocaleString()}</span>
                      <span className={`text-sm ${
                        month.growth.startsWith('+') ? 'text-green-600' : 'text-red-600'
                      }`}>{month.growth}</span>
                    </div>
                  </div>
                ))}
              </div>
              <Button variant="outline" className="w-full mt-4 text-gray-600 border-gray-300">
                <BarChart3 className="w-4 h-4 mr-2" />
                View Revenue Analytics
              </Button>
            </CardContent>
          </Card>
        </div>

        {/* System Alerts */}
        <Card className="bg-white mb-6">
          <CardHeader>
            <CardTitle className="text-xl text-gray-800">System Alerts</CardTitle>
            <CardDescription>Critical notifications and system updates</CardDescription>
          </CardHeader>
          <CardContent className="p-6 bg-white">
            <div className="space-y-4">
              {systemAlerts.map((alert) => {
                const IconComponent = alert.icon;
                return (
                  <div key={alert.id} className="flex items-start space-x-4 p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors cursor-pointer">
                    <div className={`w-10 h-10 ${alert.color} rounded-full flex items-center justify-center flex-shrink-0`}>
                      <IconComponent className="w-5 h-5 text-white" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <h4 className="font-medium text-gray-900 mb-1">{alert.title}</h4>
                          <p className="text-sm text-gray-600 mb-2">{alert.description}</p>
                        </div>
                        <div className="text-right flex-shrink-0 ml-4">
                          <div className="text-xs text-gray-500">{alert.time}</div>
                          <div className={`mt-1 inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${
                            alert.priority === 'High' ? 'bg-red-100 text-red-800' :
                            alert.priority === 'Medium' ? 'bg-yellow-100 text-yellow-800' :
                            'bg-gray-100 text-gray-800'
                          }`}>
                            {alert.priority} Priority
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
            <div className="mt-6 flex justify-center">
              <Button variant="outline" className="text-gray-600 border-gray-300">
                <Eye className="w-4 h-4 mr-2" />
                View All Alerts
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Recent Activities */}
        <Card className="bg-white mb-6">
          <CardHeader>
            <CardTitle className="text-xl text-gray-800">Recent Admin Activities</CardTitle>
            <CardDescription>Latest system administration actions and events</CardDescription>
          </CardHeader>
          <CardContent className="p-6 bg-white">
            <div className="space-y-4">
              {recentActivities.map((activity) => {
                const IconComponent = activity.icon;
                return (
                  <div key={activity.id} className="flex items-start space-x-4 p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors cursor-pointer">
                    <div className={`w-10 h-10 ${activity.color} rounded-full flex items-center justify-center flex-shrink-0`}>
                      <IconComponent className="w-5 h-5 text-white" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <h4 className="font-medium text-gray-900 mb-1">{activity.title}</h4>
                          <div className="flex items-center space-x-4 text-sm text-gray-600">
                            {activity.tenant && (
                              <span className="flex items-center">
                                <Building2 className="w-4 h-4 mr-1" />
                                {activity.tenant}
                              </span>
                            )}
                            {activity.count && (
                              <span className="flex items-center">
                                <Users className="w-4 h-4 mr-1" />
                                {activity.count}
                              </span>
                            )}
                            {activity.amount && (
                              <span className="flex items-center">
                                <DollarSign className="w-4 h-4 mr-1" />
                                {activity.amount}
                              </span>
                            )}
                            {activity.result && (
                              <span className="flex items-center">
                                <CheckCircle className="w-4 h-4 mr-1" />
                                {activity.result}
                              </span>
                            )}
                            {activity.improvement && (
                              <span className="flex items-center">
                                <TrendingUp className="w-4 h-4 mr-1" />
                                {activity.improvement}
                              </span>
                            )}
                          </div>
                        </div>
                        <div className="text-right flex-shrink-0 ml-4">
                          <div className="text-xs text-gray-500">{activity.time}</div>
                          <div className="mt-1 inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-green-100 text-green-800">
                            ✓ Complete
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
            <div className="mt-6 flex justify-center">
              <Button variant="outline" className="text-gray-600 border-gray-300">
                <Clock className="w-4 h-4 mr-2" />
                View Activity Log
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Call-to-Action */}
        <Card className="bg-white">
          <CardContent className="p-8 text-center">
            <h3 className="text-2xl font-bold text-gray-900 mb-2">Platform Scaling Opportunities</h3>
            <p className="text-gray-600 mb-6">Optimize system performance and expand infrastructure to support growing tenant demands.</p>
            <div className="flex justify-center space-x-4">
              <Button className="bg-sky-500 hover:bg-sky-600 text-white">
                <Server className="w-4 h-4 mr-2" />
                Scale Infrastructure
              </Button>
              <Button variant="outline" className="border-gray-300 text-gray-600">
                <BarChart3 className="w-4 h-4 mr-2" />
                Performance Report
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </PlatformLayout>
  );
}