import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import PlatformLayout from "@/components/layout/platform-layout";
import { adminNavigation } from "@/config/complete-navigation";
import { 
  Monitor, 
  CheckCircle, 
  AlertTriangle,
  XCircle,
  Activity,
  Clock,
  Zap,
  Globe,
  RefreshCw,
  Settings,
  Eye
} from "lucide-react";

export default function Integrations() {
  const systemHealth = [
    { name: "API Uptime", value: "99.9%", status: "healthy", change: "+0.1%" },
    { name: "Response Time", value: "245ms", status: "good", change: "-15ms" },
    { name: "Error Rate", value: "0.08%", status: "healthy", change: "-0.02%" },
    { name: "Active Connections", value: "1,247", status: "normal", change: "+52" }
  ];

  const integrations = [
    {
      id: 1,
      name: "TechCorp HR System",
      partner: "TechCorp Solutions",
      type: "Webhook",
      status: "healthy",
      uptime: 99.8,
      lastSync: "2 minutes ago",
      syncFrequency: "Real-time",
      dataPoints: 28500,
      errorCount: 0,
      avgResponseTime: 180,
      endpoint: "https://api.techcorp.com/webhook/talenthub"
    },
    {
      id: 2,
      name: "StartupHub ATS",
      partner: "StartupHub Inc",
      type: "REST API",
      status: "healthy",
      uptime: 99.2,
      lastSync: "5 minutes ago",
      syncFrequency: "15 minutes",
      dataPoints: 15200,
      errorCount: 2,
      avgResponseTime: 320,
      endpoint: "https://startuphub.io/api/v2/candidates"
    },
    {
      id: 3,
      name: "EduTech Learning Portal",
      partner: "EduTech Platform",
      type: "GraphQL",
      status: "warning",
      uptime: 97.5,
      lastSync: "2 hours ago",
      syncFrequency: "1 hour",
      dataPoints: 5600,
      errorCount: 15,
      avgResponseTime: 580,
      endpoint: "https://edutech.edu/graphql"
    },
    {
      id: 4,
      name: "Legacy Data Bridge",
      partner: "DataFlow Systems",
      type: "SOAP",
      status: "critical",
      uptime: 85.2,
      lastSync: "6 hours ago",
      syncFrequency: "Manual",
      dataPoints: 0,
      errorCount: 45,
      avgResponseTime: 1200,
      endpoint: "https://legacy.dataflow.com/soap/v1"
    }
  ];

  const recentEvents = [
    {
      id: 1,
      type: "success",
      message: "TechCorp HR System - Successful sync of 150 candidates",
      timestamp: "2 minutes ago",
      partner: "TechCorp Solutions"
    },
    {
      id: 2,
      type: "warning",
      message: "EduTech Learning Portal - High response time detected (850ms)",
      timestamp: "15 minutes ago",
      partner: "EduTech Platform"
    },
    {
      id: 3,
      type: "error",
      message: "Legacy Data Bridge - Connection timeout after 30 seconds",
      timestamp: "1 hour ago",
      partner: "DataFlow Systems"
    },
    {
      id: 4,
      type: "success",
      message: "StartupHub ATS - API rate limit reset successful",
      timestamp: "2 hours ago",
      partner: "StartupHub Inc"
    }
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'healthy': return 'bg-green-100 text-green-800 border-green-200';
      case 'warning': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'critical': return 'bg-red-100 text-red-800 border-red-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'healthy': return <CheckCircle className="h-5 w-5 text-green-500" />;
      case 'warning': return <AlertTriangle className="h-5 w-5 text-yellow-500" />;
      case 'critical': return <XCircle className="h-5 w-5 text-red-500" />;
      default: return <Monitor className="h-5 w-5 text-gray-500" />;
    }
  };

  const getEventIcon = (type: string) => {
    switch (type) {
      case 'success': return <CheckCircle className="h-4 w-4 text-green-500" />;
      case 'warning': return <AlertTriangle className="h-4 w-4 text-yellow-500" />;
      case 'error': return <XCircle className="h-4 w-4 text-red-500" />;
      default: return <Activity className="h-4 w-4 text-blue-500" />;
    }
  };

  const usageData = [
    { label: "System Load", current: 78, max: 100 },
    { label: "Storage Used", current: 847, max: 1000 },
    { label: "Active Users", current: 1247, max: 2000 }
  ];

  return (
    <PlatformLayout
      sidebarTitle="Admin Control"
      sidebarSubtitle="System management"
      sidebarSections={adminNavigation}
      usageData={usageData}
    >
      <div className="max-w-7xl mx-auto px-6 py-8">
      {/* Header */}
      <div className="mb-8 flex justify-between items-start">
        <div>
          <h2 className="text-3xl font-bold text-sky-800 mb-2">Integration Monitoring</h2>
          <p className="text-sky-600">Monitor API integrations, system health, and data synchronization</p>
        </div>
        <div className="flex gap-3">
          <Button variant="outline" className="border-sky-200 text-sky-700 hover:bg-sky-50">
            <RefreshCw className="h-4 w-4 mr-2" />
            Refresh Status
          </Button>
          <Button variant="outline" className="border-sky-200 text-sky-700 hover:bg-sky-50">
            <Settings className="h-4 w-4 mr-2" />
            Configure Alerts
          </Button>
        </div>
      </div>

      {/* System Health Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        {systemHealth.map((metric, index) => (
          <Card key={index} className="shadow-sm border-sky-200">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-sky-600 mb-1">{metric.name}</p>
                  <p className="text-2xl font-bold text-sky-800">{metric.value}</p>
                  <p className="text-xs text-sky-500 mt-1">{metric.change}</p>
                </div>
                <div className="h-12 w-12 bg-sky-100 rounded-lg flex items-center justify-center">
                  <Activity className="h-6 w-6 text-sky-600" />
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-8">
        {/* Integration Status */}
        <div className="lg:col-span-2">
          <Card className="shadow-sm border-sky-200">
            <CardHeader>
              <CardTitle className="text-sky-800">Active Integrations</CardTitle>
              <CardDescription>Real-time status of all partner integrations</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {integrations.map((integration) => (
                  <div key={integration.id} className="p-4 bg-sky-50 rounded-lg border border-sky-100">
                    <div className="flex items-start justify-between mb-4">
                      <div className="flex items-start space-x-3">
                        {getStatusIcon(integration.status)}
                        <div>
                          <div className="flex items-center space-x-2 mb-1">
                            <h3 className="font-semibold text-sky-800">{integration.name}</h3>
                            <Badge className={getStatusColor(integration.status)}>
                              {integration.status}
                            </Badge>
                            <Badge variant="outline" className="text-xs border-sky-300 text-sky-700">
                              {integration.type}
                            </Badge>
                          </div>
                          <p className="text-sm text-sky-600">{integration.partner}</p>
                        </div>
                      </div>
                      <div className="flex space-x-2">
                        <Button variant="outline" size="sm" className="border-sky-200 text-sky-700 hover:bg-sky-50">
                          <Eye className="h-4 w-4 mr-1" />
                          Details
                        </Button>
                        <Button variant="outline" size="sm" className="border-sky-200 text-sky-700 hover:bg-sky-50">
                          <Settings className="h-4 w-4 mr-1" />
                          Configure
                        </Button>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-3">
                      <div>
                        <p className="text-xs text-sky-500 mb-1">Uptime</p>
                        <p className="font-semibold text-sky-800">{integration.uptime}%</p>
                      </div>
                      <div>
                        <p className="text-xs text-sky-500 mb-1">Last Sync</p>
                        <p className="font-semibold text-sky-800">{integration.lastSync}</p>
                      </div>
                      <div>
                        <p className="text-xs text-sky-500 mb-1">Response Time</p>
                        <p className="font-semibold text-sky-800">{integration.avgResponseTime}ms</p>
                      </div>
                      <div>
                        <p className="text-xs text-sky-500 mb-1">Errors (24h)</p>
                        <p className="font-semibold text-sky-800">{integration.errorCount}</p>
                      </div>
                    </div>

                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span className="text-sky-600">Uptime</span>
                        <span className="text-sky-800 font-medium">{integration.uptime}%</span>
                      </div>
                      <Progress value={integration.uptime} className="h-2 bg-sky-100" />
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Recent Events */}
        <Card className="shadow-sm border-sky-200">
          <CardHeader>
            <CardTitle className="text-sky-800">Recent Events</CardTitle>
            <CardDescription>Latest integration activities and alerts</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {recentEvents.map((event) => (
                <div key={event.id} className="flex items-start space-x-3 p-3 bg-sky-50 rounded-lg">
                  {getEventIcon(event.type)}
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-sky-800 mb-1">{event.message}</p>
                    <div className="flex items-center space-x-2">
                      <p className="text-xs text-sky-600">{event.partner}</p>
                      <span className="text-xs text-sky-400">•</span>
                      <p className="text-xs text-sky-500">{event.timestamp}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Performance Overview */}
      <Card className="shadow-sm border-sky-200">
        <CardHeader>
          <CardTitle className="text-sky-800">Performance Overview</CardTitle>
          <CardDescription>Integration performance metrics and trends</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="text-center p-6 bg-sky-50 rounded-lg">
              <Zap className="h-8 w-8 text-sky-600 mx-auto mb-3" />
              <p className="text-2xl font-bold text-sky-800">1.2M</p>
              <p className="text-sm text-sky-600">API Calls Today</p>
            </div>
            <div className="text-center p-6 bg-sky-50 rounded-lg">
              <Globe className="h-8 w-8 text-sky-600 mx-auto mb-3" />
              <p className="text-2xl font-bold text-sky-800">47</p>
              <p className="text-sm text-sky-600">Active Endpoints</p>
            </div>
            <div className="text-center p-6 bg-sky-50 rounded-lg">
              <Clock className="h-8 w-8 text-sky-600 mx-auto mb-3" />
              <p className="text-2xl font-bold text-sky-800">245ms</p>
              <p className="text-sm text-sky-600">Avg Response Time</p>
            </div>
          </div>
        </CardContent>
      </Card>
      </div>
    </PlatformLayout>
  );
}