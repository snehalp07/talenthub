import { useAuth } from "@/hooks/use-auth";
import { useQuery } from "@tanstack/react-query";
import DashboardHeader from "@/components/dashboard-header";
import Sidebar from "@/components/sidebar";
import DashboardContent from "@/components/dashboard-content";
import { Loader2 } from "lucide-react";

export default function Dashboard() {
  const { user } = useAuth();
  
  const { data: dashboardData, isLoading } = useQuery({
    queryKey: ["/api/dashboard"],
    enabled: !!user,
  });

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-neutral-50">
      <DashboardHeader user={user} tenant={dashboardData?.tenant} />
      <div className="flex h-[calc(100vh-80px)]">
        <Sidebar 
          user={user} 
          usageSummary={dashboardData?.usageSummary || []} 
        />
        <main className="flex-1 overflow-auto">
          <DashboardContent 
            user={user}
            metrics={dashboardData?.metrics}
            recentCandidates={dashboardData?.recentCandidates || []}
            tenant={dashboardData?.tenant}
          />
        </main>
      </div>
    </div>
  );
}
