import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Separator } from "@/components/ui/separator";
import PlatformLayout from "@/components/layout/platform-layout";
import { platformConfigs } from "@/config/complete-navigation";
import { 
  Bell, 
  Plus, 
  Search, 
  MapPin, 
  DollarSign, 
  Briefcase,
  Clock,
  Filter,
  Edit,
  Trash2,
  CheckCircle,
  AlertCircle,
  Mail,
  Smartphone,
  Settings
} from "lucide-react";

function JobAlertsContent() {
  const [alertForm, setAlertForm] = useState({
    title: "",
    keywords: "",
    location: "",
    salaryMin: "",
    salaryMax: "",
    jobType: "all",
    experienceLevel: "all",
    company: "",
    frequency: "daily"
  });

  const existingAlerts = [
    {
      id: "1",
      name: "Frontend Developer - San Francisco",
      keywords: "React, JavaScript, TypeScript",
      location: "San Francisco, CA",
      salaryRange: "$100K - $150K",
      jobType: "Full-time",
      frequency: "daily",
      isActive: true,
      createdAt: "2024-01-15",
      newJobs: 5,
      lastSent: "2 hours ago"
    },
    {
      id: "2", 
      name: "Senior Software Engineer",
      keywords: "Node.js, Python, AWS",
      location: "Remote",
      salaryRange: "$120K - $180K",
      jobType: "Full-time",
      frequency: "weekly",
      isActive: true,
      createdAt: "2024-01-10",
      newJobs: 12,
      lastSent: "1 day ago"
    },
    {
      id: "3",
      name: "UI/UX Designer",
      keywords: "Figma, Design Systems, Prototyping",
      location: "New York, NY",
      salaryRange: "$90K - $130K",
      jobType: "Full-time",
      frequency: "daily",
      isActive: false,
      createdAt: "2024-01-05",
      newJobs: 0,
      lastSent: "5 days ago"
    }
  ];

  const recentMatches = [
    {
      id: "1",
      title: "Senior React Developer",
      company: "TechCorp Inc.",
      location: "San Francisco, CA",
      salary: "$130,000 - $160,000",
      type: "Full-time",
      postedAt: "2 hours ago",
      matchScore: 95,
      alertName: "Frontend Developer - San Francisco"
    },
    {
      id: "2",
      title: "Full Stack Engineer",
      company: "StartupXYZ",
      location: "Remote",
      salary: "$120,000 - $150,000",
      type: "Full-time",
      postedAt: "4 hours ago",
      matchScore: 88,
      alertName: "Senior Software Engineer"
    },
    {
      id: "3",
      title: "Frontend Developer",
      company: "Digital Agency",
      location: "San Francisco, CA",
      salary: "$110,000 - $140,000",
      type: "Full-time",
      postedAt: "6 hours ago",
      matchScore: 92,
      alertName: "Frontend Developer - San Francisco"
    }
  ];

  const handleCreateAlert = () => {
    console.log("Creating alert:", alertForm);
    // Reset form
    setAlertForm({
      title: "",
      keywords: "",
      location: "",
      salaryMin: "",
      salaryMax: "",
      jobType: "all",
      experienceLevel: "all",
      company: "",
      frequency: "daily"
    });
  };

  const getMatchScoreColor = (score: number) => {
    if (score >= 90) return "text-green-600";
    if (score >= 80) return "text-yellow-600";
    return "text-red-600";
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-sky-50 to-white p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Job Alerts</h1>
          <p className="text-gray-600">Set up personalized job alerts to never miss the perfect opportunity</p>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card className="border-sky-200">
            <CardContent className="p-6 text-center">
              <Bell className="h-8 w-8 text-sky-600 mx-auto mb-2" />
              <div className="text-2xl font-bold text-sky-700">{existingAlerts.length}</div>
              <div className="text-sm text-gray-600">Active Alerts</div>
            </CardContent>
          </Card>
          <Card className="border-green-200">
            <CardContent className="p-6 text-center">
              <CheckCircle className="h-8 w-8 text-green-600 mx-auto mb-2" />
              <div className="text-2xl font-bold text-green-700">{recentMatches.length}</div>
              <div className="text-sm text-gray-600">New Matches Today</div>
            </CardContent>
          </Card>
          <Card className="border-purple-200">
            <CardContent className="p-6 text-center">
              <Mail className="h-8 w-8 text-purple-600 mx-auto mb-2" />
              <div className="text-2xl font-bold text-purple-700">15</div>
              <div className="text-sm text-gray-600">Emails Sent This Week</div>
            </CardContent>
          </Card>
          <Card className="border-orange-200">
            <CardContent className="p-6 text-center">
              <Briefcase className="h-8 w-8 text-orange-600 mx-auto mb-2" />
              <div className="text-2xl font-bold text-orange-700">127</div>
              <div className="text-sm text-gray-600">Total Jobs Matched</div>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Create New Alert */}
          <div className="lg:col-span-1">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Plus className="h-5 w-5 text-sky-600" />
                  Create Job Alert
                </CardTitle>
                <CardDescription>Set up a new personalized job alert</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label htmlFor="title">Alert Name</Label>
                  <Input
                    id="title"
                    placeholder="e.g., Frontend Developer - SF"
                    value={alertForm.title}
                    onChange={(e) => setAlertForm(prev => ({ ...prev, title: e.target.value }))}
                  />
                </div>

                <div>
                  <Label htmlFor="keywords">Keywords</Label>
                  <Input
                    id="keywords"
                    placeholder="React, JavaScript, TypeScript"
                    value={alertForm.keywords}
                    onChange={(e) => setAlertForm(prev => ({ ...prev, keywords: e.target.value }))}
                  />
                </div>

                <div>
                  <Label htmlFor="location">Location</Label>
                  <Input
                    id="location"
                    placeholder="San Francisco, CA or Remote"
                    value={alertForm.location}
                    onChange={(e) => setAlertForm(prev => ({ ...prev, location: e.target.value }))}
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <Label htmlFor="salaryMin">Min Salary</Label>
                    <Input
                      id="salaryMin"
                      placeholder="100000"
                      value={alertForm.salaryMin}
                      onChange={(e) => setAlertForm(prev => ({ ...prev, salaryMin: e.target.value }))}
                    />
                  </div>
                  <div>
                    <Label htmlFor="salaryMax">Max Salary</Label>
                    <Input
                      id="salaryMax"
                      placeholder="150000"
                      value={alertForm.salaryMax}
                      onChange={(e) => setAlertForm(prev => ({ ...prev, salaryMax: e.target.value }))}
                    />
                  </div>
                </div>

                <div>
                  <Label>Job Type</Label>
                  <Select value={alertForm.jobType} onValueChange={(value) => setAlertForm(prev => ({ ...prev, jobType: value }))}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Types</SelectItem>
                      <SelectItem value="full-time">Full-time</SelectItem>
                      <SelectItem value="part-time">Part-time</SelectItem>
                      <SelectItem value="contract">Contract</SelectItem>
                      <SelectItem value="remote">Remote</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label>Experience Level</Label>
                  <Select value={alertForm.experienceLevel} onValueChange={(value) => setAlertForm(prev => ({ ...prev, experienceLevel: value }))}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Levels</SelectItem>
                      <SelectItem value="entry">Entry Level</SelectItem>
                      <SelectItem value="mid">Mid Level</SelectItem>
                      <SelectItem value="senior">Senior Level</SelectItem>
                      <SelectItem value="lead">Lead/Manager</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label>Alert Frequency</Label>
                  <Select value={alertForm.frequency} onValueChange={(value) => setAlertForm(prev => ({ ...prev, frequency: value }))}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="immediate">Immediate</SelectItem>
                      <SelectItem value="daily">Daily</SelectItem>
                      <SelectItem value="weekly">Weekly</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <Button onClick={handleCreateAlert} className="w-full bg-sky-600 hover:bg-sky-700">
                  <Plus className="h-4 w-4 mr-2" />
                  Create Alert
                </Button>
              </CardContent>
            </Card>

            {/* Notification Settings */}
            <Card className="mt-6">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Settings className="h-5 w-5 text-sky-600" />
                  Notification Settings
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <div className="flex items-center gap-2">
                      <Mail className="h-4 w-4 text-gray-500" />
                      <Label>Email Notifications</Label>
                    </div>
                    <p className="text-sm text-gray-500">Receive alerts via email</p>
                  </div>
                  <Switch defaultChecked />
                </div>
                <div className="flex items-center justify-between">
                  <div className="space-y-0.5">
                    <div className="flex items-center gap-2">
                      <Smartphone className="h-4 w-4 text-gray-500" />
                      <Label>Push Notifications</Label>
                    </div>
                    <p className="text-sm text-gray-500">Browser push notifications</p>
                  </div>
                  <Switch />
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Existing Alerts & Recent Matches */}
          <div className="lg:col-span-2 space-y-6">
            {/* Existing Alerts */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Bell className="h-5 w-5 text-sky-600" />
                  Your Job Alerts
                </CardTitle>
                <CardDescription>Manage your existing job alerts</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {existingAlerts.map((alert) => (
                    <Card key={alert.id} className={`border-2 ${alert.isActive ? 'border-green-200' : 'border-gray-200'}`}>
                      <CardContent className="p-4">
                        <div className="flex items-center justify-between mb-3">
                          <div className="flex items-center gap-3">
                            <h3 className="font-semibold text-gray-900">{alert.name}</h3>
                            <Badge className={alert.isActive ? "bg-green-100 text-green-700" : "bg-gray-100 text-gray-700"}>
                              {alert.isActive ? (
                                <>
                                  <CheckCircle className="h-3 w-3 mr-1" />
                                  Active
                                </>
                              ) : (
                                <>
                                  <AlertCircle className="h-3 w-3 mr-1" />
                                  Paused
                                </>
                              )}
                            </Badge>
                            {alert.newJobs > 0 && (
                              <Badge className="bg-sky-100 text-sky-700">
                                {alert.newJobs} new
                              </Badge>
                            )}
                          </div>
                          <div className="flex gap-2">
                            <Button variant="outline" size="sm">
                              <Edit className="h-4 w-4" />
                            </Button>
                            <Button variant="outline" size="sm">
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>

                        <div className="grid grid-cols-2 gap-4 text-sm mb-3">
                          <div className="flex items-center gap-2">
                            <Search className="h-4 w-4 text-gray-400" />
                            <span className="text-gray-600">Keywords:</span>
                            <span className="font-medium">{alert.keywords}</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <MapPin className="h-4 w-4 text-gray-400" />
                            <span className="text-gray-600">Location:</span>
                            <span className="font-medium">{alert.location}</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <DollarSign className="h-4 w-4 text-gray-400" />
                            <span className="text-gray-600">Salary:</span>
                            <span className="font-medium">{alert.salaryRange}</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <Clock className="h-4 w-4 text-gray-400" />
                            <span className="text-gray-600">Frequency:</span>
                            <span className="font-medium capitalize">{alert.frequency}</span>
                          </div>
                        </div>

                        <div className="flex justify-between items-center text-xs text-gray-500">
                          <span>Created: {alert.createdAt}</span>
                          <span>Last sent: {alert.lastSent}</span>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Recent Matches */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Briefcase className="h-5 w-5 text-sky-600" />
                  Recent Matches
                </CardTitle>
                <CardDescription>Latest job opportunities matching your alerts</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {recentMatches.map((job) => (
                    <div key={job.id} className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50 transition-colors">
                      <div className="flex-1">
                        <div className="flex items-center gap-3 mb-2">
                          <h4 className="font-medium text-gray-900">{job.title}</h4>
                          <Badge variant="outline" className="text-xs">
                            From: {job.alertName}
                          </Badge>
                        </div>
                        <div className="flex items-center gap-4 text-sm text-gray-600">
                          <span>{job.company}</span>
                          <span>•</span>
                          <span>{job.location}</span>
                          <span>•</span>
                          <span>{job.salary}</span>
                          <span>•</span>
                          <span>{job.postedAt}</span>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className={`text-lg font-bold ${getMatchScoreColor(job.matchScore)}`}>
                          {job.matchScore}%
                        </div>
                        <div className="text-xs text-gray-500">Match</div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}

export default function JobAlerts() {
  const config = platformConfigs.candidate;
  
  const usageData = [
    { label: "Active Alerts", current: 5, max: 10 },
    { label: "Matches Today", current: 3, max: 20 },
    { label: "Alert Accuracy", current: 85, max: 100 },
  ];

  return (
    <PlatformLayout
      sidebarTitle={config.sidebarTitle}
      sidebarSubtitle={config.sidebarSubtitle}
      sidebarSections={config.sidebarSections}
      usageData={usageData}
    >
      <JobAlertsContent />
    </PlatformLayout>
  );
}

