import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import PlatformLayout from "@/components/layout/platform-layout";
import { platformConfigs } from "@/config/navigation";
import { 
  BarChart3, 
  Users, 
  FileText, 
  TrendingUp, 
  Brain, 
  Award, 
  Briefcase, 
  Clock, 
  CheckCircle, 
  Target, 
  Star, 
  MapPin,
  Calendar,
  DollarSign,
  Send,
  Eye,
  ArrowRight,
  Play,
  BookOpen,
  Trophy,
  Zap,
  Filter,
  Heart,
  Building2,
  TrendingDown
} from "lucide-react";

export default function CandidateDashboard() {
  const config = platformConfigs.candidate;

  // Job Matching Data
  const jobMatchingScore = 92;
  const topJobMatches = [
    {
      id: 1,
      company: "TechCorp Solutions",
      position: "Senior Full Stack Developer",
      match: 95,
      salary: "₹15-25 LPA",
      location: "Bangalore",
      type: "Full-time",
      posted: "2 days ago",
      skills: ["React", "Node.js", "TypeScript"],
      companyLogo: "bg-blue-500"
    },
    {
      id: 2,
      company: "Innovation Labs",
      position: "Frontend Engineer",
      match: 89,
      salary: "₹12-20 LPA",
      location: "Mumbai",
      type: "Full-time", 
      posted: "1 day ago",
      skills: ["React", "Vue.js", "CSS"],
      companyLogo: "bg-green-500"
    },
    {
      id: 3,
      company: "StartupXYZ",
      position: "React Developer",
      match: 87,
      salary: "₹10-18 LPA",
      location: "Pune",
      type: "Remote",
      posted: "3 days ago",
      skills: ["React", "Redux", "Jest"],
      companyLogo: "bg-purple-500"
    }
  ];

  // Application Pipeline Data
  const applicationStats = [
    { stage: "Applied", count: 15, color: "bg-blue-500", icon: Send },
    { stage: "Screening", count: 8, color: "bg-yellow-500", icon: Eye },
    { stage: "Interview", count: 4, color: "bg-orange-500", icon: Users },
    { stage: "Offer", count: 2, color: "bg-green-500", icon: Trophy }
  ];

  // Skill Radar Chart Data
  const skillCategories = [
    { category: "Frontend", score: 88, color: "text-blue-600", bgColor: "bg-blue-500" },
    { category: "Backend", score: 72, color: "text-green-600", bgColor: "bg-green-500" },
    { category: "Database", score: 65, color: "text-purple-600", bgColor: "bg-purple-500" },
    { category: "DevOps", score: 45, color: "text-orange-600", bgColor: "bg-orange-500" },
    { category: "Mobile", score: 38, color: "text-pink-600", bgColor: "bg-pink-500" },
    { category: "Testing", score: 78, color: "text-indigo-600", bgColor: "bg-indigo-500" }
  ];

  // Certification Progress
  const certificationProgress = [
    { name: "React Developer", progress: 85, icon: "⚛️", color: "bg-blue-500" },
    { name: "AWS Solutions", progress: 60, icon: "☁️", color: "bg-orange-500" },
    { name: "Node.js Expert", progress: 40, icon: "🟢", color: "bg-green-500" }
  ];

  // Recent Assessment Results
  const recentAssessments = [
    { name: "JavaScript Fundamentals", score: 87, date: "2 days ago", trend: "up", badge: "🏆" },
    { name: "React Advanced", score: 78, date: "1 week ago", trend: "up", badge: "⭐" },
    { name: "System Design", score: 65, date: "2 weeks ago", trend: "down", badge: "📊" }
  ];

  // Salary Analytics
  const salaryData = [
    { role: "Your Target", amount: 18, color: "bg-sky-500" },
    { role: "Market Average", amount: 15, color: "bg-gray-400" },
    { role: "Top 10%", amount: 25, color: "bg-green-500" }
  ];

  // Personalized Job Recommendations
  const recommendedJobs = [
    {
      id: 1,
      title: "Senior Frontend Developer",
      company: "TechFlow Solutions",
      logo: "🚀",
      location: "San Francisco, CA",
      salary: "$120k - $150k",
      match: 94,
      type: "Full-time",
      posted: "2 days ago",
      skills: ["React", "TypeScript", "Node.js"],
      benefits: ["Remote Work", "Health Insurance", "Stock Options"]
    },
    {
      id: 2,
      title: "Full Stack Engineer",
      company: "Innovation Labs",
      logo: "💡",
      location: "New York, NY",
      salary: "$110k - $140k",
      match: 89,
      type: "Full-time",
      posted: "1 day ago",
      skills: ["JavaScript", "Python", "AWS"],
      benefits: ["Flexible Hours", "Learning Budget", "Gym Membership"]
    },
    {
      id: 3,
      title: "React Developer",
      company: "StartupXYZ",
      logo: "⭐",
      location: "Austin, TX",
      salary: "$100k - $130k",
      match: 87,
      type: "Contract",
      posted: "3 days ago",
      skills: ["React", "Redux", "GraphQL"],
      benefits: ["Remote First", "Equity", "Unlimited PTO"]
    },
    {
      id: 4,
      title: "Software Engineer",
      company: "MegaCorp Inc",
      logo: "🏢",
      location: "Seattle, WA",
      salary: "$130k - $160k",
      match: 85,
      type: "Full-time",
      posted: "4 days ago",
      skills: ["Java", "Spring", "Microservices"],
      benefits: ["401k Match", "Paid Training", "Relocation Bonus"]
    }
  ];

  // Recent Activity Feed
  const recentActivities = [
    {
      id: 1,
      type: "application",
      title: "Applied to Senior Full Stack Developer",
      company: "TechCorp Solutions",
      time: "2 hours ago",
      icon: Send,
      color: "bg-blue-500",
      status: "success"
    },
    {
      id: 2,
      type: "assessment",
      title: "Completed JavaScript Fundamentals Test",
      score: "87%",
      time: "5 hours ago",
      icon: Brain,
      color: "bg-purple-500",
      status: "success"
    },
    {
      id: 3,
      type: "profile",
      title: "Updated Professional Experience",
      section: "Work History",
      time: "1 day ago",
      icon: FileText,
      color: "bg-green-500",
      status: "success"
    },
    {
      id: 4,
      type: "interview",
      title: "Interview Scheduled",
      company: "Innovation Labs",
      time: "2 days ago",
      icon: Calendar,
      color: "bg-orange-500",
      status: "pending"
    },
    {
      id: 5,
      type: "certification",
      title: "AWS Solutions Architect Progress",
      progress: "60% Complete",
      time: "3 days ago",
      icon: Award,
      color: "bg-indigo-500",
      status: "progress"
    },
    {
      id: 6,
      type: "job_alert",
      title: "New Job Match Found",
      match: "89% Match",
      time: "4 days ago",
      icon: Target,
      color: "bg-emerald-500",
      status: "info"
    }
  ];

  return (
    <PlatformLayout
      sidebarTitle={config.sidebarTitle}
      sidebarSubtitle={config.sidebarSubtitle}
      sidebarSections={config.sidebarSections}
    >
      <div className="max-w-7xl mx-auto px-6 py-8 space-y-8">
        {/* Hero Section - Job Matching Score */}
        <div className="bg-gradient-to-r from-sky-500 to-blue-600 rounded-2xl p-8 text-white relative overflow-hidden">
          <div className="absolute inset-0 bg-black/10"></div>
          <div className="relative z-10 flex items-center justify-between">
            <div className="flex-1">
              <h1 className="text-4xl font-bold mb-2">Welcome back, John!</h1>
              <p className="text-sky-100 text-lg">Your job matching score is looking great today</p>
            </div>
            
            {/* Job Matching Score Circle */}
            <div className="relative">
              <div className="w-32 h-32 rounded-full bg-white/20 backdrop-blur-sm flex items-center justify-center">
                <div className="text-center">
                  <div className="text-3xl font-bold">{jobMatchingScore}%</div>
                  <div className="text-sm text-sky-100">Match Score</div>
                </div>
              </div>
              <div className="absolute -top-2 -right-2">
                <div className="w-8 h-8 bg-green-400 rounded-full flex items-center justify-center">
                  <TrendingUp className="w-4 h-4 text-white" />
                </div>
              </div>
            </div>
          </div>
          
          {/* Quick Action Buttons */}
          <div className="mt-6 flex gap-4">
            <Button className="bg-white/20 hover:bg-white/30 text-white border-white/30">
              <Target className="w-4 h-4 mr-2" />
              Find Jobs
            </Button>
            <Button className="bg-white/20 hover:bg-white/30 text-white border-white/30">
              <Play className="w-4 h-4 mr-2" />
              Take Assessment
            </Button>
          </div>
        </div>

        {/* Application Pipeline Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          {applicationStats.map((stat, index) => {
            const IconComponent = stat.icon;
            return (
              <Card key={index} className="bg-white hover:shadow-lg transition-all duration-300">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between mb-4">
                    <div className={`w-12 h-12 ${stat.color} rounded-lg flex items-center justify-center`}>
                      <IconComponent className="w-6 h-6 text-white" />
                    </div>
                    <div className="text-right">
                      <div className="text-2xl font-bold text-gray-900">{stat.count}</div>
                      <div className="text-sm text-gray-600">{stat.stage}</div>
                    </div>
                  </div>
                  <Progress value={(stat.count / 15) * 100} className="h-2" />
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* Main Content Grid - Jobs (70%) + Assessments (30%) */}
        <div className="grid grid-cols-1 lg:grid-cols-10 gap-8">
          {/* Job Section (70% width) */}
          <div className="lg:col-span-7 space-y-6">
            {/* Top Job Matches */}
            <Card className="bg-white overflow-hidden">
              <CardHeader className="bg-gradient-to-r from-green-50 to-emerald-50 border-b">
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle className="text-xl text-green-800">Top Job Matches</CardTitle>
                    <CardDescription>AI-powered recommendations based on your profile</CardDescription>
                  </div>
                  <Button variant="outline" className="text-green-600 border-green-200">
                    <Filter className="w-4 h-4 mr-2" />
                    View All Jobs
                  </Button>
                </div>
              </CardHeader>
              <CardContent className="p-6 bg-white">
                <div className="space-y-4">
                  {topJobMatches.map((job) => (
                    <div key={job.id} className="border border-gray-200 rounded-xl p-5 hover:shadow-md transition-all duration-300 bg-white">
                      <div className="flex items-start justify-between">
                        <div className="flex items-start space-x-4 flex-1">
                          <div className={`w-12 h-12 ${job.companyLogo} rounded-lg flex items-center justify-center`}>
                            <Building2 className="w-6 h-6 text-white" />
                          </div>
                          <div className="flex-1">
                            <h3 className="font-semibold text-gray-900 mb-1">{job.position}</h3>
                            <p className="text-gray-600 mb-2">{job.company}</p>
                            <div className="flex items-center space-x-4 text-sm text-gray-500 mb-3">
                              <div className="flex items-center">
                                <MapPin className="w-4 h-4 mr-1" />
                                {job.location}
                              </div>
                              <div className="flex items-center">
                                <DollarSign className="w-4 h-4 mr-1" />
                                {job.salary}
                              </div>
                              <div className="flex items-center">
                                <Clock className="w-4 h-4 mr-1" />
                                {job.posted}
                              </div>
                            </div>
                            <div className="flex flex-wrap gap-2">
                              {job.skills.map((skill, index) => (
                                <Badge key={index} variant="secondary" className="text-xs">
                                  {skill}
                                </Badge>
                              ))}
                            </div>
                          </div>
                        </div>
                        <div className="text-right space-y-3">
                          <div className="flex items-center">
                            <div className="w-16 h-16 rounded-full bg-gradient-to-r from-green-400 to-emerald-500 flex items-center justify-center">
                              <span className="text-white font-bold text-lg">{job.match}%</span>
                            </div>
                          </div>
                          <div className="space-y-2">
                            <Button size="sm" className="w-full bg-green-600 hover:bg-green-700">
                              <Send className="w-4 h-4 mr-2" />
                              Apply
                            </Button>
                            <Button size="sm" variant="outline" className="w-full">
                              <Heart className="w-4 h-4 mr-2" />
                              Save
                            </Button>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Salary Analytics Chart */}
            <Card className="bg-white">
              <CardHeader>
                <CardTitle className="text-xl text-gray-800">Salary Analytics</CardTitle>
                <CardDescription>Compare your target with market rates</CardDescription>
              </CardHeader>
              <CardContent className="bg-white">
                <div className="space-y-4">
                  {salaryData.map((item, index) => (
                    <div key={index} className="flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <div className={`w-4 h-4 ${item.color} rounded`}></div>
                        <span className="font-medium text-gray-700">{item.role}</span>
                      </div>
                      <div className="flex items-center space-x-4">
                        <div className={`h-8 ${item.color} rounded`} style={{width: `${(item.amount / 25) * 200}px`}}></div>
                        <span className="font-bold text-gray-900 min-w-[60px]">₹{item.amount}L</span>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Assessment Section (30% width) */}
          <div className="lg:col-span-3 space-y-6">
            {/* Skill Radar Chart */}
            <Card className="bg-white">
              <CardHeader className="bg-gradient-to-r from-purple-50 to-indigo-50 border-b">
                <CardTitle className="text-xl text-purple-800">Skill Assessment</CardTitle>
                <CardDescription>Your expertise across different technology areas</CardDescription>
              </CardHeader>
              <CardContent className="p-6 bg-white">
                <div className="space-y-4">
                  {skillCategories.map((category, index) => (
                    <div key={index} className="relative">
                      <div className="flex items-center justify-between mb-2">
                        <span className={`font-medium ${category.color}`}>{category.category}</span>
                        <span className="text-sm font-bold text-gray-900">{category.score}%</span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-3">
                        <div 
                          className={`h-3 rounded-full ${category.bgColor}`}
                          style={{width: `${category.score}%`}}
                        ></div>
                      </div>
                    </div>
                  ))}
                </div>
                <Button className="w-full mt-6 bg-purple-600 hover:bg-purple-700">
                  <Brain className="w-4 h-4 mr-2" />
                  Improve Skills
                </Button>
              </CardContent>
            </Card>

            {/* Certification Progress */}
            <Card className="bg-white">
              <CardHeader>
                <CardTitle className="text-xl text-gray-800">Certification Progress</CardTitle>
                <CardDescription>Track your learning achievements</CardDescription>
              </CardHeader>
              <CardContent className="p-6 bg-white">
                <div className="space-y-4">
                  {certificationProgress.map((cert, index) => (
                    <div key={index} className="border border-gray-200 rounded-lg p-4 bg-white">
                      <div className="flex items-center justify-between mb-3">
                        <div className="flex items-center space-x-3">
                          <span className="text-2xl">{cert.icon}</span>
                          <div>
                            <h4 className="font-medium text-gray-900">{cert.name}</h4>
                            <p className="text-sm text-gray-600">{cert.progress}% complete</p>
                          </div>
                        </div>
                        <div className={`w-12 h-12 ${cert.color} rounded-full flex items-center justify-center`}>
                          <span className="text-white font-bold text-sm">{cert.progress}%</span>
                        </div>
                      </div>
                      <Progress value={cert.progress} className="h-2" />
                    </div>
                  ))}
                </div>
                <Button variant="outline" className="w-full mt-4">
                  <BookOpen className="w-4 h-4 mr-2" />
                  Browse Certifications
                </Button>
              </CardContent>
            </Card>

            {/* Recent Assessment Results */}
            <Card className="bg-white">
              <CardHeader>
                <CardTitle className="text-xl text-gray-800">Recent Results</CardTitle>
                <CardDescription>Your latest assessment performance</CardDescription>
              </CardHeader>
              <CardContent className="p-6 bg-white">
                <div className="space-y-4">
                  {recentAssessments.map((assessment, index) => (
                    <div key={index} className="flex items-center justify-between p-3 border border-gray-200 rounded-lg bg-white">
                      <div className="flex items-center space-x-3">
                        <span className="text-xl">{assessment.badge}</span>
                        <div>
                          <h4 className="font-medium text-gray-900 text-sm">{assessment.name}</h4>
                          <p className="text-xs text-gray-600">{assessment.date}</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="flex items-center space-x-2">
                          <span className="font-bold text-gray-900">{assessment.score}%</span>
                          {assessment.trend === "up" ? (
                            <TrendingUp className="w-4 h-4 text-green-500" />
                          ) : (
                            <TrendingDown className="w-4 h-4 text-red-500" />
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
                <Button variant="outline" className="w-full mt-4">
                  <BarChart3 className="w-4 h-4 mr-2" />
                  View All Results
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Personalized Job Recommendations */}
        <Card className="bg-white">
          <CardHeader>
            <CardTitle className="text-xl text-gray-800">Recommended for You</CardTitle>
            <CardDescription>Jobs matching your skills and preferences • Updated daily</CardDescription>
          </CardHeader>
          <CardContent className="p-6 bg-white">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {recommendedJobs.map((job) => (
                <div key={job.id} className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow cursor-pointer group">
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex items-center space-x-3">
                      <div className="w-12 h-12 bg-gray-100 rounded-lg flex items-center justify-center text-2xl">
                        {job.logo}
                      </div>
                      <div>
                        <h4 className="font-semibold text-gray-900 group-hover:text-sky-600 transition-colors">{job.title}</h4>
                        <p className="text-sm text-gray-600">{job.company}</p>
                      </div>
                    </div>
                    <div className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${
                      job.match >= 90 ? 'bg-green-100 text-green-800' :
                      job.match >= 85 ? 'bg-blue-100 text-blue-800' :
                      'bg-yellow-100 text-yellow-800'
                    }`}>
                      {job.match}% match
                    </div>
                  </div>
                  
                  <div className="space-y-2 mb-4">
                    <div className="flex items-center text-sm text-gray-600">
                      <MapPin className="w-4 h-4 mr-1" />
                      {job.location}
                      <span className="mx-2">•</span>
                      <span className="font-medium text-green-600">{job.salary}</span>
                    </div>
                    <div className="flex items-center text-sm text-gray-600">
                      <Briefcase className="w-4 h-4 mr-1" />
                      {job.type}
                      <span className="mx-2">•</span>
                      <Clock className="w-4 h-4 mr-1" />
                      {job.posted}
                    </div>
                  </div>

                  <div className="space-y-2">
                    <div className="flex flex-wrap gap-1">
                      {job.skills.slice(0, 3).map((skill, index) => (
                        <span key={index} className="inline-flex items-center px-2 py-1 rounded-md text-xs font-medium bg-sky-100 text-sky-800">
                          {skill}
                        </span>
                      ))}
                    </div>
                    <div className="flex flex-wrap gap-1">
                      {job.benefits.slice(0, 2).map((benefit, index) => (
                        <span key={index} className="inline-flex items-center px-2 py-1 rounded-md text-xs font-medium bg-gray-100 text-gray-700">
                          {benefit}
                        </span>
                      ))}
                    </div>
                  </div>

                  <div className="mt-4 flex space-x-2">
                    <Button size="sm" className="flex-1 bg-sky-500 hover:bg-sky-600 text-white">
                      <Send className="w-4 h-4 mr-1" />
                      Apply Now
                    </Button>
                    <Button size="sm" variant="outline" className="border-gray-300 text-gray-600 hover:bg-gray-50">
                      <Heart className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
            <div className="mt-6 flex justify-center">
              <Button variant="outline" className="text-gray-600 border-gray-300">
                <Eye className="w-4 h-4 mr-2" />
                View All Job Matches
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Recent Activity Feed */}
        <Card className="bg-white">
          <CardHeader>
            <CardTitle className="text-xl text-gray-800">Recent Activity</CardTitle>
            <CardDescription>Your latest actions and achievements across the platform</CardDescription>
          </CardHeader>
          <CardContent className="p-6 bg-white">
            <div className="space-y-4">
              {recentActivities.map((activity) => {
                const IconComponent = activity.icon;
                return (
                  <div key={activity.id} className="flex items-start space-x-4 p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors cursor-pointer">
                    <div className={`w-10 h-10 ${activity.color} rounded-full flex items-center justify-center flex-shrink-0`}>
                      <IconComponent className="w-5 h-5 text-white" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <h4 className="font-medium text-gray-900 mb-1">{activity.title}</h4>
                          <div className="flex items-center space-x-4 text-sm text-gray-600">
                            {activity.company && (
                              <span className="flex items-center">
                                <Building2 className="w-4 h-4 mr-1" />
                                {activity.company}
                              </span>
                            )}
                            {activity.score && (
                              <span className="flex items-center">
                                <Trophy className="w-4 h-4 mr-1" />
                                {activity.score}
                              </span>
                            )}
                            {activity.section && (
                              <span className="flex items-center">
                                <FileText className="w-4 h-4 mr-1" />
                                {activity.section}
                              </span>
                            )}
                            {activity.progress && (
                              <span className="flex items-center">
                                <BarChart3 className="w-4 h-4 mr-1" />
                                {activity.progress}
                              </span>
                            )}
                            {activity.match && (
                              <span className="flex items-center">
                                <Target className="w-4 h-4 mr-1" />
                                {activity.match}
                              </span>
                            )}
                          </div>
                        </div>
                        <div className="text-right flex-shrink-0 ml-4">
                          <div className="text-xs text-gray-500">{activity.time}</div>
                          <div className={`mt-1 inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${
                            activity.status === 'success' ? 'bg-green-100 text-green-800' :
                            activity.status === 'pending' ? 'bg-yellow-100 text-yellow-800' :
                            activity.status === 'progress' ? 'bg-blue-100 text-blue-800' :
                            'bg-gray-100 text-gray-800'
                          }`}>
                            {activity.status === 'success' ? '✓ Complete' :
                             activity.status === 'pending' ? '⏳ Pending' :
                             activity.status === 'progress' ? '🔄 In Progress' :
                             'ℹ️ New'}
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
            <div className="mt-6 flex justify-center">
              <Button variant="outline" className="text-gray-600 border-gray-300">
                <Clock className="w-4 h-4 mr-2" />
                View All Activity
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Footer Call-to-Action */}
        <Card className="bg-white">
          <CardContent className="p-8 text-center">
            <h3 className="text-2xl font-bold text-gray-900 mb-2">Ready to Level Up Your Career?</h3>
            <p className="text-gray-600 mb-6">Take our comprehensive skill assessment to unlock better job matches and higher salary potential.</p>
            <div className="flex justify-center space-x-4">
              <Button className="bg-sky-600 hover:bg-sky-700 text-white px-8 py-3 rounded-xl font-semibold shadow-lg hover:shadow-xl transition-all duration-300">
                <Target className="w-5 h-5 mr-2" />
                Start Assessment
              </Button>
              <Button variant="outline" className="border border-sky-200 text-sky-700 hover:bg-sky-50 px-8 py-3 rounded-xl font-semibold">
                <Briefcase className="w-5 h-5 mr-2" />
                Explore Jobs
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </PlatformLayout>
  );
}