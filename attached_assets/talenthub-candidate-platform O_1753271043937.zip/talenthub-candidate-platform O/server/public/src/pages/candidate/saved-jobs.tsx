import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { 
  Star, 
  Search, 
  Filter, 
  Building, 
  MapPin, 
  DollarSign, 
  Clock,
  Briefcase,
  Eye,
  ExternalLink,
  Trash2,
  Calendar,
  Users,
  TrendingUp,
  BookmarkMinus
} from "lucide-react";
import PlatformLayout from "@/components/layout/platform-layout";
import { platformConfigs } from "@/config/complete-navigation";

function SavedJobsContent() {
  const [searchTerm, setSearchTerm] = useState("");
  const [sortBy, setSortBy] = useState("saved_date");
  const [filterBy, setFilterBy] = useState("all");

  const savedJobs = [
    {
      id: "1",
      title: "Senior Frontend Developer",
      company: "TechCorp Inc.",
      location: "San Francisco, CA",
      salary: "$130,000 - $160,000",
      type: "Full-time",
      remote: true,
      savedAt: "2024-01-20",
      postedAt: "2024-01-18",
      applicants: 47,
      status: "active",
      skills: ["React", "TypeScript", "Node.js"],
      description: "We're looking for a passionate Senior Frontend Developer to join our growing team...",
      applied: false,
      matchScore: 95
    },
    {
      id: "2",
      title: "Full Stack Engineer",
      company: "StartupXYZ",
      location: "Remote",
      salary: "$120,000 - $150,000",
      type: "Full-time",
      remote: true,
      savedAt: "2024-01-19",
      postedAt: "2024-01-15",
      applicants: 32,
      status: "active",
      skills: ["React", "Python", "AWS"],
      description: "Join our innovative team building the next generation of...",
      applied: true,
      matchScore: 88
    },
    {
      id: "3",
      title: "UI/UX Developer",
      company: "Design Studio",
      location: "New York, NY",
      salary: "$95,000 - $125,000",
      type: "Full-time",
      remote: false,
      savedAt: "2024-01-17",
      postedAt: "2024-01-12",
      applicants: 89,
      status: "closing_soon",
      skills: ["Figma", "React", "CSS"],
      description: "Creative UI/UX Developer needed to craft beautiful user experiences...",
      applied: false,
      matchScore: 82
    },
    {
      id: "4",
      title: "Backend Developer",
      company: "Enterprise Corp",
      location: "Seattle, WA",
      salary: "$115,000 - $145,000",
      type: "Contract",
      remote: true,
      savedAt: "2024-01-15",
      postedAt: "2024-01-10",
      applicants: 64,
      status: "expired",
      skills: ["Node.js", "MongoDB", "Docker"],
      description: "Looking for an experienced Backend Developer to work on...",
      applied: false,
      matchScore: 76
    }
  ];

  const getStatusBadge = (status: string, applied: boolean) => {
    if (applied) {
      return <Badge className="bg-blue-100 text-blue-700">Applied</Badge>;
    }
    
    switch (status) {
      case "active":
        return <Badge className="bg-green-100 text-green-700">Active</Badge>;
      case "closing_soon":
        return <Badge className="bg-orange-100 text-orange-700">Closing Soon</Badge>;
      case "expired":
        return <Badge className="bg-red-100 text-red-700">Expired</Badge>;
      default:
        return <Badge className="bg-gray-100 text-gray-700">Unknown</Badge>;
    }
  };

  const getMatchScoreColor = (score: number) => {
    if (score >= 90) return "text-green-600";
    if (score >= 80) return "text-yellow-600";
    return "text-red-600";
  };

  const filteredJobs = savedJobs.filter(job => {
    const matchesSearch = job.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         job.company.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         job.skills.some(skill => skill.toLowerCase().includes(searchTerm.toLowerCase()));
    
    if (filterBy === "all") return matchesSearch;
    if (filterBy === "applied") return matchesSearch && job.applied;
    if (filterBy === "not_applied") return matchesSearch && !job.applied;
    if (filterBy === "remote") return matchesSearch && job.remote;
    if (filterBy === "active") return matchesSearch && job.status === "active";
    
    return matchesSearch;
  });

  const stats = {
    total: savedJobs.length,
    applied: savedJobs.filter(job => job.applied).length,
    active: savedJobs.filter(job => job.status === "active").length,
    remote: savedJobs.filter(job => job.remote).length
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-sky-50 to-white p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Saved Jobs</h1>
          <p className="text-gray-600">Keep track of interesting job opportunities for future reference</p>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card className="border-sky-200">
            <CardContent className="p-6 text-center">
              <Star className="h-8 w-8 text-sky-600 mx-auto mb-2" />
              <div className="text-2xl font-bold text-sky-700">{stats.total}</div>
              <div className="text-sm text-gray-600">Total Saved</div>
            </CardContent>
          </Card>
          <Card className="border-blue-200">
            <CardContent className="p-6 text-center">
              <Briefcase className="h-8 w-8 text-blue-600 mx-auto mb-2" />
              <div className="text-2xl font-bold text-blue-700">{stats.applied}</div>
              <div className="text-sm text-gray-600">Applied</div>
            </CardContent>
          </Card>
          <Card className="border-green-200">
            <CardContent className="p-6 text-center">
              <TrendingUp className="h-8 w-8 text-green-600 mx-auto mb-2" />
              <div className="text-2xl font-bold text-green-700">{stats.active}</div>
              <div className="text-sm text-gray-600">Still Active</div>
            </CardContent>
          </Card>
          <Card className="border-purple-200">
            <CardContent className="p-6 text-center">
              <Users className="h-8 w-8 text-purple-600 mx-auto mb-2" />
              <div className="text-2xl font-bold text-purple-700">{stats.remote}</div>
              <div className="text-sm text-gray-600">Remote Jobs</div>
            </CardContent>
          </Card>
        </div>

        {/* Filters */}
        <Card className="mb-6">
          <CardContent className="p-6">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="flex-1">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                  <Input
                    placeholder="Search saved jobs by title, company, or skills..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                  />
                </div>
              </div>
              <div className="flex gap-4">
                <Select value={filterBy} onValueChange={setFilterBy}>
                  <SelectTrigger className="w-48">
                    <Filter className="h-4 w-4 mr-2" />
                    <SelectValue placeholder="Filter by" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Jobs</SelectItem>
                    <SelectItem value="applied">Applied</SelectItem>
                    <SelectItem value="not_applied">Not Applied</SelectItem>
                    <SelectItem value="remote">Remote Only</SelectItem>
                    <SelectItem value="active">Active Jobs</SelectItem>
                  </SelectContent>
                </Select>
                <Select value={sortBy} onValueChange={setSortBy}>
                  <SelectTrigger className="w-48">
                    <SelectValue placeholder="Sort by" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="saved_date">Date Saved</SelectItem>
                    <SelectItem value="posted_date">Date Posted</SelectItem>
                    <SelectItem value="match_score">Match Score</SelectItem>
                    <SelectItem value="salary">Salary</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Saved Jobs List */}
        <div className="space-y-4">
          {filteredJobs.length === 0 ? (
            <Card>
              <CardContent className="p-12 text-center">
                <Star className="h-16 w-16 text-gray-300 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-gray-900 mb-2">No saved jobs found</h3>
                <p className="text-gray-600">Try adjusting your search criteria or browse new jobs to save.</p>
              </CardContent>
            </Card>
          ) : (
            filteredJobs.map((job) => (
              <Card key={job.id} className="hover:shadow-lg transition-shadow">
                <CardContent className="p-6">
                  <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
                    {/* Main Job Info */}
                    <div className="flex-1">
                      <div className="flex items-start justify-between mb-3">
                        <div>
                          <h3 className="text-lg font-semibold text-gray-900 mb-1">
                            {job.title}
                          </h3>
                          <div className="flex items-center gap-4 text-sm text-gray-600">
                            <div className="flex items-center gap-1">
                              <Building className="h-4 w-4" />
                              {job.company}
                            </div>
                            <div className="flex items-center gap-1">
                              <MapPin className="h-4 w-4" />
                              {job.location}
                            </div>
                            <div className="flex items-center gap-1">
                              <Briefcase className="h-4 w-4" />
                              {job.type}
                            </div>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          {getStatusBadge(job.status, job.applied)}
                          <div className={`text-lg font-bold ${getMatchScoreColor(job.matchScore)}`}>
                            {job.matchScore}%
                          </div>
                        </div>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4 text-sm">
                        <div className="flex items-center gap-1">
                          <DollarSign className="h-4 w-4 text-gray-400" />
                          <span className="font-medium text-green-600">{job.salary}</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <Users className="h-4 w-4 text-gray-400" />
                          <span>{job.applicants} applicants</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <Clock className="h-4 w-4 text-gray-400" />
                          <span>Posted {job.postedAt}</span>
                        </div>
                      </div>

                      <div className="mb-4">
                        <p className="text-sm text-gray-600 mb-2">{job.description}</p>
                        <div className="flex flex-wrap gap-2">
                          {job.skills.map((skill) => (
                            <Badge key={skill} variant="outline" className="text-xs">
                              {skill}
                            </Badge>
                          ))}
                          {job.remote && (
                            <Badge className="text-xs bg-purple-100 text-purple-700">
                              Remote
                            </Badge>
                          )}
                        </div>
                      </div>

                      <div className="text-xs text-gray-500">
                        Saved on {job.savedAt}
                      </div>
                    </div>

                    {/* Actions */}
                    <div className="flex flex-col gap-2 lg:w-48">
                      <Button 
                        className="w-full bg-sky-600 hover:bg-sky-700" 
                        disabled={job.applied || job.status === "expired"}
                      >
                        {job.applied ? "Applied" : job.status === "expired" ? "Expired" : "Apply Now"}
                      </Button>
                      <Button variant="outline" className="w-full">
                        <Eye className="h-4 w-4 mr-2" />
                        View Details
                      </Button>
                      <div className="flex gap-2">
                        <Button variant="outline" size="sm" className="flex-1">
                          <ExternalLink className="h-4 w-4 mr-2" />
                          Original
                        </Button>
                        <Button variant="outline" size="sm" className="flex-1">
                          <BookmarkMinus className="h-4 w-4 mr-2" />
                          Unsave
                        </Button>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))
          )}
        </div>

        {/* Quick Actions */}
        {filteredJobs.length > 0 && (
          <Card className="mt-6">
            <CardContent className="p-6">
              <div className="flex justify-between items-center">
                <div>
                  <h3 className="font-medium text-gray-900">Bulk Actions</h3>
                  <p className="text-sm text-gray-600">Manage multiple saved jobs at once</p>
                </div>
                <div className="flex gap-3">
                  <Button variant="outline">
                    Remove Expired Jobs
                  </Button>
                  <Button variant="outline">
                    Export to CSV
                  </Button>
                  <Button className="bg-sky-600 hover:bg-sky-700">
                    Apply to Selected
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}

export default function SavedJobs() {
  const config = platformConfigs.candidate;
  
  const usageData = [
    { label: "Saved Jobs", current: 12, max: 50 },
    { label: "Applied", current: 8, max: 25 },
    { label: "Shortlisted", current: 3, max: 10 },
  ];

  return (
    <PlatformLayout
      sidebarTitle={config.sidebarTitle}
      sidebarSubtitle={config.sidebarSubtitle}
      sidebarSections={config.sidebarSections}
      usageData={usageData}
    >
      <SavedJobsContent />
    </PlatformLayout>
  );
}

