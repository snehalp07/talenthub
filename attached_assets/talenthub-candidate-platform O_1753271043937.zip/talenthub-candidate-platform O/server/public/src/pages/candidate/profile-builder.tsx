import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Link } from "wouter";
import { platformConfigs } from "@/config/complete-navigation";
import PlatformLayout from "@/components/layout/platform-layout";
import { useThemeClasses } from "@/lib/theme-config";
import { 
  Save, Plus, X, Eye, Share, ExternalLink, Mail, ChevronLeft,
  User, MapPin, Phone, Globe, Linkedin, Briefcase, GraduationCap,
  Award, Calendar, Building, Code, Sparkles
} from "lucide-react";

// Types
type ProfileFormData = {
  bio: string;
  professionalSummary: string;
  phone: string;
  location: string;
  linkedinUrl: string;
  profilePhoto: string;
};

type ExperienceFormData = {
  company: string;
  position: string;
  startDate: string;
  endDate: string;
  description: string;
  current: boolean;
};

type EducationFormData = {
  institution: string;
  degree: string;
  fieldOfStudy: string;
  startDate: string;
  endDate: string;
  description: string;
};

type SkillFormData = {
  name: string;
  level: string;
  category: string;
};

type ProjectFormData = {
  title: string;
  description: string;
  technologies: string;
  githubUrl: string;
  demoUrl: string;
  startDate: string;
  endDate: string;
  status: string;
};

type AchievementFormData = {
  title: string;
  description: string;
  date: string;
  category: string;
  issuer: string;
};

function ProfileBuilderContent() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // State management
  const [sharePopupOpen, setSharePopupOpen] = useState(false);
  const [aiOptimizeLoading, setAiOptimizeLoading] = useState(false);
  const [optimizedContent, setOptimizedContent] = useState<any>(null);

  // Form states
  const [profileData, setProfileData] = useState<ProfileFormData>({
    bio: "",
    professionalSummary: "",
    phone: "",
    location: "",
    linkedinUrl: "",
    profilePhoto: ""
  });

  const [experienceData, setExperienceData] = useState<ExperienceFormData>({
    company: "",
    position: "",
    startDate: "",
    endDate: "",
    description: "",
    current: false
  });

  const [educationData, setEducationData] = useState<EducationFormData>({
    institution: "",
    degree: "",
    fieldOfStudy: "",
    startDate: "",
    endDate: "",
    description: ""
  });

  const [skillData, setSkillData] = useState<SkillFormData>({
    name: "",
    level: "beginner",
    category: "technical"
  });

  const [projectData, setProjectData] = useState<ProjectFormData>({
    title: "",
    description: "",
    technologies: "",
    githubUrl: "",
    demoUrl: "",
    startDate: "",
    endDate: "",
    status: "in_progress"
  });

  const [achievementData, setAchievementData] = useState<AchievementFormData>({
    title: "",
    description: "",
    date: "",
    category: "award",
    issuer: ""
  });

  // API queries and mutations
  const { data: profile, isLoading: profileLoading } = useQuery({
    queryKey: ["/api/profile"],
    queryFn: async () => {
      const response = await apiRequest("GET", "/api/profile");
      return response.json();
    }
  });

  const saveProfileMutation = useMutation({
    mutationFn: async (data: any) => {
      const response = await apiRequest("POST", "/api/profile", data);
      return response.json();
    },
    onSuccess: () => {
      toast({ title: "Profile saved successfully!" });
      queryClient.invalidateQueries({ queryKey: ["/api/profile"] });
    },
    onError: (error: Error) => {
      toast({ 
        title: "Error saving profile", 
        description: error.message,
        variant: "destructive" 
      });
    }
  });

  const addExperienceMutation = useMutation({
    mutationFn: async (data: ExperienceFormData) => {
      const response = await apiRequest("POST", "/api/profile/experience", data);
      return response.json();
    },
    onSuccess: () => {
      toast({ title: "Experience added successfully!" });
      queryClient.invalidateQueries({ queryKey: ["/api/profile"] });
      setExperienceData({
        company: "",
        position: "",
        startDate: "",
        endDate: "",
        description: "",
        current: false
      });
    },
    onError: (error: Error) => {
      toast({ 
        title: "Error adding experience", 
        description: error.message,
        variant: "destructive" 
      });
    }
  });

  const addEducationMutation = useMutation({
    mutationFn: async (data: EducationFormData) => {
      const response = await apiRequest("POST", "/api/profile/education", data);
      return response.json();
    },
    onSuccess: () => {
      toast({ title: "Education added successfully!" });
      queryClient.invalidateQueries({ queryKey: ["/api/profile"] });
      setEducationData({
        institution: "",
        degree: "",
        fieldOfStudy: "",
        startDate: "",
        endDate: "",
        description: ""
      });
    },
    onError: (error: Error) => {
      toast({ 
        title: "Error adding education", 
        description: error.message,
        variant: "destructive" 
      });
    }
  });

  const addSkillMutation = useMutation({
    mutationFn: async (data: SkillFormData) => {
      const response = await apiRequest("POST", "/api/profile/skills", data);
      return response.json();
    },
    onSuccess: () => {
      toast({ title: "Skill added successfully!" });
      queryClient.invalidateQueries({ queryKey: ["/api/profile"] });
      setSkillData({
        name: "",
        level: "beginner",
        category: "technical"
      });
    },
    onError: (error: Error) => {
      toast({ 
        title: "Error adding skill", 
        description: error.message,
        variant: "destructive" 
      });
    }
  });

  const addProjectMutation = useMutation({
    mutationFn: async (data: ProjectFormData) => {
      const response = await apiRequest("POST", "/api/profile/projects", data);
      return response.json();
    },
    onSuccess: () => {
      toast({ title: "Project added successfully!" });
      queryClient.invalidateQueries({ queryKey: ["/api/profile"] });
      setProjectData({
        title: "",
        description: "",
        technologies: "",
        githubUrl: "",
        demoUrl: "",
        startDate: "",
        endDate: "",
        status: "in_progress"
      });
    },
    onError: (error: Error) => {
      toast({ 
        title: "Error adding project", 
        description: error.message,
        variant: "destructive" 
      });
    }
  });

  const addAchievementMutation = useMutation({
    mutationFn: async (data: AchievementFormData) => {
      const response = await apiRequest("POST", "/api/profile/achievements", data);
      return response.json();
    },
    onSuccess: () => {
      toast({ title: "Achievement added successfully!" });
      queryClient.invalidateQueries({ queryKey: ["/api/profile"] });
      setAchievementData({
        title: "",
        description: "",
        date: "",
        category: "award",
        issuer: ""
      });
    },
    onError: (error: Error) => {
      toast({ 
        title: "Error adding achievement", 
        description: error.message,
        variant: "destructive" 
      });
    }
  });

  // Load profile data when component mounts
  useEffect(() => {
    if (profile?.profile) {
      setProfileData({
        bio: profile.profile.bio || "",
        professionalSummary: profile.profile.professionalSummary || "",
        phone: profile.profile.phone || "",
        location: profile.profile.location || "",
        linkedinUrl: profile.profile.linkedinUrl || "",
        profilePhoto: profile.profile.profilePhoto || ""
      });
    }
  }, [profile]);

  // Event handlers
  const handleSaveProfile = () => {
    saveProfileMutation.mutate(profileData);
  };

  const handleAddExperience = () => {
    if (!experienceData.company || !experienceData.position) {
      toast({
        title: "Please fill in required fields",
        description: "Company and position are required",
        variant: "destructive"
      });
      return;
    }
    addExperienceMutation.mutate(experienceData);
  };

  const handleAddEducation = () => {
    if (!educationData.institution || !educationData.degree) {
      toast({
        title: "Please fill in required fields",
        description: "Institution and degree are required",
        variant: "destructive"
      });
      return;
    }
    addEducationMutation.mutate(educationData);
  };

  const handleAddSkill = () => {
    if (!skillData.name) {
      toast({
        title: "Please enter a skill name",
        variant: "destructive"
      });
      return;
    }
    addSkillMutation.mutate(skillData);
  };

  const handleAddProject = () => {
    if (!projectData.title || !projectData.description) {
      toast({
        title: "Please fill in required fields",
        description: "Title and description are required",
        variant: "destructive"
      });
      return;
    }
    addProjectMutation.mutate(projectData);
  };

  const handleAddAchievement = () => {
    if (!achievementData.title || !achievementData.date) {
      toast({
        title: "Please fill in required fields",
        description: "Title and date are required",
        variant: "destructive"
      });
      return;
    }
    addAchievementMutation.mutate(achievementData);
  };

  const handleAiOptimize = async () => {
    setAiOptimizeLoading(true);
    try {
      const response = await apiRequest("POST", "/api/profile/ai-optimize", profileData);
      const result = await response.json();
      setOptimizedContent(result);
      toast({ title: "AI optimization completed!" });
    } catch (error: any) {
      toast({
        title: "AI optimization failed",
        description: error.message,
        variant: "destructive"
      });
    } finally {
      setAiOptimizeLoading(false);
    }
  };

  const handleApplyOptimization = () => {
    if (optimizedContent) {
      setProfileData({
        ...profileData,
        bio: optimizedContent.bio || profileData.bio,
        professionalSummary: optimizedContent.professionalSummary || profileData.professionalSummary
      });
      setOptimizedContent(null);
      toast({ title: "Optimization applied!" });
    }
  };

  // Share functionality
  const handleCopyLink = () => {
    const profileUrl = `${window.location.origin}/profile-preview`;
    navigator.clipboard.writeText(profileUrl);
    toast({ title: "Profile link copied to clipboard!" });
    setSharePopupOpen(false);
  };

  const handleLinkedInShare = () => {
    const profileUrl = `${window.location.origin}/profile-preview`;
    const linkedinUrl = `https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(profileUrl)}`;
    window.open(linkedinUrl, '_blank');
    setSharePopupOpen(false);
  };

  const handleEmailShare = () => {
    const profileUrl = `${window.location.origin}/profile-preview`;
    const subject = "Check out my professional profile";
    const body = `I'd like to share my professional profile with you: ${profileUrl}`;
    const mailtoUrl = `mailto:?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
    window.location.href = mailtoUrl;
    setSharePopupOpen(false);
  };

  if (profileLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin w-8 h-8 border-4 border-sky-500 border-t-transparent rounded-full"></div>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Profile Builder</h1>
          <p className="text-gray-600 mt-1">Create and manage your professional profile</p>
        </div>
        <div className="flex gap-3">
          <Button
                onClick={handleAiOptimize}
                disabled={aiOptimizeLoading}
                variant="outline"
                className="border-sky-500 text-sky-600 hover:bg-sky-50"
              >
                <Sparkles className="w-4 h-4 mr-2" />
                {aiOptimizeLoading ? "Optimizing..." : "AI Optimize"}
              </Button>
              <Button
                onClick={() => setSharePopupOpen(true)}
                variant="outline"
                className="border-sky-500 text-sky-600 hover:bg-sky-50"
              >
                <Share className="w-4 h-4 mr-2" />
                Share
              </Button>
              <Link href="/candidate/profile-preview">
                <Button variant="outline">
                  <Eye className="w-4 h-4 mr-2" />
                  Preview
                </Button>
              </Link>
            </div>
          </div>

          {/* AI Optimization Results */}
          {optimizedContent && (
            <Card className="border-sky-200 bg-sky-50">
              <CardHeader>
                <CardTitle className="text-sky-900 flex items-center">
                  <Sparkles className="w-5 h-5 mr-2" />
                  AI Optimization Suggestions
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {optimizedContent.bio && (
                  <div>
                    <Label className="text-sm font-medium text-sky-800">Optimized Bio:</Label>
                    <p className="text-sm text-gray-700 bg-white p-3 rounded border">{optimizedContent.bio}</p>
                  </div>
                )}
                {optimizedContent.professionalSummary && (
                  <div>
                    <Label className="text-sm font-medium text-sky-800">Optimized Professional Summary:</Label>
                    <p className="text-sm text-gray-700 bg-white p-3 rounded border">{optimizedContent.professionalSummary}</p>
                  </div>
                )}
                <div className="flex gap-2">
                  <Button onClick={handleApplyOptimization} size="sm" className="bg-sky-600 hover:bg-sky-700">
                    Apply Suggestions
                  </Button>
                  <Button onClick={() => setOptimizedContent(null)} variant="outline" size="sm">
                    Dismiss
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Profile Builder Tabs */}
          <Tabs defaultValue="basic" className="space-y-6">
            <TabsList className="grid w-full grid-cols-6">
              <TabsTrigger value="basic">Basic Info</TabsTrigger>
              <TabsTrigger value="experience">Experience</TabsTrigger>
              <TabsTrigger value="education">Education</TabsTrigger>
              <TabsTrigger value="skills">Skills</TabsTrigger>
              <TabsTrigger value="projects">Projects</TabsTrigger>
              <TabsTrigger value="achievements">Achievements</TabsTrigger>
            </TabsList>

            {/* Basic Information Tab */}
            <TabsContent value="basic">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <User className="w-5 h-5 mr-2" />
                    Basic Information
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="bio">Bio</Label>
                      <Textarea
                        id="bio"
                        placeholder="Tell us about yourself..."
                        value={profileData.bio}
                        onChange={(e) => setProfileData({ ...profileData, bio: e.target.value })}
                        rows={3}
                      />
                    </div>
                    <div>
                      <Label htmlFor="professionalSummary">Professional Summary</Label>
                      <Textarea
                        id="professionalSummary"
                        placeholder="Your professional summary..."
                        value={profileData.professionalSummary}
                        onChange={(e) => setProfileData({ ...profileData, professionalSummary: e.target.value })}
                        rows={3}
                      />
                    </div>
                    <div>
                      <Label htmlFor="phone">Phone</Label>
                      <Input
                        id="phone"
                        placeholder="+1 (555) 123-4567"
                        value={profileData.phone}
                        onChange={(e) => setProfileData({ ...profileData, phone: e.target.value })}
                      />
                    </div>
                    <div>
                      <Label htmlFor="location">Location</Label>
                      <Input
                        id="location"
                        placeholder="City, State, Country"
                        value={profileData.location}
                        onChange={(e) => setProfileData({ ...profileData, location: e.target.value })}
                      />
                    </div>
                    <div>
                      <Label htmlFor="linkedinUrl">LinkedIn URL</Label>
                      <Input
                        id="linkedinUrl"
                        placeholder="https://linkedin.com/in/yourprofile"
                        value={profileData.linkedinUrl}
                        onChange={(e) => setProfileData({ ...profileData, linkedinUrl: e.target.value })}
                      />
                    </div>
                    <div>
                      <Label htmlFor="profilePhoto">Profile Photo URL</Label>
                      <Input
                        id="profilePhoto"
                        placeholder="https://example.com/photo.jpg"
                        value={profileData.profilePhoto}
                        onChange={(e) => setProfileData({ ...profileData, profilePhoto: e.target.value })}
                      />
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Experience Tab */}
            <TabsContent value="experience">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Briefcase className="w-5 h-5 mr-2" />
                    Work Experience
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  {/* Add New Experience Form */}
                  <div className="border rounded-lg p-4 bg-gray-50">
                    <h3 className="font-medium mb-4">Add New Experience</h3>
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="company">Company *</Label>
                        <Input
                          id="company"
                          placeholder="Company name"
                          value={experienceData.company}
                          onChange={(e) => setExperienceData({ ...experienceData, company: e.target.value })}
                        />
                      </div>
                      <div>
                        <Label htmlFor="position">Position *</Label>
                        <Input
                          id="position"
                          placeholder="Job title"
                          value={experienceData.position}
                          onChange={(e) => setExperienceData({ ...experienceData, position: e.target.value })}
                        />
                      </div>
                      <div>
                        <Label htmlFor="startDate">Start Date</Label>
                        <Input
                          id="startDate"
                          type="date"
                          value={experienceData.startDate}
                          onChange={(e) => setExperienceData({ ...experienceData, startDate: e.target.value })}
                        />
                      </div>
                      <div>
                        <Label htmlFor="endDate">End Date</Label>
                        <Input
                          id="endDate"
                          type="date"
                          value={experienceData.endDate}
                          onChange={(e) => setExperienceData({ ...experienceData, endDate: e.target.value })}
                          disabled={experienceData.current}
                        />
                      </div>
                      <div className="col-span-2">
                        <Label htmlFor="description">Description</Label>
                        <Textarea
                          id="description"
                          placeholder="Describe your role and achievements..."
                          value={experienceData.description}
                          onChange={(e) => setExperienceData({ ...experienceData, description: e.target.value })}
                          rows={3}
                        />
                      </div>
                      <div className="col-span-2">
                        <label className="flex items-center space-x-2">
                          <input
                            type="checkbox"
                            checked={experienceData.current}
                            onChange={(e) => setExperienceData({ ...experienceData, current: e.target.checked })}
                          />
                          <span className="text-sm">I currently work here</span>
                        </label>
                      </div>
                    </div>
                    <Button 
                      onClick={handleAddExperience}
                      disabled={addExperienceMutation.isPending}
                      className="mt-4"
                    >
                      <Plus className="w-4 h-4 mr-2" />
                      {addExperienceMutation.isPending ? "Adding..." : "Add Experience"}
                    </Button>
                  </div>

                  {/* Existing Experience List */}
                  <div className="space-y-4">
                    <h3 className="font-medium">Current Experience</h3>
                    {profile?.experience?.length > 0 ? (
                      profile.experience.map((exp: any, index: number) => (
                        <div key={index} className="border rounded-lg p-4">
                          <div className="flex justify-between items-start">
                            <div>
                              <h4 className="font-medium">{exp.position}</h4>
                              <p className="text-sm text-gray-600">{exp.company}</p>
                              <p className="text-xs text-gray-500">
                                {exp.startDate} - {exp.current ? "Present" : exp.endDate}
                              </p>
                              {exp.description && (
                                <p className="text-sm mt-2">{exp.description}</p>
                              )}
                            </div>
                            <Button variant="ghost" size="sm">
                              <X className="w-4 h-4" />
                            </Button>
                          </div>
                        </div>
                      ))
                    ) : (
                      <p className="text-gray-500 text-center py-8">No experience added yet</p>
                    )}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Education Tab */}
            <TabsContent value="education">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <GraduationCap className="w-5 h-5 mr-2" />
                    Education
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  {/* Add New Education Form */}
                  <div className="border rounded-lg p-4 bg-gray-50">
                    <h3 className="font-medium mb-4">Add New Education</h3>
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="institution">Institution *</Label>
                        <Input
                          id="institution"
                          placeholder="University or school name"
                          value={educationData.institution}
                          onChange={(e) => setEducationData({ ...educationData, institution: e.target.value })}
                        />
                      </div>
                      <div>
                        <Label htmlFor="degree">Degree *</Label>
                        <Input
                          id="degree"
                          placeholder="Bachelor's, Master's, etc."
                          value={educationData.degree}
                          onChange={(e) => setEducationData({ ...educationData, degree: e.target.value })}
                        />
                      </div>
                      <div>
                        <Label htmlFor="fieldOfStudy">Field of Study</Label>
                        <Input
                          id="fieldOfStudy"
                          placeholder="Computer Science, Business, etc."
                          value={educationData.fieldOfStudy}
                          onChange={(e) => setEducationData({ ...educationData, fieldOfStudy: e.target.value })}
                        />
                      </div>
                      <div>
                        <Label htmlFor="eduStartDate">Start Date</Label>
                        <Input
                          id="eduStartDate"
                          type="date"
                          value={educationData.startDate}
                          onChange={(e) => setEducationData({ ...educationData, startDate: e.target.value })}
                        />
                      </div>
                      <div>
                        <Label htmlFor="eduEndDate">End Date</Label>
                        <Input
                          id="eduEndDate"
                          type="date"
                          value={educationData.endDate}
                          onChange={(e) => setEducationData({ ...educationData, endDate: e.target.value })}
                        />
                      </div>
                      <div className="col-span-2">
                        <Label htmlFor="eduDescription">Description</Label>
                        <Textarea
                          id="eduDescription"
                          placeholder="Additional details, achievements, etc."
                          value={educationData.description}
                          onChange={(e) => setEducationData({ ...educationData, description: e.target.value })}
                          rows={3}
                        />
                      </div>
                    </div>
                    <Button 
                      onClick={handleAddEducation}
                      disabled={addEducationMutation.isPending}
                      className="mt-4"
                    >
                      <Plus className="w-4 h-4 mr-2" />
                      {addEducationMutation.isPending ? "Adding..." : "Add Education"}
                    </Button>
                  </div>

                  {/* Existing Education List */}
                  <div className="space-y-4">
                    <h3 className="font-medium">Current Education</h3>
                    {profile?.education?.length > 0 ? (
                      profile.education.map((edu: any, index: number) => (
                        <div key={index} className="border rounded-lg p-4">
                          <div className="flex justify-between items-start">
                            <div>
                              <h4 className="font-medium">{edu.degree}</h4>
                              <p className="text-sm text-gray-600">{edu.institution}</p>
                              {edu.fieldOfStudy && (
                                <p className="text-sm text-gray-600">{edu.fieldOfStudy}</p>
                              )}
                              <p className="text-xs text-gray-500">
                                {edu.startDate} - {edu.endDate}
                              </p>
                              {edu.description && (
                                <p className="text-sm mt-2">{edu.description}</p>
                              )}
                            </div>
                            <Button variant="ghost" size="sm">
                              <X className="w-4 h-4" />
                            </Button>
                          </div>
                        </div>
                      ))
                    ) : (
                      <p className="text-gray-500 text-center py-8">No education added yet</p>
                    )}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Skills Tab */}
            <TabsContent value="skills">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Award className="w-5 h-5 mr-2" />
                    Skills
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  {/* Add New Skill Form */}
                  <div className="border rounded-lg p-4 bg-gray-50">
                    <h3 className="font-medium mb-4">Add New Skill</h3>
                    <div className="grid grid-cols-3 gap-4">
                      <div>
                        <Label htmlFor="skillName">Skill Name *</Label>
                        <Input
                          id="skillName"
                          placeholder="JavaScript, Project Management, etc."
                          value={skillData.name}
                          onChange={(e) => setSkillData({ ...skillData, name: e.target.value })}
                        />
                      </div>
                      <div>
                        <Label htmlFor="skillLevel">Level</Label>
                        <Select 
                          value={skillData.level} 
                          onValueChange={(value) => setSkillData({ ...skillData, level: value })}
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="Select level" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="beginner">Beginner</SelectItem>
                            <SelectItem value="intermediate">Intermediate</SelectItem>
                            <SelectItem value="advanced">Advanced</SelectItem>
                            <SelectItem value="expert">Expert</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div>
                        <Label htmlFor="skillCategory">Category</Label>
                        <Select 
                          value={skillData.category} 
                          onValueChange={(value) => setSkillData({ ...skillData, category: value })}
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="Select category" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="technical">Technical</SelectItem>
                            <SelectItem value="soft">Soft Skills</SelectItem>
                            <SelectItem value="language">Language</SelectItem>
                            <SelectItem value="tools">Tools</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                    <Button 
                      onClick={handleAddSkill}
                      disabled={addSkillMutation.isPending}
                      className="mt-4"
                    >
                      <Plus className="w-4 h-4 mr-2" />
                      {addSkillMutation.isPending ? "Adding..." : "Add Skill"}
                    </Button>
                  </div>

                  {/* Existing Skills List */}
                  <div className="space-y-4">
                    <h3 className="font-medium">Current Skills</h3>
                    {profile?.skills?.length > 0 ? (
                      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                        {profile.skills.map((skill: any, index: number) => (
                          <div key={index} className="border rounded-lg p-3">
                            <div className="flex justify-between items-start">
                              <div>
                                <h4 className="font-medium">{skill.name}</h4>
                                <div className="flex items-center gap-2 mt-1">
                                  <Badge variant="secondary" className="text-xs">
                                    {skill.level}
                                  </Badge>
                                  <Badge variant="outline" className="text-xs">
                                    {skill.category}
                                  </Badge>
                                </div>
                              </div>
                              <Button variant="ghost" size="sm">
                                <X className="w-3 h-3" />
                              </Button>
                            </div>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <p className="text-gray-500 text-center py-8">No skills added yet</p>
                    )}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Projects Tab */}
            <TabsContent value="projects">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Code className="w-5 h-5 mr-2" />
                    Projects
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  {/* Add New Project Form */}
                  <div className="border rounded-lg p-4 bg-gray-50">
                    <h3 className="font-medium mb-4">Add New Project</h3>
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="projectTitle">Project Title *</Label>
                        <Input
                          id="projectTitle"
                          placeholder="My Awesome Project"
                          value={projectData.title}
                          onChange={(e) => setProjectData({ ...projectData, title: e.target.value })}
                        />
                      </div>
                      <div>
                        <Label htmlFor="projectStatus">Status</Label>
                        <Select 
                          value={projectData.status} 
                          onValueChange={(value) => setProjectData({ ...projectData, status: value })}
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="Select status" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="in_progress">In Progress</SelectItem>
                            <SelectItem value="completed">Completed</SelectItem>
                            <SelectItem value="on_hold">On Hold</SelectItem>
                            <SelectItem value="cancelled">Cancelled</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="col-span-2">
                        <Label htmlFor="projectDescription">Description *</Label>
                        <Textarea
                          id="projectDescription"
                          placeholder="Describe your project, what it does, and your role..."
                          value={projectData.description}
                          onChange={(e) => setProjectData({ ...projectData, description: e.target.value })}
                          rows={3}
                        />
                      </div>
                      <div>
                        <Label htmlFor="technologies">Technologies Used</Label>
                        <Input
                          id="technologies"
                          placeholder="React, Node.js, PostgreSQL, etc."
                          value={projectData.technologies}
                          onChange={(e) => setProjectData({ ...projectData, technologies: e.target.value })}
                        />
                      </div>
                      <div>
                        <Label htmlFor="githubUrl">GitHub URL</Label>
                        <Input
                          id="githubUrl"
                          placeholder="https://github.com/username/project"
                          value={projectData.githubUrl}
                          onChange={(e) => setProjectData({ ...projectData, githubUrl: e.target.value })}
                        />
                      </div>
                      <div>
                        <Label htmlFor="demoUrl">Demo URL</Label>
                        <Input
                          id="demoUrl"
                          placeholder="https://myproject.com"
                          value={projectData.demoUrl}
                          onChange={(e) => setProjectData({ ...projectData, demoUrl: e.target.value })}
                        />
                      </div>
                      <div>
                        <Label htmlFor="projectStartDate">Start Date</Label>
                        <Input
                          id="projectStartDate"
                          type="date"
                          value={projectData.startDate}
                          onChange={(e) => setProjectData({ ...projectData, startDate: e.target.value })}
                        />
                      </div>
                      <div>
                        <Label htmlFor="projectEndDate">End Date</Label>
                        <Input
                          id="projectEndDate"
                          type="date"
                          value={projectData.endDate}
                          onChange={(e) => setProjectData({ ...projectData, endDate: e.target.value })}
                        />
                      </div>
                    </div>
                    <Button 
                      onClick={handleAddProject}
                      disabled={addProjectMutation.isPending}
                      className="mt-4"
                    >
                      <Plus className="w-4 h-4 mr-2" />
                      {addProjectMutation.isPending ? "Adding..." : "Add Project"}
                    </Button>
                  </div>

                  {/* Existing Projects List */}
                  <div className="space-y-4">
                    <h3 className="font-medium">Current Projects</h3>
                    {profile?.projects?.length > 0 ? (
                      profile.projects.map((project: any, index: number) => (
                        <div key={index} className="border rounded-lg p-4">
                          <div className="flex justify-between items-start">
                            <div className="flex-1">
                              <div className="flex items-center gap-2 mb-2">
                                <h4 className="font-medium">{project.title}</h4>
                                <Badge variant={project.status === 'completed' ? 'default' : 'secondary'} className="text-xs">
                                  {project.status}
                                </Badge>
                              </div>
                              <p className="text-sm text-gray-600 mb-2">{project.description}</p>
                              {project.technologies && (
                                <p className="text-xs text-gray-500 mb-2">
                                  <strong>Technologies:</strong> {project.technologies}
                                </p>
                              )}
                              <div className="flex gap-2 text-xs">
                                {project.githubUrl && (
                                  <a href={project.githubUrl} target="_blank" rel="noopener noreferrer" 
                                     className="text-sky-600 hover:underline">
                                    GitHub
                                  </a>
                                )}
                                {project.demoUrl && (
                                  <a href={project.demoUrl} target="_blank" rel="noopener noreferrer"
                                     className="text-sky-600 hover:underline">
                                    Live Demo
                                  </a>
                                )}
                              </div>
                              {(project.startDate || project.endDate) && (
                                <p className="text-xs text-gray-500 mt-1">
                                  {project.startDate} {project.endDate && `- ${project.endDate}`}
                                </p>
                              )}
                            </div>
                            <Button variant="ghost" size="sm">
                              <X className="w-4 h-4" />
                            </Button>
                          </div>
                        </div>
                      ))
                    ) : (
                      <p className="text-gray-500 text-center py-8">No projects added yet</p>
                    )}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Achievements Tab */}
            <TabsContent value="achievements">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Award className="w-5 h-5 mr-2" />
                    Achievements & Awards
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  {/* Add New Achievement Form */}
                  <div className="border rounded-lg p-4 bg-gray-50">
                    <h3 className="font-medium mb-4">Add New Achievement</h3>
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <Label htmlFor="achievementTitle">Achievement Title *</Label>
                        <Input
                          id="achievementTitle"
                          placeholder="Employee of the Month, Best Project Award, etc."
                          value={achievementData.title}
                          onChange={(e) => setAchievementData({ ...achievementData, title: e.target.value })}
                        />
                      </div>
                      <div>
                        <Label htmlFor="achievementDate">Date *</Label>
                        <Input
                          id="achievementDate"
                          type="date"
                          value={achievementData.date}
                          onChange={(e) => setAchievementData({ ...achievementData, date: e.target.value })}
                        />
                      </div>
                      <div>
                        <Label htmlFor="achievementCategory">Category</Label>
                        <Select 
                          value={achievementData.category} 
                          onValueChange={(value) => setAchievementData({ ...achievementData, category: value })}
                        >
                          <SelectTrigger>
                            <SelectValue placeholder="Select category" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="award">Award</SelectItem>
                            <SelectItem value="certification">Certification</SelectItem>
                            <SelectItem value="recognition">Recognition</SelectItem>
                            <SelectItem value="competition">Competition</SelectItem>
                            <SelectItem value="publication">Publication</SelectItem>
                            <SelectItem value="other">Other</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      <div>
                        <Label htmlFor="achievementIssuer">Issuing Organization</Label>
                        <Input
                          id="achievementIssuer"
                          placeholder="Company, Institution, Organization"
                          value={achievementData.issuer}
                          onChange={(e) => setAchievementData({ ...achievementData, issuer: e.target.value })}
                        />
                      </div>
                      <div className="col-span-2">
                        <Label htmlFor="achievementDescription">Description</Label>
                        <Textarea
                          id="achievementDescription"
                          placeholder="Describe the achievement and its significance..."
                          value={achievementData.description}
                          onChange={(e) => setAchievementData({ ...achievementData, description: e.target.value })}
                          rows={3}
                        />
                      </div>
                    </div>
                    <Button 
                      onClick={handleAddAchievement}
                      disabled={addAchievementMutation.isPending}
                      className="mt-4"
                    >
                      <Plus className="w-4 h-4 mr-2" />
                      {addAchievementMutation.isPending ? "Adding..." : "Add Achievement"}
                    </Button>
                  </div>

                  {/* Existing Achievements List */}
                  <div className="space-y-4">
                    <h3 className="font-medium">Current Achievements</h3>
                    {profile?.achievements?.length > 0 ? (
                      profile.achievements.map((achievement: any, index: number) => (
                        <div key={index} className="border rounded-lg p-4">
                          <div className="flex justify-between items-start">
                            <div className="flex-1">
                              <div className="flex items-center gap-2 mb-2">
                                <h4 className="font-medium">{achievement.title}</h4>
                                <Badge variant="outline" className="text-xs">
                                  {achievement.category}
                                </Badge>
                              </div>
                              {achievement.issuer && (
                                <p className="text-sm text-gray-600 mb-1">
                                  <strong>Issued by:</strong> {achievement.issuer}
                                </p>
                              )}
                              <p className="text-xs text-gray-500 mb-2">
                                <Calendar className="w-3 h-3 inline mr-1" />
                                {achievement.date}
                              </p>
                              {achievement.description && (
                                <p className="text-sm">{achievement.description}</p>
                              )}
                            </div>
                            <Button variant="ghost" size="sm">
                              <X className="w-4 h-4" />
                            </Button>
                          </div>
                        </div>
                      ))
                    ) : (
                      <p className="text-gray-500 text-center py-8">No achievements added yet</p>
                    )}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>

          {/* Save Button (Fixed) */}
          <div className="fixed bottom-6 right-6">
            <Button
              onClick={handleSaveProfile}
              disabled={saveProfileMutation.isPending}
              size="lg"
              className="shadow-lg bg-sky-600 hover:bg-sky-700"
            >
              <Save className="w-5 h-5 mr-2" />
              {saveProfileMutation.isPending ? "Saving..." : "Save All Changes"}
            </Button>
          </div>

          {/* Share Popup */}
          {sharePopupOpen && (
            <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
              <div className="bg-white rounded-lg p-6 w-96 max-w-sm mx-4">
                <div className="flex justify-between items-center mb-4">
                  <h3 className="text-lg font-semibold">Share Profile</h3>
                  <Button 
                    variant="ghost" 
                    size="sm" 
                    onClick={() => setSharePopupOpen(false)}
                  >
                    <X className="w-4 h-4" />
                  </Button>
                </div>
                
                <div className="space-y-3">
                  <Button 
                    onClick={handleCopyLink}
                    variant="outline" 
                    className="w-full justify-start"
                  >
                    <ExternalLink className="w-4 h-4 mr-2" />
                    Copy Profile Link
                  </Button>
                  
                  <Button 
                    onClick={handleLinkedInShare}
                    variant="outline" 
                    className="w-full justify-start"
                  >
                    <Share className="w-4 h-4 mr-2" />
                    Share on LinkedIn
                  </Button>
                  
                  <Button 
                    onClick={handleEmailShare}
                    variant="outline" 
                    className="w-full justify-start"
                  >
                    <Mail className="w-4 h-4 mr-2" />
                    Share via Email
                  </Button>
                </div>
              </div>
            </div>
          )}
    </div>
  );
}

export default function ProfileBuilder() {
  const config = platformConfigs.candidate;
  const theme = useThemeClasses('candidate');
  
  const usageData = [
    { label: "Profile Completion", current: 85, max: 100 },
    { label: "Profile Views", current: 23, max: 50 },
    { label: "Skills Added", current: 12, max: 20 },
  ];

  return (
    <PlatformLayout
      sidebarTitle={config.sidebarTitle}
      sidebarSubtitle={config.sidebarSubtitle}
      sidebarSections={config.sidebarSections}
      usageData={usageData}
    >
      <ProfileBuilderContent />
    </PlatformLayout>
  );
}