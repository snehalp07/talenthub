import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import PlatformLayout from "@/components/layout/platform-layout";
import { platformConfigs } from "@/config/complete-navigation";
import { useThemeClasses } from "@/lib/theme-config";
import { 
  Search, 
  Filter, 
  Calendar, 
  Building, 
  MapPin, 
  Clock, 
  CheckCircle, 
  XCircle, 
  AlertCircle,
  Eye,
  MessageSquare,
  Phone,
  Mail
} from "lucide-react";

function ApplicationTrackerContent() {
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");

  const { data: applications = [], isLoading } = useQuery({
    queryKey: ["/api/candidate/job-applications"],
  });

  // Filter applications based on search and status
  const getFilteredApplications = () => {
    // Use database applications or fallback to hardcoded for demo
    const apps = applications.length > 0 ? applications as any[] : hardcodedApplications;
    return apps.filter((app: any) => {
      const matchesSearch = app.jobTitle?.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           app.company?.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesStatus = statusFilter === "all" || app.status === statusFilter;
      return matchesSearch && matchesStatus;
    });
  };

  if (isLoading) {
    return (
      <div className="max-w-6xl mx-auto p-6">
        <div className="space-y-4">
          {[1, 2, 3].map((i) => (
            <Card key={i} className="animate-pulse">
              <CardContent className="p-6">
                <div className="h-4 bg-gray-200 rounded w-1/4 mb-2"></div>
                <div className="h-3 bg-gray-200 rounded w-1/2 mb-4"></div>
                <div className="h-3 bg-gray-200 rounded w-3/4"></div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  const hardcodedApplications = [
    {
      id: "1",
      jobTitle: "Senior Frontend Developer",
      company: "TechCorp Inc.",
      location: "San Francisco, CA",
      appliedDate: "2024-01-15",
      status: "interview_scheduled",
      statusText: "Interview Scheduled",
      salary: "$120,000 - $150,000",
      interviewDate: "2024-01-22",
      notes: "Technical round with the frontend team",
      recruiterContact: "sarah.johnson@techcorp.com"
    },
    {
      id: "2",
      jobTitle: "Full Stack Engineer",
      company: "StartupXYZ",
      location: "Remote",
      appliedDate: "2024-01-10",
      status: "under_review",
      statusText: "Under Review",
      salary: "$100,000 - $130,000",
      notes: "Applied through company website",
      recruiterContact: "hr@startupxyz.com"
    },
    {
      id: "3",
      jobTitle: "React Developer",
      company: "Digital Solutions",
      location: "New York, NY",
      appliedDate: "2024-01-08",
      status: "rejected",
      statusText: "Not Selected",
      salary: "$110,000 - $140,000",
      feedback: "Strong technical skills but looking for more backend experience"
    },
    {
      id: "4",
      jobTitle: "UI/UX Developer",
      company: "Creative Agency",
      location: "Los Angeles, CA",
      appliedDate: "2024-01-20",
      status: "applied",
      statusText: "Application Sent",
      salary: "$95,000 - $125,000",
      notes: "Portfolio review pending"
    },
    {
      id: "5",
      jobTitle: "Lead Frontend Engineer",
      company: "Enterprise Corp",
      location: "Seattle, WA",
      appliedDate: "2024-01-18",
      status: "offer_received",
      statusText: "Offer Received",
      salary: "$140,000 - $170,000",
      offerDeadline: "2024-01-30",
      notes: "Negotiating start date and benefits package"
    }
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case "applied": return "bg-blue-100 text-blue-700 border-blue-200";
      case "under_review": return "bg-yellow-100 text-yellow-700 border-yellow-200";
      case "interview_scheduled": return "bg-purple-100 text-purple-700 border-purple-200";
      case "offer_received": return "bg-green-100 text-green-700 border-green-200";
      case "rejected": return "bg-red-100 text-red-700 border-red-200";
      default: return "bg-gray-100 text-gray-700 border-gray-200";
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "applied": return <Clock className="h-4 w-4" />;
      case "under_review": return <AlertCircle className="h-4 w-4" />;
      case "interview_scheduled": return <Calendar className="h-4 w-4" />;
      case "offer_received": return <CheckCircle className="h-4 w-4" />;
      case "rejected": return <XCircle className="h-4 w-4" />;
      default: return <Clock className="h-4 w-4" />;
    }
  };

  const displayApplications = getFilteredApplications();
  
  // Use database applications or fallback to hardcoded for demo
  const allApplications = applications.length > 0 ? applications as any[] : hardcodedApplications;

  const statusCounts = {
    all: allApplications.length,
    applied: allApplications.filter((app: any) => app.status === "applied").length,
    under_review: allApplications.filter((app: any) => app.status === "under_review").length,
    interview_scheduled: allApplications.filter((app: any) => app.status === "interview_scheduled").length,
    offer_received: allApplications.filter((app: any) => app.status === "offer_received").length,
    rejected: allApplications.filter((app: any) => app.status === "rejected").length,
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-sky-50 to-white p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Application Tracker</h1>
          <p className="text-gray-600">Track all your job applications in one place</p>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-2 md:grid-cols-6 gap-4 mb-6">
          <Card className="border-blue-200">
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-blue-700">{statusCounts.all}</div>
              <div className="text-xs text-gray-600">Total Applications</div>
            </CardContent>
          </Card>
          <Card className="border-yellow-200">
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-yellow-700">{statusCounts.applied}</div>
              <div className="text-xs text-gray-600">Applied</div>
            </CardContent>
          </Card>
          <Card className="border-purple-200">
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-purple-700">{statusCounts.under_review}</div>
              <div className="text-xs text-gray-600">Under Review</div>
            </CardContent>
          </Card>
          <Card className="border-orange-200">
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-orange-700">{statusCounts.interview_scheduled}</div>
              <div className="text-xs text-gray-600">Interviews</div>
            </CardContent>
          </Card>
          <Card className="border-green-200">
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-green-700">{statusCounts.offer_received}</div>
              <div className="text-xs text-gray-600">Offers</div>
            </CardContent>
          </Card>
          <Card className="border-red-200">
            <CardContent className="p-4 text-center">
              <div className="text-2xl font-bold text-red-700">{statusCounts.rejected}</div>
              <div className="text-xs text-gray-600">Rejected</div>
            </CardContent>
          </Card>
        </div>

        {/* Filters */}
        <Card className="mb-6">
          <CardContent className="p-6">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="flex-1">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                  <Input
                    placeholder="Search by job title or company..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                  />
                </div>
              </div>
              <div className="flex gap-4">
                <Select value={statusFilter} onValueChange={setStatusFilter}>
                  <SelectTrigger className="w-48">
                    <Filter className="h-4 w-4 mr-2" />
                    <SelectValue placeholder="Filter by status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Status</SelectItem>
                    <SelectItem value="applied">Applied</SelectItem>
                    <SelectItem value="under_review">Under Review</SelectItem>
                    <SelectItem value="interview_scheduled">Interview Scheduled</SelectItem>
                    <SelectItem value="offer_received">Offer Received</SelectItem>
                    <SelectItem value="rejected">Rejected</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Applications List */}
        <div className="space-y-4">
          {displayApplications.map((application: any) => (
            <Card key={application.id} className="hover:shadow-lg transition-shadow">
              <CardContent className="p-6">
                <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
                  {/* Main Info */}
                  <div className="flex-1">
                    <div className="flex items-start justify-between mb-3">
                      <div>
                        <h3 className="text-lg font-semibold text-gray-900 mb-1">
                          {application.jobTitle}
                        </h3>
                        <div className="flex items-center gap-4 text-sm text-gray-600">
                          <div className="flex items-center gap-1">
                            <Building className="h-4 w-4" />
                            {application.company}
                          </div>
                          <div className="flex items-center gap-1">
                            <MapPin className="h-4 w-4" />
                            {application.location}
                          </div>
                          <div className="flex items-center gap-1">
                            <Calendar className="h-4 w-4" />
                            Applied {application.appliedDate}
                          </div>
                        </div>
                      </div>
                      <Badge className={`${getStatusColor(application.status)} flex items-center gap-1`}>
                        {getStatusIcon(application.status)}
                        {application.statusText}
                      </Badge>
                    </div>

                    {/* Additional Info */}
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                      <div>
                        <span className="font-medium text-gray-700">Salary: </span>
                        <span className="text-gray-600">{application.salary}</span>
                      </div>
                      {application.interviewDate && (
                        <div>
                          <span className="font-medium text-gray-700">Interview: </span>
                          <span className="text-gray-600">{application.interviewDate}</span>
                        </div>
                      )}
                      {application.offerDeadline && (
                        <div>
                          <span className="font-medium text-gray-700">Offer Deadline: </span>
                          <span className="text-orange-600 font-medium">{application.offerDeadline}</span>
                        </div>
                      )}
                    </div>

                    {/* Notes */}
                    {application.notes && (
                      <div className="mt-3 p-3 bg-gray-50 rounded-lg">
                        <span className="text-sm text-gray-600">{application.notes}</span>
                      </div>
                    )}

                    {/* Feedback */}
                    {application.feedback && (
                      <div className="mt-3 p-3 bg-red-50 rounded-lg border border-red-200">
                        <span className="text-sm text-red-700">{application.feedback}</span>
                      </div>
                    )}
                  </div>

                  {/* Actions */}
                  <div className="flex flex-col gap-2">
                    <Button variant="outline" size="sm">
                      <Eye className="h-4 w-4 mr-2" />
                      View Details
                    </Button>
                    {application.recruiterContact && (
                      <Button variant="outline" size="sm">
                        <Mail className="h-4 w-4 mr-2" />
                        Contact
                      </Button>
                    )}
                    <Button variant="outline" size="sm">
                      <MessageSquare className="h-4 w-4 mr-2" />
                      Add Note
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {displayApplications.length === 0 && (
          <Card>
            <CardContent className="p-12 text-center">
              <div className="text-gray-400 mb-4">
                <Search className="h-12 w-12 mx-auto" />
              </div>
              <h3 className="text-lg font-medium text-gray-900 mb-2">No applications found</h3>
              <p className="text-gray-600">Try adjusting your search criteria or add a new application.</p>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}

export default function ApplicationTracker() {
  const config = platformConfigs.candidate;
  const theme = useThemeClasses('candidate');
  
  const usageData = [
    { label: "Active Applications", current: 8, max: 20 },
    { label: "Interview Success", current: 75, max: 100 },
    { label: "Response Rate", current: 65, max: 100 },
  ];

  return (
    <PlatformLayout
      sidebarTitle={config.sidebarTitle}
      sidebarSubtitle={config.sidebarSubtitle}
      sidebarSections={config.sidebarSections}
      usageData={usageData}
    >
      <ApplicationTrackerContent />
    </PlatformLayout>
  );
}