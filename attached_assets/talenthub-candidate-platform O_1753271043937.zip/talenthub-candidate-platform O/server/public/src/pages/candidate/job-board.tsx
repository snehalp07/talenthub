import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useAuth } from "@/hooks/use-auth";
import PlatformLayout from "@/components/layout/platform-layout";
import { platformConfigs } from "@/config/complete-navigation";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { useToast } from "@/hooks/use-toast";
import JobApplicationModal from "@/components/job-application-modal";
import { 
  MapPin, 
  DollarSign, 
  Clock, 
  Building2, 
  Users, 
  Bookmark, 
  BookmarkCheck,
  Search,
  Filter,
  Briefcase,
  Calendar,
  Eye,
  Award,
  Lock,
  Crown
} from "lucide-react";

interface JobPosting {
  id: number;
  title: string;
  description: string;
  organizationName: string;
  location: string;
  remoteAllowed: boolean;
  minSalary: number;
  maxSalary: number;
  experienceLevel: string;
  requiredSkills: string[];
  requiredCertificationLevel?: number;
  applicationCount?: number;
  viewCount?: number;
  applicationDeadline?: string;
  createdAt: string;
  isSaved?: boolean;
  hasApplied?: boolean;
}

function JobBoardContent() {
  const { user } = useAuth() || { user: null };
  const { toast } = useToast();
  const [searchQuery, setSearchQuery] = useState("");
  const [locationFilter, setLocationFilter] = useState("");
  const [experienceFilter, setExperienceFilter] = useState("");
  const [remoteFilter, setRemoteFilter] = useState("");
  const [selectedJob, setSelectedJob] = useState<JobPosting | null>(null);
  const [isApplicationModalOpen, setIsApplicationModalOpen] = useState(false);

  // Check subscription status using user profile endpoint
  const { data: subscriptionStatus, isLoading: subscriptionLoading } = useQuery({
    queryKey: ["/api/user-profile"],
    // Remove user requirement to allow subscription check without auth
  });

  const { data: jobs = [], isLoading } = useQuery<JobPosting[]>({
    queryKey: ["/api/jobs", { 
      search: searchQuery, 
      location: locationFilter, 
      experience: experienceFilter,
      remote: remoteFilter 
    }],
    // Remove user requirement to allow data loading without auth
  });

  const { data: savedJobs = [] } = useQuery({
    queryKey: ["/api/saved-jobs"],
    enabled: !!user && user.role === "candidate",
    initialData: []
  });

  const { data: applications = [] } = useQuery({
    queryKey: ["/api/job-applications"],
    enabled: !!user && user.role === "candidate",
    initialData: []
  });

  const saveJobMutation = useMutation({
    mutationFn: async (jobId: string) => {
      return await apiRequest("POST", `/api/jobs/${jobId}/save`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/saved-jobs"] });
      toast({
        title: "Job Saved",
        description: "Job has been added to your saved jobs",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const unsaveJobMutation = useMutation({
    mutationFn: async (jobId: string) => {
      return await apiRequest("DELETE", `/api/jobs/${jobId}/save`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/saved-jobs"] });
      toast({
        title: "Job Removed",
        description: "Job has been removed from your saved jobs",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleApplyClick = (job: JobPosting) => {
    setSelectedJob(job);
    setIsApplicationModalOpen(true);
  };

  const isJobSaved = (jobId: string) => {
    return Array.isArray(savedJobs) && savedJobs.some((saved: any) => saved.jobId === jobId);
  };

  const hasAppliedToJob = (jobId: string) => {
    return Array.isArray(applications) && applications.some((app: any) => app.jobId === jobId);
  };

  const formatSalary = (min: number, max: number) => {
    const formatAmount = (amount: number) => {
      if (amount >= 10000000) return `${(amount / 10000000).toFixed(1)}Cr`;
      if (amount >= 100000) return `${(amount / 100000).toFixed(1)}L`;
      return `${(amount / 1000).toFixed(0)}K`;
    };
    return `₹${formatAmount(min)} - ₹${formatAmount(max)}`;
  };

  const getExperienceLevelColor = (level: string) => {
    const colors = {
      entry: "bg-green-100 text-green-800",
      mid: "bg-blue-100 text-blue-800",
      senior: "bg-purple-100 text-purple-800",
      expert: "bg-red-100 text-red-800"
    };
    return colors[level as keyof typeof colors] || "bg-gray-100 text-gray-800";
  };

  if (isLoading || subscriptionLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full" />
      </div>
    );
  }

  // Show subscription gate if user doesn't have active subscription
  if (user && subscriptionStatus && !(subscriptionStatus as any)?.hasActiveSubscription) {
    return (
      <div className="max-w-7xl mx-auto p-6">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Job Board</h1>
          <p className="text-muted-foreground">Discover opportunities that match your skills and interests</p>
        </div>

        <Card className="max-w-2xl mx-auto text-center">
          <CardContent className="p-12">
            <div className="mb-6">
              <div className="mx-auto w-16 h-16 bg-gradient-to-br from-sky-400 to-sky-600 rounded-full flex items-center justify-center mb-4">
                <Crown className="w-8 h-8 text-white" />
              </div>
              <Lock className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
            </div>
            <h3 className="text-2xl font-bold mb-4">Premium Job Board Access Required</h3>
            <p className="text-muted-foreground mb-6 max-w-md mx-auto">
              Unlock access to exclusive job opportunities, advanced filtering, and direct application features with our premium subscription.
            </p>
            <div className="space-y-4">
              <Button className="bg-sky-500 hover:bg-sky-600 text-white px-8">
                <Crown className="w-4 h-4 mr-2" />
                Upgrade to Premium
              </Button>
              <div className="text-sm text-muted-foreground">
                Starting at ₹999/month • Cancel anytime
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto p-6">
      <div className="mb-8 flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Job Board</h1>
          <p className="text-muted-foreground">Discover opportunities that match your skills and interests</p>
        </div>
        {subscriptionStatus?.hasActiveSubscription && (
          <Badge variant="outline" className="bg-sky-50 text-sky-700 border-sky-200">
            <Crown className="w-3 h-3 mr-1" />
            Premium Member
          </Badge>
        )}
      </div>

      {/* Search and Filters */}
      <Card className="mb-6">
        <CardContent className="p-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
            <div className="lg:col-span-2 relative">
              <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search jobs, companies, skills..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10"
              />
            </div>
            <div className="relative">
              <MapPin className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Location"
                value={locationFilter}
                onChange={(e) => setLocationFilter(e.target.value)}
                className="pl-10"
              />
            </div>
            <Select value={experienceFilter} onValueChange={setExperienceFilter}>
              <SelectTrigger>
                <SelectValue placeholder="Experience Level" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Levels</SelectItem>
                <SelectItem value="entry">Entry Level</SelectItem>
                <SelectItem value="mid">Mid Level</SelectItem>
                <SelectItem value="senior">Senior Level</SelectItem>
                <SelectItem value="expert">Expert Level</SelectItem>
              </SelectContent>
            </Select>
            <Select value={remoteFilter} onValueChange={setRemoteFilter}>
              <SelectTrigger>
                <SelectValue placeholder="Work Type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Types</SelectItem>
                <SelectItem value="remote">Remote</SelectItem>
                <SelectItem value="onsite">On-site</SelectItem>
                <SelectItem value="hybrid">Hybrid</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Job Listings */}
      <div className="space-y-4">
        {jobs.length === 0 ? (
          <Card>
            <CardContent className="p-12 text-center">
              <Briefcase className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
              <h3 className="text-lg font-semibold mb-2">No Jobs Found</h3>
              <p className="text-muted-foreground">
                {searchQuery || locationFilter || experienceFilter || remoteFilter
                  ? "Try adjusting your search criteria"
                  : "Check back later for new opportunities"}
              </p>
            </CardContent>
          </Card>
        ) : (
          jobs.map((job: JobPosting) => (
            <Card key={job.id} className="hover:shadow-md transition-shadow">
              <CardContent className="p-6">
                <div className="flex justify-between items-start mb-4">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <h3 className="text-xl font-semibold text-gray-900">{job.title}</h3>
                      {job.requiredCertificationLevel && (
                        <Badge variant="outline" className="flex items-center gap-1">
                          <Award className="h-3 w-3" />
                          Level {job.requiredCertificationLevel}+ Required
                        </Badge>
                      )}
                    </div>
                    <div className="flex items-center gap-4 text-sm text-muted-foreground mb-3">
                      <div className="flex items-center gap-1">
                        <Building2 className="h-4 w-4" />
                        {job.organizationName}
                      </div>
                      <div className="flex items-center gap-1">
                        <MapPin className="h-4 w-4" />
                        {job.location}
                        {job.remoteAllowed && " • Remote OK"}
                      </div>
                      <div className="flex items-center gap-1">
                        <DollarSign className="h-4 w-4" />
                        {formatSalary(job.minSalary, job.maxSalary)}
                      </div>
                    </div>
                  </div>
                  <div className="flex gap-2">
                    {user?.role === "candidate" && (
                      <>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => {
                            if (isJobSaved(job.id.toString())) {
                              unsaveJobMutation.mutate(job.id.toString());
                            } else {
                              saveJobMutation.mutate(job.id.toString());
                            }
                          }}
                          disabled={saveJobMutation.isPending || unsaveJobMutation.isPending}
                        >
                          {isJobSaved(job.id.toString()) ? (
                            <BookmarkCheck className="h-4 w-4" />
                          ) : (
                            <Bookmark className="h-4 w-4" />
                          )}
                        </Button>
                        {hasAppliedToJob(job.id.toString()) ? (
                          <Button disabled size="sm">
                            Applied
                          </Button>
                        ) : (
                          <Button
                            onClick={() => handleApplyClick(job)}
                            size="sm"
                            className="bg-sky-500 hover:bg-sky-600 text-white"
                          >
                            Apply Now
                          </Button>
                        )}
                      </>
                    )}
                  </div>
                </div>

                <div className="flex items-center gap-2 mb-3">
                  <Badge className={getExperienceLevelColor(job.experienceLevel)}>
                    {job.experienceLevel} Level
                  </Badge>
                  <div className="flex items-center gap-1 text-sm text-muted-foreground">
                    <Users className="h-4 w-4" />
                    {job.applicationCount} applicants
                  </div>
                  <div className="flex items-center gap-1 text-sm text-muted-foreground">
                    <Eye className="h-4 w-4" />
                    {job.viewCount} views
                  </div>
                  <div className="flex items-center gap-1 text-sm text-muted-foreground">
                    <Calendar className="h-4 w-4" />
                    {job.applicationDeadline ? new Date(job.applicationDeadline).toLocaleDateString() : 'No deadline set'}
                  </div>
                </div>

                <p className="text-gray-700 mb-4 line-clamp-2">{job.description}</p>

                {job.requiredSkills && job.requiredSkills.length > 0 && (
                  <div className="flex flex-wrap gap-2">
                    {job.requiredSkills.slice(0, 5).map((skill) => (
                      <Badge key={skill} variant="secondary">
                        {skill}
                      </Badge>
                    ))}
                    {job.requiredSkills.length > 5 && (
                      <Badge variant="secondary">
                        +{job.requiredSkills.length - 5} more
                      </Badge>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>
          ))
        )}
      </div>

      {/* Job Application Modal */}
      {selectedJob && (
        <JobApplicationModal
          isOpen={isApplicationModalOpen}
          onClose={() => {
            setIsApplicationModalOpen(false);
            setSelectedJob(null);
          }}
          job={selectedJob}
        />
      )}
    </div>
  );
}

export default function JobBoard() {
  const config = platformConfigs.candidate;
  
  const usageData = [
    { label: "Job Searches", current: 15, max: 50 },
    { label: "Applications", current: 8, max: 25 },
    { label: "Profile Views", current: 42, max: 100 },
  ];

  return (
    <PlatformLayout
      sidebarTitle={config.sidebarTitle}
      sidebarSubtitle={config.sidebarSubtitle}
      sidebarSections={config.sidebarSections}
      usageData={usageData}
    >
      <JobBoardContent />
    </PlatformLayout>
  );
}

