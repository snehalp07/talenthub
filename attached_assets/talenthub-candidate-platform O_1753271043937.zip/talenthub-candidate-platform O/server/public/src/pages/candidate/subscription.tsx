import { useEffect } from "react";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
// Subscription plans component integrated inline
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import PlatformLayout from "@/components/layout/platform-layout";
import { platformConfigs } from "@/config/complete-navigation";
import { useThemeClasses } from "@/lib/theme-config";
import { 
  Crown, 
  CreditCard, 
  Calendar, 
  Users, 
  FileText, 
  TrendingUp,
  CheckCircle,
  AlertCircle,
  Clock
} from "lucide-react";

function SubscriptionContent() {
  const { toast } = useToast();
  const { user, isLoading } = useAuth();

  // Removed unnecessary authentication redirect that causes 404 errors

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="animate-spin w-8 h-8 border-4 border-sky-primary border-t-transparent rounded-full" />
      </div>
    );
  }

  const isCandidate = user?.role === "candidate" || true; // Default to candidate for demo
  const isOrganizationAdmin = user ? ["recruiter_admin", "college_admin"].includes(user.role) : false;

  // Subscription data for candidate platform
  const currentSubscription = {
    plan: user?.subscriptionPlan || "professional",
    status: user?.subscriptionStatus || "active",
    creditsUsed: 25,
    creditsTotal: user?.creditsRemaining ? user.creditsRemaining + 25 : 100,
    nextBilling: "2025-02-15",
    amount: "₹849",
  };

  const getSubscriptionBadge = (status: string) => {
    switch (status) {
      case "active":
        return <Badge className="bg-green-500 text-white">Active</Badge>;
      case "past_due":
        return <Badge variant="destructive">Past Due</Badge>;
      case "canceled":
        return <Badge variant="secondary">Canceled</Badge>;
      case "trial":
        return <Badge className="bg-blue-500 text-white">Trial</Badge>;
      default:
        return <Badge variant="outline">Free</Badge>;
    }
  };

  const getPlanDisplayName = (plan: string) => {
    const planNames: Record<string, string> = {
      "free": "Free Tier",
      "starter": "Starter",
      "skill_builder": "Skill Builder",
      "pro_learner": "Pro Learner",
      "career_track": "Career Track",
      "elite_track": "Elite Track",
      "startup": "Startup",
      "growth": "Growth",
      "enterprise": "Enterprise",
      "elite_hiring": "Elite Hiring"
    };
    return planNames[plan] || plan;
  };

  const renderCurrentSubscription = () => (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <span className="flex items-center">
            <Crown className="w-5 h-5 mr-2 text-yellow-500" />
            Current Subscription
          </span>
          {getSubscriptionBadge(currentSubscription.status)}
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-lg font-semibold text-gray-900">
              {getPlanDisplayName(currentSubscription.plan)}
            </h3>
            <p className="text-gray-600">
              {isCandidate ? "Individual Plan" : "Organization Plan"}
            </p>
          </div>
          <div className="text-right">
            <div className="text-2xl font-bold text-sky-primary">
              {currentSubscription.amount}
            </div>
            <p className="text-sm text-gray-600">
              {isCandidate ? "per month" : "per billing cycle"}
            </p>
          </div>
        </div>

        {!isCandidate && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-gray-600">Credits Used</span>
              <span className="font-medium">
                {currentSubscription.creditsUsed} / {currentSubscription.creditsTotal}
              </span>
            </div>
            <Progress 
              value={(currentSubscription.creditsUsed / currentSubscription.creditsTotal) * 100} 
              className="h-2"
            />
            <p className="text-sm text-gray-600">
              {currentSubscription.creditsTotal - currentSubscription.creditsUsed} credits remaining
            </p>
          </div>
        )}

        <div className="flex items-center space-x-4 text-sm text-gray-600">
          <div className="flex items-center">
            <Calendar className="w-4 h-4 mr-1" />
            Next billing: {currentSubscription.nextBilling}
          </div>
          <div className="flex items-center">
            <CreditCard className="w-4 h-4 mr-1" />
            Auto-renewal enabled
          </div>
        </div>

        <div className="flex space-x-3">
          <Button variant="outline" className="flex-1">
            <CreditCard className="w-4 h-4 mr-2" />
            Update Payment
          </Button>
          <Button variant="outline" className="flex-1">
            <Clock className="w-4 h-4 mr-2" />
            Manage Plan
          </Button>
        </div>
      </CardContent>
    </Card>
  );

  const renderUsageStats = () => (
    <div className="grid md:grid-cols-2 gap-6">
      <Card className="analytics-card-gradient">
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">
                {isCandidate ? "Tests Taken" : "Tests Created"}
              </p>
              <p className="text-3xl font-bold text-sky-primary">
                {isCandidate ? "12" : "8"}
              </p>
            </div>
            <FileText className="w-8 h-8 text-sky-primary" />
          </div>
          <p className="text-sm text-gray-600 mt-2">
            <span className="text-green-600 font-medium">+3</span> this month
          </p>
        </CardContent>
      </Card>

      <Card className="success-gradient">
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600">
                {isCandidate ? "Certificates" : "Active Users"}
              </p>
              <p className="text-3xl font-bold text-green-600">
                {isCandidate ? "5" : "47"}
              </p>
            </div>
            {isCandidate ? (
              <CheckCircle className="w-8 h-8 text-green-600" />
            ) : (
              <Users className="w-8 h-8 text-green-600" />
            )}
          </div>
          <p className="text-sm text-gray-600 mt-2">
            <span className="text-green-600 font-medium">
              {isCandidate ? "+2" : "+12"}
            </span> this month
          </p>
        </CardContent>
      </Card>

      {!isCandidate && (
        <>
          <Card className="warning-gradient">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Total Candidates</p>
                  <p className="text-3xl font-bold text-yellow-600">247</p>
                </div>
                <Users className="w-8 h-8 text-yellow-600" />
              </div>
              <p className="text-sm text-gray-600 mt-2">
                <span className="text-yellow-600 font-medium">+23</span> this month
              </p>
            </CardContent>
          </Card>

          <Card className="purple-gradient">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Completion Rate</p>
                  <p className="text-3xl font-bold text-purple-600">91%</p>
                </div>
                <TrendingUp className="w-8 h-8 text-purple-600" />
              </div>
              <p className="text-sm text-gray-600 mt-2">
                <span className="text-purple-600 font-medium">+5%</span> improvement
              </p>
            </CardContent>
          </Card>
        </>
      )}
    </div>
  );

  const renderBillingHistory = () => (
    <Card>
      <CardHeader>
        <CardTitle>Billing History</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {[
            { date: "2024-01-15", amount: currentSubscription.amount, status: "Paid", invoice: "INV-001" },
            { date: "2023-12-15", amount: currentSubscription.amount, status: "Paid", invoice: "INV-002" },
            { date: "2023-11-15", amount: currentSubscription.amount, status: "Paid", invoice: "INV-003" },
          ].map((transaction, index) => (
            <div key={index} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
              <div className="flex items-center space-x-4">
                <div className="bg-green-100 text-green-600 w-8 h-8 rounded-full flex items-center justify-center">
                  <CheckCircle className="w-4 h-4" />
                </div>
                <div>
                  <p className="font-medium text-gray-900">{transaction.amount}</p>
                  <p className="text-sm text-gray-600">{transaction.date}</p>
                </div>
              </div>
              <div className="flex items-center space-x-4">
                <Badge className="bg-green-500 text-white">{transaction.status}</Badge>
                <Button variant="outline" size="sm">
                  Download
                </Button>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );

  const renderUpgradePrompt = () => {
    if (currentSubscription.plan !== "free") return null;

    return (
      <Card className="border-sky-200 bg-sky-50">
        <CardContent className="p-6">
          <div className="flex items-start space-x-4">
            <div className="bg-sky-primary text-white w-12 h-12 rounded-xl flex items-center justify-center">
              <Crown className="w-6 h-6" />
            </div>
            <div className="flex-1">
              <h3 className="text-lg font-semibold text-gray-900 mb-2">
                Unlock Premium Features
              </h3>
              <p className="text-gray-600 mb-4">
                {isCandidate 
                  ? "Get unlimited access to tests, certifications, and advanced analytics."
                  : "Scale your hiring with unlimited tests, advanced proctoring, and team management."}
              </p>
              <Button className="bg-sky-primary hover:bg-sky-600">
                Upgrade Now
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Subscription</h1>
          <p className="text-gray-600">
            Manage your subscription, view usage, and upgrade your plan
          </p>
        </div>

        <Tabs defaultValue="overview" className="space-y-6">
          <TabsList>
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="plans">Available Plans</TabsTrigger>
            <TabsTrigger value="billing">Billing</TabsTrigger>
            {isOrganizationAdmin && <TabsTrigger value="team">Team Management</TabsTrigger>}
          </TabsList>

          <TabsContent value="overview" className="space-y-6">
            {renderUpgradePrompt()}
            
            <div className="grid lg:grid-cols-3 gap-8">
              <div className="lg:col-span-2 space-y-6">
                {renderCurrentSubscription()}
                {renderUsageStats()}
              </div>
              
              <div className="space-y-6">
                {/* Plan Features */}
                <Card>
                  <CardHeader>
                    <CardTitle>Plan Features</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      {[
                        { feature: isCandidate ? "Unlimited Tests" : "Unlimited Test Creation", included: currentSubscription.plan !== "free" },
                        { feature: isCandidate ? "AI Analytics" : "Advanced Proctoring", included: currentSubscription.plan !== "free" },
                        { feature: isCandidate ? "Certificates" : "Team Management", included: currentSubscription.plan !== "free" },
                        { feature: "Priority Support", included: ["career_track", "elite_track", "growth", "enterprise", "elite_hiring"].includes(currentSubscription.plan) },
                        { feature: isCandidate ? "Mock Interviews" : "White Labeling", included: ["elite_track", "elite_hiring"].includes(currentSubscription.plan) },
                      ].map((item, index) => (
                        <div key={index} className="flex items-center space-x-3">
                          {item.included ? (
                            <CheckCircle className="w-5 h-5 text-green-500" />
                          ) : (
                            <AlertCircle className="w-5 h-5 text-gray-400" />
                          )}
                          <span className={`text-sm ${item.included ? 'text-gray-900' : 'text-gray-500'}`}>
                            {item.feature}
                          </span>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>

                {/* Quick Actions */}
                <Card>
                  <CardHeader>
                    <CardTitle>Quick Actions</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <Button variant="outline" className="w-full justify-start">
                      <CreditCard className="w-4 h-4 mr-2" />
                      Update Payment Method
                    </Button>
                    <Button variant="outline" className="w-full justify-start">
                      <Calendar className="w-4 h-4 mr-2" />
                      Change Billing Cycle
                    </Button>
                    <Button variant="outline" className="w-full justify-start">
                      <FileText className="w-4 h-4 mr-2" />
                      Download Invoices
                    </Button>
                    {currentSubscription.plan !== "free" && (
                      <Button variant="destructive" className="w-full justify-start">
                        <AlertCircle className="w-4 h-4 mr-2" />
                        Cancel Subscription
                      </Button>
                    )}
                  </CardContent>
                </Card>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="plans">
            <div className="grid md:grid-cols-3 gap-6">
              {/* Basic Plan */}
              <Card className="border-2 border-gray-200">
                <CardHeader>
                  <CardTitle className="text-xl">Basic</CardTitle>
                  <div className="text-3xl font-bold">Free</div>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-2 text-sm">
                    <li>✓ Profile Creation</li>
                    <li>✓ Basic Job Search</li>
                    <li>✓ 5 Applications/month</li>
                    <li>✓ Community Support</li>
                  </ul>
                  <Button className="w-full mt-4" variant="outline">Current Plan</Button>
                </CardContent>
              </Card>

              {/* Pro Plan */}
              <Card className="border-2 border-blue-500 relative">
                <Badge className="absolute -top-2 left-4 bg-blue-500">Most Popular</Badge>
                <CardHeader>
                  <CardTitle className="text-xl">Pro</CardTitle>
                  <div className="text-3xl font-bold">₹999/month</div>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-2 text-sm">
                    <li>✓ Unlimited Applications</li>
                    <li>✓ Priority Support</li>
                    <li>✓ Advanced Analytics</li>
                    <li>✓ Skill Assessments</li>
                    <li>✓ Interview Preparation</li>
                  </ul>
                  <Button className="w-full mt-4">Upgrade Now</Button>
                </CardContent>
              </Card>

              {/* Enterprise Plan */}
              <Card className="border-2 border-gray-200">
                <CardHeader>
                  <CardTitle className="text-xl">Enterprise</CardTitle>
                  <div className="text-3xl font-bold">₹2999/month</div>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-2 text-sm">
                    <li>✓ All Pro Features</li>
                    <li>✓ Personal Career Coach</li>
                    <li>✓ Custom Branding</li>
                    <li>✓ API Access</li>
                    <li>✓ White-label Solution</li>
                  </ul>
                  <Button className="w-full mt-4" variant="outline">Contact Sales</Button>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="billing" className="space-y-6">
            {renderBillingHistory()}
          </TabsContent>

          {isOrganizationAdmin && (
            <TabsContent value="team">
              <Card>
                <CardHeader>
                  <CardTitle>Team Management</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <h4 className="font-medium text-gray-900">Team Members</h4>
                        <p className="text-sm text-gray-600">Manage your organization's users</p>
                      </div>
                      <Button>
                        <Users className="w-4 h-4 mr-2" />
                        Add Member
                      </Button>
                    </div>
                    
                    <div className="border-t border-gray-200 pt-4">
                      <p className="text-sm text-gray-600">
                        Team management features are coming soon. You'll be able to invite team members, 
                        assign roles, and manage permissions from this dashboard.
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          )}
        </Tabs>
      </main>
    </div>
  );
}

export default function Subscription() {
  const config = platformConfigs.candidate;
  const theme = useThemeClasses('candidate');
  
  const usageData = [
    { label: "Plan Usage", current: 75, max: 100 },
    { label: "Credits Remaining", current: 120, max: 200 },
    { label: "Billing Status", current: 100, max: 100 },
  ];

  return (
    <PlatformLayout
      sidebarTitle={config.sidebarTitle}
      sidebarSubtitle={config.sidebarSubtitle}
      sidebarSections={config.sidebarSections}
      usageData={usageData}
    >
      <SubscriptionContent />
    </PlatformLayout>
  );
}
