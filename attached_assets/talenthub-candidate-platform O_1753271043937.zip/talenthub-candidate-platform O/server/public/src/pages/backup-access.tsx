import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Download, FileArchive, Calendar, HardDrive } from "lucide-react";

export default function BackupAccess() {
  const [backupInfo, setBackupInfo] = useState<any>(null);
  const [loading, setLoading] = useState(false);

  const checkBackupStatus = async () => {
    setLoading(true);
    try {
      // Get backup information directly from the file system
      const response = await fetch('/api/backup/status');
      if (response.ok) {
        const data = await response.json();
        setBackupInfo(data);
      }
    } catch (error) {
      console.error('Failed to check backup status:', error);
    } finally {
      setLoading(false);
    }
  };

  const downloadBackup = (filename: string) => {
    // Direct download from the download folder
    window.open(`/download/${filename}`, '_blank');
  };

  const formatFileSize = (bytes: number) => {
    const mb = bytes / (1024 * 1024);
    return `${mb.toFixed(1)} MB`;
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-sky-50 via-white to-blue-50 p-6">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-sky-800 mb-4">TalentHub Backup Access</h1>
          <p className="text-sky-600 text-lg">Download project backups and access system files</p>
        </div>

        {/* Backup Status Card */}
        <Card className="shadow-lg border-sky-200 mb-6">
          <CardHeader>
            <CardTitle className="text-sky-800 flex items-center gap-2">
              <FileArchive className="h-6 w-6" />
              Backup Status
            </CardTitle>
            <CardDescription>Check and download available project backups</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex gap-4 mb-6">
              <Button 
                onClick={checkBackupStatus} 
                disabled={loading}
                className="bg-sky-600 hover:bg-sky-700"
              >
                <HardDrive className="h-4 w-4 mr-2" />
                {loading ? 'Checking...' : 'Check Backup Status'}
              </Button>
            </div>

            {backupInfo && (
              <div className="space-y-4">
                <div className="p-4 bg-sky-50 rounded-lg border border-sky-200">
                  <h3 className="font-semibold text-sky-800 mb-2">Available Backups</h3>
                  <div className="space-y-3">
                    {backupInfo.backupFiles?.map((filename: string, index: number) => (
                      <div key={index} className="flex items-center justify-between p-3 bg-white rounded border border-sky-100">
                        <div className="flex items-center gap-3">
                          <FileArchive className="h-5 w-5 text-sky-600" />
                          <div>
                            <p className="font-medium text-sky-800">{filename}</p>
                            <p className="text-sm text-sky-600">
                              <Calendar className="h-4 w-4 inline mr-1" />
                              {filename.includes('20250613') ? 'Today' : 'Recent'}
                            </p>
                          </div>
                        </div>
                        <div className="flex items-center gap-3">
                          {filename === backupInfo.latestBackup && (
                            <Badge variant="secondary" className="bg-sky-100 text-sky-700">
                              Latest
                            </Badge>
                          )}
                          <Button
                            onClick={() => downloadBackup(filename)}
                            size="sm"
                            className="bg-sky-600 hover:bg-sky-700"
                          >
                            <Download className="h-4 w-4 mr-1" />
                            Download
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Direct Download Links */}
        <Card className="shadow-lg border-sky-200">
          <CardHeader>
            <CardTitle className="text-sky-800">Direct Downloads</CardTitle>
            <CardDescription>Known backup files available for download</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div 
                className="p-4 border border-sky-200 rounded-lg hover:bg-sky-50 transition-colors cursor-pointer"
                onClick={() => downloadBackup('talenthub-backup-20250613_212417.tar.gz')}
              >
                <div className="flex items-center gap-3">
                  <FileArchive className="h-6 w-6 text-sky-600" />
                  <div>
                    <p className="font-medium text-sky-800">Latest TalentHub Backup</p>
                    <p className="text-sm text-sky-600">June 13, 2025 - Complete Project</p>
                    <Badge variant="outline" className="mt-1">~97.6 MB</Badge>
                  </div>
                </div>
              </div>

              <div 
                className="p-4 border border-sky-200 rounded-lg hover:bg-sky-50 transition-colors cursor-pointer"
                onClick={() => downloadBackup('talenthub-lms-complete-backup-2025-06-13.tar.gz')}
              >
                <div className="flex items-center gap-3">
                  <FileArchive className="h-6 w-6 text-sky-600" />
                  <div>
                    <p className="font-medium text-sky-800">LMS Module Backup</p>
                    <p className="text-sm text-sky-600">June 13, 2025 - LMS Components</p>
                    <Badge variant="outline" className="mt-1">~264 KB</Badge>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Instructions */}
        <div className="mt-8 p-6 bg-sky-50 rounded-lg border border-sky-200">
          <h3 className="font-semibold text-sky-800 mb-2">Download Instructions</h3>
          <ul className="text-sky-700 space-y-1 text-sm">
            <li>• Click "Download" buttons to get backup files</li>
            <li>• Files are compressed .tar.gz archives containing the complete project</li>
            <li>• Extract with: <code className="bg-white px-2 py-1 rounded">tar -xzf filename.tar.gz</code></li>
            <li>• Backups exclude node_modules, .git, and build artifacts for smaller file sizes</li>
          </ul>
        </div>
      </div>
    </div>
  );
}