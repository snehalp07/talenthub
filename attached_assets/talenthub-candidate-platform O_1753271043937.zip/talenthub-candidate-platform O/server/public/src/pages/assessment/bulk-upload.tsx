import PlatformLayout from "@/components/layout/platform-layout";
import { NavigationSection } from "@/components/layout/expandable-sidebar";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  Target,
  BarChart3,
  FileText,
  Database,
  Award,
  Play,
  Users,
  TrendingUp,
  Shield,
  BookOpen,
  Upload,
  Download,
  FileSpreadsheet,
  AlertCircle
} from "lucide-react";

const assessmentNavigation: NavigationSection[] = [
  {
    title: "Assessment Hub",
    items: [
      { name: "Dashboard", href: "/assessment/dashboard", icon: Target }
    ]
  },
  {
    title: "Take Assessments",
    items: [
      { name: "Browse Tests", href: "/assessment/browse-tests", icon: Target },
      { name: "Test Runner", href: "/assessment/test-runner", icon: Play },
      { name: "Test Results", href: "/assessment/test-results", icon: BarChart3 }
    ]
  },
  {
    title: "Create & Manage",
    items: [
      { name: "Question Banks", href: "/assessment/question-bank", icon: Database },
      { name: "Bulk Upload", href: "/assessment/bulk-upload", icon: FileText },
      { name: "User Management", href: "/assessment/users", icon: Users }
    ]
  },
  {
    title: "Analytics & Reports",
    items: [
      { name: "Assessment Analytics", href: "/assessment/analytics", icon: TrendingUp },
      { name: "Platform Overview", href: "/assessment/overview", icon: BarChart3 }
    ]
  },
  {
    title: "Certification",
    items: [
      { name: "Earned Certificates", href: "/assessment/certifications", icon: Award },
      { name: "Blockchain Certs", href: "/assessment/blockchain-certificates", icon: Shield }
    ]
  },
  {
    title: "Learning Integration",
    items: [
      { name: "LMS Courses", href: "/assessment/courses", icon: BookOpen },
      { name: "Practice Tests", href: "/assessment/practice-tests", icon: Target }
    ]
  }
];

export default function AssessmentBulkUpload() {
  const usageData = [
    { label: "Monthly Tests", current: 245, max: 500 },
    { label: "Active Users", current: 1247, max: 2000 },
    { label: "Storage Used", current: 12, max: 50 }
  ];

  return (
    <PlatformLayout
      sidebarTitle="Assessment Platform"
      sidebarSubtitle="Testing & Evaluation Hub"
      sidebarSections={assessmentNavigation}
      usageData={usageData}
    >
      <div className="space-y-8">
        {/* Header */}
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Bulk Upload Management</h1>
            <p className="text-gray-600 mt-2">Upload questions, users, and test data in bulk operations</p>
          </div>
          <Button 
            className="bg-purple-600 hover:bg-purple-700"
            onClick={() => window.location.href = "/admin/bulk-upload"}
          >
            <Upload className="w-4 h-4 mr-2" />
            Access Admin Bulk Upload
          </Button>
        </div>

        {/* Upload Options */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card className="border-2 border-dashed border-gray-300 hover:border-purple-400 transition-colors">
            <CardHeader className="text-center">
              <FileSpreadsheet className="w-12 h-12 text-purple-600 mx-auto mb-4" />
              <CardTitle>Question Upload</CardTitle>
              <CardDescription>
                Upload multiple questions via CSV or Excel format
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Button 
                variant="outline" 
                className="w-full"
                onClick={() => window.location.href = "/admin/bulk-upload?type=questions"}
              >
                Upload Questions
              </Button>
              <p className="text-xs text-gray-500 mt-2 text-center">
                Supports: CSV, XLSX, JSON
              </p>
            </CardContent>
          </Card>

          <Card className="border-2 border-dashed border-gray-300 hover:border-blue-400 transition-colors">
            <CardHeader className="text-center">
              <Users className="w-12 h-12 text-blue-600 mx-auto mb-4" />
              <CardTitle>User Upload</CardTitle>
              <CardDescription>
                Import candidate and user data in bulk
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Button 
                variant="outline" 
                className="w-full"
                onClick={() => window.location.href = "/admin/users?action=bulk-import"}
              >
                Upload Users
              </Button>
              <p className="text-xs text-gray-500 mt-2 text-center">
                Supports: CSV, XLSX
              </p>
            </CardContent>
          </Card>

          <Card className="border-2 border-dashed border-gray-300 hover:border-green-400 transition-colors">
            <CardHeader className="text-center">
              <Target className="w-12 h-12 text-green-600 mx-auto mb-4" />
              <CardTitle>Test Data</CardTitle>
              <CardDescription>
                Upload complete test configurations and results
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Button 
                variant="outline" 
                className="w-full"
                onClick={() => window.location.href = "/admin/bulk-upload?type=tests"}
              >
                Upload Tests
              </Button>
              <p className="text-xs text-gray-500 mt-2 text-center">
                Supports: JSON, XML
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Recent Upload History */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Upload className="w-5 h-5 text-purple-600" />
              Recent Upload Activity
            </CardTitle>
            <CardDescription>
              Track your recent bulk upload operations and their status
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center justify-between p-4 border rounded-lg">
                <div className="flex items-center gap-4">
                  <FileSpreadsheet className="w-8 h-8 text-purple-600" />
                  <div>
                    <h3 className="font-semibold">JavaScript Questions Batch</h3>
                    <p className="text-sm text-gray-600">156 questions uploaded</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <Badge className="bg-green-100 text-green-800">Completed</Badge>
                  <span className="text-sm text-gray-500">2 hours ago</span>
                </div>
              </div>

              <div className="flex items-center justify-between p-4 border rounded-lg">
                <div className="flex items-center gap-4">
                  <Users className="w-8 h-8 text-blue-600" />
                  <div>
                    <h3 className="font-semibold">Candidate User Import</h3>
                    <p className="text-sm text-gray-600">89 users imported</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <Badge className="bg-green-100 text-green-800">Completed</Badge>
                  <span className="text-sm text-gray-500">1 day ago</span>
                </div>
              </div>

              <div className="flex items-center justify-between p-4 border rounded-lg">
                <div className="flex items-center gap-4">
                  <AlertCircle className="w-8 h-8 text-amber-600" />
                  <div>
                    <h3 className="font-semibold">React Assessment Data</h3>
                    <p className="text-sm text-gray-600">12 of 15 tests uploaded</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <Badge className="bg-amber-100 text-amber-800">Partial</Badge>
                  <span className="text-sm text-gray-500">3 days ago</span>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Template Downloads */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Download className="w-5 h-5 text-purple-600" />
              Download Templates
            </CardTitle>
            <CardDescription>
              Get standardized templates for bulk upload operations
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Button variant="outline" className="justify-start p-4 h-auto">
                <div className="flex items-center gap-3">
                  <FileSpreadsheet className="w-6 h-6 text-purple-600" />
                  <div className="text-left">
                    <div className="font-medium">Question Template</div>
                    <div className="text-sm text-gray-500">CSV format for bulk question upload</div>
                  </div>
                </div>
              </Button>

              <Button variant="outline" className="justify-start p-4 h-auto">
                <div className="flex items-center gap-3">
                  <Users className="w-6 h-6 text-blue-600" />
                  <div className="text-left">
                    <div className="font-medium">User Template</div>
                    <div className="text-sm text-gray-500">CSV format for bulk user import</div>
                  </div>
                </div>
              </Button>

              <Button variant="outline" className="justify-start p-4 h-auto">
                <div className="flex items-center gap-3">
                  <Target className="w-6 h-6 text-green-600" />
                  <div className="text-left">
                    <div className="font-medium">Test Template</div>
                    <div className="text-sm text-gray-500">JSON format for test configuration</div>
                  </div>
                </div>
              </Button>

              <Button variant="outline" className="justify-start p-4 h-auto">
                <div className="flex items-center gap-3">
                  <BarChart3 className="w-6 h-6 text-indigo-600" />
                  <div className="text-left">
                    <div className="font-medium">Results Template</div>
                    <div className="text-sm text-gray-500">CSV format for result import</div>
                  </div>
                </div>
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Integration Links */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle>Admin Tools</CardTitle>
              <CardDescription>Access existing admin bulk operation tools</CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              <Button 
                variant="outline" 
                className="w-full justify-start"
                onClick={() => window.location.href = "/admin/bulk-upload"}
              >
                <Upload className="w-4 h-4 mr-2" />
                Admin Bulk Upload Interface
              </Button>
              <Button 
                variant="outline" 
                className="w-full justify-start"
                onClick={() => window.location.href = "/admin/users"}
              >
                <Users className="w-4 h-4 mr-2" />
                Admin User Management
              </Button>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Related Features</CardTitle>
              <CardDescription>Connect with other Assessment Platform tools</CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              <Button 
                variant="outline" 
                className="w-full justify-start"
                onClick={() => window.location.href = "/assessment/question-bank"}
              >
                <Database className="w-4 h-4 mr-2" />
                Question Bank Management
              </Button>
              <Button 
                variant="outline" 
                className="w-full justify-start"
                onClick={() => window.location.href = "/assessment/analytics"}
              >
                <BarChart3 className="w-4 h-4 mr-2" />
                Upload Analytics
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </PlatformLayout>
  );
}