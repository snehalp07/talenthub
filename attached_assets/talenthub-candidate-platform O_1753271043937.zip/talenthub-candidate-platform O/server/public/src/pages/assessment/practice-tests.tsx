import PlatformLayout from "@/components/layout/platform-layout";
import { NavigationSection } from "@/components/layout/expandable-sidebar";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  Target,
  BarChart3,
  FileText,
  Database,
  Award,
  Play,
  Users,
  TrendingUp,
  Shield,
  BookOpen,
  ExternalLink,
  Clock,
  CheckCircle
} from "lucide-react";

const assessmentNavigation: NavigationSection[] = [
  {
    title: "Assessment Hub",
    items: [
      { name: "Dashboard", href: "/assessment/dashboard", icon: Target }
    ]
  },
  {
    title: "Take Assessments",
    items: [
      { name: "Browse Tests", href: "/assessment/browse-tests", icon: Target },
      { name: "Test Runner", href: "/assessment/test-runner", icon: Play },
      { name: "Test Results", href: "/assessment/test-results", icon: BarChart3 }
    ]
  },
  {
    title: "Create & Manage",
    items: [
      { name: "Question Banks", href: "/assessment/question-bank", icon: Database },
      { name: "Bulk Upload", href: "/assessment/bulk-upload", icon: FileText },
      { name: "User Management", href: "/assessment/users", icon: Users }
    ]
  },
  {
    title: "Analytics & Reports",
    items: [
      { name: "Assessment Analytics", href: "/assessment/analytics", icon: TrendingUp },
      { name: "Platform Overview", href: "/assessment/overview", icon: BarChart3 }
    ]
  },
  {
    title: "Certification",
    items: [
      { name: "Earned Certificates", href: "/assessment/certifications", icon: Award },
      { name: "Blockchain Certs", href: "/assessment/blockchain-certificates", icon: Shield }
    ]
  },
  {
    title: "Learning Integration",
    items: [
      { name: "LMS Courses", href: "/assessment/courses", icon: BookOpen },
      { name: "Practice Tests", href: "/assessment/practice-tests", icon: Target }
    ]
  }
];

export default function AssessmentPracticeTests() {
  const usageData = [
    { label: "Monthly Tests", current: 245, max: 500 },
    { label: "Active Users", current: 1247, max: 2000 },
    { label: "Storage Used", current: 12, max: 50 }
  ];

  return (
    <PlatformLayout
      sidebarTitle="Assessment Platform"
      sidebarSubtitle="Testing & Evaluation Hub"
      sidebarSections={assessmentNavigation}
      usageData={usageData}
    >
      <div className="space-y-8">
        {/* Header */}
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Practice Tests</h1>
            <p className="text-gray-600 mt-2">Learning-integrated practice assessments and skill validation</p>
          </div>
          <Button 
            variant="outline"
            onClick={() => window.location.href = "/lms/practice-tests"}
          >
            <ExternalLink className="w-4 h-4 mr-2" />
            LMS Practice Tests
          </Button>
        </div>

        {/* Practice Test Categories */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card className="border-l-4 border-green-500">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Target className="w-5 h-5 text-green-600" />
                Skill Validation
              </CardTitle>
              <CardDescription>Practice tests for skill assessment</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-sm font-medium">Available Tests</span>
                  <Badge className="bg-green-100 text-green-800">156</Badge>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm font-medium">Completion Rate</span>
                  <span className="text-sm text-green-600">87%</span>
                </div>
                <Button 
                  size="sm" 
                  className="w-full"
                  onClick={() => window.location.href = "/assessment/browse-tests?category=skill-validation"}
                >
                  Start Practice
                </Button>
              </div>
            </CardContent>
          </Card>

          <Card className="border-l-4 border-blue-500">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BookOpen className="w-5 h-5 text-blue-600" />
                Course Integration
              </CardTitle>
              <CardDescription>Tests integrated with learning courses</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-sm font-medium">Course Tests</span>
                  <Badge className="bg-blue-100 text-blue-800">89</Badge>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm font-medium">Pass Rate</span>
                  <span className="text-sm text-blue-600">92%</span>
                </div>
                <Button 
                  size="sm" 
                  className="w-full"
                  onClick={() => window.location.href = "/assessment/courses"}
                >
                  Browse Courses
                </Button>
              </div>
            </CardContent>
          </Card>

          <Card className="border-l-4 border-purple-500">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Award className="w-5 h-5 text-purple-600" />
                Certification Prep
              </CardTitle>
              <CardDescription>Preparation for certification exams</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-sm font-medium">Prep Tests</span>
                  <Badge className="bg-purple-100 text-purple-800">67</Badge>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm font-medium">Certified</span>
                  <span className="text-sm text-purple-600">78%</span>
                </div>
                <Button 
                  size="sm" 
                  className="w-full"
                  onClick={() => window.location.href = "/assessment/certifications"}
                >
                  View Certs
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Recent Practice Sessions */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Clock className="w-5 h-5 text-purple-600" />
              Recent Practice Sessions
            </CardTitle>
            <CardDescription>
              Latest practice test activities and results
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center justify-between p-4 border rounded-lg">
                <div className="flex items-center gap-4">
                  <Target className="w-8 h-8 text-green-600" />
                  <div>
                    <h3 className="font-semibold text-gray-900">JavaScript Fundamentals Practice</h3>
                    <p className="text-sm text-gray-600">15 questions • 30 minutes</p>
                  </div>
                </div>
                <div className="text-right">
                  <div className="flex items-center gap-2">
                    <CheckCircle className="w-5 h-5 text-green-600" />
                    <span className="text-lg font-semibold text-green-600">85%</span>
                  </div>
                  <p className="text-sm text-gray-500">2 hours ago</p>
                </div>
              </div>

              <div className="flex items-center justify-between p-4 border rounded-lg">
                <div className="flex items-center gap-4">
                  <BookOpen className="w-8 h-8 text-blue-600" />
                  <div>
                    <h3 className="font-semibold text-gray-900">React Component Testing</h3>
                    <p className="text-sm text-gray-600">20 questions • 45 minutes</p>
                  </div>
                </div>
                <div className="text-right">
                  <div className="flex items-center gap-2">
                    <CheckCircle className="w-5 h-5 text-blue-600" />
                    <span className="text-lg font-semibold text-blue-600">92%</span>
                  </div>
                  <p className="text-sm text-gray-500">1 day ago</p>
                </div>
              </div>

              <div className="flex items-center justify-between p-4 border rounded-lg">
                <div className="flex items-center gap-4">
                  <Award className="w-8 h-8 text-purple-600" />
                  <div>
                    <h3 className="font-semibold text-gray-900">AWS Certification Practice</h3>
                    <p className="text-sm text-gray-600">50 questions • 90 minutes</p>
                  </div>
                </div>
                <div className="text-right">
                  <div className="flex items-center gap-2">
                    <CheckCircle className="w-5 h-5 text-purple-600" />
                    <span className="text-lg font-semibold text-purple-600">78%</span>
                  </div>
                  <p className="text-sm text-gray-500">3 days ago</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Integration Links */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle>LMS Integration</CardTitle>
              <CardDescription>Access full LMS practice test functionality</CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              <Button 
                variant="outline" 
                className="w-full justify-start"
                onClick={() => window.location.href = "/lms/practice-tests"}
              >
                <Target className="w-4 h-4 mr-2" />
                LMS Practice Tests
              </Button>
              <Button 
                variant="outline" 
                className="w-full justify-start"
                onClick={() => window.location.href = "/lms/courses"}
              >
                <BookOpen className="w-4 h-4 mr-2" />
                Course Assessments
              </Button>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Assessment Tools</CardTitle>
              <CardDescription>Connect with core assessment features</CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              <Button 
                variant="outline" 
                className="w-full justify-start"
                onClick={() => window.location.href = "/assessment/browse-tests"}
              >
                <Target className="w-4 h-4 mr-2" />
                Browse All Tests
              </Button>
              <Button 
                variant="outline" 
                className="w-full justify-start"
                onClick={() => window.location.href = "/assessment/test-results"}
              >
                <BarChart3 className="w-4 h-4 mr-2" />
                Practice Results
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </PlatformLayout>
  );
}