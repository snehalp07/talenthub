import { useState, useEffect } from "react";
import { useRoute } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Clock, CheckCircle, AlertCircle, ArrowLeft, ArrowRight, Code } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import Editor from "@monaco-editor/react";
import PlatformLayout from "@/components/layout/platform-layout";
import { NavigationSection } from "@/components/layout/expandable-sidebar";
import { 
  Target,
  BarChart3,
  FileText,
  Database,
  Award,
  Play,
  Users,
  TrendingUp,
  Shield,
  BookOpen
} from "lucide-react";

interface Question {
  id: string;
  type: string;
  title: string;
  content: string;
  options?: string[];
  correctAnswer: string;
  explanation: string;
  points: number;
  order: number;
  tags: string[];
}

interface Test {
  id: string;
  title: string;
  description: string;
  duration: number;
  totalQuestions: number;
  passingScore: number;
  difficulty: string;
  category: string;
  questions: Question[];
}

const assessmentNavigation: NavigationSection[] = [
  {
    title: "Assessment Hub",
    items: [
      { name: "Dashboard", href: "/assessment/dashboard", icon: Target }
    ]
  },
  {
    title: "Take Assessments",
    items: [
      { name: "Browse Tests", href: "/assessment/browse-tests", icon: Target },
      { name: "Test Runner", href: "/assessment/test-runner", icon: Play },
      { name: "Test Results", href: "/assessment/test-results", icon: BarChart3 }
    ]
  },
  {
    title: "Create & Manage",
    items: [
      { name: "Question Banks", href: "/assessment/question-bank", icon: Database },
      { name: "Bulk Upload", href: "/assessment/bulk-upload", icon: FileText },
      { name: "User Management", href: "/assessment/users", icon: Users }
    ]
  },
  {
    title: "Analytics & Reports",
    items: [
      { name: "Assessment Analytics", href: "/assessment/analytics", icon: TrendingUp },
      { name: "Platform Overview", href: "/assessment/overview", icon: BarChart3 }
    ]
  },
  {
    title: "Certification",
    items: [
      { name: "Earned Certificates", href: "/assessment/certifications", icon: Award },
      { name: "Blockchain Certs", href: "/assessment/blockchain-certificates", icon: Shield }
    ]
  },
  {
    title: "Learning Integration",
    items: [
      { name: "LMS Courses", href: "/assessment/courses", icon: BookOpen },
      { name: "Practice Tests", href: "/assessment/practice-tests", icon: Target }
    ]
  }
];

function TestRunnerContent() {
  const [, params] = useRoute("/assessment/test-runner/:testId");
  const testId = params?.testId || new URLSearchParams(window.location.search).get('testId');
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [answers, setAnswers] = useState<Record<string, string>>({});
  const [timeRemaining, setTimeRemaining] = useState(0);
  const [testStarted, setTestStarted] = useState(false);
  const [testCompleted, setTestCompleted] = useState(false);
  const { toast } = useToast();

  // Fetch test with questions
  const { data: test, isLoading } = useQuery<Test>({
    queryKey: ["/api/candidate/tests", testId],
    queryFn: async () => {
      const response = await fetch(`/api/candidate/tests/${testId}`);
      if (!response.ok) throw new Error("Failed to fetch test");
      return response.json();
    },
    enabled: !!testId,
  });

  // Submit test attempt
  const submitTestMutation = useMutation({
    mutationFn: async (testData: { testId: string; answers: Record<string, string>; timeSpent: number }) => {
      const response = await fetch("/api/candidate/test-attempts", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(testData),
      });
      if (!response.ok) throw new Error("Failed to submit test");
      return response.json();
    },
    onSuccess: (data) => {
      toast({
        title: "Test Submitted Successfully",
        description: `Score: ${data.score}%. ${data.certificationEarned ? '🎉 Certificate earned!' : 'Badge earned!'}`,
      });
      setTestCompleted(true);
    },
    onError: () => {
      toast({
        title: "Submission Failed",
        description: "Failed to submit test. Please try again.",
        variant: "destructive",
      });
    },
  });

  // Timer effect
  useEffect(() => {
    if (!testStarted || !test || timeRemaining <= 0) return;

    const timer = setInterval(() => {
      setTimeRemaining((prev) => {
        if (prev <= 1) {
          handleSubmitTest();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [testStarted, test]);

  const handleStartTest = () => {
    if (test) {
      setTimeRemaining(test.duration * 60); // Convert minutes to seconds
      setTestStarted(true);
    }
  };

  const handleSubmitTest = () => {
    if (!test || !testStarted) return;
    
    const timeSpent = (test.duration * 60) - timeRemaining;
    submitTestMutation.mutate({
      testId: test.id,
      answers,
      timeSpent,
    });
  };

  const handleAnswerChange = (questionId: string, answer: string) => {
    setAnswers(prev => ({ ...prev, [questionId]: answer }));
  };

  const handleNextQuestion = () => {
    if (test && currentQuestionIndex < test.questions.length - 1) {
      setCurrentQuestionIndex(prev => prev + 1);
    }
  };

  const handlePreviousQuestion = () => {
    if (currentQuestionIndex > 0) {
      setCurrentQuestionIndex(prev => prev - 1);
    }
  };

  const formatTime = (seconds: number) => {
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes}:${remainingSeconds.toString().padStart(2, '0')}`;
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-96">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-purple-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading test...</p>
        </div>
      </div>
    );
  }

  if (!test) {
    return (
      <div className="text-center py-12">
        <AlertCircle className="w-16 h-16 text-red-500 mx-auto mb-4" />
        <h3 className="text-lg font-medium text-gray-900 mb-2">Test not found</h3>
        <p className="text-gray-600 mb-4">The requested test could not be loaded.</p>
        <Button onClick={() => window.location.href = "/assessment/browse-tests"}>
          Browse Tests
        </Button>
      </div>
    );
  }

  if (testCompleted) {
    return (
      <div className="text-center py-12">
        <CheckCircle className="w-16 h-16 text-green-500 mx-auto mb-4" />
        <h3 className="text-lg font-medium text-gray-900 mb-2">Test Completed!</h3>
        <p className="text-gray-600 mb-4">Your answers have been submitted successfully.</p>
        <div className="space-x-4">
          <Button onClick={() => window.location.href = "/assessment/test-results"}>
            View Results
          </Button>
          <Button variant="outline" onClick={() => window.location.href = "/assessment/browse-tests"}>
            Take Another Test
          </Button>
        </div>
      </div>
    );
  }

  if (!testStarted) {
    return (
      <div className="max-w-2xl mx-auto py-8">
        <Card className="border-purple-200">
          <CardHeader className="text-center">
            <CardTitle className="text-2xl text-purple-800">{test.title}</CardTitle>
            <p className="text-gray-600">{test.description}</p>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
              <div>
                <div className="text-2xl font-bold text-purple-600">{test.duration}</div>
                <div className="text-sm text-gray-600">Minutes</div>
              </div>
              <div>
                <div className="text-2xl font-bold text-purple-600">{test.totalQuestions}</div>
                <div className="text-sm text-gray-600">Questions</div>
              </div>
              <div>
                <div className="text-2xl font-bold text-purple-600">{test.passingScore}%</div>
                <div className="text-sm text-gray-600">Pass Score</div>
              </div>
              <div>
                <div className="text-2xl font-bold text-purple-600">{test.difficulty}</div>
                <div className="text-sm text-gray-600">Difficulty</div>
              </div>
            </div>
            
            <div className="text-center">
              <Button onClick={handleStartTest} size="lg" className="bg-purple-600 hover:bg-purple-700">
                <Play className="w-5 h-5 mr-2" />
                Start Test
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  const currentQuestion = test.questions[currentQuestionIndex];
  const progress = ((currentQuestionIndex + 1) / test.questions.length) * 100;

  return (
    <div className="max-w-4xl mx-auto py-8">
      {/* Header */}
      <div className="mb-6">
        <div className="flex items-center justify-between mb-4">
          <h1 className="text-2xl font-bold text-purple-800">{test.title}</h1>
          <div className="flex items-center gap-4">
            <Badge variant="outline" className="text-purple-600 border-purple-600">
              <Clock className="w-4 h-4 mr-1" />
              {formatTime(timeRemaining)}
            </Badge>
            <Badge variant="secondary">
              Question {currentQuestionIndex + 1} of {test.questions.length}
            </Badge>
          </div>
        </div>
        <Progress value={progress} className="h-2" />
      </div>

      {/* Question */}
      <Card className="mb-6 border-purple-200">
        <CardHeader>
          <CardTitle className="text-lg">{currentQuestion.title}</CardTitle>
          <div className="flex items-center gap-2">
            <Badge variant="outline">{currentQuestion.type}</Badge>
            <Badge variant="secondary">{currentQuestion.points} points</Badge>
          </div>
        </CardHeader>
        <CardContent>
          <p className="text-gray-700 mb-6">{currentQuestion.content}</p>

          {currentQuestion.type === "multiple-choice" && (
            <RadioGroup
              value={answers[currentQuestion.id] || ""}
              onValueChange={(value) => handleAnswerChange(currentQuestion.id, value)}
              className="space-y-3"
            >
              {currentQuestion.options?.map((option, index) => (
                <div key={index} className="flex items-center space-x-2">
                  <RadioGroupItem value={option} id={`option-${index}`} />
                  <Label htmlFor={`option-${index}`} className="flex-1 cursor-pointer">
                    {option}
                  </Label>
                </div>
              ))}
            </RadioGroup>
          )}

          {currentQuestion.type === "coding" && (
            <div className="space-y-4">
              <div className="border rounded-lg overflow-hidden">
                <Editor
                  height="300px"
                  defaultLanguage="javascript"
                  theme="vs-dark"
                  value={answers[currentQuestion.id] || "// Write your solution here\n"}
                  onChange={(value) => handleAnswerChange(currentQuestion.id, value || "")}
                  options={{
                    minimap: { enabled: false },
                    fontSize: 14,
                    lineNumbers: "on",
                    wordWrap: "on",
                  }}
                />
              </div>
            </div>
          )}

          {currentQuestion.type === "text" && (
            <Textarea
              placeholder="Enter your answer here..."
              value={answers[currentQuestion.id] || ""}
              onChange={(e) => handleAnswerChange(currentQuestion.id, e.target.value)}
              className="min-h-32"
            />
          )}
        </CardContent>
      </Card>

      {/* Navigation */}
      <div className="flex items-center justify-between">
        <Button
          variant="outline"
          onClick={handlePreviousQuestion}
          disabled={currentQuestionIndex === 0}
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Previous
        </Button>

        <div className="flex gap-2">
          {currentQuestionIndex === test.questions.length - 1 ? (
            <Button
              onClick={handleSubmitTest}
              className="bg-green-600 hover:bg-green-700"
              disabled={submitTestMutation.isPending}
            >
              {submitTestMutation.isPending ? "Submitting..." : "Submit Test"}
            </Button>
          ) : (
            <Button onClick={handleNextQuestion}>
              Next
              <ArrowRight className="w-4 h-4 ml-2" />
            </Button>
          )}
        </div>
      </div>

      {/* Question Navigation */}
      <Card className="mt-6 border-purple-200">
        <CardHeader>
          <CardTitle className="text-sm">Question Overview</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-10 gap-2">
            {test.questions.map((_, index) => (
              <Button
                key={index}
                variant={index === currentQuestionIndex ? "default" : "outline"}
                size="sm"
                className={`
                  ${index === currentQuestionIndex ? "bg-purple-600 hover:bg-purple-700" : ""}
                  ${answers[test.questions[index].id] ? "ring-2 ring-green-500" : ""}
                `}
                onClick={() => setCurrentQuestionIndex(index)}
              >
                {index + 1}
              </Button>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

export default function AssessmentTestRunner() {
  const usageData = [
    { label: "Monthly Tests", current: 245, max: 500 },
    { label: "Active Users", current: 1247, max: 2000 },
    { label: "Storage Used", current: 12, max: 50 }
  ];

  return (
    <PlatformLayout
      sidebarTitle="Assessment Platform"
      sidebarSubtitle="Testing & Evaluation Hub"
      sidebarSections={assessmentNavigation}
      usageData={usageData}
    >
      <TestRunnerContent />
    </PlatformLayout>
  );
}