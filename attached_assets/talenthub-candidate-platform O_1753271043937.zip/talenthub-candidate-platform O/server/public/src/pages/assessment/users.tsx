import PlatformLayout from "@/components/layout/platform-layout";
import { NavigationSection } from "@/components/layout/expandable-sidebar";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  Target,
  BarChart3,
  FileText,
  Database,
  Award,
  Play,
  Users,
  TrendingUp,
  Shield,
  BookOpen,
  ExternalLink,
  UserPlus,
  Upload,
  Search
} from "lucide-react";

const assessmentNavigation: NavigationSection[] = [
  {
    title: "Assessment Hub",
    items: [
      { name: "Dashboard", href: "/assessment/dashboard", icon: Target }
    ]
  },
  {
    title: "Take Assessments",
    items: [
      { name: "Browse Tests", href: "/assessment/browse-tests", icon: Target },
      { name: "Test Runner", href: "/assessment/test-runner", icon: Play },
      { name: "Test Results", href: "/assessment/test-results", icon: BarChart3 }
    ]
  },
  {
    title: "Create & Manage",
    items: [
      { name: "Question Banks", href: "/assessment/question-bank", icon: Database },
      { name: "Bulk Upload", href: "/assessment/bulk-upload", icon: FileText },
      { name: "User Management", href: "/assessment/users", icon: Users }
    ]
  },
  {
    title: "Analytics & Reports",
    items: [
      { name: "Assessment Analytics", href: "/assessment/analytics", icon: TrendingUp },
      { name: "Platform Overview", href: "/assessment/overview", icon: BarChart3 }
    ]
  },
  {
    title: "Certification",
    items: [
      { name: "Earned Certificates", href: "/assessment/certifications", icon: Award },
      { name: "Blockchain Certs", href: "/assessment/blockchain-certificates", icon: Shield }
    ]
  },
  {
    title: "Learning Integration",
    items: [
      { name: "LMS Courses", href: "/assessment/courses", icon: BookOpen },
      { name: "Practice Tests", href: "/assessment/practice-tests", icon: Target }
    ]
  }
];

export default function AssessmentUsers() {
  const usageData = [
    { label: "Monthly Tests", current: 245, max: 500 },
    { label: "Active Users", current: 1247, max: 2000 },
    { label: "Storage Used", current: 12, max: 50 }
  ];

  return (
    <PlatformLayout
      sidebarTitle="Assessment Platform"
      sidebarSubtitle="Testing & Evaluation Hub"
      sidebarSections={assessmentNavigation}
      usageData={usageData}
    >
      <div className="space-y-8">
        {/* Header */}
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">User Management</h1>
            <p className="text-gray-600 mt-2">Manage assessment platform users and their access permissions</p>
          </div>
          <Button 
            variant="outline"
            onClick={() => window.location.href = "/admin/users"}
          >
            <ExternalLink className="w-4 h-4 mr-2" />
            Full Admin User Management
          </Button>
        </div>

        {/* User Statistics */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <Card className="border-l-4 border-blue-500">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Total Users</p>
                  <p className="text-3xl font-bold text-gray-900">3,456</p>
                  <p className="text-sm text-green-600 mt-1">+234 this month</p>
                </div>
                <Users className="w-8 h-8 text-blue-600" />
              </div>
            </CardContent>
          </Card>

          <Card className="border-l-4 border-green-500">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Active Users</p>
                  <p className="text-3xl font-bold text-gray-900">2,189</p>
                  <p className="text-sm text-green-600 mt-1">63% engagement</p>
                </div>
                <Target className="w-8 h-8 text-green-600" />
              </div>
            </CardContent>
          </Card>

          <Card className="border-l-4 border-purple-500">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Test Takers</p>
                  <p className="text-3xl font-bold text-gray-900">1,847</p>
                  <p className="text-sm text-purple-600 mt-1">84% completion</p>
                </div>
                <Play className="w-8 h-8 text-purple-600" />
              </div>
            </CardContent>
          </Card>

          <Card className="border-l-4 border-amber-500">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Certified</p>
                  <p className="text-3xl font-bold text-gray-900">1,234</p>
                  <p className="text-sm text-amber-600 mt-1">67% pass rate</p>
                </div>
                <Award className="w-8 h-8 text-amber-600" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* User Management Actions */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <UserPlus className="w-5 h-5 text-purple-600" />
                Add Users
              </CardTitle>
              <CardDescription>Create individual or bulk user accounts</CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              <Button 
                variant="outline" 
                className="w-full justify-start"
                onClick={() => window.location.href = "/admin/users?action=create"}
              >
                <UserPlus className="w-4 h-4 mr-2" />
                Add Single User
              </Button>
              <Button 
                variant="outline" 
                className="w-full justify-start"
                onClick={() => window.location.href = "/assessment/bulk-upload"}
              >
                <Upload className="w-4 h-4 mr-2" />
                Bulk User Import
              </Button>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Search className="w-5 h-5 text-purple-600" />
                Find Users
              </CardTitle>
              <CardDescription>Search and filter user accounts</CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              <Button 
                variant="outline" 
                className="w-full justify-start"
                onClick={() => window.location.href = "/admin/users?filter=candidates"}
              >
                <Users className="w-4 h-4 mr-2" />
                Browse Candidates
              </Button>
              <Button 
                variant="outline" 
                className="w-full justify-start"
                onClick={() => window.location.href = "/admin/users?filter=active"}
              >
                <Target className="w-4 h-4 mr-2" />
                Active Test Takers
              </Button>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BarChart3 className="w-5 h-5 text-purple-600" />
                User Analytics
              </CardTitle>
              <CardDescription>User performance and engagement metrics</CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              <Button 
                variant="outline" 
                className="w-full justify-start"
                onClick={() => window.location.href = "/assessment/analytics"}
              >
                <BarChart3 className="w-4 h-4 mr-2" />
                User Performance
              </Button>
              <Button 
                variant="outline" 
                className="w-full justify-start"
                onClick={() => window.location.href = "/admin/users?view=analytics"}
              >
                <TrendingUp className="w-4 h-4 mr-2" />
                Engagement Metrics
              </Button>
            </CardContent>
          </Card>
        </div>

        {/* User Categories */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Users className="w-5 h-5 text-purple-600" />
              User Categories
            </CardTitle>
            <CardDescription>
              Assessment platform user distribution by role and activity
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="p-4 border rounded-lg">
                <div className="flex items-center justify-between mb-2">
                  <h3 className="font-semibold text-gray-900">Candidates</h3>
                  <Badge className="bg-blue-100 text-blue-800">2,847</Badge>
                </div>
                <p className="text-sm text-gray-600">Users taking assessments and earning certifications</p>
                <div className="mt-2">
                  <div className="text-xs text-gray-500">
                    Active: 1,923 | Certified: 1,234 | Pass Rate: 67%
                  </div>
                </div>
              </div>

              <div className="p-4 border rounded-lg">
                <div className="flex items-center justify-between mb-2">
                  <h3 className="font-semibold text-gray-900">Administrators</h3>
                  <Badge className="bg-purple-100 text-purple-800">34</Badge>
                </div>
                <p className="text-sm text-gray-600">Platform administrators managing questions and users</p>
                <div className="mt-2">
                  <div className="text-xs text-gray-500">
                    Super Admin: 3 | Question Managers: 12 | User Managers: 19
                  </div>
                </div>
              </div>

              <div className="p-4 border rounded-lg">
                <div className="flex items-center justify-between mb-2">
                  <h3 className="font-semibold text-gray-900">Instructors</h3>
                  <Badge className="bg-green-100 text-green-800">156</Badge>
                </div>
                <p className="text-sm text-gray-600">LMS instructors creating course assessments</p>
                <div className="mt-2">
                  <div className="text-xs text-gray-500">
                    Active: 98 | Course Tests: 234 | Avg Score: 82%
                  </div>
                </div>
              </div>

              <div className="p-4 border rounded-lg">
                <div className="flex items-center justify-between mb-2">
                  <h3 className="font-semibold text-gray-900">Recruiters</h3>
                  <Badge className="bg-amber-100 text-amber-800">89</Badge>
                </div>
                <p className="text-sm text-gray-600">Recruiters using assessments for candidate evaluation</p>
                <div className="mt-2">
                  <div className="text-xs text-gray-500">
                    Active: 67 | Screening Tests: 156 | Candidates: 890
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Quick Access */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle>Administrative Tools</CardTitle>
              <CardDescription>Access full user management capabilities</CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              <Button 
                variant="outline" 
                className="w-full justify-start"
                onClick={() => window.location.href = "/admin/users"}
              >
                <Users className="w-4 h-4 mr-2" />
                Complete User Management
              </Button>
              <Button 
                variant="outline" 
                className="w-full justify-start"
                onClick={() => window.location.href = "/admin/tenants"}
              >
                <Database className="w-4 h-4 mr-2" />
                Tenant User Management
              </Button>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Assessment Integration</CardTitle>
              <CardDescription>Connect user management with assessment features</CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              <Button 
                variant="outline" 
                className="w-full justify-start"
                onClick={() => window.location.href = "/assessment/test-results"}
              >
                <Award className="w-4 h-4 mr-2" />
                User Test Results
              </Button>
              <Button 
                variant="outline" 
                className="w-full justify-start"
                onClick={() => window.location.href = "/assessment/certifications"}
              >
                <Shield className="w-4 h-4 mr-2" />
                User Certifications
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </PlatformLayout>
  );
}