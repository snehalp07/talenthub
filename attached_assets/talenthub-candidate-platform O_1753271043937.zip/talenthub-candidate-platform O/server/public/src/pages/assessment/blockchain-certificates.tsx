import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Alert, AlertDescription } from "@/components/ui/alert";
import PlatformLayout from "@/components/layout/platform-layout";
import { NavigationSection } from "@/components/layout/expandable-sidebar";
import { 
  Target,
  BarChart3,
  FileText,
  Database,
  Award,
  Play,
  Users,
  TrendingUp,
  Shield,
  BookOpen,
  Link2, 
  Download, 
  Copy, 
  ExternalLink, 
  CheckCircle, 
  AlertTriangle,
  Clock,
  Globe,
  Lock,
  Key,
  QrCode,
  Share,
  Eye,
  Wallet,
  Search
} from "lucide-react";

const assessmentNavigation: NavigationSection[] = [
  {
    title: "Assessment Hub",
    items: [
      { name: "Dashboard", href: "/assessment/dashboard", icon: Target }
    ]
  },
  {
    title: "Take Assessments",
    items: [
      { name: "Browse Tests", href: "/assessment/browse-tests", icon: Target },
      { name: "Test Runner", href: "/assessment/test-runner", icon: Play },
      { name: "Test Results", href: "/assessment/test-results", icon: BarChart3 }
    ]
  },
  {
    title: "Create & Manage",
    items: [
      { name: "Question Banks", href: "/assessment/question-bank", icon: Database },
      { name: "Bulk Upload", href: "/assessment/bulk-upload", icon: FileText },
      { name: "User Management", href: "/assessment/users", icon: Users }
    ]
  },
  {
    title: "Analytics & Reports",
    items: [
      { name: "Assessment Analytics", href: "/assessment/analytics", icon: TrendingUp },
      { name: "Platform Overview", href: "/assessment/overview", icon: BarChart3 }
    ]
  },
  {
    title: "Certification",
    items: [
      { name: "Earned Certificates", href: "/assessment/certifications", icon: Award },
      { name: "Blockchain Certs", href: "/assessment/blockchain-certificates", icon: Shield }
    ]
  },
  {
    title: "Learning Integration",
    items: [
      { name: "LMS Courses", href: "/assessment/courses", icon: BookOpen },
      { name: "Practice Tests", href: "/assessment/practice-tests", icon: Target }
    ]
  }
];

function BlockchainCertificatesContent() {
  const [selectedCredential, setSelectedCredential] = useState<string | null>(null);
  const [verificationHash, setVerificationHash] = useState("");

  const blockchainCredentials = [
    {
      id: "bc-001",
      name: "AWS Solutions Architect Professional",
      issuer: "Amazon Web Services",
      issueDate: "2024-01-15",
      blockchainNetwork: "Ethereum",
      transactionHash: "0x1a2b3c4d5e6f7890abcdef1234567890abcdef1234567890abcdef1234567890",
      contractAddress: "0xABC123456789012345678901234567890ABC12345",
      tokenId: "12345",
      ipfsHash: "QmYjh5NsDc5kjf7DGHytg4FGhjk3k4mL7jNm8kLp9qR7XZ",
      status: "verified",
      verificationCount: 47,
      lastVerified: "2024-02-18 14:30",
      publicUrl: "https://credentials.aws.com/verify/bc-001"
    },
    {
      id: "bc-002", 
      name: "Certified Kubernetes Administrator",
      issuer: "Cloud Native Computing Foundation",
      issueDate: "2023-11-22",
      blockchainNetwork: "Polygon",
      transactionHash: "0x9876543210fedcba0987654321fedcba0987654321fedcba0987654321fedcba",
      contractAddress: "0xDEF456789012345678901234567890DEF45678901",
      tokenId: "67890",
      ipfsHash: "QmAbC123456789DeF012345678901AbC456789012345678901AbC456789012",
      status: "verified",
      verificationCount: 23,
      lastVerified: "2024-02-17 09:15",
      publicUrl: "https://training.linuxfoundation.org/verify/bc-002"
    },
    {
      id: "bc-003",
      name: "React Developer Certification",
      issuer: "Meta (Facebook)",
      issueDate: "2024-02-10",
      blockchainNetwork: "Ethereum",
      transactionHash: "0xfedcba0987654321fedcba0987654321fedcba0987654321fedcba0987654321",
      contractAddress: "0x123456789012345678901234567890123456789012",
      tokenId: "11111",
      ipfsHash: "QmXyZ789012345ABC678901234567890XyZ123456789012345678901XyZ123",
      status: "pending",
      verificationCount: 0,
      lastVerified: "Never",
      publicUrl: "https://developers.facebook.com/verify/bc-003"
    }
  ];

  const truncateHash = (hash: string) => {
    return `${hash.slice(0, 8)}...${hash.slice(-8)}`;
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "verified":
        return <Badge className="bg-green-100 text-green-800 border-green-200"><CheckCircle className="w-3 h-3 mr-1" />Verified</Badge>;
      case "pending":
        return <Badge className="bg-yellow-100 text-yellow-800 border-yellow-200"><Clock className="w-3 h-3 mr-1" />Pending</Badge>;
      case "expired":
        return <Badge className="bg-red-100 text-red-800 border-red-200"><AlertTriangle className="w-3 h-3 mr-1" />Expired</Badge>;
      default:
        return <Badge variant="secondary">Unknown</Badge>;
    }
  };

  return (
    <div className="space-y-8">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Blockchain Certificates</h1>
          <p className="text-gray-600 mt-2">Secure, verifiable digital credentials on blockchain networks</p>
        </div>
        <Button>
          <Download className="w-4 h-4 mr-2" />
          Export All
        </Button>
      </div>

      <Tabs defaultValue="credentials" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="credentials">My Credentials</TabsTrigger>
          <TabsTrigger value="verification">Verify Others</TabsTrigger>
          <TabsTrigger value="networks">Networks</TabsTrigger>
          <TabsTrigger value="wallet">Digital Wallet</TabsTrigger>
        </TabsList>

        <TabsContent value="credentials" className="space-y-6">
          <div className="grid gap-6">
            {blockchainCredentials.map((credential) => (
              <Card key={credential.id} className="border-l-4 border-l-blue-500">
                <CardContent className="p-6">
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex-1">
                      <h3 className="text-xl font-semibold text-gray-900 mb-2">{credential.name}</h3>
                      <p className="text-gray-600 mb-3">Issued by {credential.issuer}</p>
                      <div className="flex items-center gap-4 text-sm text-gray-500">
                        <span>Issued: {credential.issueDate}</span>
                        <span>•</span>
                        <span>Verified {credential.verificationCount} times</span>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      {getStatusBadge(credential.status)}
                      <Badge variant="outline" className="flex items-center gap-1">
                        <Link2 className="w-3 h-3" />
                        {credential.blockchainNetwork}
                      </Badge>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-4">
                    <div className="space-y-3">
                      <div>
                        <label className="text-xs font-medium text-gray-500 uppercase tracking-wide">
                          Blockchain Details
                        </label>
                        <div className="mt-1 space-y-2">
                          <div className="flex items-center justify-between">
                            <span className="text-sm text-gray-600">Transaction Hash:</span>
                            <div className="flex items-center gap-2">
                              <code className="text-xs bg-gray-100 px-2 py-1 rounded">
                                {truncateHash(credential.transactionHash)}
                              </code>
                              <Button
                                size="sm"
                                variant="ghost"
                                className="h-6 w-6 p-0"
                                onClick={() => copyToClipboard(credential.transactionHash)}
                              >
                                <Copy className="w-3 h-3" />
                              </Button>
                            </div>
                          </div>
                          <div className="flex items-center justify-between">
                            <span className="text-sm text-gray-600">Contract Address:</span>
                            <div className="flex items-center gap-2">
                              <code className="text-xs bg-gray-100 px-2 py-1 rounded">
                                {truncateHash(credential.contractAddress)}
                              </code>
                              <Button
                                size="sm"
                                variant="ghost"
                                className="h-6 w-6 p-0"
                                onClick={() => copyToClipboard(credential.contractAddress)}
                              >
                                <Copy className="w-3 h-3" />
                              </Button>
                            </div>
                          </div>
                          <div className="flex items-center justify-between">
                            <span className="text-sm text-gray-600">Token ID:</span>
                            <span className="text-sm font-mono">{credential.tokenId}</span>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="space-y-3">
                      <div>
                        <label className="text-xs font-medium text-gray-500 uppercase tracking-wide">
                          Verification & Storage
                        </label>
                        <div className="mt-1 space-y-2">
                          <div className="flex items-center justify-between">
                            <span className="text-sm text-gray-600">IPFS Hash:</span>
                            <div className="flex items-center gap-2">
                              <code className="text-xs bg-gray-100 px-2 py-1 rounded">
                                {truncateHash(credential.ipfsHash)}
                              </code>
                              <Button
                                size="sm"
                                variant="ghost"
                                className="h-6 w-6 p-0"
                                onClick={() => copyToClipboard(credential.ipfsHash)}
                              >
                                <Copy className="w-3 h-3" />
                              </Button>
                            </div>
                          </div>
                          <div className="flex items-center justify-between">
                            <span className="text-sm text-gray-600">Last Verified:</span>
                            <span className="text-sm">{credential.lastVerified}</span>
                          </div>
                          <div className="flex items-center justify-between">
                            <span className="text-sm text-gray-600">Public URL:</span>
                            <Button
                              size="sm"
                              variant="ghost"
                              className="h-6 w-6 p-0"
                              onClick={() => window.open(credential.publicUrl, '_blank')}
                            >
                              <ExternalLink className="w-3 h-3" />
                            </Button>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="flex gap-2 pt-4 border-t">
                    <Button size="sm" variant="outline">
                      <Eye className="w-4 h-4 mr-2" />
                      View Details
                    </Button>
                    <Button size="sm" variant="outline">
                      <Share className="w-4 h-4 mr-2" />
                      Share
                    </Button>
                    <Button size="sm" variant="outline">
                      <Download className="w-4 h-4 mr-2" />
                      Download
                    </Button>
                    <Button size="sm" variant="outline">
                      <QrCode className="w-4 h-4 mr-2" />
                      QR Code
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="verification" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Search className="w-5 h-5 text-blue-600" />
                Verify Blockchain Certificates
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <label className="text-sm font-medium">Enter Transaction Hash or Certificate ID</label>
                <div className="flex gap-2">
                  <Input
                    placeholder="0x1a2b3c4d5e6f7890abcdef... or certificate ID"
                    value={verificationHash}
                    onChange={(e) => setVerificationHash(e.target.value)}
                    className="flex-1"
                  />
                  <Button>
                    <Search className="w-4 h-4 mr-2" />
                    Verify
                  </Button>
                </div>
              </div>

              {verificationHash && (
                <Alert>
                  <CheckCircle className="h-4 w-4" />
                  <AlertDescription>
                    Certificate verified! This credential was issued by Amazon Web Services on January 15, 2024, 
                    and is recorded on the Ethereum blockchain. Last verification: February 18, 2024.
                  </AlertDescription>
                </Alert>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="networks" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {[
              { name: "Ethereum", credentials: 2, usage: 85, status: "active", fees: "High", speed: "15s" },
              { name: "Polygon", credentials: 1, usage: 45, status: "active", fees: "Low", speed: "2s" }
            ].map((network) => (
              <Card key={network.name}>
                <CardHeader>
                  <CardTitle className="flex items-center justify-between">
                    <span className="flex items-center gap-2">
                      <Globe className="w-5 h-5 text-blue-600" />
                      {network.name}
                    </span>
                    <Badge className="bg-green-100 text-green-800">{network.status}</Badge>
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <span className="text-gray-600">Credentials:</span>
                      <div className="font-semibold">{network.credentials}</div>
                    </div>
                    <div>
                      <span className="text-gray-600">Transaction Fees:</span>
                      <div className="font-semibold">{network.fees}</div>
                    </div>
                    <div>
                      <span className="text-gray-600">Avg Speed:</span>
                      <div className="font-semibold">{network.speed}</div>
                    </div>
                  </div>
                  <div>
                    <div className="flex justify-between text-sm mb-1">
                      <span className="text-gray-600">Platform Usage</span>
                      <span className="font-medium">{network.usage}%</span>
                    </div>
                    <Progress value={network.usage} className="h-2" />
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="wallet" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Wallet className="w-5 h-5 text-purple-600" />
                Digital Wallet Management
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <div>
                  <label className="text-sm font-medium text-gray-600">Wallet Address</label>
                  <div className="flex items-center gap-2">
                    <code className="flex-1 text-xs bg-gray-100 px-3 py-2 rounded break-all">
                      0x742d35Cc6639C0532C78D5C0C4c9D2F3c95e8C6A
                    </code>
                    <Button size="sm" variant="outline">
                      <Copy className="w-4 h-4" />
                    </Button>
                  </div>
                </div>

                <div className="space-y-4">
                  <h4 className="font-semibold text-gray-900">Wallet Statistics</h4>
                  <div className="space-y-3">
                    <div className="flex justify-between">
                      <span className="text-gray-600">Total Credentials:</span>
                      <span className="font-semibold">3</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Verified Credentials:</span>
                      <span className="font-semibold text-green-600">2</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Total Verifications:</span>
                      <span className="font-semibold">82</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Wallet Created:</span>
                      <span className="font-semibold">Dec 15, 2023</span>
                    </div>
                  </div>
                </div>
              </div>

              <Alert>
                <Lock className="h-4 w-4" />
                <AlertDescription>
                  Your private keys are encrypted and stored securely. Never share your private key or recovery phrase with anyone.
                </AlertDescription>
              </Alert>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}

export default function AssessmentBlockchainCertificates() {
  const usageData = [
    { label: "Monthly Tests", current: 245, max: 500 },
    { label: "Active Users", current: 1247, max: 2000 },
    { label: "Storage Used", current: 12, max: 50 }
  ];

  return (
    <PlatformLayout
      sidebarTitle="Assessment Platform"
      sidebarSubtitle="Testing & Evaluation Hub"
      sidebarSections={assessmentNavigation}
      usageData={usageData}
    >
      <BlockchainCertificatesContent />
    </PlatformLayout>
  );
}