import PlatformLayout from "@/components/layout/platform-layout";
import { NavigationSection } from "@/components/layout/expandable-sidebar";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  Target,
  BarChart3,
  FileText,
  Database,
  Award,
  Play,
  Users,
  TrendingUp,
  Shield,
  BookOpen,
  ExternalLink,
  Activity,
  PieChart
} from "lucide-react";

const assessmentNavigation: NavigationSection[] = [
  {
    title: "Assessment Hub",
    items: [
      { name: "Dashboard", href: "/assessment/dashboard", icon: Target }
    ]
  },
  {
    title: "Take Assessments",
    items: [
      { name: "Browse Tests", href: "/assessment/browse-tests", icon: Target },
      { name: "Test Runner", href: "/assessment/test-runner", icon: Play },
      { name: "Test Results", href: "/assessment/test-results", icon: BarChart3 }
    ]
  },
  {
    title: "Create & Manage",
    items: [
      { name: "Question Banks", href: "/assessment/question-bank", icon: Database },
      { name: "Bulk Upload", href: "/assessment/bulk-upload", icon: FileText },
      { name: "User Management", href: "/assessment/users", icon: Users }
    ]
  },
  {
    title: "Analytics & Reports",
    items: [
      { name: "Assessment Analytics", href: "/assessment/analytics", icon: TrendingUp },
      { name: "Platform Overview", href: "/assessment/overview", icon: BarChart3 }
    ]
  },
  {
    title: "Certification",
    items: [
      { name: "Earned Certificates", href: "/assessment/certifications", icon: Award },
      { name: "Blockchain Certs", href: "/assessment/blockchain-certificates", icon: Shield }
    ]
  },
  {
    title: "Learning Integration",
    items: [
      { name: "LMS Courses", href: "/assessment/courses", icon: BookOpen },
      { name: "Practice Tests", href: "/assessment/practice-tests", icon: Target }
    ]
  }
];

export default function AssessmentAnalytics() {
  const usageData = [
    { label: "Monthly Tests", current: 245, max: 500 },
    { label: "Active Users", current: 1247, max: 2000 },
    { label: "Storage Used", current: 12, max: 50 }
  ];

  // Mock analytics data - would come from API in real implementation
  const analyticsData = {
    totalTests: 1247,
    totalUsers: 3456,
    passRate: 87,
    avgScore: 82,
    popularCategories: [
      { name: "JavaScript", tests: 456, users: 1234 },
      { name: "React", tests: 234, users: 789 },
      { name: "Python", tests: 189, users: 567 }
    ],
    monthlyTrends: {
      tests: "+23%",
      users: "+18%",
      scores: "+5%"
    }
  };

  return (
    <PlatformLayout
      sidebarTitle="Assessment Platform"
      sidebarSubtitle="Testing & Evaluation Hub"
      sidebarSections={assessmentNavigation}
      usageData={usageData}
    >
      <div className="space-y-8">
        {/* Header */}
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Assessment Analytics</h1>
            <p className="text-gray-600 mt-2">Comprehensive analytics and performance insights across all assessments</p>
          </div>
          <Button 
            variant="outline"
            onClick={() => window.location.href = "/admin/assessment-analytics"}
          >
            <ExternalLink className="w-4 h-4 mr-2" />
            Admin Analytics
          </Button>
        </div>

        {/* Key Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <Card className="border-l-4 border-purple-500">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Total Tests</p>
                  <p className="text-3xl font-bold text-gray-900">{analyticsData.totalTests.toLocaleString()}</p>
                  <p className="text-sm text-green-600 mt-1">{analyticsData.monthlyTrends.tests} this month</p>
                </div>
                <Target className="w-8 h-8 text-purple-600" />
              </div>
            </CardContent>
          </Card>

          <Card className="border-l-4 border-blue-500">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Active Users</p>
                  <p className="text-3xl font-bold text-gray-900">{analyticsData.totalUsers.toLocaleString()}</p>
                  <p className="text-sm text-green-600 mt-1">{analyticsData.monthlyTrends.users} this month</p>
                </div>
                <Users className="w-8 h-8 text-blue-600" />
              </div>
            </CardContent>
          </Card>

          <Card className="border-l-4 border-green-500">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Pass Rate</p>
                  <p className="text-3xl font-bold text-gray-900">{analyticsData.passRate}%</p>
                  <p className="text-sm text-green-600 mt-1">{analyticsData.monthlyTrends.scores} improvement</p>
                </div>
                <TrendingUp className="w-8 h-8 text-green-600" />
              </div>
            </CardContent>
          </Card>

          <Card className="border-l-4 border-indigo-500">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Avg Score</p>
                  <p className="text-3xl font-bold text-gray-900">{analyticsData.avgScore}%</p>
                  <p className="text-sm text-gray-500 mt-1">Across all tests</p>
                </div>
                <Award className="w-8 h-8 text-indigo-600" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Popular Categories */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <PieChart className="w-5 h-5 text-purple-600" />
              Popular Test Categories
            </CardTitle>
            <CardDescription>
              Most frequently accessed assessment categories
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {analyticsData.popularCategories.map((category, index) => (
                <div key={index} className="flex items-center justify-between p-4 border rounded-lg">
                  <div className="flex-1">
                    <h3 className="font-semibold text-gray-900">{category.name}</h3>
                    <p className="text-sm text-gray-600">{category.tests} tests available</p>
                  </div>
                  <div className="text-right">
                    <div className="text-lg font-semibold text-purple-600">{category.users.toLocaleString()}</div>
                    <div className="text-sm text-gray-500">active users</div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Analytics Access */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Activity className="w-5 h-5 text-purple-600" />
                Detailed Analytics
              </CardTitle>
              <CardDescription>Access comprehensive admin analytics dashboard</CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              <Button 
                variant="outline" 
                className="w-full justify-start"
                onClick={() => window.location.href = "/admin/assessment-analytics"}
              >
                <BarChart3 className="w-4 h-4 mr-2" />
                Full Admin Analytics Dashboard
              </Button>
              <Button 
                variant="outline" 
                className="w-full justify-start"
                onClick={() => window.location.href = "/admin/api-analytics"}
              >
                <Activity className="w-4 h-4 mr-2" />
                API Usage Analytics
              </Button>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <TrendingUp className="w-5 h-5 text-purple-600" />
                Performance Insights
              </CardTitle>
              <CardDescription>Assessment-specific performance metrics</CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              <Button 
                variant="outline" 
                className="w-full justify-start"
                onClick={() => window.location.href = "/assessment/test-results"}
              >
                <Award className="w-4 h-4 mr-2" />
                Test Results Overview
              </Button>
              <Button 
                variant="outline" 
                className="w-full justify-start"
                onClick={() => window.location.href = "/assessment/certifications"}
              >
                <Shield className="w-4 h-4 mr-2" />
                Certification Analytics
              </Button>
            </CardContent>
          </Card>
        </div>

        {/* Quick Access */}
        <Card>
          <CardHeader>
            <CardTitle>Quick Analytics Access</CardTitle>
            <CardDescription>Direct links to specific analytics sections</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              <Button variant="outline" size="sm" onClick={() => window.location.href = "/assessment/browse-tests"}>
                <Target className="w-4 h-4 mr-1" />
                Test Analytics
              </Button>
              <Button variant="outline" size="sm" onClick={() => window.location.href = "/assessment/users"}>
                <Users className="w-4 h-4 mr-1" />
                User Analytics
              </Button>
              <Button variant="outline" size="sm" onClick={() => window.location.href = "/assessment/question-bank"}>
                <Database className="w-4 h-4 mr-1" />
                Question Analytics
              </Button>
              <Button variant="outline" size="sm" onClick={() => window.location.href = "/assessment/overview"}>
                <BarChart3 className="w-4 h-4 mr-1" />
                Platform Overview
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </PlatformLayout>
  );
}