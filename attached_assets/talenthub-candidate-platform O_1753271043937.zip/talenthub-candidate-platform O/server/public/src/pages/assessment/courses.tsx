import PlatformLayout from "@/components/layout/platform-layout";
import { NavigationSection } from "@/components/layout/expandable-sidebar";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { 
  Target,
  BarChart3,
  FileText,
  Database,
  Award,
  Play,
  Users,
  TrendingUp,
  Shield,
  BookOpen,
  ExternalLink,
  Clock,
  CheckCircle,
  Star,
  GraduationCap
} from "lucide-react";

const assessmentNavigation: NavigationSection[] = [
  {
    title: "Assessment Hub",
    items: [
      { name: "Dashboard", href: "/assessment/dashboard", icon: Target }
    ]
  },
  {
    title: "Take Assessments",
    items: [
      { name: "Browse Tests", href: "/assessment/browse-tests", icon: Target },
      { name: "Test Runner", href: "/assessment/test-runner", icon: Play },
      { name: "Test Results", href: "/assessment/test-results", icon: BarChart3 }
    ]
  },
  {
    title: "Create & Manage",
    items: [
      { name: "Question Banks", href: "/assessment/question-bank", icon: Database },
      { name: "Bulk Upload", href: "/assessment/bulk-upload", icon: FileText },
      { name: "User Management", href: "/assessment/users", icon: Users }
    ]
  },
  {
    title: "Analytics & Reports",
    items: [
      { name: "Assessment Analytics", href: "/assessment/analytics", icon: TrendingUp },
      { name: "Platform Overview", href: "/assessment/overview", icon: BarChart3 }
    ]
  },
  {
    title: "Certification",
    items: [
      { name: "Earned Certificates", href: "/assessment/certifications", icon: Award },
      { name: "Blockchain Certs", href: "/assessment/blockchain-certificates", icon: Shield }
    ]
  },
  {
    title: "Learning Integration",
    items: [
      { name: "LMS Courses", href: "/assessment/courses", icon: BookOpen },
      { name: "Practice Tests", href: "/assessment/practice-tests", icon: Target }
    ]
  }
];

export default function AssessmentCourses() {
  const usageData = [
    { label: "Monthly Tests", current: 245, max: 500 },
    { label: "Active Users", current: 1247, max: 2000 },
    { label: "Storage Used", current: 12, max: 50 }
  ];

  return (
    <PlatformLayout
      sidebarTitle="Assessment Platform"
      sidebarSubtitle="Testing & Evaluation Hub"
      sidebarSections={assessmentNavigation}
      usageData={usageData}
    >
      <div className="space-y-8">
        {/* Header */}
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">LMS Courses</h1>
            <p className="text-gray-600 mt-2">Assessment-integrated learning courses and training programs</p>
          </div>
          <Button 
            variant="outline"
            onClick={() => window.location.href = "/lms/courses"}
          >
            <ExternalLink className="w-4 h-4 mr-2" />
            Full LMS Platform
          </Button>
        </div>

        {/* Course Categories */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card className="border-l-4 border-blue-500">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <GraduationCap className="w-5 h-5 text-blue-600" />
                Technical Skills
              </CardTitle>
              <CardDescription>Programming and technical assessment courses</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-sm font-medium">Available Courses</span>
                  <Badge className="bg-blue-100 text-blue-800">24</Badge>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm font-medium">With Assessments</span>
                  <span className="text-sm text-blue-600">18</span>
                </div>
                <Button 
                  size="sm" 
                  className="w-full"
                  onClick={() => window.location.href = "/lms/courses?category=technical"}
                >
                  Browse Technical
                </Button>
              </div>
            </CardContent>
          </Card>

          <Card className="border-l-4 border-green-500">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BookOpen className="w-5 h-5 text-green-600" />
                Certification Prep
              </CardTitle>
              <CardDescription>Industry certification preparation courses</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-sm font-medium">Prep Courses</span>
                  <Badge className="bg-green-100 text-green-800">12</Badge>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm font-medium">Success Rate</span>
                  <span className="text-sm text-green-600">87%</span>
                </div>
                <Button 
                  size="sm" 
                  className="w-full"
                  onClick={() => window.location.href = "/lms/courses?category=certification"}
                >
                  Start Prep Course
                </Button>
              </div>
            </CardContent>
          </Card>

          <Card className="border-l-4 border-purple-500">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Target className="w-5 h-5 text-purple-600" />
                Skill Assessment
              </CardTitle>
              <CardDescription>Courses with integrated skill testing</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-sm font-medium">Assessment Courses</span>
                  <Badge className="bg-purple-100 text-purple-800">8</Badge>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm font-medium">Avg Score</span>
                  <span className="text-sm text-purple-600">82%</span>
                </div>
                <Button 
                  size="sm" 
                  className="w-full"
                  onClick={() => window.location.href = "/assessment/browse-tests"}
                >
                  Take Assessment
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Featured Courses */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Star className="w-5 h-5 text-purple-600" />
              Featured Assessment-Integrated Courses
            </CardTitle>
            <CardDescription>
              Popular courses with comprehensive skill assessments
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center justify-between p-4 border rounded-lg">
                <div className="flex items-center gap-4">
                  <GraduationCap className="w-8 h-8 text-blue-600" />
                  <div>
                    <h3 className="font-semibold text-gray-900">Full Stack JavaScript Development</h3>
                    <p className="text-sm text-gray-600">Complete course with React, Node.js assessments</p>
                    <div className="flex items-center gap-4 mt-1 text-xs text-gray-500">
                      <span>24 lessons</span>
                      <span>•</span>
                      <span>8 assessments</span>
                      <span>•</span>
                      <span>Certificate included</span>
                    </div>
                  </div>
                </div>
                <div className="text-right">
                  <div className="flex items-center gap-2 mb-1">
                    <Star className="w-4 h-4 text-yellow-500" />
                    <span className="text-sm font-semibold">4.8</span>
                  </div>
                  <p className="text-sm text-gray-500">1,234 students</p>
                </div>
              </div>

              <div className="flex items-center justify-between p-4 border rounded-lg">
                <div className="flex items-center gap-4">
                  <Shield className="w-8 h-8 text-green-600" />
                  <div>
                    <h3 className="font-semibold text-gray-900">AWS Solutions Architect Preparation</h3>
                    <p className="text-sm text-gray-600">Certification prep with practice assessments</p>
                    <div className="flex items-center gap-4 mt-1 text-xs text-gray-500">
                      <span>18 modules</span>
                      <span>•</span>
                      <span>12 practice tests</span>
                      <span>•</span>
                      <span>Official certification</span>
                    </div>
                  </div>
                </div>
                <div className="text-right">
                  <div className="flex items-center gap-2 mb-1">
                    <Star className="w-4 h-4 text-yellow-500" />
                    <span className="text-sm font-semibold">4.9</span>
                  </div>
                  <p className="text-sm text-gray-500">856 students</p>
                </div>
              </div>

              <div className="flex items-center justify-between p-4 border rounded-lg">
                <div className="flex items-center gap-4">
                  <Target className="w-8 h-8 text-purple-600" />
                  <div>
                    <h3 className="font-semibold text-gray-900">Data Science & Analytics Skills</h3>
                    <p className="text-sm text-gray-600">Python, SQL, and data analysis with assessments</p>
                    <div className="flex items-center gap-4 mt-1 text-xs text-gray-500">
                      <span>16 lessons</span>
                      <span>•</span>
                      <span>6 skill tests</span>
                      <span>•</span>
                      <span>Portfolio project</span>
                    </div>
                  </div>
                </div>
                <div className="text-right">
                  <div className="flex items-center gap-2 mb-1">
                    <Star className="w-4 h-4 text-yellow-500" />
                    <span className="text-sm font-semibold">4.7</span>
                  </div>
                  <p className="text-sm text-gray-500">678 students</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Progress Overview */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle>Your Course Progress</CardTitle>
              <CardDescription>Current enrollment and completion status</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span>JavaScript Fundamentals</span>
                  <span>85%</span>
                </div>
                <Progress value={85} className="h-2" />
              </div>
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span>React Development</span>
                  <span>60%</span>
                </div>
                <Progress value={60} className="h-2" />
              </div>
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span>AWS Certification Prep</span>
                  <span>30%</span>
                </div>
                <Progress value={30} className="h-2" />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Assessment Performance</CardTitle>
              <CardDescription>Your scores across course assessments</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-600">Average Score:</span>
                <span className="text-lg font-semibold text-green-600">87%</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-600">Completed Assessments:</span>
                <span className="font-semibold">14</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm text-gray-600">Certificates Earned:</span>
                <span className="font-semibold text-purple-600">3</span>
              </div>
              <Button 
                variant="outline" 
                className="w-full"
                onClick={() => window.location.href = "/assessment/test-results"}
              >
                View Detailed Results
              </Button>
            </CardContent>
          </Card>
        </div>

        {/* Quick Actions */}
        <Card>
          <CardHeader>
            <CardTitle>Quick Actions</CardTitle>
            <CardDescription>Access LMS features and assessment tools</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              <Button variant="outline" size="sm" onClick={() => window.location.href = "/lms/courses"}>
                <BookOpen className="w-4 h-4 mr-1" />
                All Courses
              </Button>
              <Button variant="outline" size="sm" onClick={() => window.location.href = "/assessment/browse-tests"}>
                <Target className="w-4 h-4 mr-1" />
                Take Test
              </Button>
              <Button variant="outline" size="sm" onClick={() => window.location.href = "/assessment/certifications"}>
                <Award className="w-4 h-4 mr-1" />
                My Certificates
              </Button>
              <Button variant="outline" size="sm" onClick={() => window.location.href = "/lms/my-learning"}>
                <GraduationCap className="w-4 h-4 mr-1" />
                My Learning
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </PlatformLayout>
  );
}