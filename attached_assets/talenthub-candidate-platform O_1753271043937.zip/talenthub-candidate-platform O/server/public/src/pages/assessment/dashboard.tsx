import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import PlatformLayout from "@/components/layout/platform-layout";
import { platformConfigs } from "@/config/navigation";
import { 
  BarChart3, 
  Users, 
  FileText, 
  TrendingUp, 
  Brain, 
  Award, 
  Briefcase, 
  Clock, 
  CheckCircle, 
  Target, 
  Star, 
  MapPin,
  Calendar,
  DollarSign,
  Send,
  Eye,
  ArrowRight,
  Play,
  BookOpen,
  Trophy,
  Zap,
  Filter,
  Heart,
  Building2,
  TrendingDown,
  UserCheck,
  MessageSquare,
  PhoneCall,
  Mail,
  Search,
  Plus,
  GraduationCap,
  Video,
  Lightbulb,
  PieChart,
  TestTube,
  Monitor,
  Layers,
  Database,
  Settings
} from "lucide-react";

export default function AssessmentDashboard() {
  const config = platformConfigs.assessment;

  // Assessment Performance Metrics
  const assessmentMetrics = [
    { metric: "Test Completion Rate", value: "94%", trend: "+8%", color: "bg-green-500" },
    { metric: "Average Score", value: "78%", trend: "+5%", color: "bg-blue-500" },
    { metric: "Question Bank Size", value: "15,247", trend: "+156", color: "bg-purple-500" },
    { metric: "Certification Issued", value: "2,847", trend: "+12%", color: "bg-orange-500" }
  ];

  // Popular Assessment Categories
  const assessmentCategories = [
    { 
      category: "JavaScript Development",
      tests: 47,
      attempts: 8945,
      avgScore: 82,
      difficulty: "Intermediate",
      completion: 89,
      popularity: 95
    },
    { 
      category: "Python Programming",
      tests: 35,
      attempts: 6723,
      avgScore: 79,
      difficulty: "Beginner",
      completion: 92,
      popularity: 88
    },
    { 
      category: "System Design",
      tests: 23,
      attempts: 3456,
      avgScore: 71,
      difficulty: "Advanced",
      completion: 67,
      popularity: 72
    },
    { 
      category: "Data Structures",
      tests: 41,
      attempts: 5678,
      avgScore: 75,
      difficulty: "Intermediate",
      completion: 78,
      popularity: 84
    }
  ];

  // Platform Integration Stats
  const platformIntegration = [
    { platform: "Candidate Platform", tests: 12847, completions: 11234, success: 87 },
    { platform: "Recruiter Platform", tests: 3421, completions: 3156, success: 92 },
    { platform: "LMS Platform", tests: 8765, completions: 7892, success: 90 },
    { platform: "Admin Platform", tests: 1432, completions: 1398, success: 98 }
  ];

  // Test Creation Analytics
  const testCreationData = [
    { type: "Multiple Choice", count: 8945, percentage: 45 },
    { type: "Coding Challenges", count: 6723, percentage: 34 },
    { type: "Essay Questions", count: 2456, percentage: 12 },
    { type: "True/False", count: 1789, percentage: 9 }
  ];

  // Top Performing Tests
  const topTests = [
    {
      id: 1,
      title: "React Advanced Patterns",
      category: "JavaScript",
      attempts: 1247,
      avgScore: 84,
      difficulty: "Advanced",
      duration: "45 min",
      questions: 25,
      certification: "Yes"
    },
    {
      id: 2,
      title: "Python Data Structures",
      category: "Programming",
      attempts: 892,
      avgScore: 79,
      difficulty: "Intermediate",
      duration: "60 min",
      questions: 30,
      certification: "Yes"
    },
    {
      id: 3,
      title: "SQL Query Optimization",
      category: "Database",
      attempts: 654,
      avgScore: 76,
      difficulty: "Advanced",
      duration: "90 min",
      questions: 20,
      certification: "No"
    }
  ];

  // Recent Assessment Activities
  const recentActivities = [
    {
      id: 1,
      type: "creation",
      title: "New test created: Machine Learning Basics",
      creator: "Dr. Sarah Chen",
      time: "30 minutes ago",
      icon: Plus,
      color: "bg-green-500",
      status: "success"
    },
    {
      id: 2,
      type: "completion",
      title: "Bulk test completion: 247 candidates",
      test: "JavaScript Fundamentals",
      time: "2 hours ago",
      icon: Users,
      color: "bg-blue-500",
      status: "success"
    },
    {
      id: 3,
      type: "certification",
      title: "Certification batch processed",
      count: "156 certificates issued",
      time: "4 hours ago",
      icon: Award,
      color: "bg-purple-500",
      status: "success"
    },
    {
      id: 4,
      type: "integration",
      title: "LMS Platform sync completed",
      data: "892 test results synchronized",
      time: "6 hours ago",
      icon: Layers,
      color: "bg-indigo-500",
      status: "success"
    },
    {
      id: 5,
      type: "analytics",
      title: "Performance report generated",
      period: "Monthly assessment analytics",
      time: "1 day ago",
      icon: BarChart3,
      color: "bg-orange-500",
      status: "success"
    }
  ];

  // Question Bank Statistics
  const questionBankStats = [
    { subject: "Programming", questions: 4567, difficulty: { easy: 1234, medium: 2345, hard: 988 } },
    { subject: "Mathematics", questions: 3421, difficulty: { easy: 1567, medium: 1456, hard: 398 } },
    { subject: "Logic & Reasoning", questions: 2789, difficulty: { easy: 1123, medium: 1234, hard: 432 } },
    { subject: "System Design", questions: 1876, difficulty: { easy: 456, medium: 867, hard: 553 } }
  ];

  return (
    <PlatformLayout
      sidebarTitle={config.sidebarTitle}
      sidebarSubtitle={config.sidebarSubtitle}
      sidebarSections={config.sidebarSections}
      usageData={[
        { label: "Active Tests", current: 847, max: 1000 },
        { label: "Monthly Attempts", current: 25689, max: 50000 },
        { label: "Question Bank", current: 15247, max: 25000 }
      ]}
    >
      <div className="min-h-screen bg-gray-50 p-6">
        {/* Hero Section */}
        <Card className="bg-white mb-6">
          <CardContent className="p-8">
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-3xl font-bold text-gray-900 mb-2">Assessment Platform Dashboard</h1>
                <p className="text-gray-600 mb-4">Centralized testing hub with cross-platform integration and analytics</p>
                <div className="flex items-center space-x-6">
                  <div className="text-center">
                    <div className="text-2xl font-bold text-sky-600">25,689</div>
                    <div className="text-sm text-gray-500">Monthly Attempts</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-green-600">847</div>
                    <div className="text-sm text-gray-500">Active Tests</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-purple-600">94%</div>
                    <div className="text-sm text-gray-500">Completion Rate</div>
                  </div>
                </div>
              </div>
              <div className="flex space-x-3">
                <Button className="bg-sky-500 hover:bg-sky-600 text-white">
                  <Plus className="w-4 h-4 mr-2" />
                  Create Test
                </Button>
                <Button variant="outline" className="border-gray-300 text-gray-600">
                  <Database className="w-4 h-4 mr-2" />
                  Question Bank
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Assessment Metrics & Categories */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
          {/* Assessment Performance Metrics */}
          <Card className="bg-white">
            <CardHeader>
              <CardTitle className="text-xl text-gray-800">Assessment Performance</CardTitle>
              <CardDescription>Key testing metrics and completion trends</CardDescription>
            </CardHeader>
            <CardContent className="p-6 bg-white">
              {/* Visual Assessment Dashboard */}
              <div className="grid grid-cols-2 gap-4 mb-6">
                {assessmentMetrics.map((metric, index) => (
                  <div key={index} className="text-center p-4 bg-gradient-to-br from-purple-50 to-blue-50 rounded-lg border hover:shadow-md transition-all">
                    <div className={`w-16 h-16 ${metric.color} rounded-full flex items-center justify-center mx-auto mb-3 shadow-lg`}>
                      {index === 0 ? (
                        <CheckCircle className="w-8 h-8 text-white" />
                      ) : index === 1 ? (
                        <Trophy className="w-8 h-8 text-white" />
                      ) : index === 2 ? (
                        <Database className="w-8 h-8 text-white" />
                      ) : (
                        <Award className="w-8 h-8 text-white" />
                      )}
                    </div>
                    <div className="mb-2">
                      <div className="text-xl font-bold text-gray-900">{metric.value}</div>
                      <div className="text-xs text-gray-600 mb-2">{metric.metric}</div>
                    </div>
                    <div className="flex items-center justify-center space-x-1">
                      <TrendingUp className="w-3 h-3 text-green-500" />
                      <span className="text-xs font-medium text-green-600">{metric.trend}</span>
                    </div>
                  </div>
                ))}
              </div>
              <Button variant="outline" className="w-full mt-4 text-gray-600 border-gray-300">
                <BarChart3 className="w-4 h-4 mr-2" />
                View Analytics Dashboard
              </Button>
            </CardContent>
          </Card>

          {/* Popular Assessment Categories */}
          <Card className="bg-white">
            <CardHeader>
              <CardTitle className="text-xl text-gray-800">Top Assessment Categories</CardTitle>
              <CardDescription>Most popular testing areas and performance</CardDescription>
            </CardHeader>
            <CardContent className="p-6 bg-white">
              <div className="space-y-4">
                {assessmentCategories.map((category, index) => (
                  <div key={index} className="border border-gray-200 rounded-lg p-4 hover:bg-gray-50 transition-colors">
                    <div className="flex items-start justify-between mb-2">
                      <h4 className="font-semibold text-gray-900 text-sm">{category.category}</h4>
                      <Badge className={`${
                        category.difficulty === 'Advanced' ? 'bg-red-100 text-red-800' :
                        category.difficulty === 'Intermediate' ? 'bg-yellow-100 text-yellow-800' :
                        'bg-green-100 text-green-800'
                      }`}>
                        {category.difficulty}
                      </Badge>
                    </div>
                    <div className="flex items-center justify-between text-sm text-gray-600 mb-2">
                      <span>{category.tests} tests • {category.attempts.toLocaleString()} attempts</span>
                      <span className="font-medium text-gray-900">{category.avgScore}% avg</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="text-xs text-gray-500">Completion: {category.completion}%</div>
                      <Progress value={category.popularity} className="h-1 w-16" />
                    </div>
                  </div>
                ))}
              </div>
              <Button variant="outline" className="w-full mt-4 text-gray-600 border-gray-300">
                <TestTube className="w-4 h-4 mr-2" />
                Browse All Categories
              </Button>
            </CardContent>
          </Card>
        </div>

        {/* Platform Integration & Test Creation */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
          {/* Cross-Platform Integration */}
          <Card className="bg-white">
            <CardHeader>
              <CardTitle className="text-xl text-gray-800">Platform Integration</CardTitle>
              <CardDescription>Assessment usage across all platforms</CardDescription>
            </CardHeader>
            <CardContent className="p-6 bg-white">
              <div className="space-y-4">
                {platformIntegration.map((platform, index) => (
                  <div key={index} className="p-4 bg-gradient-to-r from-gray-50 to-blue-50 border border-gray-200 rounded-lg hover:shadow-md transition-all">
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center space-x-3">
                        <div className={`w-10 h-10 ${
                          index === 0 ? 'bg-teal-500' :
                          index === 1 ? 'bg-indigo-500' :
                          index === 2 ? 'bg-emerald-500' :
                          'bg-purple-500'
                        } rounded-full flex items-center justify-center shadow-md`}>
                          <Layers className="w-5 h-5 text-white" />
                        </div>
                        <h4 className="font-semibold text-gray-900">{platform.platform}</h4>
                      </div>
                      <div className="text-right">
                        <div className="text-lg font-bold text-gray-900">{platform.success}%</div>
                        <div className="text-xs text-gray-500">success rate</div>
                      </div>
                    </div>
                    <div className="flex items-center justify-between text-sm text-gray-600 mb-3">
                      <span className="flex items-center">
                        <TestTube className="w-4 h-4 mr-1" />
                        {platform.tests.toLocaleString()} tests
                      </span>
                      <span className="flex items-center">
                        <CheckCircle className="w-4 h-4 mr-1" />
                        {platform.completions.toLocaleString()} completed
                      </span>
                    </div>
                    <div className="mb-2">
                      <Progress value={platform.success} className="h-3" />
                    </div>
                    <div className={`text-xs font-medium px-2 py-1 rounded-full inline-flex items-center ${
                      platform.success >= 95 ? 'bg-green-100 text-green-800' :
                      platform.success >= 85 ? 'bg-blue-100 text-blue-800' :
                      'bg-yellow-100 text-yellow-800'
                    }`}>
                      {platform.success >= 95 ? '🟢 Excellent' :
                       platform.success >= 85 ? '🔵 Good' :
                       '🟡 Fair'}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Question Bank Statistics */}
          <Card className="bg-white">
            <CardHeader>
              <CardTitle className="text-xl text-gray-800">Question Bank Overview</CardTitle>
              <CardDescription>Content distribution by subject and difficulty</CardDescription>
            </CardHeader>
            <CardContent className="p-6 bg-white">
              <div className="space-y-4">
                {questionBankStats.map((subject, index) => (
                  <div key={index} className="border border-gray-200 rounded-lg p-4">
                    <div className="flex items-center justify-between mb-2">
                      <h4 className="font-semibold text-gray-900">{subject.subject}</h4>
                      <span className="text-sm font-medium text-gray-900">{subject.questions.toLocaleString()}</span>
                    </div>
                    <div className="flex items-center justify-between text-xs text-gray-600">
                      <span className="flex items-center space-x-2">
                        <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                        <span>Easy: {subject.difficulty.easy}</span>
                      </span>
                      <span className="flex items-center space-x-2">
                        <div className="w-2 h-2 bg-yellow-500 rounded-full"></div>
                        <span>Medium: {subject.difficulty.medium}</span>
                      </span>
                      <span className="flex items-center space-x-2">
                        <div className="w-2 h-2 bg-red-500 rounded-full"></div>
                        <span>Hard: {subject.difficulty.hard}</span>
                      </span>
                    </div>
                  </div>
                ))}
              </div>
              <Button variant="outline" className="w-full mt-4 text-gray-600 border-gray-300">
                <Database className="w-4 h-4 mr-2" />
                Manage Question Bank
              </Button>
            </CardContent>
          </Card>
        </div>

        {/* Top Performing Tests */}
        <Card className="bg-white mb-6">
          <CardHeader>
            <CardTitle className="text-xl text-gray-800">Top Performing Tests</CardTitle>
            <CardDescription>Most attempted and highest scoring assessments</CardDescription>
          </CardHeader>
          <CardContent className="p-6 bg-white">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {topTests.map((test) => (
                <div key={test.id} className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow cursor-pointer">
                  <div className="flex items-start justify-between mb-3">
                    <h4 className="font-semibold text-gray-900 text-sm">{test.title}</h4>
                    <Badge className={`${
                      test.difficulty === 'Advanced' ? 'bg-red-100 text-red-800' :
                      test.difficulty === 'Intermediate' ? 'bg-yellow-100 text-yellow-800' :
                      'bg-green-100 text-green-800'
                    }`}>
                      {test.difficulty}
                    </Badge>
                  </div>
                  
                  <div className="space-y-2 mb-4">
                    <div className="flex items-center text-sm text-gray-600">
                      <Users className="w-4 h-4 mr-1" />
                      {test.attempts} attempts
                      <span className="mx-2">•</span>
                      <Clock className="w-4 h-4 mr-1" />
                      {test.duration}
                    </div>
                    <div className="flex items-center text-sm text-gray-600">
                      <FileText className="w-4 h-4 mr-1" />
                      {test.questions} questions
                      <span className="mx-2">•</span>
                      <Award className={`w-4 h-4 mr-1 ${test.certification === 'Yes' ? 'text-purple-600' : 'text-gray-400'}`} />
                      {test.certification === 'Yes' ? 'Certified' : 'Practice'}
                    </div>
                  </div>

                  <div className="mb-3">
                    <div className="flex items-center justify-between text-sm mb-1">
                      <span className="text-gray-600">Average Score</span>
                      <span className="font-medium text-gray-900">{test.avgScore}%</span>
                    </div>
                    <Progress value={test.avgScore} className="h-2" />
                  </div>

                  <div className="flex space-x-2">
                    <Button size="sm" variant="outline" className="flex-1 border-gray-300 text-gray-600">
                      <Eye className="w-4 h-4 mr-1" />
                      View
                    </Button>
                    <Button size="sm" variant="outline" className="border-gray-300 text-gray-600">
                      <Settings className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
            <div className="mt-6 flex justify-center">
              <Button variant="outline" className="text-gray-600 border-gray-300">
                <TestTube className="w-4 h-4 mr-2" />
                View All Tests
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Recent Activities */}
        <Card className="bg-white mb-6">
          <CardHeader>
            <CardTitle className="text-xl text-gray-800">Recent Assessment Activities</CardTitle>
            <CardDescription>Latest test creation, completion, and system events</CardDescription>
          </CardHeader>
          <CardContent className="p-6 bg-white">
            <div className="space-y-4">
              {recentActivities.map((activity) => {
                const IconComponent = activity.icon;
                return (
                  <div key={activity.id} className="flex items-start space-x-4 p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors cursor-pointer">
                    <div className={`w-10 h-10 ${activity.color} rounded-full flex items-center justify-center flex-shrink-0`}>
                      <IconComponent className="w-5 h-5 text-white" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <h4 className="font-medium text-gray-900 mb-1">{activity.title}</h4>
                          <div className="flex items-center space-x-4 text-sm text-gray-600">
                            {activity.creator && (
                              <span className="flex items-center">
                                <UserCheck className="w-4 h-4 mr-1" />
                                {activity.creator}
                              </span>
                            )}
                            {activity.test && (
                              <span className="flex items-center">
                                <TestTube className="w-4 h-4 mr-1" />
                                {activity.test}
                              </span>
                            )}
                            {activity.count && (
                              <span className="flex items-center">
                                <Award className="w-4 h-4 mr-1" />
                                {activity.count}
                              </span>
                            )}
                            {activity.data && (
                              <span className="flex items-center">
                                <Database className="w-4 h-4 mr-1" />
                                {activity.data}
                              </span>
                            )}
                            {activity.period && (
                              <span className="flex items-center">
                                <Calendar className="w-4 h-4 mr-1" />
                                {activity.period}
                              </span>
                            )}
                          </div>
                        </div>
                        <div className="text-right flex-shrink-0 ml-4">
                          <div className="text-xs text-gray-500">{activity.time}</div>
                          <div className="mt-1 inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-green-100 text-green-800">
                            ✓ Complete
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
            <div className="mt-6 flex justify-center">
              <Button variant="outline" className="text-gray-600 border-gray-300">
                <Clock className="w-4 h-4 mr-2" />
                View Activity Log
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Call-to-Action */}
        <Card className="bg-white">
          <CardContent className="p-8 text-center">
            <h3 className="text-2xl font-bold text-gray-900 mb-2">Scale Your Assessment Capabilities</h3>
            <p className="text-gray-600 mb-6">Expand testing infrastructure, integrate new platforms, and enhance certification programs.</p>
            <div className="flex justify-center space-x-4">
              <Button className="bg-sky-500 hover:bg-sky-600 text-white">
                <Layers className="w-4 h-4 mr-2" />
                Platform Integration
              </Button>
              <Button variant="outline" className="border-gray-300 text-gray-600">
                <BarChart3 className="w-4 h-4 mr-2" />
                Advanced Analytics
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </PlatformLayout>
  );
}