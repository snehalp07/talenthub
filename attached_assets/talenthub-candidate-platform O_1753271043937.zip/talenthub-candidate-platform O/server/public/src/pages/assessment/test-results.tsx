import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Award, 
  BarChart3, 
  Calendar, 
  CheckCircle, 
  Clock, 
  Target, 
  TrendingUp,
  Trophy,
  ExternalLink,
  FileText,
  Database,
  Play,
  Users,
  Shield,
  BookOpen
} from "lucide-react";
import PlatformLayout from "@/components/layout/platform-layout";
import { NavigationSection } from "@/components/layout/expandable-sidebar";

const assessmentNavigation: NavigationSection[] = [
  {
    title: "Assessment Hub",
    items: [
      { name: "Dashboard", href: "/assessment/dashboard", icon: Target }
    ]
  },
  {
    title: "Take Assessments",
    items: [
      { name: "Browse Tests", href: "/assessment/browse-tests", icon: Target },
      { name: "Test Runner", href: "/assessment/test-runner", icon: Play },
      { name: "Test Results", href: "/assessment/test-results", icon: BarChart3 }
    ]
  },
  {
    title: "Create & Manage",
    items: [
      { name: "Question Banks", href: "/assessment/question-bank", icon: Database },
      { name: "Bulk Upload", href: "/assessment/bulk-upload", icon: FileText },
      { name: "User Management", href: "/assessment/users", icon: Users }
    ]
  },
  {
    title: "Analytics & Reports",
    items: [
      { name: "Assessment Analytics", href: "/assessment/analytics", icon: TrendingUp },
      { name: "Platform Overview", href: "/assessment/overview", icon: BarChart3 }
    ]
  },
  {
    title: "Certification",
    items: [
      { name: "Earned Certificates", href: "/assessment/certifications", icon: Award },
      { name: "Blockchain Certs", href: "/assessment/blockchain-certificates", icon: Shield }
    ]
  },
  {
    title: "Learning Integration",
    items: [
      { name: "LMS Courses", href: "/assessment/courses", icon: BookOpen },
      { name: "Practice Tests", href: "/assessment/practice-tests", icon: Target }
    ]
  }
];

function TestResultsContent() {
  const [activeView, setActiveView] = useState("overview");

  // Mock data for demonstration (would come from API in real implementation)
  const mockResults = [
    {
      testId: "js-fundamentals",
      testTitle: "JavaScript Fundamentals",
      score: 85,
      passed: true,
      completedAt: "2024-02-15T10:30:00Z",
      timeSpent: 45,
      totalQuestions: 15,
      correctAnswers: 13
    },
    {
      testId: "react-basics",
      testTitle: "React Basics",
      score: 92,
      passed: true,
      completedAt: "2024-02-10T14:20:00Z",
      timeSpent: 60,
      totalQuestions: 20,
      correctAnswers: 18
    },
    {
      testId: "node-api",
      testTitle: "Node.js API Development",
      score: 78,
      passed: true,
      completedAt: "2024-02-08T16:45:00Z",
      timeSpent: 90,
      totalQuestions: 25,
      correctAnswers: 19
    }
  ];

  const mockCertificates = [
    {
      id: "cert-001",
      name: "JavaScript Developer",
      issuer: "TalentHub",
      earnedDate: "2024-02-15",
      status: "earned"
    },
    {
      id: "cert-002", 
      name: "React Specialist",
      issuer: "TalentHub",
      earnedDate: "2024-02-10",
      status: "earned"
    }
  ];

  const overallStats = {
    totalTests: mockResults.length,
    averageScore: Math.round(mockResults.reduce((sum, result) => sum + result.score, 0) / mockResults.length),
    certificatesEarned: mockCertificates.length,
    passRate: Math.round((mockResults.filter(r => r.passed).length / mockResults.length) * 100)
  };

  return (
    <div className="space-y-8">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-purple-800">Test Results</h1>
          <p className="text-purple-600 mt-2">Track your assessment performance and earned certifications</p>
        </div>
        <Button 
          variant="outline"
          onClick={() => window.location.href = "/candidate/test-results"}
        >
          <ExternalLink className="w-4 h-4 mr-2" />
          Full Candidate View
        </Button>
      </div>

      <Tabs value={activeView} onValueChange={setActiveView} className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="history">Test History</TabsTrigger>
          <TabsTrigger value="certificates">Certificates</TabsTrigger>
          <TabsTrigger value="analytics">Analytics</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          {/* Performance Summary */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <Card className="border-l-4 border-purple-500">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">Total Tests</p>
                    <p className="text-3xl font-bold text-gray-900">{overallStats.totalTests}</p>
                  </div>
                  <Target className="w-8 h-8 text-purple-600" />
                </div>
              </CardContent>
            </Card>

            <Card className="border-l-4 border-green-500">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">Average Score</p>
                    <p className="text-3xl font-bold text-gray-900">{overallStats.averageScore}%</p>
                  </div>
                  <BarChart3 className="w-8 h-8 text-green-600" />
                </div>
              </CardContent>
            </Card>

            <Card className="border-l-4 border-blue-500">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">Certificates</p>
                    <p className="text-3xl font-bold text-gray-900">{overallStats.certificatesEarned}</p>
                  </div>
                  <Award className="w-8 h-8 text-blue-600" />
                </div>
              </CardContent>
            </Card>

            <Card className="border-l-4 border-amber-500">
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">Pass Rate</p>
                    <p className="text-3xl font-bold text-gray-900">{overallStats.passRate}%</p>
                  </div>
                  <Trophy className="w-8 h-8 text-amber-600" />
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Recent Results */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Clock className="w-5 h-5 text-purple-600" />
                Recent Test Results
              </CardTitle>
              <CardDescription>Your latest assessment performances</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {mockResults.slice(0, 3).map((result) => (
                  <div key={result.testId} className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="flex-1">
                      <h3 className="font-semibold text-gray-900">{result.testTitle}</h3>
                      <p className="text-sm text-gray-600">
                        {result.correctAnswers}/{result.totalQuestions} correct • {result.timeSpent} minutes
                      </p>
                      <p className="text-xs text-gray-500 mt-1">
                        {new Date(result.completedAt).toLocaleDateString()}
                      </p>
                    </div>
                    <div className="text-right">
                      <div className="flex items-center gap-2">
                        {result.passed ? (
                          <CheckCircle className="w-5 h-5 text-green-600" />
                        ) : (
                          <Target className="w-5 h-5 text-red-600" />
                        )}
                        <span className={`text-lg font-semibold ${result.passed ? 'text-green-600' : 'text-red-600'}`}>
                          {result.score}%
                        </span>
                      </div>
                      <Badge variant={result.passed ? "default" : "destructive"} className="mt-1">
                        {result.passed ? "Passed" : "Failed"}
                      </Badge>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="history" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Complete Test History</CardTitle>
              <CardDescription>All your assessment attempts and results</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {mockResults.map((result) => (
                  <div key={result.testId} className="border rounded-lg p-4">
                    <div className="flex items-center justify-between mb-2">
                      <h3 className="font-semibold">{result.testTitle}</h3>
                      <Badge variant={result.passed ? "default" : "destructive"}>
                        {result.score}% - {result.passed ? "Passed" : "Failed"}
                      </Badge>
                    </div>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm text-gray-600">
                      <div>
                        <span className="font-medium">Questions:</span> {result.totalQuestions}
                      </div>
                      <div>
                        <span className="font-medium">Correct:</span> {result.correctAnswers}
                      </div>
                      <div>
                        <span className="font-medium">Time:</span> {result.timeSpent} min
                      </div>
                      <div>
                        <span className="font-medium">Date:</span> {new Date(result.completedAt).toLocaleDateString()}
                      </div>
                    </div>
                    <div className="mt-3">
                      <Progress value={(result.correctAnswers / result.totalQuestions) * 100} className="h-2" />
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="certificates" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Award className="w-5 h-5 text-purple-600" />
                Earned Certificates
              </CardTitle>
              <CardDescription>Your completed certifications and achievements</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {mockCertificates.map((cert) => (
                  <div key={cert.id} className="border rounded-lg p-4 bg-gradient-to-r from-purple-50 to-blue-50">
                    <div className="flex items-center gap-3 mb-3">
                      <Award className="w-8 h-8 text-purple-600" />
                      <div>
                        <h3 className="font-semibold text-gray-900">{cert.name}</h3>
                        <p className="text-sm text-gray-600">Issued by {cert.issuer}</p>
                      </div>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-gray-600">
                        Earned: {new Date(cert.earnedDate).toLocaleDateString()}
                      </span>
                      <Badge className="bg-green-100 text-green-800">Verified</Badge>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="analytics" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Performance Trends</CardTitle>
                <CardDescription>Your improvement over time</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-600">Recent Improvement:</span>
                    <div className="flex items-center gap-1 text-green-600">
                      <TrendingUp className="w-4 h-4" />
                      <span className="font-semibold">+12%</span>
                    </div>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-600">Best Category:</span>
                    <span className="font-semibold text-purple-600">JavaScript</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-600">Focus Area:</span>
                    <span className="font-semibold text-amber-600">Node.js APIs</span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Quick Actions</CardTitle>
                <CardDescription>Continue your assessment journey</CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                <Button 
                  variant="outline" 
                  className="w-full justify-start"
                  onClick={() => window.location.href = "/assessment/browse-tests"}
                >
                  <Target className="w-4 h-4 mr-2" />
                  Take New Test
                </Button>
                <Button 
                  variant="outline" 
                  className="w-full justify-start"
                  onClick={() => window.location.href = "/assessment/certifications"}
                >
                  <Award className="w-4 h-4 mr-2" />
                  View All Certificates
                </Button>
                <Button 
                  variant="outline" 
                  className="w-full justify-start"
                  onClick={() => window.location.href = "/assessment/analytics"}
                >
                  <BarChart3 className="w-4 h-4 mr-2" />
                  Detailed Analytics
                </Button>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}

export default function AssessmentTestResults() {
  const usageData = [
    { label: "Monthly Tests", current: 245, max: 500 },
    { label: "Active Users", current: 1247, max: 2000 },
    { label: "Storage Used", current: 12, max: 50 }
  ];

  return (
    <PlatformLayout
      sidebarTitle="Assessment Platform"
      sidebarSubtitle="Testing & Evaluation Hub"
      sidebarSections={assessmentNavigation}
      usageData={usageData}
    >
      <TestResultsContent />
    </PlatformLayout>
  );
}