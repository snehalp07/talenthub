import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import PlatformLayout from "@/components/layout/platform-layout";
import { platformConfigs } from "@/config/complete-navigation";
import { useThemeClasses } from "@/lib/theme-config";
import { 
  GraduationCap, 
  BookOpen, 
  Video, 
  Award, 
  Users, 
  TrendingUp,
  Calendar,
  CheckCircle,
  Play,
  Star,
  Clock,
  FileText,
  Home,
  Settings,
  BarChart3,
  MessageSquare,
  Folder,
  Plus,
  Search,
  Filter
} from "lucide-react";

export default function LMSPlatform() {
  const config = platformConfigs.lms;
  const theme = useThemeClasses('lms');

  const usageData = [
    { label: "Course Completion", current: 65, max: 100 },
    { label: "Active Students", current: 1247, max: 2000 },
    { label: "Content Hours", current: 156, max: 200 },
  ];

  const learningStats = [
    { label: "Active Courses", value: "247", change: "+12", icon: BookOpen },
    { label: "Total Students", value: "1,247", change: "+18%", icon: Users },
    { label: "Completion Rate", value: "85%", change: "+8%", icon: TrendingUp },
    { label: "Certifications", value: "89", change: "+23", icon: Award }
  ];

  const featuredCourses = [
    {
      title: "Advanced JavaScript Programming",
      instructor: "Dr. Sarah Wilson",
      duration: "8 weeks",
      students: 245,
      rating: 4.8,
      progress: 78,
      category: "Programming",
      level: "Advanced"
    },
    {
      title: "Data Science Fundamentals",
      instructor: "Prof. Michael Chen",
      duration: "12 weeks",
      students: 189,
      rating: 4.9,
      progress: 45,
      category: "Data Science",
      level: "Beginner"
    },
    {
      title: "Digital Marketing Strategy",
      instructor: "Maria Rodriguez",
      duration: "6 weeks",
      students: 167,
      rating: 4.7,
      progress: 92,
      category: "Marketing",
      level: "Intermediate"
    }
  ];

  const recentActivity = [
    { action: "Completed course", course: "React Development", user: "John Doe", time: "2 hours ago" },
    { action: "New enrollment", course: "Python Basics", user: "Sarah Johnson", time: "4 hours ago" },
    { action: "Certificate earned", course: "JavaScript Advanced", user: "Mike Wilson", time: "1 day ago" },
    { action: "Course updated", course: "Data Analytics", user: "Instructor", time: "2 days ago" }
  ];

  const upcomingEvents = [
    { event: "JavaScript Workshop", date: "Today, 3:00 PM", type: "Live Session" },
    { event: "Data Science Webinar", date: "Tomorrow, 2:00 PM", type: "Webinar" },
    { event: "Assessment Deadline", date: "Friday, 11:59 PM", type: "Deadline" },
    { event: "Course Launch", date: "Monday, 10:00 AM", type: "Launch" }
  ];

  const topCategories = [
    { name: "Programming", courses: 45, progress: 78 },
    { name: "Data Science", courses: 32, progress: 65 },
    { name: "Marketing", courses: 28, progress: 82 },
    { name: "Design", courses: 24, progress: 71 },
    { name: "Business", courses: 19, progress: 59 }
  ];

  return (
    <PlatformLayout
      sidebarTitle={config.sidebarTitle}
      sidebarSubtitle={config.sidebarSubtitle}
      sidebarSections={config.sidebarSections}
      usageData={config.usageData}
    >
      <div className="max-w-6xl mx-auto px-6 py-8">
        {/* Welcome Section */}
        <div className="mb-8">
          <h2 className={theme.title}>Learning Dashboard</h2>
          <p className={theme.accent}>Manage courses, track student progress, and deliver exceptional learning experiences.</p>
        </div>

        {/* Learning Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          {learningStats.map((stat, index) => (
            <Card key={index} className={`${theme.card} shadow-sm`}>
              <CardContent className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <div className="w-12 h-12 bg-accent-peach rounded-lg flex items-center justify-center">
                    <stat.icon className="w-6 h-6 text-orange-600" />
                  </div>
                  <Badge variant="outline" className="border-accent-peach text-orange-700">
                    {stat.change}
                  </Badge>
                </div>
                <h3 className="text-2xl font-bold text-sky-800 mb-1">{stat.value}</h3>
                <p className="text-sm text-orange-600">{stat.label}</p>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Main Content Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Featured Courses */}
          <div className="lg:col-span-2">
            <Card className="shadow-sm">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="text-xl">Featured Courses</CardTitle>
                  <div className="flex space-x-2">
                    <Button variant="ghost" size="sm">
                      <Filter className="w-4 h-4 mr-2" />
                      Filter
                    </Button>
                    <Button variant="ghost" size="sm">
                      <Search className="w-4 h-4 mr-2" />
                      Search
                    </Button>
                  </div>
                </div>
                <CardDescription>
                  Popular and highly-rated courses in your learning platform
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {featuredCourses.map((course, index) => (
                    <div key={index} className="border border-neutral-200 rounded-lg p-4 hover:bg-neutral-50 transition-colors">
                      <div className="flex items-start justify-between mb-3">
                        <div className="flex-1">
                          <div className="flex items-center space-x-2 mb-2">
                            <h3 className="font-semibold text-neutral-600">{course.title}</h3>
                            <Badge variant="outline" className="text-xs">{course.level}</Badge>
                          </div>
                          <p className="text-sm text-neutral-500 mb-2">by {course.instructor}</p>
                          <div className="flex items-center space-x-4 text-xs text-neutral-400 mb-3">
                            <div className="flex items-center">
                              <Clock className="w-3 h-3 mr-1" />
                              {course.duration}
                            </div>
                            <div className="flex items-center">
                              <Users className="w-3 h-3 mr-1" />
                              {course.students} students
                            </div>
                            <div className="flex items-center">
                              <Star className="w-3 h-3 mr-1 text-yellow-500 fill-current" />
                              {course.rating}
                            </div>
                          </div>
                          <div className="flex items-center space-x-2 mb-2">
                            <span className="text-xs text-neutral-500">Progress:</span>
                            <Progress value={course.progress} className="h-2 flex-1" />
                            <span className="text-xs text-neutral-500">{course.progress}%</span>
                          </div>
                        </div>
                        <div className="text-right">
                          <Badge className="bg-purple-100 text-purple-600 mb-2">
                            {course.category}
                          </Badge>
                          <div className="space-y-2">
                            <Button size="sm" className="bg-purple-500 hover:bg-purple-600">
                              <Play className="w-4 h-4 mr-2" />
                              Continue
                            </Button>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
                <Button variant="outline" className="w-full mt-4">
                  View All Courses
                </Button>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar Content */}
          <div className="space-y-6">
            {/* Upcoming Events */}
            <Card className="shadow-sm">
              <CardHeader>
                <CardTitle className="text-lg flex items-center">
                  <Calendar className="w-5 h-5 mr-2" />
                  Upcoming Events
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {upcomingEvents.map((event, index) => (
                    <div key={index} className="border-l-2 border-purple-500 pl-4">
                      <h3 className="font-medium text-neutral-600">{event.event}</h3>
                      <div className="flex items-center justify-between mt-2">
                        <div className="text-xs text-neutral-400">
                          <Clock className="w-3 h-3 inline mr-1" />
                          {event.date}
                        </div>
                        <Badge variant="outline" className="text-xs">
                          {event.type}
                        </Badge>
                      </div>
                    </div>
                  ))}
                </div>
                <Button variant="outline" className="w-full mt-4">
                  <Calendar className="w-4 h-4 mr-2" />
                  View Calendar
                </Button>
              </CardContent>
            </Card>

            {/* Recent Activity */}
            <Card className="shadow-sm">
              <CardHeader>
                <CardTitle className="text-lg">Recent Activity</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {recentActivity.map((activity, index) => (
                    <div key={index} className="flex items-start space-x-3">
                      <div className="w-2 h-2 bg-purple-500 rounded-full mt-2 flex-shrink-0"></div>
                      <div className="flex-1">
                        <p className="text-sm text-neutral-600">{activity.action}</p>
                        <p className="text-xs text-neutral-500">{activity.course}</p>
                        <div className="flex items-center justify-between mt-1">
                          <p className="text-xs text-neutral-400">{activity.user}</p>
                          <p className="text-xs text-neutral-400">{activity.time}</p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Course Categories */}
        <div className="mt-8">
          <Card className="shadow-sm">
            <CardHeader>
              <CardTitle className="text-xl">Course Categories</CardTitle>
              <CardDescription>
                Browse courses by category and track completion rates
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-5 gap-6">
                {topCategories.map((category, index) => (
                  <div key={index} className="text-center">
                    <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-3">
                      <BookOpen className="w-8 h-8 text-purple-600" />
                    </div>
                    <h3 className="font-semibold text-neutral-600 mb-1">{category.name}</h3>
                    <p className="text-sm text-neutral-500 mb-2">{category.courses} courses</p>
                    <Progress value={category.progress} className="h-2" />
                    <div className="text-xs text-neutral-400 mt-1">{category.progress}% avg completion</div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Quick Actions */}
        <div className="mt-8">
          <Card className="shadow-sm">
            <CardHeader>
              <CardTitle className="text-xl">Quick Actions</CardTitle>
              <CardDescription>
                Common tasks and management functions for your learning platform
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="space-y-4">
                  <h3 className="font-semibold text-neutral-600 flex items-center">
                    <Plus className="w-5 h-5 mr-2" />
                    Content Creation
                  </h3>
                  <div className="space-y-2">
                    <Button variant="outline" className="w-full justify-start text-sm">
                      <BookOpen className="w-4 h-4 mr-2" />
                      Create New Course
                    </Button>
                    <Button variant="outline" className="w-full justify-start text-sm">
                      <Video className="w-4 h-4 mr-2" />
                      Upload Video Content
                    </Button>
                    <Button variant="outline" className="w-full justify-start text-sm">
                      <FileText className="w-4 h-4 mr-2" />
                      Create Assessment
                    </Button>
                  </div>
                </div>

                <div className="space-y-4">
                  <h3 className="font-semibold text-neutral-600 flex items-center">
                    <Users className="w-5 h-5 mr-2" />
                    Student Management
                  </h3>
                  <div className="space-y-2">
                    <Button variant="outline" className="w-full justify-start text-sm">
                      <Users className="w-4 h-4 mr-2" />
                      Enroll Students
                    </Button>
                    <Button variant="outline" className="w-full justify-start text-sm">
                      <BarChart3 className="w-4 h-4 mr-2" />
                      Track Progress
                    </Button>
                    <Button variant="outline" className="w-full justify-start text-sm">
                      <Award className="w-4 h-4 mr-2" />
                      Issue Certificates
                    </Button>
                  </div>
                </div>

                <div className="space-y-4">
                  <h3 className="font-semibold text-neutral-600 flex items-center">
                    <BarChart3 className="w-5 h-5 mr-2" />
                    Analytics & Reports
                  </h3>
                  <div className="space-y-2">
                    <Button variant="outline" className="w-full justify-start text-sm">
                      <BarChart3 className="w-4 h-4 mr-2" />
                      Learning Analytics
                    </Button>
                    <Button variant="outline" className="w-full justify-start text-sm">
                      <TrendingUp className="w-4 h-4 mr-2" />
                      Engagement Reports
                    </Button>
                    <Button variant="outline" className="w-full justify-start text-sm">
                      <FileText className="w-4 h-4 mr-2" />
                      Export Data
                    </Button>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </PlatformLayout>
  );
}