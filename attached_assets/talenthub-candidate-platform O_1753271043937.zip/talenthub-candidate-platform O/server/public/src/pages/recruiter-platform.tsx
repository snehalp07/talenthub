import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import PlatformLayout from "@/components/layout/platform-layout";
import { platformConfigs } from "@/config/complete-navigation";
import { useThemeClasses } from "@/lib/theme-config";
import { 
  UserCheck, 
  Briefcase, 
  Calendar, 
  Users, 
  TrendingUp, 
  Clock,
  Filter,
  Search,
  Eye,
  MessageSquare,
  CheckCircle,
  XCircle,
  Star,
  MapPin,
  Home,
  Settings,
  BarChart3,
  FileText,
  Plus,
  Database
} from "lucide-react";

export default function RecruiterPlatform() {
  const config = platformConfigs.recruiter;
  const theme = useThemeClasses('recruiter');

  const usageData = [
    { label: "Candidate Views", current: 372, max: 500 },
    { label: "Job Postings", current: 12, max: 20 },
    { label: "Interview Slots", current: 25, max: 50 },
  ];

  const candidates = [
    {
      name: "Sarah Johnson",
      role: "Full Stack Developer",
      experience: "5 years",
      skills: ["React", "Node.js", "Python"],
      location: "Bangalore",
      match: 92,
      status: "New",
      avatar: "SJ"
    },
    {
      name: "Rahul Sharma",
      role: "DevOps Engineer", 
      experience: "4 years",
      skills: ["AWS", "Docker", "Kubernetes"],
      location: "Mumbai",
      match: 87,
      status: "Screening",
      avatar: "RS"
    },
    {
      name: "Priya Patel",
      role: "Frontend Developer",
      experience: "3 years", 
      skills: ["React", "Vue.js", "TypeScript"],
      location: "Pune",
      match: 85,
      status: "Interview",
      avatar: "PP"
    }
  ];

  const activeJobs = [
    {
      title: "Senior Full Stack Developer",
      applications: 127,
      interviews: 8,
      posted: "2 weeks ago",
      status: "Active"
    },
    {
      title: "DevOps Engineer",
      applications: 89,
      interviews: 5,
      posted: "1 week ago", 
      status: "Active"
    },
    {
      title: "Product Manager",
      applications: 156,
      interviews: 12,
      posted: "3 weeks ago",
      status: "Paused"
    }
  ];

  const upcomingInterviews = [
    {
      candidate: "Sarah Johnson",
      position: "Full Stack Developer",
      time: "Today, 2:00 PM",
      type: "Technical Round"
    },
    {
      candidate: "Rahul Sharma", 
      position: "DevOps Engineer",
      time: "Tomorrow, 10:30 AM",
      type: "HR Round"
    },
    {
      candidate: "Priya Patel",
      position: "Frontend Developer", 
      time: "Friday, 3:00 PM",
      type: "Final Round"
    }
  ];

  const hiringFunnel = [
    { stage: "Applications", count: 372, percentage: 100 },
    { stage: "Screening", count: 89, percentage: 24 },
    { stage: "Interview", count: 25, percentage: 7 },
    { stage: "Offer", count: 8, percentage: 2 },
    { stage: "Hired", count: 5, percentage: 1 }
  ];

  return (
    <PlatformLayout
      sidebarTitle={config.sidebarTitle}
      sidebarSubtitle={config.sidebarSubtitle}
      sidebarSections={config.sidebarSections}
      usageData={usageData}
    >
      <div className="max-w-6xl mx-auto px-6 py-8">
        {/* Welcome Section */}
        <div className="mb-8">
          <h2 className={theme.title}>Welcome back, Recruiter!</h2>
          <p className={theme.accent}>Manage your hiring pipeline and discover top talent efficiently.</p>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card className={`${theme.card} shadow-sm`}>
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="w-12 h-12 bg-accent-lavender rounded-lg flex items-center justify-center">
                  <Users className="w-6 h-6 text-purple-600" />
                </div>
                <Badge variant="outline" className="border-accent-lavender text-purple-700">+24 new</Badge>
              </div>
              <h3 className="text-2xl font-bold text-sky-800 mb-1">372</h3>
              <p className="text-sm text-purple-600">Total Applications</p>
            </CardContent>
          </Card>

          <Card className={`${theme.card} shadow-sm`}>
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="w-12 h-12 bg-accent-lavender rounded-lg flex items-center justify-center">
                  <Briefcase className="w-6 h-6 text-purple-600" />
                </div>
                <Badge variant="outline" className="border-accent-lavender text-purple-700">3 Active</Badge>
              </div>
              <h3 className="text-2xl font-bold text-sky-800 mb-1">5</h3>
              <p className="text-sm text-purple-600">Open Positions</p>
            </CardContent>
          </Card>

          <Card className={`${theme.card} shadow-sm`}>
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="w-12 h-12 bg-accent-lavender rounded-lg flex items-center justify-center">
                  <Calendar className="w-6 h-6 text-purple-600" />
                </div>
                <Badge variant="outline" className="border-accent-lavender text-purple-700">This week</Badge>
              </div>
              <h3 className="text-2xl font-bold text-sky-800 mb-1">25</h3>
              <p className="text-sm text-purple-600">Interviews Scheduled</p>
            </CardContent>
          </Card>

          <Card className={`${theme.card} shadow-sm`}>
            <CardContent className="p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="w-12 h-12 bg-accent-lavender rounded-lg flex items-center justify-center">
                  <TrendingUp className="w-6 h-6 text-purple-600" />
                </div>
                <Badge variant="outline" className="border-accent-lavender text-purple-700">+62%</Badge>
              </div>
              <h3 className="text-2xl font-bold text-sky-800 mb-1">1.3%</h3>
              <p className="text-sm text-purple-600">Hire Rate</p>
            </CardContent>
          </Card>
        </div>

        {/* Main Content Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Candidate Pipeline */}
          <div className="lg:col-span-2">
            <Card className="shadow-sm">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="text-xl">Candidate Pipeline</CardTitle>
                  <div className="flex space-x-2">
                    <Button variant="ghost" size="sm">
                      <Filter className="w-4 h-4 mr-2" />
                      Filter
                    </Button>
                    <Button variant="ghost" size="sm">
                      <Search className="w-4 h-4 mr-2" />
                      Search
                    </Button>
                  </div>
                </div>
                <CardDescription>
                  Review and manage candidates in your hiring pipeline
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {candidates.map((candidate, index) => (
                    <div key={index} className="border border-neutral-200 rounded-lg p-4 hover:bg-neutral-50 transition-colors">
                      <div className="flex items-center space-x-4">
                        <Avatar className="h-12 w-12">
                          <AvatarFallback className="bg-green-100 text-green-600">
                            {candidate.avatar}
                          </AvatarFallback>
                        </Avatar>
                        <div className="flex-1">
                          <div className="flex items-center justify-between mb-2">
                            <h3 className="font-semibold text-neutral-600">{candidate.name}</h3>
                            <Badge className="bg-green-100 text-green-600">
                              {candidate.match}% match
                            </Badge>
                          </div>
                          <p className="text-sm text-neutral-500 mb-1">{candidate.role} • {candidate.experience}</p>
                          <div className="flex items-center space-x-4 text-xs text-neutral-400 mb-2">
                            <div className="flex items-center">
                              <MapPin className="w-3 h-3 mr-1" />
                              {candidate.location}
                            </div>
                            <div className="flex items-center space-x-1">
                              {candidate.skills.map((skill, skillIndex) => (
                                <Badge key={skillIndex} variant="outline" className="text-xs">
                                  {skill}
                                </Badge>
                              ))}
                            </div>
                          </div>
                          <div className="flex items-center justify-between">
                            <Badge 
                              variant={candidate.status === 'New' ? 'default' : 
                                      candidate.status === 'Interview' ? 'secondary' : 'outline'}
                              className="text-xs"
                            >
                              {candidate.status}
                            </Badge>
                            <div className="flex space-x-2">
                              <Button size="sm" variant="ghost">
                                <Eye className="w-4 h-4" />
                              </Button>
                              <Button size="sm" variant="ghost">
                                <MessageSquare className="w-4 h-4" />
                              </Button>
                              <Button size="sm" variant="ghost" className="text-green-600">
                                <CheckCircle className="w-4 h-4" />
                              </Button>
                              <Button size="sm" variant="ghost" className="text-red-600">
                                <XCircle className="w-4 h-4" />
                              </Button>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
                <Button variant="outline" className="w-full mt-4">
                  View All Candidates
                </Button>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar Content */}
          <div className="space-y-6">
            {/* Upcoming Interviews */}
            <Card className="shadow-sm">
              <CardHeader>
                <CardTitle className="text-lg">Upcoming Interviews</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {upcomingInterviews.map((interview, index) => (
                    <div key={index} className="border-l-2 border-green-500 pl-4">
                      <h3 className="font-medium text-neutral-600">{interview.candidate}</h3>
                      <p className="text-sm text-neutral-500">{interview.position}</p>
                      <div className="flex items-center justify-between mt-2">
                        <div className="text-xs text-neutral-400">
                          <Clock className="w-3 h-3 inline mr-1" />
                          {interview.time}
                        </div>
                        <Badge variant="outline" className="text-xs">
                          {interview.type}
                        </Badge>
                      </div>
                    </div>
                  ))}
                </div>
                <Button variant="outline" className="w-full mt-4">
                  <Calendar className="w-4 h-4 mr-2" />
                  Schedule Interview
                </Button>
              </CardContent>
            </Card>

            {/* Active Job Postings */}
            <Card className="shadow-sm">
              <CardHeader>
                <CardTitle className="text-lg">Active Job Postings</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {activeJobs.map((job, index) => (
                    <div key={index} className="p-3 border border-neutral-200 rounded-lg">
                      <div className="flex items-center justify-between mb-2">
                        <h3 className="font-medium text-neutral-600 text-sm">{job.title}</h3>
                        <Badge 
                          variant={job.status === 'Active' ? 'default' : 'secondary'}
                          className="text-xs"
                        >
                          {job.status}
                        </Badge>
                      </div>
                      <div className="grid grid-cols-2 gap-2 text-xs text-neutral-500">
                        <div>Applications: {job.applications}</div>
                        <div>Interviews: {job.interviews}</div>
                      </div>
                      <p className="text-xs text-neutral-400 mt-1">{job.posted}</p>
                    </div>
                  ))}
                </div>
                <Button variant="outline" className="w-full mt-4">
                  <Plus className="w-4 h-4 mr-2" />
                  Create Job Posting
                </Button>
              </CardContent>
            </Card>

            {/* Hiring Funnel */}
            <Card className="shadow-sm">
              <CardHeader>
                <CardTitle className="text-lg">Hiring Funnel</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {hiringFunnel.map((stage, index) => (
                    <div key={index}>
                      <div className="flex justify-between items-center mb-1">
                        <span className="text-sm text-neutral-600">{stage.stage}</span>
                        <span className="text-sm font-medium text-neutral-600">{stage.count}</span>
                      </div>
                      <Progress value={stage.percentage} className="h-2" />
                      <div className="text-xs text-neutral-400 mt-1">{stage.percentage}% of total</div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </PlatformLayout>
  );
}