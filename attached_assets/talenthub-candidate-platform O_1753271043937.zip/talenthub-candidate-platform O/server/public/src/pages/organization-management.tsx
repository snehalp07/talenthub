import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Progress } from "@/components/ui/progress";
import { 
  Building2,
  Users,
  GraduationCap,
  Shield,
  Target,
  BarChart3,
  Settings,
  UserPlus,
  TestTube,
  Award,
  Calendar,
  TrendingUp,
  FileText,
  Download,
  Upload
} from "lucide-react";
import PlatformLayout from "@/components/layout/platform-layout";
import { NavigationSection } from "@/components/layout/expandable-sidebar";

const orgNavigation: NavigationSection[] = [
  {
    title: "Organization",
    items: [
      { name: "Dashboard", href: "/organization", icon: Building2 },
      { name: "Settings", href: "/organization/settings", icon: Settings }
    ]
  },
  {
    title: "User Management",
    items: [
      { name: "All Users", href: "/organization/users", icon: Users },
      { name: "Departments", href: "/organization/departments", icon: Building2 },
      { name: "Roles & Permissions", href: "/organization/roles", icon: Shield },
      { name: "Bulk Import", href: "/organization/bulk-import", icon: Upload }
    ]
  },
  {
    title: "Assessment Management",
    items: [
      { name: "Test Creation", href: "/organization/tests/create", icon: TestTube },
      { name: "Test Library", href: "/organization/tests", icon: FileText },
      { name: "Assign Tests", href: "/organization/assign", icon: Target },
      { name: "Proctoring", href: "/organization/proctoring", icon: Shield }
    ]
  },
  {
    title: "Analytics & Reports",
    items: [
      { name: "Organization Analytics", href: "/organization/analytics", icon: BarChart3 },
      { name: "Department Reports", href: "/organization/department-reports", icon: TrendingUp },
      { name: "Compliance", href: "/organization/compliance", icon: Award },
      { name: "Export Data", href: "/organization/export", icon: Download }
    ]
  }
];

// Sample organizational data representing real multi-tenant scenarios
const sampleOrganizations = [
  {
    id: "1",
    name: "TechCorp Inc.",
    type: "Enterprise",
    industry: "Technology",
    size: "1000-5000",
    plan: "Enterprise",
    departments: [
      { name: "Engineering", userCount: 450, testsActive: 12, manager: "Sarah Chen", budget: 125000 },
      { name: "Product Management", userCount: 85, testsActive: 3, manager: "David Rodriguez", budget: 45000 },
      { name: "Human Resources", userCount: 25, testsActive: 8, manager: "Lisa Wang", budget: 35000 },
      { name: "Sales & Marketing", userCount: 120, testsActive: 2, manager: "Michael Johnson", budget: 28000 }
    ],
    roles: [
      { name: "CHRO", users: 1, permissions: ["org_admin", "view_all", "manage_users", "budget_approval"] },
      { name: "Engineering Manager", users: 8, permissions: ["dept_manage", "create_tests", "view_dept", "hire_approve"] },
      { name: "Senior Recruiter", users: 12, permissions: ["create_hire_tests", "view_candidates", "schedule_interviews"] },
      { name: "Team Lead", users: 45, permissions: ["assign_tests", "view_team", "performance_review"] },
      { name: "Software Engineer", users: 420, permissions: ["take_tests", "view_own", "skill_development"] },
      { name: "Intern", users: 45, permissions: ["take_tests", "view_own"] }
    ],
    metrics: {
      totalUsers: 680,
      activeTests: 25,
      completedAssessments: 1247,
      certificationRate: 78,
      monthlyBudget: 233000,
      avgHireTime: 45
    },
    workflows: {
      recruitment: {
        activePipelines: 12,
        candidatesInProcess: 89,
        avgTimeToHire: 35,
        successRate: 82
      },
      performance: {
        annualReviews: 156,
        promotionCandidates: 23,
        skillGapAnalysis: 8
      }
    }
  },
  {
    id: "2",
    name: "State University",
    type: "Educational",
    industry: "Higher Education",
    size: "5000+",
    plan: "Education",
    departments: [
      { name: "Computer Science", userCount: 850, testsActive: 35, manager: "Dr. Emily Foster", budget: 280000 },
      { name: "Business Administration", userCount: 1200, testsActive: 28, manager: "Prof. James Miller", budget: 195000 },
      { name: "Engineering", userCount: 950, testsActive: 42, manager: "Dr. Robert Kim", budget: 320000 },
      { name: "Liberal Arts", userCount: 780, testsActive: 15, manager: "Dr. Maria Gonzalez", budget: 145000 }
    ],
    roles: [
      { name: "Dean", users: 4, permissions: ["org_admin", "view_all", "manage_faculty", "curriculum_approve"] },
      { name: "Department Head", users: 12, permissions: ["dept_manage", "create_exams", "view_dept", "faculty_hire"] },
      { name: "Professor", users: 185, permissions: ["create_tests", "grade_students", "view_classes", "research_access"] },
      { name: "Associate Professor", users: 145, permissions: ["create_tests", "grade_students", "view_classes"] },
      { name: "Teaching Assistant", users: 95, permissions: ["assist_grading", "view_assigned", "student_support"] },
      { name: "Graduate Student", users: 456, permissions: ["take_tests", "view_grades", "research_participate"] },
      { name: "Undergraduate Student", users: 3124, permissions: ["take_tests", "view_grades", "course_evaluate"] }
    ],
    metrics: {
      totalUsers: 3876,
      activeTests: 120,
      completedAssessments: 15420,
      certificationRate: 92,
      semesterBudget: 940000,
      graduationRate: 87
    },
    workflows: {
      academic: {
        scheduledExams: 45,
        studentsEnrolled: 3580,
        coursesActive: 156,
        gradingPending: 890
      },
      placement: {
        placementTests: 12,
        newStudentTesting: 450,
        transferCredits: 89
      }
    }
  },
  {
    id: "3",
    name: "AWS Professional Certification",
    type: "Certification Body",
    industry: "Professional Certification",
    size: "500-1000",
    plan: "Professional",
    departments: [
      { name: "Cloud Architecture", userCount: 2500, testsActive: 8, manager: "Jennifer Adams", budget: 450000 },
      { name: "DevOps Engineering", userCount: 1800, testsActive: 6, manager: "Carlos Rivera", budget: 380000 },
      { name: "Security Specialization", userCount: 1200, testsActive: 4, manager: "Ahmed Hassan", budget: 290000 },
      { name: "Data Analytics", userCount: 950, testsActive: 3, manager: "Priya Sharma", budget: 220000 }
    ],
    roles: [
      { name: "Certification Director", users: 2, permissions: ["org_admin", "manage_standards", "approve_certs", "policy_set"] },
      { name: "Subject Matter Expert", users: 25, permissions: ["create_cert_tests", "review_content", "standards_define"] },
      { name: "Proctor Administrator", users: 45, permissions: ["manage_proctoring", "monitor_exams", "security_enforce"] },
      { name: "Content Developer", users: 78, permissions: ["create_content", "test_design", "quality_assurance"] },
      { name: "Certification Candidate", users: 6450, permissions: ["take_cert_tests", "view_progress", "schedule_exams"] }
    ],
    metrics: {
      totalUsers: 6522,
      activeTests: 21,
      completedAssessments: 28450,
      certificationRate: 68,
      annualRevenue: 12500000,
      examIntegrity: 99.7
    },
    workflows: {
      certification: {
        activeCertifications: 21,
        monthlyTestTakers: 2890,
        passRate: 68,
        retakeRate: 15
      },
      credentialing: {
        issuedCredentials: 19340,
        verificationRequests: 5670,
        fraudPrevention: 45,
        blockchainVerified: 8950
      }
    }
  },
  {
    id: "4",
    name: "Global Consulting Partners",
    type: "Enterprise",
    industry: "Professional Services",
    size: "500-1000",
    plan: "Enterprise",
    departments: [
      { name: "Strategy Consulting", userCount: 180, testsActive: 6, manager: "Alexander Thompson", budget: 95000 },
      { name: "Technology Consulting", userCount: 220, testsActive: 8, manager: "Raj Patel", budget: 110000 },
      { name: "Operations", userCount: 85, testsActive: 3, manager: "Sophie Laurent", budget: 42000 },
      { name: "Human Capital", userCount: 45, testsActive: 4, manager: "Emma Williams", budget: 38000 }
    ],
    roles: [
      { name: "Managing Partner", users: 3, permissions: ["org_admin", "client_access", "revenue_view", "strategic_decisions"] },
      { name: "Principal", users: 12, permissions: ["practice_manage", "client_manage", "team_build", "proposal_approve"] },
      { name: "Senior Manager", users: 35, permissions: ["project_lead", "team_manage", "client_interface", "assess_skills"] },
      { name: "Manager", users: 65, permissions: ["project_manage", "team_coord", "skill_assess", "mentor_junior"] },
      { name: "Senior Consultant", users: 125, permissions: ["client_work", "skill_develop", "mentor_support"] },
      { name: "Consultant", users: 285, permissions: ["take_tests", "skill_develop", "project_support"] }
    ],
    metrics: {
      totalUsers: 530,
      activeTests: 21,
      completedAssessments: 2340,
      certificationRate: 85,
      clientSatisfaction: 4.7,
      billableUtilization: 78
    },
    workflows: {
      consulting: {
        activeProjects: 45,
        clientEngagements: 78,
        proposalsInProgress: 23,
        talentAllocation: 89
      },
      development: {
        skillAssessments: 156,
        careerProgression: 67,
        mentoringPrograms: 12
      }
    }
  }
];

export default function OrganizationManagement() {
  const [selectedOrg, setSelectedOrg] = useState(sampleOrganizations[0]);
  const [activeTab, setActiveTab] = useState("overview");

  const usageData = [
    { label: "Active Users", current: Math.min(selectedOrg.metrics.totalUsers, 5000), max: 10000 },
    { label: "Monthly Tests", current: selectedOrg.metrics.activeTests, max: 200 },
    { label: "Storage Used", current: 45, max: 100 }
  ];

  return (
    <PlatformLayout
      sidebarTitle="Organization Management"
      sidebarSubtitle="Multi-Tenant Administration"
      sidebarSections={orgNavigation}
      usageData={usageData}
    >
      <div className="space-y-8">
        {/* Header */}
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold text-blue-800">Organization Dashboard</h1>
            <p className="text-blue-600 mt-2">Multi-tenant assessment platform management across diverse organizational types</p>
          </div>
          <div className="flex items-center gap-4">
            <Select value={selectedOrg.id} onValueChange={(value) => setSelectedOrg(sampleOrganizations.find(org => org.id === value) || sampleOrganizations[0])}>
              <SelectTrigger className="w-64">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {sampleOrganizations.map((org) => (
                  <SelectItem key={org.id} value={org.id}>
                    <div className="flex items-center gap-2">
                      <Building2 className="w-4 h-4" />
                      {org.name}
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Organization Overview */}
        <Card className="border-l-4 border-blue-500">
          <CardHeader>
            <div className="flex justify-between items-start">
              <div>
                <CardTitle className="text-xl text-blue-800">{selectedOrg.name}</CardTitle>
                <CardDescription className="text-base">
                  {selectedOrg.type} • {selectedOrg.industry} • {selectedOrg.size} employees
                </CardDescription>
              </div>
              <Badge className="bg-blue-100 text-blue-800">{selectedOrg.plan} Plan</Badge>
            </div>
          </CardHeader>
        </Card>

        {/* Key Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <Card className="border-l-4 border-green-500">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Total Users</p>
                  <p className="text-3xl font-bold text-gray-900">{selectedOrg.metrics.totalUsers.toLocaleString()}</p>
                  <p className="text-xs text-gray-500 mt-1">Across {selectedOrg.departments.length} departments</p>
                </div>
                <Users className="w-8 h-8 text-green-600" />
              </div>
            </CardContent>
          </Card>

          <Card className="border-l-4 border-purple-500">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Active Tests</p>
                  <p className="text-3xl font-bold text-gray-900">{selectedOrg.metrics.activeTests}</p>
                  <p className="text-xs text-gray-500 mt-1">{selectedOrg.type === "Educational" ? "Course exams" : selectedOrg.type === "Certification Body" ? "Cert exams" : "Assessments"}</p>
                </div>
                <TestTube className="w-8 h-8 text-purple-600" />
              </div>
            </CardContent>
          </Card>

          <Card className="border-l-4 border-amber-500">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Completed Assessments</p>
                  <p className="text-3xl font-bold text-gray-900">{selectedOrg.metrics.completedAssessments.toLocaleString()}</p>
                  <p className="text-xs text-gray-500 mt-1">This academic/fiscal year</p>
                </div>
                <BarChart3 className="w-8 h-8 text-amber-600" />
              </div>
            </CardContent>
          </Card>

          <Card className="border-l-4 border-indigo-500">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">
                    {selectedOrg.type === "Educational" ? "Graduation Rate" : 
                     selectedOrg.type === "Certification Body" ? "Certification Rate" : "Success Rate"}
                  </p>
                  <p className="text-3xl font-bold text-gray-900">{selectedOrg.metrics.certificationRate}%</p>
                  <p className="text-xs text-gray-500 mt-1">
                    {selectedOrg.type === "Educational" ? "Student graduation" :
                     selectedOrg.type === "Certification Body" ? "Exam pass rate" : "Assessment completion"}
                  </p>
                </div>
                <Award className="w-8 h-8 text-indigo-600" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Detailed Management Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="departments">Departments</TabsTrigger>
            <TabsTrigger value="roles">Roles & Permissions</TabsTrigger>
            <TabsTrigger value="workflows">Specialized Workflows</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6">
            {/* Quick Actions */}
            <Card>
              <CardHeader>
                <CardTitle>Quick Actions</CardTitle>
                <CardDescription>Common organizational management tasks for {selectedOrg.type.toLowerCase()} organizations</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                  <Button variant="outline" className="flex items-center gap-2">
                    <UserPlus className="w-4 h-4" />
                    {selectedOrg.type === "Educational" ? "Enroll Students" : "Add Users"}
                  </Button>
                  <Button variant="outline" className="flex items-center gap-2">
                    <TestTube className="w-4 h-4" />
                    {selectedOrg.type === "Educational" ? "Create Exam" : selectedOrg.type === "Certification Body" ? "Design Certification" : "Create Assessment"}
                  </Button>
                  <Button variant="outline" className="flex items-center gap-2">
                    <Target className="w-4 h-4" />
                    {selectedOrg.type === "Educational" ? "Schedule Exam" : "Assign Assessment"}
                  </Button>
                  <Button variant="outline" className="flex items-center gap-2">
                    <BarChart3 className="w-4 h-4" />
                    {selectedOrg.type === "Educational" ? "Academic Reports" : "View Analytics"}
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Recent Activity */}
            <Card>
              <CardHeader>
                <CardTitle>Recent Organizational Activity</CardTitle>
                <CardDescription>Latest actions across {selectedOrg.name}</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {selectedOrg.type === "Educational" && (
                    <>
                      <div className="flex items-center gap-4 p-3 border rounded-lg">
                        <TestTube className="w-5 h-5 text-purple-600" />
                        <div className="flex-1">
                          <p className="font-medium">Midterm Examinations Scheduled</p>
                          <p className="text-sm text-gray-600">Computer Science Department • 3 hours ago</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-4 p-3 border rounded-lg">
                        <Users className="w-5 h-5 text-blue-600" />
                        <div className="flex-1">
                          <p className="font-medium">450 New Students Enrolled for Fall Semester</p>
                          <p className="text-sm text-gray-600">University-wide • 6 hours ago</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-4 p-3 border rounded-lg">
                        <Award className="w-5 h-5 text-green-600" />
                        <div className="flex-1">
                          <p className="font-medium">287 Students Graduated with Honors</p>
                          <p className="text-sm text-gray-600">Spring Graduation Ceremony • Yesterday</p>
                        </div>
                      </div>
                    </>
                  )}
                  
                  {selectedOrg.type === "Enterprise" && (
                    <>
                      <div className="flex items-center gap-4 p-3 border rounded-lg">
                        <TestTube className="w-5 h-5 text-purple-600" />
                        <div className="flex-1">
                          <p className="font-medium">Senior Software Engineer Assessment Created</p>
                          <p className="text-sm text-gray-600">Engineering Department • 2 hours ago</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-4 p-3 border rounded-lg">
                        <Users className="w-5 h-5 text-blue-600" />
                        <div className="flex-1">
                          <p className="font-medium">12 New Candidates in Recruitment Pipeline</p>
                          <p className="text-sm text-gray-600">HR Department • 4 hours ago</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-4 p-3 border rounded-lg">
                        <Award className="w-5 h-5 text-green-600" />
                        <div className="flex-1">
                          <p className="font-medium">23 Employees Promoted Based on Assessment Results</p>
                          <p className="text-sm text-gray-600">Q1 Performance Review • Yesterday</p>
                        </div>
                      </div>
                    </>
                  )}

                  {selectedOrg.type === "Certification Body" && (
                    <>
                      <div className="flex items-center gap-4 p-3 border rounded-lg">
                        <TestTube className="w-5 h-5 text-purple-600" />
                        <div className="flex-1">
                          <p className="font-medium">AWS Solutions Architect Professional Exam Updated</p>
                          <p className="text-sm text-gray-600">Cloud Architecture Team • 1 hour ago</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-4 p-3 border rounded-lg">
                        <Users className="w-5 h-5 text-blue-600" />
                        <div className="flex-1">
                          <p className="font-medium">2,890 Monthly Certification Exam Attempts</p>
                          <p className="text-sm text-gray-600">All Certification Programs • Today</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-4 p-3 border rounded-lg">
                        <Award className="w-5 h-5 text-green-600" />
                        <div className="flex-1">
                          <p className="font-medium">1,967 Digital Credentials Issued</p>
                          <p className="text-sm text-gray-600">Blockchain Verified • This month</p>
                        </div>
                      </div>
                    </>
                  )}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="departments" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Department Structure</CardTitle>
                <CardDescription>Organizational departments and their assessment activities</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {selectedOrg.departments.map((dept, index) => (
                    <div key={index} className="border rounded-lg p-4">
                      <div className="flex items-center justify-between mb-3">
                        <div>
                          <h3 className="font-semibold text-lg">{dept.name}</h3>
                          <p className="text-sm text-gray-600">Managed by {dept.manager}</p>
                        </div>
                        <div className="flex items-center gap-4">
                          <Badge variant="outline">{dept.userCount.toLocaleString()} users</Badge>
                          <Badge variant="secondary">{dept.testsActive} active tests</Badge>
                          <Badge variant="outline">${dept.budget.toLocaleString()} budget</Badge>
                        </div>
                      </div>
                      <div className="grid grid-cols-3 gap-4 text-sm">
                        <div>
                          <span className="text-gray-600">User Engagement:</span>
                          <Progress value={(dept.userCount / selectedOrg.metrics.totalUsers) * 100} className="h-2 mt-1" />
                          <span className="text-xs text-gray-500">{Math.round((dept.userCount / selectedOrg.metrics.totalUsers) * 100)}% of total</span>
                        </div>
                        <div>
                          <span className="text-gray-600">Test Activity:</span>
                          <Progress value={(dept.testsActive / selectedOrg.metrics.activeTests) * 100} className="h-2 mt-1" />
                          <span className="text-xs text-gray-500">{Math.round((dept.testsActive / selectedOrg.metrics.activeTests) * 100)}% of tests</span>
                        </div>
                        <div className="flex gap-2">
                          <Button size="sm" variant="outline">Manage</Button>
                          <Button size="sm" variant="outline">Analytics</Button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="roles" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Role-Based Access Control</CardTitle>
                <CardDescription>Organizational hierarchy and permissions for {selectedOrg.type.toLowerCase()} operations</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {selectedOrg.roles.map((role, index) => (
                    <div key={index} className="border rounded-lg p-4">
                      <div className="flex items-center justify-between mb-3">
                        <div>
                          <h3 className="font-semibold">{role.name}</h3>
                          <p className="text-sm text-gray-600">{role.users.toLocaleString()} users assigned</p>
                        </div>
                        <Button size="sm" variant="outline">Edit Permissions</Button>
                      </div>
                      <div className="flex flex-wrap gap-2">
                        {role.permissions.map((permission, permIndex) => (
                          <Badge key={permIndex} variant="secondary" className="text-xs">
                            {permission.replace(/_/g, ' ')}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="workflows" className="space-y-6">
            {/* Specialized Workflows based on Organization Type */}
            {selectedOrg.type === "Enterprise" && (
              <>
                <Card>
                  <CardHeader>
                    <CardTitle>Corporate Hiring Workflows</CardTitle>
                    <CardDescription>Recruitment and employee assessment processes</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="border rounded-lg p-4">
                        <h4 className="font-semibold mb-2">Technical Recruitment Pipeline</h4>
                        <p className="text-sm text-gray-600 mb-3">Multi-stage assessment for engineering roles</p>
                        <div className="space-y-2">
                          <div className="flex justify-between text-sm">
                            <span>Active Pipelines:</span>
                            <span className="font-medium">{selectedOrg.workflows?.recruitment?.activePipelines || 0}</span>
                          </div>
                          <div className="flex justify-between text-sm">
                            <span>Candidates in Process:</span>
                            <span className="font-medium">{selectedOrg.workflows?.recruitment?.candidatesInProcess || 0}</span>
                          </div>
                          <div className="flex justify-between text-sm">
                            <span>Avg. Time to Hire:</span>
                            <span className="font-medium">{selectedOrg.workflows?.recruitment?.avgTimeToHire || 0} days</span>
                          </div>
                          <div className="flex justify-between text-sm">
                            <span>Success Rate:</span>
                            <span className="font-medium">{selectedOrg.workflows?.recruitment?.successRate || 0}%</span>
                          </div>
                        </div>
                      </div>
                      <div className="border rounded-lg p-4">
                        <h4 className="font-semibold mb-2">Performance Management</h4>
                        <p className="text-sm text-gray-600 mb-3">Employee skill validation and career progression</p>
                        <div className="space-y-2">
                          <div className="flex justify-between text-sm">
                            <span>Annual Reviews Completed:</span>
                            <span className="font-medium">{selectedOrg.workflows?.performance?.annualReviews || 0}</span>
                          </div>
                          <div className="flex justify-between text-sm">
                            <span>Promotion Candidates:</span>
                            <span className="font-medium">{selectedOrg.workflows?.performance?.promotionCandidates || 0}</span>
                          </div>
                          <div className="flex justify-between text-sm">
                            <span>Skill Gap Analysis:</span>
                            <span className="font-medium">{selectedOrg.workflows?.performance?.skillGapAnalysis || 0} departments</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </>
            )}

            {selectedOrg.type === "Educational" && (
              <Card>
                <CardHeader>
                  <CardTitle>Academic Assessment Workflows</CardTitle>
                  <CardDescription>Course examinations, placement testing, and academic evaluations</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="border rounded-lg p-4">
                      <h4 className="font-semibold mb-2">Course Examinations</h4>
                      <p className="text-sm text-gray-600 mb-3">Semester exams with automated proctoring</p>
                      <div className="space-y-2">
                        <div className="flex justify-between text-sm">
                          <span>Scheduled Exams:</span>
                          <span className="font-medium">{selectedOrg.workflows.academic.scheduledExams}</span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span>Students Enrolled:</span>
                          <span className="font-medium">{selectedOrg.workflows.academic.studentsEnrolled.toLocaleString()}</span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span>Active Courses:</span>
                          <span className="font-medium">{selectedOrg.workflows.academic.coursesActive}</span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span>Grading Pending:</span>
                          <span className="font-medium">{selectedOrg.workflows.academic.gradingPending}</span>
                        </div>
                      </div>
                    </div>
                    <div className="border rounded-lg p-4">
                      <h4 className="font-semibold mb-2">Student Placement</h4>
                      <p className="text-sm text-gray-600 mb-3">Prerequisite validation and course placement</p>
                      <div className="space-y-2">
                        <div className="flex justify-between text-sm">
                          <span>Placement Tests Available:</span>
                          <span className="font-medium">{selectedOrg.workflows.placement.placementTests}</span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span>New Student Testing:</span>
                          <span className="font-medium">{selectedOrg.workflows.placement.newStudentTesting}</span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span>Transfer Credit Evaluations:</span>
                          <span className="font-medium">{selectedOrg.workflows.placement.transferCredits}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}

            {selectedOrg.type === "Certification Body" && (
              <Card>
                <CardHeader>
                  <CardTitle>Professional Certification Workflows</CardTitle>
                  <CardDescription>Industry certification exams and digital credential management</CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="border rounded-lg p-4">
                      <h4 className="font-semibold mb-2">Certification Examinations</h4>
                      <p className="text-sm text-gray-600 mb-3">Proctored professional certification testing</p>
                      <div className="space-y-2">
                        <div className="flex justify-between text-sm">
                          <span>Active Certifications:</span>
                          <span className="font-medium">{selectedOrg.workflows.certification.activeCertifications}</span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span>Monthly Test Takers:</span>
                          <span className="font-medium">{selectedOrg.workflows.certification.monthlyTestTakers.toLocaleString()}</span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span>Pass Rate:</span>
                          <span className="font-medium">{selectedOrg.workflows.certification.passRate}%</span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span>Retake Rate:</span>
                          <span className="font-medium">{selectedOrg.workflows.certification.retakeRate}%</span>
                        </div>
                      </div>
                    </div>
                    <div className="border rounded-lg p-4">
                      <h4 className="font-semibold mb-2">Digital Credential Management</h4>
                      <p className="text-sm text-gray-600 mb-3">Blockchain-verified badge and certificate issuance</p>
                      <div className="space-y-2">
                        <div className="flex justify-between text-sm">
                          <span>Issued Credentials:</span>
                          <span className="font-medium">{selectedOrg.workflows.credentialing.issuedCredentials.toLocaleString()}</span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span>Verification Requests:</span>
                          <span className="font-medium">{selectedOrg.workflows.credentialing.verificationRequests.toLocaleString()}</span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span>Fraud Prevention Cases:</span>
                          <span className="font-medium">{selectedOrg.workflows.credentialing.fraudPrevention}</span>
                        </div>
                        <div className="flex justify-between text-sm">
                          <span>Blockchain Verified:</span>
                          <span className="font-medium">{selectedOrg.workflows.credentialing.blockchainVerified.toLocaleString()}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </PlatformLayout>
  );
}