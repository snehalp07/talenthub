import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { 
  CreditCard, 
  Calendar, 
  BarChart3, 
  AlertTriangle, 
  Download, 
  Plus,
  Check,
  X,
  ArrowLeft,
  Home,
  Users,
  Briefcase,
  Award,
  Settings,
  Star,
  Target,
  TrendingUp,
  Search
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { queryClient } from "@/lib/queryClient";
import { Link } from "wouter";
import PlatformLayout from "@/components/layout/platform-layout";
import { platformConfigs } from "@/config/complete-navigation";

export default function BillingDashboard() {
  const [isAddingPaymentMethod, setIsAddingPaymentMethod] = useState(false);
  const { toast } = useToast();

  // Use candidate platform configuration
  const config = platformConfigs.candidate;



  // Fetch billing data
  const { data: subscriptionData, isLoading: subscriptionLoading } = useQuery({
    queryKey: ["/api/billing/subscription"],
  });

  const { data: billingUsageData, isLoading: usageLoading } = useQuery({
    queryKey: ["/api/billing/usage"],
  });

  const { data: invoicesData, isLoading: invoicesLoading } = useQuery({
    queryKey: ["/api/billing/invoices"],
  });

  const { data: paymentMethodsData, isLoading: paymentMethodsLoading } = useQuery({
    queryKey: ["/api/billing/payment-methods"],
  });

  const { data: alertsData } = useQuery({
    queryKey: ["/api/billing/alerts"],
  });

  // Payment processing mutation
  const processPaymentMutation = useMutation({
    mutationFn: async (paymentData: any) => {
      const response = await fetch("/api/billing/process-payment", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(paymentData),
      });
      return response.json();
    },
    onSuccess: (data) => {
      if (data.success) {
        toast({
          title: "Payment Successful",
          description: data.message,
        });
        queryClient.invalidateQueries({ queryKey: ["/api/billing/invoices"] });
      } else {
        toast({
          title: "Payment Failed",
          description: data.message,
          variant: "destructive",
        });
      }
    },
  });

  // Add payment method mutation
  const addPaymentMethodMutation = useMutation({
    mutationFn: async (paymentMethodData: any) => {
      const response = await fetch("/api/billing/payment-methods", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(paymentMethodData),
      });
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Payment Method Added",
        description: "Your payment method has been successfully added.",
      });
      setIsAddingPaymentMethod(false);
      queryClient.invalidateQueries({ queryKey: ["/api/billing/payment-methods"] });
    },
  });

  const handleAddPaymentMethod = (e: React.FormEvent) => {
    e.preventDefault();
    const formData = new FormData(e.target as HTMLFormElement);
    
    addPaymentMethodMutation.mutate({
      type: 'card',
      cardLast4: formData.get('cardNumber')?.toString().slice(-4),
      cardBrand: 'Visa', // Demo data
      expiryMonth: parseInt(formData.get('expiryMonth')?.toString() || '12'),
      expiryYear: parseInt(formData.get('expiryYear')?.toString() || '2028'),
      holderName: formData.get('holderName'),
      isDefault: true,
    });
  };

  if (subscriptionLoading || usageLoading || invoicesLoading || paymentMethodsLoading) {
    return (
      <PlatformLayout
        sidebarTitle={config.sidebarTitle}
        sidebarSubtitle={config.sidebarSubtitle}
        sidebarSections={config.sidebarSections}
      >
        <div className="flex items-center justify-center min-h-[400px]">
          <div className="animate-spin w-8 h-8 border-4 border-gray-300 border-t-gray-600 rounded-full" />
        </div>
      </PlatformLayout>
    );
  }

  // Mock data for billing dashboard demonstration
  const subscription = subscriptionData?.subscription || {
    id: "sub_123456",
    plan: "Professional",
    status: "active",
    currentPeriod: { start: "2024-01-01", end: "2024-01-31" },
    amount: 2999,
    currency: "USD"
  };
  
  const plan = subscriptionData?.plan || {
    name: "Professional",
    features: ["Unlimited Tests", "Advanced Analytics", "Priority Support"],
    limits: { tests: -1, users: 50, storage: "100GB" }
  };
  
  const usage = billingUsageData?.summary || [
    { metric: "Tests Created", used: 45, limit: 100, unit: "tests" },
    { metric: "Active Users", used: 23, limit: 50, unit: "users" },
    { metric: "Storage Used", used: 35, limit: 100, unit: "GB" }
  ];
  
  const invoices = Array.isArray(invoicesData) ? invoicesData : [
    { id: "inv_001", date: "2024-01-01", amount: 2999, status: "paid", description: "Professional Plan - January 2024" },
    { id: "inv_002", date: "2023-12-01", amount: 2999, status: "paid", description: "Professional Plan - December 2023" },
    { id: "inv_003", date: "2023-11-01", amount: 2999, status: "paid", description: "Professional Plan - November 2023" }
  ];
  
  const paymentMethods = Array.isArray(paymentMethodsData) ? paymentMethodsData : [
    { id: "pm_001", type: "card", last4: "4242", brand: "Visa", expiryMonth: 12, expiryYear: 2027, isDefault: true }
  ];
  
  const alerts = Array.isArray(alertsData) ? alertsData : [
    { id: "alert_001", severity: "warning", title: "Usage Alert", message: "You're approaching 80% of your test creation limit." }
  ];

  const getUsageColor = (percentage: number) => {
    if (percentage >= 100) return "bg-red-500";
    if (percentage >= 80) return "bg-yellow-500";
    return "bg-green-500";
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'paid':
        return <Badge className="bg-green-100 text-green-800">Paid</Badge>;
      case 'overdue':
        return <Badge className="bg-red-100 text-red-800">Overdue</Badge>;
      case 'pending':
        return <Badge className="bg-yellow-100 text-yellow-800">Pending</Badge>;
      default:
        return <Badge className="bg-gray-100 text-gray-800">{status}</Badge>;
    }
  };

  return (
    <PlatformLayout
      sidebarTitle={config.sidebarTitle}
      sidebarSubtitle={config.sidebarSubtitle}
      sidebarSections={config.sidebarSections}
    >
      <div className="p-6 space-y-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Link href="/candidate">
              <Button variant="ghost" size="sm" className="text-gray-600 hover:text-gray-900">
                <ArrowLeft className="h-4 w-4 mr-2" />
                Back to Candidate Dashboard
              </Button>
            </Link>
            <h1 className="text-3xl font-bold text-gray-900">Candidate Billing</h1>
          </div>
          <Button variant="outline">
            <Download className="w-4 h-4 mr-2" />
            Export Data
          </Button>
        </div>

      {/* Critical Alerts */}
      {alerts.length > 0 && (
        <div className="space-y-3">
          {alerts.map((alert: any) => (
            <Alert key={alert.id} className={`border-l-4 ${
              alert.severity === 'critical' ? 'border-red-500 bg-red-50' :
              alert.severity === 'warning' ? 'border-yellow-500 bg-yellow-50' :
              'border-blue-500 bg-blue-50'
            }`}>
              <AlertTriangle className="h-4 w-4" />
              <AlertDescription>
                <div className="flex items-center justify-between">
                  <div>
                    <span className="font-medium">{alert.title}</span>
                    <p className="text-sm text-gray-600 mt-1">{alert.message}</p>
                  </div>
                  <Badge className={`${
                    alert.severity === 'critical' ? 'bg-red-100 text-red-800' :
                    alert.severity === 'warning' ? 'bg-yellow-100 text-yellow-800' :
                    'bg-blue-100 text-blue-800'
                  }`}>
                    {alert.severity}
                  </Badge>
                </div>
              </AlertDescription>
            </Alert>
          ))}
        </div>
      )}

      <Tabs defaultValue="overview" className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="usage">Usage</TabsTrigger>
          <TabsTrigger value="invoices">Invoices</TabsTrigger>
          <TabsTrigger value="payment">Payment</TabsTrigger>
        </TabsList>

        {/* Overview Tab */}
        <TabsContent value="overview" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Current Plan */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <CreditCard className="w-5 h-5" />
                  Current Plan
                </CardTitle>
              </CardHeader>
              <CardContent>
                {plan ? (
                  <div className="space-y-4">
                    <div>
                      <h3 className="text-2xl font-bold">{plan.name}</h3>
                      <p className="text-gray-600">{plan.description}</p>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-3xl font-bold">${plan.price}</span>
                      <span className="text-gray-600">/{plan.billingCycle}</span>
                    </div>
                    <div className="pt-4">
                      <Button className="w-full">Upgrade Plan</Button>
                    </div>
                  </div>
                ) : (
                  <div className="text-center py-4">
                    <p className="text-gray-600">No active subscription</p>
                    <Button className="mt-4">Choose a Plan</Button>
                  </div>
                )}
              </CardContent>
            </Card>

            {/* Billing Info */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Calendar className="w-5 h-5" />
                  Billing Information
                </CardTitle>
              </CardHeader>
              <CardContent>
                {subscription ? (
                  <div className="space-y-4">
                    <div className="flex justify-between">
                      <span className="text-gray-600">Status:</span>
                      <Badge className={`${
                        subscription.status === 'active' ? 'bg-green-100 text-green-800' :
                        subscription.status === 'past_due' ? 'bg-red-100 text-red-800' :
                        'bg-yellow-100 text-yellow-800'
                      }`}>
                        {subscription.status}
                      </Badge>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Current Period:</span>
                      <span className="font-medium">
                        {new Date(subscription.currentPeriod?.start || '2024-01-01').toLocaleDateString()} - 
                        {new Date(subscription.currentPeriod?.end || '2024-01-31').toLocaleDateString()}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Next Payment:</span>
                      <span className="font-medium">
                        {subscription.nextPaymentDate ? 
                          new Date(subscription.nextPaymentDate).toLocaleDateString() : 
                          'Not scheduled'
                        }
                      </span>
                    </div>
                  </div>
                ) : (
                  <p className="text-gray-600">No billing information available</p>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Quick Usage Overview */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BarChart3 className="w-5 h-5" />
                Usage Summary
              </CardTitle>
              <CardDescription>Current month usage compared to plan limits</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                {usage.map((item: any) => (
                  <div key={item.feature} className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="capitalize">{item.feature.replace(/([A-Z])/g, ' $1')}</span>
                      <span className="font-medium">
                        {item.planLimit === -1 ? 'Unlimited' : `${item.currentUsage}/${item.planLimit}`}
                      </span>
                    </div>
                    {item.planLimit !== -1 && (
                      <Progress 
                        value={Math.min(item.usagePercentage, 100)} 
                        className="h-2"
                      />
                    )}
                    {item.overageCount > 0 && (
                      <div className="text-xs text-red-600">
                        +{item.overageCount} overage
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Usage Tab */}
        <TabsContent value="usage" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Detailed Usage Breakdown</CardTitle>
              <CardDescription>
                Usage for billing period: {billingUsageData?.currentPeriod || 'Current Period'}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Feature</TableHead>
                    <TableHead>Plan Limit</TableHead>
                    <TableHead>Current Usage</TableHead>
                    <TableHead>Usage %</TableHead>
                    <TableHead>Overage</TableHead>
                    <TableHead>Status</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {usage.map((item: any) => (
                    <TableRow key={item.feature}>
                      <TableCell className="font-medium capitalize">
                        {item.feature.replace(/([A-Z])/g, ' $1')}
                      </TableCell>
                      <TableCell>
                        {item.planLimit === -1 ? 'Unlimited' : item.planLimit.toLocaleString()}
                      </TableCell>
                      <TableCell>{item.currentUsage.toLocaleString()}</TableCell>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <Progress 
                            value={Math.min(item.usagePercentage, 100)} 
                            className="w-16 h-2"
                          />
                          <span className="text-sm font-medium">
                            {item.usagePercentage}%
                          </span>
                        </div>
                      </TableCell>
                      <TableCell>
                        {item.overageCount > 0 ? (
                          <span className="text-red-600 font-medium">
                            +{item.overageCount}
                          </span>
                        ) : (
                          <span className="text-gray-400">-</span>
                        )}
                      </TableCell>
                      <TableCell>
                        {item.usagePercentage >= 100 ? (
                          <Badge className="bg-red-100 text-red-800">Over Limit</Badge>
                        ) : item.usagePercentage >= 80 ? (
                          <Badge className="bg-yellow-100 text-yellow-800">Near Limit</Badge>
                        ) : (
                          <Badge className="bg-green-100 text-green-800">Within Limit</Badge>
                        )}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Invoices Tab */}
        <TabsContent value="invoices" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Billing History</CardTitle>
              <CardDescription>Your invoice and payment history</CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Invoice #</TableHead>
                    <TableHead>Date</TableHead>
                    <TableHead>Amount</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {invoices.map((invoice: any) => (
                    <TableRow key={invoice.id}>
                      <TableCell className="font-medium">{invoice.invoiceNumber}</TableCell>
                      <TableCell>{new Date(invoice.createdAt).toLocaleDateString()}</TableCell>
                      <TableCell>${parseFloat(invoice.total).toFixed(2)}</TableCell>
                      <TableCell>{getStatusBadge(invoice.status)}</TableCell>
                      <TableCell>
                        <div className="flex space-x-2">
                          <Button variant="outline" size="sm">
                            <Download className="w-4 h-4" />
                          </Button>
                          {invoice.status === 'overdue' && (
                            <Button 
                              size="sm"
                              onClick={() => processPaymentMutation.mutate({
                                amount: parseFloat(invoice.total),
                                paymentMethodId: paymentMethods[0]?.id,
                                description: `Payment for invoice ${invoice.invoiceNumber}`
                              })}
                              disabled={processPaymentMutation.isPending}
                            >
                              Pay Now
                            </Button>
                          )}
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Payment Tab */}
        <TabsContent value="payment" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Payment Methods */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  Payment Methods
                  <Dialog open={isAddingPaymentMethod} onOpenChange={setIsAddingPaymentMethod}>
                    <DialogTrigger asChild>
                      <Button size="sm">
                        <Plus className="w-4 h-4 mr-2" />
                        Add Method
                      </Button>
                    </DialogTrigger>
                    <DialogContent>
                      <DialogHeader>
                        <DialogTitle>Add Payment Method</DialogTitle>
                        <DialogDescription>
                          Add a new payment method to your account
                        </DialogDescription>
                      </DialogHeader>
                      <form onSubmit={handleAddPaymentMethod} className="space-y-4">
                        <div>
                          <Label htmlFor="cardNumber">Card Number</Label>
                          <Input
                            id="cardNumber"
                            name="cardNumber"
                            placeholder="4242 4242 4242 4242"
                            required
                          />
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                          <div>
                            <Label htmlFor="expiryMonth">Expiry Month</Label>
                            <Input
                              id="expiryMonth"
                              name="expiryMonth"
                              placeholder="12"
                              required
                            />
                          </div>
                          <div>
                            <Label htmlFor="expiryYear">Expiry Year</Label>
                            <Input
                              id="expiryYear"
                              name="expiryYear"
                              placeholder="2028"
                              required
                            />
                          </div>
                        </div>
                        <div>
                          <Label htmlFor="holderName">Cardholder Name</Label>
                          <Input
                            id="holderName"
                            name="holderName"
                            placeholder="John Smith"
                            required
                          />
                        </div>
                        <Button 
                          type="submit" 
                          className="w-full"
                          disabled={addPaymentMethodMutation.isPending}
                        >
                          Add Payment Method
                        </Button>
                      </form>
                    </DialogContent>
                  </Dialog>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {paymentMethods.map((method: any) => (
                    <div key={method.id} className="flex items-center justify-between p-3 border rounded-lg">
                      <div className="flex items-center gap-3">
                        <CreditCard className="w-5 h-5 text-gray-600" />
                        <div>
                          <div className="font-medium">
                            {method.cardBrand} •••• {method.cardLast4}
                          </div>
                          <div className="text-sm text-gray-600">
                            Expires {method.expiryMonth}/{method.expiryYear}
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        {method.isDefault && (
                          <Badge className="bg-blue-100 text-blue-800">Default</Badge>
                        )}
                        <Button variant="outline" size="sm">Edit</Button>
                      </div>
                    </div>
                  ))}
                  {paymentMethods.length === 0 && (
                    <div className="text-center py-4 text-gray-600">
                      No payment methods added yet
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>

            {/* Quick Payment */}
            <Card>
              <CardHeader>
                <CardTitle>Quick Payment</CardTitle>
                <CardDescription>Make a one-time payment</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <Label htmlFor="amount">Amount</Label>
                    <Input
                      id="amount"
                      type="number"
                      placeholder="50.00"
                      step="0.01"
                    />
                  </div>
                  <div>
                    <Label htmlFor="description">Description</Label>
                    <Input
                      id="description"
                      placeholder="Account credit, overage payment, etc."
                    />
                  </div>
                  <Button 
                    className="w-full"
                    disabled={paymentMethods.length === 0 || processPaymentMutation.isPending}
                    onClick={() => {
                      const amount = (document.getElementById('amount') as HTMLInputElement)?.value;
                      const description = (document.getElementById('description') as HTMLInputElement)?.value;
                      
                      if (amount && paymentMethods[0]) {
                        processPaymentMutation.mutate({
                          amount: parseFloat(amount),
                          paymentMethodId: paymentMethods[0].id,
                          description: description || 'One-time payment'
                        });
                      }
                    }}
                  >
                    {processPaymentMutation.isPending ? 'Processing...' : 'Process Payment'}
                  </Button>
                  {paymentMethods.length === 0 && (
                    <p className="text-sm text-gray-600 text-center">
                      Add a payment method first
                    </p>
                  )}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
      </div>
    </PlatformLayout>
  );
}