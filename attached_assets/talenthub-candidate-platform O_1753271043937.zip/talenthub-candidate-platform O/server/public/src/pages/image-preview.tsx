import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ArrowLeft } from "lucide-react";
import { Link } from "wouter";

const imageOptions = [
  {
    id: 1,
    title: "Option 1: Professional Woman in Modern Office Interview",
    src: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=800&h=600",
    description: "Beautiful professional woman in business attire during a job interview in modern office setting. Features natural lighting and contemporary office environment."
  },
  {
    id: 2,
    title: "Option 2: Diverse Team Meeting with Professional Woman Leading",
    src: "https://images.unsplash.com/photo-1600880292203-757bb62b4baf?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=800&h=600",
    description: "Professional woman leading team discussion with laptops and modern workspace. Shows collaborative environment and leadership scenario."
  },
  {
    id: 3,
    title: "Option 3: Professional Woman at Computer - Assessment Environment",
    src: "https://images.unsplash.com/photo-1580894894513-541e068a3e2b?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=800&h=600",
    description: "Beautiful professional woman working on computer in modern office. Perfect for online assessment platform with clean workspace and technology focus."
  },
  {
    id: 4,
    title: "Option 4: Professional Interview Scene - Woman Candidate",
    src: "https://images.unsplash.com/photo-1556761175-b413da4baf72?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=800&h=600",
    description: "Professional woman as candidate in interview setting with recruiter. Shows authentic interview scenario in professional business environment."
  },
  {
    id: 5,
    title: "Option 5: Modern Office - Woman Professional with Team",
    src: "https://images.unsplash.com/photo-1521791136064-7986c2920216?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=800&h=600",
    description: "Professional woman in contemporary office environment with colleagues. Features modern workspace, collaborative atmosphere, and professional diversity."
  }
];

export default function ImagePreview() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-sky-50 to-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="mb-8">
          <Link href="/">
            <Button variant="outline" className="mb-4">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Landing Page
            </Button>
          </Link>
          <h1 className="text-3xl font-bold text-gray-900 mb-2">
            Professional Image Options for Landing Page
          </h1>
          <p className="text-lg text-gray-600">
            Choose your preferred professional image featuring beautiful women in business environments
          </p>
        </div>

        {/* Current Image */}
        <div className="mb-12">
          <h2 className="text-2xl font-semibold text-gray-900 mb-4">Current Image</h2>
          <Card>
            <CardHeader>
              <CardTitle>Current: Professional Testing Environment</CardTitle>
            </CardHeader>
            <CardContent>
              <img 
                src="https://images.unsplash.com/photo-1551434678-e076c223a692?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600"
                alt="Current professional testing environment"
                className="w-full h-64 object-cover rounded-lg shadow-lg"
              />
              <p className="text-gray-600 mt-3">
                Professional online testing environment with people working in modern office setting
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Image Options */}
        <div className="grid gap-8">
          <h2 className="text-2xl font-semibold text-gray-900 mb-4">New Image Options</h2>
          
          {imageOptions.map((option) => (
            <Card key={option.id} className="overflow-hidden">
              <CardHeader>
                <CardTitle className="text-sky-600">{option.title}</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid lg:grid-cols-2 gap-6">
                  <div>
                    <img 
                      src={option.src}
                      alt={option.title}
                      className="w-full h-64 object-cover rounded-lg shadow-lg"
                      onError={(e) => {
                        console.log(`Failed to load image: ${option.src}`);
                        e.currentTarget.src = "https://images.unsplash.com/photo-1551434678-e076c223a692?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600";
                      }}
                    />
                  </div>
                  <div className="flex flex-col justify-center">
                    <p className="text-gray-600 mb-4">{option.description}</p>
                    <div className="space-y-2">
                      <h4 className="font-semibold text-gray-900">Key Features:</h4>
                      <ul className="text-sm text-gray-600 space-y-1">
                        <li>• High-quality professional photography</li>
                        <li>• Beautiful women in authentic business settings</li>
                        <li>• Modern office environment</li>
                        <li>• Perfect for talent management platform</li>
                      </ul>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Instructions */}
        <div className="mt-12 bg-sky-50 border border-sky-200 rounded-lg p-6">
          <h3 className="text-lg font-semibold text-sky-800 mb-2">Instructions</h3>
          <p className="text-sky-700">
            Review all image options above and let me know which option you prefer (Option 1, 2, 3, 4, or 5). 
            I'll then implement your chosen image in the landing page hero section.
          </p>
        </div>
      </div>
    </div>
  );
}