import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import PlatformLayout from "@/components/layout/platform-layout";
import { platformConfigs } from "@/config/complete-navigation";
import { Brain, TrendingUp, Users, Target, BarChart3, Search, Filter } from "lucide-react";

export default function TalentIntelligence() {
  const config = platformConfigs.recruiter;

  const marketInsights = [
    {
      title: "Frontend Developer Demand",
      trend: "+15%",
      description: "High demand for React developers in your region",
      urgency: "High",
      salaryRange: "₹12-25 LPA"
    },
    {
      title: "Backend Engineer Supply",
      trend: "-8%",
      description: "Limited availability of senior Node.js developers",
      urgency: "Medium",
      salaryRange: "₹15-30 LPA"
    },
    {
      title: "DevOps Specialist Market",
      trend: "+22%",
      description: "Growing demand for cloud and containerization skills",
      urgency: "High",
      salaryRange: "₹18-35 LPA"
    }
  ];

  const talentMetrics = [
    { label: "Available Candidates", value: "12,847", change: "+5.2%" },
    { label: "Active Seekers", value: "3,426", change: "+8.1%" },
    { label: "Skill Match Rate", value: "73%", change: "+2.3%" },
    { label: "Response Rate", value: "34%", change: "-1.2%" }
  ];

  const skillTrends = [
    { skill: "React", demand: 92, growth: "+18%" },
    { skill: "Node.js", demand: 78, growth: "+12%" },
    { skill: "Python", demand: 85, growth: "+15%" },
    { skill: "AWS", demand: 67, growth: "+25%" },
    { skill: "TypeScript", demand: 71, growth: "+22%" }
  ];

  return (
    <PlatformLayout
      sidebarTitle={config.sidebarTitle}
      sidebarSubtitle={config.sidebarSubtitle}
      sidebarSections={config.sidebarSections}
      usageData={config.usageData}
    >
      <div className="max-w-6xl mx-auto px-6 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Talent Intelligence</h1>
          <p className="text-gray-600">Market insights and talent analytics to optimize your hiring strategy</p>
        </div>

        {/* Key Metrics */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          {talentMetrics.map((metric, index) => (
            <Card key={index}>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600">{metric.label}</p>
                    <p className="text-2xl font-bold">{metric.value}</p>
                    <p className={`text-sm ${metric.change.startsWith('+') ? 'text-green-600' : 'text-red-600'}`}>
                      {metric.change}
                    </p>
                  </div>
                  <Brain className="w-8 h-8 text-blue-500" />
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Market Insights */}
          <div>
            <h2 className="text-xl font-semibold mb-4">Market Insights</h2>
            <div className="space-y-4">
              {marketInsights.map((insight, index) => (
                <Card key={index}>
                  <CardHeader className="pb-3">
                    <div className="flex justify-between items-start">
                      <div>
                        <CardTitle className="text-lg">{insight.title}</CardTitle>
                        <CardDescription>{insight.description}</CardDescription>
                      </div>
                      <div className="text-right">
                        <Badge variant={insight.urgency === 'High' ? 'destructive' : 'secondary'}>
                          {insight.urgency}
                        </Badge>
                        <div className={`text-sm font-medium mt-1 ${
                          insight.trend.startsWith('+') ? 'text-green-600' : 'text-red-600'
                        }`}>
                          {insight.trend}
                        </div>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-gray-600">Salary Range:</span>
                      <span className="font-medium">{insight.salaryRange}</span>
                    </div>
                    <Button size="sm" className="mt-3">
                      <Search className="w-4 h-4 mr-2" />
                      Find Candidates
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>

          {/* Skill Trends */}
          <div>
            <h2 className="text-xl font-semibold mb-4">Trending Skills</h2>
            <Card>
              <CardHeader>
                <CardTitle>In-Demand Technologies</CardTitle>
                <CardDescription>Skills with highest market demand</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {skillTrends.map((skill, index) => (
                    <div key={index}>
                      <div className="flex justify-between items-center mb-2">
                        <span className="font-medium">{skill.skill}</span>
                        <div className="flex items-center space-x-2">
                          <span className="text-sm text-green-600">{skill.growth}</span>
                          <Badge variant="outline">{skill.demand}%</Badge>
                        </div>
                      </div>
                      <Progress value={skill.demand} className="h-2" />
                    </div>
                  ))}
                </div>
                <Button className="w-full mt-4">
                  <BarChart3 className="w-4 h-4 mr-2" />
                  View Full Report
                </Button>
              </CardContent>
            </Card>

            {/* Quick Actions */}
            <Card className="mt-6">
              <CardHeader>
                <CardTitle>Quick Insights</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <Button variant="outline" className="w-full justify-start">
                    <TrendingUp className="w-4 h-4 mr-2" />
                    Salary Benchmarking
                  </Button>
                  <Button variant="outline" className="w-full justify-start">
                    <Users className="w-4 h-4 mr-2" />
                    Competitor Analysis
                  </Button>
                  <Button variant="outline" className="w-full justify-start">
                    <Target className="w-4 h-4 mr-2" />
                    Sourcing Strategy
                  </Button>
                  <Button variant="outline" className="w-full justify-start">
                    <Filter className="w-4 h-4 mr-2" />
                    Market Filters
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </PlatformLayout>
  );
}