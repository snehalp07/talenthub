import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import PlatformLayout from "@/components/layout/platform-layout";
import { platformConfigs } from "@/config/navigation";
import { 
  Briefcase, 
  Search, 
  Filter, 
  MoreHorizontal, 
  Eye, 
  Edit, 
  Copy,
  Trash2,
  Plus,
  MapPin,
  Calendar,
  DollarSign,
  Users,
  Clock,
  TrendingUp,
  BarChart3,
  FileText,
  Share,
  PauseCircle,
  PlayCircle,
  AlertCircle
} from "lucide-react";

interface JobPosting {
  id: string;
  title: string;
  department: string;
  location: string;
  type: string;
  experience: string;
  salary: {
    min: number;
    max: number;
    currency: string;
  };
  status: string;
  applicants: number;
  views: number;
  datePosted: string;
  deadline: string;
  description: string;
  requirements: string[];
  benefits: string[];
  isRemote: boolean;
  urgency: string;
  hiringManager: string;
}

export default function RecruiterJobs() {
  const config = platformConfigs.recruiter;
  const { toast } = useToast();
  
  const [searchTerm, setSearchTerm] = useState("");
  const [filterStatus, setFilterStatus] = useState("all");
  const [filterType, setFilterType] = useState("all");
  const [sortBy, setSortBy] = useState("newest");
  const [selectedJobs, setSelectedJobs] = useState<string[]>([]);

  const { data: jobs = [], isLoading } = useQuery<JobPosting[]>({
    queryKey: ["/api/recruiter/jobs"],
    initialData: [
      {
        id: "1",
        title: "Senior Frontend Developer",
        department: "Engineering",
        location: "San Francisco, CA",
        type: "Full-time",
        experience: "5+ years",
        salary: { min: 120000, max: 160000, currency: "USD" },
        status: "active",
        applicants: 47,
        views: 234,
        datePosted: "2024-06-10",
        deadline: "2024-07-10",
        description: "We're looking for a senior frontend developer to join our growing team...",
        requirements: ["React", "TypeScript", "Redux", "CSS", "Testing"],
        benefits: ["Health Insurance", "401k", "Remote Work", "Equity"],
        isRemote: true,
        urgency: "high",
        hiringManager: "John Smith"
      },
      {
        id: "2",
        title: "Product Manager",
        department: "Product",
        location: "New York, NY",
        type: "Full-time",
        experience: "3-5 years",
        salary: { min: 100000, max: 140000, currency: "USD" },
        status: "active",
        applicants: 32,
        views: 189,
        datePosted: "2024-06-08",
        deadline: "2024-07-08",
        description: "Join our product team to drive strategy and execution...",
        requirements: ["Product Strategy", "Analytics", "Agile", "Communication"],
        benefits: ["Health Insurance", "401k", "Flexible Hours", "Learning Budget"],
        isRemote: false,
        urgency: "medium",
        hiringManager: "Sarah Johnson"
      },
      {
        id: "3",
        title: "Data Scientist",
        department: "Data",
        location: "Austin, TX",
        type: "Full-time",
        experience: "2-4 years",
        salary: { min: 90000, max: 130000, currency: "USD" },
        status: "paused",
        applicants: 28,
        views: 156,
        datePosted: "2024-06-05",
        deadline: "2024-07-05",
        description: "We need a data scientist to help us derive insights from our data...",
        requirements: ["Python", "SQL", "Machine Learning", "Statistics", "Visualization"],
        benefits: ["Health Insurance", "401k", "Professional Development"],
        isRemote: true,
        urgency: "low",
        hiringManager: "Michael Chen"
      }
    ]
  });

  const toggleJobStatus = useMutation({
    mutationFn: async ({ jobId, status }: { jobId: string; status: string }) => {
      return await apiRequest("PATCH", `/api/recruiter/jobs/${jobId}`, { status });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/recruiter/jobs"] });
      toast({
        title: "Job Updated",
        description: "Job status has been updated successfully",
      });
    }
  });

  const duplicateJob = useMutation({
    mutationFn: async (jobId: string) => {
      return await apiRequest("POST", `/api/recruiter/jobs/${jobId}/duplicate`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/recruiter/jobs"] });
      toast({
        title: "Job Duplicated",
        description: "Job has been duplicated successfully",
      });
    }
  });

  const deleteJob = useMutation({
    mutationFn: async (jobId: string) => {
      return await apiRequest("DELETE", `/api/recruiter/jobs/${jobId}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/recruiter/jobs"] });
      toast({
        title: "Job Deleted",
        description: "Job has been deleted successfully",
      });
    }
  });

  const filteredJobs = jobs.filter(job => {
    const matchesSearch = job.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         job.department.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = filterStatus === "all" || job.status === filterStatus;
    const matchesType = filterType === "all" || job.type === filterType;
    
    return matchesSearch && matchesStatus && matchesType;
  });

  const sortedJobs = [...filteredJobs].sort((a, b) => {
    switch (sortBy) {
      case "applicants":
        return b.applicants - a.applicants;
      case "views":
        return b.views - a.views;
      case "salary":
        return b.salary.max - a.salary.max;
      default:
        return new Date(b.datePosted).getTime() - new Date(a.datePosted).getTime();
    }
  });

  const getStatusColor = (status: string) => {
    const colors = {
      active: "bg-green-100 text-green-800",
      paused: "bg-yellow-100 text-yellow-800",
      closed: "bg-red-100 text-red-800",
      draft: "bg-gray-100 text-gray-800"
    };
    return colors[status as keyof typeof colors] || colors.active;
  };

  const getUrgencyColor = (urgency: string) => {
    const colors = {
      high: "bg-red-100 text-red-800",
      medium: "bg-yellow-100 text-yellow-800",
      low: "bg-green-100 text-green-800"
    };
    return colors[urgency as keyof typeof colors] || colors.medium;
  };

  const formatSalary = (salary: { min: number; max: number; currency: string }) => {
    const format = (amount: number) => {
      if (amount >= 1000000) return `${(amount / 1000000).toFixed(1)}M`;
      if (amount >= 1000) return `${(amount / 1000).toFixed(0)}K`;
      return amount.toString();
    };
    return `$${format(salary.min)} - $${format(salary.max)}`;
  };

  const handleToggleStatus = (jobId: string, currentStatus: string) => {
    const newStatus = currentStatus === "active" ? "paused" : "active";
    toggleJobStatus.mutate({ jobId, status: newStatus });
  };

  const handleDuplicate = (jobId: string) => {
    duplicateJob.mutate(jobId);
  };

  const handleDelete = (jobId: string) => {
    if (confirm("Are you sure you want to delete this job posting?")) {
      deleteJob.mutate(jobId);
    }
  };

  const handleBulkAction = (action: string) => {
    toast({
      title: `Bulk ${action}`,
      description: `${action} applied to ${selectedJobs.length} jobs`,
    });
    setSelectedJobs([]);
  };

  return (
    <PlatformLayout
      sidebarTitle={config.sidebarTitle}
      sidebarSubtitle={config.sidebarSubtitle}
      sidebarSections={config.sidebarSections}
      usageData={config.usageData}
    >
      <div className="max-w-7xl mx-auto px-6 py-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h2 className="text-3xl font-bold text-neutral-600 mb-2">Job Postings</h2>
            <p className="text-neutral-500">Create, manage, and track your job postings and applications.</p>
          </div>
          <div className="flex items-center space-x-3">
            <Button variant="outline">
              <FileText className="w-4 h-4 mr-2" />
              Templates
            </Button>
            <Button>
              <Plus className="w-4 h-4 mr-2" />
              Post New Job
            </Button>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-neutral-500">Active Jobs</p>
                  <p className="text-3xl font-bold text-neutral-600">
                    {jobs.filter(job => job.status === "active").length}
                  </p>
                </div>
                <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                  <Briefcase className="w-6 h-6 text-green-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-neutral-500">Total Applicants</p>
                  <p className="text-3xl font-bold text-neutral-600">
                    {jobs.reduce((sum, job) => sum + job.applicants, 0)}
                  </p>
                </div>
                <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                  <Users className="w-6 h-6 text-blue-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-neutral-500">Total Views</p>
                  <p className="text-3xl font-bold text-neutral-600">
                    {jobs.reduce((sum, job) => sum + job.views, 0)}
                  </p>
                </div>
                <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
                  <Eye className="w-6 h-6 text-purple-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-neutral-500">Avg. Applications</p>
                  <p className="text-3xl font-bold text-neutral-600">
                    {Math.round(jobs.reduce((sum, job) => sum + job.applicants, 0) / jobs.length)}
                  </p>
                </div>
                <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center">
                  <TrendingUp className="w-6 h-6 text-orange-600" />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Search and Filters */}
        <Card className="mb-6">
          <CardContent className="p-6">
            <div className="flex flex-col lg:flex-row gap-4">
              <div className="flex-1">
                <div className="relative">
                  <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Search jobs by title, department, or location..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                  />
                </div>
              </div>
              <div className="flex gap-3">
                <Select value={filterStatus} onValueChange={setFilterStatus}>
                  <SelectTrigger className="w-40">
                    <SelectValue placeholder="Status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Status</SelectItem>
                    <SelectItem value="active">Active</SelectItem>
                    <SelectItem value="paused">Paused</SelectItem>
                    <SelectItem value="closed">Closed</SelectItem>
                    <SelectItem value="draft">Draft</SelectItem>
                  </SelectContent>
                </Select>
                
                <Select value={filterType} onValueChange={setFilterType}>
                  <SelectTrigger className="w-40">
                    <SelectValue placeholder="Type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Types</SelectItem>
                    <SelectItem value="Full-time">Full-time</SelectItem>
                    <SelectItem value="Part-time">Part-time</SelectItem>
                    <SelectItem value="Contract">Contract</SelectItem>
                    <SelectItem value="Internship">Internship</SelectItem>
                  </SelectContent>
                </Select>

                <Select value={sortBy} onValueChange={setSortBy}>
                  <SelectTrigger className="w-40">
                    <SelectValue placeholder="Sort by" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="newest">Newest</SelectItem>
                    <SelectItem value="applicants">Most Applicants</SelectItem>
                    <SelectItem value="views">Most Views</SelectItem>
                    <SelectItem value="salary">Highest Salary</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Bulk Actions */}
        {selectedJobs.length > 0 && (
          <Card className="mb-6 border-blue-200 bg-blue-50">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">
                  {selectedJobs.length} jobs selected
                </span>
                <div className="flex items-center space-x-2">
                  <Button size="sm" variant="outline" onClick={() => handleBulkAction("pause")}>
                    <PauseCircle className="w-3 h-3 mr-1" />
                    Pause
                  </Button>
                  <Button size="sm" variant="outline" onClick={() => handleBulkAction("activate")}>
                    <PlayCircle className="w-3 h-3 mr-1" />
                    Activate
                  </Button>
                  <Button size="sm" variant="outline" onClick={() => handleBulkAction("export")}>
                    <FileText className="w-3 h-3 mr-1" />
                    Export
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Jobs List */}
        <div className="space-y-4">
          {isLoading ? (
            <div className="text-center py-12">
              <Briefcase className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
              <p className="text-muted-foreground">Loading job postings...</p>
            </div>
          ) : sortedJobs.length === 0 ? (
            <Card>
              <CardContent className="p-12 text-center">
                <Briefcase className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
                <h3 className="text-lg font-semibold mb-2">No Jobs Found</h3>
                <p className="text-muted-foreground mb-4">
                  Try adjusting your search criteria or create your first job posting.
                </p>
                <Button>
                  <Plus className="w-4 h-4 mr-2" />
                  Post First Job
                </Button>
              </CardContent>
            </Card>
          ) : (
            sortedJobs.map((job) => (
              <Card key={job.id} className="hover:shadow-md transition-shadow">
                <CardContent className="p-6">
                  <div className="flex items-start justify-between">
                    <div className="flex items-start space-x-4 flex-1">
                      <input
                        type="checkbox"
                        className="mt-1"
                        checked={selectedJobs.includes(job.id)}
                        onChange={(e) => {
                          if (e.target.checked) {
                            setSelectedJobs([...selectedJobs, job.id]);
                          } else {
                            setSelectedJobs(selectedJobs.filter(id => id !== job.id));
                          }
                        }}
                      />
                      
                      <div className="flex-1">
                        <div className="flex items-center space-x-3 mb-2">
                          <h3 className="text-lg font-semibold text-neutral-600">{job.title}</h3>
                          <Badge className={getStatusColor(job.status)}>
                            {job.status}
                          </Badge>
                          <Badge className={getUrgencyColor(job.urgency)}>
                            {job.urgency} priority
                          </Badge>
                          {job.isRemote && (
                            <Badge variant="outline" className="bg-blue-100 text-blue-600">
                              Remote
                            </Badge>
                          )}
                        </div>
                        
                        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 mb-4">
                          <div>
                            <p className="text-sm font-medium text-neutral-600">{job.department}</p>
                            <div className="flex items-center text-sm text-neutral-500 mt-1">
                              <MapPin className="w-3 h-3 mr-1" />
                              {job.location}
                            </div>
                            <div className="flex items-center text-sm text-neutral-500 mt-1">
                              <Clock className="w-3 h-3 mr-1" />
                              {job.type} • {job.experience}
                            </div>
                          </div>
                          
                          <div>
                            <div className="flex items-center text-sm text-neutral-500 mb-1">
                              <DollarSign className="w-3 h-3 mr-1" />
                              Salary Range
                            </div>
                            <p className="font-medium text-neutral-600">{formatSalary(job.salary)}</p>
                            <p className="text-sm text-neutral-500 mt-1">Hiring Manager: {job.hiringManager}</p>
                          </div>
                          
                          <div>
                            <div className="grid grid-cols-2 gap-4 text-sm">
                              <div>
                                <p className="text-neutral-500">Applicants</p>
                                <p className="font-medium text-blue-600">{job.applicants}</p>
                              </div>
                              <div>
                                <p className="text-neutral-500">Views</p>
                                <p className="font-medium">{job.views}</p>
                              </div>
                              <div>
                                <p className="text-neutral-500">Posted</p>
                                <p className="font-medium">{new Date(job.datePosted).toLocaleDateString()}</p>
                              </div>
                              <div>
                                <p className="text-neutral-500">Deadline</p>
                                <p className="font-medium">{new Date(job.deadline).toLocaleDateString()}</p>
                              </div>
                            </div>
                          </div>
                        </div>
                        
                        <div className="flex items-center space-x-4 text-sm text-neutral-500">
                          <div className="flex items-center">
                            <Users className="w-3 h-3 mr-1" />
                            {job.applicants} applications
                          </div>
                          <div className="flex items-center">
                            <Eye className="w-3 h-3 mr-1" />
                            {job.views} views
                          </div>
                          <div className="flex items-center">
                            <Calendar className="w-3 h-3 mr-1" />
                            {Math.ceil((new Date(job.deadline).getTime() - new Date().getTime()) / (1000 * 60 * 60 * 24))} days left
                          </div>
                        </div>
                      </div>
                    </div>
                    
                    <div className="flex items-center space-x-2 ml-4">
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => handleToggleStatus(job.id, job.status)}
                      >
                        {job.status === "active" ? (
                          <PauseCircle className="w-4 h-4" />
                        ) : (
                          <PlayCircle className="w-4 h-4" />
                        )}
                      </Button>
                      
                      <Button size="sm" variant="outline">
                        <Edit className="w-4 h-4" />
                      </Button>
                      
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => handleDuplicate(job.id)}
                      >
                        <Copy className="w-4 h-4" />
                      </Button>
                      
                      <Button size="sm" variant="outline">
                        <Share className="w-4 h-4" />
                      </Button>
                      
                      <Button size="sm" variant="outline">
                        <BarChart3 className="w-4 h-4" />
                      </Button>
                      
                      <Button size="sm" variant="outline">
                        <MoreHorizontal className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))
          )}
        </div>

        {/* Pagination */}
        <div className="flex items-center justify-between mt-8">
          <p className="text-sm text-neutral-500">
            Showing {sortedJobs.length} of {jobs.length} job postings
          </p>
          <div className="flex items-center space-x-2">
            <Button variant="outline" size="sm" disabled>
              Previous
            </Button>
            <Button variant="outline" size="sm" className="bg-blue-50">
              1
            </Button>
            <Button variant="outline" size="sm">
              2
            </Button>
            <Button variant="outline" size="sm">
              Next
            </Button>
          </div>
        </div>
      </div>
    </PlatformLayout>
  );
}