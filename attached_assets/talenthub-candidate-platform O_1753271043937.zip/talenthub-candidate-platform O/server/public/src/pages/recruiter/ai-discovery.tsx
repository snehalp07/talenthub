import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import PlatformLayout from "@/components/layout/platform-layout";
import { platformConfigs } from "@/config/complete-navigation";
import { Brain, Search, Filter, Star, MapPin, Clock, Briefcase } from "lucide-react";

export default function AIDiscovery() {
  const config = platformConfigs.recruiter;

  const aiSuggestions = [
    {
      name: "Sarah Chen",
      role: "Senior React Developer",
      match: 94,
      location: "Bangalore",
      experience: "5 years",
      skills: ["React", "TypeScript", "Node.js"],
      availability: "Immediately",
      salary: "₹18-22 LPA",
      reason: "Perfect match for your Frontend Lead position requirements"
    },
    {
      name: "Rahul Kumar",
      role: "Full Stack Engineer",
      match: 89,
      location: "Mumbai",
      experience: "4 years",
      skills: ["Python", "Django", "React"],
      availability: "2 weeks",
      salary: "₹15-20 LPA",
      reason: "Strong backend experience with frontend capabilities"
    },
    {
      name: "Priya Singh",
      role: "DevOps Specialist",
      match: 92,
      location: "Pune",
      experience: "6 years",
      skills: ["AWS", "Docker", "Kubernetes"],
      availability: "1 month",
      salary: "₹20-28 LPA",
      reason: "Exceptional cloud infrastructure expertise"
    }
  ];

  const searchFilters = [
    { label: "Experience", options: ["0-2 years", "3-5 years", "5+ years"] },
    { label: "Location", options: ["Bangalore", "Mumbai", "Delhi", "Remote"] },
    { label: "Salary Range", options: ["10-15 LPA", "15-25 LPA", "25+ LPA"] },
    { label: "Availability", options: ["Immediate", "Within 2 weeks", "Within 1 month"] }
  ];

  return (
    <PlatformLayout
      sidebarTitle={config.sidebarTitle}
      sidebarSubtitle={config.sidebarSubtitle}
      sidebarSections={config.sidebarSections}
      usageData={config.usageData}
    >
      <div className="max-w-6xl mx-auto px-6 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">AI Discovery</h1>
          <p className="text-gray-600">Let AI find the perfect candidates for your open positions</p>
        </div>

        {/* Search Section */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="flex items-center">
              <Brain className="w-5 h-5 mr-2" />
              AI-Powered Candidate Search
            </CardTitle>
            <CardDescription>
              Describe your ideal candidate and let our AI find the best matches
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex gap-4">
                <Input 
                  placeholder="e.g., Senior React developer with 5+ years experience..."
                  className="flex-1"
                />
                <Button>
                  <Search className="w-4 h-4 mr-2" />
                  Search
                </Button>
              </div>
              
              <div className="flex flex-wrap gap-2">
                {searchFilters.map((filter, index) => (
                  <Button key={index} variant="outline" size="sm">
                    <Filter className="w-4 h-4 mr-2" />
                    {filter.label}
                  </Button>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>

        {/* AI Suggestions */}
        <div>
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-xl font-semibold">AI Recommendations</h2>
            <Badge variant="outline">
              <Brain className="w-4 h-4 mr-1" />
              3 Perfect Matches Found
            </Badge>
          </div>

          <div className="space-y-6">
            {aiSuggestions.map((candidate, index) => (
              <Card key={index} className="border-l-4 border-l-blue-500">
                <CardHeader>
                  <div className="flex justify-between items-start">
                    <div>
                      <CardTitle className="text-lg">{candidate.name}</CardTitle>
                      <CardDescription>{candidate.role}</CardDescription>
                    </div>
                    <div className="text-right">
                      <div className="flex items-center mb-2">
                        <Star className="w-4 h-4 text-yellow-500 mr-1" />
                        <span className="font-bold text-lg">{candidate.match}%</span>
                        <span className="text-sm text-gray-500 ml-1">match</span>
                      </div>
                      <Badge variant="default">Top Pick</Badge>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <p className="text-sm text-blue-700 bg-blue-50 p-3 rounded-lg">
                      <Brain className="w-4 h-4 inline mr-2" />
                      {candidate.reason}
                    </p>
                    
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                      <div className="flex items-center">
                        <MapPin className="w-4 h-4 mr-2 text-gray-500" />
                        {candidate.location}
                      </div>
                      <div className="flex items-center">
                        <Briefcase className="w-4 h-4 mr-2 text-gray-500" />
                        {candidate.experience}
                      </div>
                      <div className="flex items-center">
                        <Clock className="w-4 h-4 mr-2 text-gray-500" />
                        {candidate.availability}
                      </div>
                      <div className="font-medium text-green-600">
                        {candidate.salary}
                      </div>
                    </div>

                    <div>
                      <span className="text-sm text-gray-600 mb-2 block">Key Skills:</span>
                      <div className="flex flex-wrap gap-1">
                        {candidate.skills.map((skill, i) => (
                          <Badge key={i} variant="outline" className="text-xs">
                            {skill}
                          </Badge>
                        ))}
                      </div>
                    </div>

                    <div className="flex gap-2 pt-2">
                      <Button size="sm">View Profile</Button>
                      <Button size="sm" variant="outline">Send Message</Button>
                      <Button size="sm" variant="outline">Add to Pipeline</Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* AI Insights */}
        <Card className="mt-8">
          <CardHeader>
            <CardTitle>AI Insights</CardTitle>
            <CardDescription>Recommendations to improve your search results</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="flex items-start space-x-3">
                <div className="w-2 h-2 bg-blue-500 rounded-full mt-2"></div>
                <div>
                  <p className="font-medium">Expand salary range</p>
                  <p className="text-sm text-gray-600">Consider increasing budget by 10-15% to access premium candidates</p>
                </div>
              </div>
              <div className="flex items-start space-x-3">
                <div className="w-2 h-2 bg-green-500 rounded-full mt-2"></div>
                <div>
                  <p className="font-medium">Remote-first approach</p>
                  <p className="text-sm text-gray-600">Adding remote work option could increase candidate pool by 40%</p>
                </div>
              </div>
              <div className="flex items-start space-x-3">
                <div className="w-2 h-2 bg-yellow-500 rounded-full mt-2"></div>
                <div>
                  <p className="font-medium">Skill optimization</p>
                  <p className="text-sm text-gray-600">Focus on core skills rather than nice-to-have requirements</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </PlatformLayout>
  );
}