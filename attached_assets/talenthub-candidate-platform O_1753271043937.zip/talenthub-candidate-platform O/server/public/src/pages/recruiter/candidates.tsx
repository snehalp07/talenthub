import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import PlatformLayout from "@/components/layout/platform-layout";
import { platformConfigs } from "@/config/navigation";
import { 
  Users, 
  Search, 
  Filter, 
  MoreHorizontal, 
  Eye, 
  MessageSquare, 
  Star, 
  StarOff,
  Download,
  Mail,
  Phone,
  MapPin,
  Calendar,
  Briefcase,
  GraduationCap,
  Award,
  CheckCircle,
  XCircle,
  Clock,
  TrendingUp,
  Plus
} from "lucide-react";

interface Candidate {
  id: string;
  name: string;
  email: string;
  phone: string;
  location: string;
  experience: string;
  currentRole: string;
  skills: string[];
  education: string;
  status: string;
  rating: number;
  appliedJobs: number;
  lastActivity: string;
  profileViews: number;
  responseRate: string;
  avatar?: string;
  isFavorite: boolean;
  matchScore: number;
}

export default function RecruiterCandidates() {
  const config = platformConfigs.recruiter;
  const { toast } = useToast();
  
  const [searchTerm, setSearchTerm] = useState("");
  const [filterStatus, setFilterStatus] = useState("all");
  const [filterExperience, setFilterExperience] = useState("all");
  const [sortBy, setSortBy] = useState("newest");
  const [selectedCandidates, setSelectedCandidates] = useState<string[]>([]);

  const { data: candidates = [], isLoading } = useQuery<Candidate[]>({
    queryKey: ["/api/recruiter/candidates"],
    initialData: [
      {
        id: "1",
        name: "Sarah Johnson",
        email: "sarah.johnson@email.com",
        phone: "+1 (555) 123-4567",
        location: "San Francisco, CA",
        experience: "5-7 years",
        currentRole: "Senior Frontend Developer",
        skills: ["React", "TypeScript", "Node.js", "Python", "AWS"],
        education: "BS Computer Science, Stanford University",
        status: "active",
        rating: 4.8,
        appliedJobs: 12,
        lastActivity: "2 hours ago",
        profileViews: 89,
        responseRate: "95%",
        isFavorite: true,
        matchScore: 92
      },
      {
        id: "2",
        name: "Michael Chen",
        email: "michael.chen@email.com",
        phone: "+1 (555) 987-6543",
        location: "New York, NY",
        experience: "3-5 years",
        currentRole: "Full Stack Developer",
        skills: ["JavaScript", "Python", "Django", "PostgreSQL", "Docker"],
        education: "MS Software Engineering, MIT",
        status: "interviewing",
        rating: 4.6,
        appliedJobs: 8,
        lastActivity: "1 day ago",
        profileViews: 67,
        responseRate: "88%",
        isFavorite: false,
        matchScore: 87
      },
      {
        id: "3",
        name: "Emily Rodriguez",
        email: "emily.rodriguez@email.com",
        phone: "+1 (555) 456-7890",
        location: "Austin, TX",
        experience: "2-3 years",
        currentRole: "Backend Developer",
        skills: ["Java", "Spring Boot", "Microservices", "Kubernetes", "MongoDB"],
        education: "BS Computer Engineering, UT Austin",
        status: "hired",
        rating: 4.9,
        appliedJobs: 15,
        lastActivity: "3 days ago",
        profileViews: 134,
        responseRate: "92%",
        isFavorite: true,
        matchScore: 94
      }
    ]
  });

  const favoriteMutation = useMutation({
    mutationFn: async ({ candidateId, isFavorite }: { candidateId: string; isFavorite: boolean }) => {
      return await apiRequest("POST", `/api/recruiter/candidates/${candidateId}/favorite`, { isFavorite });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/recruiter/candidates"] });
      toast({
        title: "Success",
        description: "Candidate favorite status updated",
      });
    }
  });

  const messageMutation = useMutation({
    mutationFn: async (candidateId: string) => {
      return await apiRequest("POST", `/api/recruiter/candidates/${candidateId}/message`);
    },
    onSuccess: () => {
      toast({
        title: "Message Sent",
        description: "Your message has been sent to the candidate",
      });
    }
  });

  const filteredCandidates = candidates.filter(candidate => {
    const matchesSearch = candidate.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         candidate.skills.some(skill => skill.toLowerCase().includes(searchTerm.toLowerCase()));
    const matchesStatus = filterStatus === "all" || candidate.status === filterStatus;
    const matchesExperience = filterExperience === "all" || candidate.experience === filterExperience;
    
    return matchesSearch && matchesStatus && matchesExperience;
  });

  const sortedCandidates = [...filteredCandidates].sort((a, b) => {
    switch (sortBy) {
      case "rating":
        return b.rating - a.rating;
      case "match":
        return b.matchScore - a.matchScore;
      case "experience":
        return b.appliedJobs - a.appliedJobs;
      default:
        return new Date(b.lastActivity).getTime() - new Date(a.lastActivity).getTime();
    }
  });

  const getStatusColor = (status: string) => {
    const colors = {
      active: "bg-green-100 text-green-800",
      interviewing: "bg-blue-100 text-blue-800",
      hired: "bg-purple-100 text-purple-800",
      declined: "bg-red-100 text-red-800",
      pending: "bg-yellow-100 text-yellow-800"
    };
    return colors[status as keyof typeof colors] || colors.active;
  };

  const handleFavorite = (candidateId: string, isFavorite: boolean) => {
    favoriteMutation.mutate({ candidateId, isFavorite: !isFavorite });
  };

  const handleMessage = (candidateId: string) => {
    messageMutation.mutate(candidateId);
  };

  const handleBulkAction = (action: string) => {
    toast({
      title: `Bulk ${action}`,
      description: `${action} applied to ${selectedCandidates.length} candidates`,
    });
    setSelectedCandidates([]);
  };

  return (
    <PlatformLayout
      sidebarTitle={config.sidebarTitle}
      sidebarSubtitle={config.sidebarSubtitle}
      sidebarSections={config.sidebarSections}
      usageData={config.usageData}
    >
      <div className="max-w-7xl mx-auto px-6 py-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h2 className="text-3xl font-bold text-neutral-600 mb-2">Candidate Management</h2>
            <p className="text-neutral-500">Discover, evaluate, and manage your talent pipeline.</p>
          </div>
          <div className="flex items-center space-x-3">
            <Button variant="outline">
              <Download className="w-4 h-4 mr-2" />
              Export
            </Button>
            <Button>
              <Plus className="w-4 h-4 mr-2" />
              Add Candidate
            </Button>
          </div>
        </div>

        {/* Search and Filters */}
        <Card className="mb-6">
          <CardContent className="p-6">
            <div className="flex flex-col lg:flex-row gap-4">
              <div className="flex-1">
                <div className="relative">
                  <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Search candidates by name, skills, or location..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                  />
                </div>
              </div>
              <div className="flex gap-3">
                <Select value={filterStatus} onValueChange={setFilterStatus}>
                  <SelectTrigger className="w-40">
                    <SelectValue placeholder="Status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Status</SelectItem>
                    <SelectItem value="active">Active</SelectItem>
                    <SelectItem value="interviewing">Interviewing</SelectItem>
                    <SelectItem value="hired">Hired</SelectItem>
                    <SelectItem value="declined">Declined</SelectItem>
                  </SelectContent>
                </Select>
                
                <Select value={filterExperience} onValueChange={setFilterExperience}>
                  <SelectTrigger className="w-40">
                    <SelectValue placeholder="Experience" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Experience</SelectItem>
                    <SelectItem value="0-2 years">0-2 years</SelectItem>
                    <SelectItem value="2-3 years">2-3 years</SelectItem>
                    <SelectItem value="3-5 years">3-5 years</SelectItem>
                    <SelectItem value="5-7 years">5-7 years</SelectItem>
                    <SelectItem value="7+ years">7+ years</SelectItem>
                  </SelectContent>
                </Select>

                <Select value={sortBy} onValueChange={setSortBy}>
                  <SelectTrigger className="w-40">
                    <SelectValue placeholder="Sort by" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="newest">Newest</SelectItem>
                    <SelectItem value="rating">Rating</SelectItem>
                    <SelectItem value="match">Match Score</SelectItem>
                    <SelectItem value="experience">Experience</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Bulk Actions */}
        {selectedCandidates.length > 0 && (
          <Card className="mb-6 border-blue-200 bg-blue-50">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">
                  {selectedCandidates.length} candidates selected
                </span>
                <div className="flex items-center space-x-2">
                  <Button size="sm" variant="outline" onClick={() => handleBulkAction("message")}>
                    <MessageSquare className="w-3 h-3 mr-1" />
                    Message All
                  </Button>
                  <Button size="sm" variant="outline" onClick={() => handleBulkAction("favorite")}>
                    <Star className="w-3 h-3 mr-1" />
                    Add to Favorites
                  </Button>
                  <Button size="sm" variant="outline" onClick={() => handleBulkAction("export")}>
                    <Download className="w-3 h-3 mr-1" />
                    Export
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Candidates List */}
        <div className="space-y-4">
          {isLoading ? (
            <div className="text-center py-12">
              <Users className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
              <p className="text-muted-foreground">Loading candidates...</p>
            </div>
          ) : sortedCandidates.length === 0 ? (
            <Card>
              <CardContent className="p-12 text-center">
                <Users className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
                <h3 className="text-lg font-semibold mb-2">No Candidates Found</h3>
                <p className="text-muted-foreground mb-4">
                  Try adjusting your search criteria or add new candidates to your pipeline.
                </p>
                <Button>
                  <Plus className="w-4 h-4 mr-2" />
                  Add First Candidate
                </Button>
              </CardContent>
            </Card>
          ) : (
            sortedCandidates.map((candidate) => (
              <Card key={candidate.id} className="hover:shadow-md transition-shadow">
                <CardContent className="p-6">
                  <div className="flex items-start justify-between">
                    <div className="flex items-start space-x-4 flex-1">
                      <input
                        type="checkbox"
                        className="mt-1"
                        checked={selectedCandidates.includes(candidate.id)}
                        onChange={(e) => {
                          if (e.target.checked) {
                            setSelectedCandidates([...selectedCandidates, candidate.id]);
                          } else {
                            setSelectedCandidates(selectedCandidates.filter(id => id !== candidate.id));
                          }
                        }}
                      />
                      
                      <Avatar className="h-12 w-12">
                        <AvatarFallback className="bg-blue-100 text-blue-600">
                          {candidate.name.split(' ').map(n => n[0]).join('')}
                        </AvatarFallback>
                      </Avatar>
                      
                      <div className="flex-1">
                        <div className="flex items-center space-x-3 mb-2">
                          <h3 className="text-lg font-semibold text-neutral-600">{candidate.name}</h3>
                          <Badge className={getStatusColor(candidate.status)}>
                            {candidate.status}
                          </Badge>
                          <div className="flex items-center space-x-1">
                            <Star className="w-4 h-4 text-yellow-400 fill-current" />
                            <span className="text-sm font-medium">{candidate.rating}</span>
                          </div>
                          <Badge variant="outline" className="bg-green-100 text-green-600">
                            {candidate.matchScore}% match
                          </Badge>
                        </div>
                        
                        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 mb-4">
                          <div>
                            <p className="text-sm font-medium text-neutral-600">{candidate.currentRole}</p>
                            <div className="flex items-center text-sm text-neutral-500 mt-1">
                              <MapPin className="w-3 h-3 mr-1" />
                              {candidate.location}
                            </div>
                            <div className="flex items-center text-sm text-neutral-500 mt-1">
                              <Briefcase className="w-3 h-3 mr-1" />
                              {candidate.experience}
                            </div>
                          </div>
                          
                          <div>
                            <p className="text-sm font-medium text-neutral-600 mb-2">Skills</p>
                            <div className="flex flex-wrap gap-1">
                              {candidate.skills.slice(0, 3).map((skill, index) => (
                                <Badge key={index} variant="outline" className="text-xs">
                                  {skill}
                                </Badge>
                              ))}
                              {candidate.skills.length > 3 && (
                                <Badge variant="outline" className="text-xs">
                                  +{candidate.skills.length - 3} more
                                </Badge>
                              )}
                            </div>
                          </div>
                          
                          <div>
                            <div className="grid grid-cols-2 gap-4 text-sm">
                              <div>
                                <p className="text-neutral-500">Applied Jobs</p>
                                <p className="font-medium">{candidate.appliedJobs}</p>
                              </div>
                              <div>
                                <p className="text-neutral-500">Response Rate</p>
                                <p className="font-medium">{candidate.responseRate}</p>
                              </div>
                              <div>
                                <p className="text-neutral-500">Profile Views</p>
                                <p className="font-medium">{candidate.profileViews}</p>
                              </div>
                              <div>
                                <p className="text-neutral-500">Last Activity</p>
                                <p className="font-medium">{candidate.lastActivity}</p>
                              </div>
                            </div>
                          </div>
                        </div>
                        
                        <div className="flex items-center text-sm text-neutral-500">
                          <GraduationCap className="w-3 h-3 mr-1" />
                          {candidate.education}
                        </div>
                      </div>
                    </div>
                    
                    <div className="flex items-center space-x-2 ml-4">
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => handleFavorite(candidate.id, candidate.isFavorite)}
                      >
                        {candidate.isFavorite ? (
                          <Star className="w-4 h-4 text-yellow-400 fill-current" />
                        ) : (
                          <StarOff className="w-4 h-4" />
                        )}
                      </Button>
                      
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => handleMessage(candidate.id)}
                      >
                        <MessageSquare className="w-4 h-4" />
                      </Button>
                      
                      <Button size="sm" variant="outline">
                        <Eye className="w-4 h-4" />
                      </Button>
                      
                      <Button size="sm" variant="outline">
                        <MoreHorizontal className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))
          )}
        </div>

        {/* Pagination */}
        <div className="flex items-center justify-between mt-8">
          <p className="text-sm text-neutral-500">
            Showing {sortedCandidates.length} of {candidates.length} candidates
          </p>
          <div className="flex items-center space-x-2">
            <Button variant="outline" size="sm" disabled>
              Previous
            </Button>
            <Button variant="outline" size="sm" className="bg-blue-50">
              1
            </Button>
            <Button variant="outline" size="sm">
              2
            </Button>
            <Button variant="outline" size="sm">
              3
            </Button>
            <Button variant="outline" size="sm">
              Next
            </Button>
          </div>
        </div>
      </div>
    </PlatformLayout>
  );
}