import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import PlatformLayout from "@/components/layout/platform-layout";
import { platformConfigs } from "@/config/navigation";
import { 
  BarChart3, 
  Users, 
  FileText, 
  TrendingUp, 
  Brain, 
  Award, 
  Briefcase, 
  Clock, 
  CheckCircle, 
  Target, 
  Star, 
  MapPin,
  Calendar,
  DollarSign,
  Send,
  Eye,
  ArrowRight,
  Play,
  BookOpen,
  Trophy,
  Zap,
  Filter,
  Heart,
  Building2,
  TrendingDown,
  UserCheck,
  MessageSquare,
  PhoneCall,
  Mail,
  Search,
  Plus
} from "lucide-react";

export default function RecruiterDashboard() {
  const config = platformConfigs.recruiter;

  // Hiring Pipeline Data
  const pipelineStages = [
    { stage: "Applied", count: 156, color: "bg-blue-500", percentage: 100 },
    { stage: "Screening", count: 89, color: "bg-yellow-500", percentage: 57 },
    { stage: "Interview", count: 34, color: "bg-purple-500", percentage: 22 },
    { stage: "Offer", count: 12, color: "bg-green-500", percentage: 8 }
  ];

  // Top Job Postings Performance
  const jobPostings = [
    { 
      title: "Senior Full Stack Developer", 
      applications: 45, 
      views: 234, 
      posted: "3 days ago",
      status: "Active",
      budget: "$120k - $150k"
    },
    { 
      title: "Product Manager", 
      applications: 38, 
      views: 189, 
      posted: "1 week ago",
      status: "Active",
      budget: "$110k - $140k"
    },
    { 
      title: "UX Designer", 
      applications: 29, 
      views: 156, 
      posted: "5 days ago",
      status: "Active",
      budget: "$90k - $120k"
    }
  ];

  // Team Performance Metrics
  const teamMetrics = [
    { name: "Interviews Scheduled", value: 85, target: 100, color: "bg-sky-500" },
    { name: "Offers Extended", value: 12, target: 15, color: "bg-green-500" },
    { name: "Response Rate", value: 78, target: 80, color: "bg-purple-500" },
    { name: "Time to Hire", value: 18, target: 14, color: "bg-orange-500", unit: "days" }
  ];

  // Candidate Pool Analytics
  const candidateData = [
    { skill: "JavaScript", count: 127, trend: "up" },
    { skill: "React", count: 89, trend: "up" },
    { skill: "Python", count: 76, trend: "down" },
    { skill: "Node.js", count: 64, trend: "up" },
    { skill: "AWS", count: 52, trend: "up" }
  ];

  // Top Candidates
  const topCandidates = [
    {
      id: 1,
      name: "Sarah Johnson",
      title: "Senior Full Stack Developer",
      experience: "7 years",
      location: "San Francisco, CA",
      match: 96,
      salary: "$140k",
      avatar: "SJ",
      skills: ["React", "Node.js", "AWS"],
      status: "Interview Scheduled"
    },
    {
      id: 2,
      name: "Michael Chen",
      title: "DevOps Engineer",
      experience: "5 years",
      location: "Seattle, WA",
      match: 94,
      salary: "$125k",
      avatar: "MC",
      skills: ["Docker", "Kubernetes", "Python"],
      status: "Screening"
    },
    {
      id: 3,
      name: "Emily Rodriguez",
      title: "Product Manager",
      experience: "6 years",
      location: "Austin, TX",
      match: 91,
      salary: "$130k",
      avatar: "ER",
      skills: ["Strategy", "Analytics", "Agile"],
      status: "Offer Pending"
    }
  ];

  // Recent Recruiter Activities
  const recentActivities = [
    {
      id: 1,
      type: "interview",
      title: "Interview completed with Sarah Johnson",
      candidate: "Senior Full Stack Developer",
      time: "1 hour ago",
      icon: UserCheck,
      color: "bg-green-500",
      status: "success"
    },
    {
      id: 2,
      type: "application",
      title: "New application received",
      job: "Product Manager Position",
      time: "3 hours ago",
      icon: FileText,
      color: "bg-blue-500",
      status: "info"
    },
    {
      id: 3,
      type: "offer",
      title: "Offer extended to Michael Chen",
      position: "DevOps Engineer",
      time: "5 hours ago",
      icon: Trophy,
      color: "bg-purple-500",
      status: "success"
    },
    {
      id: 4,
      type: "schedule",
      title: "Interview scheduled for tomorrow",
      candidate: "Emily Rodriguez",
      time: "1 day ago",
      icon: Calendar,
      color: "bg-orange-500",
      status: "pending"
    },
    {
      id: 5,
      type: "posting",
      title: "New job posting published",
      job: "Frontend Developer",
      time: "2 days ago",
      icon: Briefcase,
      color: "bg-indigo-500",
      status: "success"
    }
  ];

  return (
    <PlatformLayout
      sidebarTitle={config.sidebarTitle}
      sidebarSubtitle={config.sidebarSubtitle}
      sidebarSections={config.sidebarSections}
      usageData={[
        { label: "Candidate Views", current: 372, max: 500 },
        { label: "Job Postings", current: 12, max: 20 },
        { label: "Interview Slots", current: 25, max: 50 }
      ]}
    >
      <div className="min-h-screen bg-gray-50 p-6">
        {/* Hero Section */}
        <Card className="bg-white mb-6">
          <CardContent className="p-8">
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-3xl font-bold text-gray-900 mb-2">Recruiter Dashboard</h1>
                <p className="text-gray-600 mb-4">Streamline your hiring process with intelligent candidate matching</p>
                <div className="flex items-center space-x-6">
                  <div className="text-center">
                    <div className="text-2xl font-bold text-sky-600">87%</div>
                    <div className="text-sm text-gray-500">Hiring Success Rate</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-green-600">23</div>
                    <div className="text-sm text-gray-500">Days Avg. Time to Hire</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-purple-600">156</div>
                    <div className="text-sm text-gray-500">Active Candidates</div>
                  </div>
                </div>
              </div>
              <div className="flex space-x-3">
                <Button className="bg-sky-500 hover:bg-sky-600 text-white">
                  <Plus className="w-4 h-4 mr-2" />
                  Post New Job
                </Button>
                <Button variant="outline" className="border-gray-300 text-gray-600">
                  <Search className="w-4 h-4 mr-2" />
                  Find Candidates
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Hiring Pipeline & Job Performance */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
          {/* Hiring Pipeline */}
          <Card className="bg-white">
            <CardHeader>
              <CardTitle className="text-xl text-gray-800">Hiring Pipeline</CardTitle>
              <CardDescription>Current recruitment funnel performance</CardDescription>
            </CardHeader>
            <CardContent className="p-6 bg-white">
              {/* Visual Pipeline Flow */}
              <div className="flex items-center justify-between mb-6 p-4 bg-gradient-to-r from-blue-50 to-purple-50 rounded-lg">
                {pipelineStages.map((stage, index) => (
                  <div key={stage.stage} className="flex items-center">
                    <div className="text-center">
                      <div className={`w-16 h-16 ${stage.color} rounded-full flex items-center justify-center mb-2 shadow-lg`}>
                        <span className="text-white font-bold text-lg">{stage.count}</span>
                      </div>
                      <div className="text-xs font-medium text-gray-700">{stage.stage}</div>
                      <div className="text-xs text-gray-500">{stage.percentage}%</div>
                    </div>
                    {index < pipelineStages.length - 1 && (
                      <div className="flex-1 mx-2">
                        <ArrowRight className="w-6 h-6 text-gray-400 mx-auto" />
                      </div>
                    )}
                  </div>
                ))}
              </div>
              
              {/* Detailed Metrics */}
              <div className="space-y-3">
                {pipelineStages.map((stage, index) => (
                  <div key={stage.stage} className="flex items-center justify-between p-3 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors">
                    <div className="flex items-center space-x-3">
                      <div className={`w-4 h-4 ${stage.color} rounded-full`}></div>
                      <span className="font-medium text-gray-900">{stage.stage}</span>
                    </div>
                    <div className="flex items-center space-x-4">
                      <div className="text-right">
                        <div className="font-semibold text-gray-900">{stage.count} candidates</div>
                        <div className="text-xs text-gray-500">Conversion: {stage.percentage}%</div>
                      </div>
                      <div className="w-24">
                        <Progress value={stage.percentage} className="h-3" />
                      </div>
                    </div>
                  </div>
                ))}
              </div>
              <Button variant="outline" className="w-full mt-4 text-gray-600 border-gray-300">
                <BarChart3 className="w-4 h-4 mr-2" />
                View Detailed Analytics
              </Button>
            </CardContent>
          </Card>

          {/* Job Postings Performance */}
          <Card className="bg-white">
            <CardHeader>
              <CardTitle className="text-xl text-gray-800">Top Job Postings</CardTitle>
              <CardDescription>Performance metrics for active positions</CardDescription>
            </CardHeader>
            <CardContent className="p-6 bg-white">
              <div className="space-y-4">
                {jobPostings.map((job, index) => (
                  <div key={index} className="border border-gray-200 rounded-lg p-4 hover:bg-gray-50 transition-colors">
                    <div className="flex items-start justify-between mb-2">
                      <h4 className="font-semibold text-gray-900">{job.title}</h4>
                      <Badge className="bg-green-100 text-green-800">{job.status}</Badge>
                    </div>
                    <div className="flex items-center justify-between text-sm text-gray-600">
                      <div className="flex items-center space-x-4">
                        <span className="flex items-center">
                          <Users className="w-4 h-4 mr-1" />
                          {job.applications} applications
                        </span>
                        <span className="flex items-center">
                          <Eye className="w-4 h-4 mr-1" />
                          {job.views} views
                        </span>
                      </div>
                      <div className="text-right">
                        <div className="font-medium text-gray-900">{job.budget}</div>
                        <div className="text-xs text-gray-500">{job.posted}</div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
              <Button variant="outline" className="w-full mt-4 text-gray-600 border-gray-300">
                <Briefcase className="w-4 h-4 mr-2" />
                Manage All Jobs
              </Button>
            </CardContent>
          </Card>
        </div>

        {/* Team Metrics & Candidate Analytics */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
          {/* Team Performance */}
          <Card className="bg-white">
            <CardHeader>
              <CardTitle className="text-xl text-gray-800">Team Performance</CardTitle>
              <CardDescription>Key recruiting metrics and goals</CardDescription>
            </CardHeader>
            <CardContent className="p-6 bg-white">
              <div className="grid grid-cols-2 gap-4">
                {teamMetrics.map((metric, index) => (
                  <div key={index} className="text-center p-4 bg-gradient-to-br from-gray-50 to-blue-50 rounded-lg border hover:shadow-md transition-all">
                    <div className={`w-16 h-16 ${metric.color} rounded-full flex items-center justify-center mx-auto mb-3 shadow-lg`}>
                      <Target className="w-8 h-8 text-white" />
                    </div>
                    <div className="mb-2">
                      <div className="text-2xl font-bold text-gray-900">
                        {metric.value}{metric.unit || ''}
                      </div>
                      <div className="text-xs text-gray-500 mb-2">{metric.name}</div>
                    </div>
                    <div className="relative mb-2">
                      <Progress 
                        value={(metric.value / metric.target) * 100} 
                        className="h-2"
                      />
                      <div className="flex justify-between text-xs text-gray-400 mt-1">
                        <span>0</span>
                        <span>Target: {metric.target}{metric.unit || ''}</span>
                      </div>
                    </div>
                    <div className={`text-xs font-medium ${
                      metric.value >= metric.target ? 'text-green-600' : 'text-orange-600'
                    }`}>
                      {metric.value >= metric.target ? '✓ Target Met' : '→ In Progress'}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Candidate Pool Analytics */}
          <Card className="bg-white">
            <CardHeader>
              <CardTitle className="text-xl text-gray-800">Candidate Pool Analytics</CardTitle>
              <CardDescription>Top skills in your talent pipeline</CardDescription>
            </CardHeader>
            <CardContent className="p-6 bg-white">
              <div className="space-y-3">
                {candidateData.map((skill, index) => (
                  <div key={index} className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">
                      <div className="w-2 h-2 bg-sky-500 rounded-full"></div>
                      <span className="font-medium text-gray-900">{skill.skill}</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <span className="text-gray-600">{skill.count}</span>
                      {skill.trend === 'up' ? (
                        <TrendingUp className="w-4 h-4 text-green-500" />
                      ) : (
                        <TrendingDown className="w-4 h-4 text-red-500" />
                      )}
                    </div>
                  </div>
                ))}
              </div>
              <Button variant="outline" className="w-full mt-4 text-gray-600 border-gray-300">
                <Brain className="w-4 h-4 mr-2" />
                View Full Analytics
              </Button>
            </CardContent>
          </Card>
        </div>

        {/* Top Candidates */}
        <Card className="bg-white mb-6">
          <CardHeader>
            <CardTitle className="text-xl text-gray-800">Top Candidates</CardTitle>
            <CardDescription>High-potential candidates in your pipeline</CardDescription>
          </CardHeader>
          <CardContent className="p-6 bg-white">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {topCandidates.map((candidate) => (
                <div key={candidate.id} className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow cursor-pointer">
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex items-center space-x-3">
                      <div className="w-12 h-12 bg-sky-100 rounded-full flex items-center justify-center">
                        <span className="font-semibold text-sky-600">{candidate.avatar}</span>
                      </div>
                      <div>
                        <h4 className="font-semibold text-gray-900">{candidate.name}</h4>
                        <p className="text-sm text-gray-600">{candidate.title}</p>
                      </div>
                    </div>
                    <Badge className={`${
                      candidate.match >= 95 ? 'bg-green-100 text-green-800' :
                      candidate.match >= 90 ? 'bg-blue-100 text-blue-800' :
                      'bg-yellow-100 text-yellow-800'
                    }`}>
                      {candidate.match}% match
                    </Badge>
                  </div>
                  
                  <div className="space-y-2 mb-4">
                    <div className="flex items-center text-sm text-gray-600">
                      <MapPin className="w-4 h-4 mr-1" />
                      {candidate.location}
                      <span className="mx-2">•</span>
                      <span className="font-medium text-green-600">{candidate.salary}</span>
                    </div>
                    <div className="flex items-center text-sm text-gray-600">
                      <Briefcase className="w-4 h-4 mr-1" />
                      {candidate.experience}
                      <span className="mx-2">•</span>
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                        candidate.status === 'Interview Scheduled' ? 'bg-blue-100 text-blue-800' :
                        candidate.status === 'Screening' ? 'bg-yellow-100 text-yellow-800' :
                        'bg-green-100 text-green-800'
                      }`}>
                        {candidate.status}
                      </span>
                    </div>
                  </div>

                  <div className="space-y-2 mb-4">
                    <div className="flex flex-wrap gap-1">
                      {candidate.skills.map((skill, index) => (
                        <span key={index} className="inline-flex items-center px-2 py-1 rounded-md text-xs font-medium bg-sky-100 text-sky-800">
                          {skill}
                        </span>
                      ))}
                    </div>
                  </div>

                  <div className="flex space-x-2">
                    <Button size="sm" className="flex-1 bg-sky-500 hover:bg-sky-600 text-white">
                      <MessageSquare className="w-4 h-4 mr-1" />
                      Contact
                    </Button>
                    <Button size="sm" variant="outline" className="border-gray-300 text-gray-600">
                      <Eye className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
            <div className="mt-6 flex justify-center">
              <Button variant="outline" className="text-gray-600 border-gray-300">
                <Users className="w-4 h-4 mr-2" />
                View All Candidates
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Recent Activities */}
        <Card className="bg-white mb-6">
          <CardHeader>
            <CardTitle className="text-xl text-gray-800">Recent Activities</CardTitle>
            <CardDescription>Your latest recruiting actions and updates</CardDescription>
          </CardHeader>
          <CardContent className="p-6 bg-white">
            <div className="space-y-4">
              {recentActivities.map((activity) => {
                const IconComponent = activity.icon;
                return (
                  <div key={activity.id} className="flex items-start space-x-4 p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors cursor-pointer">
                    <div className={`w-10 h-10 ${activity.color} rounded-full flex items-center justify-center flex-shrink-0`}>
                      <IconComponent className="w-5 h-5 text-white" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <h4 className="font-medium text-gray-900 mb-1">{activity.title}</h4>
                          <div className="flex items-center space-x-4 text-sm text-gray-600">
                            {activity.candidate && (
                              <span className="flex items-center">
                                <UserCheck className="w-4 h-4 mr-1" />
                                {activity.candidate}
                              </span>
                            )}
                            {activity.job && (
                              <span className="flex items-center">
                                <Briefcase className="w-4 h-4 mr-1" />
                                {activity.job}
                              </span>
                            )}
                            {activity.position && (
                              <span className="flex items-center">
                                <Trophy className="w-4 h-4 mr-1" />
                                {activity.position}
                              </span>
                            )}
                          </div>
                        </div>
                        <div className="text-right flex-shrink-0 ml-4">
                          <div className="text-xs text-gray-500">{activity.time}</div>
                          <div className={`mt-1 inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${
                            activity.status === 'success' ? 'bg-green-100 text-green-800' :
                            activity.status === 'pending' ? 'bg-yellow-100 text-yellow-800' :
                            'bg-blue-100 text-blue-800'
                          }`}>
                            {activity.status === 'success' ? '✓ Complete' :
                             activity.status === 'pending' ? '⏳ Pending' :
                             'ℹ️ New'}
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
            <div className="mt-6 flex justify-center">
              <Button variant="outline" className="text-gray-600 border-gray-300">
                <Clock className="w-4 h-4 mr-2" />
                View All Activities
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Call-to-Action */}
        <Card className="bg-white">
          <CardContent className="p-8 text-center">
            <h3 className="text-2xl font-bold text-gray-900 mb-2">Ready to Accelerate Your Hiring?</h3>
            <p className="text-gray-600 mb-6">Use our AI-powered candidate matching to find the perfect talent faster than ever.</p>
            <div className="flex justify-center space-x-4">
              <Button className="bg-sky-500 hover:bg-sky-600 text-white">
                <Brain className="w-4 h-4 mr-2" />
                Start AI Matching
              </Button>
              <Button variant="outline" className="border-gray-300 text-gray-600">
                <Calendar className="w-4 h-4 mr-2" />
                Schedule Demo
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </PlatformLayout>
  );
}