import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import PlatformLayout from "@/components/layout/platform-layout";
import { platformConfigs } from "@/config/complete-navigation";
import { BookOpen, Search, Filter, Play, Clock, Star, Users, Download } from "lucide-react";

export default function LMSLibrary() {
  const config = platformConfigs.lms;

  const courses = [
    {
      id: 1,
      title: "React Fundamentals",
      description: "Learn the core concepts of React including components, props, and state",
      instructor: "Sarah Johnson",
      duration: "4 hours",
      rating: 4.8,
      students: 1234,
      level: "Beginner",
      category: "Frontend",
      thumbnail: "/course-thumbnails/react-fundamentals.jpg",
      progress: 65
    },
    {
      id: 2,
      title: "Node.js Backend Development",
      description: "Build scalable backend applications with Node.js and Express",
      instructor: "Mike Chen",
      duration: "6 hours",
      rating: 4.7,
      students: 892,
      level: "Intermediate",
      category: "Backend",
      thumbnail: "/course-thumbnails/nodejs-backend.jpg",
      progress: 0
    },
    {
      id: 3,
      title: "Python Data Science",
      description: "Master data analysis and machine learning with Python",
      instructor: "Dr. Lisa Wang",
      duration: "8 hours",
      rating: 4.9,
      students: 2156,
      level: "Advanced",
      category: "Data Science",
      thumbnail: "/course-thumbnails/python-ds.jpg",
      progress: 25
    },
    {
      id: 4,
      title: "AWS Cloud Fundamentals",
      description: "Get started with Amazon Web Services and cloud computing",
      instructor: "John Smith",
      duration: "5 hours",
      rating: 4.6,
      students: 765,
      level: "Beginner",
      category: "Cloud",
      thumbnail: "/course-thumbnails/aws-fundamentals.jpg",
      progress: 0
    }
  ];

  const categories = [
    { name: "Frontend", count: 45 },
    { name: "Backend", count: 32 },
    { name: "Data Science", count: 28 },
    { name: "Cloud", count: 21 },
    { name: "Mobile", count: 18 },
    { name: "DevOps", count: 15 }
  ];

  const libraryStats = [
    { label: "Total Courses", value: "159", change: "+12 this month" },
    { label: "Hours of Content", value: "847", change: "+45 hours" },
    { label: "Active Students", value: "12,847", change: "+8.5%" },
    { label: "Completion Rate", value: "73%", change: "+2.1%" }
  ];

  return (
    <PlatformLayout
      sidebarTitle={config.sidebarTitle}
      sidebarSubtitle={config.sidebarSubtitle}
      sidebarSections={config.sidebarSections}
      usageData={config.usageData}
    >
      <div className="max-w-7xl mx-auto px-6 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Course Library</h1>
          <p className="text-gray-600">Explore our comprehensive collection of technical courses</p>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          {libraryStats.map((stat, index) => (
            <Card key={index}>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600">{stat.label}</p>
                    <p className="text-2xl font-bold">{stat.value}</p>
                    <p className="text-sm text-green-600">{stat.change}</p>
                  </div>
                  <BookOpen className="w-8 h-8 text-blue-500" />
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          {/* Filters Sidebar */}
          <div className="lg:col-span-1">
            <Card>
              <CardHeader>
                <CardTitle>Categories</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {categories.map((category, index) => (
                    <div key={index} className="flex justify-between items-center p-2 hover:bg-gray-50 rounded cursor-pointer">
                      <span>{category.name}</span>
                      <Badge variant="outline">{category.count}</Badge>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card className="mt-6">
              <CardHeader>
                <CardTitle>Filters</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <label className="text-sm font-medium mb-2 block">Level</label>
                    <div className="space-y-2">
                      {['Beginner', 'Intermediate', 'Advanced'].map((level) => (
                        <label key={level} className="flex items-center space-x-2">
                          <input type="checkbox" className="rounded" />
                          <span className="text-sm">{level}</span>
                        </label>
                      ))}
                    </div>
                  </div>
                  <div>
                    <label className="text-sm font-medium mb-2 block">Rating</label>
                    <div className="space-y-2">
                      {['4.5+ Stars', '4.0+ Stars', '3.5+ Stars'].map((rating) => (
                        <label key={rating} className="flex items-center space-x-2">
                          <input type="checkbox" className="rounded" />
                          <span className="text-sm">{rating}</span>
                        </label>
                      ))}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Course Grid */}
          <div className="lg:col-span-3">
            {/* Search Bar */}
            <Card className="mb-6">
              <CardContent className="p-4">
                <div className="flex gap-4">
                  <div className="flex-1">
                    <Input 
                      placeholder="Search courses, instructors, or topics..."
                      className="w-full"
                    />
                  </div>
                  <Button variant="outline">
                    <Filter className="w-4 h-4 mr-2" />
                    Filter
                  </Button>
                  <Button>
                    <Search className="w-4 h-4 mr-2" />
                    Search
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Course Cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {courses.map((course) => (
                <Card key={course.id} className="overflow-hidden">
                  <div className="h-48 bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center">
                    <BookOpen className="w-16 h-16 text-white" />
                  </div>
                  <CardHeader>
                    <div className="flex justify-between items-start">
                      <div>
                        <CardTitle className="text-lg">{course.title}</CardTitle>
                        <CardDescription className="mt-1">{course.description}</CardDescription>
                      </div>
                      <Badge variant={course.level === 'Beginner' ? 'default' : 
                                   course.level === 'Intermediate' ? 'secondary' : 'destructive'}>
                        {course.level}
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      <div className="flex items-center justify-between text-sm text-gray-600">
                        <span>By {course.instructor}</span>
                        <span className="font-medium text-blue-600">{course.category}</span>
                      </div>
                      
                      <div className="flex items-center justify-between text-sm">
                        <div className="flex items-center">
                          <Clock className="w-4 h-4 mr-1" />
                          {course.duration}
                        </div>
                        <div className="flex items-center">
                          <Star className="w-4 h-4 mr-1 text-yellow-500" />
                          {course.rating}
                        </div>
                        <div className="flex items-center">
                          <Users className="w-4 h-4 mr-1" />
                          {course.students}
                        </div>
                      </div>

                      {course.progress > 0 && (
                        <div>
                          <div className="flex justify-between text-sm mb-1">
                            <span>Progress</span>
                            <span>{course.progress}%</span>
                          </div>
                          <div className="w-full bg-gray-200 rounded-full h-2">
                            <div 
                              className="bg-blue-600 h-2 rounded-full" 
                              style={{ width: `${course.progress}%` }}
                            ></div>
                          </div>
                        </div>
                      )}

                      <div className="flex gap-2 pt-2">
                        {course.progress > 0 ? (
                          <Button className="flex-1">
                            <Play className="w-4 h-4 mr-2" />
                            Continue
                          </Button>
                        ) : (
                          <Button className="flex-1">
                            <Play className="w-4 h-4 mr-2" />
                            Start Course
                          </Button>
                        )}
                        <Button variant="outline" size="sm">
                          <Download className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </div>
      </div>
    </PlatformLayout>
  );
}