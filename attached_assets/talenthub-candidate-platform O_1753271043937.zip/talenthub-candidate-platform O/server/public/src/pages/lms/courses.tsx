import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Progress } from "@/components/ui/progress";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import PlatformLayout from "@/components/layout/platform-layout";
import { platformConfigs } from "@/config/navigation";
import { 
  BookOpen, 
  Search, 
  Filter, 
  MoreHorizontal, 
  Eye, 
  Edit, 
  Copy,
  Trash2,
  Plus,
  Users,
  Calendar,
  Clock,
  Star,
  Play,
  Download,
  Upload,
  BarChart3,
  Award,
  CheckCircle,
  XCircle,
  Video,
  FileText,
  Headphones,
  Image,
  Link,
  TrendingUp,
  Target,
  Zap
} from "lucide-react";

interface Course {
  id: string;
  title: string;
  description: string;
  category: string;
  level: string;
  duration: string;
  price: number;
  currency: string;
  status: string;
  instructor: {
    name: string;
    avatar?: string;
    expertise: string;
  };
  enrollments: number;
  completions: number;
  rating: number;
  reviews: number;
  createdAt: string;
  updatedAt: string;
  thumbnail: string;
  modules: number;
  lessons: number;
  quizzes: number;
  certificates: boolean;
  skills: string[];
  prerequisites: string[];
  outcomes: string[];
  contentTypes: {
    videos: number;
    documents: number;
    quizzes: number;
    assignments: number;
  };
  analytics: {
    completionRate: number;
    averageScore: number;
    timeSpent: string;
    dropoffRate: number;
  };
}

export default function LMSCourses() {
  const config = platformConfigs.lms;
  const { toast } = useToast();
  
  const [searchTerm, setSearchTerm] = useState("");
  const [filterCategory, setFilterCategory] = useState("all");
  const [filterLevel, setFilterLevel] = useState("all");
  const [filterStatus, setFilterStatus] = useState("all");
  const [sortBy, setSortBy] = useState("newest");
  const [selectedCourses, setSelectedCourses] = useState<string[]>([]);

  const { data: courses = [], isLoading } = useQuery<Course[]>({
    queryKey: ["/api/lms/courses"],
    initialData: [
      {
        id: "1",
        title: "Complete JavaScript Fundamentals",
        description: "Master JavaScript from basics to advanced concepts with hands-on projects and real-world applications.",
        category: "Programming",
        level: "Beginner",
        duration: "12 weeks",
        price: 99,
        currency: "USD",
        status: "published",
        instructor: {
          name: "Sarah Johnson",
          expertise: "Full Stack Developer"
        },
        enrollments: 1247,
        completions: 892,
        rating: 4.8,
        reviews: 234,
        createdAt: "2024-03-15",
        updatedAt: "2024-06-10",
        thumbnail: "/course-thumbnails/javascript.jpg",
        modules: 8,
        lessons: 64,
        quizzes: 16,
        certificates: true,
        skills: ["JavaScript", "ES6+", "DOM Manipulation", "Async Programming", "APIs"],
        prerequisites: ["Basic HTML", "Basic CSS"],
        outcomes: ["Build interactive web applications", "Understand modern JavaScript", "Work with APIs"],
        contentTypes: {
          videos: 48,
          documents: 16,
          quizzes: 16,
          assignments: 8
        },
        analytics: {
          completionRate: 71.6,
          averageScore: 85.3,
          timeSpent: "24.5 hours",
          dropoffRate: 28.4
        }
      },
      {
        id: "2",
        title: "React Development Masterclass",
        description: "Build modern React applications with hooks, context, routing, and state management.",
        category: "Programming",
        level: "Intermediate",
        duration: "16 weeks",
        price: 149,
        currency: "USD",
        status: "published",
        instructor: {
          name: "Michael Chen",
          expertise: "React Specialist"
        },
        enrollments: 856,
        completions: 567,
        rating: 4.9,
        reviews: 189,
        createdAt: "2024-02-20",
        updatedAt: "2024-06-08",
        thumbnail: "/course-thumbnails/react.jpg",
        modules: 12,
        lessons: 96,
        quizzes: 24,
        certificates: true,
        skills: ["React", "Hooks", "Redux", "React Router", "Testing"],
        prerequisites: ["JavaScript", "HTML/CSS", "ES6+"],
        outcomes: ["Build complex React apps", "Manage application state", "Test React components"],
        contentTypes: {
          videos: 72,
          documents: 24,
          quizzes: 24,
          assignments: 12
        },
        analytics: {
          completionRate: 66.2,
          averageScore: 88.7,
          timeSpent: "32.8 hours",
          dropoffRate: 33.8
        }
      },
      {
        id: "3",
        title: "Data Science with Python",
        description: "Learn data analysis, visualization, and machine learning using Python and popular libraries.",
        category: "Data Science",
        level: "Intermediate",
        duration: "20 weeks",
        price: 199,
        currency: "USD",
        status: "draft",
        instructor: {
          name: "Emily Rodriguez",
          expertise: "Data Scientist"
        },
        enrollments: 634,
        completions: 412,
        rating: 4.7,
        reviews: 156,
        createdAt: "2024-01-10",
        updatedAt: "2024-06-05",
        thumbnail: "/course-thumbnails/data-science.jpg",
        modules: 10,
        lessons: 80,
        quizzes: 20,
        certificates: true,
        skills: ["Python", "Pandas", "NumPy", "Matplotlib", "Scikit-learn", "Machine Learning"],
        prerequisites: ["Basic Python", "Statistics", "Mathematics"],
        outcomes: ["Analyze large datasets", "Create data visualizations", "Build ML models"],
        contentTypes: {
          videos: 60,
          documents: 20,
          quizzes: 20,
          assignments: 15
        },
        analytics: {
          completionRate: 65.0,
          averageScore: 82.1,
          timeSpent: "45.2 hours",
          dropoffRate: 35.0
        }
      }
    ]
  });

  const publishCourse = useMutation({
    mutationFn: async (courseId: string) => {
      return await apiRequest("PATCH", `/api/lms/courses/${courseId}`, { status: "published" });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/lms/courses"] });
      toast({
        title: "Course Published",
        description: "Course has been published successfully",
      });
    }
  });

  const duplicateCourse = useMutation({
    mutationFn: async (courseId: string) => {
      return await apiRequest("POST", `/api/lms/courses/${courseId}/duplicate`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/lms/courses"] });
      toast({
        title: "Course Duplicated",
        description: "Course has been duplicated successfully",
      });
    }
  });

  const deleteCourse = useMutation({
    mutationFn: async (courseId: string) => {
      return await apiRequest("DELETE", `/api/lms/courses/${courseId}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/lms/courses"] });
      toast({
        title: "Course Deleted",
        description: "Course has been deleted successfully",
      });
    }
  });

  const filteredCourses = courses.filter(course => {
    const matchesSearch = course.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         course.skills.some(skill => skill.toLowerCase().includes(searchTerm.toLowerCase()));
    const matchesCategory = filterCategory === "all" || course.category === filterCategory;
    const matchesLevel = filterLevel === "all" || course.level === filterLevel;
    const matchesStatus = filterStatus === "all" || course.status === filterStatus;
    
    return matchesSearch && matchesCategory && matchesLevel && matchesStatus;
  });

  const sortedCourses = [...filteredCourses].sort((a, b) => {
    switch (sortBy) {
      case "enrollments":
        return b.enrollments - a.enrollments;
      case "rating":
        return b.rating - a.rating;
      case "completion":
        return b.analytics.completionRate - a.analytics.completionRate;
      case "price":
        return b.price - a.price;
      default:
        return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
    }
  });

  const getStatusColor = (status: string) => {
    const colors = {
      published: "bg-green-100 text-green-800",
      draft: "bg-yellow-100 text-yellow-800",
      archived: "bg-gray-100 text-gray-800",
      review: "bg-blue-100 text-blue-800"
    };
    return colors[status as keyof typeof colors] || colors.draft;
  };

  const getLevelColor = (level: string) => {
    const colors = {
      "Beginner": "bg-green-100 text-green-800",
      "Intermediate": "bg-yellow-100 text-yellow-800",
      "Advanced": "bg-red-100 text-red-800"
    };
    return colors[level as keyof typeof colors] || colors["Beginner"];
  };

  const formatPrice = (price: number, currency: string) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: currency
    }).format(price);
  };

  const handlePublish = (courseId: string) => {
    publishCourse.mutate(courseId);
  };

  const handleDuplicate = (courseId: string) => {
    duplicateCourse.mutate(courseId);
  };

  const handleDelete = (courseId: string, courseTitle: string) => {
    if (confirm(`Are you sure you want to delete "${courseTitle}"?`)) {
      deleteCourse.mutate(courseId);
    }
  };

  const handleBulkAction = (action: string) => {
    toast({
      title: `Bulk ${action}`,
      description: `${action} applied to ${selectedCourses.length} courses`,
    });
    setSelectedCourses([]);
  };

  return (
    <PlatformLayout
      sidebarTitle={config.sidebarTitle}
      sidebarSubtitle={config.sidebarSubtitle}
      sidebarSections={config.sidebarSections}
      usageData={config.usageData}
    >
      <div className="max-w-7xl mx-auto px-6 py-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h2 className="text-3xl font-bold text-neutral-600 mb-2">Course Management</h2>
            <p className="text-neutral-500">Create, manage, and analyze your educational content and learner progress.</p>
          </div>
          <div className="flex items-center space-x-3">
            <Button variant="outline">
              <Upload className="w-4 h-4 mr-2" />
              Import
            </Button>
            <Button variant="outline">
              <BarChart3 className="w-4 h-4 mr-2" />
              Analytics
            </Button>
            <Button>
              <Plus className="w-4 h-4 mr-2" />
              Create Course
            </Button>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-neutral-500">Total Courses</p>
                  <p className="text-3xl font-bold text-neutral-600">{courses.length}</p>
                </div>
                <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                  <BookOpen className="w-6 h-6 text-blue-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-neutral-500">Total Enrollments</p>
                  <p className="text-3xl font-bold text-neutral-600">
                    {courses.reduce((sum, course) => sum + course.enrollments, 0).toLocaleString()}
                  </p>
                </div>
                <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                  <Users className="w-6 h-6 text-green-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-neutral-500">Avg. Completion Rate</p>
                  <p className="text-3xl font-bold text-neutral-600">
                    {Math.round(courses.reduce((sum, course) => sum + course.analytics.completionRate, 0) / courses.length)}%
                  </p>
                </div>
                <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
                  <Target className="w-6 h-6 text-purple-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-neutral-500">Avg. Rating</p>
                  <p className="text-3xl font-bold text-neutral-600">
                    {(courses.reduce((sum, course) => sum + course.rating, 0) / courses.length).toFixed(1)}
                  </p>
                </div>
                <div className="w-12 h-12 bg-yellow-100 rounded-lg flex items-center justify-center">
                  <Star className="w-6 h-6 text-yellow-600" />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Search and Filters */}
        <Card className="mb-6">
          <CardContent className="p-6">
            <div className="flex flex-col lg:flex-row gap-4">
              <div className="flex-1">
                <div className="relative">
                  <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder="Search courses by title, skills, or instructor..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                  />
                </div>
              </div>
              <div className="flex gap-3">
                <Select value={filterCategory} onValueChange={setFilterCategory}>
                  <SelectTrigger className="w-40">
                    <SelectValue placeholder="Category" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Categories</SelectItem>
                    <SelectItem value="Programming">Programming</SelectItem>
                    <SelectItem value="Data Science">Data Science</SelectItem>
                    <SelectItem value="Design">Design</SelectItem>
                    <SelectItem value="Business">Business</SelectItem>
                    <SelectItem value="Marketing">Marketing</SelectItem>
                  </SelectContent>
                </Select>
                
                <Select value={filterLevel} onValueChange={setFilterLevel}>
                  <SelectTrigger className="w-40">
                    <SelectValue placeholder="Level" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Levels</SelectItem>
                    <SelectItem value="Beginner">Beginner</SelectItem>
                    <SelectItem value="Intermediate">Intermediate</SelectItem>
                    <SelectItem value="Advanced">Advanced</SelectItem>
                  </SelectContent>
                </Select>

                <Select value={filterStatus} onValueChange={setFilterStatus}>
                  <SelectTrigger className="w-40">
                    <SelectValue placeholder="Status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Status</SelectItem>
                    <SelectItem value="published">Published</SelectItem>
                    <SelectItem value="draft">Draft</SelectItem>
                    <SelectItem value="review">Under Review</SelectItem>
                    <SelectItem value="archived">Archived</SelectItem>
                  </SelectContent>
                </Select>

                <Select value={sortBy} onValueChange={setSortBy}>
                  <SelectTrigger className="w-40">
                    <SelectValue placeholder="Sort by" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="newest">Newest</SelectItem>
                    <SelectItem value="enrollments">Most Popular</SelectItem>
                    <SelectItem value="rating">Highest Rated</SelectItem>
                    <SelectItem value="completion">Best Completion</SelectItem>
                    <SelectItem value="price">Highest Price</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Bulk Actions */}
        {selectedCourses.length > 0 && (
          <Card className="mb-6 border-blue-200 bg-blue-50">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">
                  {selectedCourses.length} courses selected
                </span>
                <div className="flex items-center space-x-2">
                  <Button size="sm" variant="outline" onClick={() => handleBulkAction("publish")}>
                    <CheckCircle className="w-3 h-3 mr-1" />
                    Publish
                  </Button>
                  <Button size="sm" variant="outline" onClick={() => handleBulkAction("archive")}>
                    <XCircle className="w-3 h-3 mr-1" />
                    Archive
                  </Button>
                  <Button size="sm" variant="outline" onClick={() => handleBulkAction("export")}>
                    <Download className="w-3 h-3 mr-1" />
                    Export
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Courses List */}
        <div className="space-y-4">
          {isLoading ? (
            <div className="text-center py-12">
              <BookOpen className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
              <p className="text-muted-foreground">Loading courses...</p>
            </div>
          ) : sortedCourses.length === 0 ? (
            <Card>
              <CardContent className="p-12 text-center">
                <BookOpen className="mx-auto h-12 w-12 text-muted-foreground mb-4" />
                <h3 className="text-lg font-semibold mb-2">No Courses Found</h3>
                <p className="text-muted-foreground mb-4">
                  Try adjusting your search criteria or create your first course.
                </p>
                <Button>
                  <Plus className="w-4 h-4 mr-2" />
                  Create First Course
                </Button>
              </CardContent>
            </Card>
          ) : (
            sortedCourses.map((course) => (
              <Card key={course.id} className="hover:shadow-md transition-shadow">
                <CardContent className="p-6">
                  <div className="flex items-start justify-between">
                    <div className="flex items-start space-x-4 flex-1">
                      <input
                        type="checkbox"
                        className="mt-1"
                        checked={selectedCourses.includes(course.id)}
                        onChange={(e) => {
                          if (e.target.checked) {
                            setSelectedCourses([...selectedCourses, course.id]);
                          } else {
                            setSelectedCourses(selectedCourses.filter(id => id !== course.id));
                          }
                        }}
                      />
                      
                      <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-purple-600 rounded-lg flex items-center justify-center text-white font-bold text-lg">
                        {course.title.split(' ').map(word => word[0]).join('').slice(0, 2)}
                      </div>
                      
                      <div className="flex-1">
                        <div className="flex items-center space-x-3 mb-2">
                          <h3 className="text-lg font-semibold text-neutral-600">{course.title}</h3>
                          <Badge className={getStatusColor(course.status)}>
                            {course.status}
                          </Badge>
                          <Badge className={getLevelColor(course.level)}>
                            {course.level}
                          </Badge>
                          {course.certificates && (
                            <Badge variant="outline" className="bg-yellow-100 text-yellow-600">
                              <Award className="w-3 h-3 mr-1" />
                              Certificate
                            </Badge>
                          )}
                        </div>
                        
                        <p className="text-sm text-neutral-500 mb-3 line-clamp-2">{course.description}</p>
                        
                        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 mb-4">
                          <div>
                            <div className="flex items-center text-sm text-neutral-500 mb-1">
                              <Users className="w-3 h-3 mr-1" />
                              Instructor: {course.instructor.name}
                            </div>
                            <div className="flex items-center text-sm text-neutral-500 mb-1">
                              <Clock className="w-3 h-3 mr-1" />
                              {course.duration} • {course.modules} modules
                            </div>
                            <div className="flex items-center text-sm text-neutral-500">
                              <Star className="w-3 h-3 mr-1 text-yellow-400" />
                              {course.rating} ({course.reviews} reviews)
                            </div>
                          </div>
                          
                          <div>
                            <div className="grid grid-cols-2 gap-4 text-sm mb-2">
                              <div>
                                <p className="text-neutral-500">Enrollments</p>
                                <p className="font-medium text-blue-600">{course.enrollments.toLocaleString()}</p>
                              </div>
                              <div>
                                <p className="text-neutral-500">Completions</p>
                                <p className="font-medium text-green-600">{course.completions.toLocaleString()}</p>
                              </div>
                            </div>
                            <div className="text-sm">
                              <p className="text-neutral-500">Price</p>
                              <p className="font-medium text-lg">{formatPrice(course.price, course.currency)}</p>
                            </div>
                          </div>
                          
                          <div>
                            <div className="text-sm mb-2">
                              <p className="text-neutral-500">Completion Rate</p>
                              <div className="flex items-center space-x-2">
                                <Progress value={course.analytics.completionRate} className="flex-1" />
                                <span className="font-medium">{course.analytics.completionRate.toFixed(1)}%</span>
                              </div>
                            </div>
                            <div className="grid grid-cols-2 gap-2 text-xs">
                              <div>
                                <p className="text-neutral-500">Avg. Score</p>
                                <p className="font-medium">{course.analytics.averageScore}%</p>
                              </div>
                              <div>
                                <p className="text-neutral-500">Avg. Time</p>
                                <p className="font-medium">{course.analytics.timeSpent}</p>
                              </div>
                            </div>
                          </div>
                        </div>
                        
                        <div className="mb-3">
                          <p className="text-sm font-medium text-neutral-600 mb-2">Content</p>
                          <div className="flex items-center space-x-4 text-xs text-neutral-500">
                            <div className="flex items-center">
                              <Video className="w-3 h-3 mr-1" />
                              {course.contentTypes.videos} videos
                            </div>
                            <div className="flex items-center">
                              <FileText className="w-3 h-3 mr-1" />
                              {course.contentTypes.documents} docs
                            </div>
                            <div className="flex items-center">
                              <CheckCircle className="w-3 h-3 mr-1" />
                              {course.contentTypes.quizzes} quizzes
                            </div>
                            <div className="flex items-center">
                              <Edit className="w-3 h-3 mr-1" />
                              {course.contentTypes.assignments} assignments
                            </div>
                          </div>
                        </div>
                        
                        <div className="flex flex-wrap gap-2">
                          {course.skills.slice(0, 4).map((skill, index) => (
                            <Badge key={index} variant="outline" className="text-xs">
                              {skill}
                            </Badge>
                          ))}
                          {course.skills.length > 4 && (
                            <Badge variant="outline" className="text-xs">
                              +{course.skills.length - 4} more
                            </Badge>
                          )}
                        </div>
                      </div>
                    </div>
                    
                    <div className="flex items-center space-x-2 ml-4">
                      {course.status === "draft" && (
                        <Button
                          size="sm"
                          onClick={() => handlePublish(course.id)}
                        >
                          <CheckCircle className="w-4 h-4 mr-1" />
                          Publish
                        </Button>
                      )}
                      
                      <Button size="sm" variant="outline">
                        <Play className="w-4 h-4" />
                      </Button>
                      
                      <Button size="sm" variant="outline">
                        <Edit className="w-4 h-4" />
                      </Button>
                      
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => handleDuplicate(course.id)}
                      >
                        <Copy className="w-4 h-4" />
                      </Button>
                      
                      <Button size="sm" variant="outline">
                        <BarChart3 className="w-4 h-4" />
                      </Button>
                      
                      <Button size="sm" variant="outline">
                        <MoreHorizontal className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))
          )}
        </div>

        {/* Pagination */}
        <div className="flex items-center justify-between mt-8">
          <p className="text-sm text-neutral-500">
            Showing {sortedCourses.length} of {courses.length} courses
          </p>
          <div className="flex items-center space-x-2">
            <Button variant="outline" size="sm" disabled>
              Previous
            </Button>
            <Button variant="outline" size="sm" className="bg-blue-50">
              1
            </Button>
            <Button variant="outline" size="sm">
              2
            </Button>
            <Button variant="outline" size="sm">
              Next
            </Button>
          </div>
        </div>
      </div>
    </PlatformLayout>
  );
}