import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import PlatformLayout from "@/components/layout/platform-layout";
import { platformConfigs } from "@/config/complete-navigation";
import { BookOpen, Play, Clock, CheckCircle, Star, Calendar, Target } from "lucide-react";

export default function MyLearning() {
  const config = platformConfigs.lms;

  const enrolledCourses = [
    {
      id: 1,
      title: "React Fundamentals",
      instructor: "Sarah Johnson",
      progress: 75,
      timeSpent: "12h 30m",
      nextLesson: "React Hooks",
      dueDate: "2024-06-20",
      rating: 4.8,
      status: "In Progress"
    },
    {
      id: 2,
      title: "Node.js Backend Development",
      instructor: "Mike Chen",
      progress: 25,
      timeSpent: "3h 15m",
      nextLesson: "Express Middleware",
      dueDate: "2024-06-25",
      rating: 4.7,
      status: "In Progress"
    },
    {
      id: 3,
      title: "Python Data Science",
      instructor: "Dr. Lisa Wang",
      progress: 100,
      timeSpent: "28h 45m",
      nextLesson: "Completed",
      dueDate: "2024-06-10",
      rating: 4.9,
      status: "Completed"
    }
  ];

  const recentActivity = [
    { action: "Completed lesson: React State Management", course: "React Fundamentals", time: "2 hours ago" },
    { action: "Started new course: Node.js Backend", course: "Node.js Backend Development", time: "1 day ago" },
    { action: "Earned certificate: Python Data Science", course: "Python Data Science", time: "3 days ago" },
    { action: "Submitted assignment: React Components", course: "React Fundamentals", time: "5 days ago" }
  ];

  const learningStats = [
    { label: "Courses Enrolled", value: "8", change: "+2 this month" },
    { label: "Hours Learned", value: "156", change: "+12 this week" },
    { label: "Certificates", value: "3", change: "+1 this month" },
    { label: "Current Streak", value: "12 days", change: "Personal best!" }
  ];

  const upcomingDeadlines = [
    { course: "React Fundamentals", task: "Final Project", due: "2024-06-20", urgent: true },
    { course: "Node.js Backend", task: "Middleware Assignment", due: "2024-06-25", urgent: false },
    { course: "AWS Fundamentals", task: "Cloud Architecture", due: "2024-06-30", urgent: false }
  ];

  return (
    <PlatformLayout
      sidebarTitle={config.sidebarTitle}
      sidebarSubtitle={config.sidebarSubtitle}
      sidebarSections={config.sidebarSections}
      usageData={config.usageData}
    >
      <div className="max-w-7xl mx-auto px-6 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">My Learning</h1>
          <p className="text-gray-600">Track your progress and continue your learning journey</p>
        </div>

        {/* Learning Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          {learningStats.map((stat, index) => (
            <Card key={index}>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-gray-600">{stat.label}</p>
                    <p className="text-2xl font-bold">{stat.value}</p>
                    <p className="text-sm text-green-600">{stat.change}</p>
                  </div>
                  <Target className="w-8 h-8 text-blue-500" />
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2">
            {/* Continue Learning */}
            <div className="mb-8">
              <h2 className="text-xl font-semibold mb-4">Continue Learning</h2>
              <div className="space-y-4">
                {enrolledCourses.filter(course => course.status === 'In Progress').map((course) => (
                  <Card key={course.id} className="border-l-4 border-l-blue-500">
                    <CardHeader>
                      <div className="flex justify-between items-start">
                        <div>
                          <CardTitle className="text-lg">{course.title}</CardTitle>
                          <CardDescription>By {course.instructor}</CardDescription>
                        </div>
                        <Badge variant="default">{course.status}</Badge>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        <div>
                          <div className="flex justify-between text-sm mb-2">
                            <span>Progress</span>
                            <span>{course.progress}%</span>
                          </div>
                          <Progress value={course.progress} className="h-2" />
                        </div>

                        <div className="grid grid-cols-2 gap-4 text-sm">
                          <div>
                            <span className="text-gray-600">Time Spent:</span>
                            <span className="ml-2 font-medium">{course.timeSpent}</span>
                          </div>
                          <div>
                            <span className="text-gray-600">Due Date:</span>
                            <span className="ml-2 font-medium">{course.dueDate}</span>
                          </div>
                        </div>

                        <div className="flex items-center justify-between">
                          <div className="text-sm text-gray-600">
                            Next: {course.nextLesson}
                          </div>
                          <div className="flex items-center">
                            <Star className="w-4 h-4 text-yellow-500 mr-1" />
                            <span className="text-sm">{course.rating}</span>
                          </div>
                        </div>

                        <Button className="w-full">
                          <Play className="w-4 h-4 mr-2" />
                          Continue Learning
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>

            {/* All Courses */}
            <div>
              <h2 className="text-xl font-semibold mb-4">All My Courses</h2>
              <div className="space-y-4">
                {enrolledCourses.map((course) => (
                  <Card key={course.id}>
                    <CardContent className="p-6">
                      <div className="flex justify-between items-start">
                        <div className="flex-1">
                          <div className="flex justify-between items-start mb-3">
                            <div>
                              <h3 className="font-medium">{course.title}</h3>
                              <p className="text-sm text-gray-600">By {course.instructor}</p>
                            </div>
                            <Badge variant={course.status === 'Completed' ? 'default' : 'secondary'}>
                              {course.status === 'Completed' && <CheckCircle className="w-3 h-3 mr-1" />}
                              {course.status}
                            </Badge>
                          </div>

                          <div className="grid grid-cols-3 gap-4 text-sm mb-3">
                            <div>
                              <span className="text-gray-600">Progress:</span>
                              <span className="ml-2 font-medium">{course.progress}%</span>
                            </div>
                            <div>
                              <span className="text-gray-600">Time:</span>
                              <span className="ml-2 font-medium">{course.timeSpent}</span>
                            </div>
                            <div className="flex items-center">
                              <Star className="w-4 h-4 text-yellow-500 mr-1" />
                              <span>{course.rating}</span>
                            </div>
                          </div>

                          <Progress value={course.progress} className="h-2 mb-3" />

                          <div className="flex gap-2">
                            {course.status === 'Completed' ? (
                              <Button size="sm" variant="outline">View Certificate</Button>
                            ) : (
                              <Button size="sm">Continue</Button>
                            )}
                            <Button size="sm" variant="outline">Course Details</Button>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          </div>

          {/* Sidebar */}
          <div>
            {/* Upcoming Deadlines */}
            <Card className="mb-6">
              <CardHeader>
                <CardTitle>Upcoming Deadlines</CardTitle>
                <CardDescription>Don't miss these important dates</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {upcomingDeadlines.map((deadline, index) => (
                    <div key={index} className={`p-3 rounded-lg border ${deadline.urgent ? 'border-red-200 bg-red-50' : 'border-gray-200'}`}>
                      <div className="flex justify-between items-start">
                        <div>
                          <p className="font-medium text-sm">{deadline.task}</p>
                          <p className="text-xs text-gray-600">{deadline.course}</p>
                        </div>
                        <Badge variant={deadline.urgent ? 'destructive' : 'outline'} className="text-xs">
                          {deadline.urgent ? 'Urgent' : 'Upcoming'}
                        </Badge>
                      </div>
                      <div className="flex items-center mt-2 text-xs text-gray-500">
                        <Calendar className="w-3 h-3 mr-1" />
                        Due: {deadline.due}
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Recent Activity */}
            <Card>
              <CardHeader>
                <CardTitle>Recent Activity</CardTitle>
                <CardDescription>Your latest learning activities</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {recentActivity.map((activity, index) => (
                    <div key={index} className="border-l-2 border-blue-200 pl-3">
                      <p className="text-sm font-medium">{activity.action}</p>
                      <p className="text-xs text-gray-600">{activity.course}</p>
                      <p className="text-xs text-gray-500">{activity.time}</p>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </PlatformLayout>
  );
}