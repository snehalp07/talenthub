import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import PlatformLayout from "@/components/layout/platform-layout";
import { platformConfigs } from "@/config/navigation";
import { 
  BarChart3, 
  Users, 
  FileText, 
  TrendingUp, 
  Brain, 
  Award, 
  Briefcase, 
  Clock, 
  CheckCircle, 
  Target, 
  Star, 
  MapPin,
  Calendar,
  DollarSign,
  Send,
  Eye,
  ArrowRight,
  Play,
  BookOpen,
  Trophy,
  Zap,
  Filter,
  Heart,
  Building2,
  TrendingDown,
  UserCheck,
  MessageSquare,
  PhoneCall,
  Mail,
  Search,
  Plus,
  GraduationCap,
  Video,
  Lightbulb,
  PieChart,
  TrendingUp as Growth,
  Users as Students,
  BookOpen as Course,
  Monitor
} from "lucide-react";

export default function LMSDashboard() {
  const config = platformConfigs.lms;

  // Learning Progress Overview
  const learningMetrics = [
    { metric: "Course Completion Rate", value: "87%", trend: "+5%", color: "bg-green-500" },
    { metric: "Average Score", value: "92%", trend: "+3%", color: "bg-blue-500" },
    { metric: "Student Engagement", value: "84%", trend: "+12%", color: "bg-purple-500" },
    { metric: "Certification Rate", value: "76%", trend: "+8%", color: "bg-orange-500" }
  ];

  // Popular Courses
  const popularCourses = [
    { 
      title: "Advanced JavaScript Development",
      students: 1247,
      completion: 89,
      rating: 4.8,
      instructor: "Dr. Sarah Chen",
      duration: "8 weeks",
      level: "Advanced",
      category: "Programming"
    },
    { 
      title: "Digital Marketing Fundamentals",
      students: 892,
      completion: 92,
      rating: 4.9,
      instructor: "Mark Rodriguez",
      duration: "6 weeks",
      level: "Beginner",
      category: "Marketing"
    },
    { 
      title: "Data Science with Python",
      students: 654,
      completion: 76,
      rating: 4.7,
      instructor: "Prof. Emily Wang",
      duration: "12 weeks",
      level: "Intermediate",
      category: "Data Science"
    },
    { 
      title: "UX/UI Design Principles",
      students: 543,
      completion: 85,
      rating: 4.8,
      instructor: "Alex Thompson",
      duration: "10 weeks",
      level: "Intermediate",
      category: "Design"
    }
  ];

  // Student Progress Analytics
  const studentProgress = [
    { category: "Programming", enrolled: 3247, completed: 2456, inProgress: 671, completion: 76 },
    { category: "Design", enrolled: 1892, completed: 1523, inProgress: 284, completion: 80 },
    { category: "Marketing", enrolled: 2156, completed: 1889, inProgress: 187, completion: 88 },
    { category: "Data Science", enrolled: 1543, completed: 1087, inProgress: 367, completion: 70 }
  ];

  // Instructor Performance
  const topInstructors = [
    {
      id: 1,
      name: "Dr. Sarah Chen",
      specialization: "Full Stack Development",
      courses: 12,
      students: 3247,
      rating: 4.9,
      earnings: "$45,670",
      avatar: "SC"
    },
    {
      id: 2,
      name: "Prof. Emily Wang",
      specialization: "Data Science & AI",
      courses: 8,
      students: 2156,
      rating: 4.8,
      earnings: "$38,920",
      avatar: "EW"
    },
    {
      id: 3,
      name: "Mark Rodriguez",
      specialization: "Digital Marketing",
      courses: 15,
      students: 2890,
      rating: 4.9,
      earnings: "$52,340",
      avatar: "MR"
    }
  ];

  // Learning Paths Performance
  const learningPaths = [
    {
      id: 1,
      title: "Full Stack Developer Path",
      courses: 8,
      duration: "6 months",
      students: 892,
      completion: 67,
      difficulty: "Advanced",
      skills: ["React", "Node.js", "MongoDB", "AWS"]
    },
    {
      id: 2,
      title: "Data Analyst Certification",
      courses: 6,
      duration: "4 months",
      students: 654,
      completion: 74,
      difficulty: "Intermediate",
      skills: ["Python", "SQL", "Tableau", "Statistics"]
    },
    {
      id: 3,
      title: "Digital Marketing Specialist",
      courses: 5,
      duration: "3 months",
      students: 743,
      completion: 82,
      difficulty: "Beginner",
      skills: ["SEO", "Google Ads", "Analytics", "Content"]
    }
  ];

  // Recent Learning Activities
  const recentActivities = [
    {
      id: 1,
      type: "completion",
      title: "Course completed: Advanced React Patterns",
      student: "Alice Johnson",
      time: "15 minutes ago",
      icon: Trophy,
      color: "bg-green-500",
      status: "success"
    },
    {
      id: 2,
      type: "enrollment",
      title: "New batch enrollment opened",
      course: "Machine Learning Fundamentals",
      time: "2 hours ago",
      icon: Users,
      color: "bg-blue-500",
      status: "info"
    },
    {
      id: 3,
      type: "certification",
      title: "Certification issued: Python Developer",
      student: "Michael Chen",
      time: "4 hours ago",
      icon: Award,
      color: "bg-purple-500",
      status: "success"
    },
    {
      id: 4,
      type: "feedback",
      title: "5-star review received",
      course: "UX Design Bootcamp",
      time: "6 hours ago",
      icon: Star,
      color: "bg-yellow-500",
      status: "positive"
    },
    {
      id: 5,
      type: "content",
      title: "New video lecture uploaded",
      course: "Advanced JavaScript",
      time: "1 day ago",
      icon: Video,
      color: "bg-indigo-500",
      status: "update"
    }
  ];

  return (
    <PlatformLayout
      sidebarTitle={config.sidebarTitle}
      sidebarSubtitle={config.sidebarSubtitle}
      sidebarSections={config.sidebarSections}
      usageData={[
        { label: "Active Courses", current: 156, max: 200 },
        { label: "Total Students", current: 8945, max: 15000 },
        { label: "Completion Rate", current: 87, max: 100 }
      ]}
    >
      <div className="min-h-screen bg-gray-50 p-6">
        {/* Hero Section */}
        <Card className="bg-white mb-6">
          <CardContent className="p-8">
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-3xl font-bold text-gray-900 mb-2">LMS Dashboard</h1>
                <p className="text-gray-600 mb-4">Comprehensive learning management and student progress tracking</p>
                <div className="flex items-center space-x-6">
                  <div className="text-center">
                    <div className="text-2xl font-bold text-sky-600">8,945</div>
                    <div className="text-sm text-gray-500">Active Students</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-green-600">156</div>
                    <div className="text-sm text-gray-500">Live Courses</div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-purple-600">87%</div>
                    <div className="text-sm text-gray-500">Completion Rate</div>
                  </div>
                </div>
              </div>
              <div className="flex space-x-3">
                <Button className="bg-sky-500 hover:bg-sky-600 text-white">
                  <Plus className="w-4 h-4 mr-2" />
                  Create Course
                </Button>
                <Button variant="outline" className="border-gray-300 text-gray-600">
                  <BarChart3 className="w-4 h-4 mr-2" />
                  Analytics
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Learning Metrics & Popular Courses */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
          {/* Learning Performance Metrics */}
          <Card className="bg-white">
            <CardHeader>
              <CardTitle className="text-xl text-gray-800">Learning Performance</CardTitle>
              <CardDescription>Key educational metrics and trends</CardDescription>
            </CardHeader>
            <CardContent className="p-6 bg-white">
              {/* Visual Learning Dashboard */}
              <div className="grid grid-cols-2 gap-4 mb-6">
                {learningMetrics.map((metric, index) => (
                  <div key={index} className="text-center p-4 bg-gradient-to-br from-blue-50 to-purple-50 rounded-lg border hover:shadow-md transition-all">
                    <div className={`w-16 h-16 ${metric.color} rounded-full flex items-center justify-center mx-auto mb-3 shadow-lg`}>
                      {index === 0 ? (
                        <CheckCircle className="w-8 h-8 text-white" />
                      ) : index === 1 ? (
                        <Trophy className="w-8 h-8 text-white" />
                      ) : index === 2 ? (
                        <Users className="w-8 h-8 text-white" />
                      ) : (
                        <Award className="w-8 h-8 text-white" />
                      )}
                    </div>
                    <div className="mb-2">
                      <div className="text-xl font-bold text-gray-900">{metric.value}</div>
                      <div className="text-xs text-gray-600 mb-2">{metric.metric}</div>
                    </div>
                    <div className="flex items-center justify-center space-x-1">
                      <TrendingUp className="w-3 h-3 text-green-500" />
                      <span className="text-xs font-medium text-green-600">{metric.trend}</span>
                    </div>
                  </div>
                ))}
              </div>
              <Button variant="outline" className="w-full mt-4 text-gray-600 border-gray-300">
                <TrendingUp className="w-4 h-4 mr-2" />
                View Detailed Reports
              </Button>
            </CardContent>
          </Card>

          {/* Popular Courses */}
          <Card className="bg-white">
            <CardHeader>
              <CardTitle className="text-xl text-gray-800">Top Performing Courses</CardTitle>
              <CardDescription>Most enrolled and highest rated courses</CardDescription>
            </CardHeader>
            <CardContent className="p-6 bg-white">
              <div className="space-y-4">
                {popularCourses.slice(0, 3).map((course, index) => (
                  <div key={index} className="border border-gray-200 rounded-lg p-4 hover:bg-gray-50 transition-colors">
                    <div className="flex items-start justify-between mb-2">
                      <h4 className="font-semibold text-gray-900 text-sm">{course.title}</h4>
                      <div className="flex items-center space-x-1">
                        <Star className="w-4 h-4 text-yellow-500 fill-current" />
                        <span className="text-sm font-medium">{course.rating}</span>
                      </div>
                    </div>
                    <div className="flex items-center justify-between text-sm text-gray-600 mb-2">
                      <span className="flex items-center">
                        <Users className="w-4 h-4 mr-1" />
                        {course.students} students
                      </span>
                      <span className="flex items-center">
                        <Clock className="w-4 h-4 mr-1" />
                        {course.duration}
                      </span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-xs text-gray-500">{course.instructor}</span>
                      <div className="text-right">
                        <div className="text-xs text-gray-900">{course.completion}% completed</div>
                        <Progress value={course.completion} className="h-1 w-16" />
                      </div>
                    </div>
                  </div>
                ))}
              </div>
              <Button variant="outline" className="w-full mt-4 text-gray-600 border-gray-300">
                <BookOpen className="w-4 h-4 mr-2" />
                View All Courses
              </Button>
            </CardContent>
          </Card>
        </div>

        {/* Student Progress & Instructor Performance */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
          {/* Student Progress by Category */}
          <Card className="bg-white">
            <CardHeader>
              <CardTitle className="text-xl text-gray-800">Student Progress Analytics</CardTitle>
              <CardDescription>Enrollment and completion by course categories</CardDescription>
            </CardHeader>
            <CardContent className="p-6 bg-white">
              <div className="space-y-4">
                {studentProgress.map((category, index) => (
                  <div key={index} className="p-4 border border-gray-200 rounded-lg">
                    <div className="flex items-center justify-between mb-2">
                      <h4 className="font-semibold text-gray-900">{category.category}</h4>
                      <div className="text-right">
                        <div className="text-sm font-medium text-gray-900">{category.completion}%</div>
                        <div className="text-xs text-gray-500">completion</div>
                      </div>
                    </div>
                    <div className="flex items-center justify-between text-sm text-gray-600 mb-2">
                      <span>{category.enrolled.toLocaleString()} enrolled</span>
                      <span>{category.completed.toLocaleString()} completed</span>
                    </div>
                    <Progress value={category.completion} className="h-2" />
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Top Instructors */}
          <Card className="bg-white">
            <CardHeader>
              <CardTitle className="text-xl text-gray-800">Top Instructors</CardTitle>
              <CardDescription>Highest performing educators and revenue leaders</CardDescription>
            </CardHeader>
            <CardContent className="p-6 bg-white">
              <div className="space-y-4">
                {topInstructors.map((instructor) => (
                  <div key={instructor.id} className="border border-gray-200 rounded-lg p-4 hover:bg-gray-50 transition-colors">
                    <div className="flex items-start justify-between mb-2">
                      <div className="flex items-center space-x-3">
                        <div className="w-10 h-10 bg-sky-100 rounded-full flex items-center justify-center">
                          <span className="font-semibold text-sky-600 text-sm">{instructor.avatar}</span>
                        </div>
                        <div>
                          <h4 className="font-semibold text-gray-900 text-sm">{instructor.name}</h4>
                          <p className="text-xs text-gray-600">{instructor.specialization}</p>
                        </div>
                      </div>
                      <div className="flex items-center space-x-1">
                        <Star className="w-4 h-4 text-yellow-500 fill-current" />
                        <span className="text-sm font-medium">{instructor.rating}</span>
                      </div>
                    </div>
                    <div className="flex items-center justify-between text-xs text-gray-600">
                      <span>{instructor.courses} courses • {instructor.students.toLocaleString()} students</span>
                      <span className="font-medium text-green-600">{instructor.earnings}</span>
                    </div>
                  </div>
                ))}
              </div>
              <Button variant="outline" className="w-full mt-4 text-gray-600 border-gray-300">
                <GraduationCap className="w-4 h-4 mr-2" />
                View All Instructors
              </Button>
            </CardContent>
          </Card>
        </div>

        {/* Learning Paths */}
        <Card className="bg-white mb-6">
          <CardHeader>
            <CardTitle className="text-xl text-gray-800">Learning Paths Performance</CardTitle>
            <CardDescription>Structured learning journeys and completion rates</CardDescription>
          </CardHeader>
          <CardContent className="p-6 bg-white">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {learningPaths.map((path) => (
                <div key={path.id} className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow cursor-pointer">
                  <div className="flex items-start justify-between mb-3">
                    <h4 className="font-semibold text-gray-900 text-sm">{path.title}</h4>
                    <Badge className={`${
                      path.difficulty === 'Advanced' ? 'bg-red-100 text-red-800' :
                      path.difficulty === 'Intermediate' ? 'bg-yellow-100 text-yellow-800' :
                      'bg-green-100 text-green-800'
                    }`}>
                      {path.difficulty}
                    </Badge>
                  </div>
                  
                  <div className="space-y-2 mb-4">
                    <div className="flex items-center text-sm text-gray-600">
                      <BookOpen className="w-4 h-4 mr-1" />
                      {path.courses} courses
                      <span className="mx-2">•</span>
                      <Clock className="w-4 h-4 mr-1" />
                      {path.duration}
                    </div>
                    <div className="flex items-center text-sm text-gray-600">
                      <Users className="w-4 h-4 mr-1" />
                      {path.students} students enrolled
                    </div>
                  </div>

                  <div className="space-y-2 mb-4">
                    <div className="text-xs text-gray-500 mb-1">Key Skills:</div>
                    <div className="flex flex-wrap gap-1">
                      {path.skills.slice(0, 3).map((skill, index) => (
                        <span key={index} className="inline-flex items-center px-2 py-1 rounded-md text-xs font-medium bg-sky-100 text-sky-800">
                          {skill}
                        </span>
                      ))}
                      {path.skills.length > 3 && (
                        <span className="inline-flex items-center px-2 py-1 rounded-md text-xs font-medium bg-gray-100 text-gray-700">
                          +{path.skills.length - 3}
                        </span>
                      )}
                    </div>
                  </div>

                  <div className="mb-3">
                    <div className="flex items-center justify-between text-sm mb-1">
                      <span className="text-gray-600">Completion Rate</span>
                      <span className="font-medium text-gray-900">{path.completion}%</span>
                    </div>
                    <Progress value={path.completion} className="h-2" />
                  </div>

                  <Button size="sm" variant="outline" className="w-full border-gray-300 text-gray-600">
                    <Eye className="w-4 h-4 mr-1" />
                    View Details
                  </Button>
                </div>
              ))}
            </div>
            <div className="mt-6 flex justify-center">
              <Button variant="outline" className="text-gray-600 border-gray-300">
                <Target className="w-4 h-4 mr-2" />
                Manage Learning Paths
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Recent Activities */}
        <Card className="bg-white mb-6">
          <CardHeader>
            <CardTitle className="text-xl text-gray-800">Recent Learning Activities</CardTitle>
            <CardDescription>Latest student achievements and platform updates</CardDescription>
          </CardHeader>
          <CardContent className="p-6 bg-white">
            <div className="space-y-4">
              {recentActivities.map((activity) => {
                const IconComponent = activity.icon;
                return (
                  <div key={activity.id} className="flex items-start space-x-4 p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors cursor-pointer">
                    <div className={`w-10 h-10 ${activity.color} rounded-full flex items-center justify-center flex-shrink-0`}>
                      <IconComponent className="w-5 h-5 text-white" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <h4 className="font-medium text-gray-900 mb-1">{activity.title}</h4>
                          <div className="flex items-center space-x-4 text-sm text-gray-600">
                            {activity.student && (
                              <span className="flex items-center">
                                <GraduationCap className="w-4 h-4 mr-1" />
                                {activity.student}
                              </span>
                            )}
                            {activity.course && (
                              <span className="flex items-center">
                                <BookOpen className="w-4 h-4 mr-1" />
                                {activity.course}
                              </span>
                            )}
                          </div>
                        </div>
                        <div className="text-right flex-shrink-0 ml-4">
                          <div className="text-xs text-gray-500">{activity.time}</div>
                          <div className={`mt-1 inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${
                            activity.status === 'success' ? 'bg-green-100 text-green-800' :
                            activity.status === 'positive' ? 'bg-yellow-100 text-yellow-800' :
                            activity.status === 'info' ? 'bg-blue-100 text-blue-800' :
                            'bg-purple-100 text-purple-800'
                          }`}>
                            {activity.status === 'success' ? '✓ Complete' :
                             activity.status === 'positive' ? '⭐ Review' :
                             activity.status === 'info' ? 'ℹ️ New' :
                             '📝 Update'}
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
            <div className="mt-6 flex justify-center">
              <Button variant="outline" className="text-gray-600 border-gray-300">
                <Clock className="w-4 h-4 mr-2" />
                View Activity Feed
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Call-to-Action */}
        <Card className="bg-white">
          <CardContent className="p-8 text-center">
            <h3 className="text-2xl font-bold text-gray-900 mb-2">Ready to Scale Your Learning Platform?</h3>
            <p className="text-gray-600 mb-6">Launch new courses, expand your instructor network, and reach more students worldwide.</p>
            <div className="flex justify-center space-x-4">
              <Button className="bg-sky-500 hover:bg-sky-600 text-white">
                <Video className="w-4 h-4 mr-2" />
                Launch Course Builder
              </Button>
              <Button variant="outline" className="border-gray-300 text-gray-600">
                <Users className="w-4 h-4 mr-2" />
                Invite Instructors
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </PlatformLayout>
  );
}