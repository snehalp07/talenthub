import { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { useLocation } from 'wouter';

interface NavigationContextType {
  expandedSections: string[];
  toggleSection: (sectionTitle: string) => void;
  isExpanded: (sectionTitle: string) => boolean;
  setExpandedFromRoute: (route: string) => void;
}

const NavigationContext = createContext<NavigationContextType | undefined>(undefined);

export function NavigationProvider({ children }: { children: ReactNode }) {
  const [expandedSections, setExpandedSections] = useState<string[]>([]);
  const [location] = useLocation();

  // Auto-expand sections based on current route
  const setExpandedFromRoute = (route: string) => {
    const routeToSectionMap: { [key: string]: string } = {
      // Candidate Platform
      '/candidate': 'Dashboard & Home',
      '/candidate/home': 'Dashboard & Home',
      '/candidate/job-board': 'Job Search & Applications',
      '/candidate/application-tracker': 'Job Search & Applications',
      '/candidate/job-alerts': 'Job Search & Applications',
      '/candidate/saved-jobs': 'Job Search & Applications',
      '/candidate/skill-tests': 'Skills & Assessment',
      '/candidate/ai-skill-assessment': 'Skills & Assessment',
      '/candidate/browse-tests': 'Skills & Assessment',
      '/candidate/certifications': 'Skills & Assessment',
      '/candidate/learning-path': 'Skills & Assessment',
      '/candidate/profile-builder': 'Profile & Branding',
      '/candidate/video-cv': 'Profile & Branding',
      '/candidate/infographic-cv': 'Profile & Branding',
      '/candidate/resume-tips': 'Profile & Branding',
      '/candidate/profile-preview': 'Profile & Branding',
      '/candidate/ai-mock-interviews': 'Interview Preparation',
      '/candidate/interview-scheduler': 'Interview Preparation',
      '/candidate/interview-feedback': 'Interview Preparation',
      '/candidate/personal-interview': 'Interview Preparation',
      '/candidate/career-guidance': 'Career Development',
      '/candidate/market-trends': 'Career Development',
      '/candidate/performance-insights': 'Career Development',
      '/candidate/networking': 'Career Development',
      '/candidate/linkedin-integration': 'Tools & Integration',
      '/candidate/mobile-app': 'Tools & Integration',
      '/candidate/project-access': 'Tools & Integration',
      '/candidate/project-editor': 'Tools & Integration',
      '/candidate/analytics': 'Analytics & Insights',
      '/candidate/performance': 'Analytics & Insights',
      '/candidate/test-reports': 'Analytics & Insights',
      '/candidate/one-on-one-support': 'Support & Services',
      '/candidate/priority-support': 'Support & Services',
      '/candidate/notifications': 'Support & Services',
      '/candidate/subscription': 'Subscription & Settings',
      '/candidate/settings': 'Subscription & Settings',

      // Recruiter Platform
      '/recruiter': 'Core Management',
      '/recruiter/talent-intelligence': 'Core Management',
      '/recruiter/candidates': 'Candidate Discovery',
      '/recruiter/ai-discovery': 'Candidate Discovery',
      '/recruiter/resume-parser': 'Candidate Discovery',
      '/recruiter/talent-pool': 'Candidate Discovery',
      '/recruiter/candidate-ranking': 'Candidate Discovery',
      '/recruiter/jobs': 'Job Management',
      '/recruiter/job-templates': 'Job Management',
      '/recruiter/job-publishing': 'Job Management',
      '/recruiter/multi-board': 'Job Management',
      '/recruiter/interview-pipeline': 'Interview & Assessment',
      '/recruiter/video-interviews': 'Interview & Assessment',
      '/recruiter/scorecards': 'Interview & Assessment',
      '/recruiter/ai-matching': 'AI-Powered Tools',
      '/recruiter/ai-screening': 'AI-Powered Tools',
      '/recruiter/ai-interview': 'AI-Powered Tools',
      '/recruiter/ai-scoring': 'AI-Powered Tools',
      '/recruiter/ai-command': 'AI-Powered Tools',
      '/recruiter/analytics': 'Analytics & Intelligence',
      '/recruiter/predictive': 'Analytics & Intelligence',
      '/recruiter/realtime': 'Analytics & Intelligence',
      '/recruiter/prediction': 'Analytics & Intelligence',
      '/recruiter/market': 'Analytics & Intelligence',
      '/recruiter/diversity': 'Analytics & Intelligence',
      '/recruiter/automation': 'Automation & Workflow',
      '/recruiter/email-templates': 'Automation & Workflow',
      '/recruiter/bulk-ops': 'Automation & Workflow',
      '/recruiter/company-profile': 'Employer Branding',
      '/recruiter/candidate-experience': 'Employer Branding',
      '/recruiter/brand-analytics': 'Employer Branding',
      '/recruiter/team': 'Business Management',
      '/recruiter/cost-analytics': 'Business Management',
      '/recruiter/subscription': 'Business Management',
      '/recruiter/settings': 'Settings & Configuration',

      // Admin Platform
      '/admin': 'Core Management',
      '/admin/users': 'Core Management',
      '/admin/organizations': 'Core Management',
      '/admin/tenants': 'Core Management',
      '/admin/test-creation': 'Assessment Control',
      '/admin/question-bank': 'Assessment Control',
      '/admin/question-upload': 'Assessment Control',
      '/admin/bulk-upload': 'Assessment Control',
      '/admin/assessment-analytics': 'Assessment Control',
      '/admin/ai-monitoring': 'AI & Content',
      '/admin/content-moderation': 'AI & Content',
      '/admin/media-library': 'AI & Content',
      '/admin/resume-parser': 'AI & Content',
      '/admin/system-monitoring': 'System Operations',
      '/admin/database': 'System Operations',
      '/admin/audit-logs': 'System Operations',
      '/admin/features': 'System Operations',
      '/admin/subscriptions': 'Business Management',
      '/admin/verification': 'Business Management',
      '/admin/scheduling': 'Business Management',
      '/admin/settings': 'Platform Settings',

      // LMS Platform
      '/lms': 'Core Learning',
      '/lms/library': 'Core Learning',
      '/lms/my-learning': 'Core Learning',
      '/lms/courses': 'Learning Modules',
      '/lms/videos': 'Learning Modules',
      '/lms/practice-tests': 'Learning Modules',
      '/lms/assignments': 'Learning Modules',
      '/lms/certifications': 'Certification Programs',
      '/lms/cert-tracker': 'Certification Programs',
      '/lms/ai-path': 'Certification Programs',
      '/lms/blockchain-certs': 'Certification Programs',
      '/lms/mentorship': 'Advanced Features',
      '/lms/projects': 'Advanced Features',
      '/lms/security-certs': 'Advanced Features',
      '/lms/study-groups': 'Collaboration',
      '/lms/peer-learning': 'Collaboration',
      '/lms/forums': 'Collaboration',
      '/lms/analytics': 'Progress Tracking',
      '/lms/progress': 'Progress Tracking',
      '/lms/badges': 'Progress Tracking',
      '/lms/profile': 'Profile & Settings',
      '/lms/settings': 'Profile & Settings',
    };

    const section = routeToSectionMap[route];
    if (section && !expandedSections.includes(section)) {
      setExpandedSections(prev => [...prev, section]);
    }
  };

  // Update expansion based on route changes
  useEffect(() => {
    setExpandedFromRoute(location);
  }, [location]);

  const toggleSection = (sectionTitle: string) => {
    setExpandedSections(prev => 
      prev.includes(sectionTitle)
        ? prev.filter(title => title !== sectionTitle)
        : [...prev, sectionTitle]
    );
  };

  const isExpanded = (sectionTitle: string) => {
    return expandedSections.includes(sectionTitle);
  };

  return (
    <NavigationContext.Provider 
      value={{ 
        expandedSections, 
        toggleSection, 
        isExpanded, 
        setExpandedFromRoute 
      }}
    >
      {children}
    </NavigationContext.Provider>
  );
}

export function useNavigation() {
  const context = useContext(NavigationContext);
  if (context === undefined) {
    throw new Error('useNavigation must be used within a NavigationProvider');
  }
  return context;
}