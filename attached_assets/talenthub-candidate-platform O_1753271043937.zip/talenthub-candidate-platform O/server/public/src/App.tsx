import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AuthProvider } from "./hooks/use-auth";
import { NavigationProvider } from "./contexts/navigation-context";
import { ProtectedRoute } from "./lib/protected-route";
import LandingPage from "@/pages/landing-page";
import Dashboard from "@/pages/dashboard";
import CandidatePlatform from "@/pages/candidate-platform";
import RecruiterPlatform from "@/pages/recruiter-platform";
import AdminPlatform from "@/pages/admin-platform";
import LMSPlatform from "@/pages/lms-platform";
import AssessmentPlatform from "@/pages/assessment-platform";
import BackupAccess from "@/pages/backup-access";
import AuthPage from "@/pages/auth-page";
import NotFound from "@/pages/not-found";
import ImagePreview from "@/pages/image-preview";

// Candidate Pages
import CandidateHome from "@/pages/candidate/home";
import CandidateDashboard from "@/pages/candidate/dashboard";

import JobBoard from "@/pages/candidate/job-board";
import ApplicationTracker from "@/pages/candidate/application-tracker";
import JobAlerts from "@/pages/candidate/job-alerts";
import SavedJobs from "@/pages/candidate/saved-jobs";
import BrowseTests from "@/pages/candidate/browse-tests";
import SkillTests from "@/pages/candidate/skill-tests";
import TestRunner from "@/pages/candidate/test-runner";
import InfographicCV from "@/pages/candidate/infographic-cv";
import VideoCV from "@/pages/candidate/video-cv";
import ResumeTips from "@/pages/candidate/resume-tips";
import AIMockInterviews from "@/pages/candidate/ai-mock-interviews";
import PersonalInterview from "@/pages/candidate/personal-interview";
import InterviewScheduler from "@/pages/candidate/interview-scheduler";
import InterviewFeedback from "@/pages/candidate/interview-feedback";
import CareerGuidance from "@/pages/candidate/career-guidance";
import MarketTrends from "@/pages/candidate/market-trends";
import PerformanceInsights from "@/pages/candidate/performance-insights";
import Networking from "@/pages/candidate/networking";
import LinkedInIntegration from "@/pages/candidate/linkedin-integration";
import ProjectAccess from "@/pages/candidate/project-access";
import ProjectEditor from "@/pages/candidate/project-editor";
import ProjectEditorEnhanced from "@/pages/candidate/project-editor-enhanced";
import TestReports from "@/pages/candidate/test-reports";
import OneOnOneSupport from "@/pages/candidate/one-on-one-support";
import PrioritySupport from "@/pages/candidate/priority-support";
import CandidateNotifications from "@/pages/candidate/notifications";
import CandidateSubscription from "@/pages/candidate/subscription";
import AISkillAssessment from "@/pages/candidate/ai-skill-assessment";
import Certifications from "@/pages/candidate/certifications";
import LearningPath from "@/pages/candidate/learning-path";
import CandidateAnalytics from "@/pages/candidate/analytics";
import ProfileBuilder from "@/pages/candidate/profile-builder";
import ProfilePreview from "@/pages/candidate/profile-preview";
import BrowseCertifications from "@/pages/candidate/browse-certifications";
import CertificationTracker from "@/pages/candidate/certification-tracker";
import AILearningPath from "@/pages/candidate/ai-learning-path";
import BlockchainCertificates from "@/pages/candidate/blockchain-certificates";
import MobileApp from "@/pages/candidate/mobile-app";
import Performance from "@/pages/candidate/performance";
import Settings from "@/pages/candidate/settings";
import TestCertificationView from "@/pages/candidate/test-certification-view";
import ProjectCertificationView from "@/pages/candidate/project-certification-view";
import MockInterviewCertificationView from "@/pages/candidate/mock-interview-certification-view";
import TestResults from "@/pages/candidate/test-results";

// Recruiter Pages
import RecruiterCandidates from "@/pages/recruiter/candidates";
import RecruiterJobs from "@/pages/recruiter/jobs";
import RecruiterDashboard from "@/pages/recruiter/dashboard";
import TalentIntelligence from "@/pages/recruiter/talent-intelligence";
import AIDiscovery from "@/pages/recruiter/ai-discovery";

// Admin Pages
import AdminTenants from "@/pages/admin/tenants";
import AdminDashboard from "@/pages/admin/dashboard";
import AdminUsers from "@/pages/admin/users";
import BillingOverview from "@/pages/admin/billing-overview";
import APIAnalytics from "@/pages/admin/api-analytics";
import Partners from "@/pages/admin/partners";
import Revenue from "@/pages/admin/revenue";
import APIKeys from "@/pages/admin/api-keys";
import Integrations from "@/pages/admin/integrations";

// Billing Pages
import BillingDashboard from "@/pages/billing-dashboard";

// LMS Pages
import LMSCourses from "@/pages/lms/courses";
import LMSDashboard from "@/pages/lms/dashboard";
import LMSLibrary from "@/pages/lms/library";
import MyLearning from "@/pages/lms/my-learning";

// Assessment Pages
import AssessmentDashboard from "@/pages/assessment/dashboard";
import AssessmentWrapperDashboard from "@/pages/assessment/wrapper-dashboard";
import AssessmentBrowseTests from "@/pages/assessment/browse-tests";
import AssessmentTestRunner from "@/pages/assessment/test-runner";
import AssessmentTestResults from "@/pages/assessment/test-results";
import AssessmentQuestionBank from "@/pages/assessment/question-bank";
import AssessmentBulkUpload from "@/pages/assessment/bulk-upload";
import AssessmentCertifications from "@/pages/assessment/certifications";
import AssessmentAnalytics from "@/pages/assessment/analytics";
import AssessmentOverview from "@/pages/assessment/overview";
import AssessmentUsers from "@/pages/assessment/users";
import AssessmentBlockchainCertificates from "@/pages/assessment/blockchain-certificates";
import AssessmentCourses from "@/pages/assessment/courses";
import AssessmentPracticeTests from "@/pages/assessment/practice-tests";

// Organization Management
import OrganizationManagement from "@/pages/organization-management";

function Router() {
  return (
    <Switch>
      <Route path="/" component={LandingPage} />
      <Route path="/image-preview" component={ImagePreview} />
      
      {/* Candidate Platform Routes */}
      <ProtectedRoute path="/candidate" component={CandidateDashboard} />
      <ProtectedRoute path="/candidate/home" component={CandidateHome} />
      <ProtectedRoute path="/candidate/dashboard" component={CandidateDashboard} />
      <ProtectedRoute path="/candidate/platform" component={CandidatePlatform} />
      
      {/* Job Search & Applications */}
      <ProtectedRoute path="/candidate/job-board" component={JobBoard} />
      <ProtectedRoute path="/candidate/application-tracker" component={ApplicationTracker} />
      <ProtectedRoute path="/candidate/job-alerts" component={JobAlerts} />
      <ProtectedRoute path="/candidate/saved-jobs" component={SavedJobs} />
      
      {/* Skills & Assessment */}
      <Route path="/candidate/skill-tests" component={SkillTests} />
      <Route path="/candidate/browse-tests" component={BrowseTests} />
      <Route path="/candidate/test-runner/:testId" component={TestRunner} />
      <Route path="/candidate/test-results" component={TestResults} />
      <Route path="/candidate/ai-skill-assessment" component={AISkillAssessment} />
      <Route path="/candidate/certifications" component={Certifications} />
      <Route path="/candidate/learning-path" component={LearningPath} />
      
      {/* Advanced Certifications */}
      <Route path="/candidate/browse-certifications" component={BrowseCertifications} />
      <Route path="/candidate/certification-tracker" component={CertificationTracker} />
      <Route path="/candidate/ai-learning-path" component={AILearningPath} />
      <Route path="/candidate/blockchain-certificates" component={BlockchainCertificates} />
      
      {/* Profile & Branding */}
      <Route path="/candidate/profile-builder" component={ProfileBuilder} />
      <Route path="/candidate/profile-preview" component={ProfilePreview} />
      <Route path="/candidate/video-cv" component={VideoCV} />
      <Route path="/candidate/infographic-cv" component={InfographicCV} />
      <Route path="/candidate/resume-tips" component={ResumeTips} />
      
      {/* Interview Preparation */}
      <ProtectedRoute path="/candidate/ai-mock-interviews" component={AIMockInterviews} />
      <ProtectedRoute path="/candidate/personal-interview" component={PersonalInterview} />
      <ProtectedRoute path="/candidate/interview-scheduler" component={InterviewScheduler} />
      <ProtectedRoute path="/candidate/interview-feedback" component={InterviewFeedback} />
      
      {/* Career Development */}
      <ProtectedRoute path="/candidate/career-guidance" component={CareerGuidance} />
      <ProtectedRoute path="/candidate/market-trends" component={MarketTrends} />
      <ProtectedRoute path="/candidate/performance-insights" component={PerformanceInsights} />
      <ProtectedRoute path="/candidate/networking" component={Networking} />
      
      {/* Additional Features */}
      <Route path="/candidate/mobile-app" component={MobileApp} />
      <Route path="/candidate/analytics" component={CandidateAnalytics} />
      <Route path="/candidate/settings" component={Settings} />
      
      {/* Certification Views */}
      <Route path="/candidate/test-certification-view" component={TestCertificationView} />
      <Route path="/candidate/project-certification-view" component={ProjectCertificationView} />
      <Route path="/candidate/mock-interview-certification-view" component={MockInterviewCertificationView} />
      
      {/* Legacy/Additional Routes */}
      <Route path="/candidate/linkedin-integration" component={LinkedInIntegration} />
      <Route path="/candidate/project-access" component={ProjectAccess} />
      <Route path="/candidate/project-editor" component={ProjectEditor} />
      <Route path="/candidate/project-editor-enhanced" component={ProjectEditorEnhanced} />
      <Route path="/candidate/test-reports" component={TestReports} />
      <Route path="/candidate/one-on-one-support" component={OneOnOneSupport} />
      <Route path="/candidate/priority-support" component={PrioritySupport} />
      <Route path="/candidate/notifications" component={CandidateNotifications} />
      <Route path="/candidate/subscription" component={CandidateSubscription} />
      <Route path="/candidate/performance" component={Performance} />
      
      {/* Recruiter Platform Routes */}
      <Route path="/recruiter" component={RecruiterDashboard} />
      <Route path="/recruiter/dashboard" component={RecruiterDashboard} />
      <Route path="/recruiter/platform" component={RecruiterPlatform} />
      <Route path="/recruiter/candidates" component={RecruiterCandidates} />
      <Route path="/recruiter/jobs" component={RecruiterJobs} />
      <Route path="/recruiter/talent-intelligence" component={TalentIntelligence} />
      <Route path="/recruiter/ai-discovery" component={AIDiscovery} />

      {/* Admin Platform Routes */}
      <Route path="/admin" component={AdminDashboard} />
      <Route path="/admin/dashboard" component={AdminDashboard} />
      <Route path="/admin/platform" component={AdminPlatform} />
      <Route path="/admin/tenants" component={AdminTenants} />
      <Route path="/admin/users" component={AdminUsers} />
      <Route path="/admin/billing-overview" component={BillingOverview} />
      <Route path="/admin/api-analytics" component={APIAnalytics} />
      <Route path="/admin/partners" component={Partners} />
      <Route path="/admin/revenue" component={Revenue} />
      <Route path="/admin/api-keys" component={APIKeys} />
      <Route path="/admin/integrations" component={Integrations} />

      {/* LMS Platform Routes */}
      <Route path="/lms" component={LMSDashboard} />
      <Route path="/lms/dashboard" component={LMSDashboard} />
      <Route path="/lms/platform" component={LMSPlatform} />
      <Route path="/lms/courses" component={LMSCourses} />
      <Route path="/lms/library" component={LMSLibrary} />
      <Route path="/lms/my-learning" component={MyLearning} />

      {/* Assessment Platform Routes */}
      <Route path="/assessment" component={AssessmentDashboard} />
      <Route path="/assessment/dashboard" component={AssessmentDashboard} />
      <Route path="/assessment/platform" component={AssessmentWrapperDashboard} />
      <Route path="/assessment/browse-tests" component={AssessmentBrowseTests} />
      <Route path="/assessment/test-runner" component={AssessmentTestRunner} />
      <Route path="/assessment/test-runner/:testId" component={AssessmentTestRunner} />
      <Route path="/assessment/test-results" component={AssessmentTestResults} />
      <Route path="/assessment/question-bank" component={AssessmentQuestionBank} />
      <Route path="/assessment/bulk-upload" component={AssessmentBulkUpload} />
      <Route path="/assessment/certifications" component={AssessmentCertifications} />
      <Route path="/assessment/analytics" component={AssessmentAnalytics} />
      <Route path="/assessment/overview" component={AssessmentOverview} />
      <Route path="/assessment/users" component={AssessmentUsers} />
      <Route path="/assessment/blockchain-certificates" component={AssessmentBlockchainCertificates} />
      <Route path="/assessment/courses" component={AssessmentCourses} />
      <Route path="/assessment/practice-tests" component={AssessmentPracticeTests} />

      {/* Organization Management Routes */}
      <Route path="/organization" component={OrganizationManagement} />
      <Route path="/organization/:section" component={OrganizationManagement} />

      {/* Platform Routes */}
      <ProtectedRoute path="/recruiter" component={RecruiterPlatform} />
      <ProtectedRoute path="/admin" component={AdminPlatform} />
      <ProtectedRoute path="/lms" component={LMSPlatform} />
      <ProtectedRoute path="/assessment" component={AssessmentPlatform} />
      
      {/* Other Routes */}
      <ProtectedRoute path="/dashboard" component={Dashboard} />
      <ProtectedRoute path="/billing" component={BillingDashboard} />
      <ProtectedRoute path="/billing-dashboard" component={BillingDashboard} />
      <ProtectedRoute path="/backup-access" component={BackupAccess} />
      <Route path="/auth" component={AuthPage} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <AuthProvider>
          <NavigationProvider>
            <Router />
            <Toaster />
          </NavigationProvider>
        </AuthProvider>
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;