import { 
  Home, 
  Users, 
  Briefcase, 
  Calendar, 
  Settings, 
  BarChart3, 
  FileText, 
  Search, 
  Target, 
  Award, 
  Video, 
  MessageSquare, 
  TrendingUp, 
  Bell, 
  Bookmark, 
  User, 
  Code, 
  FolderOpen, 
  CreditCard, 
  Brain, 
  Eye, 
  Activity, 
  Headphones,
  Smartphone,
  FileImage,
  MapPin,
  MessageCircle,
  FileBarChart,
  Building,
  Shield,
  Database,
  Monitor,
  DollarSign,
  CheckCircle,
  BookOpen,
  GraduationCap,
  PlayCircle,
  PenTool,
  UserCheck,
  Globe,
  BarChart,
  Zap,
  Filter,
  Mail,
  Workflow,
  Link,
  HelpCircle,
  Star,
  Clock,
  Upload,
  Download,
  Handshake,
  Key
} from "lucide-react";

export interface NavigationItem {
  name: string;
  href: string;
  icon: any;
  current?: boolean;
  badge?: string;
  children?: NavigationItem[];
}

export interface NavigationSection {
  title?: string;
  items: NavigationItem[];
}

export interface PlatformConfig {
  platformName: string;
  platformSubtitle: string;
  platformIcon: any;
  platformColor: string;
  planName: string;
  planColor: string;
  sidebarTitle: string;
  sidebarSubtitle: string;
  sidebarSections: NavigationSection[];
  usageData?: {
    label: string;
    current: number;
    max: number;
  }[];
}

// 1. CANDIDATE PLATFORM - Blue Theme
export const candidateNavigation: NavigationSection[] = [
  {
    title: "Dashboard",
    items: [
      { name: "Dashboard", href: "/candidate", icon: BarChart3, current: true },
    ]
  },
  {
    title: "Profile & Branding",
    items: [
      { name: "Profile Builder", href: "/candidate/profile-builder", icon: User },
      { name: "Video CV", href: "/candidate/video-cv", icon: Video },
      { name: "Infographic CV", href: "/candidate/infographic-cv", icon: FileImage },
      { name: "Resume Tips", href: "/candidate/resume-tips", icon: FileText },
      { name: "Profile Preview", href: "/candidate/profile-preview", icon: Eye },
    ]
  },
  {
    title: "Skills & Assessment",
    items: [
      { name: "Skill Tests", href: "/candidate/skill-tests", icon: Target },
      { name: "AI Skill Assessment", href: "/candidate/ai-skill-assessment", icon: Brain },
      { name: "Browse Tests", href: "/candidate/browse-tests", icon: Search },
      { name: "Certifications", href: "/candidate/certifications", icon: Award },
      { name: "Learning Path", href: "/candidate/learning-path", icon: MapPin },
    ]
  },
  {
    title: "Advanced Certifications",
    items: [
      { name: "Browse Certifications", href: "/candidate/browse-certifications", icon: GraduationCap },
      { name: "Certification Tracker", href: "/candidate/certification-tracker", icon: CheckCircle },
      { name: "AI Learning Path", href: "/candidate/ai-learning-path", icon: Brain },
      { name: "Blockchain Certificates", href: "/candidate/blockchain-certificates", icon: Shield },
    ]
  },
  {
    title: "Job Search & Applications", 
    items: [
      { name: "Job Board", href: "/candidate/job-board", icon: Briefcase, badge: "247" },
      { name: "Application Tracker", href: "/candidate/application-tracker", icon: FileText, badge: "12" },
      { name: "Job Alerts", href: "/candidate/job-alerts", icon: Bell, badge: "5" },
      { name: "Saved Jobs", href: "/candidate/saved-jobs", icon: Bookmark, badge: "18" },
    ]
  },
  {
    title: "Interview Preparation",
    items: [
      { name: "AI Mock Interviews", href: "/candidate/ai-mock-interviews", icon: MessageSquare },
      { name: "Interview Scheduler", href: "/candidate/interview-scheduler", icon: Calendar },
      { name: "Interview Feedback", href: "/candidate/interview-feedback", icon: MessageCircle },
      { name: "Personal Interview", href: "/candidate/personal-interview", icon: Users },
    ]
  },
  {
    title: "Career Development",
    items: [
      { name: "Career Guidance", href: "/candidate/career-guidance", icon: TrendingUp },
      { name: "Market Trends", href: "/candidate/market-trends", icon: BarChart3 },
      { name: "Performance Insights", href: "/candidate/performance-insights", icon: Activity },
      { name: "Networking", href: "/candidate/networking", icon: Users },
    ]
  },
  {
    title: "Tools & Integration",
    items: [
      { name: "Assessment Hub", href: "/assessment", icon: Target, badge: "New" },
      { name: "LinkedIn Integration", href: "/candidate/linkedin-integration", icon: Link },
      { name: "Mobile App", href: "/candidate/mobile-app", icon: Smartphone },
      { name: "Project Access", href: "/candidate/project-access", icon: FolderOpen },
      { name: "Project Editor", href: "/candidate/project-editor-enhanced", icon: Code },
    ]
  },
  {
    title: "Analytics & Insights",
    items: [
      { name: "Analytics", href: "/candidate/analytics", icon: BarChart3 },
      { name: "My Performance", href: "/candidate/performance", icon: TrendingUp },
      { name: "Test Reports", href: "/candidate/test-reports", icon: FileBarChart },
    ]
  },
  {
    title: "Support & Services",
    items: [
      { name: "One-on-One Support", href: "/candidate/one-on-one-support", icon: Users },
      { name: "Priority Support", href: "/candidate/priority-support", icon: Headphones },
      { name: "Notifications", href: "/candidate/notifications", icon: Bell },
    ]
  },
  {
    title: "Subscription & Settings",
    items: [
      { name: "Billing & Usage", href: "/billing-dashboard", icon: CreditCard },
      { name: "Candidate Subscription", href: "/candidate/subscription", icon: DollarSign },
      { name: "Settings", href: "/candidate/settings", icon: Settings },
    ]
  }
];

// 2. RECRUITER PLATFORM - Green Theme
export const recruiterNavigation: NavigationSection[] = [
  {
    title: "Core Management",
    items: [
      { name: "Dashboard", href: "/recruiter", icon: BarChart3, current: true },
      { name: "Talent Intelligence", href: "/recruiter/talent-intelligence", icon: Brain },
    ]
  },
  {
    title: "Candidate Discovery",
    items: [
      { name: "AI Candidate Discovery", href: "/recruiter/ai-discovery", icon: Search },
      { name: "Resume Parser", href: "/recruiter/resume-parser", icon: FileText },
      { name: "Talent Pool", href: "/recruiter/talent-pool", icon: Users },
      { name: "Candidate Ranking", href: "/recruiter/candidate-ranking", icon: Star },
    ]
  },
  {
    title: "Job Management",
    items: [
      { name: "Job Management", href: "/recruiter/jobs", icon: Briefcase, badge: "12" },
      { name: "Job Templates", href: "/recruiter/job-templates", icon: FileText },
      { name: "Job Publishing", href: "/recruiter/job-publishing", icon: Upload },
      { name: "Multi-board Distribution", href: "/recruiter/multi-board", icon: Globe },
    ]
  },
  {
    title: "Interview & Assessment",
    items: [
      { name: "Assessment Hub", href: "/assessment", icon: Target, badge: "New" },
      { name: "Interview Pipeline", href: "/recruiter/interview-pipeline", icon: Calendar },
      { name: "Video Interviews", href: "/recruiter/video-interviews", icon: Video },
      { name: "Interview Scorecards", href: "/recruiter/scorecards", icon: CheckCircle },
    ]
  },
  {
    title: "AI-Powered Tools",
    items: [
      { name: "AI Matching", href: "/recruiter/ai-matching", icon: Target },
      { name: "AI Screening", href: "/recruiter/ai-screening", icon: Filter },
      { name: "AI Interview Analysis", href: "/recruiter/ai-interview", icon: MessageSquare },
      { name: "AI Scoring", href: "/recruiter/ai-scoring", icon: Star },
      { name: "AI Command Center", href: "/recruiter/ai-command", icon: Zap },
    ]
  },
  {
    title: "Analytics & Intelligence",
    items: [
      { name: "Recruiter Analytics", href: "/recruiter/analytics", icon: BarChart3 },
      { name: "Predictive Hiring", href: "/recruiter/predictive", icon: TrendingUp },
      { name: "Real-time Analytics", href: "/recruiter/realtime", icon: Activity },
      { name: "Success Prediction", href: "/recruiter/prediction", icon: Target },
      { name: "Market Intelligence", href: "/recruiter/market", icon: BarChart },
      { name: "Diversity Metrics", href: "/recruiter/diversity", icon: Users },
    ]
  },
  {
    title: "Automation & Workflow",
    items: [
      { name: "Workflow Automation", href: "/recruiter/automation", icon: Workflow },
      { name: "Email Templates", href: "/recruiter/email-templates", icon: Mail },
      { name: "Bulk Operations", href: "/recruiter/bulk-ops", icon: Database },
    ]
  },
  {
    title: "Employer Branding",
    items: [
      { name: "Company Profile", href: "/recruiter/company-profile", icon: Building },
      { name: "Candidate Experience", href: "/recruiter/candidate-experience", icon: Star },
      { name: "Brand Analytics", href: "/recruiter/brand-analytics", icon: BarChart3 },
    ]
  },
  {
    title: "Business Management",
    items: [
      { name: "Team Collaboration", href: "/recruiter/team", icon: Users },
      { name: "Billing & Usage", href: "/billing-dashboard", icon: CreditCard },
      { name: "Cost Analytics", href: "/recruiter/cost-analytics", icon: DollarSign },
      { name: "Subscription Management", href: "/recruiter/subscription", icon: Star },
    ]
  },
  {
    title: "Settings & Configuration",
    items: [
      { name: "Recruiter Settings", href: "/recruiter/settings", icon: Settings },
    ]
  }
];

// 3. ADMIN PLATFORM - Purple Theme
export const adminNavigation: NavigationSection[] = [
  {
    title: "Core Management",
    items: [
      { name: "Dashboard", href: "/admin", icon: BarChart3, current: true },
      { name: "User Management", href: "/admin/users", icon: Users },
      { name: "Organization Settings", href: "/admin/organizations", icon: Building },
    ]
  },
  {
    title: "Assessment Control",
    items: [
      { name: "Assessment Hub", href: "/assessment", icon: Target, badge: "New" },
      { name: "Test Creation", href: "/admin/test-creation", icon: PenTool },
      { name: "Question Bank", href: "/admin/question-bank", icon: Database },
      { name: "Question Upload", href: "/admin/question-upload", icon: Upload },
      { name: "Bulk Question Upload", href: "/admin/bulk-upload", icon: Download },
      { name: "Assessment Analytics", href: "/admin/assessment-analytics", icon: BarChart3 },
    ]
  },
  {
    title: "AI & Content",
    items: [
      { name: "AI Monitoring", href: "/admin/ai-monitoring", icon: Monitor },
      { name: "Content Moderation", href: "/admin/content-moderation", icon: Shield },
      { name: "Media Library", href: "/admin/media-library", icon: FolderOpen },
      { name: "Resume Parser", href: "/admin/resume-parser", icon: FileText },
    ]
  },
  {
    title: "System Operations",
    items: [
      { name: "System Monitoring", href: "/admin/system-monitoring", icon: Monitor },
      { name: "Database Management", href: "/admin/database", icon: Database },
      { name: "Audit Logs", href: "/admin/audit-logs", icon: FileText },
      { name: "Feature Control", href: "/admin/features", icon: Settings },
    ]
  },
  {
    title: "Business Management",
    items: [
      { name: "Billing Overview", href: "/admin/billing-overview", icon: CreditCard },
      { name: "Subscription Management", href: "/admin/subscriptions", icon: Star },
      { name: "Verification Queue", href: "/admin/verification", icon: CheckCircle },
      { name: "Bulk Scheduling", href: "/admin/scheduling", icon: Calendar },
    ]
  },
  {
    title: "API & Partners",
    items: [
      { name: "API Usage Analytics", href: "/admin/api-analytics", icon: TrendingUp },
      { name: "Partner Management", href: "/admin/partners", icon: Users },
      { name: "Revenue Tracking", href: "/admin/revenue", icon: DollarSign },
      { name: "API Key Management", href: "/admin/api-keys", icon: Settings },
      { name: "Integration Monitoring", href: "/admin/integrations", icon: Monitor },
    ]
  },
  {
    title: "Platform Settings",
    items: [
      { name: "Admin Settings", href: "/admin/settings", icon: Settings },
    ]
  }
];

// 4. LMS PLATFORM - Green Theme (Education Focus)
export const lmsNavigation: NavigationSection[] = [
  {
    title: "Core Learning",
    items: [
      { name: "Dashboard", href: "/lms", icon: BarChart3, current: true },
      { name: "Course Library", href: "/lms/library", icon: BookOpen },
      { name: "My Learning", href: "/lms/my-learning", icon: User },
    ]
  },
  {
    title: "Learning Modules",
    items: [
      { name: "Interactive Courses", href: "/lms/courses", icon: BookOpen, badge: "24" },
      { name: "Video Lectures", href: "/lms/videos", icon: Video },
      { name: "Practice Tests", href: "/lms/practice-tests", icon: Target },
      { name: "Assignments", href: "/lms/assignments", icon: PenTool },
    ]
  },
  {
    title: "Certification Programs",
    items: [
      { name: "Assessment Hub", href: "/assessment", icon: Target, badge: "New" },
      { name: "Browse Certifications", href: "/lms/certifications", icon: Award },
      { name: "Certification Tracker", href: "/lms/cert-tracker", icon: CheckCircle },
      { name: "AI Learning Path", href: "/lms/ai-path", icon: Brain },
      { name: "Blockchain Certificates", href: "/lms/blockchain-certs", icon: Shield },
    ]
  },
  {
    title: "Advanced Features",
    items: [
      { name: "Mentorship Programs", href: "/lms/mentorship", icon: Users },
      { name: "Project-based Learning", href: "/lms/projects", icon: Code },
      { name: "Security Certifications", href: "/lms/security-certs", icon: Shield },
    ]
  },
  {
    title: "Collaboration",
    items: [
      { name: "Study Groups", href: "/lms/study-groups", icon: Users },
      { name: "Peer Learning", href: "/lms/peer-learning", icon: MessageSquare },
      { name: "Discussion Forums", href: "/lms/forums", icon: MessageCircle },
    ]
  },
  {
    title: "Progress Tracking",
    items: [
      { name: "Learning Analytics", href: "/lms/analytics", icon: BarChart3 },
      { name: "Progress Reports", href: "/lms/progress", icon: TrendingUp },
      { name: "Achievement Badges", href: "/lms/badges", icon: Award },
    ]
  },
  {
    title: "Profile & Settings",
    items: [
      { name: "LMS Profile", href: "/lms/profile", icon: User },
      { name: "Billing & Usage", href: "/billing-dashboard", icon: CreditCard },
      { name: "Settings", href: "/lms/settings", icon: Settings },
    ]
  }
];

// Platform Configurations
export const platformConfigs: Record<string, PlatformConfig> = {
  candidate: {
    platformName: "Candidate Portal",
    platformSubtitle: "Your Career Journey Starts Here",
    platformIcon: UserCheck,
    platformColor: "blue",
    planName: "Professional",
    planColor: "blue",
    sidebarTitle: "Candidate Portal",
    sidebarSubtitle: "Build Your Future",
    sidebarSections: candidateNavigation,
    usageData: [
      { label: "Applications", current: 12, max: 50 },
      { label: "Skill Tests", current: 8, max: 20 },
      { label: "AI Sessions", current: 15, max: 30 }
    ]
  },
  recruiter: {
    platformName: "Recruiter Portal",
    platformSubtitle: "Smart Hiring Made Simple",
    platformIcon: Users,
    platformColor: "green",
    planName: "Enterprise",
    planColor: "green",
    sidebarTitle: "Recruiter Portal",
    sidebarSubtitle: "Find Top Talent",
    sidebarSections: recruiterNavigation,
    usageData: [
      { label: "Active Jobs", current: 12, max: 25 },
      { label: "Candidates", current: 247, max: 500 },
      { label: "AI Credits", current: 850, max: 1000 }
    ]
  },
  admin: {
    platformName: "AdminHub",
    platformSubtitle: "System Control Center",
    platformIcon: Shield,
    platformColor: "purple",
    planName: "Super Admin",
    planColor: "purple",
    sidebarTitle: "AdminHub",
    sidebarSubtitle: "Platform Management",
    sidebarSections: adminNavigation,
    usageData: [
      { label: "System Load", current: 68, max: 100 },
      { label: "Active Users", current: 1247, max: 2000 },
      { label: "Storage", current: 45, max: 100 }
    ]
  },
  lms: {
    platformName: "LearningHub",
    platformSubtitle: "Knowledge Empowers Growth",
    platformIcon: GraduationCap,
    platformColor: "emerald",
    planName: "Education Pro",
    planColor: "emerald",
    sidebarTitle: "LearningHub",
    sidebarSubtitle: "Expand Your Skills",
    sidebarSections: lmsNavigation,
    usageData: [
      { label: "Courses", current: 8, max: 15 },
      { label: "Certificates", current: 3, max: 10 },
      { label: "Learning Hours", current: 45, max: 100 }
    ]
  }
};