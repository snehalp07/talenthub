import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage.js";
import { setupAuth } from "./auth.js";
import { insertUserProfileSchema, insertResumeDocumentSchema, insertProfileViewSchema } from "../shared/schema.js";
import path from "path";
import express from "express";
import fs from "fs";
import { exec } from "child_process";
import { promisify } from "util";

export async function registerRoutes(app: Express): Promise<Server> {
  
  // Quick test route
  app.get('/test', (req: Request, res: Response) => {
    res.sendFile(path.join(process.cwd(), 'quick-test.html'));
  });
  // Authentication bypass for development
  const bypassAuth = process.env.NODE_ENV === 'development';
  
  // Setup authentication routes
  setupAuth(app);

  // Health check endpoint
  app.get("/api/health", (req, res) => {
    res.json({ 
      status: 'ok', 
      timestamp: new Date().toISOString(),
      platform: 'TalentHub Multi-Platform SaaS',
      version: '1.0.0'
    });
  });

  // Static documentation files served directly 
  app.use('/docs', express.static('.', {
    setHeaders: (res, path) => {
      if (path.endsWith('.html')) {
        res.setHeader('Content-Type', 'text/html; charset=utf-8');
        res.setHeader('Content-Disposition', 'inline');
      } else if (path.endsWith('.md')) {
        res.setHeader('Content-Type', 'text/markdown; charset=utf-8');
        res.setHeader('Content-Disposition', 'attachment');
      }
    }
  }));

  // MVP ZIP files served for download
  app.use('/mvpzip', express.static('./mvpzip', {
    setHeaders: (res, path) => {
      if (path.endsWith('.tar.gz')) {
        res.setHeader('Content-Type', 'application/gzip');
        res.setHeader('Content-Disposition', 'attachment');
      }
    }
  }));

  // Optimized MVP ZIP files served for download
  app.use('/mvpzip1', express.static('./mvpzip1', {
    setHeaders: (res, path) => {
      if (path.endsWith('.tar.gz')) {
        res.setHeader('Content-Type', 'application/gzip');
        res.setHeader('Content-Disposition', 'attachment');
      } else if (path.endsWith('.html')) {
        res.setHeader('Content-Type', 'text/html; charset=utf-8');
        res.setHeader('Content-Disposition', 'inline');
      }
    }
  }));

  // Backup files served for download
  app.use('/backup', express.static('./backup', {
    setHeaders: (res, path) => {
      if (path.endsWith('.tar.gz')) {
        res.setHeader('Content-Type', 'application/gzip');
        res.setHeader('Content-Disposition', 'attachment');
      } else if (path.endsWith('.md')) {
        res.setHeader('Content-Type', 'text/markdown; charset=utf-8');
        res.setHeader('Content-Disposition', 'inline');
      }
    }
  }));

  // Direct backup download endpoint
  app.get("/api/download/backup", async (req, res) => {
    try {
      const filePath = path.join(process.cwd(), 'backup', 'talenthub-recruiter-settings-20250625-101247.tar.gz');
      const fileName = 'talenthub-recruiter-settings-20250625-101247.tar.gz';
      
      res.setHeader('Content-Type', 'application/gzip');
      res.setHeader('Content-Disposition', `attachment; filename="${fileName}"`);
      res.setHeader('Content-Length', fs.statSync(filePath).size);
      
      const fileStream = fs.createReadStream(filePath);
      fileStream.pipe(res);
    } catch (error) {
      console.error('Backup download error:', error);
      res.status(404).json({ error: 'Backup file not found' });
    }
  });

  // Requirements document download endpoint
  app.get("/api/download/requirements", async (req, res) => {
    try {
      const filePath = path.join(process.cwd(), 'requirementdoc', 'TalentHub-Requirements-Analysis.html');
      const fileName = 'TalentHub-Requirements-Analysis.html';
      
      res.setHeader('Content-Type', 'text/html');
      res.setHeader('Content-Disposition', `attachment; filename="${fileName}"`);
      res.setHeader('Content-Length', fs.statSync(filePath).size);
      
      const fileStream = fs.createReadStream(filePath);
      fileStream.pipe(res);
    } catch (error) {
      console.error('Requirements download error:', error);
      res.status(404).json({ error: 'Requirements document not found' });
    }
  });

  // Complete navigation structure download endpoint
  app.get("/api/download/complete-navigation", async (req, res) => {
    try {
      const filePath = path.join(process.cwd(), 'featuredoc', 'TalentHub-Complete-Navigation-Structure.html');
      const fileName = 'TalentHub-Complete-Navigation-Structure.html';
      
      res.setHeader('Content-Type', 'text/html');
      res.setHeader('Content-Disposition', `attachment; filename="${fileName}"`);
      res.setHeader('Content-Length', fs.statSync(filePath).size);
      
      const fileStream = fs.createReadStream(filePath);
      fileStream.pipe(res);
    } catch (error) {
      console.error('Complete navigation download error:', error);
      res.status(404).json({ error: 'Complete navigation document not found' });
    }
  });

  // Navigation analysis download endpoint
  app.get("/api/download/navigation", async (req, res) => {
    try {
      const filePath = path.join(process.cwd(), 'requirementdoc', 'TalentHub-Navigation-Analysis.html');
      const fileName = 'TalentHub-Navigation-Analysis.html';
      
      res.setHeader('Content-Type', 'text/html');
      res.setHeader('Content-Disposition', `attachment; filename="${fileName}"`);
      res.setHeader('Content-Length', fs.statSync(filePath).size);
      
      const fileStream = fs.createReadStream(filePath);
      fileStream.pipe(res);
    } catch (error) {
      console.error('Navigation analysis download error:', error);
      res.status(404).json({ error: 'Navigation analysis document not found' });
    }
  });

  // Feature list CSV download endpoint
  app.get("/api/download/feature-list", async (req, res) => {
    try {
      const filePath = path.join(process.cwd(), 'TalentHub-Complete-Feature-List.csv');
      const fileName = 'TalentHub-Complete-Feature-List.csv';
      
      // Check if file exists
      if (!fs.existsSync(filePath)) {
        return res.status(404).json({ error: 'Feature list CSV file not found' });
      }
      
      res.setHeader('Content-Type', 'text/csv; charset=utf-8');
      res.setHeader('Content-Disposition', `attachment; filename="${fileName}"`);
      res.setHeader('Content-Length', fs.statSync(filePath).size);
      
      const fileStream = fs.createReadStream(filePath);
      fileStream.pipe(res);
    } catch (error) {
      console.error('Feature list CSV download error:', error);
      res.status(500).json({ error: 'Error downloading feature list CSV' });
    }
  });

  // Feature list download page
  app.get("/csv", async (req, res) => {
    try {
      const filePath = path.resolve(process.cwd(), 'feature-list-download.html');
      
      // Check if file exists first
      if (!fs.existsSync(filePath)) {
        return res.status(404).send('Feature list download page not found');
      }
      
      // Read and serve the HTML content directly
      const htmlContent = fs.readFileSync(filePath, 'utf-8');
      res.setHeader('Content-Type', 'text/html; charset=utf-8');
      res.send(htmlContent);
    } catch (error) {
      console.error('Feature list download page error:', error);
      res.status(500).send('Error loading feature list download page');
    }
  });

  // Feature documentation served for browsing
  app.use('/featuredoc', express.static('./featuredoc', {
    setHeaders: (res, path) => {
      if (path.endsWith('.html')) {
        res.setHeader('Content-Type', 'text/html; charset=utf-8');
        res.setHeader('Content-Disposition', 'inline');
      } else if (path.endsWith('.md')) {
        res.setHeader('Content-Type', 'text/markdown; charset=utf-8');
        res.setHeader('Content-Disposition', 'attachment');
      }
    }
  }));

  // Requirements documentation served for browsing
  app.use('/requirementdoc', express.static('./requirementdoc', {
    setHeaders: (res, path) => {
      if (path.endsWith('.html')) {
        res.setHeader('Content-Type', 'text/html; charset=utf-8');
        res.setHeader('Content-Disposition', 'inline');
      } else if (path.endsWith('.md')) {
        res.setHeader('Content-Type', 'text/markdown; charset=utf-8');
        res.setHeader('Content-Disposition', 'attachment');
      }
    }
  }));

  // Architecture PDF download endpoint - direct file download
  app.get("/api/architecture/pdf", async (req, res) => {
    try {
      const filePath = path.join(process.cwd(), 'TalentHub-Complete-Architecture-All-6-Platforms.html');
      res.download(filePath, 'TalentHub-Complete-Architecture-All-6-Platforms.html', (err) => {
        if (err) {
          console.error('Error downloading PDF file:', err);
          res.status(404).send('Documentation file not found');
        }
      });
    } catch (error) {
      console.error('Error serving PDF download:', error);
      res.status(500).json({ error: "Failed to download architecture documentation" });
    }
  });

  // Architecture Markdown download endpoint - direct file download
  app.get("/api/architecture/markdown", async (req, res) => {
    try {
      const filePath = path.join(process.cwd(), 'ARCHITECTURE_FLOW.md');
      res.download(filePath, 'TalentHub-Architecture-Flow.md', (err) => {
        if (err) {
          console.error('Error downloading markdown file:', err);
          res.status(404).send('Documentation file not found');
        }
      });
    } catch (error) {
      console.error('Error serving markdown download:', error);
      res.status(500).json({ error: "Failed to download architecture markdown" });
    }
  });

  // Direct backup download endpoint - serves most recent backup from /backup directory
  app.get("/download", async (req, res) => {
    try {
      console.log("Direct backup download requested");
      
      // Look for the most recent backup in backup folder
      const backupDir = path.join(process.cwd(), 'backup');
      if (!fs.existsSync(backupDir)) {
        return res.status(404).json({ error: "No backup directory found" });
      }
      
      // Find the most recent backup file
      const files = fs.readdirSync(backupDir).filter(file => file.endsWith('.tar.gz'));
      if (files.length === 0) {
        return res.status(404).json({ error: "No backup files found" });
      }
      
      // Get the most recent backup (sorted by name which includes timestamp)
      const latestBackup = files.sort().reverse()[0];
      const backupPath = path.resolve(backupDir, latestBackup);
      
      // Check file exists and get stats
      if (!fs.existsSync(backupPath)) {
        return res.status(404).json({ error: "Backup file not found" });
      }
      
      const stats = fs.statSync(backupPath);
      const fileSizeMB = (stats.size / (1024 * 1024)).toFixed(2);
      
      console.log(`Serving backup: ${latestBackup} (${fileSizeMB}MB)`);
      
      // Set headers for download
      res.setHeader('Content-Type', 'application/gzip');
      res.setHeader('Content-Disposition', `attachment; filename="${latestBackup}"`);
      res.setHeader('Content-Length', stats.size);
      res.setHeader('X-File-Size', `${fileSizeMB}MB`);
      
      const fileStream = fs.createReadStream(backupPath);
      fileStream.pipe(res);
      
      fileStream.on('error', (error) => {
        console.error('Download stream error:', error);
        if (!res.headersSent) {
          res.status(500).json({ error: "Download failed" });
        }
      });
      
    } catch (error) {
      console.error('Download error:', error);
      if (!res.headersSent) {
        res.status(500).json({ error: "Failed to download backup" });
      }
    }
  });



  // Database seeding endpoint for development
  app.post("/api/seed-database", async (req, res) => {
    if (process.env.NODE_ENV !== 'development') {
      return res.status(403).json({ error: "Database seeding only available in development" });
    }
    
    try {
      const { seedSimpleData } = await import('./seed-simple');
      const result = await seedSimpleData();
      res.json(result);
    } catch (error) {
      console.error("Database seeding error:", error);
      res.status(500).json({ error: "Failed to seed database", details: error instanceof Error ? error.message : "Unknown error" });
    }
  });

  // Resource monitoring endpoint
  app.get("/api/system/stats", (req, res) => {
    const stats = {
      memory: process.memoryUsage(),
      uptime: process.uptime(),
      version: process.version,
      platform: process.platform
    };
    res.json(stats);
  });

  // Candidate Platform API Routes
  
  // Performance & Analytics
  
  app.get("/api/candidate/performance/metrics", async (req, res) => {
    if (!bypassAuth && !req.isAuthenticated()) return res.sendStatus(401);
    
    const metrics = {
      skillRating: 4.7,
      testsCompleted: 23,
      averageScore: 87,
      timeSpent: 45,
      certifications: 5,
      profileViews: 142,
      applications: 12,
      interviews: 7
    };
    res.json(metrics);
  });

  app.get("/api/candidate/performance/skills", async (req, res) => {
    if (!bypassAuth && !req.isAuthenticated()) return res.sendStatus(401);
    
    const skills = [
      { skill: "JavaScript", currentLevel: 85, targetLevel: 90, progress: 94, trend: 'up', lastAssessment: '2 days ago' },
      { skill: "React", currentLevel: 78, targetLevel: 85, progress: 92, trend: 'up', lastAssessment: '1 week ago' },
      { skill: "Python", currentLevel: 65, targetLevel: 80, progress: 81, trend: 'stable', lastAssessment: '3 days ago' },
      { skill: "System Design", currentLevel: 55, targetLevel: 75, progress: 73, trend: 'up', lastAssessment: '5 days ago' },
    ];
    res.json(skills);
  });

  app.get("/api/candidate/performance/achievements", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    
    const achievements = [
      { id: '1', title: 'React Expert', description: 'Completed advanced React certification', date: '2024-06-10', type: 'certification', badge: '🚀' },
      { id: '2', title: 'Top Performer', description: 'Scored in top 10% on JavaScript assessment', date: '2024-06-08', type: 'test', badge: '🏆' },
      { id: '3', title: 'Skill Master', description: 'Achieved 90%+ in 5 different skills', date: '2024-06-05', type: 'skill', badge: '⭐' },
      { id: '4', title: 'Interview Champion', description: 'Completed 5 successful interviews', date: '2024-06-01', type: 'milestone', badge: '💼' },
    ];
    res.json(achievements);
  });

  // Public test browsing endpoints
  app.get("/api/public/tests", async (req, res) => {
    try {
      const tenantId = 1; // Use default tenant for public tests
      const allTests = await storage.getTests(tenantId);
      
      // Return all tests for browsing (demo environment)
      const publicTests = allTests.map(test => ({
        id: test.id,
        title: test.title,
        description: test.description || '',
        duration: test.duration,
        totalQuestions: test.totalQuestions,
        passingScore: test.passingScore,
        isPublic: true, // Set to true for demo
        status: test.status,
        createdAt: test.createdAt,
        subject: test.category || 'General'
      }));
      
      res.json(publicTests);
    } catch (error) {
      console.error('Error fetching public tests:', error);
      res.status(500).json({ error: "Failed to fetch public tests" });
    }
  });

  app.get("/api/subjects", async (req, res) => {
    try {
      const tenantId = 1;
      const tests = await storage.getTests(tenantId);
      
      // Extract unique categories from tests
      const subjects = Array.from(new Set(tests.map(test => test.category).filter(Boolean)));
      
      res.json(subjects.length > 0 ? subjects : ['JavaScript', 'Python', 'React', 'Node.js', 'Database']);
    } catch (error) {
      console.error('Error fetching subjects:', error);
      res.json(['JavaScript', 'Python', 'React', 'Node.js', 'Database']); // Fallback subjects
    }
  });

  // Candidate job applications endpoint
  app.get("/api/candidate/job-applications", async (req, res) => {
    try {
      const tenantId = req.user?.tenantId || 1;
      const userId = req.user?.id || 1;
      
      // Get job applications for the user
      const jobApplications = await storage.getJobApplications(userId, tenantId);
      
      // Format applications with job details
      const formattedApplications = jobApplications.map(app => ({
        id: app.id,
        jobTitle: 'Software Engineer', // Default since JobApplication doesn't store job details
        company: 'Tech Company',
        location: 'Remote',
        appliedDate: app.appliedDate ? new Date(app.appliedDate).toISOString().split('T')[0] : new Date().toISOString().split('T')[0],
        status: app.status || 'applied',
        statusText: getStatusText(app.status || 'applied'),
        salary: '$100,000 - $120,000',
        notes: app.coverLetter || app.notes || '',
        interviewDate: null,
        recruiterContact: null,
        feedback: null,
        offerDeadline: null
      }));
      
      res.json(formattedApplications);
    } catch (error) {
      console.error('Error fetching job applications:', error);
      res.status(500).json({ error: "Failed to fetch job applications" });
    }
  });

  function getStatusText(status: string): string {
    switch (status) {
      case 'applied': return 'Application Sent';
      case 'under_review': return 'Under Review';
      case 'interview_scheduled': return 'Interview Scheduled';
      case 'interview_completed': return 'Interview Completed';
      case 'offer_received': return 'Offer Received';
      case 'rejected': return 'Not Selected';
      case 'withdrawn': return 'Withdrawn';
      default: return 'Application Sent';
    }
  }

  // Test & Assessment Routes
  app.get("/api/candidate/tests", async (req, res) => {
    try {
      // Use default tenant and user for demo
      const tenantId = req.user?.tenantId || 1;
      const userId = req.user?.id || 1;
      
      console.log('Fetching tests for tenant:', tenantId, 'user:', userId);
      
      const availableTests = await storage.getTests(tenantId);
      console.log('Available tests:', availableTests.length);
      
      // Get user attempts with error handling
      let userAttempts = [];
      try {
        userAttempts = await storage.getTestAttempts(userId, tenantId);
        console.log('User attempts:', userAttempts.length);
      } catch (attemptError) {
        console.error('Error fetching test attempts:', attemptError);
        // Continue without attempts data
      }
      
      // Enrich tests with user attempt data
      const enrichedTests = availableTests.map(test => {
        const attempts = userAttempts.filter(attempt => attempt.testId === test.id);
        const bestScore = attempts.length > 0 ? Math.max(...attempts.map(a => a.score || 0)) : undefined;
        const hasCompleted = attempts.some(a => a.status === 'completed');
        
        return {
          ...test,
          attempts: attempts.length,
          bestScore,
          status: hasCompleted ? 'completed' : 'available'
        };
      });
      
      console.log('Returning', enrichedTests.length, 'enriched tests');
      res.json(enrichedTests);
    } catch (error) {
      console.error('Error in /api/candidate/tests:', error);
      res.status(500).json({ error: "Failed to fetch tests", details: error.message });
    }
  });

  app.get("/api/candidate/tests/:id", async (req, res) => {
    // Temporarily disable auth for demo
    // if (!req.isAuthenticated()) return res.sendStatus(401);
    
    try {
      const { id } = req.params;
      // Use default tenant for demo
      const tenantId = req.user?.tenantId || 1;
      
      const test = await storage.getTest(id, tenantId);
      if (!test) {
        return res.status(404).json({ error: "Test not found" });
      }
      
      const questions = await storage.getTestQuestions(id);
      
      res.json({
        ...test,
        questions
      });
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch test details" });
    }
  });

  app.post("/api/tests/:id/submit", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    
    try {
      const { answers, timeSpent } = req.body;
      const { id: testId } = req.params;
      const user = req.user!;
      
      // Get test and questions to calculate real score
      const test = await storage.getTest(testId, user.tenantId);
      if (!test) {
        return res.status(404).json({ error: "Test not found" });
      }
      
      const questions = await storage.getTestQuestions(testId);
      
      // Calculate actual score based on correct answers
      let correctAnswers = 0;
      let totalPoints = 0;
      
      questions.forEach(question => {
        totalPoints += question.points || 1;
        const userAnswer = answers[question.id];
        
        if (question.type === 'multiple_choice' && userAnswer === question.correctAnswer) {
          correctAnswers += question.points || 1;
        } else if (question.type === 'coding' && userAnswer && userAnswer.trim().length > 0) {
          // For coding questions, give partial credit if there's an attempt
          correctAnswers += Math.floor((question.points || 1) * 0.7);
        }
      });
      
      const score = Math.round((correctAnswers / totalPoints) * 100);
      const passed = score >= test.passingScore;
      
      // Create test attempt record
      const attempt = await storage.createTestAttempt({
        id: `attempt_${Date.now()}_${user.id}`,
        testId,
        userId: user.id,
        tenantId: user.tenantId,
        answers,
        score,
        timeSpent,
        completedAt: new Date(),
        status: 'completed'
      });
      
      // If passed and score is high enough, create certification
      if (passed && score >= 85) {
        await storage.createCertification({
          id: `cert_${testId}_${Date.now()}`,
          title: `${test.title} Certification`,
          description: `Certification for completing ${test.title} with a score of ${score}%`,
          type: 'test',
          issuer: 'talenthub_academy',
          userId: user.id,
          tenantId: user.tenantId,
          score,
          passingScore: test.passingScore,
          credentialId: `TH-${testId.toUpperCase()}-${Date.now()}`,
          verificationUrl: `https://verify.talenthub.com/cert_${testId}_${Date.now()}`,
          skills: test.tags || [],
          metadata: {
            testId,
            completionDate: new Date().toISOString(),
            timeSpent,
            difficulty: test.difficulty
          }
        });
      }
      
      const result = {
        ...attempt,
        passed,
        breakdown: {
          correct: correctAnswers,
          total: totalPoints,
          percentage: score
        }
      };
      
      res.json(result);
    } catch (error) {
      console.error('Test submission error:', error);
      res.status(500).json({ error: "Failed to submit test" });
    }
  });

  // Certification Routes
  app.get("/api/candidate/certifications", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    
    try {
      const user = req.user!;
      const certifications = await storage.getCertifications(user.id, user.tenantId);
      res.json(certifications);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch certifications" });
    }
  });

  app.get("/api/candidate/certifications/test/:id", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    
    const certification = {
      id: req.params.id,
      testTitle: "Advanced JavaScript Fundamentals",
      certificationTitle: "JavaScript Expert Certification", 
      description: "Comprehensive assessment covering advanced JavaScript concepts",
      completedDate: "2024-06-10T14:30:00Z",
      score: 92,
      passingScore: 80,
      timeSpent: 45,
      totalQuestions: 50,
      correctAnswers: 46,
      difficulty: "Advanced",
      skills: ["JavaScript", "ES6+", "Async Programming", "Design Patterns"]
    };
    res.json(certification);
  });

  // Projects Routes
  app.get("/api/candidate/projects", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    
    const projects = [
      {
        id: "1",
        name: "E-commerce React App",
        description: "Full-stack e-commerce application with React and Node.js",
        language: "JavaScript",
        framework: "React",
        created: "2024-06-01",
        lastModified: "2024-06-10",
        status: "in_progress",
        files: []
      }
    ];
    res.json(projects);
  });

  app.post("/api/projects/:id/test", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    
    const results = [
      { id: "test1", fileName: "App.test.js", status: "passed", message: "All components render correctly", duration: 245 },
      { id: "test2", fileName: "utils.test.js", status: "passed", message: "Utility functions work as expected", duration: 156 },
      { id: "test3", fileName: "api.test.js", status: "failed", message: "API endpoint timeout", duration: 5000 }
    ];
    
    res.json({ results });
  });

  // Job Board Routes
  app.get("/api/candidate/jobs", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    
    const jobs = [
      {
        id: "job-1",
        title: "Senior Frontend Developer",
        company: "TechCorp Inc.",
        location: "San Francisco, CA",
        type: "Full-time",
        remote: true,
        salary: { min: 120000, max: 160000 },
        postedDate: "2024-06-08",
        description: "Join our team building next-generation web applications",
        requirements: ["5+ years React", "TypeScript", "System Design"],
        benefits: ["Health Insurance", "401k", "Remote Work"],
        matchScore: 92
      },
      {
        id: "job-2", 
        title: "Full Stack Engineer",
        company: "StartupXYZ",
        location: "New York, NY",
        type: "Full-time", 
        remote: false,
        salary: { min: 100000, max: 140000 },
        postedDate: "2024-06-07",
        description: "Build scalable web applications from frontend to backend",
        requirements: ["React", "Node.js", "PostgreSQL"],
        benefits: ["Equity", "Flexible Hours", "Learning Budget"],
        matchScore: 87
      }
    ];
    res.json(jobs);
  });

  // User Settings Routes
  app.get("/api/candidate/settings", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    
    const settings = {
      profile: {
        firstName: "Alex",
        lastName: "Johnson", 
        email: "alex.johnson@email.com",
        phone: "+1 (555) 123-4567",
        location: "San Francisco, CA",
        bio: "Full-stack developer with 5+ years experience",
        website: "https://alexjohnson.dev",
        linkedin: "https://linkedin.com/in/alexjohnson",
        github: "https://github.com/alexjohnson"
      },
      preferences: {
        emailNotifications: true,
        smsNotifications: false,
        profilePublic: true,
        theme: "light",
        language: "en"
      }
    };
    res.json(settings);
  });

  app.put("/api/candidate/settings", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    
    // In real implementation, update user settings in database
    res.json({ success: true, message: "Settings updated successfully" });
  });

  // Backup management routes
  app.get('/api/backup/status', (req, res) => {
    const fs = require('fs');
    const backupDir = path.join(process.cwd(), 'backup');
    const downloadDir = path.join(process.cwd(), 'download');
    
    try {
      const backupFiles = fs.readdirSync(backupDir).filter((file: string) => file.endsWith('.tar.gz'));
      const downloadFiles = fs.readdirSync(downloadDir).filter((file: string) => file.endsWith('.tar.gz'));
      
      const latestBackup = backupFiles.sort().reverse()[0];

      res.json({
        success: true,
        latestBackup,
        backupFiles,
        downloadFiles,
        downloadPath: `/download/${latestBackup}`,
        message: "Backup available for download"
      });
    } catch (error) {
      res.status(500).json({ success: false, error: "Failed to access backup files" });
    }
  });

  // Serve backup files directly
  app.use('/backup', express.static(path.join(process.cwd(), 'backup')));

  // Dashboard metrics endpoint
  app.get("/api/dashboard", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Not authenticated" });
    }

    try {
      const user = req.user;
      const metrics = await storage.getDashboardMetrics(user.tenantId, user.id);
      const recentCandidates = await storage.getRecentCandidates(user.tenantId, 5);
      const usageSummary = await storage.getUsageSummary(user.tenantId);
      const tenant = await storage.getTenant(user.tenantId);

      res.json({
        metrics,
        recentCandidates,
        usageSummary,
        tenant,
        user,
      });
    } catch (error) {
      console.error('Dashboard error:', error);
      res.status(500).json({ message: "Failed to load dashboard data" });
    }
  });

  // Jobs endpoints
  app.get("/api/jobs", async (req, res) => {
    if (!bypassAuth && !req.isAuthenticated()) {
      return res.status(401).json({ message: "Not authenticated" });
    }

    try {
      const tenantId = bypassAuth ? 1 : req.user?.tenantId || 1;
      const jobs = await storage.getJobs(tenantId);
      res.json(jobs);
    } catch (error) {
      console.error('Jobs error:', error);
      res.status(500).json({ message: "Failed to load jobs" });
    }
  });

  app.post("/api/jobs", async (req, res) => {
    if (!bypassAuth && !req.isAuthenticated()) {
      return res.status(401).json({ message: "Not authenticated" });
    }

    if (!bypassAuth && req.user && (req.user.role !== 'recruiter' && req.user.role !== 'admin')) {
      return res.status(403).json({ message: "Insufficient permissions" });
    }

    try {
      const tenantId = bypassAuth ? 1 : req.user?.tenantId || 1;
      const recruiterId = bypassAuth ? 2 : req.user?.id || 2;
      
      const job = await storage.createJob({
        ...req.body,
        tenantId,
        recruiterId,
      });
      
      // Track usage (only if not bypassing auth)
      if (!bypassAuth) {
        await storage.trackUsage({
          tenantId: req.user.tenantId,
          userId: req.user.id,
          feature: 'job_posting',
          count: 1,
        });
      }

      res.status(201).json(job);
    } catch (error) {
      console.error('Create job error:', error);
      res.status(500).json({ message: "Failed to create job" });
    }
  });

  // Applications endpoints
  app.get("/api/applications", async (req, res) => {
    if (!bypassAuth && !req.isAuthenticated()) {
      return res.status(401).json({ message: "Not authenticated" });
    }

    try {
      const tenantId = bypassAuth ? 1 : req.user?.tenantId || 1;
      const applications = await storage.getApplications(tenantId);
      res.json(applications);
    } catch (error) {
      console.error('Applications error:', error);
      res.status(500).json({ message: "Failed to load applications" });
    }
  });

  app.post("/api/applications", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Not authenticated" });
    }

    try {
      const application = await storage.createApplication({
        ...req.body,
        tenantId: req.user.tenantId,
        candidateId: req.user.id,
      });

      res.status(201).json(application);
    } catch (error) {
      console.error('Create application error:', error);
      res.status(500).json({ message: "Failed to create application" });
    }
  });

  // Assessments endpoints
  app.get("/api/assessments", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Not authenticated" });
    }

    try {
      const assessments = await storage.getAssessments(req.user.tenantId);
      res.json(assessments);
    } catch (error) {
      console.error('Assessments error:', error);
      res.status(500).json({ message: "Failed to load assessments" });
    }
  });

  app.post("/api/assessments", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Not authenticated" });
    }

    if (req.user.role !== 'recruiter' && req.user.role !== 'admin') {
      return res.status(403).json({ message: "Insufficient permissions" });
    }

    try {
      const assessment = await storage.createAssessment({
        ...req.body,
        tenantId: req.user.tenantId,
      });

      // Track usage
      await storage.trackUsage({
        tenantId: req.user.tenantId,
        userId: req.user.id,
        feature: 'assessment_creation',
        count: 1,
      });

      res.status(201).json(assessment);
    } catch (error) {
      console.error('Create assessment error:', error);
      res.status(500).json({ message: "Failed to create assessment" });
    }
  });

  // Courses endpoints
  app.get("/api/courses", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Not authenticated" });
    }

    try {
      const courses = await storage.getCourses(req.user.tenantId);
      res.json(courses);
    } catch (error) {
      console.error('Courses error:', error);
      res.status(500).json({ message: "Failed to load courses" });
    }
  });

  app.post("/api/courses", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Not authenticated" });
    }

    if (req.user.role !== 'lms_user' && req.user.role !== 'admin') {
      return res.status(403).json({ message: "Insufficient permissions" });
    }

    try {
      const course = await storage.createCourse({
        ...req.body,
        tenantId: req.user.tenantId,
      });

      res.status(201).json(course);
    } catch (error) {
      console.error('Create course error:', error);
      res.status(500).json({ message: "Failed to create course" });
    }
  });

  // Usage tracking endpoint
  app.post("/api/track-usage", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Not authenticated" });
    }

    try {
      const usage = await storage.trackUsage({
        ...req.body,
        tenantId: req.user.tenantId,
        userId: req.user.id,
      });

      res.status(201).json(usage);
    } catch (error) {
      console.error('Track usage error:', error);
      res.status(500).json({ message: "Failed to track usage" });
    }
  });

  // Phase 2: Draft Applications API Routes
  app.get("/api/candidate/draft-applications", async (req, res) => {
    if (!bypassAuth && !req.isAuthenticated()) return res.sendStatus(401);
    
    const draftApplications = [
      {
        id: "draft_1",
        jobTitle: "Senior React Developer",
        company: "Tech Innovations",
        location: "San Francisco, CA",
        lastEdited: "2024-01-20T10:30:00Z",
        completionStatus: 85,
        coverLetter: "Draft cover letter for React position...",
        templateUsed: "Tech Role Template",
        notes: "Need to add portfolio links"
      },
      {
        id: "draft_2", 
        jobTitle: "Full Stack Engineer",
        company: "StartupCorp",
        location: "Remote",
        lastEdited: "2024-01-19T15:45:00Z", 
        completionStatus: 60,
        coverLetter: "Initial draft for startup position...",
        templateUsed: "Startup Template",
        notes: "Research company culture more"
      }
    ];
    res.json(draftApplications);
  });

  app.post("/api/candidate/draft-applications", async (req, res) => {
    if (!bypassAuth && !req.isAuthenticated()) return res.sendStatus(401);
    
    const { jobId, coverLetter, templateId, notes } = req.body;
    const newDraft = {
      id: `draft_${Date.now()}`,
      jobId,
      coverLetter,
      templateId,
      notes,
      status: "draft",
      lastEdited: new Date().toISOString(),
      completionStatus: 50
    };
    res.status(201).json(newDraft);
  });

  // Phase 2: Application Templates API Routes
  app.get("/api/candidate/application-templates", async (req, res) => {
    if (!bypassAuth && !req.isAuthenticated()) return res.sendStatus(401);
    
    const templates = [
      {
        id: "template_1",
        name: "Tech Role Template",
        description: "Standard template for technical positions",
        coverLetterTemplate: "Dear Hiring Manager,\n\nI am excited to apply for the {jobTitle} position at {company}. With my experience in {skills}, I believe I would be a valuable addition to your team...",
        usageCount: 12,
        isDefault: true,
        category: "Technology",
        lastUsed: "2024-01-18T09:00:00Z"
      },
      {
        id: "template_2",
        name: "Startup Template", 
        description: "Template optimized for startup environments",
        coverLetterTemplate: "Hi {hiringManager},\n\nI'm thrilled about the opportunity to join {company} as a {jobTitle}. Your mission to {companyMission} aligns perfectly with my passion for {passion}...",
        usageCount: 8,
        isDefault: false,
        category: "Startup",
        lastUsed: "2024-01-15T14:30:00Z"
      },
      {
        id: "template_3",
        name: "Enterprise Template",
        description: "Formal template for large enterprise companies",
        coverLetterTemplate: "Dear {hiringManager},\n\nI am writing to express my strong interest in the {jobTitle} position at {company}. With {yearsExperience} years of experience in {industry}...",
        usageCount: 6,
        isDefault: false,
        category: "Enterprise",
        lastUsed: "2024-01-12T11:15:00Z"
      }
    ];
    res.json(templates);
  });

  app.post("/api/candidate/application-templates", async (req, res) => {
    if (!bypassAuth && !req.isAuthenticated()) return res.sendStatus(401);
    
    const { name, description, coverLetterTemplate, category } = req.body;
    const newTemplate = {
      id: `template_${Date.now()}`,
      name,
      description,
      coverLetterTemplate,
      category,
      usageCount: 0,
      isDefault: false,
      createdAt: new Date().toISOString()
    };
    res.status(201).json(newTemplate);
  });

  // Phase 2: Follow-up Reminders API Routes
  app.get("/api/candidate/follow-up-reminders", async (req, res) => {
    if (!bypassAuth && !req.isAuthenticated()) return res.sendStatus(401);
    
    const reminders = [
      {
        id: "reminder_1",
        applicationId: "1",
        jobTitle: "Senior Frontend Developer",
        company: "TechCorp Inc.",
        reminderType: "follow_up",
        reminderDate: "2024-01-25T09:00:00Z",
        message: "Follow up on application status - it's been 1 week",
        isCompleted: false,
        priority: "medium"
      },
      {
        id: "reminder_2", 
        applicationId: "2",
        jobTitle: "Full Stack Engineer",
        company: "StartupXYZ",
        reminderType: "interview_prep",
        reminderDate: "2024-01-23T15:00:00Z",
        message: "Prepare for technical interview - review React concepts",
        isCompleted: false,
        priority: "high"
      },
      {
        id: "reminder_3",
        applicationId: "5",
        jobTitle: "Lead Frontend Engineer", 
        company: "Enterprise Corp",
        reminderType: "thank_you",
        reminderDate: "2024-01-21T10:00:00Z",
        message: "Send thank you email after offer received",
        isCompleted: true,
        completedAt: "2024-01-21T10:30:00Z",
        priority: "low"
      }
    ];
    res.json(reminders);
  });

  app.post("/api/candidate/follow-up-reminders", async (req, res) => {
    if (!bypassAuth && !req.isAuthenticated()) return res.sendStatus(401);
    
    const { applicationId, reminderType, reminderDate, message, priority } = req.body;
    const newReminder = {
      id: `reminder_${Date.now()}`,
      applicationId,
      reminderType,
      reminderDate,
      message,
      priority,
      isCompleted: false,
      createdAt: new Date().toISOString()
    };
    res.status(201).json(newReminder);
  });

  app.patch("/api/candidate/follow-up-reminders/:id", async (req, res) => {
    if (!bypassAuth && !req.isAuthenticated()) return res.sendStatus(401);
    
    const { isCompleted } = req.body;
    const updatedReminder = {
      id: req.params.id,
      isCompleted,
      completedAt: isCompleted ? new Date().toISOString() : null
    };
    res.json(updatedReminder);
  });

  // Phase 2: Success Analytics API Routes  
  app.get("/api/candidate/success-analytics", async (req, res) => {
    if (!bypassAuth && !req.isAuthenticated()) return res.sendStatus(401);
    
    const analytics = {
      overview: {
        totalApplications: 25,
        responseRate: 68,
        interviewRate: 32, 
        offerRate: 12,
        averageResponseTime: 5.2,
        successScore: 84
      },
      applicationTrends: [
        { month: "Oct 2023", applications: 8, responses: 6, interviews: 3, offers: 1 },
        { month: "Nov 2023", applications: 10, responses: 7, interviews: 4, offers: 1 },
        { month: "Dec 2023", applications: 7, responses: 5, interviews: 2, offers: 1 },
        { month: "Jan 2024", applications: 12, responses: 9, interviews: 5, offers: 2 }
      ],
      responseTimeAnalysis: {
        immediate: 15,    // 0-1 days
        quick: 35,        // 2-5 days  
        moderate: 30,     // 6-10 days
        slow: 20          // 10+ days
      },
      industryPerformance: [
        { industry: "Technology", applications: 15, successRate: 73, avgSalary: "$125K" },
        { industry: "Finance", applications: 6, successRate: 50, avgSalary: "$135K" },
        { industry: "Healthcare", applications: 4, successRate: 75, avgSalary: "$95K" }
      ],
      topPerformingTemplates: [
        { template: "Tech Role Template", applications: 12, responseRate: 75, offerRate: 17 },
        { template: "Startup Template", applications: 8, responseRate: 63, offerRate: 13 },
        { template: "Enterprise Template", applications: 5, responseRate: 60, offerRate: 20 }
      ],
      skillsImpact: [
        { skill: "React", applications: 10, successRate: 80, demandTrend: "up" },
        { skill: "Node.js", applications: 8, successRate: 75, demandTrend: "up" },
        { skill: "Python", applications: 7, successRate: 71, demandTrend: "stable" }
      ]
    };
    res.json(analytics);
  });

  // Profile management endpoints
  app.get("/api/profile", async (req, res) => {
    // Bypass auth for demo purposes
    const demoUserId = 2;
    const demoTenantId = 1;

    try {
      const profile = await storage.getUserProfile(demoUserId, demoTenantId);
      const resumeDocuments = await storage.getResumeDocuments(demoUserId, demoTenantId);
      
      // Calculate completion percentage
      const completionData = {
        bio: profile?.bio || '',
        professionalSummary: profile?.professionalSummary || '',
        phone: profile?.phone || '',
        location: profile?.location || '',
        linkedinUrl: profile?.linkedinUrl || '',
        profilePhoto: profile?.profilePhoto || null
      };
      
      const filledFields = Object.values(completionData).filter(val => val && val.toString().length > 0).length;
      const totalFields = Object.keys(completionData).length;
      const profileCompletionScore = Math.round((filledFields / totalFields) * 100);
      
      res.json({
        profile: profile || {
          firstName: 'John',
          lastName: 'Doe', 
          profileCompletionScore: profileCompletionScore,
          bio: '',
          professionalSummary: '',
          objective: '',
          phone: '',
          location: '',
          website: '',
          linkedinUrl: '',
          githubUrl: '',
          portfolioUrl: '',
          personalBrandStatement: '',
          isPublic: false,
          profilePhoto: null
        },
        analytics: {
          totalViews: 42,
          uniqueViewers: 28,
          viewsByType: [
            { viewerType: 'recruiter', count: 15 },
            { viewerType: 'candidate', count: 8 },
            { viewerType: 'anonymous', count: 19 }
          ]
        },
        resumeDocuments: resumeDocuments || [],
        experience: [],
        education: [],
        skills: [],
        projects: [],
        certifications: [],
        languages: []
      });
    } catch (error) {
      console.error('Get profile error:', error);
      res.status(500).json({ message: "Failed to load profile" });
    }
  });

  app.post("/api/profile", async (req, res) => {
    const demoUserId = 2;
    const demoTenantId = 1;

    try {
      // For demo, accept any profile data without strict validation
      const profileData = {
        ...req.body,
        userId: demoUserId,
        tenantId: demoTenantId
      };
      
      // Check if profile exists
      let profile = await storage.getUserProfile(demoUserId, demoTenantId);
      
      if (profile) {
        // Update existing profile - pass individual fields to avoid schema conflicts
        const updateData = {
          bio: profileData.bio || profile.bio,
          professionalSummary: profileData.professionalSummary || profile.professionalSummary,
          phone: profileData.phone || profile.phone,
          location: profileData.location || profile.location,
          linkedinUrl: profileData.linkedinUrl || profile.linkedinUrl,
          website: profileData.website || profile.website,
          githubUrl: profileData.githubUrl || profile.githubUrl,
          profilePhoto: profileData.profilePhoto || profile.profilePhoto,
          objective: profileData.objective || profile.objective,
          // availability: profileData.availability || profile.availability,
          profileCompletionScore: profileData.profileCompletionScore || profile.profileCompletionScore
        };
        profile = await storage.updateUserProfile(demoUserId, demoTenantId, updateData);
      } else {
        // Create new profile with minimal required fields
        const createData = {
          userId: demoUserId,
          tenantId: demoTenantId,
          bio: profileData.bio || "Bio not provided",
          professionalSummary: profileData.professionalSummary || "Summary not provided",
          phone: profileData.phone || "",
          location: profileData.location || "",
          linkedinUrl: profileData.linkedinUrl || null,
          profilePhoto: null,
          objective: profileData.objective || null,
          website: profileData.website || null,
          githubUrl: profileData.githubUrl || null,
          portfolioUrl: profileData.portfolioUrl || null,
          availability: profileData.availability || "Available",
          experience: [],
          education: [],
          skills: [],
          certifications: [],
          languages: [],
          projects: [],
          achievements: [],
          references: [],
          personalBrandStatement: profileData.personalBrandStatement || null,
          profileCompletionScore: profileData.profileCompletionScore || 0,
          profileVisibility: "public",
          profileStatus: "active"
        };
        profile = await storage.createUserProfile(createData);
      }
      
      res.json({ profile, message: "Profile saved successfully" });
    } catch (error) {
      console.error('Profile save error:', error);
      res.status(500).json({ error: 'Failed to save profile', details: String(error) });
    }
  });

  // Resume document endpoints
  app.get("/api/profile/resumes", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Not authenticated" });
    }

    try {
      const documents = await storage.getResumeDocuments(req.user.id, req.user.tenantId);
      res.json(documents);
    } catch (error) {
      console.error('Get resumes error:', error);
      res.status(500).json({ message: "Failed to load resumes" });
    }
  });

  app.post("/api/profile/resumes", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Not authenticated" });
    }

    try {
      const validatedData = insertResumeDocumentSchema.parse({
        ...req.body,
        userId: req.user.id,
        tenantId: req.user.tenantId,
      });

      const document = await storage.createResumeDocument(validatedData);
      res.status(201).json(document);
    } catch (error) {
      console.error('Upload resume error:', error);
      res.status(500).json({ message: "Failed to upload resume" });
    }
  });

  app.delete("/api/profile/resumes/:id", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Not authenticated" });
    }

    try {
      await storage.deleteResumeDocument(parseInt(req.params.id), req.user.tenantId);
      res.status(204).send();
    } catch (error) {
      console.error('Delete resume error:', error);
      res.status(500).json({ message: "Failed to delete resume" });
    }
  });

  app.put("/api/profile/resumes/:id/primary", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Not authenticated" });
    }

    try {
      await storage.setPrimaryResume(parseInt(req.params.id), req.user.id, req.user.tenantId);
      res.status(204).send();
    } catch (error) {
      console.error('Set primary resume error:', error);
      res.status(500).json({ message: "Failed to set primary resume" });
    }
  });

  // Profile analytics endpoints
  app.get("/api/profile/analytics", async (req, res) => {
    try {
      const demoUserId = 2;
      const demoTenantId = 1;
      
      const analytics = await storage.getProfileAnalytics(demoUserId, demoTenantId);
      res.json(analytics || {
        totalViews: 42,
        uniqueViewers: 28,
        viewsByType: [
          { viewerType: 'recruiter', count: 15 },
          { viewerType: 'candidate', count: 8 },
          { viewerType: 'anonymous', count: 19 }
        ]
      });
    } catch (error) {
      console.error('Get profile analytics error:', error);
      res.status(500).json({ message: "Failed to load profile analytics" });
    }
  });

  app.post("/api/profile/views", async (req, res) => {
    try {
      const demoUserId = 2;
      const demoTenantId = 1;
      
      const viewData = {
        profileUserId: demoUserId,
        viewerId: req.body.viewerId || null,
        viewerType: req.body.viewerType || 'anonymous',
        tenantId: demoTenantId,
        source: req.body.source || 'direct',
        userAgent: req.headers['user-agent'] || '',
        ipAddress: req.ip || '127.0.0.1'
      };
      
      const view = await storage.trackProfileView(viewData);
      res.status(201).json(view);
    } catch (error) {
      console.error('Track profile view error:', error);
      res.status(500).json({ message: "Failed to track profile view" });
    }
  });

  // Profile publish/unpublish endpoints
  app.post("/api/profile/publish", async (req, res) => {
    try {
      const demoUserId = 2;
      const demoTenantId = 1;
      
      const profile = await storage.getUserProfile(demoUserId, demoTenantId);
      if (!profile) {
        return res.status(404).json({ message: "Profile not found" });
      }

      // Calculate current completion score
      const completionData = {
        bio: profile.bio || '',
        professionalSummary: profile.professionalSummary || '',
        phone: profile.phone || '',
        location: profile.location || '',
        linkedinUrl: profile.linkedinUrl || '',
        profilePhoto: profile.profilePhoto || null
      };
      
      const filledFields = Object.values(completionData).filter(val => val && val.toString().length > 0).length;
      const totalFields = Object.keys(completionData).length;
      const currentScore = Math.round((filledFields / totalFields) * 100);

      // Check profile completion score
      if (currentScore < 70) {
        return res.status(400).json({ 
          message: "Profile must be at least 70% complete to publish",
          currentScore: currentScore,
          missingFields: Object.keys(completionData).filter(key => !completionData[key])
        });
      }

      await storage.updateUserProfile(demoUserId, demoTenantId, { 
        isPublic: true
      });

      res.json({ 
        message: "Profile published successfully", 
        isPublic: true,
        profileUrl: `https://talenthub.com/profile/${demoUserId}`
      });
    } catch (error) {
      console.error('Profile publish error:', error);
      res.status(500).json({ message: "Failed to publish profile" });
    }
  });

  app.post("/api/profile/unpublish", async (req, res) => {
    try {
      const demoUserId = 2;
      const demoTenantId = 1;
      
      await storage.updateUserProfile(demoUserId, demoTenantId, { 
        isPublic: false
      });

      res.json({ message: "Profile unpublished successfully", isPublic: false });
    } catch (error) {
      console.error('Profile unpublish error:', error);
      res.status(500).json({ message: "Failed to unpublish profile" });
    }
  });

  // Video CV endpoints
  app.get("/api/video-cv/templates", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Not authenticated" });
    }

    const templates = [
      {
        id: "professional",
        name: "Professional Introduction",
        duration: "60-90 seconds",
        sections: ["Personal intro", "Experience highlights", "Key skills", "Career goals"],
        difficulty: "Beginner",
        description: "Perfect for traditional corporate roles and formal interviews"
      },
      {
        id: "technical",
        name: "Technical Showcase",
        duration: "2-3 minutes",
        sections: ["Tech introduction", "Project demos", "Code walkthrough", "Problem solving"],
        difficulty: "Advanced",
        description: "Ideal for software engineers and technical positions"
      },
      {
        id: "creative",
        name: "Creative Portfolio",
        duration: "90-120 seconds",
        sections: ["Creative intro", "Portfolio showcase", "Design process", "Vision statement"],
        difficulty: "Intermediate",
        description: "Great for designers, artists, and creative professionals"
      }
    ];

    res.json(templates);
  });

  app.get("/api/video-cv/my-videos", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Not authenticated" });
    }

    // Mock data for demonstration - would be stored in database
    const videos = [
      {
        id: "video-1",
        title: "Professional Introduction",
        template: "professional",
        duration: 85,
        status: "published",
        views: 127,
        createdAt: new Date(Date.now() - 86400000 * 5).toISOString(),
        thumbnail: "/thumbnails/video1.jpg",
        analytics: {
          completionRate: 78,
          engagement: 85,
          feedback: "Excellent presentation skills"
        }
      },
      {
        id: "video-2",
        title: "Technical Skills Demo",
        template: "technical",
        duration: 165,
        status: "draft",
        views: 0,
        createdAt: new Date(Date.now() - 86400000 * 2).toISOString(),
        thumbnail: "/thumbnails/video2.jpg",
        analytics: null
      }
    ];

    res.json(videos);
  });

  // Job Board API Endpoints
  app.get("/api/jobs", async (req, res) => {
    try {
      const demoTenantId = 1;
      const jobs = await storage.getJobs(demoTenantId);
      res.json(jobs || []);
    } catch (error) {
      console.error('Get jobs error:', error);
      res.status(500).json({ message: "Failed to fetch jobs" });
    }
  });

  app.get("/api/job-applications", async (req, res) => {
    try {
      const demoUserId = 2;
      const demoTenantId = 1;
      
      const applications = await storage.getJobApplications(demoUserId, demoTenantId);
      res.json(applications || []);
    } catch (error) {
      console.error('Get job applications error:', error);
      res.status(500).json({ message: "Failed to fetch applications" });
    }
  });

  app.post("/api/job-applications", async (req, res) => {
    try {
      const demoUserId = 2;
      const demoTenantId = 1;
      
      const applicationData = {
        ...req.body,
        userId: demoUserId,
        tenantId: demoTenantId,
        appliedDate: new Date(),
        status: "applied"
      };
      
      const application = await storage.createJobApplication(applicationData);
      res.status(201).json(application);
    } catch (error) {
      console.error('Create job application error:', error);
      res.status(500).json({ message: "Failed to submit application" });
    }
  });

  // User profile with extended fields API
  app.get("/api/user-profile", async (req, res) => {
    try {
      const demoUserId = 2;
      const demoTenantId = 1;
      
      const user = await storage.getUser(demoUserId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      res.json({
        ...user,
        // Provide defaults for missing fields
        subscriptionPlan: user.subscriptionPlan || "free",
        subscriptionStatus: user.subscriptionStatus || "active", 
        creditsRemaining: user.creditsRemaining || 100,
        jobIntent: user.jobIntent || "full-time",
        topStrengths: user.topStrengths || ["JavaScript", "React", "Problem Solving"],
        preferredDomain: user.preferredDomain || "technology",
        expectedCtc: user.expectedCtc || "15-20 LPA",
        currentLocation: user.currentLocation || "Bangalore, India",
        willingnessToRelocate: user.willingnessToRelocate || false,
        paymentStatus: user.paymentStatus || "current",
        hasActiveSubscription: user.hasActiveSubscription || true,
        completedAt: new Date().toISOString()
      });
    } catch (error) {
      console.error('Get user profile error:', error);
      res.status(500).json({ message: "Failed to fetch user profile" });
    }
  });

  // Profile data storage (temporary in-memory storage for development)
  const profileData = {
    experiences: [],
    educations: [],
    skills: [],
    projects: []
  };

  // Get user profile entries
  app.get("/api/user/experiences", async (req, res) => {
    try {
      res.json(profileData.experiences);
    } catch (error) {
      console.error('Get experiences error:', error);
      res.status(500).json({ message: "Failed to fetch experiences" });
    }
  });

  app.get("/api/user/educations", async (req, res) => {
    try {
      res.json(profileData.educations);
    } catch (error) {
      console.error('Get educations error:', error);
      res.status(500).json({ message: "Failed to fetch educations" });
    }
  });

  app.get("/api/user/skills", async (req, res) => {
    try {
      res.json(profileData.skills);
    } catch (error) {
      console.error('Get skills error:', error);
      res.status(500).json({ message: "Failed to fetch skills" });
    }
  });

  app.get("/api/user/projects", async (req, res) => {
    try {
      res.json(profileData.projects);
    } catch (error) {
      console.error('Get projects error:', error);
      res.status(500).json({ message: "Failed to fetch projects" });
    }
  });

  // Batch endpoints for Profile Builder
  app.post("/api/user/experiences/batch", async (req, res) => {
    try {
      const { experiences } = req.body;
      if (!Array.isArray(experiences)) {
        return res.status(400).json({ message: "Experiences must be an array" });
      }

      // Add experiences with unique IDs
      const newExperiences = experiences.map((exp, index) => ({
        id: Date.now() + index,
        ...exp
      }));
      
      profileData.experiences.push(...newExperiences);

      res.json({ 
        message: `Successfully added ${experiences.length} experience(s)`,
        count: experiences.length,
        success: true,
        data: newExperiences
      });
    } catch (error) {
      console.error('Batch save experiences error:', error);
      res.status(500).json({ message: "Failed to save experiences" });
    }
  });

  app.post("/api/user/educations/batch", async (req, res) => {
    try {
      const { educations } = req.body;
      if (!Array.isArray(educations)) {
        return res.status(400).json({ message: "Educations must be an array" });
      }

      // Add educations with unique IDs
      const newEducations = educations.map((edu, index) => ({
        id: Date.now() + index,
        ...edu
      }));
      
      profileData.educations.push(...newEducations);

      res.json({ 
        message: `Successfully added ${educations.length} education(s)`,
        count: educations.length,
        success: true,
        data: newEducations
      });
    } catch (error) {
      console.error('Batch save educations error:', error);
      res.status(500).json({ message: "Failed to save educations" });
    }
  });

  app.post("/api/user/skills/batch", async (req, res) => {
    try {
      const { skills } = req.body;
      if (!Array.isArray(skills)) {
        return res.status(400).json({ message: "Skills must be an array" });
      }

      // Add skills with unique IDs
      const newSkills = skills.map((skill, index) => ({
        id: Date.now() + index,
        ...skill
      }));
      
      profileData.skills.push(...newSkills);

      res.json({ 
        message: `Successfully added ${skills.length} skill(s)`,
        count: skills.length,
        success: true,
        data: newSkills
      });
    } catch (error) {
      console.error('Batch save skills error:', error);
      res.status(500).json({ message: "Failed to save skills" });
    }
  });

  app.post("/api/user/projects/batch", async (req, res) => {
    try {
      const { projects } = req.body;
      if (!Array.isArray(projects)) {
        return res.status(400).json({ message: "Projects must be an array" });
      }

      // Add projects with unique IDs
      const newProjects = projects.map((project, index) => ({
        id: Date.now() + index,
        ...project
      }));
      
      profileData.projects.push(...newProjects);

      res.json({ 
        message: `Successfully added ${projects.length} project(s)`,
        count: projects.length,
        success: true,
        data: newProjects
      });
    } catch (error) {
      console.error('Batch save projects error:', error);
      res.status(500).json({ message: "Failed to save projects" });
    }
  });

  // Individual CRUD endpoints for edit/delete functionality

  // Experience CRUD
  app.put("/api/user/experiences/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const experienceIndex = profileData.experiences.findIndex(exp => exp.id === id);
      
      if (experienceIndex === -1) {
        return res.status(404).json({ message: "Experience not found" });
      }

      profileData.experiences[experienceIndex] = { id, ...req.body };
      
      res.json({ 
        message: "Experience updated successfully",
        data: profileData.experiences[experienceIndex]
      });
    } catch (error) {
      console.error('Update experience error:', error);
      res.status(500).json({ message: "Failed to update experience" });
    }
  });

  app.delete("/api/user/experiences/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const experienceIndex = profileData.experiences.findIndex(exp => exp.id === id);
      
      if (experienceIndex === -1) {
        return res.status(404).json({ message: "Experience not found" });
      }

      profileData.experiences.splice(experienceIndex, 1);
      
      res.json({ message: "Experience deleted successfully" });
    } catch (error) {
      console.error('Delete experience error:', error);
      res.status(500).json({ message: "Failed to delete experience" });
    }
  });

  // Education CRUD
  app.put("/api/user/educations/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const educationIndex = profileData.educations.findIndex(edu => edu.id === id);
      
      if (educationIndex === -1) {
        return res.status(404).json({ message: "Education not found" });
      }

      profileData.educations[educationIndex] = { id, ...req.body };
      
      res.json({ 
        message: "Education updated successfully",
        data: profileData.educations[educationIndex]
      });
    } catch (error) {
      console.error('Update education error:', error);
      res.status(500).json({ message: "Failed to update education" });
    }
  });

  app.delete("/api/user/educations/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const educationIndex = profileData.educations.findIndex(edu => edu.id === id);
      
      if (educationIndex === -1) {
        return res.status(404).json({ message: "Education not found" });
      }

      profileData.educations.splice(educationIndex, 1);
      
      res.json({ message: "Education deleted successfully" });
    } catch (error) {
      console.error('Delete education error:', error);
      res.status(500).json({ message: "Failed to delete education" });
    }
  });

  // Skills CRUD
  app.put("/api/user/skills/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const skillIndex = profileData.skills.findIndex(skill => skill.id === id);
      
      if (skillIndex === -1) {
        return res.status(404).json({ message: "Skill not found" });
      }

      profileData.skills[skillIndex] = { id, ...req.body };
      
      res.json({ 
        message: "Skill updated successfully",
        data: profileData.skills[skillIndex]
      });
    } catch (error) {
      console.error('Update skill error:', error);
      res.status(500).json({ message: "Failed to update skill" });
    }
  });

  app.delete("/api/user/skills/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const skillIndex = profileData.skills.findIndex(skill => skill.id === id);
      
      if (skillIndex === -1) {
        return res.status(404).json({ message: "Skill not found" });
      }

      profileData.skills.splice(skillIndex, 1);
      
      res.json({ message: "Skill deleted successfully" });
    } catch (error) {
      console.error('Delete skill error:', error);
      res.status(500).json({ message: "Failed to delete skill" });
    }
  });

  // Projects CRUD
  app.put("/api/user/projects/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const projectIndex = profileData.projects.findIndex(project => project.id === id);
      
      if (projectIndex === -1) {
        return res.status(404).json({ message: "Project not found" });
      }

      profileData.projects[projectIndex] = { id, ...req.body };
      
      res.json({ 
        message: "Project updated successfully",
        data: profileData.projects[projectIndex]
      });
    } catch (error) {
      console.error('Update project error:', error);
      res.status(500).json({ message: "Failed to update project" });
    }
  });

  app.delete("/api/user/projects/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const projectIndex = profileData.projects.findIndex(project => project.id === id);
      
      if (projectIndex === -1) {
        return res.status(404).json({ message: "Project not found" });
      }

      profileData.projects.splice(projectIndex, 1);
      
      res.json({ message: "Project deleted successfully" });
    } catch (error) {
      console.error('Delete project error:', error);
      res.status(500).json({ message: "Failed to delete project" });
    }
  });

  // Certificate Management API Endpoints
  app.get("/api/certificates", async (req, res) => {
    try {
      const demoUserId = 2;
      const demoTenantId = 1;
      
      const certificates = await storage.getCertifications(demoUserId, demoTenantId);
      res.json(certificates || []);
    } catch (error) {
      console.error('Get certificates error:', error);
      res.status(500).json({ message: "Failed to fetch certificates" });
    }
  });

  app.get("/api/certificates/:id", async (req, res) => {
    try {
      const certId = req.params.id;
      const demoTenantId = 1;
      
      const certificate = await storage.getCertification(certId, demoTenantId);
      if (!certificate) {
        return res.status(404).json({ message: "Certificate not found" });
      }
      
      res.json(certificate);
    } catch (error) {
      console.error('Get certificate error:', error);
      res.status(500).json({ message: "Failed to fetch certificate" });
    }
  });

  app.get("/api/certificates/:id/download", async (req, res) => {
    try {
      const certId = req.params.id;
      const demoTenantId = 1;
      
      const certificate = await storage.getCertification(certId, demoTenantId);
      if (!certificate) {
        return res.status(404).json({ message: "Certificate not found" });
      }

      // Generate PDF certificate content
      const pdfContent = `
CERTIFICATE OF ACHIEVEMENT

This certifies that
ALEX JOHNSON

has successfully completed
${certificate.title}

Score: ${certificate.score}%
Level: ${certificate.level}
Date: ${new Date(certificate.issueDate).toLocaleDateString()}
Issuer: ${certificate.issuer}

Credential ID: ${certificate.credentialId}
Verification Code: ${certificate.verificationCode || 'VF-' + certificate.credentialId}

This certificate is digitally signed and blockchain verified.
For verification, visit: https://verify.talenthub.com/${certificate.credentialId}

TALENTHUB ACADEMY
Professional Skills Certification
      `;

      res.setHeader('Content-Type', 'application/pdf');
      res.setHeader('Content-Disposition', `attachment; filename="${certificate.title.replace(/\s+/g, '_')}_Certificate.pdf"`);
      res.send(Buffer.from(pdfContent, 'utf-8'));
    } catch (error) {
      console.error('Download certificate error:', error);
      res.status(500).json({ message: "Failed to download certificate" });
    }
  });

  app.get("/api/certificates/:id/verify", async (req, res) => {
    try {
      const certId = req.params.id;
      const demoTenantId = 1;
      
      const certificate = await storage.getCertification(certId, demoTenantId);
      if (!certificate) {
        return res.status(404).json({ message: "Certificate not found" });
      }

      const verificationData = {
        certificate: {
          id: certificate.id,
          title: certificate.title,
          issuer: certificate.issuer,
          recipient: "Alex Johnson",
          issueDate: certificate.issueDate,
          expiryDate: certificate.expiryDate,
          credentialId: certificate.credentialId,
          score: certificate.score,
          level: certificate.level,
          skills: certificate.skills,
          verified: certificate.verified
        },
        verification: {
          status: "verified",
          verificationCode: certificate.verificationCode || 'VF-' + certificate.credentialId,
          publicUrl: `https://verify.talenthub.com/${certificate.credentialId}`,
          blockchainHash: certificate.certificateHash || 'a1b2c3d4e5f6g7h8i9j0k1l2m3n4o5p6',
          digitalSignature: "valid",
          issuerAuthentication: "verified",
          expiryStatus: new Date(certificate.expiryDate) > new Date() ? "valid" : "expired",
          verificationSteps: [
            {
              step: 1,
              title: "Digital Signature",
              description: "Certificate signed with TalentHub's private key",
              status: "verified",
              details: "SHA-256 hash verified"
            },
            {
              step: 2,
              title: "Blockchain Record",
              description: "Certificate hash recorded on blockchain",
              status: "verified",
              details: "Block #847592 confirmed"
            },
            {
              step: 3,
              title: "Issuer Authentication",
              description: "Issuing authority verified",
              status: "verified",
              details: certificate.issuer
            },
            {
              step: 4,
              title: "Expiry Check",
              description: "Certificate validity period",
              status: new Date(certificate.expiryDate) > new Date() ? "valid" : "expired",
              details: `Valid until ${new Date(certificate.expiryDate).toLocaleDateString()}`
            }
          ]
        }
      };

      res.json(verificationData);
    } catch (error) {
      console.error('Verify certificate error:', error);
      res.status(500).json({ message: "Failed to verify certificate" });
    }
  });

  // Public certificate verification endpoint (no auth required)
  app.get("/verify/:credentialId", async (req, res) => {
    try {
      const credentialId = req.params.credentialId;
      
      // In real implementation, search across all tenants for this credential ID
      const demoTenantId = 1;
      const certificate = await storage.getCertification(credentialId, demoTenantId);
      
      if (!certificate) {
        return res.status(404).json({ 
          error: "Certificate not found",
          message: "The certificate with this credential ID could not be found." 
        });
      }

      const verificationPage = `
<!DOCTYPE html>
<html>
<head>
  <title>Certificate Verification - TalentHub</title>
  <style>
    body { font-family: Arial, sans-serif; max-width: 800px; margin: 0 auto; padding: 20px; }
    .header { text-align: center; border-bottom: 2px solid #0ea5e9; padding-bottom: 20px; }
    .certificate { background: #f8fafc; padding: 30px; border-radius: 10px; margin: 20px 0; }
    .verified { color: #059669; font-weight: bold; }
    .details { margin: 20px 0; }
    .footer { text-align: center; color: #64748b; font-size: 14px; margin-top: 40px; }
  </style>
</head>
<body>
  <div class="header">
    <h1>TalentHub Certificate Verification</h1>
    <p class="verified">✓ VERIFIED CERTIFICATE</p>
  </div>
  
  <div class="certificate">
    <h2>${certificate.title}</h2>
    <p><strong>Recipient:</strong> Alex Johnson</p>
    <p><strong>Issuer:</strong> ${certificate.issuer}</p>
    <p><strong>Issue Date:</strong> ${new Date(certificate.issueDate).toLocaleDateString()}</p>
    <p><strong>Expiry Date:</strong> ${new Date(certificate.expiryDate).toLocaleDateString()}</p>
    <p><strong>Score:</strong> ${certificate.score}%</p>
    <p><strong>Level:</strong> ${certificate.level}</p>
    <p><strong>Credential ID:</strong> ${certificate.credentialId}</p>
    <p><strong>Verification Status:</strong> <span class="verified">Verified & Authentic</span></p>
  </div>
  
  <div class="details">
    <h3>Verification Details</h3>
    <p>✓ Digital signature verified</p>
    <p>✓ Blockchain record confirmed</p>
    <p>✓ Issuer authentication passed</p>
    <p>✓ Certificate validity confirmed</p>
  </div>
  
  <div class="footer">
    <p>This certificate has been verified by TalentHub's secure verification system.</p>
    <p>For questions about this certificate, contact the issuing organization.</p>
  </div>
</body>
</html>
      `;

      res.setHeader('Content-Type', 'text/html');
      res.send(verificationPage);
    } catch (error) {
      console.error('Public verification error:', error);
      res.status(500).send('Verification service temporarily unavailable');
    }
  });

  // Infographic CV endpoints
  app.get("/api/infographic-cv/templates", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Not authenticated" });
    }

    const templates = [
      {
        id: "modern-minimal",
        name: "Modern Minimal",
        description: "Clean design with subtle colors and elegant typography",
        category: "Professional",
        colors: ["#2563eb", "#64748b", "#f8fafc"],
        preview: "/templates/modern-minimal.svg"
      },
      {
        id: "creative-bold",
        name: "Creative Bold",
        description: "Vibrant colors and dynamic layouts for creative roles",
        category: "Creative",
        colors: ["#7c3aed", "#f59e0b", "#ef4444"],
        preview: "/templates/creative-bold.svg"
      },
      {
        id: "tech-focused",
        name: "Tech Focused",
        description: "Data visualization heavy design for technical positions",
        category: "Technical",
        colors: ["#059669", "#0891b2", "#374151"],
        preview: "/templates/tech-focused.svg"
      }
    ];

    res.json(templates);
  });

  // Resume analysis endpoints
  app.get("/api/resume/analysis", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Not authenticated" });
    }

    const analysis = {
      score: 78,
      strengths: [
        "Strong technical skills section",
        "Quantified achievements",
        "Clean formatting",
        "Relevant work experience"
      ],
      improvements: [
        "Add more action verbs",
        "Include soft skills",
        "Optimize for ATS scanning",
        "Add portfolio links"
      ],
      sections: {
        contact: { score: 90, status: "excellent" },
        summary: { score: 75, status: "good" },
        experience: { score: 80, status: "good" },
        skills: { score: 85, status: "excellent" },
        education: { score: 70, status: "average" },
        projects: { score: 60, status: "needs_improvement" }
      }
    };

    res.json(analysis);
  });

  // AI profile optimization endpoint
  app.post("/api/profile/optimize", async (req, res) => {
    // For demo, skip authentication
    const demoUserId = 2;
    const demoTenantId = 1;

    try {
      // Get current profile
      const profile = await storage.getUserProfile(demoUserId, demoTenantId);
      
      // AI-powered optimization suggestions
      const suggestions = {
        bio: profile?.bio ? 
          `${profile.bio} | Expert in driving innovation and delivering results in fast-paced environments.` :
          "Results-driven professional with expertise in strategic planning and team leadership.",
        professionalSummary: profile?.professionalSummary ?
          `${profile.professionalSummary} Proven track record of exceeding targets and fostering collaborative team environments.` :
          "Experienced professional with a passion for innovation and excellence in project delivery.",
        improvements: [
          "Enhanced professional summary with industry keywords",
          "Strengthened bio with achievement-focused language",
          "Added quantifiable metrics where applicable",
          "Improved keyword optimization for better visibility"
        ]
      };

      // Update profile with optimized content
      if (profile) {
        await storage.updateUserProfile(demoUserId, demoTenantId, {
          bio: suggestions.bio,
          professionalSummary: suggestions.professionalSummary
        });
      }

      res.json({ 
        message: "Profile optimized successfully with AI suggestions",
        suggestions: suggestions.improvements,
        optimizedContent: {
          bio: suggestions.bio,
          professionalSummary: suggestions.professionalSummary
        }
      });
    } catch (error) {
      console.error('Profile optimization error:', error);
      res.status(500).json({ message: "Failed to optimize profile" });
    }
  });

  // COMPREHENSIVE BILLING SYSTEM API ROUTES

  // Admin billing overview routes
  app.get("/api/admin/billing/overview", async (req, res) => {
    // Temporarily disable auth for testing
    // if (!req.isAuthenticated() || req.user.role !== 'admin') {
    //   return res.status(403).json({ message: "Admin access required" });
    // }

    try {
      // Comprehensive billing overview data for admin
      const billingOverview = [
        {
          tenantId: 1,
          tenantName: "TalentHub Demo",
          subscriptionStatus: "active",
          currentPlan: "Professional",
          monthlyRevenue: 99.00,
          lastPayment: new Date("2025-06-01"),
          nextPayment: new Date("2025-07-01"),
          outstandingAmount: 0,
          alerts: 0
        },
        {
          tenantId: 2,
          tenantName: "StartupXYZ Inc",
          subscriptionStatus: "past_due",
          currentPlan: "Starter",
          monthlyRevenue: 29.00,
          lastPayment: new Date("2025-05-01"),
          nextPayment: new Date("2025-06-01"),
          outstandingAmount: 58.00,
          alerts: 3
        },
        {
          tenantId: 3,
          tenantName: "Enterprise Corp",
          subscriptionStatus: "active",
          currentPlan: "Enterprise",
          monthlyRevenue: 299.00,
          lastPayment: new Date("2025-06-01"),
          nextPayment: new Date("2025-07-01"),
          outstandingAmount: 0,
          alerts: 1
        }
      ];
      res.json(billingOverview);
    } catch (error) {
      console.error('Admin billing overview error:', error);
      res.status(500).json({ message: "Failed to get billing overview" });
    }
  });

  app.get("/api/admin/billing/alerts", async (req, res) => {
    // Temporarily disable auth for testing
    // if (!req.isAuthenticated() || req.user.role !== 'admin') {
    //   return res.status(403).json({ message: "Admin access required" });
    // }

    try {
      const alerts = [
        {
          id: 1,
          tenantId: 2,
          tenantName: "StartupXYZ Inc",
          title: "Payment Failed",
          message: "Monthly subscription payment of $29.00 failed. Account will be suspended in 3 days.",
          severity: "critical",
          createdAt: new Date("2025-06-10"),
          resolved: false
        },
        {
          id: 2,
          tenantId: 2,
          title: "Usage Limit Exceeded",
          message: "Profile views (1200/1000) exceeded plan limit. Overage charges apply.",
          severity: "warning",
          createdAt: new Date("2025-06-12"),
          resolved: false
        },
        {
          id: 3,
          tenantId: 3,
          title: "High Usage Alert",
          message: "80% of monthly AI credits used. Consider upgrading plan.",
          severity: "info",
          createdAt: new Date("2025-06-13"),
          resolved: false
        }
      ];
      res.json(alerts);
    } catch (error) {
      console.error('Admin billing alerts error:', error);
      res.status(500).json({ message: "Failed to get billing alerts" });
    }
  });

  // Subscription plans management
  app.get("/api/billing/plans", async (req, res) => {
    try {
      const plans = [
        {
          id: 1,
          name: "Starter",
          description: "Perfect for small teams and individual professionals",
          price: 29.00,
          billingCycle: "monthly",
          features: {
            profileViews: 1000,
            jobPostings: 5,
            aiCredits: 100,
            videoUploads: 2,
            assessments: 10
          }
        },
        {
          id: 2,
          name: "Professional",
          description: "Advanced features for growing businesses",
          price: 99.00,
          billingCycle: "monthly",
          features: {
            profileViews: 5000,
            jobPostings: 25,
            aiCredits: 500,
            videoUploads: 10,
            assessments: 50
          }
        },
        {
          id: 3,
          name: "Enterprise",
          description: "Unlimited access with premium support",
          price: 299.00,
          billingCycle: "monthly",
          features: {
            profileViews: -1,
            jobPostings: -1,
            aiCredits: -1,
            videoUploads: -1,
            assessments: -1
          }
        }
      ];
      res.json(plans);
    } catch (error) {
      console.error('Get subscription plans error:', error);
      res.status(500).json({ message: "Failed to get subscription plans" });
    }
  });

  // User billing interface routes
  app.get("/api/billing/subscription", async (req, res) => {
    // Temporarily disable auth for testing
    // if (!req.isAuthenticated()) {
    //   return res.status(401).json({ message: "Not authenticated" });
    // }

    try {
      // Dynamic subscription data based on user's tenant
      const tenantSubscriptions = {
        1: { // LearnWise Academy - Education Pro Plan
          subscription: {
            id: 1,
            tenantId: 1,
            planId: 2,
            status: "active",
            currentPeriodStart: new Date("2025-06-01"),
            currentPeriodEnd: new Date("2025-07-01"),
            nextPaymentDate: new Date("2025-07-01"),
            amount: 149.00
          },
          plan: {
            id: 2,
            name: "Education Pro",
            description: "Advanced learning management with unlimited courses and students",
            price: 149.00,
            billingCycle: "monthly"
          }
        },
        2: { // Small Learning Center - Learning Starter Plan
          subscription: {
            id: 2,
            tenantId: 2,
            planId: 1,
            status: "active",
            currentPeriodStart: new Date("2025-06-01"),
            currentPeriodEnd: new Date("2025-07-01"),
            nextPaymentDate: new Date("2025-07-01"),
            amount: 49.00
          },
          plan: {
            id: 1,
            name: "Learning Starter",
            description: "Essential tools for small educational institutions",
            price: 49.00,
            billingCycle: "monthly"
          }
        },
        3: { // University Enterprise - Education Enterprise Plan
          subscription: {
            id: 3,
            tenantId: 3,
            planId: 3,
            status: "active",
            currentPeriodStart: new Date("2025-06-01"),
            currentPeriodEnd: new Date("2025-07-01"),
            nextPaymentDate: new Date("2025-07-01"),
            amount: 499.00
          },
          plan: {
            id: 3,
            name: "Education Enterprise",
            description: "Complete learning ecosystem for large institutions with white-label options",
            price: 499.00,
            billingCycle: "monthly"
          }
        }
      };

      // Default to tenant 1 for testing
      const tenantId = req.user?.tenantId || 1;
      const userSubscription = tenantSubscriptions[tenantId as keyof typeof tenantSubscriptions] || tenantSubscriptions[1];
      res.json(userSubscription);
    } catch (error) {
      console.error('Get subscription error:', error);
      res.status(500).json({ message: "Failed to get subscription details" });
    }
  });

  app.get("/api/billing/usage", async (req, res) => {
    // Temporarily disable auth for testing
    // if (!req.isAuthenticated()) {
    //   return res.status(401).json({ message: "Not authenticated" });
    // }

    try {
      const currentPeriod = "2025-06";
      
      // Dynamic usage data based on tenant
      const tenantUsage = {
        1: { // LearnWise Academy - Education Pro Plan
          summary: [
            { feature: "activeCourses", planLimit: 50, currentUsage: 34, usagePercentage: 68, overageCount: 0 },
            { feature: "enrolledStudents", planLimit: 1000, currentUsage: 687, usagePercentage: 69, overageCount: 0 },
            { feature: "videoContent", planLimit: 500, currentUsage: 324, usagePercentage: 65, overageCount: 0 },
            { feature: "assessments", planLimit: 200, currentUsage: 142, usagePercentage: 71, overageCount: 0 },
            { feature: "storageGB", planLimit: 100, currentUsage: 78, usagePercentage: 78, overageCount: 0 }
          ]
        },
        2: { // Small Learning Center - Learning Starter Plan
          summary: [
            { feature: "activeCourses", planLimit: 10, currentUsage: 8, usagePercentage: 80, overageCount: 0 },
            { feature: "enrolledStudents", planLimit: 100, currentUsage: 89, usagePercentage: 89, overageCount: 0 },
            { feature: "videoContent", planLimit: 50, currentUsage: 45, usagePercentage: 90, overageCount: 0 },
            { feature: "assessments", planLimit: 25, currentUsage: 22, usagePercentage: 88, overageCount: 0 },
            { feature: "storageGB", planLimit: 10, currentUsage: 7, usagePercentage: 70, overageCount: 0 }
          ]
        },
        3: { // University Enterprise - Education Enterprise Plan (unlimited)
          summary: [
            { feature: "activeCourses", planLimit: -1, currentUsage: 247, usagePercentage: 0, overageCount: 0 },
            { feature: "enrolledStudents", planLimit: -1, currentUsage: 15420, usagePercentage: 0, overageCount: 0 },
            { feature: "videoContent", planLimit: -1, currentUsage: 1847, usagePercentage: 0, overageCount: 0 },
            { feature: "assessments", planLimit: -1, currentUsage: 856, usagePercentage: 0, overageCount: 0 },
            { feature: "storageGB", planLimit: -1, currentUsage: 2340, usagePercentage: 0, overageCount: 0 }
          ]
        }
      };

      // Default to tenant 1 for testing
      const tenantId = req.user?.tenantId || 1;
      const userUsage = tenantUsage[tenantId as keyof typeof tenantUsage] || tenantUsage[1];
      
      res.json({
        currentPeriod,
        summary: userUsage.summary,
        details: []
      });
    } catch (error) {
      console.error('Get usage error:', error);
      res.status(500).json({ message: "Failed to get usage details" });
    }
  });

  app.get("/api/billing/invoices", async (req, res) => {
    // Temporarily disable auth for testing
    // if (!req.isAuthenticated()) {
    //   return res.status(401).json({ message: "Not authenticated" });
    // }

    try {
      // Dynamic invoice data based on tenant
      const tenantInvoices = {
        1: [ // LearnWise Academy - Education Pro Plan
          {
            id: 1,
            invoiceNumber: "INV-EDU-2025-0001",
            amount: 149.00,
            status: "paid",
            dueDate: new Date("2025-06-01"),
            paidDate: new Date("2025-06-01"),
            description: "Education Pro Plan - June 2025"
          },
          {
            id: 2,
            invoiceNumber: "INV-EDU-2025-0002",
            amount: 149.00,
            status: "pending",
            dueDate: new Date("2025-07-01"),
            paidDate: null,
            description: "Education Pro Plan - July 2025"
          }
        ],
        2: [ // Small Learning Center - Learning Starter Plan
          {
            id: 3,
            invoiceNumber: "INV-EDU-2025-0003",
            amount: 49.00,
            status: "paid",
            dueDate: new Date("2025-05-01"),
            paidDate: new Date("2025-05-01"),
            description: "Learning Starter Plan - May 2025"
          },
          {
            id: 4,
            invoiceNumber: "INV-EDU-2025-0004",
            amount: 49.00,
            status: "pending",
            dueDate: new Date("2025-06-01"),
            paidDate: null,
            description: "Learning Starter Plan - June 2025"
          }
        ],
        3: [ // University Enterprise - Education Enterprise Plan
          {
            id: 5,
            invoiceNumber: "INV-EDU-2025-0005",
            amount: 499.00,
            status: "paid",
            dueDate: new Date("2025-06-01"),
            paidDate: new Date("2025-06-01"),
            description: "Education Enterprise Plan - June 2025"
          }
        ]
      };

      // Default to tenant 1 for testing
      const tenantId = req.user?.tenantId || 1;
      const userInvoices = tenantInvoices[tenantId as keyof typeof tenantInvoices] || tenantInvoices[1];
      res.json(userInvoices);
    } catch (error) {
      console.error('Get invoices error:', error);
      res.status(500).json({ message: "Failed to get invoices" });
    }
  });

  // Payment methods management
  app.get("/api/billing/payment-methods", async (req, res) => {
    // Temporarily disable auth for testing
    // if (!req.isAuthenticated()) {
    //   return res.status(401).json({ message: "Not authenticated" });
    // }

    try {
      // Dynamic payment method data based on tenant
      const tenantPaymentMethods = {
        1: [ // TalentHub Demo - Professional Plan
          {
            id: 1,
            tenantId: 1,
            type: "card",
            last4: "4242",
            brand: "visa",
            expiryMonth: 12,
            expiryYear: 2026,
            isDefault: true,
            createdAt: new Date("2024-12-01")
          }
        ],
        2: [ // StartupXYZ Inc - Starter Plan
          {
            id: 2,
            tenantId: 2,
            type: "card",
            last4: "1234",
            brand: "mastercard",
            expiryMonth: 8,
            expiryYear: 2025,
            isDefault: true,
            createdAt: new Date("2024-11-15")
          }
        ],
        3: [ // Enterprise Corp - Enterprise Plan
          {
            id: 3,
            tenantId: 3,
            type: "card",
            last4: "5678",
            brand: "amex",
            expiryMonth: 3,
            expiryYear: 2027,
            isDefault: true,
            createdAt: new Date("2024-10-01")
          }
        ]
      };

      // Default to tenant 1 for testing
      const tenantId = req.user?.tenantId || 1;
      const userPaymentMethods = tenantPaymentMethods[tenantId as keyof typeof tenantPaymentMethods] || tenantPaymentMethods[1];
      res.json(userPaymentMethods);
    } catch (error) {
      console.error('Get payment methods error:', error);
      res.status(500).json({ message: "Failed to get payment methods" });
    }
  });

  app.post("/api/billing/payment-methods", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Not authenticated" });
    }

    try {
      const paymentMethodData = {
        ...req.body,
        tenantId: req.user.tenantId,
        provider: 'demo',
        providerPaymentMethodId: `demo_pm_${Date.now()}`,
        isActive: true,
      };

      // Simulate payment gateway integration with 90% success rate
      const paymentSuccess = Math.random() > 0.1;
      
      if (!paymentSuccess) {
        return res.status(400).json({ 
          message: "Payment method verification failed. Please check your card details." 
        });
      }

      const paymentMethod = {
        id: Date.now(),
        ...paymentMethodData,
        createdAt: new Date()
      };
      res.status(201).json(paymentMethod);
    } catch (error) {
      console.error('Create payment method error:', error);
      res.status(500).json({ message: "Failed to create payment method" });
    }
  });

  // Dummy payment processing
  app.post("/api/billing/process-payment", async (req, res) => {
    // Temporarily disable auth for testing
    // if (!req.isAuthenticated()) {
    //   return res.status(401).json({ message: "Not authenticated" });
    // }

    try {
      const { amount, paymentMethodId, description } = req.body;

      const paymentResult = {
        id: `demo_payment_${Date.now()}`,
        status: Math.random() > 0.1 ? 'succeeded' : 'failed',
        amount: amount,
        currency: 'USD',
        paymentMethodId,
        description,
        processedAt: new Date(),
      };

      if (paymentResult.status === 'succeeded') {
        console.log(`Payment processed: $${amount} for tenant ${req.user.tenantId}`);
        res.json({ 
          success: true, 
          payment: paymentResult,
          message: "Payment processed successfully"
        });
      } else {
        console.log(`Payment failed: $${amount} for tenant ${req.user.tenantId}`);
        res.status(400).json({ 
          success: false, 
          payment: paymentResult,
          message: "Payment failed. Please try again."
        });
      }
    } catch (error) {
      console.error('Process payment error:', error);
      res.status(500).json({ message: "Failed to process payment" });
    }
  });

  // Billing alerts for users
  app.get("/api/billing/alerts", async (req, res) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Not authenticated" });
    }

    try {
      // Dynamic billing alerts based on tenant
      const tenantAlerts = {
        1: [], // TalentHub Demo - No alerts
        2: [ // StartupXYZ Inc - Multiple alerts
          {
            id: 1,
            title: "Payment Overdue",
            message: "Your monthly subscription payment is overdue. Please update your payment method.",
            severity: "critical",
            createdAt: new Date("2025-06-10"),
            resolved: false
          },
          {
            id: 2,
            title: "Usage Limit Exceeded",
            message: "You've exceeded your profile view limit. Consider upgrading your plan.",
            severity: "warning",
            createdAt: new Date("2025-06-12"),
            resolved: false
          }
        ],
        3: [ // Enterprise Corp - Info alert
          {
            id: 3,
            title: "High Usage Notice",
            message: "You're using 80% of your monthly AI credits.",
            severity: "info",
            createdAt: new Date("2025-06-13"),
            resolved: false
          }
        ]
      };

      const userAlerts = tenantAlerts[req.user.tenantId as keyof typeof tenantAlerts] || tenantAlerts[1];
      res.json(userAlerts);
    } catch (error) {
      console.error('Get billing alerts error:', error);
      res.status(500).json({ message: "Failed to get billing alerts" });
    }
  });

  // API Analytics endpoint
  app.get("/api/admin/api-analytics", async (req, res) => {
    try {
      const apiMetrics = {
        totalCalls: 1200000,
        activePartners: 47,
        revenueGenerated: 24750,
        errorRate: 0.3
      };

      const usageByEndpoint = [
        { endpoint: "/api/v1/candidates", calls: 450000, revenue: 8900, percentage: 37.5 },
        { endpoint: "/api/v1/jobs", calls: 320000, revenue: 6400, percentage: 26.7 },
        { endpoint: "/api/v1/assessments", calls: 280000, revenue: 5600, percentage: 23.3 },
        { endpoint: "/api/v1/analytics", calls: 150000, revenue: 3850, percentage: 12.5 }
      ];

      const topPartners = [
        { name: "TechCorp Solutions", calls: 280000, revenue: 5600, plan: "Enterprise" },
        { name: "StartupHub Inc", calls: 150000, revenue: 3000, plan: "Professional" },
        { name: "EduTech Platform", calls: 120000, revenue: 2400, plan: "Professional" },
        { name: "HR Innovations", calls: 85000, revenue: 1700, plan: "Starter" }
      ];

      res.json({
        metrics: apiMetrics,
        usageByEndpoint,
        topPartners
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to get API analytics" });
    }
  });

  // Partners endpoint
  app.get("/api/admin/partners", async (req, res) => {
    try {
      const partners = [
        {
          id: 1,
          name: "TechCorp Solutions",
          type: "Enterprise",
          status: "active",
          contact: "sarah.johnson@techcorp.com",
          phone: "+1 (555) 123-4567",
          website: "techcorp.com",
          monthlyRevenue: 8900,
          apiCalls: 450000,
          plan: "Enterprise API",
          joinDate: "2024-01-15",
          lastActive: "2 hours ago",
          integrations: 5
        },
        {
          id: 2,
          name: "StartupHub Inc",
          type: "Professional",
          status: "active",
          contact: "mike.chen@startuphub.io",
          phone: "+1 (555) 987-6543",
          website: "startuphub.io",
          monthlyRevenue: 3200,
          apiCalls: 180000,
          plan: "Professional API",
          joinDate: "2024-03-10",
          lastActive: "1 day ago",
          integrations: 3
        }
      ];

      res.json(partners);
    } catch (error) {
      res.status(500).json({ message: "Failed to get partners data" });
    }
  });

  // Revenue tracking endpoint
  app.get("/api/admin/revenue", async (req, res) => {
    try {
      const revenueData = {
        totalRevenue: 124750,
        monthlyRecurring: 89200,
        usageBased: 35550,
        avgRevenuePerPartner: 2653,
        revenueByModel: [
          { model: "White-Label Licensing", revenue: 48500, percentage: 38.9, growth: "+15%" },
          { model: "API Usage Pricing", revenue: 35550, percentage: 28.5, growth: "+28%" },
          { model: "Revenue Sharing", revenue: 25200, percentage: 20.2, growth: "+8%" },
          { model: "Tiered Access", revenue: 15500, percentage: 12.4, growth: "+35%" }
        ]
      };

      res.json(revenueData);
    } catch (error) {
      res.status(500).json({ message: "Failed to get revenue data" });
    }
  });

  // API Keys endpoint
  app.get("/api/admin/api-keys", async (req, res) => {
    try {
      const apiKeys = [
        {
          id: 1,
          name: "TechCorp Production",
          key: "tk_live_abcd1234efgh5678ijkl9012mnop3456",
          partner: "TechCorp Solutions",
          permissions: ["read:candidates", "write:jobs", "read:analytics"],
          status: "active",
          lastUsed: "2 hours ago",
          created: "2024-01-15",
          usage: 450000,
          rateLimit: "1000/hour"
        },
        {
          id: 2,
          name: "StartupHub Development",
          key: "tk_test_wxyz9876stuv5432nopq1098rstu7654",
          partner: "StartupHub Inc",
          permissions: ["read:candidates", "read:jobs"],
          status: "active",
          lastUsed: "1 day ago",
          created: "2024-03-10",
          usage: 180000,
          rateLimit: "500/hour"
        }
      ];

      res.json(apiKeys);
    } catch (error) {
      res.status(500).json({ message: "Failed to get API keys data" });
    }
  });

  // Integrations monitoring endpoint
  app.get("/api/admin/integrations", async (req, res) => {
    try {
      const systemHealth = [
        { name: "API Uptime", value: "99.9%", status: "healthy", change: "+0.1%" },
        { name: "Response Time", value: "245ms", status: "good", change: "-15ms" },
        { name: "Error Rate", value: "0.08%", status: "healthy", change: "-0.02%" },
        { name: "Active Connections", value: "1,247", status: "normal", change: "+52" }
      ];

      const integrations = [
        {
          id: 1,
          name: "TechCorp HR System",
          partner: "TechCorp Solutions",
          type: "Webhook",
          status: "healthy",
          uptime: 99.8,
          lastSync: "2 minutes ago",
          syncFrequency: "Real-time",
          dataPoints: 28500,
          errorCount: 0,
          avgResponseTime: 180,
          endpoint: "https://api.techcorp.com/webhook/talenthub"
        },
        {
          id: 2,
          name: "StartupHub ATS",
          partner: "StartupHub Inc",
          type: "REST API",
          status: "healthy",
          uptime: 99.2,
          lastSync: "5 minutes ago",
          syncFrequency: "15 minutes",
          dataPoints: 15200,
          errorCount: 2,
          avgResponseTime: 320,
          endpoint: "https://startuphub.io/api/v2/candidates"
        }
      ];

      res.json({
        systemHealth,
        integrations
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to get integrations data" });
    }
  });

  // Test attempt submission
  app.post("/api/candidate/test-attempts", async (req, res) => {
    try {
      const { testId, answers, timeSpent } = req.body;
      
      // Get test and questions for scoring
      const test = await storage.getTest(testId, 1);
      if (!test) {
        return res.status(404).json({ message: "Test not found" });
      }

      const questions = await storage.getTestQuestions(testId);
      let correctAnswers = 0;
      let totalPoints = 0;
      let earnedPoints = 0;

      questions.forEach((question) => {
        const points = question.points || 1;
        totalPoints += points;
        if (answers[question.id] === question.correctAnswer) {
          correctAnswers++;
          earnedPoints += points;
        }
      });

      const score = totalPoints > 0 ? Math.round((earnedPoints / totalPoints) * 100) : 0;
      
      const result = await storage.createTestAttempt({
        id: `attempt_${Date.now()}`,
        userId: 2, // Use existing user ID from database
        tenantId: 1,
        testId,
        score,
        answers: JSON.stringify(answers),
        timeSpent,
        startedAt: new Date(Date.now() - timeSpent * 1000),
        completedAt: new Date(),
        status: 'completed'
      });
      
      // Check if this completes a certification track
      const certificationStatus = await checkCertificationCompletion(2, testId);
      
      res.json({ 
        ...result, 
        score, 
        passed: score >= test.passingScore,
        correctAnswers,
        totalQuestions: questions.length,
        certificationEarned: certificationStatus.earned,
        certificationId: certificationStatus.certificationId,
        badgeEarned: true,
      });
    } catch (error) {
      console.error('Create test attempt error:', error);
      res.status(500).json({ message: "Failed to create test attempt" });
    }
  });

  // Get test results history for a user
  app.get("/api/candidate/test-results", async (req, res) => {
    try {
      const userId = 2; // Demo user ID
      const tenantId = 1;
      
      const results = await storage.getTestAttempts(userId, tenantId);
      
      res.json(results);
    } catch (error) {
      console.error("Error fetching test results:", error);
      res.status(500).json({ message: "Failed to fetch test results" });
    }
  });

  // Get detailed test analytics
  app.get("/api/candidate/test-analytics", async (req, res) => {
    try {
      const userId = 2; // Demo user ID
      const tenantId = 1;
      
      const results = await storage.getTestAttempts(userId, tenantId);
      
      // Calculate analytics
      const totalTests = results.length;
      const passedTests = results.filter(r => r.passed).length;
      const averageScore = totalTests > 0 ? Math.round(results.reduce((sum, r) => sum + r.score, 0) / totalTests) : 0;
      const totalTimeSpent = results.reduce((sum, r) => sum + r.timeSpent, 0);
      
      // Group by category/difficulty
      const byCategory = results.reduce((acc, result) => {
        const category = result.testId.split('-')[0]; // Extract category from test ID
        if (!acc[category]) acc[category] = { passed: 0, total: 0, avgScore: 0, scores: [] };
        acc[category].total++;
        acc[category].scores.push(result.score);
        if (result.passed) acc[category].passed++;
        acc[category].avgScore = Math.round(acc[category].scores.reduce((sum, score) => sum + score, 0) / acc[category].scores.length);
        return acc;
      }, {});
      
      res.json({
        totalTests,
        passedTests,
        averageScore,
        totalTimeSpent,
        passRate: totalTests > 0 ? Math.round((passedTests / totalTests) * 100) : 0,
        categoryBreakdown: byCategory,
        recentResults: results.slice(-5).reverse(),
        improvementTrend: calculateImprovementTrend(results),
      });
    } catch (error) {
      console.error("Error fetching test analytics:", error);
      res.status(500).json({ message: "Failed to fetch test analytics" });
    }
  });

  // Get earned certificates and badges
  app.get("/api/candidate/certificates", async (req, res) => {
    try {
      const userId = 2; // Demo user ID
      const tenantId = 1;
      
      const certificates = await storage.getCertifications(userId, tenantId);
      const testResults = await storage.getTestAttempts(userId, tenantId);
      
      // Generate individual test badges
      const badges = testResults
        .filter(r => r.passed)
        .map(r => ({
          id: `badge_${r.testId}`,
          testId: r.testId,
          title: `${r.testId.replace('-', ' ').toUpperCase()} Badge`,
          earnedAt: r.completedAt,
          score: r.score,
          type: 'test_completion'
        }));
      
      res.json({
        certificates,
        badges,
        totalBadges: badges.length,
        totalCertificates: certificates.length,
      });
    } catch (error) {
      console.error("Error fetching certificates:", error);
      res.status(500).json({ message: "Failed to fetch certificates" });
    }
  });

  // Profile sharing endpoints
  app.post("/api/profile/share", async (req, res) => {
    try {
      const demoUserId = 2;
      const { platform, message } = req.body;
      
      const shareToken = Math.random().toString(36).substr(2, 10);
      const shareUrl = `https://talenthub.com/profile/shared/${shareToken}`;
      
      // In real implementation, store share token in database
      res.json({
        shareUrl,
        platform: platform || 'general',
        message: message || 'Check out my professional profile',
        expiresAt: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000) // 30 days
      });
    } catch (error) {
      console.error('Profile share error:', error);
      res.status(500).json({ message: "Failed to generate share link" });
    }
  });

  // Profile PDF export
  app.post("/api/profile/export/pdf", async (req, res) => {
    try {
      const demoUserId = 2;
      const demoTenantId = 1;
      
      const profile = await storage.getUserProfile(demoUserId, demoTenantId);
      if (!profile) {
        return res.status(404).json({ message: "Profile not found" });
      }
      
      // In real implementation, generate PDF using puppeteer or similar
      const downloadUrl = `/api/profile/download/${demoUserId}/profile.pdf`;
      
      res.json({
        downloadUrl,
        filename: `${profile.firstName || 'profile'}_${profile.lastName || 'resume'}.pdf`,
        message: "PDF generated successfully"
      });
    } catch (error) {
      console.error('PDF export error:', error);
      res.status(500).json({ message: "Failed to export profile as PDF" });
    }
  });

  // Profile preview
  app.get("/api/profile/preview", async (req, res) => {
    try {
      const demoUserId = 2;
      const demoTenantId = 1;
      
      const profile = await storage.getUserProfile(demoUserId, demoTenantId);
      if (!profile) {
        return res.status(404).json({ message: "Profile not found" });
      }
      
      res.json({
        profile,
        previewUrl: `https://talenthub.com/profile/preview/${demoUserId}`,
        message: "Profile preview ready"
      });
    } catch (error) {
      console.error('Profile preview error:', error);
      res.status(500).json({ message: "Failed to generate profile preview" });
    }
  });

  // Projects endpoints for project tab
  app.get("/api/profile/projects", async (req, res) => {
    try {
      const demoUserId = 2;
      const demoTenantId = 1;
      
      const projects = await storage.getProjects(demoUserId, demoTenantId);
      res.json(projects || []);
    } catch (error) {
      console.error('Get projects error:', error);
      res.status(500).json({ message: "Failed to load projects" });
    }
  });

  app.post("/api/profile/projects", async (req, res) => {
    try {
      const demoUserId = 2;
      const demoTenantId = 1;
      
      const projectData = {
        ...req.body,
        userId: demoUserId,
        tenantId: demoTenantId,
        id: `project_${Date.now()}`
      };
      
      const project = await storage.createProject(projectData);
      res.status(201).json(project);
    } catch (error) {
      console.error('Create project error:', error);
      res.status(500).json({ message: "Failed to create project" });
    }
  });

  // Backup system endpoints
  app.get("/backup", (req, res) => {
    
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
    const archiveName = `talenthub-complete-${timestamp}.tar.gz`;
    const backupPath = path.join('./backup', archiveName);
    
    // Create backup directory
    if (!fs.existsSync('./backup')) {
      fs.mkdirSync('./backup', { recursive: true });
    }
    
    const tarCommand = `tar --exclude=node_modules --exclude=dist --exclude=.git --exclude=backup --exclude=.cache --exclude=.config --exclude=.upm --exclude=venv --exclude=__pycache__ --exclude=*.log -czf ${backupPath} client/ server/ shared/ scripts/ package.json package-lock.json tsconfig.json vite.config.ts tailwind.config.ts postcss.config.js drizzle.config.ts components.json replit.md README.md ARCHITECTURE_FLOW.md .replit .gitignore`;
    
    exec(tarCommand, (error, stdout, stderr) => {
      if (error) {
        console.error('Backup failed:', error);
        return res.status(500).json({ error: "Backup creation failed" });
      }
      
      if (fs.existsSync(backupPath)) {
        const stats = fs.statSync(backupPath);
        
        res.set({
          'Content-Type': 'application/gzip',
          'Content-Disposition': `attachment; filename="${archiveName}"`,
          'Content-Length': stats.size
        });
        
        const fileStream = fs.createReadStream(backupPath);
        fileStream.pipe(res);
        
        fileStream.on('end', () => {
          setTimeout(() => {
            if (fs.existsSync(backupPath)) {
              fs.unlinkSync(backupPath);
            }
          }, 5000);
        });
      } else {
        res.status(500).json({ error: "Backup file not created" });
      }
    });
  });

  // List available backups
  app.get("/backup/list", (req, res) => {
    try {
      const fs = require('fs');
      const path = require('path');
      const backupDir = './backup';
      
      if (!fs.existsSync(backupDir)) {
        return res.json({ backups: [] });
      }
      
      const files = fs.readdirSync(backupDir)
        .filter(file => file.endsWith('.tar.gz'))
        .map(file => {
          const filepath = path.join(backupDir, file);
          const stats = fs.statSync(filepath);
          return {
            filename: file,
            size: (stats.size / (1024 * 1024)).toFixed(2) + ' MB',
            created: stats.birthtime,
            downloadUrl: `/backup/download/${file}`
          };
        })
        .sort((a, b) => new Date(b.created).getTime() - new Date(a.created).getTime());
      
      res.json({ backups: files });
    } catch (error) {
      console.error('List backups error:', error);
      res.status(500).json({ error: "Failed to list backups" });
    }
  });

  // Download specific backup file
  app.get("/backup/download/:filename", (req, res) => {
    const filename = req.params.filename;
    const filepath = `./backup/${filename}`;
    
    // Security check - only allow specific backup files
    if (!filename.includes('talenthub') || !filename.endsWith('.tar.gz')) {
      return res.status(403).json({ error: "File not allowed" });
    }
    
    res.download(filepath, (err) => {
      if (err) {
        console.error('Download error:', err);
        res.status(404).json({ error: "File not found" });
      }
    });
  });

  // Legacy download endpoint
  app.get("/download/:filename", (req, res) => {
    const filename = req.params.filename;
    const filepath = `./download/${filename}`;
    
    // Security check - only allow specific backup files
    if (!filename.includes('talenthub') || !filename.endsWith('.tar.gz')) {
      return res.status(403).json({ error: "File not allowed" });
    }
    
    res.download(filepath, (err) => {
      if (err) {
        console.error('Download error:', err);
        res.status(404).json({ error: "File not found" });
      }
    });
  });

  // Simple Architecture Documentation API
  app.get('/api/architecture', (req: Request, res: Response) => {
    res.json({
      htmlFile: 'TalentHub-Architecture-Documentation.html',
      markdownFile: 'ARCHITECTURE_FLOW.md',
      status: 'available',
      downloadInstructions: {
        html: 'Open the HTML file in browser and use Ctrl+P (Cmd+P on Mac) to save as PDF',
        markdown: 'Can be viewed in any markdown editor or converted to PDF'
      }
    });
  });

  // Main backup download endpoint - creates and serves complete application backup
  app.get("/api/download", async (req, res) => {
    try {
      const execAsync = promisify(exec);
      const timestamp = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
      const zipFileName = `talenthub-complete-application-${timestamp}.tar.gz`;
      
      // Store backup in backup directory
      const backupDir = path.join(process.cwd(), 'backup');
      if (!fs.existsSync(backupDir)) {
        fs.mkdirSync(backupDir, { recursive: true });
      }
      
      const zipPath = path.join(backupDir, zipFileName);
      
      // Create comprehensive backup excluding unnecessary files
      const excludePatterns = [
        '--exclude=node_modules',
        '--exclude=.git', 
        '--exclude=dist',
        '--exclude=backup',
        '--exclude=.next',
        '--exclude=.vite',
        '--exclude=.cache',
        '--exclude=.upm',
        '--exclude=.config',
        '--exclude=venv',
        '--exclude=__pycache__',
        '--exclude=*.log',
        '--exclude=*.tar.gz',
        '--exclude=*.backup',
        '--exclude=mvp*',
        '--exclude=deploy*',
        '--exclude=build-*',
        '--exclude=create-*',
        '--exclude=production-*',
        '--exclude=start-*',
        '--exclude=dist-*',
        '--exclude=attached_assets',
        '--exclude=featuredoc',
        '--exclude=requirementdoc',
        '--exclude=scripts',
        '--exclude=cookies.txt',
        '--exclude=*.docx',
        '--exclude=*.html',
        '--exclude=*.csv',
        '--exclude=*.md',
        '--exclude=.env.local'
      ].join(' ');
      
      console.log(`Creating comprehensive application backup: ${zipFileName}`);
      
      // Create tar.gz archive of essential application files
      const tarCommand = `tar ${excludePatterns} -czf "${zipPath}" \
        client/ \
        server/ \
        shared/ \
        package.json \
        package-lock.json \
        tsconfig.json \
        vite.config.ts \
        tailwind.config.ts \
        postcss.config.js \
        drizzle.config.ts \
        components.json \
        .replit \
        .gitignore \
        2>/dev/null || true`;
      
      await execAsync(tarCommand);
      
      // Check if file was created successfully
      if (!fs.existsSync(zipPath)) {
        throw new Error('Failed to create backup archive');
      }
      
      const stats = fs.statSync(zipPath);
      const fileSizeMB = (stats.size / (1024 * 1024)).toFixed(2);
      
      console.log(`✓ Backup created successfully: ${fileSizeMB}MB`);
      
      // Set headers for download
      res.setHeader('Content-Type', 'application/gzip');
      res.setHeader('Content-Disposition', `attachment; filename="${zipFileName}"`);
      res.setHeader('Content-Length', stats.size);
      res.setHeader('X-File-Size', `${fileSizeMB}MB`);
      res.setHeader('X-Created-At', timestamp);
      
      // Stream the file to client and keep permanent copy in backup directory
      const fileStream = fs.createReadStream(zipPath);
      
      fileStream.on('error', (error) => {
        console.error('Download stream error:', error);
        if (!res.headersSent) {
          res.status(500).json({ error: 'Download failed' });
        }
      });
      
      fileStream.on('end', () => {
        console.log(`✓ Backup download completed: ${zipFileName} (preserved in backup directory)`);
      });
      
      fileStream.pipe(res);
      
    } catch (error) {
      console.error('Download endpoint error:', error);
      if (!res.headersSent) {
        res.status(500).json({ 
          error: 'Failed to create application backup',
          message: error instanceof Error ? error.message : 'Unknown error'
        });
      }
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}

// Helper function to check certification completion
async function checkCertificationCompletion(userId: number, completedTestId: string) {
  try {
    // Define certification tracks
    const certificationTracks = {
      'javascript-fundamentals-cert': ['js-fundamentals', 'js-advanced', 'js-async'],
      'python-developer-cert': ['python-basics', 'python-oop', 'python-frameworks'],
      'react-specialist-cert': ['react-basics', 'react-hooks', 'react-performance'],
    };
    
    // Get all user's passed tests
    const userResults = await storage.getTestAttempts(userId, 1);
    const passedTests = userResults.filter(r => r.passed).map(r => r.testId);
    
    // Check each certification track
    for (const [certId, requiredTests] of Object.entries(certificationTracks)) {
      if (requiredTests.includes(completedTestId)) {
        const completedRequiredTests = requiredTests.filter(test => passedTests.includes(test));
        
        if (completedRequiredTests.length === requiredTests.length) {
          // All tests in track completed - award certification
          await storage.createCertification({
            id: `cert_${Date.now()}`,
            userId,
            tenantId: 1,
            title: certId.replace('-', ' ').toUpperCase(),
            description: `Completed all ${requiredTests.length} tests in the certification track`,
            earnedAt: new Date(),
            verificationCode: `CERT_${Math.random().toString(36).substr(2, 9).toUpperCase()}`,
            issuedBy: 'TalentHub Platform',
          });
          
          return { earned: true, certificationId: certId };
        }
      }
    }
    
    return { earned: false, certificationId: null };
  } catch (error) {
    console.error("Error checking certification completion:", error);
    return { earned: false, certificationId: null };
  }

  const httpServer = createServer(app);
  return httpServer;
}

// Helper function to calculate improvement trend
function calculateImprovementTrend(results: any[]) {
  if (results.length < 2) return 0;
  
  const sortedResults = results.sort((a, b) => new Date(a.completedAt).getTime() - new Date(b.completedAt).getTime());
  const firstHalf = sortedResults.slice(0, Math.floor(sortedResults.length / 2));
  const secondHalf = sortedResults.slice(Math.floor(sortedResults.length / 2));
  
  const firstHalfAvg = firstHalf.reduce((sum, r) => sum + r.score, 0) / firstHalf.length;
  const secondHalfAvg = secondHalf.reduce((sum, r) => sum + r.score, 0) / secondHalf.length;
  
  return Math.round(secondHalfAvg - firstHalfAvg);
}
