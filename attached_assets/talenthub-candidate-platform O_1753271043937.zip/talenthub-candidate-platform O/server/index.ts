import express, { type Request, Response, NextFunction } from "express";
import path from "path";
import { registerRoutes } from "./routes.js";

async function initializeServer() {
  let setupVite: any, serveStatic: any, log: any;

  if (process.env.NODE_ENV === "development") {
    try {
      const viteModule = await import("./vite.js");
      setupVite = viteModule.setupVite;
      log = viteModule.log;
      
      serveStatic = viteModule.serveStatic;
    } catch (err) {
      console.log("Vite not available, using production mode");
      process.env.NODE_ENV = "production";
    }
  }

  if (process.env.NODE_ENV !== "development") {
    log = (message: string, source = "express") => {
      const formattedTime = new Date().toLocaleTimeString("en-US", {
        hour: "numeric",
        minute: "2-digit",
        second: "2-digit",
        hour12: true,
      });
      console.log(`${formattedTime} [${source}] ${message}`);
    };

    serveStatic = (app: express.Express) => {
      // In production, serve static assets directly without Vite
      app.use(express.static(path.join(process.cwd(), 'client/public')));
      
      // Serve static landing page first for immediate display
      app.get("/", (_req: Request, res: Response) => {
        res.sendFile(path.join(process.cwd(), 'client/public/landing.html'));
      });
      
      // For all other routes, serve the React application
      app.get("*", (_req: Request, res: Response) => {
        res.sendFile(path.join(process.cwd(), 'client/index.html'));
      });
    };
  }

  const app = express();
  app.use(express.json());
  app.use(express.urlencoded({ extended: false }));

  app.use((req, res, next) => {
    const start = Date.now();
    const path = req.path;
    const method = req.method;

    res.on("finish", () => {
      const duration = Date.now() - start;
      const status = res.statusCode;
      const logMessage = `${method} ${path} ${status} in ${duration}ms`;
      log(logMessage);
    });

    next();
  });



  const server = await registerRoutes(app);

  if (setupVite) {
    await setupVite(app, server);
  }

  if (serveStatic) {
    serveStatic(app);
  }

  app.use((err: any, _req: Request, res: Response, _next: NextFunction) => {
    const status = err.status || err.statusCode || 500;
    const message = err.message || "Internal Server Error";
    res.status(status).json({ message });
    log(`Unhandled error: ${err.message}`);
  });

  const PORT = Number(process.env.PORT) || 3000;
  server.listen(PORT, "0.0.0.0", () => {
    log(`serving on 0.0.0.0:${PORT}`);
    log(`✓ TalentHub server ready on 0.0.0.0:${PORT}`);
    log(`Preview URL: https://${process.env.REPL_SLUG}.${process.env.REPL_OWNER}.repl.co`);
    log(`Alternative URLs to try:`);
    log(`- https://workspace.apprun452.replit.dev`);
    log(`- Click the preview/webview button in Replit interface`);
    log(`- Use the direct Replit preview panel`);
  });
}

initializeServer();