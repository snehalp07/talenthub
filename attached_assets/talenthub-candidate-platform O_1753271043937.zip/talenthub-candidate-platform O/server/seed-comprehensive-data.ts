import { storage } from "./storage";
import { db } from "./db";
import { eq } from "drizzle-orm";
import * as schema from "@shared/schema";

export async function seedComprehensiveData() {
  try {
    console.log("Starting comprehensive database seeding...");

    // Get or create test tenant
    let tenant;
    try {
      const tenants = await db.select().from(schema.tenants).where(eq(schema.tenants.slug, "techcorp-solutions"));
      if (tenants.length > 0) {
        tenant = tenants[0];
        console.log("Using existing tenant:", tenant.name);
      } else {
        tenant = await storage.createTenant({
          name: "TechCorp Solutions",
          slug: "techcorp-solutions",
          plan: "enterprise",
          isActive: true
        });
        console.log("Created new tenant:", tenant.name);
      }
    } catch (error) {
      console.log("Error with tenant, using existing data");
      const tenants = await db.select().from(schema.tenants).limit(1);
      tenant = tenants[0];
    }

    // Create test users with different roles
    const candidateUser = await storage.createUser({
      email: "john.candidate@email.com",
      username: "johncandidate",
      password: "hashedpassword123",
      role: "candidate",
      tenantId: tenant.id
    });

    const recruiterUser = await storage.createUser({
      email: "sarah.recruiter@techcorp.com",
      username: "sarahrecruiter", 
      password: "hashedpassword123",
      role: "recruiter",
      tenantId: tenant.id
    });

    // Create comprehensive user profile
    const profile = await storage.createUserProfile({
      userId: candidateUser.id,
      tenantId: tenant.id,
      firstName: "John",
      lastName: "Candidate",
      bio: "Passionate full-stack developer with 5+ years experience building scalable web applications",
      professionalSummary: "Experienced software engineer specializing in React, Node.js, and cloud technologies. Led development of microservices architecture serving 100K+ users.",
      phone: "+1-555-0123",
      location: "San Francisco, CA",
      linkedinUrl: "https://linkedin.com/in/johncandidate",
      githubUrl: "https://github.com/johncandidate",
      portfolioUrl: "https://johncandidate.dev",
      experience: [
        {
          title: "Senior Full Stack Developer",
          company: "TechStartup Inc",
          startDate: "2022-01-01",
          endDate: null,
          current: true,
          description: "Led development of React-based dashboard serving 50K+ users. Implemented microservices architecture with Node.js and PostgreSQL."
        },
        {
          title: "Frontend Developer", 
          company: "WebSolutions LLC",
          startDate: "2020-03-01",
          endDate: "2021-12-31",
          current: false,
          description: "Built responsive web applications using React and TypeScript. Collaborated with design team to implement pixel-perfect UIs."
        }
      ],
      education: [
        {
          degree: "Bachelor of Science in Computer Science",
          institution: "Stanford University",
          startDate: "2016-09-01",
          endDate: "2020-05-01",
          gpa: "3.8"
        }
      ],
      skills: [
        { name: "JavaScript", level: "Advanced", category: "Programming" },
        { name: "React", level: "Advanced", category: "Frontend" },
        { name: "Node.js", level: "Intermediate", category: "Backend" },
        { name: "PostgreSQL", level: "Intermediate", category: "Database" },
        { name: "AWS", level: "Intermediate", category: "Cloud" },
        { name: "Docker", level: "Beginner", category: "DevOps" }
      ],
      projects: [
        {
          title: "E-commerce Platform",
          description: "Full-stack e-commerce solution with React frontend and Node.js backend",
          technologies: "React, Node.js, PostgreSQL, Stripe",
          githubUrl: "https://github.com/johncandidate/ecommerce-platform",
          demoUrl: "https://demo-ecommerce.johncandidate.dev",
          startDate: "2023-01-01",
          endDate: "2023-06-01",
          status: "completed"
        },
        {
          title: "Task Management App",
          description: "Collaborative task management tool with real-time updates",
          technologies: "React, Socket.io, Express, MongoDB",
          githubUrl: "https://github.com/johncandidate/task-manager",
          demoUrl: "https://tasks.johncandidate.dev",
          startDate: "2023-07-01",
          endDate: null,
          status: "in_progress"
        }
      ],
      achievements: [
        {
          title: "AWS Certified Solutions Architect",
          description: "Achieved AWS Solutions Architect Associate certification",
          date: "2023-05-15",
          category: "certification",
          issuer: "Amazon Web Services"
        },
        {
          title: "Employee of the Quarter",
          description: "Recognized for outstanding performance and leadership",
          date: "2023-03-01",
          category: "award",
          issuer: "TechStartup Inc"
        }
      ]
    });

    // Create job postings
    const jobs = await Promise.all([
      storage.createJob({
        title: "Senior Full Stack Developer",
        description: "We're seeking an experienced full-stack developer to join our growing team. You'll work on cutting-edge projects using React, Node.js, and cloud technologies.",
        organizationName: "TechCorp Solutions",
        location: "San Francisco, CA",
        remoteAllowed: true,
        minSalary: 120000,
        maxSalary: 180000,
        experienceLevel: "senior",
        requiredSkills: ["React", "Node.js", "PostgreSQL", "AWS"],
        requiredCertificationLevel: 3,
        applicationDeadline: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000), // 30 days from now
        tenantId: tenant.id,
        recruiterId: recruiterUser.id,
        status: "open"
      }),

      storage.createJob({
        title: "Frontend React Developer",
        description: "Join our product team to build beautiful, responsive user interfaces. Experience with React, TypeScript, and modern CSS frameworks required.",
        organizationName: "StartupXYZ",
        location: "New York, NY",
        remoteAllowed: false,
        minSalary: 90000,
        maxSalary: 130000,
        experienceLevel: "mid",
        requiredSkills: ["React", "TypeScript", "CSS", "JavaScript"],
        requiredCertificationLevel: 2,
        applicationDeadline: new Date(Date.now() + 45 * 24 * 60 * 60 * 1000),
        tenantId: tenant.id,
        recruiterId: recruiterUser.id,
        status: "open"
      }),

      storage.createJob({
        title: "DevOps Engineer",
        description: "Help us scale our infrastructure to support millions of users. Experience with AWS, Docker, Kubernetes, and CI/CD pipelines essential.",
        organizationName: "CloudTech Inc",
        location: "Seattle, WA", 
        remoteAllowed: true,
        minSalary: 110000,
        maxSalary: 160000,
        experienceLevel: "senior",
        requiredSkills: ["AWS", "Docker", "Kubernetes", "Terraform"],
        requiredCertificationLevel: 4,
        applicationDeadline: new Date(Date.now() + 20 * 24 * 60 * 60 * 1000),
        tenantId: tenant.id,
        recruiterId: recruiterUser.id,
        status: "open"
      })
    ]);

    // Create job applications
    const applications = await Promise.all([
      storage.createApplication({
        jobId: jobs[0].id,
        candidateId: candidateUser.id,
        tenantId: tenant.id,
        status: "applied",
        coverLetter: "I'm excited to apply for the Senior Full Stack Developer position. My experience with React and Node.js aligns perfectly with your requirements.",
        resumeUrl: "https://resume.johncandidate.dev/resume.pdf"
      }),

      storage.createApplication({
        jobId: jobs[1].id,
        candidateId: candidateUser.id,
        tenantId: tenant.id,
        status: "interview_scheduled",
        coverLetter: "I would love to contribute to your frontend team. My expertise in React and TypeScript would be valuable for your product development.",
        resumeUrl: "https://resume.johncandidate.dev/resume.pdf"
      })
    ]);

    // Get or create skill tests
    let tests = [];
    const testConfigs = [
      {
        id: "js-fundamentals-2024",
        title: "JavaScript Fundamentals",
        description: "Comprehensive test covering ES6+, async programming, and modern JavaScript concepts",
        difficulty: "intermediate",
        duration: 45,
        totalQuestions: 25,
        passingScore: 70,
        category: "programming"
      },
      {
        id: "react-advanced-2024", 
        title: "React Advanced Concepts",
        description: "Deep dive into React hooks, context, performance optimization, and testing",
        difficulty: "advanced",
        duration: 60,
        totalQuestions: 30,
        passingScore: 75,
        category: "frontend"
      },
      {
        id: "nodejs-backend-2024",
        title: "Node.js Backend Development", 
        description: "Server-side development with Express, databases, and API design",
        difficulty: "intermediate",
        duration: 50,
        totalQuestions: 28,
        passingScore: 70,
        category: "backend"
      }
    ];

    for (const testConfig of testConfigs) {
      try {
        const existingTests = await db.select().from(schema.tests).where(eq(schema.tests.id, testConfig.id));
        if (existingTests.length > 0) {
          tests.push(existingTests[0]);
          console.log("Using existing test:", testConfig.title);
        } else {
          const newTest = await storage.createTest({
            ...testConfig,
            tenantId: tenant.id
          });
          tests.push(newTest);
          console.log("Created new test:", testConfig.title);
        }
      } catch (error) {
        console.log("Test creation error for", testConfig.title, "- using existing");
        const existingTests = await db.select().from(schema.tests).where(eq(schema.tests.id, testConfig.id));
        if (existingTests.length > 0) {
          tests.push(existingTests[0]);
        }
      }
    }

    // Create test attempts with realistic scores
    const testAttempts = await Promise.all([
      storage.createTestAttempt({
        id: "attempt-js-001",
        userId: candidateUser.id,
        tenantId: tenant.id,
        testId: tests[0].id,
        status: "completed",
        answers: {
          "q1": "const",
          "q2": "arrow function",
          "q3": "promise"
        },
        score: 88,
        timeSpent: 42,
        startedAt: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000),
        completedAt: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000 + 42 * 60 * 1000)
      }),

      storage.createTestAttempt({
        id: "attempt-react-001",
        userId: candidateUser.id,
        tenantId: tenant.id,
        testId: tests[1].id,
        status: "completed",
        answers: {
          "q1": "useState",
          "q2": "useEffect",
          "q3": "context"
        },
        score: 92,
        timeSpent: 58,
        startedAt: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000),
        completedAt: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000 + 58 * 60 * 1000)
      })
    ]);

    // Create certifications earned
    const certifications = await Promise.all([
      storage.createCertification({
        id: "cert-js-fundamentals-001",
        userId: candidateUser.id,
        tenantId: tenant.id,
        title: "JavaScript Fundamentals Certification",
        type: "test",
        issuerId: "system",
        credentialId: "JS-FUND-2024-001",
        skills: ["JavaScript", "ES6", "Async Programming"],
        validFrom: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000),
        validUntil: new Date(Date.now() + 365 * 24 * 60 * 60 * 1000),
        verificationUrl: "https://verify.talenthub.com/cert-js-fundamentals-001"
      }),

      storage.createCertification({
        id: "cert-react-advanced-001",
        userId: candidateUser.id,
        tenantId: tenant.id,
        title: "React Advanced Concepts Certification",
        type: "test",
        issuerId: "system",
        credentialId: "REACT-ADV-2024-001",
        skills: ["React", "Hooks", "Performance", "Testing"],
        validFrom: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000),
        validUntil: new Date(Date.now() + 365 * 24 * 60 * 60 * 1000),
        verificationUrl: "https://verify.talenthub.com/cert-react-advanced-001"
      })
    ]);

    // Create courses for LMS
    const courses = await Promise.all([
      storage.createCourse({
        title: "Advanced React Patterns",
        description: "Master advanced React patterns including render props, higher-order components, and custom hooks",
        content: {
          modules: [
            {
              title: "Render Props Pattern",
              lessons: ["Introduction to Render Props", "Building Reusable Components", "Advanced Use Cases"]
            },
            {
              title: "Higher-Order Components",
              lessons: ["HOC Fundamentals", "Composition Patterns", "Real-world Examples"]
            }
          ],
          totalLessons: 12,
          exercises: 8
        },
        duration: 8,
        tenantId: tenant.id,
        isActive: true
      }),

      storage.createCourse({
        title: "Node.js Microservices",
        description: "Build scalable microservices architecture with Node.js, Docker, and Kubernetes",
        content: {
          modules: [
            {
              title: "Microservices Architecture",
              lessons: ["Service Design", "API Gateway Patterns", "Data Management"]
            },
            {
              title: "Docker & Kubernetes",
              lessons: ["Containerization", "Orchestration", "Deployment Strategies"]
            }
          ],
          totalLessons: 18,
          exercises: 12
        },
        duration: 12,
        tenantId: tenant.id,
        isActive: true
      })
    ]);

    // Create course enrollments
    const enrollments = await Promise.all([
      storage.createEnrollment({
        userId: candidateUser.id,
        courseId: courses[0].id,
        tenantId: tenant.id,
        status: "in_progress",
        progress: 60,
        enrolledAt: new Date(Date.now() - 14 * 24 * 60 * 60 * 1000)
      }),

      storage.createEnrollment({
        userId: candidateUser.id,
        courseId: courses[1].id,
        tenantId: tenant.id,
        status: "completed",
        progress: 100,
        enrolledAt: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000),
        completedAt: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000)
      })
    ]);

    // Track usage metrics
    const usageMetrics = await Promise.all([
      storage.trackUsage({
        tenantId: tenant.id,
        userId: candidateUser.id,
        feature: "test_attempts",
        count: 1,
        timestamp: new Date()
      }),

      storage.trackUsage({
        tenantId: tenant.id,
        userId: candidateUser.id,
        feature: "job_applications",
        count: 1,
        timestamp: new Date()
      }),

      storage.trackUsage({
        tenantId: tenant.id,
        userId: candidateUser.id,
        feature: "profile_views",
        count: 1,
        timestamp: new Date()
      })
    ]);

    console.log("Comprehensive database seeding completed successfully!");
    console.log(`Created:
      - 1 Tenant: ${tenant.name}
      - 2 Users: ${candidateUser.email}, ${recruiterUser.email}
      - 1 User Profile with complete data
      - ${jobs.length} Job Postings
      - ${applications.length} Job Applications
      - ${tests.length} Skill Tests
      - ${testAttempts.length} Test Attempts
      - ${certifications.length} Certifications
      - ${courses.length} Courses
      - ${enrollments.length} Course Enrollments
      - ${usageMetrics.length} Usage Metrics
    `);

    return {
      tenant,
      users: { candidateUser, recruiterUser },
      profile,
      jobs,
      applications,
      tests,
      testAttempts,
      certifications,
      courses,
      enrollments,
      usageMetrics
    };

  } catch (error) {
    console.error("Error seeding comprehensive data:", error);
    throw error;
  }
}