import { 
  users, 
  tenants,
  jobs,
  applications,
  assessments,
  assessmentResults,
  courses,
  enrollments,
  usageMetrics,
  subscriptionPlans,
  userProfiles,
  resumeDocuments,
  profileViews,
  enhancedSubscriptionPlans,
  tenantSubscriptions,
  usageTracking,
  usageQuotas,
  billingInvoices,
  paymentMethods,
  billingAlerts,
  tests,
  questions,
  testAttempts,
  certifications,
  projects,
  projectFiles,
  jobPostings,
  jobApplications,
  userSettings,
  type User, 
  type InsertUser,
  type Tenant,
  type InsertTenant,
  type Job,
  type InsertJob,
  type Application,
  type InsertApplication,
  type Assessment,
  type InsertAssessment,
  type AssessmentResult,
  type InsertAssessmentResult,
  type Course,
  type InsertCourse,
  type Enrollment,
  type InsertEnrollment,
  type UsageMetric,
  type InsertUsageMetric,
  type UserProfile,
  type InsertUserProfile,
  type ResumeDocument,
  type InsertResumeDocument,
  type ProfileView,
  type InsertProfileView,
  type EnhancedSubscriptionPlan,
  type InsertEnhancedSubscriptionPlan,
  type TenantSubscription,
  type InsertTenantSubscription,
  type UsageTracking,
  type InsertUsageTracking,
  type UsageQuota,
  type InsertUsageQuota,
  type BillingInvoice,
  type InsertBillingInvoice,
  type PaymentMethod,
  type InsertPaymentMethod,
  type BillingAlert,
  type InsertBillingAlert,
  type Test,
  type InsertTest,
  type Question,
  type InsertQuestion,
  type TestAttempt,
  type InsertTestAttempt,
  type Certification,
  type InsertCertification,
  type Project,
  type InsertProject,
  type ProjectFile,
  type InsertProjectFile,
  type JobPosting,
  type InsertJobPosting,
  type JobApplication,
  type InsertJobApplication,
  type UserSettings,
  type InsertUserSettings,
} from "../shared/schema.js";
import { db } from "./db";
import { eq, and, desc, count, sum } from "drizzle-orm";
import session from "express-session";
import connectPg from "connect-pg-simple";
import { pool } from "./db";

const PostgresSessionStore = connectPg(session);

export interface IStorage {
  // User management
  getUser(id: number): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, updates: Partial<User>): Promise<User>;
  
  // Tenant management
  getTenant(id: number): Promise<Tenant | undefined>;
  getTenantByName(name: string): Promise<Tenant | undefined>;
  createTenant(tenant: InsertTenant): Promise<Tenant>;
  
  // Job management
  getJobs(tenantId: number, limit?: number): Promise<Job[]>;
  getJob(id: number, tenantId: number): Promise<Job | undefined>;
  createJob(job: InsertJob): Promise<Job>;
  updateJob(id: number, tenantId: number, updates: Partial<Job>): Promise<Job>;
  
  // Application management
  getApplications(tenantId: number, jobId?: number): Promise<Application[]>;
  createApplication(application: InsertApplication): Promise<Application>;
  updateApplication(id: number, tenantId: number, updates: Partial<Application>): Promise<Application>;
  
  // Job application management
  getJobApplications(userId: number, tenantId: number): Promise<JobApplication[]>;
  createJobApplication(application: InsertJobApplication): Promise<JobApplication>;
  
  // Assessment management
  getAssessments(tenantId: number): Promise<Assessment[]>;
  getAssessment(id: number, tenantId: number): Promise<Assessment | undefined>;
  createAssessment(assessment: InsertAssessment): Promise<Assessment>;
  
  // Assessment results
  getAssessmentResults(tenantId: number, candidateId?: number): Promise<AssessmentResult[]>;
  createAssessmentResult(result: InsertAssessmentResult): Promise<AssessmentResult>;
  
  // Course management
  getCourses(tenantId: number): Promise<Course[]>;
  getCourse(id: number, tenantId: number): Promise<Course | undefined>;
  createCourse(course: InsertCourse): Promise<Course>;
  
  // Enrollment management
  getEnrollments(tenantId: number, userId?: number): Promise<Enrollment[]>;
  createEnrollment(enrollment: InsertEnrollment): Promise<Enrollment>;
  updateEnrollment(id: number, tenantId: number, updates: Partial<Enrollment>): Promise<Enrollment>;
  
  // Usage tracking
  trackUsage(usage: InsertUsageMetric): Promise<UsageMetric>;
  getUsageMetrics(tenantId: number, feature?: string): Promise<UsageMetric[]>;
  getUsageSummary(tenantId: number): Promise<{ feature: string; totalCount: number }[]>;
  
  // Dashboard data
  getDashboardMetrics(tenantId: number, userId: number): Promise<{
    candidateCount: number;
    jobCount: number;
    interviewCount: number;
    hireCount: number;
  }>;
  
  getRecentCandidates(tenantId: number, limit?: number): Promise<User[]>;
  
  // Profile management
  getUserProfile(userId: number, tenantId: number): Promise<UserProfile | undefined>;
  createUserProfile(profile: InsertUserProfile): Promise<UserProfile>;
  updateUserProfile(userId: number, tenantId: number, updates: Partial<UserProfile>): Promise<UserProfile>;
  
  // Resume documents
  getResumeDocuments(userId: number, tenantId: number): Promise<ResumeDocument[]>;
  createResumeDocument(document: InsertResumeDocument): Promise<ResumeDocument>;
  deleteResumeDocument(id: number, tenantId: number): Promise<void>;
  setPrimaryResume(id: number, userId: number, tenantId: number): Promise<void>;
  
  // Profile analytics
  trackProfileView(view: InsertProfileView): Promise<ProfileView>;
  getProfileViews(profileUserId: number, tenantId: number): Promise<ProfileView[]>;
  getProfileAnalytics(userId: number, tenantId: number): Promise<{
    totalViews: number;
    uniqueViewers: number;
    viewsByType: { viewerType: string; count: number }[];
  }>;

  // Billing management
  getSubscriptionPlans(): Promise<EnhancedSubscriptionPlan[]>;
  createSubscriptionPlan(plan: InsertEnhancedSubscriptionPlan): Promise<EnhancedSubscriptionPlan>;
  updateSubscriptionPlan(id: number, updates: Partial<EnhancedSubscriptionPlan>): Promise<EnhancedSubscriptionPlan>;
  
  // Tenant subscriptions
  getTenantSubscription(tenantId: number): Promise<TenantSubscription | undefined>;
  createTenantSubscription(subscription: InsertTenantSubscription): Promise<TenantSubscription>;
  updateTenantSubscription(id: number, updates: Partial<TenantSubscription>): Promise<TenantSubscription>;
  
  // Usage tracking and quotas
  trackUsage(usage: InsertUsageTracking): Promise<UsageTracking>;
  getUsageByTenant(tenantId: number, billingPeriod: string): Promise<UsageTracking[]>;
  getUsageQuotas(tenantId: number, billingPeriod: string): Promise<UsageQuota[]>;
  updateUsageQuota(tenantId: number, feature: string, usage: number): Promise<UsageQuota>;
  
  // Billing invoices
  getBillingInvoices(tenantId: number): Promise<BillingInvoice[]>;
  createBillingInvoice(invoice: InsertBillingInvoice): Promise<BillingInvoice>;
  updateBillingInvoice(id: number, updates: Partial<BillingInvoice>): Promise<BillingInvoice>;
  
  // Payment methods
  getPaymentMethods(tenantId: number): Promise<PaymentMethod[]>;
  createPaymentMethod(method: InsertPaymentMethod): Promise<PaymentMethod>;
  updatePaymentMethod(id: number, updates: Partial<PaymentMethod>): Promise<PaymentMethod>;
  deletePaymentMethod(id: number): Promise<void>;
  
  // Billing alerts
  getBillingAlerts(tenantId: number, resolved?: boolean): Promise<BillingAlert[]>;
  createBillingAlert(alert: InsertBillingAlert): Promise<BillingAlert>;
  resolveBillingAlert(id: number): Promise<void>;
  
  // Admin billing overview
  getAllTenantBilling(): Promise<{
    tenantId: number;
    tenantName: string;
    subscriptionStatus: string;
    currentPlan: string;
    monthlyRevenue: number;
    lastPayment: Date | null;
    nextPayment: Date | null;
    outstandingAmount: number;
    alerts: number;
  }[]>;
  
  getUsageSummaryByTenant(tenantId: number): Promise<{
    feature: string;
    planLimit: number;
    currentUsage: number;
    usagePercentage: number;
    overageCount: number;
  }[]>;

  // Test and Assessment operations
  getTests(tenantId: number): Promise<Test[]>;
  getTest(testId: string, tenantId: number): Promise<Test | undefined>;
  createTest(test: InsertTest): Promise<Test>;
  getTestQuestions(testId: string): Promise<Question[]>;
  createTestAttempt(attempt: InsertTestAttempt): Promise<TestAttempt>;
  updateTestAttempt(attemptId: string, updates: Partial<TestAttempt>): Promise<TestAttempt>;
  getTestAttempts(userId: number, tenantId: number): Promise<TestAttempt[]>;

  // Certification operations
  getCertifications(userId: number, tenantId: number): Promise<Certification[]>;
  getCertification(certId: string, tenantId: number): Promise<Certification | undefined>;
  createCertification(cert: InsertCertification): Promise<Certification>;

  // Project operations
  getProjects(userId: number, tenantId: number): Promise<Project[]>;
  getProject(projectId: string, tenantId: number): Promise<Project | undefined>;
  createProject(project: InsertProject): Promise<Project>;
  updateProject(projectId: string, updates: Partial<Project>): Promise<Project>;
  getProjectFiles(projectId: string): Promise<ProjectFile[]>;
  createProjectFile(file: InsertProjectFile): Promise<ProjectFile>;
  updateProjectFile(fileId: string, updates: Partial<ProjectFile>): Promise<ProjectFile>;

  // Job operations
  getJobPostings(tenantId: number, filters?: any): Promise<JobPosting[]>;
  getJobPosting(jobId: string, tenantId: number): Promise<JobPosting | undefined>;
  createJobApplication(application: InsertJobApplication): Promise<JobApplication>;
  getJobApplications(userId: number, tenantId: number): Promise<JobApplication[]>;

  // User settings
  getUserSettings(userId: number): Promise<UserSettings | undefined>;
  createUserSettings(settings: InsertUserSettings): Promise<UserSettings>;
  updateUserSettings(userId: number, updates: Partial<UserSettings>): Promise<UserSettings>;
  
  sessionStore: any;
}

export class DatabaseStorage implements IStorage {
  sessionStore: any;

  constructor() {
    this.sessionStore = new PostgresSessionStore({ 
      pool, 
      createTableIfMissing: true 
    });
  }

  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }

  async updateUser(id: number, updates: Partial<User>): Promise<User> {
    const [user] = await db
      .update(users)
      .set(updates)
      .where(eq(users.id, id))
      .returning();
    return user;
  }

  async getTenant(id: number): Promise<Tenant | undefined> {
    const [tenant] = await db.select().from(tenants).where(eq(tenants.id, id));
    return tenant || undefined;
  }

  async getTenantByName(name: string): Promise<Tenant | undefined> {
    const [tenant] = await db.select().from(tenants).where(eq(tenants.name, name));
    return tenant || undefined;
  }

  async createTenant(insertTenant: InsertTenant): Promise<Tenant> {
    const [tenant] = await db
      .insert(tenants)
      .values(insertTenant)
      .returning();
    return tenant;
  }

  async getJobs(tenantId: number, limit = 50): Promise<Job[]> {
    return await db
      .select()
      .from(jobs)
      .where(and(eq(jobs.tenantId, tenantId), eq(jobs.isActive, true)))
      .orderBy(desc(jobs.createdAt))
      .limit(limit);
  }

  async getJob(id: number, tenantId: number): Promise<Job | undefined> {
    const [job] = await db
      .select()
      .from(jobs)
      .where(and(eq(jobs.id, id), eq(jobs.tenantId, tenantId)));
    return job || undefined;
  }

  async createJob(insertJob: InsertJob): Promise<Job> {
    const [job] = await db
      .insert(jobs)
      .values(insertJob)
      .returning();
    return job;
  }

  async updateJob(id: number, tenantId: number, updates: Partial<Job>): Promise<Job> {
    const [job] = await db
      .update(jobs)
      .set(updates)
      .where(and(eq(jobs.id, id), eq(jobs.tenantId, tenantId)))
      .returning();
    return job;
  }

  async getApplications(tenantId: number, jobId?: number): Promise<Application[]> {
    const conditions = [eq(applications.tenantId, tenantId)];
    if (jobId) {
      conditions.push(eq(applications.jobId, jobId));
    }
    
    return await db
      .select()
      .from(applications)
      .where(and(...conditions))
      .orderBy(desc(applications.appliedAt));
  }

  async createApplication(insertApplication: InsertApplication): Promise<Application> {
    const [application] = await db
      .insert(applications)
      .values(insertApplication)
      .returning();
    return application;
  }

  async updateApplication(id: number, tenantId: number, updates: Partial<Application>): Promise<Application> {
    const [application] = await db
      .update(applications)
      .set(updates)
      .where(and(eq(applications.id, id), eq(applications.tenantId, tenantId)))
      .returning();
    return application;
  }

  async getAssessments(tenantId: number): Promise<Assessment[]> {
    return await db
      .select()
      .from(assessments)
      .where(and(eq(assessments.tenantId, tenantId), eq(assessments.isActive, true)))
      .orderBy(desc(assessments.createdAt));
  }

  async getAssessment(id: number, tenantId: number): Promise<Assessment | undefined> {
    const [assessment] = await db
      .select()
      .from(assessments)
      .where(and(eq(assessments.id, id), eq(assessments.tenantId, tenantId)));
    return assessment || undefined;
  }

  async createAssessment(insertAssessment: InsertAssessment): Promise<Assessment> {
    const [assessment] = await db
      .insert(assessments)
      .values(insertAssessment)
      .returning();
    return assessment;
  }

  async getAssessmentResults(tenantId: number, candidateId?: number): Promise<AssessmentResult[]> {
    const conditions = [eq(assessmentResults.tenantId, tenantId)];
    if (candidateId) {
      conditions.push(eq(assessmentResults.candidateId, candidateId));
    }
    
    return await db
      .select()
      .from(assessmentResults)
      .where(and(...conditions))
      .orderBy(desc(assessmentResults.completedAt));
  }

  async createAssessmentResult(insertResult: InsertAssessmentResult): Promise<AssessmentResult> {
    const [result] = await db
      .insert(assessmentResults)
      .values(insertResult)
      .returning();
    return result;
  }

  async getCourses(tenantId: number): Promise<Course[]> {
    return await db
      .select()
      .from(courses)
      .where(and(eq(courses.tenantId, tenantId), eq(courses.isActive, true)))
      .orderBy(desc(courses.createdAt));
  }

  async getCourse(id: number, tenantId: number): Promise<Course | undefined> {
    const [course] = await db
      .select()
      .from(courses)
      .where(and(eq(courses.id, id), eq(courses.tenantId, tenantId)));
    return course || undefined;
  }

  async createCourse(insertCourse: InsertCourse): Promise<Course> {
    const [course] = await db
      .insert(courses)
      .values(insertCourse)
      .returning();
    return course;
  }

  async getEnrollments(tenantId: number, userId?: number): Promise<Enrollment[]> {
    const conditions = [eq(enrollments.tenantId, tenantId)];
    if (userId) {
      conditions.push(eq(enrollments.userId, userId));
    }
    
    return await db
      .select()
      .from(enrollments)
      .where(and(...conditions))
      .orderBy(desc(enrollments.enrolledAt));
  }

  async createEnrollment(insertEnrollment: InsertEnrollment): Promise<Enrollment> {
    const [enrollment] = await db
      .insert(enrollments)
      .values(insertEnrollment)
      .returning();
    return enrollment;
  }

  async updateEnrollment(id: number, tenantId: number, updates: Partial<Enrollment>): Promise<Enrollment> {
    const [enrollment] = await db
      .update(enrollments)
      .set(updates)
      .where(and(eq(enrollments.id, id), eq(enrollments.tenantId, tenantId)))
      .returning();
    return enrollment;
  }

  async trackUsage(insertUsage: InsertUsageMetric): Promise<UsageMetric> {
    const [usage] = await db
      .insert(usageMetrics)
      .values(insertUsage)
      .returning();
    return usage;
  }

  async getUsageMetrics(tenantId: number, feature?: string): Promise<UsageMetric[]> {
    const conditions = [eq(usageMetrics.tenantId, tenantId)];
    if (feature) {
      conditions.push(eq(usageMetrics.feature, feature));
    }
    
    return await db
      .select()
      .from(usageMetrics)
      .where(and(...conditions))
      .orderBy(desc(usageMetrics.recordedAt));
  }

  async getUsageSummary(tenantId: number): Promise<{ feature: string; totalCount: number }[]> {
    return await db
      .select({
        feature: usageMetrics.feature,
        totalCount: sum(usageMetrics.count).mapWith(Number),
      })
      .from(usageMetrics)
      .where(eq(usageMetrics.tenantId, tenantId))
      .groupBy(usageMetrics.feature);
  }

  async getDashboardMetrics(tenantId: number, userId: number): Promise<{
    candidateCount: number;
    jobCount: number;
    interviewCount: number;
    hireCount: number;
  }> {
    const [candidateCountResult] = await db
      .select({ count: count() })
      .from(users)
      .where(and(eq(users.tenantId, tenantId), eq(users.role, 'candidate')));

    const [jobCountResult] = await db
      .select({ count: count() })
      .from(jobs)
      .where(and(eq(jobs.tenantId, tenantId), eq(jobs.isActive, true)));

    const [interviewCountResult] = await db
      .select({ count: count() })
      .from(applications)
      .where(and(eq(applications.tenantId, tenantId), eq(applications.status, 'interview')));

    const [hireCountResult] = await db
      .select({ count: count() })
      .from(applications)
      .where(and(eq(applications.tenantId, tenantId), eq(applications.status, 'hired')));

    return {
      candidateCount: candidateCountResult.count,
      jobCount: jobCountResult.count,
      interviewCount: interviewCountResult.count,
      hireCount: hireCountResult.count,
    };
  }

  async getRecentCandidates(tenantId: number, limit = 10): Promise<User[]> {
    return await db
      .select()
      .from(users)
      .where(and(eq(users.tenantId, tenantId), eq(users.role, 'candidate'), eq(users.isActive, true)))
      .orderBy(desc(users.createdAt))
      .limit(limit);
  }

  // Profile management methods
  async getUserProfile(userId: number, tenantId: number): Promise<UserProfile | undefined> {
    const [profile] = await db
      .select()
      .from(userProfiles)
      .where(and(eq(userProfiles.userId, userId), eq(userProfiles.tenantId, tenantId)));
    return profile || undefined;
  }

  async createUserProfile(insertProfile: InsertUserProfile): Promise<UserProfile> {
    const [profile] = await db
      .insert(userProfiles)
      .values(insertProfile)
      .returning();
    return profile;
  }

  async updateUserProfile(userId: number, tenantId: number, updates: Partial<UserProfile>): Promise<UserProfile> {
    const [profile] = await db
      .update(userProfiles)
      .set({ ...updates, updatedAt: new Date() })
      .where(and(eq(userProfiles.userId, userId), eq(userProfiles.tenantId, tenantId)))
      .returning();
    return profile;
  }

  // Resume document methods
  async getResumeDocuments(userId: number, tenantId: number): Promise<ResumeDocument[]> {
    return await db
      .select()
      .from(resumeDocuments)
      .where(and(eq(resumeDocuments.userId, userId), eq(resumeDocuments.tenantId, tenantId)))
      .orderBy(desc(resumeDocuments.createdAt));
  }

  async createResumeDocument(insertDocument: InsertResumeDocument): Promise<ResumeDocument> {
    const [document] = await db
      .insert(resumeDocuments)
      .values(insertDocument)
      .returning();
    return document;
  }

  async deleteResumeDocument(id: number, tenantId: number): Promise<void> {
    await db
      .delete(resumeDocuments)
      .where(and(eq(resumeDocuments.id, id), eq(resumeDocuments.tenantId, tenantId)));
  }

  async setPrimaryResume(id: number, userId: number, tenantId: number): Promise<void> {
    // First, unset all primary flags for the user
    await db
      .update(resumeDocuments)
      .set({ isPrimary: false })
      .where(and(eq(resumeDocuments.userId, userId), eq(resumeDocuments.tenantId, tenantId)));
    
    // Then set the specified document as primary
    await db
      .update(resumeDocuments)
      .set({ isPrimary: true })
      .where(and(eq(resumeDocuments.id, id), eq(resumeDocuments.tenantId, tenantId)));
  }

  // Profile analytics methods
  async trackProfileView(insertView: InsertProfileView): Promise<ProfileView> {
    const [view] = await db
      .insert(profileViews)
      .values(insertView)
      .returning();
    return view;
  }

  async getProfileViews(profileUserId: number, tenantId: number): Promise<ProfileView[]> {
    return await db
      .select()
      .from(profileViews)
      .where(and(eq(profileViews.profileUserId, profileUserId), eq(profileViews.tenantId, tenantId)))
      .orderBy(desc(profileViews.viewedAt));
  }

  async getProfileAnalytics(userId: number, tenantId: number): Promise<{
    totalViews: number;
    uniqueViewers: number;
    viewsByType: { viewerType: string; count: number }[];
  }> {
    const totalViewsResult = await db
      .select({ count: count() })
      .from(profileViews)
      .where(and(eq(profileViews.profileUserId, userId), eq(profileViews.tenantId, tenantId)));

    const uniqueViewersResult = await db
      .selectDistinct({ viewerId: profileViews.viewerUserId })
      .from(profileViews)
      .where(and(eq(profileViews.profileUserId, userId), eq(profileViews.tenantId, tenantId)));

    const viewsByTypeResult = await db
      .select({
        viewerType: profileViews.viewerType,
        count: count()
      })
      .from(profileViews)
      .where(and(eq(profileViews.profileUserId, userId), eq(profileViews.tenantId, tenantId)))
      .groupBy(profileViews.viewerType);

    return {
      totalViews: totalViewsResult[0]?.count || 0,
      uniqueViewers: uniqueViewersResult.filter(v => v.viewerId !== null).length,
      viewsByType: viewsByTypeResult,
    };
  }

  // Test and Assessment operations
  async getTests(tenantId: number): Promise<Test[]> {
    try {
      const result = await db.select().from(tests).where(eq(tests.tenantId, tenantId));
      console.log('getTests result:', result.length, 'tests found for tenant', tenantId);
      return result;
    } catch (error) {
      console.error('getTests error:', error);
      return [];
    }
  }

  async getTest(testId: string, tenantId: number): Promise<Test | undefined> {
    try {
      const [test] = await db.select().from(tests).where(and(eq(tests.id, testId), eq(tests.tenantId, tenantId)));
      return test;
    } catch (error) {
      console.error('getTest error:', error);
      return undefined;
    }
  }

  async createTest(test: InsertTest): Promise<Test> {
    try {
      const [newTest] = await db.insert(tests).values(test).returning();
      console.log('Test created:', newTest.id, newTest.title);
      return newTest;
    } catch (error) {
      console.error('createTest error:', error);
      throw error;
    }
  }

  async getTestQuestions(testId: string): Promise<Question[]> {
    return await db.select().from(questions).where(eq(questions.testId, testId)).orderBy(questions.order);
  }

  async createTestAttempt(attempt: InsertTestAttempt): Promise<TestAttempt> {
    const [newAttempt] = await db.insert(testAttempts).values(attempt).returning();
    return newAttempt;
  }

  async updateTestAttempt(attemptId: string, updates: Partial<TestAttempt>): Promise<TestAttempt> {
    const [updated] = await db.update(testAttempts).set(updates).where(eq(testAttempts.id, attemptId)).returning();
    return updated;
  }

  async getTestAttempts(userId: number, tenantId: number): Promise<TestAttempt[]> {
    return await db.select().from(testAttempts).where(and(eq(testAttempts.userId, userId), eq(testAttempts.tenantId, tenantId)));
  }

  // Certification operations
  async getCertifications(userId: number, tenantId: number): Promise<Certification[]> {
    return await db.select().from(certifications).where(and(eq(certifications.userId, userId), eq(certifications.tenantId, tenantId)));
  }

  async getCertification(certId: string, tenantId: number): Promise<Certification | undefined> {
    const [cert] = await db.select().from(certifications).where(and(eq(certifications.id, certId), eq(certifications.tenantId, tenantId)));
    return cert;
  }

  async createCertification(cert: InsertCertification): Promise<Certification> {
    const [newCert] = await db.insert(certifications).values(cert).returning();
    return newCert;
  }

  // Project operations
  async getProjects(userId: number, tenantId: number): Promise<Project[]> {
    return await db.select().from(projects).where(and(eq(projects.userId, userId), eq(projects.tenantId, tenantId)));
  }

  async getProject(projectId: string, tenantId: number): Promise<Project | undefined> {
    const [project] = await db.select().from(projects).where(and(eq(projects.id, projectId), eq(projects.tenantId, tenantId)));
    return project;
  }

  async createProject(project: InsertProject): Promise<Project> {
    const [newProject] = await db.insert(projects).values(project).returning();
    return newProject;
  }

  async updateProject(projectId: string, updates: Partial<Project>): Promise<Project> {
    const [updated] = await db.update(projects).set(updates).where(eq(projects.id, projectId)).returning();
    return updated;
  }

  async getProjectFiles(projectId: string): Promise<ProjectFile[]> {
    return await db.select().from(projectFiles).where(eq(projectFiles.projectId, projectId));
  }

  async createProjectFile(file: InsertProjectFile): Promise<ProjectFile> {
    const [newFile] = await db.insert(projectFiles).values(file).returning();
    return newFile;
  }

  async updateProjectFile(fileId: string, updates: Partial<ProjectFile>): Promise<ProjectFile> {
    const [updated] = await db.update(projectFiles).set(updates).where(eq(projectFiles.id, fileId)).returning();
    return updated;
  }



  // User settings
  async getUserSettings(userId: number): Promise<UserSettings | undefined> {
    const [settings] = await db.select().from(userSettings).where(eq(userSettings.userId, userId));
    return settings;
  }

  async createUserSettings(settings: InsertUserSettings): Promise<UserSettings> {
    const [newSettings] = await db.insert(userSettings).values(settings).returning();
    return newSettings;
  }

  async updateUserSettings(userId: number, updates: Partial<UserSettings>): Promise<UserSettings> {
    const [updated] = await db.update(userSettings).set(updates).where(eq(userSettings.userId, userId)).returning();
    return updated;
  }

  // Job application management methods
  async getJobApplications(userId: number, tenantId: number): Promise<JobApplication[]> {
    return await db
      .select()
      .from(jobApplications)
      .where(and(eq(jobApplications.userId, userId), eq(jobApplications.tenantId, tenantId)))
      .orderBy(desc(jobApplications.appliedDate));
  }

  async createJobApplication(application: InsertJobApplication): Promise<JobApplication> {
    const [created] = await db
      .insert(jobApplications)
      .values(application)
      .returning();
    return created;
  }

  // Job posting management methods
  async getJobPostings(tenantId: number, filters?: any): Promise<JobPosting[]> {
    return await db
      .select()
      .from(jobPostings)
      .where(eq(jobPostings.tenantId, tenantId))
      .orderBy(desc(jobPostings.postedDate));
  }

  async getJobPosting(jobId: string, tenantId: number): Promise<JobPosting | undefined> {
    const [posting] = await db
      .select()
      .from(jobPostings)
      .where(and(eq(jobPostings.id, jobId), eq(jobPostings.tenantId, tenantId)));
    return posting || undefined;
  }
}

export const storage = new DatabaseStorage();
