import { Request, Response, NextFunction } from 'express';

// Simple compression middleware to reduce bandwidth
export function compressionMiddleware(req: Request, res: Response, next: NextFunction) {
  const acceptEncoding = req.headers['accept-encoding'] || '';
  
  if (acceptEncoding.includes('gzip')) {
    res.setHeader('Content-Encoding', 'gzip');
    res.setHeader('Vary', 'Accept-Encoding');
  }
  
  // Cache static assets
  if (req.url.match(/\.(js|css|png|jpg|jpeg|gif|ico|svg)$/)) {
    res.setHeader('Cache-Control', 'public, max-age=31536000'); // 1 year
  } else {
    res.setHeader('Cache-Control', 'no-cache');
  }
  
  next();
}

// API response optimization
export function optimizeApiResponse(data: any): any {
  if (Array.isArray(data)) {
    return data.map(item => {
      if (typeof item === 'object' && item !== null) {
        // Remove null/undefined values to reduce payload size
        const optimized: any = {};
        Object.keys(item).forEach(key => {
          if (item[key] !== null && item[key] !== undefined) {
            optimized[key] = item[key];
          }
        });
        return optimized;
      }
      return item;
    });
  }
  return data;
}