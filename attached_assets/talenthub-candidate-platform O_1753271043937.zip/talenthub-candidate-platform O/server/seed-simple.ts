import { storage } from "./storage";
import { db } from "./db";
import { eq } from "drizzle-orm";
import * as schema from "@shared/schema";

export async function seedSimpleData() {
  try {
    console.log("Starting simple database seeding with existing data...");

    // Get existing tenant
    const tenants = await db.select().from(schema.tenants).limit(1);
    if (tenants.length === 0) {
      throw new Error("No tenants found - please create a tenant first");
    }
    const tenant = tenants[0];

    // Get existing users
    const users = await db.select().from(schema.users).where(eq(schema.users.tenantId, tenant.id)).limit(5);
    if (users.length === 0) {
      throw new Error("No users found - please create users first");
    }

    const candidateUser = users.find(u => u.role === 'candidate') || users[0];
    const recruiterUser = users.find(u => u.role === 'recruiter') || users[1] || users[0];

    console.log("Using existing tenant:", tenant.name);
    console.log("Using candidate user:", candidateUser.email);
    console.log("Using recruiter user:", recruiterUser.email);

    // Create or update user profile for better testing
    try {
      const existingProfiles = await db.select().from(schema.userProfiles).where(eq(schema.userProfiles.userId, candidateUser.id));
      if (existingProfiles.length === 0) {
        await storage.createUserProfile({
          userId: candidateUser.id,
          tenantId: tenant.id,
          bio: "Experienced full-stack developer passionate about building scalable applications",
          professionalSummary: "5+ years developing React and Node.js applications with strong focus on user experience",
          phone: "+1-555-0123",
          location: "San Francisco, CA",
          linkedinUrl: "https://linkedin.com/in/candidate",
          githubUrl: "https://github.com/candidate",
          portfolioUrl: "https://candidate.dev"
        });
        console.log("Created user profile for candidate");
      } else {
        console.log("User profile already exists");
      }
    } catch (error) {
      console.log("Profile creation skipped - may already exist");
    }

    // Get existing tests
    const existingTests = await db.select().from(schema.tests).where(eq(schema.tests.tenantId, tenant.id)).limit(3);
    console.log("Found existing tests:", existingTests.length);

    // Create test attempts if tests exist
    if (existingTests.length > 0) {
      try {
        const existingAttempts = await db.select().from(schema.testAttempts).where(eq(schema.testAttempts.userId, candidateUser.id));
        if (existingAttempts.length === 0) {
          const newAttempt = await storage.createTestAttempt({
            id: `attempt-${Date.now()}`,
            userId: candidateUser.id,
            tenantId: tenant.id,
            testId: existingTests[0].id,
            status: "completed",
            answers: { "q1": "const", "q2": "arrow function", "q3": "promise" },
            score: 85,
            timeSpent: 45,
            startedAt: new Date(Date.now() - 60 * 60 * 1000),
            completedAt: new Date()
          });
          console.log("Created test attempt with score:", newAttempt.score);
        }
      } catch (error) {
        console.log("Test attempt creation skipped");
      }
    }

    // Get existing jobs
    const existingJobs = await db.select().from(schema.jobs).where(eq(schema.jobs.tenantId, tenant.id)).limit(5);
    console.log("Found existing jobs:", existingJobs.length);

    // Create job applications if jobs exist  
    if (existingJobs.length > 0) {
      try {
        const existingApplications = await db.select().from(schema.applications).where(eq(schema.applications.candidateId, candidateUser.id));
        if (existingApplications.length === 0) {
          const newApplication = await storage.createApplication({
            jobId: existingJobs[0].id,
            candidateId: candidateUser.id,
            tenantId: tenant.id,
            status: "applied",
            coverLetter: "I am excited to apply for this position and contribute to your team's success.",
            resumeUrl: "https://resume.candidate.dev/resume.pdf"
          });
          console.log("Created job application for job:", existingJobs[0].title);
        }
      } catch (error) {
        console.log("Job application creation skipped");
      }
    }

    // Verify data exists for UI testing
    const profileCount = await db.select().from(schema.userProfiles).where(eq(schema.userProfiles.tenantId, tenant.id));
    const jobCount = await db.select().from(schema.jobs).where(eq(schema.jobs.tenantId, tenant.id));
    const applicationCount = await db.select().from(schema.applications).where(eq(schema.applications.tenantId, tenant.id));
    const testCount = await db.select().from(schema.tests).where(eq(schema.tests.tenantId, tenant.id));

    console.log("Database seeding completed successfully!");
    console.log(`Data available for testing:
      - ${profileCount.length} User Profiles
      - ${jobCount.length} Jobs
      - ${applicationCount.length} Applications  
      - ${testCount.length} Tests
      - Tenant: ${tenant.name}
      - Primary candidate: ${candidateUser.email}
    `);

    return {
      success: true,
      tenant: tenant.name,
      candidateUser: candidateUser.email,
      recruiterUser: recruiterUser.email,
      dataAvailable: {
        profiles: profileCount.length,
        jobs: jobCount.length,
        applications: applicationCount.length,
        tests: testCount.length
      }
    };

  } catch (error) {
    console.error("Error in simple database seeding:", error);
    throw error;
  }
}