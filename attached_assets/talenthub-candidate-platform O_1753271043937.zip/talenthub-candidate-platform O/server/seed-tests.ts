import { db } from "./db";
import { tests, questions, testAttempts, certifications } from "@shared/schema";

export async function seedTestData(tenantId: number) {
  try {
    // Create sample tests
    const jsTest = {
      id: "js-fundamentals",
      title: "JavaScript Fundamentals",
      description: "Test your knowledge of core JavaScript concepts including variables, functions, objects, and asynchronous programming",
      duration: 45,
      totalQuestions: 25,
      passingScore: 70,
      difficulty: "intermediate" as const,
      category: "Programming",
      tags: ["JavaScript", "ES6", "Functions", "Objects", "Async"],
      status: "published" as const,
      tenantId,
    };

    const reactTest = {
      id: "react-advanced",
      title: "Advanced React Development",
      description: "Advanced React concepts including hooks, context, performance optimization, and modern patterns",
      duration: 60,
      totalQuestions: 30,
      passingScore: 75,
      difficulty: "advanced" as const,
      category: "Frontend",
      tags: ["React", "Hooks", "Context", "Performance", "TypeScript"],
      status: "published" as const,
      tenantId,
    };

    const systemTest = {
      id: "system-design",
      title: "System Design Fundamentals",
      description: "Fundamentals of scalable system architecture, databases, caching, and distributed systems",
      duration: 90,
      totalQuestions: 20,
      passingScore: 80,
      difficulty: "expert" as const,
      category: "Architecture",
      tags: ["Scalability", "Databases", "Caching", "Load Balancing", "Microservices"],
      status: "published" as const,
      tenantId,
    };

    // Insert tests
    await db.insert(tests).values([jsTest, reactTest, systemTest]);

    // Create questions for JavaScript test
    const jsQuestions = [
      {
        id: "js-q1",
        testId: "js-fundamentals",
        type: "multiple_choice" as const,
        title: "Variable Declaration",
        content: "Which of the following is the correct way to declare a block-scoped variable in ES6?",
        options: ["var x = 5;", "let x = 5;", "const x = 5;", "Both let and const"],
        correctAnswer: "Both let and const",
        explanation: "Both 'let' and 'const' create block-scoped variables in ES6, unlike 'var' which is function-scoped.",
        points: 2,
        order: 1,
        tags: ["variables", "ES6", "scope"]
      },
      {
        id: "js-q2",
        testId: "js-fundamentals",
        type: "coding" as const,
        title: "Array Methods",
        content: "Write a function that takes an array of numbers and returns the sum of all even numbers.\n\nExample: sumEvenNumbers([1,2,3,4,5,6]) should return 12",
        correctAnswer: "function sumEvenNumbers(arr) {\n  return arr.filter(num => num % 2 === 0).reduce((sum, num) => sum + num, 0);\n}",
        explanation: "Filter even numbers, then reduce to sum them up.",
        points: 5,
        order: 2,
        tags: ["arrays", "filter", "reduce"]
      },
      {
        id: "js-q3",
        testId: "js-fundamentals",
        type: "multiple_choice" as const,
        title: "Async/Await",
        content: "What is the correct way to handle errors in async/await?",
        options: [
          "Use .catch() method",
          "Use try/catch blocks",
          "Use error callbacks",
          "Errors are handled automatically"
        ],
        correctAnswer: "Use try/catch blocks",
        explanation: "try/catch blocks are the standard way to handle errors in async/await syntax.",
        points: 3,
        order: 3,
        tags: ["async", "await", "error-handling"]
      },
      {
        id: "js-q4",
        testId: "js-fundamentals",
        type: "multiple_choice" as const,
        title: "Object Destructuring",
        content: "What does the following code do?\nconst { name, age = 25 } = person;",
        options: [
          "Creates new variables with default values",
          "Assigns properties from person object to variables with age defaulting to 25",
          "Modifies the person object",
          "Creates a copy of the person object"
        ],
        correctAnswer: "Assigns properties from person object to variables with age defaulting to 25",
        explanation: "Destructuring assignment extracts properties from objects into variables, with default values when property is undefined.",
        points: 2,
        order: 4,
        tags: ["destructuring", "objects", "ES6"]
      },
      {
        id: "js-q5",
        testId: "js-fundamentals",
        type: "coding" as const,
        title: "Promise Handling",
        content: "Convert this callback-based function to use Promises:\n\nfunction fetchData(callback) {\n  setTimeout(() => {\n    callback(null, 'data');\n  }, 1000);\n}",
        correctAnswer: "function fetchData() {\n  return new Promise((resolve) => {\n    setTimeout(() => {\n      resolve('data');\n    }, 1000);\n  });\n}",
        explanation: "Wrap the asynchronous operation in a Promise constructor and use resolve/reject instead of callback.",
        points: 4,
        order: 5,
        tags: ["promises", "async", "callbacks"]
      }
    ];

    // Create questions for React test
    const reactQuestions = [
      {
        id: "react-q1",
        testId: "react-advanced",
        type: "multiple_choice" as const,
        title: "useEffect Hook",
        content: "When does useEffect run if no dependency array is provided?",
        options: [
          "Only on mount",
          "Only on unmount",
          "After every render",
          "Only when state changes"
        ],
        correctAnswer: "After every render",
        explanation: "Without a dependency array, useEffect runs after every render.",
        points: 2,
        order: 1,
        tags: ["hooks", "useEffect", "lifecycle"]
      },
      {
        id: "react-q2",
        testId: "react-advanced",
        type: "coding" as const,
        title: "Custom Hook",
        content: "Create a custom hook called 'useCounter' that manages a counter state with increment and decrement functions.",
        correctAnswer: "function useCounter(initialValue = 0) {\n  const [count, setCount] = useState(initialValue);\n  const increment = () => setCount(c => c + 1);\n  const decrement = () => setCount(c => c - 1);\n  return { count, increment, decrement };\n}",
        explanation: "Custom hooks should start with 'use' and can encapsulate stateful logic.",
        points: 5,
        order: 2,
        tags: ["custom-hooks", "useState", "state-management"]
      },
      {
        id: "react-q3",
        testId: "react-advanced",
        type: "multiple_choice" as const,
        title: "React Performance",
        content: "Which React feature helps prevent unnecessary re-renders?",
        options: [
          "useEffect",
          "useState",
          "React.memo",
          "useContext"
        ],
        correctAnswer: "React.memo",
        explanation: "React.memo is a higher order component that memoizes the result and skips re-rendering if props haven't changed.",
        points: 3,
        order: 3,
        tags: ["performance", "memo", "optimization"]
      }
    ];

    // Create questions for System Design test
    const systemQuestions = [
      {
        id: "sys-q1",
        testId: "system-design",
        type: "multiple_choice" as const,
        title: "Database Scaling",
        content: "Which approach is best for scaling read-heavy database workloads?",
        options: [
          "Vertical scaling only",
          "Read replicas",
          "Write replicas",
          "More application servers"
        ],
        correctAnswer: "Read replicas",
        explanation: "Read replicas distribute read load across multiple database instances.",
        points: 3,
        order: 1,
        tags: ["databases", "scaling", "replicas"]
      },
      {
        id: "sys-q2",
        testId: "system-design",
        type: "essay" as const,
        title: "Caching Strategy",
        content: "Explain the difference between cache-aside and write-through caching patterns. When would you use each?",
        explanation: "Cache-aside: Application manages cache. Write-through: Cache manages writes to storage.",
        points: 5,
        order: 2,
        tags: ["caching", "patterns", "architecture"]
      },
      {
        id: "sys-q3",
        testId: "system-design",
        type: "multiple_choice" as const,
        title: "Load Balancing",
        content: "What is the main benefit of using a load balancer?",
        options: [
          "Increases security",
          "Distributes traffic across multiple servers",
          "Reduces bandwidth usage",
          "Improves data consistency"
        ],
        correctAnswer: "Distributes traffic across multiple servers",
        explanation: "Load balancers distribute incoming requests across multiple servers to prevent any single server from being overwhelmed.",
        points: 2,
        order: 3,
        tags: ["load-balancing", "scalability", "infrastructure"]
      }
    ];

    // Insert all questions
    const allQuestions = [...jsQuestions, ...reactQuestions, ...systemQuestions];
    await db.insert(questions).values(allQuestions);

    return {
      tests: [jsTest, reactTest, systemTest],
      questionsCreated: allQuestions.length
    };
  } catch (error) {
    console.error("Error seeding test data:", error);
    throw error;
  }
}