import { pgTable, text, serial, integer, boolean, timestamp, decimal, jsonb } from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Tenants table for multi-tenancy
export const tenants = pgTable("tenants", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  slug: text("slug").notNull().unique(),
  plan: text("plan").notNull().default("starter"), // starter, professional, enterprise
  isActive: boolean("is_active").notNull().default(true),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Users table with tenant isolation
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  tenantId: integer("tenant_id").references(() => tenants.id).notNull(),
  username: text("username").notNull(),
  email: text("email").notNull(),
  password: text("password").notNull(),
  role: text("role").notNull(), // candidate, recruiter, admin, lms_user, etc.
  firstName: text("first_name"),
  lastName: text("last_name"),
  isActive: boolean("is_active").notNull().default(true),
  stripeCustomerId: text("stripe_customer_id"),
  stripeSubscriptionId: text("stripe_subscription_id"),
  // Extended profile fields for comprehensive candidate data
  subscriptionPlan: text("subscription_plan").default("free"), // free, basic, premium, enterprise
  subscriptionStatus: text("subscription_status").default("active"), // active, cancelled, expired
  creditsRemaining: integer("credits_remaining").default(100),
  jobIntent: text("job_intent"), // full-time, part-time, contract, freelance
  topStrengths: text("top_strengths").array(),
  preferredDomain: text("preferred_domain"), // technology, finance, healthcare, etc.
  expectedCtc: text("expected_ctc"), // salary expectations
  currentLocation: text("current_location"),
  willingnessToRelocate: boolean("willingness_to_relocate").default(false),
  paymentStatus: text("payment_status").default("current"), // current, overdue, suspended
  hasActiveSubscription: boolean("has_active_subscription").default(true),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Job postings
export const jobs = pgTable("jobs", {
  id: serial("id").primaryKey(),
  tenantId: integer("tenant_id").references(() => tenants.id).notNull(),
  recruiterId: integer("recruiter_id").references(() => users.id).notNull(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  organizationName: text("organization_name").notNull(),
  requirements: text("requirements"),
  location: text("location"),
  remoteAllowed: boolean("remote_allowed").default(false),
  minSalary: integer("min_salary"),
  maxSalary: integer("max_salary"),
  experienceLevel: text("experience_level"), // entry, mid, senior
  requiredSkills: jsonb("required_skills").default([]),
  requiredCertificationLevel: integer("required_certification_level"),
  applicationDeadline: timestamp("application_deadline"),
  status: text("status").notNull().default("open"), // open, closed, draft
  isActive: boolean("is_active").notNull().default(true),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Job applications
export const applications = pgTable("applications", {
  id: serial("id").primaryKey(),
  tenantId: integer("tenant_id").references(() => tenants.id).notNull(),
  jobId: integer("job_id").references(() => jobs.id).notNull(),
  candidateId: integer("candidate_id").references(() => users.id).notNull(),
  status: text("status").notNull().default("applied"), // applied, screening, interview, hired, rejected, draft
  coverLetter: text("cover_letter"),
  resumeUrl: text("resume_url"),
  appliedAt: timestamp("applied_at").defaultNow().notNull(),
  isDraft: boolean("is_draft").default(false),
  templateId: integer("template_id").references(() => applicationTemplates.id),
  lastEditedAt: timestamp("last_edited_at").defaultNow(),
});

// Application Templates for Phase 2
export const applicationTemplates = pgTable("application_templates", {
  id: serial("id").primaryKey(),
  tenantId: integer("tenant_id").references(() => tenants.id).notNull(),
  candidateId: integer("candidate_id").references(() => users.id).notNull(),
  name: text("name").notNull(),
  description: text("description"),
  coverLetterTemplate: text("cover_letter_template"),
  customFields: jsonb("custom_fields").default({}),
  isDefault: boolean("is_default").default(false),
  usageCount: integer("usage_count").default(0),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Follow-up Reminders for Phase 2
export const followUpReminders = pgTable("follow_up_reminders", {
  id: serial("id").primaryKey(),
  tenantId: integer("tenant_id").references(() => tenants.id).notNull(),
  applicationId: integer("application_id").references(() => applications.id).notNull(),
  candidateId: integer("candidate_id").references(() => users.id).notNull(),
  reminderDate: timestamp("reminder_date").notNull(),
  reminderType: text("reminder_type").notNull(), // follow_up, interview_prep, thank_you, check_status
  message: text("message"),
  isCompleted: boolean("is_completed").default(false),
  completedAt: timestamp("completed_at"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Assessments
export const assessments = pgTable("assessments", {
  id: serial("id").primaryKey(),
  tenantId: integer("tenant_id").references(() => tenants.id).notNull(),
  title: text("title").notNull(),
  description: text("description"),
  questions: jsonb("questions").notNull(), // Array of question objects
  duration: integer("duration"), // in minutes
  isActive: boolean("is_active").notNull().default(true),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Assessment results
export const assessmentResults = pgTable("assessment_results", {
  id: serial("id").primaryKey(),
  tenantId: integer("tenant_id").references(() => tenants.id).notNull(),
  assessmentId: integer("assessment_id").references(() => assessments.id).notNull(),
  candidateId: integer("candidate_id").references(() => users.id).notNull(),
  score: decimal("score", { precision: 5, scale: 2 }),
  answers: jsonb("answers").notNull(),
  completedAt: timestamp("completed_at").defaultNow().notNull(),
});

// LMS Courses
export const courses = pgTable("courses", {
  id: serial("id").primaryKey(),
  tenantId: integer("tenant_id").references(() => tenants.id).notNull(),
  title: text("title").notNull(),
  description: text("description"),
  content: jsonb("content").notNull(), // Course modules and lessons
  duration: integer("duration"), // in hours
  isActive: boolean("is_active").notNull().default(true),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Course enrollments
export const enrollments = pgTable("enrollments", {
  id: serial("id").primaryKey(),
  tenantId: integer("tenant_id").references(() => tenants.id).notNull(),
  courseId: integer("course_id").references(() => courses.id).notNull(),
  userId: integer("user_id").references(() => users.id).notNull(),
  progress: decimal("progress", { precision: 5, scale: 2 }).default("0"),
  completedAt: timestamp("completed_at"),
  enrolledAt: timestamp("enrolled_at").defaultNow().notNull(),
});

// Usage tracking for billing
export const usageMetrics = pgTable("usage_metrics", {
  id: serial("id").primaryKey(),
  tenantId: integer("tenant_id").references(() => tenants.id).notNull(),
  userId: integer("user_id").references(() => users.id),
  feature: text("feature").notNull(), // candidate_views, assessments, resume_parsing, etc.
  count: integer("count").notNull().default(1),
  recordedAt: timestamp("recorded_at").defaultNow().notNull(),
});

// Subscription plans
export const subscriptionPlans = pgTable("subscription_plans", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  price: decimal("price", { precision: 10, scale: 2 }).notNull(),
  billingPeriod: text("billing_period").notNull(), // monthly, yearly
  features: jsonb("features").notNull(), // Feature limits and permissions
  isActive: boolean("is_active").notNull().default(true),
});

// User profiles for the Profile & Branding module
export const userProfiles = pgTable("user_profiles", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id).notNull().unique(),
  tenantId: integer("tenant_id").references(() => tenants.id).notNull(),
  profilePhoto: text("profile_photo"),
  bio: text("bio"),
  professionalSummary: text("professional_summary"),
  objective: text("objective"),
  phone: text("phone"),
  location: text("location"),
  website: text("website"),
  linkedinUrl: text("linkedin_url"),
  githubUrl: text("github_url"),
  portfolioUrl: text("portfolio_url"),
  personalBrandStatement: text("personal_brand_statement"),
  skills: jsonb("skills").default([]), // Array of skill objects
  experience: jsonb("experience").default([]), // Array of work experience
  education: jsonb("education").default([]), // Array of education
  certifications: jsonb("certifications").default([]), // Array of certifications
  projects: jsonb("projects").default([]), // Array of portfolio projects
  achievements: jsonb("achievements").default([]), // Array of achievements
  languages: jsonb("languages").default([]), // Array of languages
  isPublic: boolean("is_public").notNull().default(false),
  profileCompletionScore: integer("profile_completion_score").default(0),
  lastOptimized: timestamp("last_optimized"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Resume files and documents
export const resumeDocuments = pgTable("resume_documents", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").references(() => users.id).notNull(),
  tenantId: integer("tenant_id").references(() => tenants.id).notNull(),
  fileName: text("file_name").notNull(),
  fileUrl: text("file_url").notNull(),
  fileType: text("file_type").notNull(), // pdf, doc, docx
  fileSize: integer("file_size").notNull(),
  isPrimary: boolean("is_primary").notNull().default(false),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Profile analytics and views
export const profileViews = pgTable("profile_views", {
  id: serial("id").primaryKey(),
  profileUserId: integer("profile_user_id").references(() => users.id).notNull(),
  viewerUserId: integer("viewer_user_id").references(() => users.id),
  tenantId: integer("tenant_id").references(() => tenants.id).notNull(),
  viewerType: text("viewer_type").notNull(), // candidate, recruiter, admin, anonymous
  viewedAt: timestamp("viewed_at").defaultNow().notNull(),
});

// Enhanced subscription plans with billing features
export const enhancedSubscriptionPlans = pgTable("enhanced_subscription_plans", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description"),
  price: decimal("price", { precision: 10, scale: 2 }).notNull(),
  billingCycle: text("billing_cycle").notNull(), // monthly, yearly
  features: jsonb("features").notNull(),
  usageLimits: jsonb("usage_limits").notNull(), // { profileViews: 1000, videoUploads: 10, etc }
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Tenant subscriptions
export const tenantSubscriptions = pgTable("tenant_subscriptions", {
  id: serial("id").primaryKey(),
  tenantId: integer("tenant_id").references(() => tenants.id).notNull(),
  planId: integer("plan_id").references(() => enhancedSubscriptionPlans.id).notNull(),
  status: text("status").notNull(), // active, past_due, canceled, suspended
  currentPeriodStart: timestamp("current_period_start").notNull(),
  currentPeriodEnd: timestamp("current_period_end").notNull(),
  paymentMethodId: text("payment_method_id"),
  lastPaymentDate: timestamp("last_payment_date"),
  nextPaymentDate: timestamp("next_payment_date"),
  cancelAtPeriodEnd: boolean("cancel_at_period_end").default(false),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Usage tracking for billing
export const usageTracking = pgTable("usage_tracking", {
  id: serial("id").primaryKey(),
  tenantId: integer("tenant_id").references(() => tenants.id).notNull(),
  userId: integer("user_id").references(() => users.id),
  feature: text("feature").notNull(), // profileView, videoUpload, aiAnalysis, etc
  quantity: integer("quantity").default(1),
  metadata: jsonb("metadata"), // additional context
  billingPeriod: text("billing_period").notNull(), // YYYY-MM format
  createdAt: timestamp("created_at").defaultNow(),
});

// Billing invoices
export const billingInvoices = pgTable("billing_invoices", {
  id: serial("id").primaryKey(),
  tenantId: integer("tenant_id").references(() => tenants.id).notNull(),
  subscriptionId: integer("subscription_id").references(() => tenantSubscriptions.id),
  invoiceNumber: text("invoice_number").notNull().unique(),
  amount: decimal("amount", { precision: 10, scale: 2 }).notNull(),
  tax: decimal("tax", { precision: 10, scale: 2 }).default("0"),
  total: decimal("total", { precision: 10, scale: 2 }).notNull(),
  currency: text("currency").default("USD"),
  status: text("status").notNull(), // draft, sent, paid, overdue, void
  dueDate: timestamp("due_date").notNull(),
  paidAt: timestamp("paid_at"),
  paymentMethod: text("payment_method"),
  items: jsonb("items").notNull(), // invoice line items
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Payment methods
export const paymentMethods = pgTable("payment_methods", {
  id: serial("id").primaryKey(),
  tenantId: integer("tenant_id").references(() => tenants.id).notNull(),
  type: text("type").notNull(), // card, bank_account, digital_wallet
  provider: text("provider").notNull(), // demo, razorpay, paypal
  providerPaymentMethodId: text("provider_payment_method_id"),
  cardLast4: text("card_last4"),
  cardBrand: text("card_brand"),
  expiryMonth: integer("expiry_month"),
  expiryYear: integer("expiry_year"),
  holderName: text("holder_name"),
  billingAddress: jsonb("billing_address"),
  isDefault: boolean("is_default").default(false),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Billing alerts
export const billingAlerts = pgTable("billing_alerts", {
  id: serial("id").primaryKey(),
  tenantId: integer("tenant_id").references(() => tenants.id).notNull(),
  type: text("type").notNull(), // usage_limit, payment_failed, overdue, etc
  severity: text("severity").notNull(), // info, warning, critical
  title: text("title").notNull(),
  message: text("message").notNull(),
  metadata: jsonb("metadata"),
  isResolved: boolean("is_resolved").default(false),
  resolvedAt: timestamp("resolved_at"),
  createdAt: timestamp("created_at").defaultNow(),
});

// Usage quotas and overages
export const usageQuotas = pgTable("usage_quotas", {
  id: serial("id").primaryKey(),
  tenantId: integer("tenant_id").references(() => tenants.id).notNull(),
  feature: text("feature").notNull(),
  planLimit: integer("plan_limit").notNull(),
  currentUsage: integer("current_usage").default(0),
  billingPeriod: text("billing_period").notNull(), // YYYY-MM format
  overageCount: integer("overage_count").default(0),
  overageRate: decimal("overage_rate", { precision: 10, scale: 4 }), // cost per unit over limit
  lastResetAt: timestamp("last_reset_at").defaultNow(),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// ===============================
// RECRUITMENT SYSTEM TABLES
// ===============================

// Recruitment candidates - separate from users for bulk uploads
export const recruitmentCandidates = pgTable("recruitment_candidates", {
  id: serial("id").primaryKey(),
  tenantId: integer("tenant_id").references(() => tenants.id).notNull(),
  name: text("name").notNull(),
  email: text("email").notNull(),
  phone: text("phone"),
  education: text("education"),
  city: text("city"),
  college: text("college"),
  company: text("company"),
  experience: text("experience"),
  status: text("status").notNull().default("uploaded"), // uploaded, registered, tested, interviewed, shortlisted, offered, hired, rejected
  tags: text("tags").array().default([]),
  resumeUrl: text("resume_url"),
  linkedUserId: integer("linked_user_id").references(() => users.id), // Links to users table if candidate registers
  source: text("source").default("bulk_upload"), // bulk_upload, campaign, registration_form
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Candidate categories for organization
export const candidateCategories = pgTable("candidate_categories", {
  id: serial("id").primaryKey(),
  tenantId: integer("tenant_id").references(() => tenants.id).notNull(),
  name: text("name").notNull(),
  color: text("color").notNull().default("#3B82F6"),
  description: text("description"),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Candidate-category relationships
export const candidateCategoryTags = pgTable("candidate_category_tags", {
  id: serial("id").primaryKey(),
  candidateId: integer("candidate_id").references(() => recruitmentCandidates.id).notNull(),
  categoryId: integer("category_id").references(() => candidateCategories.id).notNull(),
  tenantId: integer("tenant_id").references(() => tenants.id).notNull(),
  assignedAt: timestamp("assigned_at").defaultNow().notNull(),
});

// Email campaigns for recruitment
export const emailCampaigns = pgTable("email_campaigns", {
  id: serial("id").primaryKey(),
  tenantId: integer("tenant_id").references(() => tenants.id).notNull(),
  createdBy: integer("created_by").references(() => users.id).notNull(),
  name: text("name").notNull(),
  subject: text("subject").notNull(),
  template: text("template").notNull(), // HTML email template
  status: text("status").notNull().default("draft"), // draft, scheduled, sending, sent, paused
  scheduledAt: timestamp("scheduled_at"),
  sentAt: timestamp("sent_at"),
  totalRecipients: integer("total_recipients").default(0),
  deliveredCount: integer("delivered_count").default(0),
  openedCount: integer("opened_count").default(0),
  clickedCount: integer("clicked_count").default(0),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Campaign recipients tracking
export const campaignRecipients = pgTable("campaign_recipients", {
  id: serial("id").primaryKey(),
  campaignId: integer("campaign_id").references(() => emailCampaigns.id).notNull(),
  candidateId: integer("candidate_id").references(() => recruitmentCandidates.id).notNull(),
  tenantId: integer("tenant_id").references(() => tenants.id).notNull(),
  status: text("status").notNull().default("pending"), // pending, sent, delivered, opened, clicked, bounced, failed
  sentAt: timestamp("sent_at"),
  deliveredAt: timestamp("delivered_at"),
  openedAt: timestamp("opened_at"),
  clickedAt: timestamp("clicked_at"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Registration forms for candidates
export const registrationForms = pgTable("registration_forms", {
  id: serial("id").primaryKey(),
  tenantId: integer("tenant_id").references(() => tenants.id).notNull(),
  createdBy: integer("created_by").references(() => users.id).notNull(),
  name: text("name").notNull(),
  title: text("title").notNull(),
  description: text("description"),
  fields: jsonb("fields").notNull(), // Dynamic form fields configuration
  branding: jsonb("branding"), // Logo, colors, company info
  paymentRequired: boolean("payment_required").default(false),
  amount: decimal("amount", { precision: 10, scale: 2 }),
  currency: text("currency").default("USD"),
  isActive: boolean("is_active").default(true),
  accessToken: text("access_token").notNull(), // Unique token for public access
  maxSubmissions: integer("max_submissions"),
  currentSubmissions: integer("current_submissions").default(0),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Registration form submissions
export const formSubmissions = pgTable("form_submissions", {
  id: serial("id").primaryKey(),
  formId: integer("form_id").references(() => registrationForms.id).notNull(),
  candidateId: integer("candidate_id").references(() => recruitmentCandidates.id),
  tenantId: integer("tenant_id").references(() => tenants.id).notNull(),
  submissionData: jsonb("submission_data").notNull(),
  paymentStatus: text("payment_status").default("pending"), // pending, completed, failed, refunded
  paymentId: text("payment_id"),
  submittedAt: timestamp("submitted_at").defaultNow().notNull(),
});

// Interview scheduling and management
export const interviews = pgTable("interviews", {
  id: serial("id").primaryKey(),
  tenantId: integer("tenant_id").references(() => tenants.id).notNull(),
  candidateId: integer("candidate_id").references(() => recruitmentCandidates.id).notNull(),
  scheduledBy: integer("scheduled_by").references(() => users.id).notNull(),
  title: text("title").notNull(),
  type: text("type").notNull().default("video"), // video, phone, in_person
  scheduledAt: timestamp("scheduled_at").notNull(),
  duration: integer("duration").default(60), // in minutes
  meetingLink: text("meeting_link"),
  location: text("location"),
  panelMembers: jsonb("panel_members").default([]), // Array of interviewer details
  status: text("status").notNull().default("scheduled"), // scheduled, completed, cancelled, no_show
  notes: text("notes"),
  feedback: jsonb("feedback"), // Interview feedback and ratings
  completedAt: timestamp("completed_at"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Offer letters and LOI management
export const offerLetters = pgTable("offer_letters", {
  id: serial("id").primaryKey(),
  tenantId: integer("tenant_id").references(() => tenants.id).notNull(),
  candidateId: integer("candidate_id").references(() => recruitmentCandidates.id).notNull(),
  createdBy: integer("created_by").references(() => users.id).notNull(),
  templateId: integer("template_id").references(() => offerTemplates.id),
  type: text("type").notNull().default("offer"), // offer, loi (letter of intent)
  title: text("title").notNull(),
  content: text("content").notNull(), // Generated letter content
  position: text("position").notNull(),
  department: text("department"),
  salary: decimal("salary", { precision: 12, scale: 2 }),
  currency: text("currency").default("USD"),
  startDate: timestamp("start_date"),
  benefits: jsonb("benefits"),
  status: text("status").notNull().default("draft"), // draft, sent, viewed, accepted, declined, expired
  expiresAt: timestamp("expires_at"),
  sentAt: timestamp("sent_at"),
  viewedAt: timestamp("viewed_at"),
  respondedAt: timestamp("responded_at"),
  accessToken: text("access_token").notNull(), // Unique token for candidate access
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Offer letter templates
export const offerTemplates = pgTable("offer_templates", {
  id: serial("id").primaryKey(),
  tenantId: integer("tenant_id").references(() => tenants.id).notNull(),
  name: text("name").notNull(),
  type: text("type").notNull().default("offer"), // offer, loi
  content: text("content").notNull(), // Template with merge fields
  fields: jsonb("fields").notNull(), // Available merge fields
  isDefault: boolean("is_default").default(false),
  isActive: boolean("is_active").default(true),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Job Requirements Labels for CV Tagging System
export const jobRequirementLabels = pgTable("job_requirement_labels", {
  id: serial("id").primaryKey(),
  tenantId: integer("tenant_id").references(() => tenants.id).notNull(),
  createdBy: integer("created_by").references(() => users.id).notNull(),
  title: text("title").notNull(),
  description: text("description"),
  department: text("department"),
  position: text("position"),
  experienceLevel: text("experience_level"), // entry, mid, senior, executive
  requiredSkills: jsonb("required_skills").default([]),
  preferredSkills: jsonb("preferred_skills").default([]),
  location: text("location"),
  remoteAllowed: boolean("remote_allowed").default(false),
  salaryRange: text("salary_range"),
  urgencyLevel: text("urgency_level").default("medium"), // low, medium, high, urgent
  status: text("status").notNull().default("active"), // active, paused, filled, archived
  linkedJobId: integer("linked_job_id").references(() => jobs.id), // Optional link to actual job posting
  color: text("color").default("#3B82F6"), // Color code for UI organization
  candidateCount: integer("candidate_count").default(0),
  targetCount: integer("target_count").default(10),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Candidate Label Assignments - Junction table for many-to-many relationship
export const candidateLabels = pgTable("candidate_labels", {
  id: serial("id").primaryKey(),
  tenantId: integer("tenant_id").references(() => tenants.id).notNull(),
  candidateId: integer("candidate_id").references(() => recruitmentCandidates.id).notNull(),
  labelId: integer("label_id").references(() => jobRequirementLabels.id).notNull(),
  assignedBy: integer("assigned_by").references(() => users.id).notNull(),
  status: text("status").notNull().default("reviewing"), // reviewing, shortlisted, interviewed, hired, rejected
  matchScore: integer("match_score"), // AI-calculated match score (0-100)
  notes: text("notes"),
  priority: text("priority").default("medium"), // low, medium, high
  source: text("source").notNull(), // ai_discovery, talent_pool, direct_application
  reviewedAt: timestamp("reviewed_at"),
  assignedAt: timestamp("assigned_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Recruitment payments tracking
export const recruitmentPayments = pgTable("recruitment_payments", {
  id: serial("id").primaryKey(),
  tenantId: integer("tenant_id").references(() => tenants.id).notNull(),
  candidateId: integer("candidate_id").references(() => recruitmentCandidates.id),
  formId: integer("form_id").references(() => registrationForms.id),
  assessmentId: integer("assessment_id").references(() => assessments.id),
  type: text("type").notNull(), // registration, test, interview
  amount: decimal("amount", { precision: 10, scale: 2 }).notNull(),
  currency: text("currency").default("USD"),
  status: text("status").notNull().default("pending"), // pending, completed, failed, refunded
  paymentGateway: text("payment_gateway").notNull(), // stripe, razorpay, demo
  gatewayPaymentId: text("gateway_payment_id"),
  gatewaySessionId: text("gateway_session_id"),
  metadata: jsonb("metadata"), // Additional payment context
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Recruitment analytics and reporting
export const recruitmentAnalytics = pgTable("recruitment_analytics", {
  id: serial("id").primaryKey(),
  tenantId: integer("tenant_id").references(() => tenants.id).notNull(),
  metric: text("metric").notNull(), // candidates_uploaded, emails_sent, registrations, tests_completed, interviews_scheduled, offers_made
  value: integer("value").notNull(),
  period: text("period").notNull(), // daily, weekly, monthly
  date: timestamp("date").notNull(),
  metadata: jsonb("metadata"), // Additional context
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Relations
export const tenantsRelations = relations(tenants, ({ many }) => ({
  users: many(users),
  jobs: many(jobs),
  assessments: many(assessments),
  courses: many(courses),
  usageMetrics: many(usageMetrics),
  subscriptions: many(tenantSubscriptions),
  invoices: many(billingInvoices),
  paymentMethods: many(paymentMethods),
  billingAlerts: many(billingAlerts),
  usageQuotas: many(usageQuotas),
  usageTracking: many(usageTracking),
  recruitmentCandidates: many(recruitmentCandidates),
  candidateCategories: many(candidateCategories),
  emailCampaigns: many(emailCampaigns),
  registrationForms: many(registrationForms),
  interviews: many(interviews),
  offerLetters: many(offerLetters),
  offerTemplates: many(offerTemplates),
  recruitmentPayments: many(recruitmentPayments),
  recruitmentAnalytics: many(recruitmentAnalytics),
}));

export const usersRelations = relations(users, ({ one, many }) => ({
  tenant: one(tenants, {
    fields: [users.tenantId],
    references: [tenants.id],
  }),
  profile: one(userProfiles, {
    fields: [users.id],
    references: [userProfiles.userId],
  }),
  jobs: many(jobs),
  applications: many(applications),
  assessmentResults: many(assessmentResults),
  enrollments: many(enrollments),
  usageMetrics: many(usageMetrics),
  resumeDocuments: many(resumeDocuments),
  profileViews: many(profileViews),
}));

export const jobsRelations = relations(jobs, ({ one, many }) => ({
  tenant: one(tenants, {
    fields: [jobs.tenantId],
    references: [tenants.id],
  }),
  recruiter: one(users, {
    fields: [jobs.recruiterId],
    references: [users.id],
  }),
  applications: many(applications),
}));

export const applicationsRelations = relations(applications, ({ one, many }) => ({
  tenant: one(tenants, {
    fields: [applications.tenantId],
    references: [tenants.id],
  }),
  job: one(jobs, {
    fields: [applications.jobId],
    references: [jobs.id],
  }),
  candidate: one(users, {
    fields: [applications.candidateId],
    references: [users.id],
  }),
  template: one(applicationTemplates, {
    fields: [applications.templateId],
    references: [applicationTemplates.id],
  }),
  followUpReminders: many(followUpReminders),
}));

export const applicationTemplatesRelations = relations(applicationTemplates, ({ one, many }) => ({
  tenant: one(tenants, {
    fields: [applicationTemplates.tenantId],
    references: [tenants.id],
  }),
  candidate: one(users, {
    fields: [applicationTemplates.candidateId],
    references: [users.id],
  }),
  applications: many(applications),
}));

export const followUpRemindersRelations = relations(followUpReminders, ({ one }) => ({
  tenant: one(tenants, {
    fields: [followUpReminders.tenantId],
    references: [tenants.id],
  }),
  application: one(applications, {
    fields: [followUpReminders.applicationId],
    references: [applications.id],
  }),
  candidate: one(users, {
    fields: [followUpReminders.candidateId],
    references: [users.id],
  }),
}));

export const assessmentsRelations = relations(assessments, ({ one, many }) => ({
  tenant: one(tenants, {
    fields: [assessments.tenantId],
    references: [tenants.id],
  }),
  results: many(assessmentResults),
}));

export const assessmentResultsRelations = relations(assessmentResults, ({ one }) => ({
  tenant: one(tenants, {
    fields: [assessmentResults.tenantId],
    references: [tenants.id],
  }),
  assessment: one(assessments, {
    fields: [assessmentResults.assessmentId],
    references: [assessments.id],
  }),
  candidate: one(users, {
    fields: [assessmentResults.candidateId],
    references: [users.id],
  }),
}));

export const coursesRelations = relations(courses, ({ one, many }) => ({
  tenant: one(tenants, {
    fields: [courses.tenantId],
    references: [tenants.id],
  }),
  enrollments: many(enrollments),
}));

export const enrollmentsRelations = relations(enrollments, ({ one }) => ({
  tenant: one(tenants, {
    fields: [enrollments.tenantId],
    references: [tenants.id],
  }),
  course: one(courses, {
    fields: [enrollments.courseId],
    references: [courses.id],
  }),
  user: one(users, {
    fields: [enrollments.userId],
    references: [users.id],
  }),
}));

export const usageMetricsRelations = relations(usageMetrics, ({ one }) => ({
  tenant: one(tenants, {
    fields: [usageMetrics.tenantId],
    references: [tenants.id],
  }),
  user: one(users, {
    fields: [usageMetrics.userId],
    references: [users.id],
  }),
}));

export const userProfilesRelations = relations(userProfiles, ({ one }) => ({
  user: one(users, {
    fields: [userProfiles.userId],
    references: [users.id],
  }),
  tenant: one(tenants, {
    fields: [userProfiles.tenantId],
    references: [tenants.id],
  }),
}));

export const resumeDocumentsRelations = relations(resumeDocuments, ({ one }) => ({
  user: one(users, {
    fields: [resumeDocuments.userId],
    references: [users.id],
  }),
  tenant: one(tenants, {
    fields: [resumeDocuments.tenantId],
    references: [tenants.id],
  }),
}));

export const profileViewsRelations = relations(profileViews, ({ one }) => ({
  profileUser: one(users, {
    fields: [profileViews.profileUserId],
    references: [users.id],
  }),
  viewerUser: one(users, {
    fields: [profileViews.viewerUserId],
    references: [users.id],
  }),
  tenant: one(tenants, {
    fields: [profileViews.tenantId],
    references: [tenants.id],
  }),
}));

// Billing table relations
export const enhancedSubscriptionPlansRelations = relations(enhancedSubscriptionPlans, ({ many }) => ({
  subscriptions: many(tenantSubscriptions),
}));

export const tenantSubscriptionsRelations = relations(tenantSubscriptions, ({ one, many }) => ({
  tenant: one(tenants, {
    fields: [tenantSubscriptions.tenantId],
    references: [tenants.id],
  }),
  plan: one(enhancedSubscriptionPlans, {
    fields: [tenantSubscriptions.planId],
    references: [enhancedSubscriptionPlans.id],
  }),
  invoices: many(billingInvoices),
}));

export const usageTrackingRelations = relations(usageTracking, ({ one }) => ({
  tenant: one(tenants, {
    fields: [usageTracking.tenantId],
    references: [tenants.id],
  }),
  user: one(users, {
    fields: [usageTracking.userId],
    references: [users.id],
  }),
}));

export const billingInvoicesRelations = relations(billingInvoices, ({ one }) => ({
  tenant: one(tenants, {
    fields: [billingInvoices.tenantId],
    references: [tenants.id],
  }),
  subscription: one(tenantSubscriptions, {
    fields: [billingInvoices.subscriptionId],
    references: [tenantSubscriptions.id],
  }),
}));

export const paymentMethodsRelations = relations(paymentMethods, ({ one }) => ({
  tenant: one(tenants, {
    fields: [paymentMethods.tenantId],
    references: [tenants.id],
  }),
}));

export const billingAlertsRelations = relations(billingAlerts, ({ one }) => ({
  tenant: one(tenants, {
    fields: [billingAlerts.tenantId],
    references: [tenants.id],
  }),
}));

export const usageQuotasRelations = relations(usageQuotas, ({ one }) => ({
  tenant: one(tenants, {
    fields: [usageQuotas.tenantId],
    references: [tenants.id],
  }),
}));

// Recruitment relations
export const recruitmentCandidatesRelations = relations(recruitmentCandidates, ({ one, many }) => ({
  tenant: one(tenants, {
    fields: [recruitmentCandidates.tenantId],
    references: [tenants.id],
  }),
  linkedUser: one(users, {
    fields: [recruitmentCandidates.linkedUserId],
    references: [users.id],
  }),
  categoryTags: many(candidateCategoryTags),
  campaignRecipients: many(campaignRecipients),
  interviews: many(interviews),
  offerLetters: many(offerLetters),
  payments: many(recruitmentPayments),
}));

export const candidateCategoriesRelations = relations(candidateCategories, ({ one, many }) => ({
  tenant: one(tenants, {
    fields: [candidateCategories.tenantId],
    references: [tenants.id],
  }),
  categoryTags: many(candidateCategoryTags),
}));

export const candidateCategoryTagsRelations = relations(candidateCategoryTags, ({ one }) => ({
  candidate: one(recruitmentCandidates, {
    fields: [candidateCategoryTags.candidateId],
    references: [recruitmentCandidates.id],
  }),
  category: one(candidateCategories, {
    fields: [candidateCategoryTags.categoryId],
    references: [candidateCategories.id],
  }),
  tenant: one(tenants, {
    fields: [candidateCategoryTags.tenantId],
    references: [tenants.id],
  }),
}));

export const emailCampaignsRelations = relations(emailCampaigns, ({ one, many }) => ({
  tenant: one(tenants, {
    fields: [emailCampaigns.tenantId],
    references: [tenants.id],
  }),
  createdBy: one(users, {
    fields: [emailCampaigns.createdBy],
    references: [users.id],
  }),
  recipients: many(campaignRecipients),
}));

export const campaignRecipientsRelations = relations(campaignRecipients, ({ one }) => ({
  campaign: one(emailCampaigns, {
    fields: [campaignRecipients.campaignId],
    references: [emailCampaigns.id],
  }),
  candidate: one(recruitmentCandidates, {
    fields: [campaignRecipients.candidateId],
    references: [recruitmentCandidates.id],
  }),
  tenant: one(tenants, {
    fields: [campaignRecipients.tenantId],
    references: [tenants.id],
  }),
}));

export const registrationFormsRelations = relations(registrationForms, ({ one, many }) => ({
  tenant: one(tenants, {
    fields: [registrationForms.tenantId],
    references: [tenants.id],
  }),
  createdBy: one(users, {
    fields: [registrationForms.createdBy],
    references: [users.id],
  }),
  submissions: many(formSubmissions),
}));

export const formSubmissionsRelations = relations(formSubmissions, ({ one }) => ({
  form: one(registrationForms, {
    fields: [formSubmissions.formId],
    references: [registrationForms.id],
  }),
  candidate: one(recruitmentCandidates, {
    fields: [formSubmissions.candidateId],
    references: [recruitmentCandidates.id],
  }),
  tenant: one(tenants, {
    fields: [formSubmissions.tenantId],
    references: [tenants.id],
  }),
}));

export const interviewsRelations = relations(interviews, ({ one }) => ({
  tenant: one(tenants, {
    fields: [interviews.tenantId],
    references: [tenants.id],
  }),
  candidate: one(recruitmentCandidates, {
    fields: [interviews.candidateId],
    references: [recruitmentCandidates.id],
  }),
  scheduledBy: one(users, {
    fields: [interviews.scheduledBy],
    references: [users.id],
  }),
}));

export const offerLettersRelations = relations(offerLetters, ({ one }) => ({
  tenant: one(tenants, {
    fields: [offerLetters.tenantId],
    references: [tenants.id],
  }),
  candidate: one(recruitmentCandidates, {
    fields: [offerLetters.candidateId],
    references: [recruitmentCandidates.id],
  }),
  createdBy: one(users, {
    fields: [offerLetters.createdBy],
    references: [users.id],
  }),
  template: one(offerTemplates, {
    fields: [offerLetters.templateId],
    references: [offerTemplates.id],
  }),
}));

export const offerTemplatesRelations = relations(offerTemplates, ({ one, many }) => ({
  tenant: one(tenants, {
    fields: [offerTemplates.tenantId],
    references: [tenants.id],
  }),
  offerLetters: many(offerLetters),
}));

export const recruitmentPaymentsRelations = relations(recruitmentPayments, ({ one }) => ({
  tenant: one(tenants, {
    fields: [recruitmentPayments.tenantId],
    references: [tenants.id],
  }),
  candidate: one(recruitmentCandidates, {
    fields: [recruitmentPayments.candidateId],
    references: [recruitmentCandidates.id],
  }),
  form: one(registrationForms, {
    fields: [recruitmentPayments.formId],
    references: [registrationForms.id],
  }),
  assessment: one(assessments, {
    fields: [recruitmentPayments.assessmentId],
    references: [assessments.id],
  }),
}));

export const recruitmentAnalyticsRelations = relations(recruitmentAnalytics, ({ one }) => ({
  tenant: one(tenants, {
    fields: [recruitmentAnalytics.tenantId],
    references: [tenants.id],
  }),
}));

// Insert schemas
export const insertTenantSchema = createInsertSchema(tenants).omit({
  id: true,
  createdAt: true,
});

export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
});

export const insertJobSchema = createInsertSchema(jobs).omit({
  id: true,
  createdAt: true,
});

export const insertApplicationSchema = createInsertSchema(applications).omit({
  id: true,
  appliedAt: true,
  lastEditedAt: true,
});

export const insertApplicationTemplateSchema = createInsertSchema(applicationTemplates).omit({
  id: true,
  createdAt: true,
});

export const insertFollowUpReminderSchema = createInsertSchema(followUpReminders).omit({
  id: true,
  createdAt: true,
  completedAt: true,
});

export const insertAssessmentSchema = createInsertSchema(assessments).omit({
  id: true,
  createdAt: true,
});

export const insertAssessmentResultSchema = createInsertSchema(assessmentResults).omit({
  id: true,
  completedAt: true,
});

export const insertCourseSchema = createInsertSchema(courses).omit({
  id: true,
  createdAt: true,
});

export const insertEnrollmentSchema = createInsertSchema(enrollments).omit({
  id: true,
  enrolledAt: true,
});

export const insertUsageMetricSchema = createInsertSchema(usageMetrics).omit({
  id: true,
  recordedAt: true,
});

export const insertSubscriptionPlanSchema = createInsertSchema(subscriptionPlans).omit({
  id: true,
});

export const insertUserProfileSchema = createInsertSchema(userProfiles).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

// Recruitment insert schemas
export const insertRecruitmentCandidateSchema = createInsertSchema(recruitmentCandidates).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertCandidateCategorySchema = createInsertSchema(candidateCategories).omit({
  id: true,
  createdAt: true,
});

export const insertCandidateCategoryTagSchema = createInsertSchema(candidateCategoryTags).omit({
  id: true,
  assignedAt: true,
});

export const insertEmailCampaignSchema = createInsertSchema(emailCampaigns).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertCampaignRecipientSchema = createInsertSchema(campaignRecipients).omit({
  id: true,
  createdAt: true,
});

export const insertRegistrationFormSchema = createInsertSchema(registrationForms).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertFormSubmissionSchema = createInsertSchema(formSubmissions).omit({
  id: true,
  submittedAt: true,
});

export const insertInterviewSchema = createInsertSchema(interviews).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertOfferLetterSchema = createInsertSchema(offerLetters).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertOfferTemplateSchema = createInsertSchema(offerTemplates).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertRecruitmentPaymentSchema = createInsertSchema(recruitmentPayments).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertRecruitmentAnalyticsSchema = createInsertSchema(recruitmentAnalytics).omit({
  id: true,
  createdAt: true,
});

// Job Requirements Labels insert schemas
export const insertJobRequirementLabelSchema = createInsertSchema(jobRequirementLabels).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertCandidateLabelSchema = createInsertSchema(candidateLabels).omit({
  id: true,
  assignedAt: true,
  updatedAt: true,
});

// Type exports for recruitment
export type SelectRecruitmentCandidate = typeof recruitmentCandidates.$inferSelect;
export type InsertRecruitmentCandidate = z.infer<typeof insertRecruitmentCandidateSchema>;
export type SelectCandidateCategory = typeof candidateCategories.$inferSelect;
export type InsertCandidateCategory = z.infer<typeof insertCandidateCategorySchema>;
export type SelectEmailCampaign = typeof emailCampaigns.$inferSelect;
export type InsertEmailCampaign = z.infer<typeof insertEmailCampaignSchema>;
export type SelectRegistrationForm = typeof registrationForms.$inferSelect;
export type InsertRegistrationForm = z.infer<typeof insertRegistrationFormSchema>;
export type SelectInterview = typeof interviews.$inferSelect;
export type InsertInterview = z.infer<typeof insertInterviewSchema>;
export type SelectOfferLetter = typeof offerLetters.$inferSelect;
export type InsertOfferLetter = z.infer<typeof insertOfferLetterSchema>;
export type SelectOfferTemplate = typeof offerTemplates.$inferSelect;
export type InsertOfferTemplate = z.infer<typeof insertOfferTemplateSchema>;
export type SelectRecruitmentPayment = typeof recruitmentPayments.$inferSelect;
export type InsertRecruitmentPayment = z.infer<typeof insertRecruitmentPaymentSchema>;
export type SelectRecruitmentAnalytics = typeof recruitmentAnalytics.$inferSelect;
export type InsertRecruitmentAnalytics = z.infer<typeof insertRecruitmentAnalyticsSchema>;

// Job Requirements Labels types
export type SelectJobRequirementLabel = typeof jobRequirementLabels.$inferSelect;
export type InsertJobRequirementLabel = z.infer<typeof insertJobRequirementLabelSchema>;
export type SelectCandidateLabel = typeof candidateLabels.$inferSelect;
export type InsertCandidateLabel = z.infer<typeof insertCandidateLabelSchema>;

export const insertResumeDocumentSchema = createInsertSchema(resumeDocuments).omit({
  id: true,
  createdAt: true,
});

export const insertProfileViewSchema = createInsertSchema(profileViews).omit({
  id: true,
  viewedAt: true,
});

// Billing insert schemas
export const insertEnhancedSubscriptionPlanSchema = createInsertSchema(enhancedSubscriptionPlans).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertTenantSubscriptionSchema = createInsertSchema(tenantSubscriptions).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertUsageTrackingSchema = createInsertSchema(usageTracking).omit({
  id: true,
  createdAt: true,
});

export const insertBillingInvoiceSchema = createInsertSchema(billingInvoices).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertPaymentMethodSchema = createInsertSchema(paymentMethods).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertBillingAlertSchema = createInsertSchema(billingAlerts).omit({
  id: true,
  createdAt: true,
});

export const insertUsageQuotaSchema = createInsertSchema(usageQuotas).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

// Test and Assessment schemas
export const tests = pgTable("tests", {
  id: text("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description"),
  duration: integer("duration").notNull(), // minutes
  totalQuestions: integer("total_questions").notNull(),
  passingScore: integer("passing_score").notNull(),
  difficulty: text("difficulty", { enum: ["beginner", "intermediate", "advanced", "expert"] }).notNull(),
  category: text("category").notNull(),
  tags: text("tags").array(),
  status: text("status", { enum: ["draft", "published", "archived"] }).default("draft"),
  tenantId: integer("tenant_id").references(() => tenants.id).notNull(),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const questions = pgTable("questions", {
  id: text("id").primaryKey(),
  testId: text("test_id").references(() => tests.id).notNull(),
  type: text("type", { enum: ["multiple_choice", "essay", "coding", "true_false"] }).notNull(),
  title: text("title").notNull(),
  content: text("content").notNull(),
  options: text("options").array(),
  correctAnswer: text("correct_answer"),
  explanation: text("explanation"),
  points: integer("points").default(1),
  timeLimit: integer("time_limit"), // seconds
  order: integer("order").notNull(),
  tags: text("tags").array(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const testAttempts = pgTable("test_attempts", {
  id: text("id").primaryKey(),
  testId: text("test_id").references(() => tests.id).notNull(),
  userId: integer("user_id").references(() => users.id).notNull(),
  tenantId: integer("tenant_id").references(() => tenants.id).notNull(),
  answers: jsonb("answers"),
  score: integer("score"),
  timeSpent: integer("time_spent"), // seconds
  startedAt: timestamp("started_at").defaultNow(),
  completedAt: timestamp("completed_at"),
  // passed: boolean("passed").default(false), // temporarily commented out until database migration
  status: text("status", { enum: ["in_progress", "completed", "abandoned"] }).default("in_progress"),
});

// Certification schemas
export const certifications = pgTable("certifications", {
  id: text("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description"),
  type: text("type", { enum: ["test", "project", "mock_interview", "skill", "course"] }).notNull(),
  // Fixed field mappings to match frontend expectations
  issuer: text("issuer").notNull(), // changed from issuerId to issuer
  userId: integer("user_id").references(() => users.id).notNull(),
  tenantId: integer("tenant_id").references(() => tenants.id).notNull(),
  issueDate: timestamp("issue_date").defaultNow(), // changed from issuedDate to issueDate
  expiryDate: timestamp("expiry_date"),
  score: integer("score").notNull().default(0), // made required with default
  passingScore: integer("passing_score"),
  credentialId: text("credential_id").notNull().unique(),
  verificationUrl: text("verification_url"),
  verificationCode: text("verification_code"), // added missing field
  certificateHash: text("certificate_hash"), // added missing field
  level: text("level", { enum: ["Beginner", "Intermediate", "Advanced", "Expert"] }), // added missing field
  verified: boolean("verified").default(true), // added missing field
  status: text("status", { enum: ["active", "expired", "revoked"] }).default("active"),
  skills: text("skills").array(),
  metadata: jsonb("metadata"),
});

// Project schemas
export const projects = pgTable("projects", {
  id: text("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description"),
  language: text("language").notNull(),
  framework: text("framework"),
  userId: integer("user_id").references(() => users.id).notNull(),
  tenantId: integer("tenant_id").references(() => tenants.id).notNull(),
  status: text("status", { enum: ["draft", "in_progress", "completed", "submitted"] }).default("draft"),
  repositoryUrl: text("repository_url"),
  liveUrl: text("live_url"),
  settings: jsonb("settings"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const projectFiles = pgTable("project_files", {
  id: text("id").primaryKey(),
  projectId: text("project_id").references(() => projects.id).notNull(),
  name: text("name").notNull(),
  path: text("path").notNull(),
  type: text("type", { enum: ["file", "folder"] }).notNull(),
  content: text("content"),
  language: text("language"),
  size: integer("size"),
  parentId: text("parent_id"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Job schemas
export const jobPostings = pgTable("job_postings", {
  id: text("id").primaryKey(),
  title: text("title").notNull(),
  company: text("company").notNull(),
  location: text("location"),
  type: text("type", { enum: ["full-time", "part-time", "contract", "internship"] }).notNull(),
  remote: boolean("remote").default(false),
  salaryMin: integer("salary_min"),
  salaryMax: integer("salary_max"),
  description: text("description").notNull(),
  requirements: text("requirements").array(),
  benefits: text("benefits").array(),
  tenantId: integer("tenant_id").references(() => tenants.id).notNull(),
  postedBy: integer("posted_by").references(() => users.id).notNull(),
  status: text("status", { enum: ["draft", "published", "closed"] }).default("draft"),
  postedDate: timestamp("posted_date").defaultNow(),
  closingDate: timestamp("closing_date"),
});

export const jobApplications = pgTable("job_applications", {
  id: text("id").primaryKey(),
  jobId: text("job_id").references(() => jobPostings.id).notNull(),
  userId: integer("user_id").references(() => users.id).notNull(),
  tenantId: integer("tenant_id").references(() => tenants.id).notNull(),
  status: text("status", { enum: ["applied", "reviewing", "interview", "offer", "hired", "rejected"] }).default("applied"),
  coverLetter: text("cover_letter"),
  resumeUrl: text("resume_url"),
  appliedDate: timestamp("applied_date").defaultNow(),
  notes: text("notes"),
});

// User settings and preferences
export const userSettings = pgTable("user_settings", {
  id: text("id").primaryKey(),
  userId: integer("user_id").references(() => users.id).notNull().unique(),
  emailNotifications: boolean("email_notifications").default(true),
  smsNotifications: boolean("sms_notifications").default(false),
  profilePublic: boolean("profile_public").default(true),
  theme: text("theme", { enum: ["light", "dark", "system"] }).default("light"),
  language: text("language").default("en"),
  timezone: text("timezone").default("UTC"),
  preferences: jsonb("preferences"),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Insert schemas for new tables
export const insertTestSchema = createInsertSchema(tests);
export const insertQuestionSchema = createInsertSchema(questions);
export const insertTestAttemptSchema = createInsertSchema(testAttempts);
export const insertCertificationSchema = createInsertSchema(certifications);
export const insertProjectSchema = createInsertSchema(projects);
export const insertProjectFileSchema = createInsertSchema(projectFiles);
export const insertJobPostingSchema = createInsertSchema(jobPostings);
export const insertJobApplicationSchema = createInsertSchema(jobApplications);
export const insertUserSettingsSchema = createInsertSchema(userSettings);

// Types
export type Tenant = typeof tenants.$inferSelect;
export type InsertTenant = z.infer<typeof insertTenantSchema>;
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type Job = typeof jobs.$inferSelect;
export type InsertJob = z.infer<typeof insertJobSchema>;
export type Application = typeof applications.$inferSelect;
export type InsertApplication = z.infer<typeof insertApplicationSchema>;
export type Assessment = typeof assessments.$inferSelect;
export type InsertAssessment = z.infer<typeof insertAssessmentSchema>;
export type AssessmentResult = typeof assessmentResults.$inferSelect;
export type InsertAssessmentResult = z.infer<typeof insertAssessmentResultSchema>;
export type Course = typeof courses.$inferSelect;
export type InsertCourse = z.infer<typeof insertCourseSchema>;
export type Enrollment = typeof enrollments.$inferSelect;

// New table types
export type Test = typeof tests.$inferSelect;
export type InsertTest = z.infer<typeof insertTestSchema>;
export type Question = typeof questions.$inferSelect;
export type InsertQuestion = z.infer<typeof insertQuestionSchema>;
export type TestAttempt = typeof testAttempts.$inferSelect;
export type InsertTestAttempt = z.infer<typeof insertTestAttemptSchema>;
export type Certification = typeof certifications.$inferSelect;
export type InsertCertification = z.infer<typeof insertCertificationSchema>;
export type Project = typeof projects.$inferSelect;
export type InsertProject = z.infer<typeof insertProjectSchema>;
export type ProjectFile = typeof projectFiles.$inferSelect;
export type InsertProjectFile = z.infer<typeof insertProjectFileSchema>;
export type JobPosting = typeof jobPostings.$inferSelect;
export type InsertJobPosting = z.infer<typeof insertJobPostingSchema>;
export type JobApplication = typeof jobApplications.$inferSelect;
export type InsertJobApplication = z.infer<typeof insertJobApplicationSchema>;
export type UserSettings = typeof userSettings.$inferSelect;
export type InsertUserSettings = z.infer<typeof insertUserSettingsSchema>;
export type InsertEnrollment = z.infer<typeof insertEnrollmentSchema>;
export type UsageMetric = typeof usageMetrics.$inferSelect;
export type InsertUsageMetric = z.infer<typeof insertUsageMetricSchema>;
export type SubscriptionPlan = typeof subscriptionPlans.$inferSelect;
export type InsertSubscriptionPlan = z.infer<typeof insertSubscriptionPlanSchema>;
export type UserProfile = typeof userProfiles.$inferSelect;
export type InsertUserProfile = z.infer<typeof insertUserProfileSchema>;
export type ResumeDocument = typeof resumeDocuments.$inferSelect;
export type InsertResumeDocument = z.infer<typeof insertResumeDocumentSchema>;
export type ProfileView = typeof profileViews.$inferSelect;
export type InsertProfileView = z.infer<typeof insertProfileViewSchema>;

// Billing types
export type EnhancedSubscriptionPlan = typeof enhancedSubscriptionPlans.$inferSelect;
export type InsertEnhancedSubscriptionPlan = z.infer<typeof insertEnhancedSubscriptionPlanSchema>;
export type TenantSubscription = typeof tenantSubscriptions.$inferSelect;
export type InsertTenantSubscription = z.infer<typeof insertTenantSubscriptionSchema>;
export type UsageTracking = typeof usageTracking.$inferSelect;
export type InsertUsageTracking = z.infer<typeof insertUsageTrackingSchema>;
export type BillingInvoice = typeof billingInvoices.$inferSelect;
export type InsertBillingInvoice = z.infer<typeof insertBillingInvoiceSchema>;
export type PaymentMethod = typeof paymentMethods.$inferSelect;
export type InsertPaymentMethod = z.infer<typeof insertPaymentMethodSchema>;
export type BillingAlert = typeof billingAlerts.$inferSelect;
export type InsertBillingAlert = z.infer<typeof insertBillingAlertSchema>;
export type UsageQuota = typeof usageQuotas.$inferSelect;
export type InsertUsageQuota = z.infer<typeof insertUsageQuotaSchema>;
